*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZWM_CONFIG......................................*
DATA:  BEGIN OF STATUS_ZWM_CONFIG                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZWM_CONFIG                    .
CONTROLS: TCTRL_ZWM_CONFIG
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZWM_CONFIG                    .
TABLES: ZWM_CONFIG                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
