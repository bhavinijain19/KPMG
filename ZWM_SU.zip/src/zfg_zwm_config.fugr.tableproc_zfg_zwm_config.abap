*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_ZWM_CONFIG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_ZWM_CONFIG      .

  PERFORM TABLEPROC.

ENDFUNCTION.
