*&---------------------------------------------------------------------*
*& Report  ZWM_SU_CREATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zwm_su_create.

CONSTANTS : lv_eve TYPE swetypecou-event VALUE 'RELEASED',
            lv_rec TYPE  swetypecou-rectype VALUE '',
            lv_obt TYPE swetypecou-objtype VALUE 'AFVC_PM'.

DATA : lv_obk TYPE sweinstcou-objkey VALUE '',
       lt_tab TYPE TABLE OF swcont.

DATA : lv_qty TYPE int4.

SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS : p_aufnr TYPE aufnr.
SELECTION-SCREEN : END OF BLOCK b1 .

AT SELECTION-SCREEN.

  SELECT
    aufnr ,
    lenum ,
    tanum ,
    su_qty ,
    del_flg
  FROM zwm_su
  INTO TABLE @DATA(it_su)
  WHERE aufnr = @p_aufnr.

  SELECT
    aufnr ,
    aufpl ,
    ftrmi ,
    gamng
FROM afko
INTO TABLE @DATA(it_afko)
WHERE aufnr = @p_aufnr.


  LOOP AT it_su INTO DATA(ls_su) WHERE del_flg <> 'X'.
    lv_qty = lv_qty + ls_su-su_qty.
  ENDLOOP.
  DATA(lv_qty1) = lv_qty.

  READ TABLE it_afko INTO DATA(ls_afko) WITH KEY aufnr = p_aufnr.
  IF sy-subrc = 0.
    LOOP AT it_su ASSIGNING FIELD-SYMBOL(<fs_su>) WHERE del_flg = 'X'.
      IF ls_afko-gamng > lv_qty.
        <fs_su>-del_flg = ''.
        UPDATE  zwm_su SET del_flg = '' WHERE aufnr = <fs_su>-aufnr AND lenum = <fs_su>-lenum .
        COMMIT WORK.
        lv_qty = lv_qty + <fs_su>-su_qty.
      ENDIF.
    ENDLOOP.
    IF lv_qty <> lv_qty1 .
      READ TABLE it_su INTO DATA(wa_su) WITH KEY aufnr = p_aufnr.
      IF wa_su-lenum IS NOT INITIAL.
        MESSAGE 'Deletion Flag is Removed but SU is Already Generated' TYPE 'I'.
        exit.
      ENDIF.
    ENDIF.
  ENDIF.

  READ TABLE it_su INTO wa_su WITH KEY aufnr = p_aufnr.
  IF wa_su-lenum IS NOT INITIAL.
    MESSAGE 'SU is Already Generated' TYPE 'I'.
    exit.
  ENDIF.

  READ TABLE it_afko INTO DATA(wa_afko) WITH KEY aufnr = p_aufnr.
  IF wa_afko-ftrmi IS INITIAL.
    MESSAGE 'The production order is not released' TYPE 'E'.
  ENDIF.

*  IF sy-subrc = 0.
  IF it_su is INITIAL .
    lv_obk = wa_afko-aufpl.

    SHIFT lv_obk  LEFT DELETING LEADING '0'.
    CALL FUNCTION 'ZWM_FM_SU_GEN'
      EXPORTING
        event              = lv_eve
        rectype            = lv_rec
        objtype            = lv_obt
        objkey             = lv_obk
        exceptions_allowed = 'X'
* IMPORTING
*       REC_ID             =
*      TABLES
*        event_container    = lt_tab
      EXCEPTIONS
        invalid_type       = 1
        update_failed      = 2
        temp_error         = 3
        OTHERS             = 4.
  ENDIF.

  CLEAR : lv_qty ,wa_su , ls_su , ls_afko.
