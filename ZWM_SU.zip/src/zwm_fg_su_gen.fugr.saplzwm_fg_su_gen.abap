*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_FG_SU_GENTOP.                 " Global Declarations
  INCLUDE LZWM_FG_SU_GENUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_FG_SU_GENF...                 " Subroutines
* INCLUDE LZWM_FG_SU_GENO...                 " PBO-Modules
* INCLUDE LZWM_FG_SU_GENI...                 " PAI-Modules
* INCLUDE LZWM_FG_SU_GENE...                 " Events
* INCLUDE LZWM_FG_SU_GENP...                 " Local class implement.
* INCLUDE LZWM_FG_SU_GENT99.                 " ABAP Unit tests
