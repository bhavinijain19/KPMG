FUNCTION-POOL ZWM_FG_SU_GEN.                "MESSAGE-ID ..

* INCLUDE LZWM_FG_SU_GEND...                 " Local class definition
