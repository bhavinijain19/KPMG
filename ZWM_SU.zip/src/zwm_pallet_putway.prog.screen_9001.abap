PROCESS BEFORE OUTPUT.
 MODULE STATUS_9001.

PROCESS AFTER INPUT.
 FIELD gs_elements-palletno MODULE get_palletno ON REQUEST.
 FIELD gs_elements-lgpla    MODULE get_bin      ON REQUEST.

 MODULE user_command_9001.
