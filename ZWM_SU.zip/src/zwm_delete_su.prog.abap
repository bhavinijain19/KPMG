*&---------------------------------------------------------------------*
*& Report  ZWM_DELETE_SU
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zwm_delete_su.

TYPE-POOLS:slis.
TABLES:afpo.

TYPES:BEGIN OF ty_final,
        chkbx TYPE c.
        INCLUDE STRUCTURE zwm_su.
TYPES:END OF ty_final.
TYPES:BEGIN OF ty_pallet,
        chkbx          TYPE c,
        palletno       TYPE zwm_su-palletno,
        pal_qty        TYPE zwm_su-pal_qty,
        lenum          TYPE lenum,
        su_from        TYPE lenum,
        su_to          TYPE lenum,
        su_qty         TYPE zwm_su-su_qty,
        aufnr          TYPE aufnr,
        matnr          TYPE zwm_su-matnr,
        charg          TYPE zwm_su-charg,
        werks          TYPE zwm_su-werks,
        pal_print      TYPE c,
        pal_createdate TYPE sydatum,
        pal_createtime TYPE syuzeit,
        pal_createname TYPE lvs_bname,
        pal_date       TYPE sydatum,
        pal_time       TYPE syuzeit,
        pal_name       TYPE lvs_bname,
        re_pal_print   TYPE c,
        re_pal_date    TYPE sydatum,
        re_pal_time    TYPE syuzeit,
        re_pal_name    TYPE lvs_bname,
        zlotno         TYPE zwm_su-zlotno,
        zprange        TYPE zwm_su-zprange,
        su_cnt(4)      TYPE c,
      END OF ty_pallet,

      BEGIN OF t_header,
        plant_name1(40),
        plant_street(60),
        plant_house_num1(10),
        plant_house_num2(10),
        plant_str_suppl1(40),
        plant_str_suppl2(40),
        plant_str_suppl3(40),
        plant_city1(40),
        plant_city2(40),
        plant_post_code1(10),
        plant_region(10),
        plant_country(10),
      END OF t_header,

      BEGIN OF ty_addr,
        street_address1(200),
        street_address2(200),
        street_address3(200),
        street_address4(200),
        city_address1(200),
        state_address1(200),
      END OF ty_addr,

      BEGIN OF ty_ad,
        lenum     TYPE lenum,
        matnr     TYPE  matnr,
        charg     TYPE charg_d,
        uom       TYPE lhmeh1,
        hsdat     TYPE hsdat,
        maktx     TYPE maktx,
        su_qty    TYPE gamng,
        su_cnt(4) TYPE c,
      END OF ty_ad,

      BEGIN OF ty_paint,
        lenum     TYPE lenum,
        matnr     TYPE  matnr,
        charg     TYPE charg_d,
        su_qty    TYPE gamng,
        meins     TYPE meins,
        hsdat     TYPE hsdat,
        maktx     TYPE maktx,
        lgpla     TYPE lgpla,
        groes     TYPE mara-groes,
        kbetr     TYPE konp-kbetr,
        kbetr1    TYPE konp-kbetr,
        kmein     TYPE konp-kmein,
        kmein1    TYPE konp-kmein,
        total     TYPE marm-umren,
        meinh     TYPE marm-meinh,
        umren1    TYPE  kbetr,
        "Changed by UDAYABAP03 on 10.04.2026
*        mvgr5     TYPE mvke-mvgr5,
        mvgr1     TYPE mvke-mvgr1,
        "Changed by UDAYABAP03 on 10.04.2026
        v_conve2  TYPE kbetr,
        kbetr_mrp TYPE konp-kbetr,
        su_cnt(4) TYPE c,
      END OF ty_paint.

DATA: gt_final           TYPE STANDARD TABLE OF ty_final,
      gt_pallet          TYPE STANDARD TABLE OF ty_pallet,
      lt_ad              TYPE TABLE OF ty_ad,
      lt_paint           TYPE TABLE OF ty_paint,
      lv_umrez           TYPE marm-umrez,
      lv_umrez1          TYPE marm-umrez,
      ls_paint           TYPE ty_paint,
      ls_ad              TYPE ty_ad,
      gv_flag            TYPE c,
      gv_qty             TYPE zwm_su-pal_qty,
      gv_qty1            TYPE zwm_su-su_qty,
      i_mrp              TYPE j_1itaxvar-j_1itaxam1,
      o_mrp              TYPE j_1itaxvar-j_1itaxam1,
      wa_address         TYPE ty_addr,
      wa_header          TYPE t_header,
      v_region           TYPE t005u-bezei,
      v_country          TYPE t005t-landx50,
      gs_pallet          TYPE ty_pallet,
      gs_final           TYPE ty_final,
      wa_fieldcat        TYPE slis_fieldcat_alv,
      v_lenum            TYPE lqua-lenum,
      v_palno            TYPE zwm_su-palletno,
      it_fieldcat        TYPE slis_t_fieldcat_alv,
      ls_layout          TYPE TABLE OF slis_layout_alv WITH HEADER LINE,
      wa_sort            TYPE slis_sortinfo_alv,
      it_sort            TYPE slis_t_sortinfo_alv,
      w_cnt2             TYPE i,
      v_form_name        TYPE rs38l_fnam,
      control_parameters TYPE ssfctrlop,
      wa_final           TYPE zsu_label_initial,
      wa_aheader         TYPE slis_listheader,
      it_aheader         TYPE slis_t_listheader,
      lv_warehouse_type  TYPE zwm_de_warehouse_type VALUE 'Plant'.

DATA:s_rv  TYPE meinh,
     s_rv1 TYPE vkorg.
DATA : lv_mtart TYPE mara-mtart. "Added by Raj on 18.06.2024

DATA: bdcdata LIKE bdcdata    OCCURS 0 WITH HEADER LINE,
      p_mode  LIKE ctu_params-dismode VALUE 'N'.
DATA:wa_msg TYPE bdcmsgcoll,
     it_msg TYPE TABLE OF bdcmsgcoll.

DATA : ls_wm TYPE zwm_pp.

RANGES:gc_rv  FOR s_rv,
       gc_rv1 FOR s_rv1.

FIELD-SYMBOLS:<fs_final> TYPE ty_final.

SELECTION-SCREEN:BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-010.
  SELECTION-SCREEN COMMENT /1(79) TEXT-001.
  PARAMETERS:r1  RADIOBUTTON GROUP g1 DEFAULT 'X' USER-COMMAND s2 MODIF ID rb1,
             r2  RADIOBUTTON GROUP g1 MODIF ID rb1,
             r3  RADIOBUTTON GROUP g1 MODIF ID rb1,
             r4  RADIOBUTTON GROUP g1 MODIF ID rb1,
             r10 RADIOBUTTON GROUP g1 MODIF ID rb1.
  SELECTION-SCREEN SKIP 1.
  SELECTION-SCREEN COMMENT /1(79) TEXT-002.
  PARAMETERS:r6  RADIOBUTTON GROUP g1,
             r5  RADIOBUTTON GROUP g1,
             r7  RADIOBUTTON GROUP g1,
             r8  RADIOBUTTON GROUP g1,
             r9  RADIOBUTTON GROUP g1,
             r11 RADIOBUTTON GROUP g1.
SELECTION-SCREEN:END OF BLOCK b2.

SELECTION-SCREEN:BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-010.
  SELECT-OPTIONS:s_aufnr  FOR afpo-aufnr NO INTERVALS NO-EXTENSION MODIF ID prd,
                 s_aufnr1 FOR afpo-aufnr NO INTERVALS NO-EXTENSION MODIF ID sup,
                 s_lenum  FOR v_lenum MODIF ID su,
                 s_palno  FOR v_palno MODIF ID pal.
  PARAMETERS:p_data TYPE sy-datum MODIF ID dat.
  PARAMETERS:r_br RADIOBUTTON GROUP g2 DEFAULT 'X' USER-COMMAND s2 MODIF ID brc,
             r_qr RADIOBUTTON GROUP g2 MODIF ID brc.

  PARAMETERS:r_ad RADIOBUTTON GROUP g3 DEFAULT 'X' USER-COMMAND s2 MODIF ID typ,
             r_pt RADIOBUTTON GROUP g3 MODIF ID typ.

  PARAMETERS:r_mrp  RADIOBUTTON GROUP g4 DEFAULT 'X' USER-COMMAND s2 MODIF ID mrp,
             r_wmrp RADIOBUTTON GROUP g4 MODIF ID mrp.
SELECTION-SCREEN:END OF BLOCK b1.

AT SELECTION-SCREEN OUTPUT.

  LOOP AT SCREEN.
    CASE screen-group1.
      WHEN 'MRP'.
        IF r5 EQ abap_true OR r6 EQ abap_true OR r7  EQ abap_true OR
           r8 EQ abap_true OR r9 EQ abap_true OR r11 EQ abap_true OR r_ad EQ abap_true OR
           r1 EQ abap_true OR r2 EQ abap_true OR r10 EQ abap_true OR r4 EQ abap_true OR r_qr EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'TYP'.
        IF r5 EQ abap_true OR r6 EQ abap_true OR r7  EQ abap_true OR
           r8 EQ abap_true OR r9 EQ abap_true OR r11 EQ abap_true OR r_qr EQ abap_true OR
           r1 EQ abap_true OR r2 EQ abap_true OR r4 EQ abap_true OR r10  EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'BRC'.
        IF r5 EQ abap_true OR r6 EQ abap_true OR r7  EQ abap_true OR
           r8 EQ abap_true OR r9 EQ abap_true OR r11 EQ abap_true OR
           r1 EQ abap_true OR r2 EQ abap_true OR r10 EQ abap_true OR r4 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'SU'.
        IF r5 EQ abap_true OR r6 EQ abap_true OR r7 EQ abap_true
                           OR r8 EQ abap_true OR r9 EQ abap_true
                           OR r11 EQ abap_true OR r2 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'PAL'.
        IF r1 EQ abap_true OR r2 EQ abap_true OR r3 EQ abap_true
                           OR r4 EQ abap_true OR r10 EQ abap_true OR r6 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'DAT'.
        IF r1 EQ abap_true OR r2 EQ abap_true OR r4 EQ abap_true OR
           r5 EQ abap_true OR r6 EQ abap_true OR r7 EQ abap_true OR
           r8 EQ abap_true OR r9 EQ abap_true OR r10 EQ abap_true OR
           r11 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'SUP'.
        IF r1 EQ abap_true OR r2 EQ abap_true OR r4 EQ abap_true OR
           r5 EQ abap_true OR r6 EQ abap_true OR r7 EQ abap_true OR
           r8 EQ abap_true OR r9 EQ abap_true OR r10 EQ abap_true OR
           r11 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'PRD'.
        IF r3 EQ abap_true.
          screen-active = 0.
          MODIFY SCREEN.
        ENDIF.
    ENDCASE.
  ENDLOOP.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_aufnr-low.
  PERFORM s_aufnr_f4 CHANGING s_aufnr-low.

START-OF-SELECTION.

  IF r1 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for display SU' TYPE 'E'.
    ENDIF.
  ELSEIF r2 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '06'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for delete SU' TYPE 'E'.
    ENDIF.
  ELSEIF r3 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '80'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for print SU' TYPE 'E'.
    ENDIF.
  ELSEIF r4 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD 'AA'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for re print SU' TYPE 'E'.
    ENDIF.
  ELSEIF r5 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for display pallet' TYPE 'E'.
    ENDIF.
  ELSEIF r6 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '01'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for create pallet' TYPE 'E'.
    ENDIF.
  ELSEIF r7 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '80'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for print pallet' TYPE 'E'.
    ENDIF.
  ELSEIF r8 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD 'AA'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for re print pallet' TYPE 'E'.
    ENDIF.
  ELSEIF r9 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD '06'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for delete pallet' TYPE 'E'.
    ENDIF.
  ELSEIF r10 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD 'G7'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for reset SU status' TYPE 'E'.
    ENDIF.
  ELSEIF r11 EQ abap_true.
    AUTHORITY-CHECK OBJECT 'ZWM_AUTH'
*    ID 'USER' FIELD sy-uname
    ID 'ACTVT' FIELD 'G7'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorised for reset pallet status' TYPE 'E'.
    ENDIF.
  ENDIF.

  IF r3 EQ abap_true AND p_data IS INITIAL.
    MESSAGE 'Enter Manufacturing date' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
  ENDIF.

  IF r3 EQ abap_true.
    IF s_aufnr1[] IS INITIAL.
      MESSAGE 'Enter mandatory production order' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSEIF r1 EQ abap_true OR r4 EQ abap_true OR r10 EQ abap_true.
    IF s_aufnr[] IS INITIAL AND s_lenum[] IS INITIAL.
      MESSAGE 'Enter either production order or SU ' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSEIF r5 EQ abap_true OR r7 EQ abap_true OR r8 EQ abap_true OR r11 EQ abap_true OR r9 EQ abap_true.
    IF s_aufnr[] IS INITIAL AND s_palno[] IS INITIAL.
      MESSAGE 'Enter either production order or Pallet ' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.

  IF r2 EQ abap_true OR r6 EQ abap_true.
    IF s_aufnr[] IS INITIAL.
      MESSAGE 'Enter production order ' TYPE 'S' DISPLAY LIKE 'E'. "or Pallet Number
      EXIT.
    ENDIF.
  ENDIF.

  IF r4 EQ abap_true.
    IF s_aufnr[] IS INITIAL.
      MESSAGE 'Enter mandatory production order' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.

  IF r1 EQ abap_true OR r2 EQ abap_true OR r3 EQ abap_true OR r4 EQ abap_true OR r5 EQ abap_true OR r6 EQ abap_true
     OR r7 EQ abap_true OR r8 EQ abap_true OR r9 EQ abap_true OR r10 EQ abap_true OR r11 EQ abap_true.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE werks FROM zwm_su INTO @DATA(lv_plant) WHERE aufnr = @s_aufnr1-low.

    SELECT werks FROM zwm_su INTO @DATA(lv_plant) UP TO 1 ROWS WHERE aufnr = @s_aufnr1-low
     ORDER BY PRIMARY KEY .
    ENDSELECT.

* End of Quick Fix

    IF lv_plant IS INITIAL.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*      SELECT SINGLE werks FROM zwm_su INTO lv_plant WHERE aufnr = s_aufnr-low.

      SELECT werks FROM zwm_su INTO lv_plant UP TO 1 ROWS WHERE aufnr = s_aufnr-low
       ORDER BY PRIMARY KEY .
      ENDSELECT.

* End of Quick Fix

    ENDIF.
    SELECT * FROM tvarvc INTO TABLE @DATA(lt_tvarvc) WHERE name = 'ZPLANT_BARCODE' AND low = @lv_plant.
    IF lt_tvarvc IS NOT INITIAL AND r3 EQ abap_true .
      IF r_qr NE abap_true.
        MESSAGE 'Select QR code lable button' TYPE 'S' DISPLAY LIKE 'E'.
        EXIT.
      ENDIF.
    ELSEIF lt_tvarvc IS INITIAL.
      IF r_br NE abap_true.
        MESSAGE 'Select barcode lable button' TYPE 'S' DISPLAY LIKE 'E'.
        EXIT.
      ENDIF.
    ENDIF.
    AUTHORITY-CHECK OBJECT 'ZFSTO_WERK'
      ID 'WERKS' FIELD lv_plant
      ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH lv_plant.
    ENDIF.
  ENDIF.


  IF r1 EQ abap_true.
    PERFORM display_su.

  ELSEIF r2 EQ abap_true.
    PERFORM display_delete.

  ELSEIF r3 EQ abap_true.
    PERFORM print_su.

  ELSEIF r4 EQ abap_true.
    PERFORM reprint_su.

  ELSEIF r10 EQ abap_true.
    PERFORM reset_su.

  ELSEIF r5 EQ abap_true.
    PERFORM display_pallet.

  ELSEIF r6 EQ abap_true.
    PERFORM create_pallet.

  ELSEIF r7 EQ abap_true.
    PERFORM print_pallet.

  ELSEIF r8 EQ abap_true.
    PERFORM reprint_pallet.

  ELSEIF r9 EQ abap_true.
    PERFORM delete_pallet.
  ELSEIF r11 EQ abap_true.
    PERFORM reset_pallet.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_SU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_su .
  SELECT * FROM zwm_su
    INTO CORRESPONDING FIELDS OF TABLE gt_final
    WHERE aufnr  IN s_aufnr
      AND lenum IN s_lenum.

  IF gt_final IS INITIAL.
    MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

    """""eoc dt.09.06.2025
  ENDIF.

  wa_fieldcat-fieldname = 'AUFNR'.
  wa_fieldcat-seltext_l = 'Production Order Number'.
  wa_fieldcat-outputlen = 12.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  wa_fieldcat-no_zero   = abap_true.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LENUM'.
  wa_fieldcat-seltext_l = 'Storage Unit Number'.
  wa_fieldcat-outputlen = 20.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'TANUM'.
  wa_fieldcat-seltext_l = 'Transfer Order No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_CNT'.
  wa_fieldcat-seltext_l = 'Serial No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATNR'.
  wa_fieldcat-seltext_l = 'Material Number'.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'CHARG'.
  wa_fieldcat-seltext_l = 'Batch'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'WERKS'.
  wa_fieldcat-seltext_l = 'Plant'.
  wa_fieldcat-outputlen = 5.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_QTY'.
  wa_fieldcat-seltext_l = 'SU Quantity'.
  wa_fieldcat-outputlen = 13.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_UNIT'.
  wa_fieldcat-seltext_l = 'SU Unit'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BDATU'.
  wa_fieldcat-seltext_l = 'Created On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BZEIT'.
  wa_fieldcat-seltext_l = 'Created time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BNAME'.
  wa_fieldcat-seltext_l = 'Created By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PPRINT'.
  wa_fieldcat-seltext_l = 'Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PDATE'.
  wa_fieldcat-seltext_l = 'Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PTIME'.
  wa_fieldcat-seltext_l = 'Printed time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PUNAME'.
  wa_fieldcat-seltext_l = 'Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PRINT'.
  wa_fieldcat-seltext_l = 'Re Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PDATE'.
  wa_fieldcat-seltext_l = 'Re Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PTIME'.
  wa_fieldcat-seltext_l = 'Re Printed Time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_UNAME'.
  wa_fieldcat-seltext_l = 'Re Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'DEL_FLG'.
  wa_fieldcat-seltext_l = 'Deletion Flag'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  ls_layout-zebra = 'X'.
  ls_layout-info_fieldname = 'COLOR'.
  ls_layout-colwidth_optimize = 'X'.
  APPEND ls_layout .
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
*       I_GRID_TITLE             =
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
    ENDIF.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DELETE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_delete .
  SELECT * FROM zwm_su
     INTO CORRESPONDING FIELDS OF TABLE gt_final
     WHERE aufnr  IN s_aufnr
       AND lenum IN s_lenum
       AND pprint EQ abap_false
       AND del_flg EQ abap_false.
  IF gt_final IS INITIAL.
    MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

    """""eoc dt.09.06.2025
  ENDIF.

*Added by Poonam on 11.10.2024
  PERFORM fieldcatelog_su.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
*       I_GRID_TITLE             =
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
    ENDIF.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_SU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print_su .
  DATA:lv_msg TYPE string.

  SELECT * FROM zwm_su
    INTO CORRESPONDING FIELDS OF TABLE gt_final
    WHERE aufnr  IN s_aufnr1
      AND lenum  IN s_lenum
      AND pprint EQ abap_false
      AND del_flg EQ abap_false .
  IF gt_final IS INITIAL.
    MESSAGE 'No data found for given selection OR SUs are already printed' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

    """""eoc dt.09.06.2025
  ENDIF.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*  SELECT SINGLE * FROM zwm_su INTO CORRESPONDING FIELDS OF gs_final
*    WHERE aufnr  IN s_aufnr1
*      AND lenum  IN s_lenum
*      AND pprint EQ abap_true.

  SELECT * FROM zwm_su INTO CORRESPONDING FIELDS OF gs_final UP TO 1 ROWS
   WHERE aufnr IN s_aufnr1 AND lenum IN s_lenum AND pprint EQ abap_true
   ORDER BY PRIMARY KEY .
  ENDSELECT.
* End of Quick Fix

  IF sy-subrc IS INITIAL.
    CASE gs_final-l_typ.
      WHEN 'B'.
        IF r_br EQ abap_false.
          MESSAGE 'Use barcode option for printing this label' TYPE 'S' DISPLAY LIKE 'E'.
          EXIT.
        ENDIF.
        CASE gs_final-p_typ.
          WHEN 'A'.
            IF r_ad EQ abap_false.
              MESSAGE 'Use adhesive option for printing this label' TYPE 'S' DISPLAY LIKE 'E'.
              EXIT.
            ENDIF.
          WHEN 'M'.
            IF r_mrp EQ abap_false.
              MESSAGE 'Use with MRP option for printing this label' TYPE 'S' DISPLAY LIKE 'E'.
              EXIT.
            ENDIF.
          WHEN 'W'.
            IF r_wmrp EQ abap_false.
              MESSAGE 'Use without MRP option for printing this label' TYPE 'S' DISPLAY LIKE 'E'.
              EXIT.
            ENDIF.
          WHEN OTHERS.
        ENDCASE.
      WHEN 'Q'.
        IF r_qr EQ abap_false.
          MESSAGE 'Use QR code option for printing this label' TYPE 'S' DISPLAY LIKE 'E'.
          EXIT.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDIF.

  PERFORM fieldcatelog_su.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
    ENDIF.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

FORM reprint_su .
  SELECT * FROM zwm_su
    INTO CORRESPONDING FIELDS OF TABLE gt_final
    WHERE aufnr  IN s_aufnr
      AND lenum  IN s_lenum
      AND pprint EQ abap_true.
  IF gt_final IS INITIAL.
    MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.
    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.
    """""eoc dt.09.06.2025
  ENDIF.
*************************************Added by Rutvi on 15.01.2025
  SELECT * FROM tvarvc INTO TABLE @DATA(lt_plant) WHERE name = 'ZWM_PLANT'.
  IF gt_final IS NOT INITIAL.
    SELECT rueck,
           rmzhl,
           aufnr,
           budat FROM afru INTO TABLE @DATA(it_afru)
           FOR ALL ENTRIES IN @gt_final WHERE aufnr = @gt_final-aufnr.
    IF it_afru IS NOT INITIAL.
      LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<fs_final>).
        READ TABLE lt_plant TRANSPORTING NO FIELDS WITH KEY low = <fs_final>-werks.
        IF sy-subrc = 0.
          READ TABLE it_afru INTO DATA(wa_afru) WITH KEY aufnr = <fs_final>-aufnr.
          IF sy-subrc = 0.
            <fs_final>-manf_date = wa_afru-budat.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
*****************************************************************
  READ TABLE gt_final INTO gs_final INDEX 1.            "#EC CI_NOORDER
  IF sy-subrc IS INITIAL.
    CLEAR:r_br,r_qr,r_ad,r_pt,r_mrp,r_wmrp.
    CASE gs_final-l_typ.
      WHEN 'B'.
        r_br = abap_true.
        CASE gs_final-p_typ.
          WHEN 'A'.
            r_ad = abap_true.
          WHEN 'M'.
            r_mrp = abap_true.
            r_pt = abap_true.
          WHEN 'W'.
            r_wmrp = abap_true.
            r_pt = abap_true.
          WHEN OTHERS.
        ENDCASE.
      WHEN 'Q'.
        r_qr = abap_true.
      WHEN OTHERS.
    ENDCASE.
  ENDIF.

  PERFORM fieldcatelog_su.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
    ENDIF.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

FORM reset_su.
  SELECT * FROM zwm_su
    INTO TABLE @DATA(lt_final)
    WHERE aufnr  IN @s_aufnr
      AND lenum  IN @s_lenum
      AND pprint EQ @abap_true
      AND f_ind  EQ @abap_false.
  IF lt_final IS INITIAL.
    MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

    """""eoc dt.09.06.2025
  ENDIF.

  READ TABLE lt_final INTO DATA(ls_final) INDEX 1.      "#EC CI_NOORDER
  IF sy-subrc EQ 0.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE * FROM afpo
*     INTO @DATA(ls_afpo)
*      WHERE aufnr EQ @ls_final-aufnr.

    SELECT * FROM afpo
     INTO @DATA(ls_afpo) UP TO 1 ROWS WHERE aufnr EQ @ls_final-aufnr
     ORDER BY PRIMARY KEY .
    ENDSELECT.
* End of Quick Fix

    IF sy-subrc IS INITIAL.
      SELECT SUM( su_qty ) FROM zwm_su
        INTO @DATA(l_quan)
         WHERE aufnr EQ @ls_final-aufnr
           AND f_ind EQ @abap_true.
      DATA(lv_quan) = ls_afpo-psmng - ls_afpo-wemng.

      SORT lt_final BY lenum DESCENDING.

      LOOP AT lt_final INTO ls_final.
        l_quan = l_quan + ls_final-su_qty.
        IF l_quan LE lv_quan.
          MOVE-CORRESPONDING ls_final TO gs_final.
          APPEND gs_final TO gt_final.
          CLEAR:gs_final.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.
      SORT gt_final BY lenum.
    ENDIF.
  ENDIF.

  PERFORM fieldcatelog_su.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
    ENDIF.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

FORM display_pallet.
  IF s_palno[] IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
**        AND lenum    IN s_lenum
*        AND palletno IN s_palno.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
            AND palletno IN s_palno ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSE.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
**        AND lenum    IN s_lenum
*        AND palletno NE ''.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
            AND palletno NE '' ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'Pallets are not yet createdfor given inputs' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.
  """""added by akshay dt.09.06.2025
  IF gt_final IS NOT INITIAL.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

  ENDIF.
  """""eoc dt.09.06.2025

  LOOP AT gt_final INTO gs_final.
    MOVE-CORRESPONDING gs_final TO gs_pallet.
    APPEND gs_pallet TO gt_pallet.
    CLEAR:gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.

  LOOP AT gt_pallet_tmp INTO DATA(ls_pallet).
    gs_pallet = ls_pallet.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls_pallet-lenum.
    ENDIF.

    gv_flag = abap_true.
    gv_qty  = gv_qty + 1.

    gv_qty1  = gv_qty1 + ls_pallet-su_qty.
    AT END OF palletno.
      gs_pallet-pal_qty = gv_qty.
      gs_pallet-su_qty  = gv_qty1.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      APPEND gs_pallet TO gt_pallet.
      CLEAR:gv_flag,gs_pallet,gv_qty,gv_qty1.
    ENDAT.
  ENDLOOP.


  PERFORM build_fieldcataloge_pal.
  ls_layout-colwidth_optimize = abap_true.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_pallet
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.


FORM create_pallet .
  SELECT * FROM zwm_su
    INTO CORRESPONDING FIELDS OF TABLE gt_final
    WHERE aufnr    IN s_aufnr
      AND lenum    IN s_lenum
      AND pprint   EQ abap_true
      AND palletno EQ ''.
  IF gt_final IS INITIAL.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
  ENDIF.

  SELECT * FROM marm
    INTO TABLE @DATA(lt_marm)
    FOR ALL ENTRIES IN @gt_final
    WHERE matnr EQ @gt_final-matnr
      AND meinh EQ 'PAL'.
  READ TABLE lt_marm INTO DATA(ls_marm) INDEX 1.        "#EC CI_NOORDER
  IF sy-subrc IS INITIAL.
    lv_umrez = ls_marm-umrez.
  ENDIF.


  PERFORM build_fieldcataloge.
  ls_layout-colwidth_optimize = abap_true.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_final
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

FORM print_pallet .
  IF s_palno[] IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr     IN s_aufnr
*        AND lenum     IN s_lenum
*        AND palletno  IN s_palno
*        AND pal_print EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr     IN s_aufnr
            AND lenum     IN s_lenum
            AND palletno  IN s_palno
            AND pal_print EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSE.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
*        AND palletno NE ''
*        AND pal_print EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
            AND lenum    IN s_lenum
            AND palletno NE ''
            AND pal_print EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'Pallets are not yet created for given order or SU' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.

  """""added by akshay dt.09.06.2025
  IF gt_final[] IS NOT INITIAL.


    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

  ENDIF.
  """""eoc dt.09.06.2025

  LOOP AT gt_final INTO gs_final.
    MOVE-CORRESPONDING gs_final TO gs_pallet.
    APPEND gs_pallet TO gt_pallet.
    CLEAR:gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.

  LOOP AT gt_pallet_tmp INTO DATA(ls_pallet).
    gs_pallet = ls_pallet.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls_pallet-lenum.
    ENDIF.

    gv_flag = abap_true.

    gv_qty  = gv_qty + 1.

    gv_qty1  = gv_qty1 + ls_pallet-su_qty.
    AT END OF palletno.
      gs_pallet-pal_qty = gv_qty.
      gs_pallet-su_qty  = gv_qty1.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      gs_pallet-zlotno = gs_pallet-zlotno.
      gs_pallet-zprange = gs_pallet-zprange.
      APPEND gs_pallet TO gt_pallet.
      CLEAR:gv_flag,gs_pallet,gv_qty,gv_qty1.
    ENDAT.
  ENDLOOP.

  PERFORM build_fieldcataloge_pal.
  ls_layout-colwidth_optimize = abap_true.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_pallet
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.


FORM reprint_pallet .
  IF s_palno[] IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
*        AND palletno IN s_palno
*        AND pal_print EQ abap_true
*        AND p_ind     EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
            AND lenum    IN s_lenum
            AND palletno IN s_palno
            AND pal_print EQ abap_true
            AND p_ind     EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSE.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
*        AND palletno NE ''
*        AND pal_print EQ abap_true
*        AND p_ind     EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
            AND lenum    IN s_lenum
            AND palletno NE ''
            AND pal_print EQ abap_true
            AND p_ind     EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'Pallets are not yet printed given inputs' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.

  """""added by akshay dt.09.06.2025
  IF gt_final[] IS NOT INITIAL.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

  ENDIF.
  """""eoc dt.09.06.2025

  LOOP AT gt_final INTO gs_final.
    MOVE-CORRESPONDING gs_final TO gs_pallet.
    APPEND gs_pallet TO gt_pallet.
    CLEAR:gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.

  LOOP AT gt_pallet_tmp INTO DATA(ls_pallet).
    gs_pallet = ls_pallet.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls_pallet-lenum.
    ENDIF.

    gv_flag = abap_true.

    gv_qty  = gv_qty + 1.

    gv_qty1  = gv_qty1 + ls_pallet-su_qty.
    AT END OF palletno.
      gs_pallet-pal_qty = gv_qty.
      gs_pallet-su_qty  = gv_qty1.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      APPEND gs_pallet TO gt_pallet.
      CLEAR:gv_flag,gs_pallet,gv_qty,gv_qty1.
    ENDAT.
  ENDLOOP.

  PERFORM build_fieldcataloge_pal.
  ls_layout-colwidth_optimize = abap_true.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_pallet
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

FORM delete_pallet .
  SELECT * FROM zwm_su
    INTO CORRESPONDING FIELDS OF TABLE gt_final
    WHERE aufnr     IN s_aufnr
      AND lenum     IN s_lenum
      AND palletno  IN s_palno
      AND pal_print EQ abap_false
      AND p_ind     EQ abap_false.
  IF gt_final IS INITIAL.
    MESSAGE 'Pallets are already printed for given Production order or SU' TYPE 'S' DISPLAY LIKE 'E'.
    EXIT.
    """""added by akshay dt.09.06.2025
  ELSE.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

    """""eoc dt.09.06.2025
  ENDIF.

  DELETE gt_final WHERE palletno IS INITIAL.
  LOOP AT gt_final INTO gs_final.
    MOVE-CORRESPONDING gs_final TO gs_pallet.
    APPEND gs_pallet TO gt_pallet.
    CLEAR:gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.
******ATC BEGIN OF CHANGE 27.02.2026 ******
  SORT gt_pallet_tmp.
******ATC END OF CHANGE 27.02.2026 ******
  LOOP AT gt_pallet_tmp INTO DATA(ls_pallet).
    gs_pallet = ls_pallet.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls_pallet-lenum.
    ENDIF.

    gv_flag = abap_true.

    gv_qty  = gv_qty + 1.

    gv_qty1  = gv_qty1 + ls_pallet-su_qty.
    AT END OF palletno.
      gs_pallet-pal_qty = gv_qty.
      gs_pallet-su_qty  = gv_qty1.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      APPEND gs_pallet TO gt_pallet.
      CLEAR:gv_flag,gs_pallet,gv_qty,gv_qty1.
    ENDAT.
  ENDLOOP.

  PERFORM build_fieldcataloge_pal.
  ls_layout-colwidth_optimize = abap_true.
  "Added by UDAYABAP03 on 18.03.2026
  wa_sort-fieldname = 'SU_CNT'.
  APPEND wa_sort TO it_sort.
  CLEAR wa_sort.
  "Added by UDAYABAP03 on 18.03.2026
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_pallet
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCATALOGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_fieldcataloge.
  IF r6 EQ abap_true OR r7 EQ abap_true OR r8 EQ abap_true OR r9 EQ abap_true.
    wa_fieldcat-fieldname = 'CHKBX'.
    wa_fieldcat-seltext_l = 'Select'.
    wa_fieldcat-checkbox  = 'X'.
    wa_fieldcat-edit      = 'X'.
    wa_fieldcat-outputlen = 16.
    wa_fieldcat-tabname   = 'GT_FINAL'.
    APPEND wa_fieldcat TO it_fieldcat.
    CLEAR wa_fieldcat.
  ENDIF.

  wa_fieldcat-fieldname = 'PALLETNO'.
  wa_fieldcat-seltext_l = 'Pallet Number                '.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'AUFNR'.
  wa_fieldcat-seltext_l = 'Production Order Number'.
  wa_fieldcat-outputlen = 12.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LENUM'.
  wa_fieldcat-seltext_l = 'Storage Unit Number'.
  wa_fieldcat-outputlen = 20.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'TANUM'.
  wa_fieldcat-seltext_l = 'Transfer Order No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATNR'.
  wa_fieldcat-seltext_l = 'Material Number'.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'CHARG'.
  wa_fieldcat-seltext_l = 'Batch'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'WERKS'.
  wa_fieldcat-seltext_l = 'Plant'.
  wa_fieldcat-outputlen = 5.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_QTY'.
  wa_fieldcat-seltext_l = 'SU Quantity'.
  wa_fieldcat-outputlen = 13.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_UNIT'.
  wa_fieldcat-seltext_l = 'SU Unit'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_CNT'.
  wa_fieldcat-seltext_l = 'Serial No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.


  wa_fieldcat-fieldname = 'PAL_CREATEDATE'.
  wa_fieldcat-seltext_l = 'Created On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_CREATETIME'.
  wa_fieldcat-seltext_l = 'Created time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_CREATENAME'.
  wa_fieldcat-seltext_l = 'Created By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_PRINT'.
  wa_fieldcat-seltext_l = 'Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_DATE'.
  wa_fieldcat-seltext_l = 'Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_TIME'.
  wa_fieldcat-seltext_l = 'Printed time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_NAME'.
  wa_fieldcat-seltext_l = 'Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_PRINT'.
  wa_fieldcat-seltext_l = 'Re Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_DATE'.
  wa_fieldcat-seltext_l = 'Re Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_TIME'.
  wa_fieldcat-seltext_l = 'Re Printed Time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_NAME'.
  wa_fieldcat-seltext_l = 'Re Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  ls_layout-zebra = 'X'.
  ls_layout-info_fieldname = 'COLOR'.
  ls_layout-colwidth_optimize = 'X'.
  APPEND ls_layout.
ENDFORM.

FORM build_fieldcataloge_pal.
  IF r7 EQ abap_true OR r8 EQ abap_true OR r9 EQ abap_true OR r11 EQ abap_true.
    wa_fieldcat-fieldname = 'CHKBX'.
    wa_fieldcat-seltext_l = 'Select'.
    wa_fieldcat-checkbox  = 'X'.
    wa_fieldcat-edit      = 'X'.
    wa_fieldcat-outputlen = 16.
    wa_fieldcat-tabname   = 'GT_PALLET'.
    APPEND wa_fieldcat TO it_fieldcat.
    CLEAR wa_fieldcat.
  ENDIF.

  wa_fieldcat-fieldname = 'PALLETNO'.
  wa_fieldcat-seltext_l = 'Pallet Number           '.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_QTY'.
  wa_fieldcat-seltext_l = 'No of SU'.
  wa_fieldcat-outputlen = 13.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_FROM'.
  wa_fieldcat-seltext_l = 'From SU'.
  wa_fieldcat-outputlen = 20.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_TO'.
  wa_fieldcat-seltext_l = 'TO SU'.
  wa_fieldcat-outputlen = 20.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_QTY'.
  wa_fieldcat-seltext_l = 'Pallet Quantity'.
  wa_fieldcat-outputlen = 13.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  wa_fieldcat-do_sum    = 'X'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_CNT'.
  wa_fieldcat-seltext_l = 'Serial No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'AUFNR'.
  wa_fieldcat-seltext_l = 'Production Order Number'.
  wa_fieldcat-outputlen = 12.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATNR'.
  wa_fieldcat-seltext_l = 'Material Number'.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'CHARG'.
  wa_fieldcat-seltext_l = 'Batch'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'WERKS'.
  wa_fieldcat-seltext_l = 'Plant'.
  wa_fieldcat-outputlen = 5.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_PRINT'.
  wa_fieldcat-seltext_l = 'Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_CREATEDATE'.
  wa_fieldcat-seltext_l = 'Created On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_CREATETIME'.
  wa_fieldcat-seltext_l = 'Created time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_CREATENAME'.
  wa_fieldcat-seltext_l = 'Created By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_DATE'.
  wa_fieldcat-seltext_l = 'Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_TIME'.
  wa_fieldcat-seltext_l = 'Printed time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PAL_NAME'.
  wa_fieldcat-seltext_l = 'Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_PRINT'.
  wa_fieldcat-seltext_l = 'Re Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_DATE'.
  wa_fieldcat-seltext_l = 'Re Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_TIME'.
  wa_fieldcat-seltext_l = 'Re Printed Time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PAL_NAME'.
  wa_fieldcat-seltext_l = 'Re Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'ZLOTNO'.
  wa_fieldcat-seltext_l = 'LOT Number'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'ZPRANGE'.
  wa_fieldcat-seltext_l = 'Pallet Range'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_PALLET'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  ls_layout-zebra = 'X'.
  ls_layout-info_fieldname = 'COLOR'.
  ls_layout-colwidth_optimize = 'X'.
  APPEND ls_layout.
ENDFORM.

FORM z_pf_status USING p_extab TYPE slis_t_extab.
  IF r1 EQ abap_true.
    SET PF-STATUS 'Z_PF_STATUS1'.
  ELSEIF r2 EQ abap_true.
    SET PF-STATUS 'ZSU_DEL'.
  ELSEIF r3 EQ abap_true.
    SET PF-STATUS 'ZSU_PRINT'.
  ELSEIF r4 EQ abap_true.
    SET PF-STATUS 'ZSU_REPRINT'.
  ELSEIF r5 EQ abap_true.
    SET PF-STATUS 'Z_PF_STATUS1'.
  ELSEIF r6 EQ abap_true.
    SET PF-STATUS 'Z_PF_STATUS_R6'.
  ELSEIF r7 EQ abap_true.
    SET PF-STATUS 'ZPAL_PRINT'.
  ELSEIF r8 EQ abap_true.
    SET PF-STATUS 'ZPAL_REPRINT'.
  ELSEIF r9 EQ abap_true.
    SET PF-STATUS 'ZPAL_DEL'.
  ELSEIF r10 EQ abap_true.
    SET PF-STATUS 'ZSU_RESET'.
  ELSEIF r11 EQ abap_true.
    SET PF-STATUS 'ZPALLET_RESET'.
  ENDIF.
ENDFORM.

FORM sub_top_of_page .
  DATA : lv_char(60) TYPE c,
         lv_date(10) TYPE c.

  REFRESH:it_aheader .
  CLEAR:wa_aheader.

  IF r1 EQ abap_true.
    DESCRIBE TABLE gt_final LINES DATA(lv_cnt).
    wa_aheader-key = 'Display Storage Unit'.
    wa_aheader-typ  = 'S'.
    wa_aheader-info = | Total Number of SU's : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r2 EQ abap_true.
    wa_aheader-key = 'Delete Storage Unit'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_final LINES lv_cnt.
    wa_aheader-info = | Total Number of SU's : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r3 EQ abap_true.
    wa_aheader-key = 'Print Storage Unit'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_final LINES lv_cnt.
    wa_aheader-info = | Total Number of SU's : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r4 EQ abap_true.
    wa_aheader-key = 'RePrint Storage Unit'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_final LINES lv_cnt.
    wa_aheader-info = | Total Number of SU's : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r10 EQ abap_true.
    wa_aheader-key = 'Reset Storage Unit'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_final LINES lv_cnt.
    wa_aheader-info = | Total Number of SU's : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r5 EQ abap_true.
    wa_aheader-key = 'Display Pallet'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_pallet LINES lv_cnt.
    wa_aheader-info = | Total Number of Pallets : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r6 EQ abap_true.
    wa_aheader-key  = 'Create Pallet'.
    wa_aheader-typ  = 'S'.
    wa_aheader-info = | Master Qty - | && | { lv_umrez }| && | Changed Qty - | && | { lv_umrez1 }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r7 EQ abap_true.
    wa_aheader-key = 'Print Pallet'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_pallet LINES lv_cnt.
    wa_aheader-info = | Total Number of Pallets : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r8 EQ abap_true.
    wa_aheader-key = 'Re Print Pallet'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_pallet LINES lv_cnt.
    wa_aheader-info = | Total Number of Pallets : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r9 EQ abap_true.
    wa_aheader-key = 'Delete Pallet'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_pallet LINES lv_cnt.
    wa_aheader-info = | Total Number of Pallets : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ELSEIF r11 EQ abap_true.
    wa_aheader-key = 'Reset Pallet'.
    wa_aheader-typ  = 'S'.
    DESCRIBE TABLE gt_pallet LINES lv_cnt.
    wa_aheader-info = | Total Number of Pallets : | && | { lv_cnt }|.
    APPEND wa_aheader TO it_aheader.
    CLEAR wa_aheader.
  ENDIF.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_aheader.
ENDFORM.                    " SUB_TOP_OF_PAGE

FORM user_command USING command LIKE sy-ucomm p_selfield TYPE slis_selfield .

  DATA:ls_zwm_su          TYPE zwm_su,
       ls_sufrom          TYPE zstr_label_ast_ltd,
       lv_no              TYPE i,
       count              TYPE i,
       ls_suto            TYPE zstr_label_ast_ltd,
       lv_palletno        TYPE zwm_su-palletno,
       gd_repid           LIKE sy-repid,
       lv_qty             TYPE gamng,
       v_form_name        TYPE rs38l_fnam,
       control_parameters TYPE ssfctrlop,
       output_options     TYPE ssfcompop,
       control            TYPE ssfctrlop,
       output             TYPE ssfcompop,
       ref_grid           TYPE REF TO cl_gui_alv_grid.

  IF ref_grid IS INITIAL.
    CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
      IMPORTING
        e_grid = ref_grid.
  ENDIF.
  IF NOT ref_grid IS INITIAL.
    CALL METHOD ref_grid->check_changed_data.
  ENDIF.

  CASE command.
    WHEN 'SEL'.
      LOOP AT gt_final ASSIGNING <fs_final>.
        <fs_final>-chkbx = abap_true.
      ENDLOOP.

      LOOP AT gt_pallet ASSIGNING FIELD-SYMBOL(<fs_pal>).
        <fs_pal>-chkbx = abap_true.
      ENDLOOP.
    WHEN 'DSEL'.
      LOOP AT gt_final ASSIGNING <fs_final>.
        <fs_final>-chkbx = abap_false.
      ENDLOOP.

      LOOP AT gt_pallet ASSIGNING <fs_pal>.
        <fs_pal>-chkbx = abap_false.
      ENDLOOP.
    WHEN 'BACK' OR 'EXIT' OR 'CANCEL'.
      LEAVE LIST-PROCESSING.
    WHEN 'DELETE'.
      SORT gt_final DESCENDING BY lenum.
      LOOP AT gt_final INTO gs_final . " WHERE chkbx IS NOT INITIAL.
        IF gs_final-chkbx EQ 'X'.
          SELECT SINGLE * FROM zwm_su
            INTO ls_zwm_su WHERE aufnr EQ gs_final-aufnr
                             AND lenum EQ gs_final-lenum.

          DELETE  gt_final WHERE aufnr EQ gs_final-aufnr
                            AND lenum EQ gs_final-lenum AND chkbx = 'X'.

          ls_zwm_su-del_flg = 'X'.
          MODIFY zwm_su FROM ls_zwm_su.

          DATA : l_lenum TYPE lenum.
          CALL FUNCTION 'CONVERSION_EXIT_LENUM_OUTPUT'
            EXPORTING
              input  = gs_final-lenum
            IMPORTING
              output = gs_final-lenum
* EXCEPTIONS
*             T344_GET_FAILED       = 1
*             OTHERS = 2
            .
          IF sy-subrc <> 0.
* Implement suitable error handling here
          ENDIF.

          PERFORM lt16 CHANGING gs_final-lenum.                          "10.12.2024
          CALL METHOD ref_grid->refresh_table_display.
          MESSAGE 'SU successfully deleted' TYPE 'S' DISPLAY LIKE 'S'.
        ELSE.
          READ TABLE gt_final INTO DATA(gs_lenum) WITH KEY chkbx = 'X'.
          IF gs_lenum-lenum <> gs_final-lenum AND sy-subrc = 0.
            MESSAGE 'Select last SU of this list' TYPE 'S' DISPLAY LIKE 'E'.
            EXIT.
          ENDIF.
        ENDIF.
      ENDLOOP.
      SORT gt_final ASCENDING BY lenum.

      p_selfield-refresh = 'X'.

    WHEN 'CHANGE_QTY'.
      DATA:lt_field TYPE STANDARD TABLE OF sval,
           ls_field TYPE sval.

      REFRESH:lt_field.

      ls_field-tabname   = 'MARM'.
      ls_field-fieldname = 'UMREZ'.
      ls_field-value     = lv_umrez.
      APPEND ls_field TO lt_field.

      CALL FUNCTION 'POPUP_GET_VALUES'
        EXPORTING
          popup_title     = 'Change quantity'
          start_column    = '5'
          start_row       = '5'
        TABLES
          fields          = lt_field
        EXCEPTIONS
          error_in_fields = 1
          OTHERS          = 2.
      IF sy-subrc EQ 0.
        READ TABLE lt_field INTO ls_field INDEX 1.
        IF sy-subrc IS INITIAL.
          lv_umrez1 = ls_field-value.
        ENDIF.
      ENDIF.

    WHEN 'CREATE_PAL'.
      DATA:lv_qtyumrez   TYPE marm-umrez,
           lv_ans        TYPE c,
           lv_zlotno     TYPE zwm_su-zlotno,
           lv_zlotno1(3) TYPE c,
           lv_from(3)    TYPE c,
           lv_to(3)      TYPE c,
           lv_prange     TYPE zwm_su-zprange,
           lv_year       TYPE inri-toyear.

      READ TABLE gt_final INTO gs_final INDEX 1.
      IF sy-subrc IS INITIAL.
        SELECT SINGLE * FROM zwm_config
          INTO @DATA(ls_zwm_config)
          WHERE werks EQ @gs_final-werks
            AND lgnum EQ @gs_final-lgnum
            AND auart EQ @gs_final-auart
            AND pal_no_range NE ''.
        IF sy-subrc IS NOT INITIAL.
          MESSAGE 'Please maintain Pallet number range interval in ZWM_CONFIG' TYPE 'S' DISPLAY LIKE 'E'.
          EXIT.
        ENDIF.

        CLEAR:lv_qtyumrez.
        IF lv_umrez1 IS NOT INITIAL.
          CALL FUNCTION 'POPUP_TO_CONFIRM'
            EXPORTING
              text_question         = 'Do you want to create pallets with changed quantity?'
              text_button_1         = 'Yes'
              text_button_2         = 'No'
              default_button        = '1'
              display_cancel_button = 'X'
              start_column          = 25
              start_row             = 6
            IMPORTING
              answer                = lv_ans
            EXCEPTIONS
              text_not_found        = 1
              OTHERS                = 2.
          IF sy-subrc EQ 0.
            CASE lv_ans.
              WHEN '1'.
                lv_qtyumrez = lv_umrez1.
              WHEN '2' OR 'A'.
                EXIT.
            ENDCASE.
          ENDIF.
        ELSE.
          lv_qtyumrez = lv_umrez.
        ENDIF.


        IF lv_qtyumrez IS INITIAL.
          MESSAGE 'Alternate UoM is not maintained for this material' TYPE 'S' DISPLAY LIKE 'E'.
          EXIT.
        ENDIF.

        SELECT SINGLE aufnr,
                      gamng,
                      gmein,
                      plnbez,
                      aufpl
                 FROM afko
                 INTO @DATA(ls_afko)
                 WHERE aufnr EQ @gs_final-aufnr.

        SELECT SUM( su_qty )
          FROM zwm_su
          INTO @DATA(lv_pal_qty)
          WHERE aufnr EQ @gs_final-aufnr
            AND palletno NE ' '.

        lv_year = sy-datum+0(4).

        SELECT * FROM zwm_su
          INTO TABLE @DATA(lt_lot)
          WHERE aufnr EQ @gs_final-aufnr
            AND palletno NE ' '.
        SORT lt_lot BY zlotno DESCENDING.
        CLEAR:lv_zlotno,lv_from,lv_to,lv_zlotno1.
        READ TABLE lt_lot INTO DATA(ls_lot) INDEX 1.
        IF ls_lot-zlotno IS INITIAL.
          lv_zlotno = 'L001'.
        ELSE.
          lv_zlotno1 = ls_lot-zlotno+1(3) + 1.
          lv_zlotno1 = |{ lv_zlotno1 ALPHA = IN } |.
          CONCATENATE 'L' lv_zlotno1 INTO lv_zlotno.
        ENDIF.

        REFRESH:lt_lot.
        LOOP AT gt_final ASSIGNING <fs_final> WHERE palletno IS INITIAL AND chkbx EQ abap_true.
          <fs_final>-pal_qty  = lv_qtyumrez.

          IF lv_qty IS INITIAL.
            CALL FUNCTION 'NUMBER_GET_NEXT'
              EXPORTING
                nr_range_nr             = ls_zwm_config-pal_no_range
                object                  = 'ZPALLET'
                toyear                  = lv_year
              IMPORTING
                number                  = <fs_final>-palletno
              EXCEPTIONS
                interval_not_found      = 1
                number_range_not_intern = 2
                object_not_found        = 3
                quantity_is_0           = 4
                quantity_is_not_1       = 5
                interval_overflow       = 6
                buffer_overflow         = 7
                OTHERS                  = 8.
            IF sy-subrc EQ 0.
              CONCATENATE <fs_final>-lgnum <fs_final>-palletno INTO <fs_final>-palletno.
              lv_palletno = <fs_final>-palletno.
              lv_to = lv_to + 1.
            ENDIF.
          ELSE.
            <fs_final>-palletno = lv_palletno.
          ENDIF.

          <fs_final>-pal_createdate = sy-datum.
          <fs_final>-pal_createtime = sy-uzeit.
          <fs_final>-pal_createname = sy-uname.
          <fs_final>-zlotno = lv_zlotno.

          UPDATE zwm_su SET palletno       = <fs_final>-palletno
                            pal_qty        = lv_qtyumrez
                            pal_createdate = sy-datum
                            pal_createtime = sy-uzeit
                            pal_createname = sy-uname
                            zlotno         = <fs_final>-zlotno
                        WHERE aufnr EQ <fs_final>-aufnr
                          AND lenum EQ <fs_final>-lenum.

*----------<< Start | Dispatch process change | by srimathi | 07.08.2024 | DEVK944530 >>-------$

          IF <fs_final>-palletno IS NOT INITIAL AND <fs_final>-lenum IS NOT INITIAL.

            SELECT COUNT(*) FROM zwm_plant_config WHERE plant = gs_final-werks.
            IF sy-subrc = 0.

              CALL FUNCTION 'ZWM_FM_PALLETIZATION'
                EXPORTING
                  iv_method         = 'CREATE_PALLET'
                  iv_warehouse_type = lv_warehouse_type
                  iv_warehouse_no   = <fs_final>-lgnum
                  iv_pallet_no      = <fs_final>-palletno
                  iv_su_no          = <fs_final>-lenum.

            ENDIF.

          ENDIF.

*-----------<< End | Dispatch process change | by srimathi | 07.08.2024 | DEVK944530 >>--------$

          MOVE-CORRESPONDING <fs_final> TO ls_lot.
          APPEND ls_lot TO lt_lot.
          CLEAR:ls_lot.
          lv_qty = lv_qty + 1.
          IF lv_qtyumrez EQ lv_qty.
            CLEAR:lv_qty,lv_palletno.
          ENDIF.
        ENDLOOP.
        SORT lt_lot BY palletno.
        DELETE ADJACENT DUPLICATES FROM lt_lot COMPARING palletno.
        LOOP AT lt_lot INTO ls_lot.
          lv_from = lv_from + 1.
          lv_from = |{ lv_from ALPHA = IN } |.
          lv_to   = |{ lv_to ALPHA = IN } |.
          CONCATENATE lv_from '-' lv_to INTO lv_prange.
          UPDATE zwm_su SET zprange     = lv_prange
                         WHERE aufnr    EQ ls_lot-aufnr
                           AND palletno EQ ls_lot-palletno.
          CLEAR:lv_prange.
        ENDLOOP.
      ENDIF.
    WHEN 'PALLET_P'.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname           = 'ZWM_PALLET_LABLE_QR_PRNT'  "change smartform for page format change " old - 'ZWM_LABEL_PRINT_AST_LTD'
        IMPORTING
          fm_name            = v_form_name
        EXCEPTIONS
          no_form            = 1
          no_function_module = 2
          OTHERS             = 3.

      control_parameters-no_open   = 'X'.
      control_parameters-no_close  = 'X'.
      CALL FUNCTION 'SSF_OPEN'
        EXPORTING
          output_options     = output
          control_parameters = control
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.

      IF gt_pallet IS NOT INITIAL.
        SELECT matnr,
               maktx
          FROM makt
          INTO TABLE @DATA(lt_makt)
          FOR ALL ENTRIES IN @gt_pallet
          WHERE matnr EQ @gt_pallet-matnr
            AND spras EQ @sy-langu.
        SORT lt_makt BY matnr.
      ENDIF.

      DATA(lt_pallet) = gt_pallet.
      DELETE lt_pallet WHERE chkbx EQ abap_false.

      DESCRIBE TABLE lt_pallet LINES lv_no.

      LOOP AT gt_pallet ASSIGNING FIELD-SYMBOL(<fs_pallet>) WHERE chkbx EQ abap_true.

        READ TABLE lt_makt INTO DATA(ls_makt) WITH KEY matnr = <fs_pallet>-matnr BINARY SEARCH.
        ls_sufrom-aufnr = <fs_pallet>-aufnr.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = <fs_pallet>-su_from
          IMPORTING
            output = ls_sufrom-zsu_no.

        ls_suto-aufnr = <fs_pallet>-aufnr.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = <fs_pallet>-su_to
          IMPORTING
            output = ls_suto-zsu_no.

        count = count + 1.

        DATA lv_qty1 TYPE zwm_su-pal_qty.
        lv_qty1 = <fs_pallet>-pal_qty.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            maktx              = ls_makt-maktx
            count              = count
            wa_su_no1          = ls_sufrom
            wa_su_no2          = ls_suto
            lv_aufnr           = <fs_pallet>-aufnr
            lv_no              = lv_no
            lv_charg           = <fs_pallet>-charg
            lv_werks           = <fs_pallet>-werks
            lv_matnrr          = <fs_pallet>-matnr
            lv_palletno        = <fs_pallet>-palletno
            lv_zlotno          = <fs_pallet>-zlotno
            lv_zprange         = <fs_pallet>-zprange
            lv_qty             = lv_qty1
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
        IF sy-subrc IS INITIAL AND sy-ucomm EQ 'PRNT'.
          LOOP AT gt_final INTO gs_final WHERE palletno = <fs_pallet>-palletno.
            UPDATE zwm_su SET pal_print = abap_true
                              pal_date  = sy-datum
                              pal_time  = sy-uzeit
                              pal_name  = sy-uname
                          WHERE aufnr EQ gs_final-aufnr
                            AND lenum EQ gs_final-lenum.
          ENDLOOP.

          DELETE gt_pallet WHERE palletno EQ <fs_pallet>-palletno.
        ENDIF.
      ENDLOOP.

      CALL FUNCTION 'SSF_CLOSE'.

    WHEN 'PALLET_RE'.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname           = 'ZWM_PALLET_LABLE_QR_PRNT'
        IMPORTING
          fm_name            = v_form_name
        EXCEPTIONS
          no_form            = 1
          no_function_module = 2
          OTHERS             = 3.

      control_parameters-no_open   = 'X'.
      control_parameters-no_close  = 'X'.
      CALL FUNCTION 'SSF_OPEN'
        EXPORTING
          output_options     = output
          control_parameters = control
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.

      IF gt_pallet IS NOT INITIAL.
        SELECT matnr
               maktx
          FROM makt
          INTO TABLE lt_makt
          FOR ALL ENTRIES IN gt_pallet
          WHERE matnr EQ gt_pallet-matnr
            AND spras EQ sy-langu.
        SORT lt_makt BY matnr.
      ENDIF.

      lt_pallet = gt_pallet.
      DELETE lt_pallet WHERE chkbx EQ abap_false.

      DESCRIBE TABLE lt_pallet LINES lv_no.

      LOOP AT gt_pallet ASSIGNING <fs_pallet> WHERE chkbx EQ abap_true.

        READ TABLE lt_makt INTO ls_makt WITH KEY matnr = <fs_pallet>-matnr BINARY SEARCH.
        ls_sufrom-aufnr = <fs_pallet>-aufnr.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = <fs_pallet>-su_from
          IMPORTING
            output = ls_sufrom-zsu_no.

        ls_suto-aufnr = <fs_pallet>-aufnr.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = <fs_pallet>-su_to
          IMPORTING
            output = ls_suto-zsu_no.

        count = count + 1.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            maktx              = ls_makt-maktx
            count              = count
            wa_su_no1          = ls_sufrom
            wa_su_no2          = ls_suto
            lv_aufnr           = <fs_pallet>-aufnr
            lv_no              = lv_no
            lv_charg           = <fs_pallet>-charg
            lv_werks           = <fs_pallet>-werks
            lv_matnrr          = <fs_pallet>-matnr
            lv_palletno        = <fs_pallet>-palletno
            lv_zlotno          = <fs_pallet>-zlotno          """""""""""""
            lv_zprange         = <fs_pallet>-zprange         """"""""""""
            lv_qty             = <fs_pallet>-pal_qty
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
        IF sy-subrc IS INITIAL AND sy-ucomm EQ 'PRNT'.
          LOOP AT gt_final ASSIGNING <fs_final> WHERE palletno EQ <fs_pallet>-palletno.
            <fs_final>-re_pal_print = abap_true.
            <fs_final>-re_pal_date  = sy-datum.
            <fs_final>-re_pal_time  = sy-uzeit.
            <fs_final>-re_pal_name  = sy-uname.

            UPDATE zwm_su SET re_pal_print = abap_true
                              re_pal_date  = sy-datum
                              re_pal_time  = sy-uzeit
                              re_pal_name  = sy-uname
                          WHERE aufnr EQ <fs_final>-aufnr
                            AND lenum EQ <fs_final>-lenum.
          ENDLOOP.
          <fs_pallet>-re_pal_print = abap_true.
          <fs_pallet>-re_pal_date  = sy-datum.
          <fs_pallet>-re_pal_time  = sy-uzeit.
          <fs_pallet>-re_pal_name  = sy-uname.
        ENDIF.
      ENDLOOP.

      CALL FUNCTION 'SSF_CLOSE'.
    WHEN 'PALLET_DEL'.
      SORT gt_pallet DESCENDING BY palletno.
      LOOP AT gt_pallet ASSIGNING <fs_pallet>." WHERE chkbx EQ abap_true.
        IF <fs_pallet>-chkbx EQ abap_true.
          LOOP AT gt_final ASSIGNING <fs_final> WHERE palletno EQ <fs_pallet>-palletno.
            UPDATE zwm_su SET palletno    = ' '
                              pal_print   = abap_false
                              pal_date    = '00000000'
                              pal_time    = '00:00:00'
                              pal_name    = ' '
                              re_pal_date = '00000000'
                              re_pal_time = '00:00:00'
                              re_pal_name = ' '
                              zlotno      = ' '
                              zprange     = ' '
                        WHERE aufnr EQ <fs_final>-aufnr
                          AND lenum EQ <fs_final>-lenum.
            DELETE gt_pallet WHERE palletno = <fs_final>-palletno.

*----------<< Start | Dispatch process change | by srimathi | 07.08.2024 | DEVK944530 >>-------$

            SELECT COUNT(*) FROM zwm_plant_config WHERE plant = gs_final-werks.
            IF sy-subrc = 0.
*
              CALL FUNCTION 'ZWM_FM_PALLETIZATION'
                EXPORTING
                  iv_warehouse_type = lv_warehouse_type
                  iv_warehouse_no   = <fs_final>-lgnum
                  iv_pallet_no      = <fs_final>-palletno
                  iv_su_no          = <fs_final>-lenum
                  iv_method         = 'PALLET_DEL'.

            ENDIF.

*-----------<< End | Dispatch process change | by srimathi | 07.08.2024 | DEVK944530 >>--------$

          ENDLOOP.
        ELSE.
          READ TABLE gt_pallet INTO DATA(ls_lenum) WITH KEY chkbx = 'X'.
          IF ls_lenum-lenum <> <fs_pallet>-lenum AND sy-subrc = 0.
            MESSAGE 'Select last pallet of this list' TYPE 'S' DISPLAY LIKE 'E'.
            EXIT.
          ENDIF.
        ENDIF.
      ENDLOOP.
      SORT gt_pallet ASCENDING BY palletno.
    WHEN 'RESET_PAL'.
      LOOP AT gt_pallet ASSIGNING <fs_pallet> WHERE chkbx EQ abap_true.
        LOOP AT gt_final ASSIGNING <fs_final> WHERE palletno EQ <fs_pallet>-palletno.
          UPDATE zwm_su SET pal_print    = abap_false
                            pal_date     = '00000000'
                            pal_time     = '00:00:00'
                            pal_name     = ' '
                            re_pal_print = abap_false
                            re_pal_date  = '00000000'
                            re_pal_time  = '00:00:00'
                            re_pal_name  = ' '
                      WHERE aufnr EQ <fs_final>-aufnr
                        AND lenum EQ <fs_final>-lenum.
          DELETE gt_pallet WHERE palletno = <fs_final>-palletno.
        ENDLOOP.
      ENDLOOP.

    WHEN 'PRINT_SU'.
      IF r_br EQ abap_true.
        IF r_ad EQ abap_true.
          PERFORM print_adhesive.
        ELSEIF r_pt EQ abap_true.
          PERFORM print_paint.
        ENDIF.
      ELSEIF r_qr EQ abap_true.
        PERFORM print_qrcode.
      ENDIF.

    WHEN 'REPRINT_SU'.
      IF r_br EQ abap_true.
        IF r_ad EQ abap_true.
          PERFORM print_adhesive.
        ELSEIF r_pt EQ abap_true.
          PERFORM print_paint.
        ENDIF.
      ELSEIF r_qr EQ abap_true.
        PERFORM print_qrcode.
      ENDIF.
    WHEN 'RESET_SU'.
      SORT gt_final DESCENDING BY lenum.
      LOOP AT gt_final INTO gs_final." WHERE chkbx EQ abap_true.
        IF gs_final-chkbx EQ 'X'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*          SELECT SINGLE * FROM zwm_su
*          INTO @DATA(ls_su) WHERE lenum EQ @gs_final-lenum.

          SELECT * FROM zwm_su
           INTO @DATA(ls_su) UP TO 1 ROWS WHERE lenum EQ @gs_final-lenum
           ORDER BY PRIMARY KEY .
          ENDSELECT.
* End of Quick Fix

          IF sy-subrc EQ 0.
            ls_su-pprint   = abap_false.
            ls_su-pdate    = ''.
            ls_su-ptime    = ''.
            ls_su-puname   = ''.
            ls_su-re_print = abap_false.
            ls_su-re_pdate = ''.
            ls_su-re_ptime = ''.
            ls_su-l_typ    = ''.
            ls_su-p_typ    = ''.
            ls_su-re_ptime = ''.
            MODIFY zwm_su FROM ls_su.
            DELETE gt_final WHERE lenum = gs_final-lenum.
          ENDIF.
        ELSE.
          READ TABLE gt_final INTO gs_lenum WITH KEY chkbx = 'X'.
          IF gs_lenum-lenum <> gs_final-lenum AND sy-subrc = 0.
            MESSAGE 'Select last record of the list' TYPE 'S' DISPLAY LIKE 'E'.
            EXIT.
          ENDIF.
        ENDIF.
      ENDLOOP.
      SORT gt_final ASCENDING BY lenum.
  ENDCASE.
  p_selfield-refresh = 'X'.

  CLEAR:ls_zwm_su,
        ls_sufrom,
        lv_no,
        count,
        ls_suto,
        lv_palletno,
        gd_repid,
        lv_qty,
        control_parameters,
        output_options,
        control,
        output,
        lv_qtyumrez,
        lv_ans,
        lv_year.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCATELOG_SU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fieldcatelog_su.
  wa_fieldcat-fieldname = 'CHKBX'.
  wa_fieldcat-seltext_l = 'Select'.
  wa_fieldcat-checkbox  = 'X'.
  wa_fieldcat-edit      = 'X'.
  wa_fieldcat-outputlen = 16.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'AUFNR'.
  wa_fieldcat-seltext_l = 'Production Order Number'.
  wa_fieldcat-outputlen = 12.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LENUM'.
  wa_fieldcat-seltext_l = 'Storage Unit Number'.
  wa_fieldcat-outputlen = 20.
  wa_fieldcat-no_zero   = abap_true.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'TANUM'.
  wa_fieldcat-seltext_l = 'Transfer Order No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_CNT'.
  wa_fieldcat-seltext_l = 'Serial No'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATNR'.
  wa_fieldcat-seltext_l = 'Material Number'.
  wa_fieldcat-outputlen = 18.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'CHARG'.
  wa_fieldcat-seltext_l = 'Batch'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'WERKS'.
  wa_fieldcat-seltext_l = 'Plant'.
  wa_fieldcat-outputlen = 5.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_QTY'.
  wa_fieldcat-seltext_l = 'SU Quantity'.
  wa_fieldcat-outputlen = 13.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SU_UNIT'.
  wa_fieldcat-seltext_l = 'SU Unit'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BDATU'.
  wa_fieldcat-seltext_l = 'Created On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BZEIT'.
  wa_fieldcat-seltext_l = 'Created time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BNAME'.
  wa_fieldcat-seltext_l = 'Created By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PPRINT'.
  wa_fieldcat-seltext_l = 'Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PDATE'.
  wa_fieldcat-seltext_l = 'Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PTIME'.
  wa_fieldcat-seltext_l = 'Printed time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'PUNAME'.
  wa_fieldcat-seltext_l = 'Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PRINT'.
  wa_fieldcat-seltext_l = 'Re Print indicator'.
  wa_fieldcat-outputlen = 1.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PDATE'.
  wa_fieldcat-seltext_l = 'Re Printed On'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_PTIME'.
  wa_fieldcat-seltext_l = 'Re Printed Time'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'RE_UNAME'.
  wa_fieldcat-seltext_l = 'Re Printed By'.
  wa_fieldcat-outputlen = 10.
  wa_fieldcat-tabname   = 'GT_FINAL'.
  APPEND wa_fieldcat TO it_fieldcat.
  CLEAR wa_fieldcat.

  ls_layout-zebra = 'X'.
  ls_layout-info_fieldname = 'COLOR'.
  ls_layout-colwidth_optimize = 'X'.
  APPEND ls_layout .
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  RESET_PALLET
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM reset_pallet .
  IF s_palno[] IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
*        AND palletno IN s_palno
*        AND pal_print EQ abap_true
*        AND p_ind     EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
            AND lenum    IN s_lenum
            AND palletno IN s_palno
            AND pal_print EQ abap_true
            AND p_ind     EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'No data found for given selection' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ELSE.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zwm_su
*      INTO CORRESPONDING FIELDS OF TABLE gt_final
*      WHERE aufnr    IN s_aufnr
*        AND lenum    IN s_lenum
*        AND palletno NE ''
*        AND pal_print EQ abap_true
*        AND p_ind     EQ abap_false.

    SELECT * FROM zwm_su
          INTO CORRESPONDING FIELDS OF TABLE gt_final
          WHERE aufnr    IN s_aufnr
            AND lenum    IN s_lenum
            AND palletno NE ''
            AND pal_print EQ abap_true
            AND p_ind     EQ abap_false ORDER BY PRIMARY KEY .

* End of Quick Fix

    IF gt_final IS INITIAL.
      MESSAGE 'Pallets are not yet printed given inputs' TYPE 'S' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.
  ENDIF.

  """""added by akshay dt.09.06.2025
  IF gt_final[] IS NOT INITIAL.

    SELECT * FROM afpo INTO TABLE @DATA(lt_batch) FOR ALL ENTRIES IN @gt_final
      WHERE aufnr = @gt_final-aufnr AND matnr = @gt_final-matnr.

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<lf_final>).
      READ TABLE lt_batch INTO DATA(wa_batch) WITH KEY  aufnr = <lf_final>-aufnr matnr = <lf_final>-matnr.
      IF sy-subrc = 0.
        <lf_final>-charg = wa_batch-charg.
      ENDIF.
    ENDLOOP.

  ENDIF.
  """""eoc dt.09.06.2025

  LOOP AT gt_final INTO gs_final.
    MOVE-CORRESPONDING gs_final TO gs_pallet.
    APPEND gs_pallet TO gt_pallet.
    CLEAR:gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.

  LOOP AT gt_pallet_tmp INTO DATA(ls_pallet).
    gs_pallet = ls_pallet.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls_pallet-lenum.
    ENDIF.

    gv_flag = abap_true.

    gv_qty  = gv_qty + 1.

    gv_qty1  = gv_qty1 + ls_pallet-su_qty.
    AT END OF palletno.
      gs_pallet-pal_qty = gv_qty.
      gs_pallet-su_qty  = gv_qty1.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      APPEND gs_pallet TO gt_pallet.
      CLEAR:gv_flag,gs_pallet,gv_qty,gv_qty1.
    ENDAT.
  ENDLOOP.

  PERFORM build_fieldcataloge_pal.
  ls_layout-colwidth_optimize = abap_true.
  IF gt_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'Z_PF_STATUS'
        i_callback_user_command  = 'USER_COMMAND'
        i_callback_top_of_page   = 'SUB_TOP_OF_PAGE'
        is_layout                = ls_layout
        it_fieldcat              = it_fieldcat
        i_default                = 'X'
        i_save                   = 'A'
        it_sort                  = it_sort
      TABLES
        t_outtab                 = gt_pallet
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
  ELSE.
    MESSAGE 'No Data found for given input' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_ADHESIVE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print_adhesive .
  IF gt_final IS NOT INITIAL.
    READ TABLE gt_final INTO gs_final INDEX 1.
    SELECT COUNT( * ) FROM zwm_su
    INTO @DATA(l_cnt)
     WHERE aufnr  EQ @gs_final-aufnr
       AND pprint EQ @abap_true.

    CLEAR:wa_header,
          wa_address.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE low FROM tvarvc INTO @DATA(v_uom) WHERE name EQ 'Z_LABEL_UOM'.

    SELECT low FROM tvarvc INTO @DATA(v_uom) UP TO 1 ROWS WHERE name EQ 'Z_LABEL_UOM'
     ORDER BY PRIMARY KEY .
    ENDSELECT.

* End of Quick Fix


    SELECT SINGLE adrnr
      INTO @DATA(v_adrnr)
      FROM t001w
      WHERE werks = @gs_final-werks.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
*    city1 city2 post_code1 region country
*      INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
*                    wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
*                    wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country)
*      FROM adrc
*      WHERE addrnumber = v_adrnr.

    SELECT name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
     city1 city2 post_code1 region country INTO ( wa_header-plant_name1 , wa_header-plant_street , wa_header-plant_house_num1 , wa_header-plant_house_num2 , wa_header-plant_str_suppl1 , wa_header-plant_str_suppl2 , wa_header-plant_str_suppl3 ,
     wa_header-plant_city1 , wa_header-plant_city2 , wa_header-plant_post_code1 , wa_header-plant_region , wa_header-plant_country ) FROM adrc UP TO 1 ROWS WHERE addrnumber = v_adrnr
     ORDER BY PRIMARY KEY .
    ENDSELECT.
* End of Quick Fix


    SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland = wa_header-plant_region AND land1 = wa_header-plant_country AND spras = sy-langu.
    SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = sy-langu.


    DATA(v_plant_name) = wa_header-plant_name1.
    IF NOT wa_header-plant_house_num1 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num1 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num1.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_house_num2 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num2 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_str_suppl1 IS INITIAL.
      wa_address-street_address2 = wa_header-plant_str_suppl1.
    ENDIF.

    IF NOT wa_header-plant_str_suppl2 IS INITIAL.
      wa_address-street_address3 = wa_header-plant_str_suppl2.
    ENDIF.

    IF NOT wa_header-plant_str_suppl3 IS INITIAL.
      wa_address-street_address4 = wa_header-plant_str_suppl3.
    ENDIF.

    IF NOT wa_header-plant_city1 IS INITIAL.
      wa_address-city_address1 = wa_header-plant_city1.
    ENDIF.

    IF NOT wa_header-plant_city2 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 ','  wa_header-plant_city2 INTO wa_address-city_address1 SEPARATED BY space.
        wa_address-city_address1 = wa_header-plant_city2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_post_code1 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 '-' wa_header-plant_post_code1 INTO wa_address-city_address1 SEPARATED BY space.
      ELSE.
        wa_address-city_address1 = wa_header-plant_post_code1.
      ENDIF.
    ENDIF.
    IF NOT v_region IS INITIAL.
      wa_address-state_address1 = v_region.
    ENDIF.

    IF NOT v_country IS INITIAL.
      IF NOT wa_address-state_address1 IS INITIAL.
        CONCATENATE wa_address-state_address1 ',' v_country INTO wa_address-state_address1 SEPARATED BY space.
      ELSE.
        wa_address-state_address1 = v_country.
      ENDIF.
    ENDIF.

    SELECT matnr,
           charg,
           hsdat
      FROM mch1
      INTO TABLE @DATA(it_mch1)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND charg EQ @gt_final-charg.

    IF sy-subrc EQ 0.
      SORT it_mch1 BY matnr charg.
    ENDIF.

    SELECT matnr,
           maktx
      FROM makt
      INTO TABLE @DATA(it_makt)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND spras EQ @sy-langu.
    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.
  ENDIF.

  REFRESH:lt_ad.

************************************Begin of Changes Added by Raj on 18.06.2024*****************************

  SELECT matnr,mtart FROM mara INTO TABLE @DATA(it_mara) FOR ALL ENTRIES IN @gt_final WHERE matnr  = @gt_final-matnr.
  READ TABLE it_mara INTO DATA(wa_mara) INDEX 1.        "#EC CI_NOORDER
  lv_mtart = wa_mara-mtart.
************************************End of changes Added by Raj on 18.06.2024******************************

  LOOP AT gt_final ASSIGNING <fs_final> WHERE chkbx EQ abap_true.
    ls_ad-lenum  =  <fs_final>-lenum.
    ls_ad-su_qty = <fs_final>-su_qty.
    ls_ad-uom    = <fs_final>-meins.
    ls_ad-matnr  = <fs_final>-matnr .
    ls_ad-charg  = <fs_final>-charg.
    ls_ad-su_cnt = <fs_final>-su_cnt.
    IF <fs_final>-meins = 'EA'.
      ls_ad-uom  = v_uom.
    ENDIF.

    IF sy-ucomm = 'REPRINT_SU'.
      ls_ad-hsdat = <fs_final>-manf_date."p_data.
    ELSE.
      ls_ad-hsdat = p_data.
    ENDIF.
*        CONCATENATE p_data+4(4) p_data+2(2) p_data+0(2) INTO ls_ad-hsdat.

    READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = <fs_final>-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      ls_ad-maktx = wa_makt-maktx.
    ENDIF.
    APPEND ls_ad TO lt_ad.
    CLEAR:ls_ad.
  ENDLOOP.


  IF sy-ucomm <> 'REPRINT_SU'.
    DESCRIBE TABLE gt_final LINES DATA(lv_no). "lt_ad
    lv_no = lv_no + l_cnt.
  ELSE.
    SELECT COUNT( * ) FROM zwm_su INTO lv_no WHERE aufnr IN s_aufnr.
*      lv_no = lv_no + l_cnt.
  ENDIF.

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
      formname           = 'ZWM_LABLE_ADHESIVE_BARCODE' "change smartform for page format change " old - " 'ZLABEL_PRINT_NEW'
    IMPORTING
      fm_name            = v_form_name
    EXCEPTIONS
      no_form            = 1
      no_function_module = 2
      OTHERS             = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  IF lt_ad IS NOT INITIAL.
    DESCRIBE TABLE lt_ad LINES DATA(w_cnt).
    DATA:count TYPE sy-tabix.

    LOOP AT lt_ad INTO ls_ad.
      count = ls_ad-su_cnt. " count + 1.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = ls_ad
          wa_address         = wa_address
          v_plant_name       = v_plant_name
          count              = count
          lv_no              = lv_no
          lv_mtart           = lv_mtart
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
      IF sy-ucomm EQ 'PRNT'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE * FROM zwm_su
*          INTO @DATA(ls_su) WHERE lenum = @ls_ad-lenum.

        SELECT * FROM zwm_su
         INTO @DATA(ls_su) UP TO 1 ROWS WHERE lenum = @ls_ad-lenum
         ORDER BY PRIMARY KEY .
        ENDSELECT.
* End of Quick Fix

        IF sy-subrc EQ 0.
          IF r3 EQ abap_true.
            ls_su-pprint    = abap_true.
            ls_su-pdate     = sy-datum.
            ls_su-ptime     = sy-uzeit.
            ls_su-puname    = sy-uname.
            ls_su-manf_date = p_data.
            ls_su-l_typ     = 'B'.
            ls_su-p_typ     = 'A'.
            MODIFY zwm_su FROM ls_su.
          ELSEIF r4 EQ abap_true.
            ls_su-re_print  = abap_true.
            ls_su-re_pdate  = sy-datum.
            ls_su-re_ptime  = sy-uzeit.
            ls_su-re_uname  = sy-uname.
            MODIFY zwm_su FROM ls_su.
          ENDIF.
        ENDIF.
        DELETE gt_final WHERE lenum = ls_ad-lenum.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDFORM.

FORM print_paint.

  IF gt_final IS NOT INITIAL.
    READ TABLE gt_final INTO gs_final INDEX 1.
    SELECT COUNT( * ) FROM zwm_su
    INTO @DATA(l_cnt)
     WHERE aufnr  EQ @gs_final-aufnr
       AND pprint EQ @abap_true.

    CLEAR:wa_header,
          wa_address.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE low FROM tvarvc INTO @DATA(v_uom)  WHERE name EQ 'Z_LABEL_UNIT'.

    SELECT low FROM tvarvc INTO @DATA(v_uom) UP TO 1 ROWS WHERE name EQ 'Z_LABEL_UNIT'
     ORDER BY PRIMARY KEY .
    ENDSELECT.

* End of Quick Fix

    SELECT * FROM tvarvc INTO TABLE @DATA(it_tvarvc)  WHERE name EQ 'Z_LABEL_UNIT'.
    SELECT * FROM tvarvc INTO TABLE @DATA(it_tvarvc1) WHERE name EQ 'Z_LABEL_SORG'.


    IF it_tvarvc IS NOT INITIAL.
      LOOP AT it_tvarvc INTO DATA(wa_tvarvc).
        gc_rv-sign   = wa_tvarvc-sign.
        gc_rv-option = wa_tvarvc-opti.
        gc_rv-low    = wa_tvarvc-low.
        gc_rv-high   = wa_tvarvc-high.
        APPEND gc_rv.
      ENDLOOP.
    ENDIF.

    IF it_tvarvc1 IS NOT INITIAL.
      LOOP AT it_tvarvc1 INTO DATA(wa_tvarvc1).
        gc_rv1-sign   = wa_tvarvc1-sign.
        gc_rv1-option = wa_tvarvc1-opti.
        gc_rv1-low    = wa_tvarvc1-low.
        gc_rv1-high   = wa_tvarvc1-high.
        APPEND gc_rv1.
      ENDLOOP.
    ENDIF.

    SELECT SINGLE adrnr INTO @DATA(v_adrnr) FROM t001w WHERE werks = @gs_final-werks.
    SELECT SINGLE bwkey, bukrs FROM t001k INTO @DATA(ls_t001k) WHERE bwkey EQ @gs_final-werks.
    SELECT SINGLE adrnr FROM t001 INTO @DATA(v_adrnr1) WHERE bukrs = @ls_t001k-bukrs.

    SELECT SINGLE smtp_addr FROM adr6 INTO @data(wa_adr6-smtp_addr)  WHERE addrnumber = @v_adrnr1.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
*    city1 city2 post_code1 region country
*      INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
*                    wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
*                    wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country)
*      FROM adrc
*      WHERE addrnumber = v_adrnr.

    SELECT name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
     city1 city2 post_code1 region country INTO ( wa_header-plant_name1 , wa_header-plant_street , wa_header-plant_house_num1 , wa_header-plant_house_num2 , wa_header-plant_str_suppl1 , wa_header-plant_str_suppl2 , wa_header-plant_str_suppl3 ,
     wa_header-plant_city1 , wa_header-plant_city2 , wa_header-plant_post_code1 , wa_header-plant_region , wa_header-plant_country ) FROM adrc UP TO 1 ROWS WHERE addrnumber = v_adrnr
     ORDER BY PRIMARY KEY .
    ENDSELECT.
* End of Quick Fix


    SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland = wa_header-plant_region AND land1 = wa_header-plant_country AND spras = sy-langu.
    SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = sy-langu.


    DATA(v_plant_name) = wa_header-plant_name1.
    IF NOT wa_header-plant_house_num1 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num1 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num1.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_house_num2 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num2 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_str_suppl1 IS INITIAL.
      wa_address-street_address2 = wa_header-plant_str_suppl1.
    ENDIF.

    IF NOT wa_header-plant_str_suppl2 IS INITIAL.
      wa_address-street_address3 = wa_header-plant_str_suppl2.
    ENDIF.

    IF NOT wa_header-plant_str_suppl3 IS INITIAL.
      wa_address-street_address4 = wa_header-plant_str_suppl3.
    ENDIF.

    IF NOT wa_header-plant_city1 IS INITIAL.
      wa_address-city_address1 = wa_header-plant_city1.
    ENDIF.

    IF NOT wa_header-plant_city2 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 ','  wa_header-plant_city2 INTO wa_address-city_address1 SEPARATED BY space.
        wa_address-city_address1 = wa_header-plant_city2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_post_code1 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 '-' wa_header-plant_post_code1 INTO wa_address-city_address1 SEPARATED BY space.
      ELSE.
        wa_address-city_address1 = wa_header-plant_post_code1.
      ENDIF.
    ENDIF.
    IF NOT v_region IS INITIAL.
      wa_address-state_address1 = v_region.
    ENDIF.

    IF NOT v_country IS INITIAL.
      IF NOT wa_address-state_address1 IS INITIAL.
        CONCATENATE wa_address-state_address1 ',' v_country INTO wa_address-state_address1 SEPARATED BY space.
      ELSE.
        wa_address-state_address1 = v_country.
      ENDIF.
    ENDIF.

    SELECT matnr,
           maktx
      FROM makt
      INTO TABLE @DATA(it_makt)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND spras EQ @sy-langu.
    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.

    SELECT kschl,
           vkorg,
           matnr,
           datbi,
           datab,
           knumh
      FROM a999
      INTO TABLE @DATA(it_a999)
      FOR ALL ENTRIES IN @gt_final
      WHERE kschl = 'PR00'
        AND vkorg IN @gc_rv1
        AND matnr EQ @gt_final-matnr
        AND datab LE @sy-datum
        AND datbi GE @sy-datum.

    IF it_a999 IS NOT INITIAL.
      SELECT knumh,
             kbetr,
             kmein
        FROM konp
        INTO TABLE @DATA(it_konp)
        FOR ALL ENTRIES IN @it_a999
        WHERE knumh EQ @it_a999-knumh.
    ENDIF.

    SELECT kschl,
           vkorg,
           pltyp,
           matnr,
           datbi,
           datab,
           knumh
      FROM a906
      INTO TABLE @DATA(it_a906)
      FOR ALL ENTRIES IN @gt_final
      WHERE kschl = 'PR00'
        AND vkorg IN @gc_rv1
        AND pltyp EQ '07'
        AND matnr EQ @gt_final-matnr
        AND datab LE @sy-datum
        AND datbi GE @sy-datum.
    IF it_a906 IS NOT INITIAL.
      SELECT knumh,
             kbetr,
             kmein
        FROM konp
        INTO TABLE @DATA(it_konp1)
        FOR ALL ENTRIES IN @it_a906
        WHERE knumh EQ @it_a906-knumh.
    ENDIF.

    SELECT matnr,
           groes
     FROM mara
     INTO TABLE @DATA(it_mara)
     FOR ALL ENTRIES IN @gt_final
     WHERE matnr EQ @gt_final-matnr.

    SELECT matnr,
           meinh,
           umrez,
           umren
      FROM marm
      INTO TABLE @DATA(it_marm)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND meinh IN @gc_rv.

    SELECT matnr,
      "Changed by UDAYABAP03 on 10.04.2026
*           mvgr5
           mvgr1
      "Changed by UDAYABAP03 on 10.04.2026
      FROM mvke
      INTO TABLE @DATA(it_mvke)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND vkorg EQ @gc_rv1-low.

  ENDIF.

  REFRESH:lt_paint.

  LOOP AT gt_final ASSIGNING <fs_final> WHERE chkbx EQ abap_true.
    ls_paint-lenum  =  <fs_final>-lenum.
    ls_paint-su_qty = <fs_final>-su_qty.
    ls_paint-meins  = <fs_final>-meins.
    ls_paint-matnr  = <fs_final>-matnr .
    ls_paint-charg  = <fs_final>-charg.
    ls_paint-su_cnt = <fs_final>-su_cnt.
    IF <fs_final>-meins = 'EA'.
      ls_paint-meins  = v_uom.
    ENDIF.

    IF sy-ucomm = 'REPRINT_SU'.
      ls_paint-hsdat = <fs_final>-manf_date."p_data.
    ELSE.
      ls_paint-hsdat = p_data.
    ENDIF.

    READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc EQ 0.
      ls_paint-maktx = wa_makt-maktx.
    ENDIF.

    READ TABLE it_mara INTO DATA(wa_mara) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc EQ 0.
      ls_paint-groes = wa_mara-groes.
    ENDIF.

    READ TABLE it_a999 INTO DATA(wa_a999) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc IS INITIAL.
      READ TABLE it_konp INTO DATA(wa_konp) WITH KEY knumh = wa_a999-knumh.
      IF sy-subrc EQ 0.
        ls_paint-kbetr = wa_konp-kbetr.
        ls_paint-kmein = wa_konp-kmein.
      ENDIF.
    ENDIF.


    READ TABLE it_a906 INTO DATA(wa_a906) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc IS INITIAL.
      READ TABLE it_konp1 INTO DATA(wa_konp1) WITH KEY knumh = wa_a906-knumh.
      IF sy-subrc EQ 0.
        ls_paint-kbetr1 = wa_konp1-kbetr.
        ls_paint-kmein1 = wa_konp1-kmein.
      ENDIF.
    ENDIF.

    READ TABLE it_marm INTO DATA(wa_marm) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc EQ 0.
      DATA(v_conve1) = wa_marm-umren / wa_marm-umrez.
      ls_paint-v_conve2 = v_conve1.                     " NET QUANTiTY
      ls_paint-total = v_conve1 *  <fs_final>-su_qty .
      ls_paint-meinh = wa_marm-meinh.
      ls_paint-umren1 =  v_conve1.
    ENDIF.

    READ TABLE it_mvke INTO DATA(wa_mvke) WITH KEY matnr = <fs_final>-matnr.
    IF sy-subrc EQ 0.
      "Changed by UDAYABAP03 on 10.04.2026
*      ls_paint-mvgr5 = wa_mvke-mvgr5.
      ls_paint-mvgr1 = wa_mvke-mvgr1.
      "Changed by UDAYABAP03 on 10.04.2026
    ENDIF.

    ls_paint-kbetr_mrp = ls_paint-kbetr1 * ls_paint-v_conve2.

    i_mrp = ls_paint-kbetr_mrp.


    CALL FUNCTION 'J_1I6_ROUND_TO_NEAREST_AMT'
      EXPORTING
        i_amount = i_mrp
      IMPORTING
        e_amount = o_mrp.

    ls_paint-kbetr_mrp = o_mrp.

    APPEND ls_paint TO lt_paint.
    CLEAR:ls_paint.
  ENDLOOP.

*  DESCRIBE TABLE lt_paint LINES DATA(lv_no).
  DESCRIBE TABLE gt_final LINES DATA(lv_no).

*  lv_no = lv_no + l_cnt.

  IF r_wmrp = 'X'. " r_mrp = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname           = 'ZWM_WOMRP_BARCODE_PRINT' " old - " ZLABEL_PRINT_PAINT_WOMRP_NEW'
      IMPORTING
        fm_name            = v_form_name
      EXCEPTIONS
        no_form            = 1
        no_function_module = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    DESCRIBE TABLE lt_paint LINES DATA(w_cnt).
    DATA count TYPE sy-tabix.

    LOOP AT lt_paint INTO ls_paint.
      count = ls_paint-su_cnt. " count + 1.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = ls_paint
          wa_address         = wa_address
          v_plant_name       = v_plant_name
          count              = count
          lv_no              = lv_no
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
      IF sy-ucomm EQ 'PRNT'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE * FROM zwm_su
*          INTO @DATA(ls_su) WHERE lenum = @ls_paint-lenum.

        SELECT * FROM zwm_su
         INTO @DATA(ls_su) UP TO 1 ROWS WHERE lenum = @ls_paint-lenum
         ORDER BY PRIMARY KEY .
        ENDSELECT.
* End of Quick Fix

        IF sy-subrc EQ 0.
          IF r3 EQ abap_true.
            ls_su-pprint    = abap_true.
            ls_su-pdate     = sy-datum.
            ls_su-ptime     = sy-uzeit.
            ls_su-puname    = sy-uname.
            ls_su-manf_date = p_data.
            ls_su-l_typ     = 'B'.
            ls_su-p_typ     = 'M'.
            MODIFY zwm_su FROM ls_su.
          ELSEIF r4 EQ abap_true.
            ls_su-re_print  = abap_true.
            ls_su-re_pdate  = sy-datum.
            ls_su-re_ptime  = sy-uzeit.
            ls_su-re_uname  = sy-uname.
            MODIFY zwm_su FROM ls_su.
          ENDIF.
        ENDIF.
        DELETE gt_final WHERE lenum = ls_paint-lenum.
      ENDIF.
    ENDLOOP.

  ELSEIF r_mrp = 'X'. " r_wmrp = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname           = 'ZLABEL_PRINT_PAINT_WITHMRP_N1' " old  - "'ZLABEL_PRINT_PAINT_WITHMRP_NEW'
      IMPORTING
        fm_name            = v_form_name
      EXCEPTIONS
        no_form            = 1
        no_function_module = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    DESCRIBE TABLE lt_paint LINES w_cnt.

    LOOP AT lt_paint INTO ls_paint.
      count = ls_paint-su_cnt. " count + 1.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = ls_paint
          wa_address         = wa_address
          v_plant_name       = v_plant_name
          count              = count
          lv_no              = lv_no
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
      IF sy-ucomm EQ 'PRNT'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE * FROM zwm_su
*          INTO ls_su WHERE lenum = ls_paint-lenum.

        SELECT * FROM zwm_su
         INTO ls_su UP TO 1 ROWS WHERE lenum = ls_paint-lenum
         ORDER BY PRIMARY KEY .
        ENDSELECT.
* End of Quick Fix

        IF sy-subrc EQ 0.
          IF r3 EQ abap_true.
            ls_su-pprint    = abap_true.
            ls_su-pdate     = sy-datum.
            ls_su-ptime     = sy-uzeit.
            ls_su-puname    = sy-uname.
            ls_su-l_typ     = 'B'.
            ls_su-p_typ     = 'W'.
            ls_su-manf_date = p_data.
            MODIFY zwm_su FROM ls_su.
          ELSEIF r4 EQ abap_true.
            ls_su-re_print  = abap_true.
            ls_su-re_pdate  = sy-datum.
            ls_su-re_ptime  = sy-uzeit.
            ls_su-re_uname  = sy-uname.
            MODIFY zwm_su FROM ls_su.
          ENDIF.
        ENDIF.
        DELETE gt_final WHERE lenum = ls_paint-lenum.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_QRCODE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print_qrcode .

  IF gt_final IS NOT INITIAL.
    READ TABLE gt_final INTO gs_final INDEX 1.
    SELECT COUNT( * ) FROM zwm_su
    INTO @DATA(l_cnt)
     WHERE aufnr  EQ @gs_final-aufnr
       AND pprint EQ @abap_true.

    CLEAR:wa_header,
          wa_address.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE low FROM tvarvc INTO @DATA(v_uom) WHERE name EQ 'Z_LABEL_UOM'.

    SELECT low FROM tvarvc INTO @DATA(v_uom) UP TO 1 ROWS WHERE name EQ 'Z_LABEL_UOM'
     ORDER BY PRIMARY KEY .
    ENDSELECT.

* End of Quick Fix


    SELECT SINGLE adrnr
      INTO @DATA(v_adrnr)
      FROM t001w
      WHERE werks = @gs_final-werks.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
*    city1 city2 post_code1 region country
*      INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
*                    wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
*                    wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country)
*      FROM adrc
*      WHERE addrnumber = v_adrnr.

    SELECT name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
     city1 city2 post_code1 region country INTO ( wa_header-plant_name1 , wa_header-plant_street , wa_header-plant_house_num1 , wa_header-plant_house_num2 , wa_header-plant_str_suppl1 , wa_header-plant_str_suppl2 , wa_header-plant_str_suppl3 ,
     wa_header-plant_city1 , wa_header-plant_city2 , wa_header-plant_post_code1 , wa_header-plant_region , wa_header-plant_country ) FROM adrc UP TO 1 ROWS WHERE addrnumber = v_adrnr
     ORDER BY PRIMARY KEY .
    ENDSELECT.
* End of Quick Fix


    SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland = wa_header-plant_region AND land1 = wa_header-plant_country AND spras = sy-langu.
    SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = sy-langu.


    DATA(v_plant_name) = wa_header-plant_name1.
    IF NOT wa_header-plant_house_num1 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num1 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num1.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_house_num2 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num2 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_str_suppl1 IS INITIAL.
      wa_address-street_address2 = wa_header-plant_str_suppl1.
    ENDIF.

    IF NOT wa_header-plant_str_suppl2 IS INITIAL.
      wa_address-street_address3 = wa_header-plant_str_suppl2.
    ENDIF.

    IF NOT wa_header-plant_str_suppl3 IS INITIAL.
      wa_address-street_address4 = wa_header-plant_str_suppl3.
    ENDIF.

    IF NOT wa_header-plant_city1 IS INITIAL.
      wa_address-city_address1 = wa_header-plant_city1.
    ENDIF.

    IF NOT wa_header-plant_city2 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 ','  wa_header-plant_city2 INTO wa_address-city_address1 SEPARATED BY space.
        wa_address-city_address1 = wa_header-plant_city2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_post_code1 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 '-' wa_header-plant_post_code1 INTO wa_address-city_address1 SEPARATED BY space.
      ELSE.
        wa_address-city_address1 = wa_header-plant_post_code1.
      ENDIF.
    ENDIF.
    IF NOT v_region IS INITIAL.
      wa_address-state_address1 = v_region.
    ENDIF.

    IF NOT v_country IS INITIAL.
      IF NOT wa_address-state_address1 IS INITIAL.
        CONCATENATE wa_address-state_address1 ',' v_country INTO wa_address-state_address1 SEPARATED BY space.
      ELSE.
        wa_address-state_address1 = v_country.
      ENDIF.
    ENDIF.

    SELECT matnr,
           charg,
           hsdat
      FROM mch1
      INTO TABLE @DATA(it_mch1)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND charg EQ @gt_final-charg.

    IF sy-subrc EQ 0.
      SORT it_mch1 BY matnr charg.
    ENDIF.

    SELECT matnr,
           maktx
      FROM makt
      INTO TABLE @DATA(it_makt)
      FOR ALL ENTRIES IN @gt_final
      WHERE matnr EQ @gt_final-matnr
        AND spras EQ @sy-langu.
    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.
  ENDIF.

  REFRESH:lt_ad.
  DATA : ls_ad1 TYPE zstr_label_rev.
  DATA : lt_ad1 TYPE TABLE OF zstr_label_rev.


  SELECT matnr,mtart FROM mara INTO TABLE @DATA(it_mara) FOR ALL ENTRIES IN @gt_final WHERE matnr  = @gt_final-matnr.
  READ TABLE it_mara INTO DATA(wa_mara) INDEX 1.        "#EC CI_NOORDER
  lv_mtart = wa_mara-mtart.



  LOOP AT gt_final ASSIGNING <fs_final> WHERE chkbx EQ abap_true.
    ls_ad1-lenum  =  <fs_final>-lenum.
    ls_ad1-su_qty = <fs_final>-su_qty.
    ls_ad1-meins  = <fs_final>-meins.
    ls_ad1-matnr  = <fs_final>-matnr .
    ls_ad1-charg  = <fs_final>-charg.
    ls_ad1-su_cnt = <fs_final>-su_cnt.
    IF <fs_final>-meins = 'EA'.
      ls_ad1-meins  = v_uom.
    ENDIF.

    IF sy-ucomm = 'REPRINT_SU'.   "Commented by Raj on 06.02.2025
*      ls_ad1-hsdat = <fs_final>-manf_date."bdatu.
      SELECT SINGLE hsdat FROM mch1 INTO ls_ad1-hsdat WHERE matnr = ls_ad1-matnr AND charg = ls_ad1-charg. "Added by Raj on 06.02.2025
      IF ls_ad1-hsdat IS  INITIAL.
        SELECT SINGLE * FROM zwm_pp INTO @DATA(wa_wm) WHERE aufnr = @<fs_final>-aufnr.
        ls_ad1-hsdat = wa_wm-pdate.
        CLEAR : wa_wm.
      ENDIF.

    ELSE.
      ls_ad1-hsdat = p_data.

      ls_wm-aufnr = <fs_final>-aufnr.
      ls_wm-pdate = p_data.
      MODIFY zwm_pp FROM ls_wm.
      CLEAR : ls_wm.

    ENDIF.







*        CONCATENATE p_data+4(4) p_data+2(2) p_data+0(2) INTO ls_ad-hsdat.

    READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = <fs_final>-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      ls_ad1-maktx = wa_makt-maktx.
    ENDIF.
    APPEND ls_ad1 TO lt_ad1.
    CLEAR:ls_ad1.
  ENDLOOP.


  IF sy-ucomm <> 'REPRINT_SU'.
    DESCRIBE TABLE gt_final LINES DATA(lv_no). "lt_ad
    lv_no = lv_no + l_cnt.
  ELSE.
    SELECT COUNT( * ) FROM zwm_su INTO lv_no WHERE aufnr IN s_aufnr.
*      lv_no = lv_no + l_cnt.
  ENDIF.

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
      formname           = 'ZMM_LABEL_PRINT_NEW' "'ZLABEL_PRINT_NEW'
    IMPORTING
      fm_name            = v_form_name
    EXCEPTIONS
      no_form            = 1
      no_function_module = 2
      OTHERS             = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  IF lt_ad1 IS NOT INITIAL.
    DESCRIBE TABLE lt_ad1 LINES DATA(w_cnt).
    DATA:count TYPE sy-tabix.

    LOOP AT lt_ad1 INTO ls_ad1.
      count = ls_ad1-su_cnt. " count + 1.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = ls_ad1
          wa_address         = wa_address
          v_plant_name       = v_plant_name
          count              = count
          lv_no              = lv_no
          lv_mtart           = lv_mtart
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
      IF sy-ucomm EQ 'PRNT'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE * FROM zwm_su
*          INTO @DATA(ls_su) WHERE lenum = @ls_ad1-lenum.

        SELECT * FROM zwm_su
         INTO @DATA(ls_su) UP TO 1 ROWS WHERE lenum = @ls_ad1-lenum
         ORDER BY PRIMARY KEY .
        ENDSELECT.
* End of Quick Fix

        IF sy-subrc EQ 0.
          IF r3 EQ abap_true.
            ls_su-pprint    = abap_true.
            ls_su-pdate     = sy-datum.
            ls_su-ptime     = sy-uzeit.
            ls_su-puname    = sy-uname.
            ls_su-manf_date = p_data.
            ls_su-l_typ     = 'Q'.
            ls_su-p_typ     = 'Q'.
            MODIFY zwm_su FROM ls_su.
          ELSEIF r4 EQ abap_true.
            ls_su-re_print  = abap_true.
            ls_su-re_pdate  = sy-datum.
            ls_su-re_ptime  = sy-uzeit.
            ls_su-re_uname  = sy-uname.
            MODIFY zwm_su FROM ls_su.
          ENDIF.
        ENDIF.
        DELETE gt_final WHERE lenum = ls_ad1-lenum.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  S_AUFNR_F4
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_S_AUFNR_LOW  text
*----------------------------------------------------------------------*
FORM s_aufnr_f4  CHANGING s_aufnr-low.
  CALL FUNCTION 'F4IF_FIELD_VALUE_REQUEST'
    EXPORTING
      tabname           = 'CAUFVD'
      fieldname         = 'AUFNR'
      searchhelp        = 'CO_SH_PRODORD_ALL'
      dynpprog          = sy-cprog
      dynpnr            = sy-dynnr
      dynprofield       = 'S_AUFNR-LOW'
    EXCEPTIONS
      field_not_found   = 1
      no_help_for_field = 2
      inconsistent_help = 3
      no_values_found   = 4
      OTHERS            = 5.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

*  TYPES:BEGIN OF aufk,
*         aufnr TYPE aufk-aufnr,                           " zebita_salesgl-zgroup,
*        END OF aufk.
*  DATA:
*    lt_values TYPE  TABLE OF aufk,
*    lt_return TYPE STANDARD TABLE OF aufk
*    .
*  REFRESH :lt_values,lt_return.
*  SELECT aufnr                                         "#EC CI_NOWHERE
*  FROM aufk
*  INTO TABLE lt_values.
*  IF sy-subrc NE 0.
*    RETURN.
*  ENDIF.
*  SORT lt_values BY AUFNR.
*  DELETE lt_values WHERE aufnr = ''.
*  DELETE ADJACENT DUPLICATES FROM lt_values COMPARING aufnr.
*  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
*    EXPORTING
*      retfield        = 'AUFNR'    " Name of field in VALUE_TAB
*      value_org       = 'S'        " Value return: C: cell by cell, S: structured
*    TABLES
*      value_tab       = lt_values  " Table of values: entries cell by cell
*      return_tab      = lt_return  " Return the selected value
*    EXCEPTIONS
*      parameter_error = 1          " Incorrect parameter
*      no_values_found = 2          " No values found
*      OTHERS          = 3.
*  IF sy-subrc NE 0.
*    RETURN.
*  ENDIF.
*  READ TABLE lt_return INTO DATA(ls_return) INDEX 1.
*  S_AUFNR = ls_return-aufnr."   fieldval.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  LT60
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM lt16 CHANGING p1.                          "added by 10.12.2024
*BREAK-POINT.
  REFRESH bdcdata[].
  PERFORM bdc_dynpro      USING 'SAPML03T' '0119'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'RL03T-RDNKL'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.
  PERFORM bdc_field       USING 'LEIN-LENUM'
                                p1.
*perform bdc_field       using 'RL03T-RHELL'
*                              record-RHELL_002.
*perform bdc_field       using 'RL03T-RDNKL'
*                              record-RDNKL_003.

  PERFORM bdc_dynpro      USING 'SAPML03T' '0120'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'LTAK-LGNUM'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BU'.
  CALL TRANSACTION 'LT16' USING bdcdata MODE p_mode  UPDATE 'S' MESSAGES INTO it_msg.

ENDFORM.                                                            "ended by 10.12.2024
*----------------------------------------------------------------------*
*        Start new screen                                              *
*----------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
  IF fval IS NOT INITIAL.
    CLEAR bdcdata.
    bdcdata-fnam = fnam.
    bdcdata-fval = fval.
    APPEND bdcdata.
  ENDIF.
ENDFORM.
