*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_ZWM_CONFIGTOP.                " Global Declarations
  INCLUDE LZFG_ZWM_CONFIGUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_ZWM_CONFIGF...                " Subroutines
* INCLUDE LZFG_ZWM_CONFIGO...                " PBO-Modules
* INCLUDE LZFG_ZWM_CONFIGI...                " PAI-Modules
* INCLUDE LZFG_ZWM_CONFIGE...                " Events
* INCLUDE LZFG_ZWM_CONFIGP...                " Local class implement.
* INCLUDE LZFG_ZWM_CONFIGT99.                " ABAP Unit tests
  INCLUDE LZFG_ZWM_CONFIGF00                      . " subprograms
  INCLUDE LZFG_ZWM_CONFIGI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
