*&---------------------------------------------------------------------*
*& Modulpool  ZWM_PALLET_PUTWAY
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
PROGRAM zwm_pallet_putway.

TYPES:BEGIN OF ty_elements,
        lgpla    TYPE lgpla,
        palletno TYPE zwm_su-palletno,
        matnr    TYPE matnr,
        maktx    TYPE maktx,
        charg    TYPE charg_d,
        lgort    TYPE lgort_d,
        lenumf   TYPE lenum,
        lenumt   TYPE lenum,
      END OF ty_elements.

DATA:gt_su       TYPE STANDARD TABLE OF zwm_su,
     gv_lgnum    TYPE lgnum,
     gs_elements TYPE ty_elements,
     wa_bdcdata  TYPE bdcdata,
     p_lgnum     TYPE ltak-lgnum,
     p_qty       TYPE mchb-clabs,
     lv_msg1(24) TYPE c,
     lv_msg2(24) TYPE c,
     lv_msg3(24) TYPE c.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9001 INPUT.
  TYPES: BEGIN OF ty_su,
           lenum TYPE lenum,
           lety1 TYPE lvs_letyp1,
           lgpla TYPE lgpla,
           auart TYPE auart,
           werks TYPE werks_d,
           solex TYPE ltak-solex,
           tanum TYPE ltak-tanum,
         END OF ty_su.

  DATA:lt_item     TYPE STANDARD TABLE OF bapi2017_gm_item_create,
       lt_ret      TYPE STANDARD TABLE OF bapiret2,
       it_trite    TYPE STANDARD TABLE OF l03b_trite,
       it_ltap_vb  TYPE STANDARD TABLE OF ltap_vb,
       it_ltak     TYPE STANDARD TABLE OF ltak_vb,
       lt_ltap_can TYPE STANDARD TABLE OF ltap_cancl,
       it_bdcdata  TYPE TABLE OF bdcdata,
       lt_su       TYPE TABLE OF ty_su,
       ls_su       TYPE ty_su,
       lv_tanum    TYPE ltak-tanum,
       lv_teilv    TYPE t340d-teilv,
       wa_trite    TYPE l03b_trite,
       ls_item     TYPE bapi2017_gm_item_create,
       ls_head     TYPE bapi2017_gm_head_01,
       lv_gmcd     TYPE bapi2017_gm_code,
       ls_doc      TYPE bapi2017_gm_head_ret,
       ls_ret      TYPE bapiret2.

  DATA: lv_error TYPE char01.

  CASE sy-ucomm.
    WHEN 'SAVE'.

      CLEAR: lv_error.
      PERFORM validate CHANGING lv_error.
      IF lv_error = 'E'.
        MESSAGE lv_msg1 TYPE 'E'.
        RETURN.
      ENDIF.

      IF gt_su IS INITIAL.
        EXIT.
      ENDIF.

      IF gs_elements-lgort IS INITIAL.
        lv_msg1 = 'Enter storage location'.
        MESSAGE lv_msg1 TYPE 'E'.
        RETURN.
        EXIT.
      ENDIF.

      ls_head-doc_date   = sy-datum.
      ls_head-pstng_date = sy-datum.
      ls_head-header_txt = 'ZWM_PUTWAY'.

      LOOP AT gt_su INTO DATA(gs_su).
        ls_item-entry_qnt = ls_item-entry_qnt + gs_su-su_qty.
      ENDLOOP.

      ls_item-material   = gs_su-matnr.
      ls_item-move_mat   = gs_su-matnr.
      ls_item-plant      = gs_su-werks.
      ls_item-move_plant = gs_su-werks.
      ls_item-stge_loc   = 'SF01'.
      ls_item-move_stloc = gs_elements-lgort.
*      ls_item-move_stloc = 'FG01'.
      ls_item-move_type  = 'Z11'.
      ls_item-entry_uom  = gs_su-meins.
      ls_item-batch      = gs_su-charg.
      ls_item-move_batch = gs_su-charg.
      APPEND ls_item TO lt_item.

      lv_gmcd-gm_code = '04'.

      CALL FUNCTION 'BAPI_GOODSMVT_CREATE' "#EC CI_USAGE_OK[2438131]
        EXPORTING
          goodsmvt_header  = ls_head
          goodsmvt_code    = lv_gmcd
        IMPORTING
          materialdocument = ls_doc-mat_doc
          matdocumentyear  = ls_doc-doc_year
        TABLES
          goodsmvt_item    = lt_item
          return           = lt_ret.
      IF ls_doc-mat_doc IS NOT INITIAL.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_true.

        SELECT SINGLE auart FROM aufk INTO @DATA(lv_auart)
                WHERE aufnr EQ @gs_su-aufnr.

        SELECT SINGLE * FROM zwm_config
          INTO @DATA(ls_zwm_config)
          WHERE werks EQ @gs_su-werks
            AND auart EQ @lv_auart.
        IF sy-subrc IS NOT INITIAL.
          lv_msg1 = 'Pls check ZWM_CONFIG'.
          EXIT.
        ENDIF.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE tbnum
*          FROM mseg
*          INTO @DATA(lv_tbnum)
*          WHERE mblnr EQ @ls_doc-mat_doc
*            AND mjahr EQ @ls_doc-doc_year
*            AND xauto EQ @abap_true.

SELECT TBNUM
 FROM MSEG INTO @DATA(LV_TBNUM) UP TO 1 ROWS WHERE MBLNR EQ @LS_DOC-MAT_DOC AND MJAHR EQ @LS_DOC-DOC_YEAR AND XAUTO EQ @ABAP_TRUE
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


        CLEAR :ls_doc-mat_doc,ls_doc-doc_year.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*        SELECT SINGLE lgnum,
*                      tbnum,
*                      tbpos,
*                      elikz,
*                      matnr,
*                      werks,
*                      charg,
*                      menge,
*                      meins,
*                      tamen,
*                      mbpos,
*                      lgort
*                 FROM ltbp
*                 INTO @DATA(ls_ltbp)
*                 WHERE tbnum EQ @lv_tbnum
*                   AND elikz EQ ' '.

SELECT LGNUM ,
 TBNUM , TBPOS , ELIKZ , MATNR , WERKS , CHARG , MENGE , MEINS , TAMEN , MBPOS , LGORT FROM LTBP INTO @DATA(LS_LTBP) UP TO 1 ROWS WHERE TBNUM EQ @LV_TBNUM AND ELIKZ EQ ' '
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


        SELECT SINGLE * FROM t333
          INTO @DATA(ls_t333) WHERE lgnum EQ @ls_zwm_config-lgnum
                                AND bwlvs EQ @ls_zwm_config-bwlvs.

        IF gt_su IS NOT INITIAL.
          SELECT aufnr,
                 auart,
                 werks
            FROM aufk
            INTO TABLE @DATA(lt_aufk)
            FOR ALL ENTRIES IN @gt_su
            WHERE aufnr EQ @gt_su-aufnr.
        ENDIF.

        LOOP AT gt_su INTO gs_su.
          wa_trite-tbpos = ls_ltbp-tbpos.
          wa_trite-altme = gs_su-meins.
          wa_trite-charg = gs_su-charg.

          " Destination
          READ TABLE lt_aufk INTO DATA(ls_aufk) WITH KEY aufnr = gs_su-aufnr.
          IF sy-subrc IS INITIAL.
            SELECT SINGLE i_storagetyp
              FROM zwm_config INTO wa_trite-nltyp
              WHERE werks EQ gs_su-werks
                AND auart EQ ls_aufk-auart.
            wa_trite-nlber = '001'.
          ENDIF.

          " Source
          wa_trite-vltyp = ls_t333-vltyp.
          wa_trite-vlber = '001'.

          wa_trite-nlenr = gs_su-lenum.
          wa_trite-letyp = gs_su-su_unit.
          wa_trite-anfme = gs_su-su_qty. "qty

          APPEND wa_trite TO it_trite.
          CLEAR wa_trite.

          ls_su-lenum = gs_su-lenum.
          ls_su-tanum = gs_su-tanum.
          ls_su-lety1 = gs_su-su_unit.
          ls_su-lgpla = gs_elements-lgpla.
          ls_su-werks = gs_su-werks.
          ls_su-solex = gs_su-su_qty.
          READ TABLE lt_aufk INTO ls_aufk WITH KEY aufnr = gs_su-aufnr.
          IF sy-subrc IS INITIAL.
            ls_su-auart = ls_aufk-auart.
          ENDIF.
          APPEND ls_su TO lt_su.
          CLEAR:ls_su.
        ENDLOOP.

        IF it_trite IS NOT INITIAL.
          CALL FUNCTION 'L_TO_CREATE_TR'
            EXPORTING
              i_lgnum                        = ls_ltbp-lgnum
              i_tbnum                        = ls_ltbp-tbnum
              i_commit_work                  = 'X'
              i_bname                        = sy-uname
              it_trite                       = it_trite
            IMPORTING
              e_tanum                        = lv_tanum
              e_teilk                        = lv_teilv
            TABLES
              t_ltak                         = it_ltak
              t_ltap_vb                      = it_ltap_vb
            EXCEPTIONS
              foreign_lock                   = 1
              qm_relevant                    = 2
              tr_completed                   = 3
              xfeld_wrong                    = 4
              ldest_wrong                    = 5
              drukz_wrong                    = 6
              tr_wrong                       = 7
              squit_forbidden                = 8
              no_to_created                  = 9
              update_without_commit          = 10
              no_authority                   = 11
              preallocated_stock             = 12
              partial_transfer_req_forbidden = 13
              input_error                    = 14
              OTHERS                         = 15.
        ENDIF.
        IF sy-subrc = 0.
          CLEAR it_trite.
***********************************************************
*BDC for confirming created TO.
***********************************************************
          PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'LTAK-TANUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'LTAK-TANUM'
                                         lv_tanum.
          PERFORM bdc_field       USING 'LTAK-LGNUM'
                                         ls_ltbp-lgnum.

          PERFORM bdc_dynpro      USING 'SAPML03T' '0114'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=QU'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BU'.

          CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.

          WAIT UP TO 1 SECONDS.

          IF lt_su IS NOT INITIAL.
            SELECT tanum
                   tapos
              FROM ltap
              INTO CORRESPONDING FIELDS OF TABLE lt_ltap_can
              FOR ALL ENTRIES IN lt_su
              WHERE lgnum EQ ls_ltbp-lgnum
                AND tanum EQ lt_su-tanum
                AND nlenr EQ lt_su-lenum.

            READ TABLE lt_ltap_can INTO DATA(ls_ltap_can) INDEX 1. "#EC CI_NOORDER
            p_lgnum = ls_ltbp-lgnum.

            CALL FUNCTION 'L_TO_CANCEL'
              EXPORTING
                i_lgnum                      = ls_ltbp-lgnum
                i_tanum                      = ls_ltap_can-tanum
                i_cancl                      = 'X'
                i_qname                      = sy-uname
                i_commit_work                = 'X'
              TABLES
                t_ltap_cancl                 = lt_ltap_can
              EXCEPTIONS
                to_confirmed                 = 1
                to_doesnt_exist              = 2
                item_confirmed               = 3
                item_doesnt_exist            = 4
                foreign_lock                 = 5
                double_lines                 = 6
                nothing_to_do                = 7
                xfeld_wrong                  = 8
                su_movement_partly_confirmed = 9
                update_without_commit        = 10
                no_authority                 = 11
                OTHERS                       = 12.
            IF sy-subrc <> 0.
* Implement suitable error handling here
            ENDIF.
          ENDIF.

          WAIT UP TO 1 SECONDS.
          PERFORM move_su.

*----------<< Start | Dispatch process change | by srimathi | 12.08.2024 | DEVK944530 >>-------$

          IF gs_su-palletno IS NOT INITIAL AND gs_su-lenum IS NOT INITIAL.
            DATA: lv_warehouse_type TYPE zwm_de_warehouse_type VALUE 'Plant'.

            SELECT COUNT(*) FROM zwm_plant_config WHERE plant = gs_su-werks.
            IF sy-subrc = 0.

              CALL FUNCTION 'ZWM_FM_PALLETIZATION'
                EXPORTING
                  iv_warehouse_type = lv_warehouse_type
                  iv_warehouse_no   = ls_ltbp-lgnum
                  iv_pallet_no      = gs_su-palletno
                  iv_su_no          = gs_su-lenum
                  iv_method         = 'PALLET_PUTWAY'.
            ENDIF.

          ENDIF.

*-----------<< End | Dispatch process change | by srimathi | 12.08.2024 | DEVK944530 >>--------$

          CLEAR lv_tanum.
        ENDIF.
      ELSE.
        REFRESH:lt_item,
              lt_ret,
              it_trite,
              it_ltap_vb,
              it_ltak,
              lt_ltap_can,
              it_bdcdata,
              lt_su,
              gt_su,
              lt_aufk.

        CLEAR:ls_su,
              lv_tanum,
              lv_teilv,
              wa_trite,
              ls_item,
              ls_head,
              lv_gmcd,
              ls_doc,
              lv_auart,
              ls_zwm_config,
              ls_ret,
              ls_ltbp,
              ls_t333,
              gv_lgnum,
              gs_elements,
              wa_bdcdata,
              p_lgnum,
              p_qty.

        lv_msg1 = 'Goods movement error'.
        EXIT.
      ENDIF.

      REFRESH:lt_item,
              lt_ret,
              it_trite,
              it_ltap_vb,
              it_ltak,
              lt_ltap_can,
              it_bdcdata,
              lt_su,
              gt_su,
              lt_aufk.

      CLEAR:ls_su,
            lv_tanum,
            lv_teilv,
            wa_trite,
            ls_item,
            ls_head,
            lv_gmcd,
            ls_doc,
            lv_auart,
            ls_zwm_config,
            ls_ret,
            ls_ltbp,
            ls_t333,
            gv_lgnum,
            gs_elements,
            wa_bdcdata,
            p_lgnum,
            p_qty.

      CLEAR: lv_msg1.

    WHEN 'BACK'.
      REFRESH:lt_item,
              lt_ret,
              it_trite,
              it_ltap_vb,
              it_ltak,
              lt_ltap_can,
              it_bdcdata,
              lt_su,
              gt_su,
              lt_aufk.

      CLEAR:ls_su,
            lv_tanum,
            lv_teilv,
            wa_trite,
            ls_item,
            ls_head,
            lv_gmcd,
            ls_doc,
            lv_auart,
            ls_zwm_config,
            ls_ret,
            ls_ltbp,
            ls_t333,
            gv_lgnum,
            gs_elements,
            wa_bdcdata,
            p_lgnum,
            p_qty.

      CLEAR: lv_msg1.

      SET SCREEN 0.
      LEAVE SCREEN.
    WHEN 'CLEAR'.
      REFRESH:lt_item,
              lt_ret,
              it_trite,
              it_ltap_vb,
              it_ltak,
              lt_ltap_can,
              it_bdcdata,
              lt_su,
              gt_su,
              lt_aufk.

      CLEAR:ls_su,
            lv_tanum,
            lv_teilv,
            wa_trite,
            ls_item,
            ls_head,
            lv_gmcd,
            ls_doc,
            lv_auart,
            ls_zwm_config,
            ls_ret,
            ls_ltbp,
            ls_t333,
            gv_lgnum,
            gs_elements,
            wa_bdcdata,
            p_lgnum,
            p_qty.
      CLEAR: lv_msg1.
  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_BIN  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_bin INPUT.
  CLEAR:lv_msg1.

  SELECT SINGLE * FROM lagp
    INTO @DATA(ls_lagp)
    WHERE lgnum EQ @gv_lgnum
      AND lgpla EQ @gs_elements-lgpla
      AND skzue EQ ''.
  IF ls_lagp IS INITIAL.
*     lv_msg1 = 'Stock missing in SF01'.
    lv_msg1 = 'Invalid Bin no'.
    CLEAR:gs_elements-lgpla .        "24-08-2024 Uncomment
*    EXIT.                           " Commented on 20.01.2025
    LEAVE TO SCREEN 9001.            " Added on 20.01.2025
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_PALLETNO  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_palletno INPUT.

  CLEAR:lv_msg1,p_qty.
  SELECT * FROM zwm_su
    INTO TABLE gt_su
    WHERE palletno  EQ gs_elements-palletno
      AND pal_print EQ abap_true.
  IF gt_su IS INITIAL.
    lv_msg1 = 'Invalid Pallet no'.
    CLEAR:gs_elements-palletno.
*    EXIT.                           " Commented on 20.01.2025
    LEAVE TO SCREEN 9001.            " Added on 20.01.2025
  ENDIF.

  REFRESH:gt_su.
  SELECT * FROM zwm_su
    INTO TABLE gt_su
    WHERE palletno  EQ gs_elements-palletno
      AND pal_print EQ abap_true
      AND p_ind     EQ abap_false.
  IF gt_su IS INITIAL.
    lv_msg1 = 'Pallet is placed'.
    CLEAR:gs_elements-palletno.
*    EXIT.                  " Commented on 20.01.2025
    LEAVE TO SCREEN 9001.   " Added on 20.01.2025
  ENDIF.

  DATA(lt_tmp) = gt_su.
  READ TABLE gt_su INTO DATA(gs_tmp) INDEX 1.  "#EC CI_NOORDER
  gs_elements-matnr = gs_tmp-matnr.
  gs_elements-charg = gs_tmp-charg.
  SELECT SINGLE maktx INTO gs_elements-maktx
    FROM makt WHERE matnr EQ gs_tmp-matnr
                AND spras EQ sy-langu.
  SORT lt_tmp BY lenum ASCENDING.
  READ TABLE lt_tmp INTO gs_tmp INDEX 1.
  gs_elements-lenumf = gs_tmp-lenum.

  SORT lt_tmp BY lenum DESCENDING.
  READ TABLE lt_tmp INTO gs_tmp INDEX 1.
  gs_elements-lenumt = gs_tmp-lenum.

  LOOP AT gt_su INTO DATA(ls_pal).
    p_qty = p_qty + ls_pal-su_qty.
  ENDLOOP.

  SELECT SINGLE clabs FROM mchb
    INTO @DATA(lv_clabs)
      WHERE matnr EQ @ls_pal-matnr
        AND werks EQ @ls_pal-werks
        AND lgort EQ 'SF01'
        AND charg EQ @ls_pal-charg.

  IF p_qty GT lv_clabs.
    lv_msg1 = 'Insufficient stock'.
*    lv_msg1 = 'Insufficient stock'.
    CLEAR:gs_elements-palletno.
*    EXIT.                          " Commented on 20.01.2025
    LEAVE TO SCREEN 9001.           " Added on 20.01.2025
  ENDIF.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*  SELECT SINGLE lgnum FROM ltak
*    INTO gv_lgnum
*    WHERE tanum EQ ls_pal-tanum.

SELECT LGNUM FROM LTAK
 INTO GV_LGNUM UP TO 1 ROWS WHERE TANUM EQ LS_PAL-TANUM
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


ENDMODULE.

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  MOVE_SU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM move_su .
  DATA:lv_tanum        TYPE ltak-tanum,
       lt_ltap_move_su TYPE STANDARD TABLE OF ltap_move_su,
       lt_ltak_vb      TYPE STANDARD TABLE OF ltak_vb,
       lt_ltap_vb      TYPE STANDARD TABLE OF ltap_vb,
       lv_nltyp        TYPE ltap-nltyp,
       lv_nlber        TYPE ltap-nlber.

  LOOP AT lt_su INTO ls_su.
    SELECT SINGLE i_storagetyp f_storagetyp
      FROM zwm_config INTO (lv_nltyp,lv_nlber)
      WHERE werks EQ ls_su-werks
        AND auart EQ ls_su-auart.

    CALL FUNCTION 'L_TO_CREATE_MOVE_SU'
      EXPORTING
        i_lenum               = ls_su-lenum
        i_bwlvs               = '999'
        i_nltyp               = lv_nlber
        i_nlber               = '001'
        i_nlpla               = ls_su-lgpla
        i_letyp               = ls_su-lety1
        i_commit_work         = 'X'
        i_bname               = sy-uname
        i_solex               = ls_su-solex
      IMPORTING
        e_tanum               = lv_tanum
      TABLES
        t_ltap_move_su        = lt_ltap_move_su
        t_ltak                = lt_ltak_vb
        t_ltap_vb             = lt_ltap_vb
      EXCEPTIONS
        not_confirmed_to      = 1
        foreign_lock          = 2
        bwlvs_wrong           = 3
        betyp_wrong           = 4
        nltyp_wrong           = 5
        nlpla_wrong           = 6
        nltyp_missing         = 7
        nlpla_missing         = 8
        squit_forbidden       = 9
        lgber_wrong           = 10
        xfeld_wrong           = 11
        drukz_wrong           = 12
        ldest_wrong           = 13
        no_stock_on_su        = 14
        su_not_found          = 15
        update_without_commit = 16
        no_authority          = 17
        benum_required        = 18
        ltap_move_su_wrong    = 19
        lenum_wrong           = 20
        OTHERS                = 21.
    IF sy-subrc EQ 0.
      UPDATE zwm_su SET f_ind = abap_true
                        p_ind = abap_true WHERE lenum EQ ls_su-lenum.

      REFRESH:it_bdcdata.

      PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'LTAK-TANUM'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'LTAK-TANUM'
                                     lv_tanum.
      PERFORM bdc_field       USING 'LTAK-LGNUM'
                                     p_lgnum.
      PERFORM bdc_field       USING 'RL03T-DUNKL'
                                    'H'.
      PERFORM bdc_field       USING 'RL03T-QENTR'
                                    'X'.
      PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'LTAK-LGNUM'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=BU'.

      CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.

    ENDIF.

  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Module  STATUS_9001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9001 OUTPUT.

*  IF gs_elements-lgpla IS INITIAL.
*    SELECT SINGLE lgnum FROM lrf_wkqu INTO @DATA(lv_lgnum) WHERE bname = @sy-uname.
*    IF sy-subrc = 0.
*      SELECT SINGLE f_storagetyp FROM  zwm_config INTO @DATA(lv_strgtyp) WHERE lgnum = @lv_lgnum.
*      IF sy-subrc = 0.
*        SELECT lgpla FROM lagp INTO TABLE @DATA(lv_lagp) WHERE lgnum = @lv_lgnum AND lgtyp = @lv_strgtyp AND anzqu = 0.
*        READ TABLE lv_lagp INTO DATA(lw_lagp) INDEX 1.
*        IF sy-subrc = 0.
*          gs_elements-lgpla = lw_lagp.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.


  LOOP AT SCREEN.
    CASE screen-group1.
      WHEN 'PAL'.
        IF gs_elements-palletno IS NOT INITIAL.
          screen-input = 0.
          MODIFY SCREEN.
        ENDIF.
      WHEN 'BIN'.
        IF gs_elements-lgpla IS NOT INITIAL.
          screen-input = 1.
          MODIFY SCREEN.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDLOOP.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_DATA  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  VALIDATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate CHANGING error TYPE char01.

  CLEAR:lv_msg1.

*  SELECT SINGLE auart FROM aufk INTO @DATA(lv_auart)
*               WHERE aufnr EQ @gs_su-aufnr.

  IF gt_su[] IS NOT INITIAL.

    READ TABLE gt_su INTO DATA(ls_su) INDEX 1.  "#EC CI_NOORDER
    IF sy-subrc = 0.
      SELECT SINGLE * FROM zwm_config
   INTO @DATA(ls_zwm_config)
   WHERE werks EQ @ls_su-werks
     AND auart EQ @ls_su-auart.
    ENDIF.
    IF sy-subrc IS NOT INITIAL OR ls_zwm_config-f_storagetyp = ''.
      lv_msg1 = 'Pls check ZWM_CONFIG'.
      error = 'E'.
      RETURN.
    ENDIF.
  ENDIF.

  SELECT SINGLE * FROM lagp
    INTO @DATA(ls_lagp)
    WHERE lgnum EQ @gv_lgnum
      AND lgtyp EQ @ls_zwm_config-f_storagetyp
      AND lgpla EQ @gs_elements-lgpla
      AND skzue EQ ''.
  IF ls_lagp IS INITIAL.
    lv_msg1 = 'Invalid Bin no'.
    CLEAR:gs_elements-lgpla.        "24-08-2024 Uncomment
    error = 'E'.
    RETURN.
  ENDIF.


  CLEAR:lv_msg1,p_qty.
  SELECT * FROM zwm_su
    INTO TABLE gt_su
    WHERE palletno  EQ gs_elements-palletno
      AND pal_print EQ abap_true.
  IF gt_su IS INITIAL.
    lv_msg1 = 'Invalid Pallet no'.
    CLEAR:gs_elements-palletno.
    error = 'E'.
    RETURN.
  ENDIF.

  SELECT * FROM zwm_su
  INTO TABLE @DATA(lt_su)
  WHERE palletno  EQ @gs_elements-palletno
    AND pal_print EQ @abap_true
    AND p_ind     EQ @abap_false.
  IF lt_su IS INITIAL.
    lv_msg1 = 'Pallet is placed'.
    CLEAR:gs_elements-palletno.
    error = 'E'.
    RETURN.
  ENDIF.

  SELECT SINGLE clabs FROM mchb
    INTO @DATA(lv_clabs)
      WHERE matnr EQ @ls_pal-matnr
        AND werks EQ @ls_pal-werks
        AND lgort EQ 'SF01'
        AND charg EQ @ls_pal-charg.

  IF p_qty GT lv_clabs.
    lv_msg1 = 'Insufficient stock'.
    CLEAR:gs_elements-palletno.
    error = 'E'.
    RETURN.
  ENDIF.


ENDFORM.
