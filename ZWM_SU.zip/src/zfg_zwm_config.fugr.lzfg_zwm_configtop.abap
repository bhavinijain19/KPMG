FUNCTION-POOL ZFG_ZWM_CONFIG             MESSAGE-ID SV.

* INCLUDE LZFG_ZWM_CONFIGD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_ZWM_CONFIGT00                      . "view rel. data dcl.
