*&---------------------------------------------------------------------*
*& Report  ZWM_TO_POST
*&
*&---------------------------------------------------------------------*
REPORT zwm_to_confirm.

*&---------------------------------------------------------------------*
*&  Include           ZWM_TO_POST_TOP
*&---------------------------------------------------------------------*
TYPE-POOLS: slis,
            icon.

TYPES:BEGIN OF ty_t300t,
        lgnum TYPE lgnum,
        lnumt TYPE lvs_lnumt,
      END OF ty_t300t,

      BEGIN OF ty_ltbk1,
        lgnum TYPE lgnum,
        tbnum	TYPE tbnum,
      END OF ty_ltbk1,

      BEGIN OF ty_final,
        checkbox TYPE c,
        tbnum    TYPE tbnum,
        tbpos	   TYPE tbpos,
        trart	   TYPE lvs_trart,
        matnr    TYPE matnr,
        maktx    TYPE maktx,
        mblnr	   TYPE mblnr,
        mbpos    TYPE mblpo,
        werks	   TYPE werks_d,
        lgort	   TYPE lgort_d,
        charg	   TYPE charg_d,
        menge    TYPE ltbp-menge,
        meins	   TYPE meins,
        tamen	   TYPE ltbp_tamen,
        tamen1   TYPE ltbp_tamen,
        lgpla	   TYPE lgpla,
        zsu_no   TYPE	lenum,
        zsu_no1  TYPE lenum,
        lety1	   TYPE lvs_letyp1,
      END OF ty_final,

      BEGIN OF ty_su,
        lenum TYPE lenum,
        lety1 TYPE lvs_letyp1,
        lgpla	TYPE lgpla,
        auart	TYPE auart,
        werks	TYPE werks_d,
        solex	TYPE ltak-solex,
        tanum	TYPE ltak-tanum,
      END OF ty_su.

DATA:it_t300t       TYPE STANDARD TABLE OF ty_t300t,
     it_ltbk1       TYPE STANDARD TABLE OF ty_ltbk1,
     it_final       TYPE STANDARD TABLE OF ty_final,
     it_ltap_vb     TYPE STANDARD TABLE OF ltap_vb,
     it_ltak        TYPE STANDARD TABLE OF ltak_vb,
     it_trite       TYPE STANDARD TABLE OF l03b_trite,
     lt_ltap_can    TYPE STANDARD TABLE OF ltap_cancl,
     gt_dynpfields  TYPE TABLE OF dynpread,
     it_bdcdata     TYPE TABLE OF bdcdata,
     lt_su          TYPE TABLE OF ty_su,
     gv_nos_su      TYPE n LENGTH 3,
     gv_count       TYPE n LENGTH 3,
     ls_su          TYPE ty_su,
     wa_final       TYPE ty_final,
     gwa_dynpfields TYPE dynpread,
     it_fldcat      TYPE  lvc_t_fcat,
     gv_lbnum       TYPE lgnum,
     wa_trite       TYPE  l03b_trite,
     rt_extab       TYPE slis_t_extab,
     r_ucomm        LIKE sy-ucomm,
     rs_selfield    TYPE slis_selfield,
     gv_tanum       TYPE ltak-tanum,
     gv_teilv       TYPE t340d-teilv,
     execute        TYPE n VALUE 0,
     it_layout      TYPE lvc_s_layo,
     wa_bdcdata     TYPE bdcdata.

FIELD-SYMBOLS:<fs_fldcat> TYPE lvc_s_fcat.

SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-020.
PARAMETERS : p_lgnum TYPE lgnum OBLIGATORY,
             p_tbnum TYPE tbnum OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_lgnum.
  PERFORM p_lgnum.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_tbnum.
  PERFORM p_tbnum.

AT SELECTION-SCREEN OUTPUT.

  IF execute EQ 1.
    execute = 0.
    CLEAR : p_lgnum,p_tbnum.
  ENDIF.

INITIALIZATION.
  execute = 1.

START-OF-SELECTION.

  SELECT lgnum,
         tbnum,
         statu,
         trart,
         mblnr
    FROM ltbk
    INTO TABLE @DATA(it_ltbk)
    WHERE lgnum EQ @p_lgnum
      AND tbnum EQ @p_tbnum
      AND ( statu EQ 'T' OR statu EQ ' ' ).
  IF it_ltbk IS NOT INITIAL.
    SORT it_ltbk BY lgnum.
    SELECT lgnum,
           tbnum,
           tbpos,
           elikz,
           matnr,
           werks,
           charg,
           menge,
           meins,
           tamen,
           mbpos,
           lgort
      FROM ltbp
      INTO TABLE @DATA(it_ltbp)
      FOR ALL ENTRIES IN @it_ltbk
      WHERE lgnum EQ @it_ltbk-lgnum
        AND tbnum EQ @it_ltbk-tbnum
        AND elikz EQ ' '.
    IF sy-subrc EQ 0.
      SORT it_ltbp BY lgnum tbnum.
    ENDIF.
  ELSE.
    MESSAGE 'No data found for given selection' TYPE 'S'.
    EXIT.
  ENDIF.

  IF it_ltbp IS NOT INITIAL.
    SELECT * FROM zwm_su
      INTO TABLE @DATA(lt_zwm_su)
      FOR ALL ENTRIES IN @it_ltbp
      WHERE matnr  EQ @it_ltbp-matnr
        AND charg  EQ @it_ltbp-charg
        AND pprint EQ @abap_true
        AND f_ind  EQ @abap_false.
    SORT lt_zwm_su BY lenum.

    SELECT matnr,
           maktx
      FROM makt
      INTO TABLE @DATA(it_makt)
      FOR ALL ENTRIES IN @it_ltbp
      WHERE matnr EQ @it_ltbp-matnr.
    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.

    DATA(it_ltbp_temp) = it_ltbp.
    SORT it_ltbp_temp BY lgnum tbnum tbpos.
    DELETE ADJACENT DUPLICATES FROM it_ltbp_temp COMPARING lgnum tbnum tbpos.

    SELECT matnr,
           lgnum,
           lety1
      FROM mlgn
      INTO TABLE @DATA(it_mlgn)
      FOR ALL ENTRIES IN @it_ltbp_temp
      WHERE matnr EQ @it_ltbp_temp-matnr
        AND lgnum EQ @p_lgnum.
  ENDIF.

  LOOP AT it_ltbp INTO DATA(wa_ltbp).

    wa_final-tbpos = wa_ltbp-tbpos.
    wa_final-matnr = wa_ltbp-matnr.
    wa_final-mbpos = wa_ltbp-mbpos.
    wa_final-werks = wa_ltbp-werks.
    wa_final-lgort = wa_ltbp-lgort.
    wa_final-charg = wa_ltbp-charg.
    wa_final-meins =  wa_ltbp-meins.
    wa_final-menge = wa_ltbp-menge.
    wa_final-tamen = wa_ltbp-menge - wa_ltbp-tamen.

    READ TABLE it_mlgn INTO DATA(wa_mlgn) WITH KEY matnr = wa_ltbp-matnr lgnum = p_lgnum.
    IF sy-subrc EQ 0.
      wa_final-lety1 = wa_mlgn-lety1.
    ENDIF.

    READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = wa_ltbp-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-maktx = wa_makt-maktx.
    ENDIF.

    READ TABLE it_ltbk INTO DATA(wa_ltbk) WITH KEY lgnum = p_lgnum
                                             tbnum = p_tbnum BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-tbnum = wa_ltbk-tbnum.
      wa_final-mblnr = wa_ltbk-mblnr.
      wa_final-trart = wa_ltbk-trart.
    ENDIF.

    CLEAR:gv_count,gv_nos_su.

    LOOP AT lt_zwm_su INTO DATA(ls_zwm_su) WHERE matnr = wa_final-matnr
                                             AND charg = wa_final-charg.

      gv_count = gv_count + 1.
      gv_nos_su = wa_final-menge / ls_zwm_su-su_qty.
      IF gv_count GT gv_nos_su.
        EXIT.
      ENDIF.
      IF gv_count EQ 1.
        wa_final-zsu_no  = ls_zwm_su-lenum.
      ELSE.
        wa_final-zsu_no1 = ls_zwm_su-lenum.
      ENDIF.
    ENDLOOP.

*      READ TABLE lt_zwm_su INTO DATA(ls_zwm_su) INDEX 1.
*      IF sy-subrc IS INITIAL.
*        wa_final-zsu_no = ls_zwm_su-lenum.
*      ENDIF.
*
*      DESCRIBE TABLE lt_zwm_su LINES DATA(lv_rows).
*      READ TABLE lt_zwm_su INTO ls_zwm_su INDEX lv_rows.
*      IF sy-subrc IS INITIAL.
*        wa_final-zsu_no1 = ls_zwm_su-lenum.
*      ENDIF.

    APPEND wa_final TO it_final.
    CLEAR wa_final.
  ENDLOOP.

  PERFORM build_alv.
  PERFORM alv_report_layout.
  PERFORM set_pf_status USING rt_extab .
  PERFORM frm_usercommand USING r_ucomm rs_selfield.
  PERFORM display_alv.

**&      Form  P_LGNUM
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
FORM p_lgnum.
  CLEAR:p_lgnum,
        it_t300t.

  SELECT lgnum
         lnumt
    FROM t300t
    INTO TABLE it_t300t
    WHERE spras = sy-langu.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'LGNUM'
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'P_LGNUM'
      value_org       = 'S'
    TABLES
      value_tab       = it_t300t
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  P_TBNUM
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
FORM p_tbnum.
  CLEAR:p_tbnum,gwa_dynpfields.

  REFRESH:gt_dynpfields.

  gwa_dynpfields-fieldname = 'P_LGNUM'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname               = sy-repid
      dynumb               = sy-dynnr
    TABLES
      dynpfields           = gt_dynpfields
    EXCEPTIONS
      invalid_abapworkarea = 1
      invalid_dynprofield  = 2
      invalid_dynproname   = 3
      invalid_dynpronummer = 4
      invalid_request      = 5
      no_fielddescription  = 6
      invalid_parameter    = 7
      undefind_error       = 8
      double_conversion    = 9
      stepl_not_found      = 10
      OTHERS               = 11.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_lbnum.
  READ TABLE gt_dynpfields INTO gwa_dynpfields WITH KEY fieldname = 'P_LGNUM'.
  IF sy-subrc = 0.
    gv_lbnum = gwa_dynpfields-fieldvalue.
  ENDIF.

  CLEAR it_ltbk1.

  SELECT lgnum
         tbnum
    FROM ltbk
    INTO TABLE it_ltbk1
    WHERE lgnum = gv_lbnum
      AND ( statu = 'T' OR statu = ' ' ).

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'TBNUM'
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'P_TBNUM'
      value_org       = 'S'
    TABLES
      value_tab       = it_ltbk1
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_alv.
  FREE it_fldcat[].
  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'CHECKBOX'.
  <fs_fldcat>-coltext   = text-016.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-checkbox = 'X'.
  <fs_fldcat>-icon = 'X'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TBNUM'.
  <fs_fldcat>-coltext   = text-001.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TBPOS'.
  <fs_fldcat>-coltext   = text-002.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TRART'.
  <fs_fldcat>-coltext   = text-003.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MATNR'.
  <fs_fldcat>-coltext   = text-004.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MAKTX'.
  <fs_fldcat>-coltext   = text-005.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MBLNR'.
  <fs_fldcat>-coltext   = text-006.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MBPOS'.
  <fs_fldcat>-coltext   = text-007.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'WERKS'.
  <fs_fldcat>-coltext   = text-008.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'T001W'.
  <fs_fldcat>-ref_field = 'WERKS'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'LGORT'.
  <fs_fldcat>-coltext   = text-009.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'T001L'.
  <fs_fldcat>-ref_field = 'LGORT'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'CHARG'.
  <fs_fldcat>-coltext   = text-010.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MENGE'.
  <fs_fldcat>-coltext   = text-011.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MEINS'.
  <fs_fldcat>-coltext   = text-012.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TAMEN'.
  <fs_fldcat>-coltext   = text-014.
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'LGPLA'.
  <fs_fldcat>-coltext   = text-013.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-ref_table = 'LAGP'.
  <fs_fldcat>-ref_field = 'LGPLA'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname = 'ZSU_NO'.
  <fs_fldcat>-coltext   = text-017.
  <fs_fldcat>-outputlen = '10'.
  <fs_fldcat>-tabname   = 'IT_FINAL'.
  <fs_fldcat>-edit      = 'X'.
  <fs_fldcat>-ref_table = 'ZMM_SU_NUMBER'.
  <fs_fldcat>-ref_field = 'ZSU_NO'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname = 'ZSU_NO1'.
  <fs_fldcat>-coltext   = text-018.
  <fs_fldcat>-outputlen = '10'.
  <fs_fldcat>-edit      = 'X'.
  <fs_fldcat>-tabname   = 'IT_FINAL'.
  <fs_fldcat>-ref_table = 'ZMM_SU_NUMBER'.
  <fs_fldcat>-ref_field = 'ZSU_NO'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv .
  IF it_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
      EXPORTING
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'SET_PF_STATUS'
        i_callback_user_command  = 'FRM_USERCOMMAND'
        is_layout_lvc            = it_layout
        it_fieldcat_lvc          = it_fldcat[]
        i_save                   = 'A'
      TABLES
        t_outtab                 = it_final[]
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  TO_POST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  ALV_REPORT_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_report_layout.
  it_layout-cwidth_opt = abap_true.
  it_layout-zebra      = abap_true.
  it_layout-col_opt    = abap_true.
ENDFORM.

FORM set_pf_status USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'ZWM_TO_CONFIRM'.
ENDFORM.

FORM frm_usercommand USING r_ucomm     LIKE sy-ucomm
                           rs_selfield TYPE slis_selfield.

  DATA:gd_repid  LIKE sy-repid,
       lv_nos_su TYPE n LENGTH 3,
       lv_count  TYPE n LENGTH 3,
       ref_grid  TYPE REF TO cl_gui_alv_grid.

  CASE r_ucomm.
    WHEN 'BACK' OR 'EXIT' OR 'CANCEL'.
      LEAVE LIST-PROCESSING.
    WHEN 'CONFIRM'.
      IF ref_grid IS INITIAL.
        CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
          IMPORTING
            e_grid = ref_grid.
      ENDIF.
      IF NOT ref_grid IS INITIAL.
        CALL METHOD ref_grid->check_changed_data .
      ENDIF.

      READ TABLE lt_zwm_su INTO ls_zwm_su INDEX 1.

      SELECT SINGLE auart FROM aufk INTO @DATA(lv_auart)
        WHERE aufnr EQ @ls_zwm_su-aufnr.

      SELECT SINGLE * FROM zwm_config
        INTO @DATA(ls_zwm_config)
        WHERE werks EQ @ls_zwm_su-werks
          AND auart EQ @lv_auart.
      IF sy-subrc IS NOT INITIAL.
        CONCATENATE 'Plant' ls_zwm_su-werks 'and order type' lv_auart 'is not maintained in ZWM_CONFIG'
         INTO DATA(lv_msg) SEPARATED BY space.
        MESSAGE lv_msg TYPE 'S'.
        EXIT.
      ENDIF.

      SELECT SINGLE * FROM t333
        INTO @DATA(ls_t333) WHERE lgnum EQ @ls_zwm_config-lgnum
                              AND bwlvs EQ @ls_zwm_config-bwlvs.

      IF lt_zwm_su IS NOT INITIAL.
        SELECT aufnr,
               auart,
               werks
          FROM aufk
          INTO TABLE @DATA(lt_aufk)
          FOR ALL ENTRIES IN @lt_zwm_su
          WHERE aufnr EQ @lt_zwm_su-aufnr.
      ENDIF.

      LOOP AT it_final INTO wa_final  WHERE checkbox = 'X'.
        CLEAR:lv_nos_su.
        LOOP AT lt_zwm_su INTO ls_zwm_su WHERE matnr = wa_final-matnr
                                           AND charg = wa_final-charg.

          lv_count = lv_count + 1.
          lv_nos_su = wa_final-menge / ls_zwm_su-su_qty.
          IF lv_count GT lv_nos_su.
            EXIT.
          ENDIF.

          wa_trite-tbpos = wa_final-tbpos.
          wa_trite-altme = wa_final-meins.
          wa_trite-charg = wa_final-charg.

          " Destination
          READ TABLE lt_aufk INTO DATA(ls_aufk) WITH KEY aufnr = ls_zwm_su-aufnr.
          IF sy-subrc IS INITIAL.
            SELECT SINGLE i_storagetyp
              FROM zwm_config INTO wa_trite-nltyp
              WHERE werks EQ wa_final-werks
                AND auart EQ ls_aufk-auart.
            wa_trite-nlber = '001'.
          ENDIF.

          " Source
          wa_trite-vltyp = ls_t333-vltyp.
          wa_trite-vlber = '001'.

          wa_trite-nlenr = ls_zwm_su-lenum.
          wa_trite-letyp = ls_zwm_su-su_unit.
          wa_trite-anfme = ls_zwm_su-su_qty. "qty

          APPEND wa_trite TO it_trite.
          CLEAR wa_trite.

          ls_su-lenum = ls_zwm_su-lenum.
          ls_su-tanum = ls_zwm_su-tanum.
          ls_su-lety1 = ls_zwm_su-su_unit.
          ls_su-lgpla = wa_final-lgpla.
          ls_su-werks = wa_final-werks.
          ls_su-solex = ls_zwm_su-su_qty.
          READ TABLE lt_aufk INTO ls_aufk WITH KEY aufnr = ls_zwm_su-aufnr.
          IF sy-subrc IS INITIAL.
            ls_su-auart = ls_aufk-auart.
          ENDIF.
          APPEND ls_su TO lt_su.
          CLEAR:ls_su.
        ENDLOOP.

        CALL FUNCTION 'L_TO_CREATE_TR'
          EXPORTING
            i_lgnum                        = p_lgnum
            i_tbnum                        = p_tbnum
            i_commit_work                  = 'X'
            i_bname                        = sy-uname
            it_trite                       = it_trite
          IMPORTING
            e_tanum                        = gv_tanum
            e_teilk                        = gv_teilv
          TABLES
            t_ltak                         = it_ltak
            t_ltap_vb                      = it_ltap_vb
          EXCEPTIONS
            foreign_lock                   = 1
            qm_relevant                    = 2
            tr_completed                   = 3
            xfeld_wrong                    = 4
            ldest_wrong                    = 5
            drukz_wrong                    = 6
            tr_wrong                       = 7
            squit_forbidden                = 8
            no_to_created                  = 9
            update_without_commit          = 10
            no_authority                   = 11
            preallocated_stock             = 12
            partial_transfer_req_forbidden = 13
            input_error                    = 14
            OTHERS                         = 15.

        IF sy-subrc = 0.
***********************************************************
*BDC for confirming created TO.
***********************************************************
          PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'LTAK-TANUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'LTAK-TANUM'
                                         gv_tanum.
          PERFORM bdc_field       USING 'LTAK-LGNUM'
                                         p_lgnum.

          PERFORM bdc_dynpro      USING 'SAPML03T' '0114'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=QU'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BU'.

          CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.

          WAIT UP TO 1 SECONDS.

          IF lt_su IS NOT INITIAL.
            SELECT tanum
                   tapos
              FROM ltap
              INTO CORRESPONDING FIELDS OF TABLE lt_ltap_can
              FOR ALL ENTRIES IN lt_su
              WHERE lgnum EQ p_lgnum
                AND tanum EQ lt_su-tanum
                AND nlenr EQ lt_su-lenum.

            READ TABLE lt_ltap_can INTO DATA(ls_ltap_can) INDEX 1. "#EC CI_NOORDER

            CALL FUNCTION 'L_TO_CANCEL'
              EXPORTING
                i_lgnum                      = p_lgnum
                i_tanum                      = ls_ltap_can-tanum
                i_cancl                      = 'X'
                i_qname                      = sy-uname
                i_commit_work                = 'X'
              TABLES
                t_ltap_cancl                 = lt_ltap_can
              EXCEPTIONS
                to_confirmed                 = 1
                to_doesnt_exist              = 2
                item_confirmed               = 3
                item_doesnt_exist            = 4
                foreign_lock                 = 5
                double_lines                 = 6
                nothing_to_do                = 7
                xfeld_wrong                  = 8
                su_movement_partly_confirmed = 9
                update_without_commit        = 10
                no_authority                 = 11
                OTHERS                       = 12.
            IF sy-subrc <> 0.
* Implement suitable error handling here
            ENDIF.
          ENDIF.

          WAIT UP TO 2 SECONDS.

          PERFORM move_su.
        ENDIF.
        CLEAR:wa_final,wa_trite.
        REFRESH: it_ltak,it_ltap_vb,it_trite,it_ltak,it_bdcdata.
      ENDLOOP.
  ENDCASE.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  MOVE_SU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM move_su.
  DATA:lv_tanum        TYPE ltak-tanum,
       lt_ltap_move_su TYPE STANDARD TABLE OF ltap_move_su,
       lt_ltak_vb      TYPE STANDARD TABLE OF ltak_vb,
       lt_ltap_vb      TYPE STANDARD TABLE OF ltap_vb,
       lv_nltyp        TYPE ltap-nltyp,
       lv_nlber        TYPE ltap-nlber.

  LOOP AT lt_su INTO ls_su.
    SELECT SINGLE i_storagetyp f_storagetyp
      FROM zwm_config INTO (lv_nltyp,lv_nlber)
      WHERE werks EQ ls_su-werks
        AND auart EQ ls_su-auart.

    CALL FUNCTION 'L_TO_CREATE_MOVE_SU'
      EXPORTING
        i_lenum               = ls_su-lenum
        i_bwlvs               = '999'
        i_nltyp               = lv_nlber
        i_nlber               = '001'
        i_nlpla               = ls_su-lgpla
        i_letyp               = ls_su-lety1
        i_commit_work         = 'X'
        i_bname               = sy-uname
        i_solex               = ls_su-solex
      IMPORTING
        e_tanum               = lv_tanum
      TABLES
        t_ltap_move_su        = lt_ltap_move_su
        t_ltak                = lt_ltak_vb
        t_ltap_vb             = lt_ltap_vb
      EXCEPTIONS
        not_confirmed_to      = 1
        foreign_lock          = 2
        bwlvs_wrong           = 3
        betyp_wrong           = 4
        nltyp_wrong           = 5
        nlpla_wrong           = 6
        nltyp_missing         = 7
        nlpla_missing         = 8
        squit_forbidden       = 9
        lgber_wrong           = 10
        xfeld_wrong           = 11
        drukz_wrong           = 12
        ldest_wrong           = 13
        no_stock_on_su        = 14
        su_not_found          = 15
        update_without_commit = 16
        no_authority          = 17
        benum_required        = 18
        ltap_move_su_wrong    = 19
        lenum_wrong           = 20
        OTHERS                = 21.
    IF sy-subrc EQ 0.
      UPDATE zwm_su SET f_ind = abap_true WHERE lenum EQ ls_su-lenum.

      REFRESH:it_bdcdata.

      PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'LTAK-TANUM'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'LTAK-TANUM'
                                     lv_tanum.
      PERFORM bdc_field       USING 'LTAK-LGNUM'
                                     p_lgnum.
      PERFORM bdc_field       USING 'RL03T-DUNKL'
                                    'H'.
      PERFORM bdc_field       USING 'RL03T-QENTR'
                                    'X'.
      PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'LTAK-LGNUM'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=BU'.

      CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.
    ENDIF.

  ENDLOOP.
ENDFORM.

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
