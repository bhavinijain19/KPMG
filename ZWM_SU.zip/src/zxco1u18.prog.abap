*&---------------------------------------------------------------------*
*&  Include           ZXCO1U18
*&---------------------------------------------------------------------*
DATA:lv_totqty TYPE gamng.

IF is_header_new-gamng NE is_header_old-gamng AND sy-tcode EQ 'CO02'.
  SELECT SINGLE * FROM tvarvc INTO @DATA(ls_tvarvc) WHERE name EQ 'ZCO11N_MATERIALNO' AND low EQ @is_header_new-matnr.
  IF sy-subrc IS NOT INITIAL.
    SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @is_header_new-matnr.
    SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
    IF sy-subrc IS INITIAL.
      SELECT SINGLE * FROM zwm_config
        INTO @DATA(ls_config)
        WHERE werks = @is_header_new-werks
          AND auart = @is_header_new-auart.
      IF sy-subrc IS INITIAL.
        SELECT SUM( su_qty )
          FROM zwm_su
          INTO ( lv_totqty )
          WHERE aufnr EQ is_header_new-aufnr AND
                del_flg EQ abap_false.
        IF sy-subrc IS INITIAL.
          SELECT SINGLE objnr FROM aufk
           INTO @DATA(lv_objnr)
            WHERE aufnr EQ @is_header_new-aufnr.

          SELECT SINGLE * FROM jest
           INTO @DATA(lv_jest)
            WHERE objnr EQ @lv_objnr
              AND stat = 'I0002'.
          IF lv_jest IS NOT INITIAL.
            IF lv_totqty IS INITIAL.
              MESSAGE 'Please mark the order for deletion' TYPE 'E'.
            ELSE.
              IF is_header_new-gamng NE lv_totqty.
                MESSAGE 'No changes are allowed as SU is already generated for this order' TYPE 'E'.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
