FUNCTION-POOL ZFI_ABAP.                     "MESSAGE-ID ..

* INCLUDE LZFI_ABAPD...                      " Local class definition
