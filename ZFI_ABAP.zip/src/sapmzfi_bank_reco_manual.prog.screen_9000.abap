PROCESS BEFORE OUTPUT.
  MODULE set_screen.
  MODULE status_9000.
  CALL SUBSCREEN: sub_8001 INCLUDING sy-repid gv_sub_8001,
                  sub_8002 INCLUDING sy-repid gv_sub_8002.
* MODULE STATUS_9000.
*
PROCESS AFTER INPUT.
  CALL SUBSCREEN :sub_8001,
                  sub_8002.
  MODULE m_exit at EXIT-COMMAND.
  MODULE user_command_9000.
