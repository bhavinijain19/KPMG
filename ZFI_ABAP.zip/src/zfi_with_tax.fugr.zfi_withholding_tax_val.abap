FUNCTION zfi_withholding_tax_val.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_BKDF) LIKE  BKDF STRUCTURE  BKDF OPTIONAL
*"  TABLES
*"      T_AUSZ1 STRUCTURE  AUSZ1 OPTIONAL
*"      T_AUSZ2 STRUCTURE  AUSZ2 OPTIONAL
*"      T_AUSZ3 STRUCTURE  AUSZ_CLR OPTIONAL
*"      T_BKP1 STRUCTURE  BKP1
*"      T_BKPF STRUCTURE  BKPF
*"      T_BSEC STRUCTURE  BSEC
*"      T_BSED STRUCTURE  BSED
*"      T_BSEG STRUCTURE  BSEG
*"      T_BSET STRUCTURE  BSET
*"      T_BSEU STRUCTURE  BSEU OPTIONAL
*"----------------------------------------------------------------------

  IF sy-tcode = 'FB60'.
    IF t_bseg IS NOT INITIAL.
      DATA(lv_tax_found) = abap_false.

      LOOP AT t_bseg ASSIGNING FIELD-SYMBOL(<fs_bseg>) WHERE
        qsskz IS NOT INITIAL AND ktosl = 'WIT'.
*        IF <fs_bseg>-ktosl = 'WIT'.
        lv_tax_found = abap_true.
        EXIT.
*        ENDIF.
      ENDLOOP.

      IF lv_tax_found = abap_false.
        MESSAGE 'Withholding tax is mandatory.' TYPE 'E'.
      ENDIF.
    ENDIF.
  ENDIF.

  SELECT sign, opti AS option, low, high FROM tvarvc
    INTO TABLE @DATA(lr_tcode)
    WHERE name = 'ZFI_ODN_TCODE'
      AND type = 'S'.

**  IF sy-tcode IN lr_tcode.
**    IF t_bseg IS NOT INITIAL.
**      SORT t_bseg BY gsber DESCENDING.
**      DATA(ls_bkpf) = VALUE #( t_bkpf[ 1 ] OPTIONAL ).
**      DATA(ls_bseg) = VALUE #( t_bseg[ 1 ] OPTIONAL ).
**
**      SELECT SINGLE * FROM zfi_odn_nrgrp INTO @DATA(lv_odn) WHERE billing_type = @ls_bkpf-blart
**                                                     AND plant = @ls_bseg-gsber.
**      IF lv_odn IS NOT INITIAL.
**        SELECT SINGLE * FROM nriv INTO @DATA(lv_nriv) WHERE object = 'J_1IG_ODN'
**                                                AND subobject = @lv_odn-nrgrp
**                                                AND toyear = @ls_bkpf-gjahr.
**        IF sy-subrc NE 0.
**          MESSAGE e009(zfi_msgs) WITH ls_bkpf-blart ls_bseg-gsber.
**        ENDIF.
**      ELSE.
**        MESSAGE e009(zfi_msgs) WITH ls_bkpf-blart ls_bseg-gsber.
**      ENDIF.
**    ENDIF.
**  ENDIF.

ENDFUNCTION.
