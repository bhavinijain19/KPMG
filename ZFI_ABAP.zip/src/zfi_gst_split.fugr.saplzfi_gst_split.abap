*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GST_SPLITTOP.                 " Global Declarations
  INCLUDE LZFI_GST_SPLITUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GST_SPLITF...                 " Subroutines
* INCLUDE LZFI_GST_SPLITO...                 " PBO-Modules
* INCLUDE LZFI_GST_SPLITI...                 " PAI-Modules
* INCLUDE LZFI_GST_SPLITE...                 " Events
* INCLUDE LZFI_GST_SPLITP...                 " Local class implement.
* INCLUDE LZFI_GST_SPLITT99.                 " ABAP Unit tests
  INCLUDE LZFI_GST_SPLITF00                       . " subprograms
  INCLUDE LZFI_GST_SPLITI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
