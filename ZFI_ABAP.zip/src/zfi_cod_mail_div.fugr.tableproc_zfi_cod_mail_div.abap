*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_COD_MAIL_DIV
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_COD_MAIL_DIV    .

  PERFORM TABLEPROC.

ENDFUNCTION.
