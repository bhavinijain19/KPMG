*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_MIS_KDGRP...................................*
DATA:  BEGIN OF STATUS_ZFI_MIS_KDGRP                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_MIS_KDGRP                 .
CONTROLS: TCTRL_ZFI_MIS_KDGRP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_MIS_KDGRP                 .
TABLES: ZFI_MIS_KDGRP                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
