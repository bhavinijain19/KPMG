*&---------------------------------------------------------------------*
*& Report  ZFI_ASSET_DETAILS
*&
*&---------------------------------------------------------------------*
*&   Created By    : Carina Jose
*&   Creation Date : 08/12/2021
*&---------------------------------------------------------------------*


REPORT zfi_asset_details.
TABLES : anla, lfa1, anlz,anlb.

*&----------------------------------------------------- DATA DECLARATION ----------------------------------------------------------&*

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       g_save         TYPE c VALUE 'X',
       g_variant      TYPE disvariant,
       gx_variant     TYPE disvariant,
       g_exit         TYPE c,
       t_event        TYPE slis_t_event WITH HEADER LINE.


TYPES : BEGIN OF ty_final,
          bukrs          TYPE anla-bukrs,
          anln1          TYPE anla-anln1,
          anlkl          TYPE anla-anlkl,
          txt50          TYPE anla-txt50, " Asset description
          txa50          TYPE anla-txa50, " Additional asset description
          sernr          TYPE anla-sernr,
          name1          TYPE lfa1-name1,
          lifnr          TYPE lfa1-lifnr,
          erdat          TYPE anla-erdat,
          aktiv          TYPE anla-aktiv,
          aibn1          TYPE anla-aibn1,                """ added by Sudeep dt: 11.02.2026
          aibn2          TYPE anla-aibn2,                """ added by Sudeep dt: 11.02.2026
          kostl          TYPE anlz-kostl,
          werks          TYPE anlz-werks,
          gsber          TYPE anlz-gsber,                 """ added by Sudeep dt: 11.02.2026
          lstar          TYPE anlz-lstar,                 """ added by Sudeep dt: 11.02.2026
          afabe          TYPE anlb-afabe,
          afasl_1        TYPE anlb-afasl,
          afasl_2        TYPE anlb-afasl,
          schrw          TYPE anlb-schrw,
          schrw_proz     TYPE anlb-schrw_proz,
*          posnr          TYPE anla-posnr,
          posnr          TYPE string,
          glo_in_blk_key TYPE glofaaassetdata-glo_in_blk_key,
          glo_in_adnlblk TYPE glofaaassetdata-glo_in_adnlblk,
          ndjar(03), "Added by Carina Jose on 29/07/2022
          ndper(03), " Added by Carina Jose on 29/07/2022
          stort          TYPE anlz-stort, " Added by Carina Jose on 29/07/2022
          name1_plant    TYPE name1, "Added by Rutvi on 04.06.2024
          sub_asset_no   TYPE anln2, "Added by Rutvi on 04.06.2024
          salvage_value  TYPE kansw, "Added by Rutvi on 04.06.2024
          txk50          TYPE ankt-txk50, """added by akshay dt.03.04.2025
          menge          TYPE anla-menge, """added by akshay dt.03.04.2025
          meins          TYPE anla-meins, """added by akshay dt.03.04.2025
          typbz          TYPE anla-typbz, """added by akshay dt.03.04.2025
          ltext          TYPE cskt-ltext, """added by akshay dt.03.04.2025
          zugdt          TYPE anla-zugdt, """added by akshay dt.03.04.2025
          afabg          TYPE anlb-afabg, """added by akshay dt.03.04.2025
          inbda          TYPE anlb-inbda, """added by akshay dt.03.04.2025
        END OF ty_final.

DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.

CONSTANTS: c_dep_key TYPE rvari_vnam VALUE 'ZFI_DEP_KEY',
           c_tax_key TYPE rvari_vnam VALUE 'ZFI_TAX_KEY'.

DATA : v_dep_key(02).
DATA : v_tax_key(02).
TYPES: BEGIN OF ty_t001,
         bukrs TYPE bukrs,
       END OF ty_t001.
DATA : gt_t001 TYPE STANDARD TABLE OF ty_t001,
       wa_t001 TYPE ty_t001.

*&----------------------------------------------------- SELECTION SCREEN ----------------------------------------------------------&*
SELECTION-SCREEN BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS : s_bukrs FOR anla-bukrs OBLIGATORY,
                   s_anln1 FOR anla-anln1,
                   s_anlkl FOR anla-anlkl,
                   s_erdat FOR anla-erdat. "Added by Carina Jose on 29/07/2022
SELECTION-SCREEN END OF BLOCK a1.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-002.
  PARAMETERS: variant LIKE disvariant-variant.
SELECTION-SCREEN END OF BLOCK b1.

*&----------------------------------------------------- INITIALIZATION ----------------------------------------------------------&*
INITIALIZATION.
  gx_variant-report = sy-repid.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.
**************
AT SELECTION-SCREEN ON VALUE-REQUEST FOR variant.
*********************
*  **-- Display all existing variants
  g_variant-report = sy-repid.
* Utilizing the name of the report, this function module will search for a list of
* variants and will fetch the selected one into the parameter field for variants
  CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
    EXPORTING
      is_variant = g_variant
      i_save     = g_save
    IMPORTING
      e_exit     = g_exit
      es_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 2.
    MESSAGE ID sy-msgid TYPE 'S'      NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
    IF g_exit = space.
      variant = gx_variant-variant.
    ENDIF.
  ENDIF.

*&----------------------------------------------------- START OF SELECTION ----------------------------------------------------------&*
START-OF-SELECTION.
  PERFORM authorization_check.
  PERFORM check_variant.
  PERFORM get_data.
  IF it_final IS INITIAL.
    MESSAGE 'No data for inputted values!! Please enter valid data.' TYPE 'S' DISPLAY LIKE 'E'.
  ELSE.
    PERFORM fill_fieldcatalog.
    PERFORM display_grid.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT bukrs FROM t001 INTO TABLE gt_t001 WHERE bukrs IN s_bukrs.
  LOOP AT gt_t001 INTO wa_t001.
    AUTHORITY-CHECK OBJECT 'Z_FI_BUKRS'
    ID 'BUKRS' FIELD wa_t001-bukrs
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e014(zsd) WITH wa_t001-bukrs.
    ENDIF.
    CLEAR : wa_t001.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  DATA lv_gjahr TYPE char4.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low
*     INTO v_dep_key
*     FROM tvarvc
*     WHERE name = c_dep_key .

  SELECT low
   INTO v_dep_key FROM tvarvc UP TO 1 ROWS WHERE name = c_dep_key
   ORDER BY PRIMARY KEY .
  ENDSELECT.
* End of Quick Fix




* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low
*    INTO v_tax_key
*    FROM tvarvc
*    WHERE name = c_tax_key .

  SELECT low
   INTO v_tax_key FROM tvarvc UP TO 1 ROWS WHERE name = c_tax_key
   ORDER BY PRIMARY KEY .
  ENDSELECT.
* End of Quick Fix


  SELECT bukrs,anln1,anln2,anlkl,erdat,aktiv,lifnr,txt50,txa50,sernr,posnr,
    menge, meins, typbz, zugdt, ""added by akshay dt.03.04.2025
    aibn1, aibn2                "" added by sudeep dt: 11.02.2026
    FROM anla
    INTO TABLE @DATA(it_anla)
    WHERE bukrs IN @s_bukrs
    AND   anln1 IN @s_anln1
    AND   anlkl IN @s_anlkl
    AND   erdat IN @s_erdat.


  IF it_anla IS NOT INITIAL.


    SELECT lifnr, name1
      FROM lfa1
      INTO TABLE @DATA(it_lfa1)
      FOR ALL ENTRIES IN @it_anla
      WHERE lifnr = @it_anla-lifnr.

    SELECT bukrs, anln1,anln2,kostl,werks,stort,
      gsber, lstar             """" added by sudeep dt: 11.02.2026
      FROM anlz
      INTO TABLE @DATA(it_anlz)
      FOR ALL ENTRIES IN @it_anla
      WHERE bukrs = @it_anla-bukrs
      AND   anln1 = @it_anla-anln1
      AND   anln2 = @it_anla-anln2.
    """""ADDED BY AKSHAY DT.03.04.2025
    SELECT anlkl, txk50
      FROM ankt
      INTO TABLE @DATA(lt_anka)
      FOR ALL ENTRIES IN @it_anla
      WHERE anlkl = @it_anla-anlkl.

    """"EOC DT.03.04.2025

********************************Added by Rutvi on 04.06.2024
    IF it_anlz IS NOT INITIAL.

      SELECT werks, name1 FROM t001w INTO TABLE @DATA(it_t001w)
        FOR ALL ENTRIES IN  @it_anlz WHERE werks = @it_anlz-werks.

      """"added by akshay dt.03.04.2025
      SELECT kostl, ltext FROM cskt INTO TABLE @DATA(lt_cskt) FOR ALL ENTRIES IN @it_anlz
        WHERE kostl = @it_anlz-kostl.
      """"eoc dt.03.04.2025

    ENDIF.
************************************************************

    SELECT bukrs, anln1,anln2,afabe,afasl,schrw,schrw_proz,ndjar,ndper,afabg,inbda
     FROM anlb
     INTO TABLE @DATA(it_anlb)
     FOR ALL ENTRIES IN @it_anla
     WHERE bukrs = @it_anla-bukrs
     AND   anln1 = @it_anla-anln1
     AND   anln2 = @it_anla-anln2.
***********************Added by Rutvi on 04.06.2024
    DATA(it_anlb_s) = it_anlb.
    DELETE it_anlb_s WHERE afabe NE '1'.
    IF it_anlb_s IS NOT INITIAL.
      SELECT afapl,afasl,anhwsl FROM t090na INTO TABLE @DATA(it_t090na)
      FOR ALL ENTRIES IN @it_anlb_s WHERE afapl = 'ASTL'
                                      AND afasl = @it_anlb_s-afasl.
    ENDIF.

    IF it_t090na IS NOT INITIAL.
      SELECT * FROM t091p INTO TABLE @DATA(it_t091p)
      FOR ALL ENTRIES IN @it_t090na WHERE anhwsl = @it_t090na-anhwsl.
    ENDIF.

    CALL FUNCTION 'GM_GET_FISCAL_YEAR'
      EXPORTING
        i_date                     = sy-datum
        i_fyv                      = 'V3'
      IMPORTING
        e_fy                       = lv_gjahr
      EXCEPTIONS
        fiscal_year_does_not_exist = 1
        not_defined_for_date       = 2
        OTHERS                     = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.


    SELECT bukrs,
           anln1,
           anln2,
           gjahr,
           afabe,
           zujhr,
           zucod,
           answl,
           kansw FROM anlc INTO TABLE @DATA(it_anlc)
           FOR ALL ENTRIES IN @it_anla WHERE bukrs = @it_anla-bukrs
                                        AND  anln1 = @it_anla-anln1
                                        AND  anln2 = @it_anla-anln2
                                        AND  afabe = '1'
                                        AND  gjahr = @lv_gjahr.
****************************************************

*&------------- Added by Carina Jose on 18/04/2022 ---------------- &*
    SELECT bukrs,anln1,anln2,glo_in_blk_key,glo_in_adnlblk
    FROM glofaaassetdata
    INTO TABLE @DATA(it_gl)
    FOR ALL ENTRIES IN @it_anla
    WHERE bukrs = @it_anla-bukrs
    AND   anln1 = @it_anla-anln1
    AND   anln2 = @it_anla-anln2.

*&------------- End of changes by Carina Jose on 18/04/2022 ------- &*

  ENDIF.

*&---------------------------------------------------------------------------------------------------------------------------------&*

  LOOP AT it_anla ASSIGNING FIELD-SYMBOL(<fs_anla>).
    IF <fs_anla> IS ASSIGNED.
      LOOP AT it_anlb ASSIGNING FIELD-SYMBOL(<fs_anlb>) WHERE bukrs = <fs_anla>-bukrs
                                                         AND  anln1 = <fs_anla>-anln1
                                                         AND anln2 = <fs_anla>-anln2.
        IF <fs_anlb> IS ASSIGNED.
          wa_final-afabe = <fs_anlb>-afabe.
          wa_final-ndjar = <fs_anlb>-ndjar.
          wa_final-ndper = <fs_anlb>-ndper.
*          wa_final-AFABG = <fs_anlb>-AFABG.
          IF wa_final-afabe = v_dep_key.
            wa_final-afasl_1 = <fs_anlb>-afasl.
            wa_final-schrw = <fs_anlb>-schrw. " Added by Carina Jose on 18.04.2022
            wa_final-schrw_proz = <fs_anlb>-schrw_proz. " Added by Carina Jose on 18.04.2022
          ENDIF.
          IF wa_final-afabe = v_tax_key.
            wa_final-afasl_2 = <fs_anlb>-afasl.
          ENDIF.


        ENDIF.
      ENDLOOP.
      UNASSIGN : <fs_anlb>.
*      READ TABLE it_anla ASSIGNING FIELD-SYMBOL(<fs_anla>) WITH KEY bukrs = <fs_anlb>-bukrs
*                                                                    anln1 = <fs_anlb>-anln1
*                                                                    anln2 = <fs_anlb>-anln2.
*      IF <fs_anla> IS ASSIGNED.
      wa_final-bukrs = <fs_anla>-bukrs.
      wa_final-anln1 = <fs_anla>-anln1.
      wa_final-anlkl = <fs_anla>-anlkl.
      wa_final-txt50 = <fs_anla>-txt50.
      wa_final-txa50 = <fs_anla>-txa50.
      wa_final-sernr = <fs_anla>-sernr.
      wa_final-erdat = <fs_anla>-erdat.
      wa_final-aktiv = <fs_anla>-aktiv.
      wa_final-menge = <fs_anla>-menge. """added by akshay dt.03.04.2025
      wa_final-meins = <fs_anla>-meins. """added by akshay dt.03.04.2025
      wa_final-typbz = <fs_anla>-typbz. """added by akshay dt.03.04.2025
      wa_final-zugdt = <fs_anla>-zugdt. """added by akshay dt.03.04.2025
      wa_final-sub_asset_no = <fs_anla>-anln2.    "Added by Rutvi on 04.06.2024
      wa_final-aibn1 = <fs_anla>-aibn1.   """ added by sudeep dt: 11.02.2026
      wa_final-aibn2 = <fs_anla>-aibn2.   """ added by sudeep dt: 11.02.2026

      """"added by akshay dt.03.04.2025
      READ TABLE lt_anka INTO DATA(wa_anka) WITH KEY anlkl = <fs_anla>-anlkl.
      IF sy-subrc = 0.
        wa_final-txk50 = wa_anka-txk50.
      ENDIF.
      """"eoc dt akshay dt.03.04.2025

      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = <fs_anla>-posnr
        IMPORTING
          output = wa_final-posnr.
*      wa_final-posnr = <fs_anla>-posnr. " Added by Carina Jose on 18.04.2022
*      ENDIF.
***********************************Added by Rurtvi on 04.06.2024
      READ TABLE it_anlb_s INTO DATA(wa_anlb_s) WITH KEY bukrs = <fs_anla>-bukrs
                                                         anln1 = <fs_anla>-anln1
                                                         anln2 = <fs_anla>-anln2
                                                         afabe = '1'.
      IF sy-subrc = 0.
        wa_final-afabg = wa_anlb_s-afabg.
        wa_final-inbda = wa_anlb_s-inbda.
        READ TABLE it_t090na INTO DATA(wa_t090na) WITH KEY afapl = 'ASTL'
                                                           afasl = wa_anlb_s-afasl.
        IF sy-subrc = 0.
          READ TABLE it_t091p INTO DATA(wa_t091p) WITH KEY anhwsl = wa_t090na-anhwsl.
          IF sy-subrc = 0.
            READ TABLE it_anlc INTO DATA(wa_anlc) WITH KEY bukrs = <fs_anla>-bukrs
                                                         anln1 = <fs_anla>-anln1
                                                         anln2 = <fs_anla>-anln2
                                                         afabe = '1'.
            IF sy-subrc = 0.
              IF wa_anlc-kansw IS INITIAL.
                wa_final-salvage_value = ( wa_anlc-answl * wa_t091p-ahproz ) / 100.
              ELSE.
                wa_final-salvage_value = ( wa_anlc-kansw * wa_t091p-ahproz ) / 100.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
******************************************************************************************88
      READ TABLE it_gl ASSIGNING FIELD-SYMBOL(<fs_gl>) WITH KEY bukrs = <fs_anla>-bukrs " Added by Carina Jose on 18.04.2022
                                                                anln1 = <fs_anla>-anln1
                                                                anln2 = <fs_anla>-anln2.
      IF <fs_gl> IS ASSIGNED.
        wa_final-glo_in_blk_key = <fs_gl>-glo_in_blk_key.
        wa_final-glo_in_adnlblk = <fs_gl>-glo_in_adnlblk.
      ENDIF.

      READ TABLE it_lfa1 ASSIGNING FIELD-SYMBOL(<fs_lfa1>) WITH KEY lifnr = <fs_anla>-lifnr.
      IF <fs_lfa1> IS ASSIGNED.
        wa_final-lifnr = <fs_lfa1>-lifnr.
        wa_final-name1 = <fs_lfa1>-name1.
      ENDIF.

      READ TABLE it_anlz ASSIGNING FIELD-SYMBOL(<fs_anlz>) WITH KEY bukrs = <fs_anla>-bukrs
                                                                    anln1 = <fs_anla>-anln1
                                                                    anln2 = <fs_anla>-anln2.
      IF <fs_anlz> IS ASSIGNED.
        wa_final-kostl = <fs_anlz>-kostl.
        wa_final-werks = <fs_anlz>-werks.
        wa_final-stort = <fs_anlz>-stort.
        wa_final-gsber = <fs_anlz>-gsber.   """" added by Sudeep dt: 11.02.2026
        wa_final-lstar = <fs_anlz>-lstar.   """" added by Sudeep dt: 11.02.2026
***************************Added by Rutvi on 04.06.2024
        READ TABLE it_t001w INTO DATA(wa_t001w) WITH KEY werks = <fs_anlz>-werks.
        IF sy-subrc = 0.
          wa_final-name1_plant = wa_t001w-name1.
        ENDIF.
*************************************************************
        """added by akshay dt.03.04.2025
        READ TABLE lt_cskt INTO DATA(wa_cskt) WITH KEY kostl = <fs_anlz>-kostl.
        IF sy-subrc = 0.
          wa_final-ltext = wa_cskt-ltext.
        ENDIF.
        """eoc dt.03.04.2025
      ENDIF.
    ENDIF.

    SHIFT wa_final-anln1 LEFT DELETING LEADING '0'.
    SHIFT wa_final-anlkl LEFT DELETING LEADING '0'.
    APPEND wa_final TO it_final.
    CLEAR : wa_final.
    UNASSIGN : <fs_lfa1>,<fs_anlz>.
  ENDLOOP.
  UNASSIGN :<fs_anla>.

****  added auth. CHECK by carina jose ON 01.03.2022
  LOOP AT it_final INTO wa_final.
    AUTHORITY-CHECK OBJECT 'Z_ASST_WRK'
    ID 'WERKS' FIELD wa_final-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc NE 0.
*      MESSAGE e018(zfi) WITH wa_final-prctr.
      DELETE it_final WHERE anln1 = wa_final-anln1 AND werks = wa_final-werks.
    ENDIF.
    CLEAR : wa_final.
  ENDLOOP.
****  End of Channges by carina Jose on 01.03.2022
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .

  PERFORM fieldcat_append  USING  'ANLN1'               'Asset Code'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'BUKRS'               'Company Code'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'ANLKL'               'Asset Class'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'TXT50'               'Asset Description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'TXA50'               'Additional Asset description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'SERNR'               'Serial number'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'NAME1'               'Name 1'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LIFNR'               'Vendor'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'ERDAT'               'Created On'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'AKTIV'               'Cap. Date'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KOSTL'               'Cost Center'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'WERKS'               'Plant'                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'AFABE'               'Real Depreciation Area'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'AFASL_1'               'Depreciation Key(01)'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'AFASL_2'               'Tax Block Key(15)'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'GLO_IN_BLK_KEY'               'Block Key'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'GLO_IN_ADNLBLK'               'Additional Block Key'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'SCHRW'               'Scrap Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'SCHRW_PROZ'               'Scrap %'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'POSNR'               'WBS Element'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'NDJAR'               'Planned useful life in years'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'NDPER'               'Planned useful life in periods'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'STORT'               'Asset location'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'NAME1_PLANT'         'Plant Name'                'X'  'IT_FINAL'   . "Added by Rutvi on 04.06.2024
  PERFORM fieldcat_append  USING  'SUB_ASSET_NO'         'Sub Asset number'                'X'  'IT_FINAL'   . "Added by Rutvi on 04.06.2024
**  PERFORM fieldcat_append  USING  'SALVAGE_VALUE'         'Salvage value'                'X'  'IT_FINAL'   . "Added by Rutvi on 04.06.2024
  PERFORM fieldcat_append  USING  'TXK50'         'Asset Class Description'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'MENGE'         'Qty'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'MEINS'         'UOM'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'LTEXT'         'Cost Center Description'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'TYPBZ'         'Type Name'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'ZUGDT'         'First acquisition on'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'AFABG'         'Ord. dep. start date'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'INBDA'         'Operating readiness'                'X'  'IT_FINAL'   . "Added by akshay dt.03.04.2025
  PERFORM fieldcat_append  USING  'GSBER'         'Business Area'                'X'  'IT_FINAL'   . "Added by Sudeep dt. 11.02.2026
  PERFORM fieldcat_append  USING  'LSTAR'         'Activity Type'                'X'  'IT_FINAL'   . "Added by Sudeep dt. 11.02.2026
  PERFORM fieldcat_append  USING  'AIBN1'         'Original Main Asset'                'X'  'IT_FINAL'   . "Added by Sudeep dt. 11.02.2026
  PERFORM fieldcat_append  USING  'AIBN2'         'Original Sub Asset No.'                'X'  'IT_FINAL'   . "Added by Sudeep dt. 11.02.2026
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0585   text
*      -->P_0586   text
*      -->P_0587   text
*      -->P_0588   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page  = 'TOP_OF_PAGE'
*     i_callback_user_command = 'USER_COMMANDS'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
*     it_events          = t_event[]
      i_save             = 'A'
*     it_sort            = i_sort
      is_variant         = g_variant
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_variant .
  g_variant-variant = variant.
  g_variant-report  = sy-repid.
  CALL FUNCTION 'LVC_VARIANT_EXISTENCE_CHECK' "Check for display variant
    EXPORTING
      i_save        = space            "Variants Can be Saved
    CHANGING
      cs_variant    = g_variant        "Variant information
    EXCEPTIONS
      wrong_input   = 1                "Inconsistent input parameters
      not_found     = 2                "Variant not found
      program_error = 3                "Program Errors
    .                                       "  LVC_VARIANT_EXISTENCE_CHECK
  IF sy-subrc = 2.
    MESSAGE 'Display Variant Not Found, Displaying Default Variant'
                                                              TYPE 'S'.
  ENDIF.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.
ENDFORM.
