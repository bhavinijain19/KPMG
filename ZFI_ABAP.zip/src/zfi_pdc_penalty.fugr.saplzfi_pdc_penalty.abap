*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PDC_PENALTYTOP.               " Global Data
  INCLUDE LZFI_PDC_PENALTYUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PDC_PENALTYF...               " Subroutines
* INCLUDE LZFI_PDC_PENALTYO...               " PBO-Modules
* INCLUDE LZFI_PDC_PENALTYI...               " PAI-Modules
* INCLUDE LZFI_PDC_PENALTYE...               " Events
* INCLUDE LZFI_PDC_PENALTYP...               " Local class implement.
* INCLUDE LZFI_PDC_PENALTYT99.               " ABAP Unit tests
  INCLUDE LZFI_PDC_PENALTYF00                     . " subprograms
  INCLUDE LZFI_PDC_PENALTYI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
