*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_SALE_SMS....................................*
DATA:  BEGIN OF STATUS_ZFI_SALE_SMS                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_SALE_SMS                  .
CONTROLS: TCTRL_ZFI_SALE_SMS
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_SALE_SMS                  .
TABLES: ZFI_SALE_SMS                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
