FUNCTION-POOL ZFI_SALE_SMS               MESSAGE-ID SV.

* INCLUDE LZFI_SALE_SMSD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_SALE_SMST00                        . "view rel. data dcl.
