FUNCTION-POOL ZF901.                        "MESSAGE-ID ..

* INCLUDE LZF901D...                         " Local class definition
