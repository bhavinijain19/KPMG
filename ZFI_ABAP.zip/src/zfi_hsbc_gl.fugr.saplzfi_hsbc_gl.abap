*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_HSBC_GLTOP.                   " Global Declarations
  INCLUDE LZFI_HSBC_GLUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_HSBC_GLF...                   " Subroutines
* INCLUDE LZFI_HSBC_GLO...                   " PBO-Modules
* INCLUDE LZFI_HSBC_GLI...                   " PAI-Modules
* INCLUDE LZFI_HSBC_GLE...                   " Events
* INCLUDE LZFI_HSBC_GLP...                   " Local class implement.
* INCLUDE LZFI_HSBC_GLT99.                   " ABAP Unit tests
  INCLUDE LZFI_HSBC_GLF00                         . " subprograms
  INCLUDE LZFI_HSBC_GLI00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
