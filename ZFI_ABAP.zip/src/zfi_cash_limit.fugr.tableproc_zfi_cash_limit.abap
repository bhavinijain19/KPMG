*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_CASH_LIMIT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_CASH_LIMIT      .

  PERFORM TABLEPROC.

ENDFUNCTION.
