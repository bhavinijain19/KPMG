*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PDC_PENALTY.................................*
DATA:  BEGIN OF STATUS_ZFI_PDC_PENALTY               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PDC_PENALTY               .
CONTROLS: TCTRL_ZFI_PDC_PENALTY
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PDC_PENALTY               .
TABLES: ZFI_PDC_PENALTY                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
