*&---------------------------------------------------------------------*
*& Report  ZCR_PENALTY_INT_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zcr_penalty_int_rcl.



************Database Structures Used
TABLES:bsik,bsak,bsid,bsad,knvv.
*************Selection Screen
SELECTION-SCREEN:BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-001.

  SELECT-OPTIONS:s_bukrs FOR bsid-bukrs OBLIGATORY,
                 s_kunnr FOR bsid-kunnr," MODIF ID KUN,
                 s_umskz FOR bsid-umskz. "no INTERVALS,
  PARAMETERS     s_blart TYPE bsid-blart. "no INTERVALS,

  SELECT-OPTIONS:  s_bldat FOR bsid-budat OBLIGATORY.
  PARAMETERS    : s_int(10) NO-DISPLAY.
  PARAMETERS    : p_bldat TYPE bsid-budat NO-DISPLAY.
  PARAMETERS    : p_vkorg TYPE knvv-vkorg OBLIGATORY. " Added by Carina Jose on 03.03.2022
*SELECT-OPTIONS: s_spart FOR knvv-spart NO INTERVALS NO-EXTENSION. " Added by Carina Jose on 03.03.2022
SELECTION-SCREEN:END OF BLOCK b2.

SELECTION-SCREEN:BEGIN OF BLOCK b3 WITH FRAME TITLE TEXT-002.
  PARAMETERS : s_days TYPE i.
SELECTION-SCREEN:END OF BLOCK b3.

"""added by akshay dt.23.07.2025
SELECTION-SCREEN:BEGIN OF BLOCK b5 WITH FRAME TITLE TEXT-003.
  PARAMETER: rad1 RADIOBUTTON GROUP rgb DEFAULT 'X',
             rad2 RADIOBUTTON GROUP rgb.
SELECTION-SCREEN:END OF BLOCK b5.
"""eoc dt.23.07.2025

SELECTION-SCREEN:BEGIN OF BLOCK b4 WITH FRAME TITLE TEXT-003.
  PARAMETERS : chk AS CHECKBOX DEFAULT 'X'.
  SELECTION-SCREEN COMMENT /1(70) xsrm2.
SELECTION-SCREEN:END OF BLOCK b4.


SELECTION-SCREEN COMMENT /1(70) xsrm1.

*SELECTION-SCREEN:BEGIN OF BLOCK b4 WITH FRAME TITLE text-003.
***********************************************************************
*                Data Declaration                                      *
************************************************************************
TYPES:BEGIN OF ty_bsid,

        kunnr              TYPE bsid-kunnr,
        belnr              TYPE bsid-belnr,
        bldat              TYPE bsid-bldat,
        shkzg              TYPE bsid-shkzg,

        budat              TYPE bsid-budat,
        blart              TYPE bsid-blart,
        xref1              TYPE bsid-xref1,  ""Added by manish Paul
        bukrs              TYPE bsid-bukrs,
        dmbtr              TYPE bsid-dmbtr,
        wrbtr              TYPE bsid-wrbtr,
        xblnr              TYPE bsid-xblnr,
        augdt              TYPE bsid-augdt,
        umskz              TYPE bsid-umskz,
        zbd1t              TYPE bsid-zbd1t, """ADDED BY AKSHAY DT.23.07.2025
        zterm              TYPE bsid-zterm, """ADDED BY AKSHAY DT.23.07.2025
        zuonr              TYPE bsad-zuonr, """Added by Manish paul 06.03.2026


        hdate              TYPE bsid-bldat,
        hbelnr             TYPE bsid-belnr,
        hdmbtr             TYPE bsid-dmbtr,
        hwrbtr             TYPE bsid-dmbtr,
        hblart             TYPE bsid-blart,
        int                TYPE bsid-dmbtr,
        pint               TYPE bsid-dmbtr,
        pint_o             TYPE bsid-dmbtr, """"added by akshay dt.27.09.2025
        oipint             TYPE bsid-dmbtr, """added by akshay dt.30.08.2025
        pint1              TYPE bsid-dmbtr,
        v_h1               TYPE bsid-dmbtr,
        v_h2               TYPE bsid-dmbtr,
        closing            TYPE bsid-dmbtr,

        days               TYPE i,
        udays              TYPE i,
        ind(1),
        split(01),
        srno(03),
        idays              TYPE i,
        ipdays             TYPE i,
        uedays             TYPE i,
        opedays            TYPE i,
        soffice(50),
        name1              TYPE kna1-name1,
        intrate(10),
        dmbtr1             TYPE bsid-dmbtr,
        dmbtr2             TYPE bsid-dmbtr,
        wrbtr2             TYPE bsid-wrbtr,
        opind(01),
        duedate            TYPE bsid-budat,
        invbalind(01),
**** Added changes to display Sales office code and payment terms by Carina Jose on 16.12.2019
*        zterm         TYPE knvv-zterm,  """COMMENTED BY AKSHAY DT.23.07.2025
        vkbur              TYPE knvv-vkbur,
*        kdgrp              TYPE knvv-kdgrp, "Commented BY BP
        kvgr1              TYPE knvv-kvgr1, "Added BY BP
        kvgr2              TYPE knvv-kvgr2, "Added BY BP
**** End of changes to display Sales office code and payment terms by Carina Jose on 16.12.2019
        bktxt              TYPE bkpf-bktxt,
        pbktxt             TYPE bkpf-bktxt,
        zstd_days          TYPE zcr_matx_new-zstd_days,
        zstd_days_f        TYPE zcr_matx_new-zstd_days,
        zlegal_remark(3)   TYPE c, """"added by akshay dt.23.07.2025
        outstanding_amount TYPE bsid-dmbtr, """"added by akshay dt.23.07.2025
        cust_group1(50), """"added by akshay dt.20.08.2025
        cust_group2(50),

      END OF ty_bsid.

DATA:wa_sbsid TYPE ty_bsid,
     it_sbsid TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_sbsid_temp TYPE ty_bsid,
     it_sbsid_temp TYPE STANDARD TABLE OF ty_bsid.


DATA:lw_sbsid TYPE ty_bsid,
     lt_sbsid TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_sbsid1 TYPE ty_bsid,
     it_sbsid1 TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_hbsid TYPE ty_bsid,
     it_hbsid TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_hbsid_temp TYPE ty_bsid,
     it_hbsid_temp TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_hbsid1 TYPE ty_bsid,
     it_hbsid1 TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_1hbsid TYPE ty_bsid,
     it_1hbsid TYPE STANDARD TABLE OF ty_bsid.

DATA:wa_1sbsid TYPE ty_bsid,
     it_1sbsid TYPE STANDARD TABLE OF ty_bsid.


DATA: it_shbsid TYPE STANDARD TABLE OF ty_bsid,
      wa_shbsid TYPE ty_bsid.

TYPES: BEGIN OF ty_knvv,
         kunnr TYPE knvv-kunnr,
         zterm TYPE knvv-zterm,
         vkbur TYPE knvv-vkbur,
*         kdgrp TYPE knvv-kdgrp,
         kvgr1 TYPE knvv-kvgr1,
         kvgr2 TYPE knvv-kvgr2,
       END OF ty_knvv.
DATA: it_knvv TYPE STANDARD TABLE OF ty_knvv,
      wa_knvv TYPE ty_knvv.

TYPES : BEGIN OF ty_kna1,
          kunnr TYPE kna1-kunnr,
          name1 TYPE kna1-name1,
        END OF ty_kna1.
DATA: it_kna1 TYPE STANDARD TABLE OF ty_kna1,
      wa_kna1 TYPE ty_kna1.
DATA : it_tvkbt TYPE STANDARD TABLE OF tvkbt,
       wa_tvkbt TYPE tvkbt.


DATA : it_t052 TYPE STANDARD TABLE OF t052,
       wa_t052 TYPE t052.
*************** invoice balance amount sum
TYPES: BEGIN OF ty_sbsid3,
         kunnr   TYPE bsid-kunnr,
         belnr   TYPE bsid-belnr,
         invbal  TYPE bsid-dmbtr,
         linvbal TYPE bsid-dmbtr,
         budat   TYPE bsid-budat,
       END OF ty_sbsid3.

DATA: it_sbsid3 TYPE STANDARD TABLE OF ty_sbsid3,
      wa_sbsid3 TYPE ty_sbsid3.

DATA:v_date1 TYPE sy-datum.
DATA: v_bukrs TYPE bsid-bukrs.
DATA: zmonth TYPE i.

TYPES : BEGIN OF t_t001,
          bukrs TYPE t001-bukrs,
        END OF t_t001.

DATA: it_bukrs TYPE STANDARD TABLE OF t_t001,
      wa_bukrs TYPE t_t001.

DATA:wa_open TYPE bapi3007_3,
     it_open TYPE TABLE OF bapi3007_3.
DATA: v_s TYPE bsid-dmbtr.
DATA: v_h TYPE bsid-dmbtr.
DATA: dmbtr1 TYPE bsid-dmbtr. "for advance ind amount ref
DATA: v_h1 TYPE bsid-dmbtr.
DATA: v_h2 TYPE bsid-dmbtr.
DATA: v_invbal TYPE bsid-dmbtr."invoice balance amount sum
DATA: l_invbal TYPE bsid-dmbtr."last line invoice balance amount sum
DATA: l_budat TYPE bsid-budat."last line invoice date
DATA: v_calc TYPE bsid-dmbtr.
DATA : zterm TYPE i.
DATA : zterm1 TYPE i.
**********************

TYPES: BEGIN OF ty_bkpf,
         bukrs TYPE bkpf-bukrs,
         belnr TYPE bkpf-belnr,
         budat TYPE bkpf-budat,
         bktxt TYPE bkpf-bktxt,
       END OF ty_bkpf.
DATA: it_bkpf TYPE STANDARD TABLE OF ty_bkpf,
      wa_bkpf TYPE ty_bkpf.

DATA: it_pbkpf TYPE STANDARD TABLE OF ty_bkpf,
      wa_pbkpf TYPE ty_bkpf.

DATA : v_dmbtr    TYPE bsid-dmbtr,
       v_wrbtr    TYPE bsid-wrbtr,
       v_bldat    TYPE bsid-bldat,
       v_shkzg    TYPE bsid-shkzg,
       v_budat    TYPE bsid-budat,
       v_blart    TYPE bsid-blart,
       v_bukrs1   TYPE bsid-bukrs,
       v_xblnr    TYPE bsid-xblnr,
       v_augdt    TYPE bsid-augdt,
       v_closing  TYPE bsid-dmbtr,
       v_closing1 TYPE bsid-dmbtr,
       lv_h2      TYPE bsid-dmbtr,
       v_sdmbtr   TYPE bsid-dmbtr,
       v_swrbtr   TYPE bsid-wrbtr,
       v_hdmbtr   TYPE bsid-dmbtr,
       v_hwrbtr   TYPE bsid-wrbtr,
       v_hdmbtr1  TYPE bsid-dmbtr,
       v_umskz    TYPE bsid-umskz,
       v_hwrbtr1  TYPE bsid-wrbtr,
       v_zterm    TYPE bsid-zterm, """added by akshay dt.23.07.2025
       v_zuonr    TYPE bsid-zuonr, """Added Manish Paul
       v_zbd1t    TYPE bsid-zbd1t. """added by akshay dt.23.07.2025
*--- OBJECT AND VARIABLE LIST FOR ALV GRID DISPLAY-------*
DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE.

CONSTANTS : c_var_name TYPE rvari_vnam VALUE 'ZCR_PINT_EX_SPGL',
            c_type_s   TYPE rsscr_kind VALUE 'S'.

TYPES: BEGIN OF ty_tvarvc,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE tvarv_val,
         high TYPE tvarv_val,
       END OF ty_tvarvc.
DATA: lt_umskz TYPE STANDARD TABLE OF ty_tvarvc,
      wa_umskz TYPE ty_tvarvc.

*DATA: gv_umskz TYPE umskz.
*RANGES : s_umskz FOR gv_umskz.

* Define the object to be passed to the RESTRICTION parameter
DATA restrict TYPE sscr_restrict.

DATA: it_matrix TYPE STANDARD TABLE OF zcr_matx_new,
      wa_matrix TYPE zcr_matx_new.

DATA: zstd_days TYPE zcr_matx_new-zstd_days.

* Auxiliary objects for filling RESTRICT
DATA : optlist TYPE sscr_opt_list,
       ass     TYPE sscr_ass.

DATA: lt_openitems TYPE TABLE OF rfpos, """added by akshay dt.23.07.2025
      ls_openitems TYPE rfpos. """added by akshay dt.23.07.2025
FIELD-SYMBOLS :        <ls_openitems> TYPE rfpos. """added by akshay dt.23.07.2025
*********************Added by Raj on 10.10.2023***************************
TYPES: BEGIN OF ty_tvarvcp,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE tvarv_val,
         high TYPE tvarv_val,
       END OF ty_tvarvcp.
DATA: it_tvarv TYPE STANDARD TABLE OF ty_tvarvcp,
      wa_tvarv TYPE ty_tvarvcp.
DATA: it_biltyp TYPE STANDARD TABLE OF ty_tvarvcp,   ""Added by Ranjan
      wa_biltyp TYPE ty_tvarvcp.
CONSTANTS : c_var_namep TYPE rvari_vnam VALUE 'ZPAY_TERMS'.
CONSTANTS : c_var_name1 TYPE rvari_vnam VALUE 'ZBILLING_TYPE'. "" added by Ranjan 30.10.2025
*********************Added by Raj on 10.10.2023****************************
*p_bldat = s_bldat-low.
*INITIALIZATION.
********************* restict  10.06.2021 for SPGL in selection
** Restricting the  selection to only EQ and 'BT'.
*  optlist-name = 'OBJECTKEY1'.
*  optlist-options-ne = 'X'.
**optlist-options-bt = 'X'.
*  APPEND optlist TO restrict-opt_list_tab.
*
*  ass-kind = 'S'.
*  ass-name = 'S_UMSKZ'.
*  ass-sg_main = 'I'.
*  ass-sg_addy = space.
*  ass-op_main = 'OBJECTKEY1'.
*  APPEND ass TO restrict-ass_tab.
*
*  CALL FUNCTION 'SELECT_OPTIONS_RESTRICT'
*    EXPORTING
*      restriction            = restrict
*    EXCEPTIONS
*      too_late               = 1
*      repeated               = 2
*      selopt_without_options = 3
*      selopt_without_signs   = 4
*      invalid_sign           = 5
*      empty_option_list      = 6
*      invalid_kind           = 7
*      repeated_kind_a        = 8
*      OTHERS                 = 9.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*  ENDIF.
*******

AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-name = 'P_BLDAT'.
      screen-input = 0.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.

  xsrm1 = 'Note : Interest Calculation is based on Document Date'.
  xsrm2 = '(For op.bal. items, interest calculated from start date in selection)'.

START-OF-SELECTION.

  IF rad1 = abap_true.           """added by akshay dt.23.07.2025
    PERFORM authorization_check.
    PERFORM get_cust.
    PERFORM fill_listheader.
    PERFORM fill_fieldcatalog.
    PERFORM fill_layout.
    PERFORM display_grid.
  ELSE.  """added by akshay dt.23.07.2025
    PERFORM authorization_check.
    PERFORM get_cust1.
*    PERFORM get_cust_open.
    PERFORM fill_listheader.
    PERFORM fill_fieldcatalog_open.
    PERFORM fill_layout.
    PERFORM display_grid.

  ENDIF.
  """eoc dt.23.07.2025
*&---------------------------------------------------------------------*
*&      Form  GET_CUST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_cust .
  p_bldat = s_bldat-low.
  CLEAR: s_int.

  CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
    EXPORTING
      begda    = s_bldat-low
      endda    = s_bldat-high
*     TAB_MODE = ' '
*     IV_LEAP_YEAR_MODE       =
    IMPORTING
*     DAYS     = zdays
*     C_WEEKS  =
      c_months = zmonth
*     C_YEARS  =
*     WEEKS    =
*     MONTHS   =
*     YEARS    =
*     D_MONTHS =
*     MONTH_TAB               =
    .
  zmonth = zmonth + 1.
***********
*  SELECT sign
*        opti
*        low
*        high INTO TABLE lt_umskz
*                   FROM tvarvc
*                   WHERE name = c_var_name AND
*                         type = c_type_s.
*
*  LOOP AT lt_umskz INTO wa_umskz.
*    s_umskz-sign = 'I'.
*    s_umskz-option = 'EQ'.
*    s_umskz-low = wa_umskz-low.
*    APPEND s_umskz.
*    CLEAR: wa_umskz.
*  ENDLOOP.
*********
*  SELECT kunnr belnr bldat shkzg  budat
*        blart bukrs dmbtr wrbtr xblnr augdt FROM bsid INTO TABLE it_sbsid
*                                              WHERE bukrs IN s_bukrs
*                                              AND kunnr IN s_kunnr
*                                              AND budat LE s_bldat-high
*                                              AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*         blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_sbsid
*                                               WHERE bukrs IN s_bukrs
*                                               AND kunnr IN s_kunnr
*                                               AND budat LE s_bldat-high
*                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                               AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*        blart bukrs dmbtr wrbtr xblnr augdt FROM bsid INTO TABLE it_hbsid
*                                              WHERE bukrs IN s_bukrs
*                                              AND kunnr IN s_kunnr
*                                              AND budat LE s_bldat-high
*                                              AND shkzg = 'H'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*        blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_hbsid
*                                              WHERE bukrs IN s_bukrs
*                                              AND kunnr IN s_kunnr
*                                              AND budat LE s_bldat-high
*                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                              AND shkzg = 'H'.

**************Added by Raj on 10.10.2023**************************
  SELECT sign
          opti
          low high
            FROM tvarvc  INTO TABLE it_tvarv
               WHERE name = c_var_namep.

  SELECT sign
        opti
        low high
          FROM tvarvc  INTO TABLE it_biltyp
             WHERE name = c_var_name1.
**************Added by Raj on 10.10.2023**************************
*********for opening
  IF zmonth LE '12'.
**** Added by Carina Jose on 03.03.2022
    SELECT kunnr,vkorg
      FROM knvv
      INTO TABLE @DATA(it_knvv1)
      WHERE kunnr IN @s_kunnr
      AND   vkorg = @p_vkorg.
*      AND spart IN @s_spart. """added by akshay dt.23.07.2025
**** End of changes by Carina Jose on 03.03.2022
    """added by akshay dt.23.07.2025
    SELECT * FROM zfi_legal_case INTO TABLE @DATA(it_legal_case) FOR ALL ENTRIES IN @it_knvv1
      WHERE kunnr = @it_knvv1-kunnr AND vkorg = @it_knvv1-vkorg.
    """eoc dt.23.07.2025


    IF it_knvv1 IS NOT INITIAL. " Added by Carina Jose on 03.03.2022

      SELECT kunnr belnr bldat shkzg  budat
              blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid INTO TABLE it_sbsid
                                                    FOR ALL ENTRIES IN it_knvv1
                                                    WHERE bukrs IN s_bukrs
*                                                  AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                    AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN s_umskz
                                                    AND budat LT s_bldat-low
                                                    AND shkzg = 'S'.

      SELECT kunnr belnr bldat shkzg  budat
              blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_sbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                    WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                    AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN  s_umskz
                                                    AND budat LT s_bldat-low
                                                    AND augdt GE s_bldat-low
                                                    AND shkzg = 'S'.

      SELECT kunnr belnr bldat shkzg  budat
             blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid INTO TABLE it_hbsid
                                                    FOR ALL ENTRIES IN it_knvv1
                                                   WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                 AND umskz IN s_umskz
                                                   AND budat LT s_bldat-low
                                                   AND shkzg = 'H'.

      SELECT kunnr belnr bldat shkzg  budat
              blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_hbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                    WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN s_umskz
                                                    AND budat LT s_bldat-low
                                                    AND augdt GE s_bldat-low
                                                    AND shkzg = 'H'.

*********** for line item
      SELECT kunnr belnr bldat shkzg  budat
               blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_sbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                     WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                   AND umskz IN s_umskz
                                                     AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                     AND shkzg = 'S'.

      SELECT kunnr belnr bldat shkzg  budat
            blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_hbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                  WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                AND umskz IN s_umskz
                                                  AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                  AND shkzg = 'H'.

      SELECT kunnr belnr bldat shkzg  budat
               blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid APPENDING TABLE it_sbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                     WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                   AND umskz IN s_umskz
                                                     AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                     AND shkzg = 'S'.

      SELECT kunnr belnr bldat shkzg  budat
            blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid APPENDING TABLE it_hbsid
                                                   FOR ALL ENTRIES IN it_knvv1
                                                  WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                   AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                AND umskz IN s_umskz
                                                  AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                  AND shkzg = 'H'.
*

*
    ENDIF. " Added by Carina Jose on 03.03.2022
********************************  11.06.2021 for date
  ELSE.
    MESSAGE 'DATE RANGE IS MAXIMUM ONE YEAR' TYPE 'E'.
  ENDIF.
*  SELECT kunnr belnr bldat shkzg  budat
*            blart bukrs dmbtr wrbtr xblnr augdt FROM bsid INTO TABLE it_sbsid_temp
*                                                  WHERE bukrs IN s_bukrs
*                                                  AND kunnr IN s_kunnr
*                                                  AND umskz NOT IN s_umskz
*                                                  AND budat LT s_bldat-low
*                                                  AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*          blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_sbsid_temp
*                                                WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr
*                                                AND umskz NOT IN  s_umskz
*                                                AND budat LT s_bldat-low
*                                                AND augdt GE s_bldat-low
*                                                AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*         blart bukrs dmbtr wrbtr xblnr augdt FROM bsid INTO TABLE it_hbsid_temp
*                                               WHERE bukrs IN s_bukrs
*                                               AND kunnr IN s_kunnr
*                                               AND umskz NOT IN s_umskz
*                                               AND budat LT s_bldat-low
*                                               AND shkzg = 'H'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*          blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_hbsid_temp
*                                                WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr
*                                                AND umskz NOT IN s_umskz
*                                                AND budat LT s_bldat-low
*                                                AND augdt GE s_bldat-low
*                                                AND shkzg = 'H'.
*
************ for line item
*  SELECT kunnr belnr bldat shkzg  budat
*           blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_sbsid_temp
*                                                 WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr
*                                                 AND umskz NOT IN s_umskz
*                                                 AND budat BETWEEN s_bldat-low AND s_bldat-high
**                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                                 AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*        blart bukrs dmbtr wrbtr xblnr augdt FROM bsad APPENDING TABLE it_hbsid_temp
*                                              WHERE bukrs IN s_bukrs
*                                              AND kunnr IN s_kunnr
*                                              AND umskz NOT IN s_umskz
*                                              AND budat BETWEEN s_bldat-low AND s_bldat-high
**                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                              AND shkzg = 'H'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*           blart bukrs dmbtr wrbtr xblnr augdt FROM bsid APPENDING TABLE it_sbsid_temp
*                                                 WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr
*                                                 AND umskz NOT IN s_umskz
*                                                 AND budat BETWEEN s_bldat-low AND s_bldat-high
**                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                                 AND shkzg = 'S'.
*
*  SELECT kunnr belnr bldat shkzg  budat
*        blart bukrs dmbtr wrbtr xblnr augdt FROM bsid APPENDING TABLE it_hbsid_temp
*                                              WHERE bukrs IN s_bukrs
*                                              AND kunnr IN s_kunnr
*                                              AND umskz NOT IN s_umskz
*                                              AND budat BETWEEN s_bldat-low AND s_bldat-high
**                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
*                                              AND shkzg = 'H'.
*********************

  IF it_sbsid IS NOT INITIAL.


*    SELECT kunnr zterm vkbur kdgrp FROM knvv INTO TABLE it_knvv
    SELECT kunnr zterm vkbur kvgr1 kvgr2 FROM knvv INTO TABLE it_knvv "Added by BP
    FOR ALL ENTRIES IN it_sbsid
     WHERE kunnr = it_sbsid-kunnr
     AND   vkorg = p_vkorg. " Added by Carina Jose on 03.03.2022

    "Start of change by Ranjan 30.10.2025

* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
    SORT it_knvv BY kunnr.

* End of Quick Fix
    " " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*    SELECT vbeln, xblnr
*         FROM vbrk
*         INTO TABLE @DATA(it_vbrk)
*         FOR ALL ENTRIES IN @it_sbsid
*         WHERE xblnr = @it_sbsid-xblnr
*         AND fkart IN @it_biltyp.
    SELECT  billingdocument AS vbeln , documentreferenceid AS xblnr FROM
   i_billingdocumentbasic INTO TABLE  @DATA(it_vbrk) FOR  ALL
   ENTRIES  IN  @it_sbsid  WHERE documentreferenceid = @it_sbsid-xblnr AND
   billingdocumenttype IN @it_biltyp.

    SELECT
  b~bukrs,
  b~belnr,
  b~gjahr,
  b~awkey,
  v~vkbur,
  v~kvgr1,
  v~kvgr2 "Taking KVGR1 as an example
FROM bkpf AS b
INNER JOIN vbrp AS v ON v~vbeln = b~awkey
FOR ALL ENTRIES IN @it_sbsid
WHERE b~belnr = @it_sbsid-belnr
  AND b~bukrs = @it_sbsid-bukrs
  AND b~awtyp = 'VBRK'
INTO TABLE @DATA(lt_final_data).

    SELECT bukrs, belnr , gjahr , awkey , awtyp FROM bkpf INTO TABLE @DATA(lt_bkpf)
      FOR ALL ENTRIES IN  @it_sbsid WHERE belnr = @it_sbsid-belnr AND awtyp = 'VBRK' AND bukrs = @it_sbsid-bukrs.


*      zuonr         as AssignmentReference,
    " " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    "End of change by Ranjan 30.10.2025

    SELECT kunnr name1 FROM kna1 INTO TABLE it_kna1
   FOR ALL ENTRIES IN it_sbsid
   WHERE kunnr = it_sbsid-kunnr.
  ENDIF.

  IF it_hbsid IS NOT INITIAL.
    SELECT kunnr zterm vkbur FROM knvv APPENDING TABLE it_knvv
     FOR ALL ENTRIES IN it_hbsid
      WHERE kunnr = it_hbsid-kunnr
      AND   vkorg = p_vkorg. " Added by Carina Jose on 03.03.2022

* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
    SORT it_knvv BY kunnr.

* End of Quick Fix
  ENDIF.


  DELETE ADJACENT DUPLICATES FROM it_knvv COMPARING kunnr.
  IF lt_final_data IS NOT INITIAL.
    SELECT * FROM tvkbt INTO TABLE it_tvkbt
      FOR ALL ENTRIES IN lt_final_data
      WHERE vkbur = lt_final_data-vkbur.
  ENDIF.





  SELECT * FROM t052 INTO TABLE it_t052 FOR ALL ENTRIES IN it_knvv WHERE zterm = it_knvv-zterm.

  SELECT * FROM zcr_matx_new INTO TABLE it_matrix.

  SELECT * FROM zfi_mis_kdgrp  INTO TABLE @DATA(gt_div)  WHERE vkorg = @p_vkorg. """added by akshay dt.20.08.2025

  SELECT * FROM tvv1t INTO TABLE @DATA(gt_tvv1t) FOR ALL ENTRIES IN @lt_final_data WHERE kvgr1 = @lt_final_data-kvgr1 AND spras = 'E'.
  SELECT * FROM tvv2t INTO TABLE @DATA(gt_tvv2t) FOR ALL ENTRIES IN @lt_final_data WHERE kvgr2 = @lt_final_data-kvgr2 AND spras = 'E'.

  SORT it_sbsid BY kunnr belnr bldat.
  SORT it_hbsid BY kunnr belnr bldat.



***************  FOR DELEETE SPGL IND DOCUMENT.
*  LOOP AT it_sbsid INTO wa_sbsid.
*    READ TABLE it_sbsid_temp INTO wa_sbsid_temp WITH KEY kunnr = wa_sbsid-belnr belnr = wa_sbsid-belnr bldat = wa_sbsid-bldat.
*    IF sy-subrc = 0.
*      DELETE TABLE it_sbsid FROM wa_sbsid.
*    ENDIF.
*    CLEAR: wa_sbsid_temp,wa_sbsid.
*  ENDLOOP.
*


  LOOP AT it_hbsid INTO wa_hbsid.
    LOOP AT  it_sbsid INTO wa_sbsid WHERE kunnr = wa_hbsid-kunnr AND belnr = wa_hbsid-belnr AND bldat = wa_hbsid-bldat.
      wa_sbsid-umskz = wa_hbsid-umskz.
      wa_sbsid-blart = wa_hbsid-blart.
      MODIFY it_sbsid FROM wa_sbsid TRANSPORTING umskz blart.
      CLEAR: wa_sbsid.
    ENDLOOP.
    CLEAR: wa_hbsid.
  ENDLOOP.
*****
**************** add logic for club document number amount
  LOOP AT it_sbsid INTO wa_sbsid.
    wa_sbsid-dmbtr2 = wa_sbsid-dmbtr.
    wa_sbsid-wrbtr2 = wa_sbsid-wrbtr.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING dmbtr2 wrbtr2.
    MOVE-CORRESPONDING wa_sbsid TO wa_shbsid.
    APPEND wa_shbsid TO it_shbsid.
  ENDLOOP.

  LOOP AT it_hbsid INTO wa_hbsid.
    wa_hbsid-dmbtr2 = wa_hbsid-dmbtr * -1.
    wa_hbsid-wrbtr2 = wa_hbsid-wrbtr * -1.
    MODIFY it_hbsid FROM wa_hbsid TRANSPORTING dmbtr2 wrbtr2.
    MOVE-CORRESPONDING wa_hbsid TO wa_shbsid.
    APPEND wa_shbsid TO it_shbsid.
  ENDLOOP.

  SORT it_shbsid BY kunnr bldat belnr.
********************
  LOOP AT it_shbsid INTO wa_shbsid.
    IF wa_shbsid-shkzg = 'S'.
      v_sdmbtr = v_sdmbtr + wa_shbsid-dmbtr2.
      v_swrbtr = v_swrbtr + wa_shbsid-wrbtr2.
    ELSE.
      v_hdmbtr = v_hdmbtr + wa_shbsid-dmbtr2.
      v_hwrbtr = v_hwrbtr + wa_shbsid-wrbtr2.
    ENDIF.
    v_bldat = wa_shbsid-bldat.
    v_shkzg = wa_shbsid-shkzg.
    v_budat = wa_shbsid-budat.
    v_blart = wa_shbsid-blart.
    v_bukrs1 = wa_shbsid-bukrs.
    v_xblnr = wa_shbsid-xblnr.
    v_augdt = wa_shbsid-augdt.
    v_umskz = wa_shbsid-umskz.
    v_umskz = wa_shbsid-umskz.
    v_zbd1t = wa_shbsid-zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
    v_zterm = wa_shbsid-zterm.  """"ADDED BY AKSHAY DT.23.07.2025
    wa_1sbsid-zuonr = wa_shbsid-zuonr.

    AT END OF belnr.
      wa_1hbsid-kunnr = wa_shbsid-kunnr.
      wa_1hbsid-belnr = wa_shbsid-belnr.
***      wa_1hbsid-zbd1t = v_zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
***      wa_1hbsid-zterm = v_zterm.  """"ADDED BY AKSHAY DT.23.07.2025
      wa_1hbsid-bldat = v_bldat.
      wa_1hbsid-shkzg = v_shkzg.
      wa_1hbsid-budat = v_budat.
      wa_1hbsid-blart = v_blart.
      wa_1hbsid-umskz = v_umskz.
      wa_1hbsid-bukrs = v_bukrs1.
      wa_1hbsid-dmbtr = v_hdmbtr + v_sdmbtr.
      wa_1hbsid-wrbtr = v_hwrbtr + v_swrbtr.
      wa_1hbsid-xblnr = v_xblnr.
      wa_1hbsid-augdt = v_augdt.
      IF wa_1hbsid-dmbtr < 0.
        IF wa_1hbsid-budat LE p_bldat.
          wa_1hbsid-opind = 'X'.
        ENDIF.
        wa_1hbsid-dmbtr = wa_1hbsid-dmbtr * -1.
        wa_1hbsid-wrbtr = wa_1hbsid-wrbtr * -1.
        APPEND wa_1hbsid TO it_1hbsid.

      ENDIF.
*    **********  for s
      wa_1sbsid-kunnr = wa_shbsid-kunnr.
      wa_1sbsid-belnr = wa_shbsid-belnr.
      wa_1sbsid-zbd1t = v_zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
      wa_1sbsid-zterm = v_zterm.  """"ADDED BY AKSHAY DT.23.07.2025
      wa_1sbsid-bldat = v_bldat.
      wa_1sbsid-shkzg = v_shkzg.
      wa_1sbsid-budat = v_budat.
      wa_1sbsid-blart = v_blart.
      wa_1sbsid-bukrs = v_bukrs1.
      wa_1sbsid-umskz = v_umskz.
      wa_1sbsid-dmbtr = v_hdmbtr + v_sdmbtr.
      wa_1sbsid-wrbtr = v_hwrbtr + v_swrbtr.
      wa_1sbsid-xblnr = v_xblnr.
      wa_1sbsid-augdt = v_augdt.
      IF wa_1sbsid-dmbtr > 0.

        IF wa_1sbsid-budat LE p_bldat.
          wa_1sbsid-opind = 'X'.
        ENDIF.

        APPEND wa_1sbsid TO it_1sbsid.

      ENDIF.
      CLEAR:v_shkzg,v_budat,v_blart,v_bukrs,v_dmbtr,v_wrbtr,v_xblnr,v_augdt,wa_1hbsid,v_hdmbtr,v_sdmbtr,v_hwrbtr, v_swrbtr,v_hdmbtr1,v_hwrbtr1,wa_1sbsid,wa_1hbsid,v_umskz,v_zbd1t,v_zterm.
    ENDAT.
  ENDLOOP.

  IF s_umskz IS NOT INITIAL.
    DELETE it_1hbsid WHERE umskz IN s_umskz.
    DELETE it_1sbsid WHERE umskz IN s_umskz.
  ENDIF.

  IF s_blart IS NOT INITIAL.
    DELETE it_1hbsid WHERE blart = s_blart.
    DELETE it_1sbsid WHERE blart = s_blart.
  ENDIF.

  it_hbsid[] = it_1hbsid[].
  it_sbsid[] = it_1sbsid[].
***********
  SORT it_sbsid BY kunnr bldat belnr.
  SORT it_hbsid BY kunnr bldat belnr.
*  commnet logic 17/01/2019
*
*  LOOP AT it_hbsid INTO wa_hbsid.
*    v_dmbtr = v_dmbtr + wa_hbsid-dmbtr.
*    v_wrbtr = v_wrbtr + wa_hbsid-wrbtr.
*    v_bldat = wa_hbsid-bldat.
*    v_shkzg = wa_hbsid-shkzg.
*    v_budat = wa_hbsid-budat.
*    v_blart = wa_hbsid-blart.
*    v_bukrs1 = wa_hbsid-bukrs.
*    v_xblnr = wa_hbsid-xblnr.
*    v_augdt = wa_hbsid-augdt.
*
*    AT END OF belnr.
*      wa_1hbsid-kunnr = wa_hbsid-kunnr.
*      wa_1hbsid-belnr = wa_hbsid-belnr.
*      wa_1hbsid-bldat = v_bldat.
*      wa_1hbsid-shkzg = v_shkzg.
*      wa_1hbsid-budat = v_budat.
*      wa_1hbsid-blart = v_blart.
*      wa_1hbsid-bukrs = v_bukrs1.
*      wa_1hbsid-dmbtr = v_dmbtr.
*      wa_1hbsid-wrbtr = v_wrbtr.
*      wa_1hbsid-xblnr = v_xblnr.
*      wa_1hbsid-augdt = v_augdt.
*      APPEND wa_1hbsid TO it_1hbsid.
*      CLEAR:v_shkzg,v_budat,v_blart,v_bukrs,v_dmbtr,v_wrbtr,v_xblnr,v_augdt,wa_1hbsid.
*    ENDAT.
*  ENDLOOP.
*  it_hbsid[] = it_1hbsid[].
************end comment logic 17/01/2019
  LOOP AT it_sbsid INTO wa_sbsid.
    wa_sbsid-dmbtr1 = wa_sbsid-dmbtr.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING dmbtr1.
  ENDLOOP.

  LOOP AT it_hbsid INTO wa_hbsid.
*LOOP AT it_sbsid INTO wa_sbsid where ind <> 'Y'.
    CLEAR:dmbtr1.
*    LOOP AT it_hbsid INTO wa_hbsid WHERE kunnr = wa_sbsid-kunnr .

    LOOP AT it_sbsid INTO wa_sbsid WHERE kunnr = wa_hbsid-kunnr AND ind <> 'Y' AND dmbtr <> '0.00'.
*      IF sy-subrc = 0.
      wa_sbsid-wrbtr = wa_sbsid-dmbtr1.
      v_h1 = wa_hbsid-dmbtr - wa_sbsid-dmbtr.
      v_s = wa_sbsid-dmbtr - wa_hbsid-dmbtr.
      v_h = wa_hbsid-dmbtr - wa_sbsid-dmbtr.
      IF v_h > 0.
        v_calc = wa_sbsid-dmbtr.
      ELSE.
        v_calc = wa_hbsid-dmbtr.
      ENDIF.
*      IF V_H > 0.
*        CONTINUE.
*      ELSE.
*        IF v_s < 0.
*          wa_sbsid-dmbtr = v_s * -1.
*        ELSE.


*        ENDIF.

      wa_sbsid-bldat = wa_sbsid-bldat.
      wa_sbsid-budat = wa_sbsid-budat.
      wa_sbsid-belnr = wa_sbsid-belnr.
      wa_sbsid-xblnr = wa_sbsid-xblnr.
      wa_sbsid-hdate = wa_hbsid-bldat.
      wa_sbsid-hbelnr = wa_hbsid-belnr.
      wa_sbsid-hdmbtr = wa_hbsid-dmbtr.
      wa_sbsid-hwrbtr = wa_hbsid-wrbtr.
      wa_sbsid-hblart = wa_hbsid-blart.
      wa_sbsid-xref1  = wa_hbsid-xref1.
***      wa_sbsid-zbd1t = wa_hbsid-zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
***      wa_sbsid-zterm = wa_hbsid-zterm.  """"ADDED BY AKSHAY DT.23.07.2025


      IF  wa_sbsid-hdmbtr < wa_sbsid-dmbtr.
        wa_sbsid-hdmbtr = '0.00'.
      ELSE.
        wa_sbsid-hdmbtr = wa_sbsid-hdmbtr -  wa_sbsid-dmbtr.
      ENDIF.
      IF wa_sbsid-hdmbtr  > '0.00'.
*          wa_sbsid-v_h1 = wa_sbsid-hwrbtr -  wa_sbsid-hdmbtr.
        wa_sbsid-v_h1 = wa_hbsid-dmbtr -  wa_sbsid-hdmbtr.
      ELSE.
        wa_sbsid-v_h1 = wa_hbsid-dmbtr.
      ENDIF.
      wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
      wa_sbsid-dmbtr = v_s .
      wa_hbsid-dmbtr = v_h .

*


*
*       if wa_sbsid-v_h1 ne '0.00'.
*          wa_sbsid-closing = wa_sbsid-v_h2 - wa_sbsid-hdmbtr.
*       else.
*          wa_sbsid-closing = wa_sbsid-v_h2 + wa_sbsid-closing.
*        endif.

      wa_hbsid-bldat = wa_hbsid-bldat.
      wa_hbsid-belnr = wa_hbsid-belnr.
      wa_hbsid-ind = 'Y'.
*********************      logic comment 24/01/2019
*      IF chk <> 'X'.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*      ELSE.
*        if wa_sbsid-budat ge p_bldat.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*        else.
*        wa_sbsid-days = wa_sbsid-hdate - p_bldat.
*        endif.
*      ENDIF.
*****************      logic comment 24/01/2019
      wa_sbsid-ind = 'Y'.

*      READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
*      IF sy-subrc = 0.
******  Added to display Sales Office code and payment terms by Carina Jose on 16.12.2019
*        wa_sbsid-vkbur = wa_knvv-vkbur.
*        wa_sbsid-kvgr1 = wa_knvv-kvgr1.
*        wa_sbsid-zterm = wa_knvv-zterm. """COMMENTED BY AKSHAY DT.23.07.2025
      ""Adedd by Ranjan 27.11.2025
      DATA: lv_is_numeric TYPE char4.

      READ TABLE lt_final_data INTO DATA(ls_final_data) WITH KEY belnr = wa_sbsid-belnr.
      wa_sbsid-kvgr1 = ls_final_data-kvgr1.
      wa_sbsid-kvgr2 = ls_final_data-kvgr2.
      wa_sbsid-vkbur = ls_final_data-vkbur.

      READ TABLE gt_tvv1t INTO DATA(ls_tvv1t) WITH KEY kvgr1 = wa_sbsid-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO DATA(ls_tvv2t) WITH KEY kvgr2 = wa_sbsid-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.

      READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_sbsid-vkbur.
      IF sy-subrc = 0.
        wa_sbsid-soffice = wa_tvkbt-bezei.
      ENDIF.

      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
          string_in = wa_sbsid-xblnr
        IMPORTING
          htype     = lv_is_numeric.
      .

      IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*          SELECT SINGLE KDGRP_AUFT FROM VBRP INTO @Data(lv_kdgrp) WHERE vbeln = @wa_sbsid-XBLNR.

*          SELECT kdgrp_auft FROM vbrp INTO @DATA(lv_kdgrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
        SELECT kvgr2 FROM vbrp INTO @DATA(lv_kdgrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
         ORDER BY PRIMARY KEY .
        ENDSELECT.

* End of Quick Fix

*          wa_sbsid-kdgrp = lv_kdgrp.

*          wa_sbsid-kvgr1 = lv_kdgrp.
      ENDIF.
      CLEAR lv_is_numeric.
*        wa_sbsid-kdgrp = wa_knvv-kdgrp.
***** End of changes to display Sales Office code and payment terms  by Carina Jose on 16.12.2019
*        READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_knvv-vkbur.
*        IF sy-subrc = 0.
*          wa_sbsid-soffice = wa_tvkbt-bezei.
*        ENDIF.

      READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
        wa_sbsid-name1 = wa_kna1-name1.
      ENDIF.

      READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
      IF sy-subrc = 0.
        zterm1 = wa_t052-ztag1.
        zterm = zterm1 + s_days.
*            SHIFT zterm LEFT DELETING LEADING '0'.
      ENDIF.

      """"added by akshay dt.20.08.2025
      READ TABLE  it_legal_case INTO DATA(wa_legal_case) WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
        wa_sbsid-zlegal_remark = 'Yes'.
      ENDIF.

*      READ TABLE  gt_div INTO DATA(wa_div) WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        wa_sbsid-cust_group = wa_div-txt.
*      ENDIF.
      """"end of changes dt.20.08.2025
******************      logic add 24/01/2019
      DATA: p_caldate TYPE sy-datum.
      DATA: p_caldate1 TYPE sy-datum.
      DATA: p_caldate2 TYPE bsid-budat.
      DATA: days LIKE t5a4a-dlydy.
*      days = zterm. """COMMENTED BY AKSHAY DT.23.07.2025
      days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025

*      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
*        EXPORTING
*          date      = wa_sbsid-bldat
*          days      = days
*          months    = 00
*          signum    = '+'
*          years     = 00
*        IMPORTING
*          calc_date = p_caldate.
**      P_caldate = wa_sbsid-bldat +
*      IF chk <> 'X'.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*      ELSE.
**         if .
*        IF p_caldate GE p_bldat AND wa_sbsid-opind = 'X'.
*          wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*        ELSE.
*          wa_sbsid-days = wa_sbsid-hdate - p_bldat.
*        ENDIF.
*      ENDIF.
**************
**********  due date calculation
******************** comment 22.08.2023
if wa_sbsid-blart = 'UE'.
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
 ELSE.
   CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
         date      = wa_sbsid-bldat
*          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
 ENDIF.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.
********************      end comment 22.08.2023
      """"added by akshay dt.30.08.2025
      DATA:lv_pint TYPE c.
      CLEAR:lv_pint.
      IF wa_sbsid-duedate IS INITIAL.
        wa_sbsid-duedate = s_bldat-high.
        lv_pint = abap_true.
      ENDIF.
      """"eoc dt.30.08.2025
*      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat."comment 05.10.2023
      IF wa_sbsid-BLART = 'UE'.
      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat. "added 05.10.2023
      ELSE.
      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-budat. "added 05.10.2023
      ENDIF.
******************* comment for exceed days 28/03/2019
*      IF wa_sbsid-budat LE p_bldat AND wa_sbsid-duedate LE p_bldat.
*        wa_sbsid-idays = wa_sbsid-hdate - p_bldat.
*        IF wa_sbsid-idays < 0.
*          wa_sbsid-idays = 0.
*        ENDIF.
*      ELSE.
*        wa_sbsid-idays = wa_sbsid-hdate - wa_sbsid-duedate.
*        IF wa_sbsid-idays < 0.
*          wa_sbsid-idays = 0.
*        ENDIF.
*      ENDIF.
****************    end 28/03/2019
*************** add 28/03/2019
      IF chk = 'X' AND wa_sbsid-budat LE p_bldat.
        wa_sbsid-idays = wa_sbsid-hdate - p_bldat.
        IF wa_sbsid-idays < 0.
          wa_sbsid-idays = 0.
        ENDIF.
      ELSE.
        wa_sbsid-idays = wa_sbsid-hdate - wa_sbsid-duedate."comment 22.08.2023
        IF wa_sbsid-BLART = 'UE'.
        wa_sbsid-ipdays = wa_sbsid-hdate - wa_sbsid-bldat. "added 27.10.2023
        ELSE.
        wa_sbsid-ipdays = wa_sbsid-hdate - wa_sbsid-budat. "added 27.10.2023
        ENDIF.
        IF wa_sbsid-idays < 0.
          wa_sbsid-idays = 0.
        ENDIF.
        IF wa_sbsid-ipdays < 0.
          wa_sbsid-ipdays = 0.
        ENDIF.
      ENDIF.

*        READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*        IF wa_tvarv IS NOT INITIAL.
*          IF wa_sbsid-zterm = wa_tvarv-low.
*            wa_sbsid-idays = 0.
*          ENDIF .
*        ENDIF.

************   END 28/03/2019


      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
          string_in = wa_sbsid-xblnr
        IMPORTING
          htype     = lv_is_numeric.
      .

      IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT SINGLE KDGRP_AUFT FROM VBRP INTO @Data(lv_kdgrp1) WHERE vbeln = @wa_sbsid-XBLNR.

*        SELECT kdgrp_auft FROM vbrp INTO @DATA(lv_kdgrp1) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*        SELECT kvgr2 FROM vbrp INTO @DATA(lv_kdgrp1) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*         ORDER BY PRIMARY KEY .
*        ENDSELECT.

* End of Quick Fix

        "" added by ranjan
      ENDIF.
      CLEAR lv_is_numeric.
      READ TABLE it_vbrk WITH KEY vbeln = wa_sbsid-xblnr TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
      ELSE.
        LOOP AT it_matrix INTO wa_matrix WHERE zkvgr1 = wa_sbsid-kvgr1 AND zkvgr2 = wa_sbsid-kvgr2. "wa_sbsid-kdgrp.

          IF wa_matrix-zday_to IS NOT INITIAL.
            IF wa_sbsid-ipdays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
              s_int = wa_matrix-zyr_per.
              wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
          IF wa_matrix-zday_to IS INITIAL.
            IF wa_sbsid-ipdays GE wa_matrix-zday_from.
              s_int = wa_matrix-zyr_per.
              wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.

*      READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*      IF wa_tvarv IS NOT INITIAL.
*        IF wa_sbsid-zterm = wa_tvarv-low.
*          wa_sbsid-ipdays = 0.
*          s_int = 0.
*        ENDIF .
*      ENDIF.



*      IF wa_sbsid-days > zterm.
*        wa_sbsid-idays = wa_sbsid-days - zterm.
      wa_sbsid-zstd_days = wa_sbsid-ipdays - wa_sbsid-zstd_days_f.

*      IF wa_sbsid-ipdays > 0. "comment by parth 12.12.2023
      IF wa_sbsid-zstd_days  > 0.

        wa_sbsid-int = ( v_calc * s_int ) / 100.
*       wa_sbsid-pint =  ( wa_sbsid-int * wa_sbsid-ipdays ) / 365. "comment by parth 12.12.2023
        IF lv_pint = abap_true.   """added by akshay dt.30.08.2025
          wa_sbsid-oipint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365. """added by akshay dt.30.08.2025
        ELSE. """added by akshay dt.30.08.2025
          wa_sbsid-pint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365.
        ENDIF.  """added by akshay dt.30.08.2025
      ENDIF.
      wa_sbsid-intrate =  s_int.
      dmbtr1 = wa_sbsid-dmbtr1.
      MODIFY it_sbsid FROM wa_sbsid TRANSPORTING ind hbelnr hdate days hdmbtr hblart idays ipdays pint soffice name1 hwrbtr v_h1 v_h2 intrate wrbtr duedate vkbur zterm zstd_days zlegal_remark
      cust_group1 cust_group2
             kvgr1 kvgr2 zstd_days_f.
      MODIFY it_hbsid FROM wa_hbsid TRANSPORTING ind.
      IF v_s <> 0.
        wa_sbsid-ind = 'N'.
      ENDIF.
      IF v_h <> 0.
        wa_hbsid-ind = 'N'.
      ENDIF.
      IF wa_sbsid-dmbtr > 0 .
        wa_sbsid-split = 'S'.
        APPEND wa_sbsid TO it_sbsid.
      ELSEIF wa_hbsid-dmbtr > 0 .
        wa_hbsid-split = 'S'.
        wa_hbsid-srno = wa_hbsid-srno + 1.

*****************Added  by Raj on 10.10.2023**********************
*        READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*        IF wa_tvarv IS NOT INITIAL.
*          IF wa_sbsid-zterm = wa_tvarv-low.
*            wa_hbsid-idays = 0.
*          ENDIF .
*        ENDIF.

****************Added  by Raj on 10.10.2023***********************
        APPEND wa_hbsid TO it_hbsid.



      ENDIF.
      SORT it_sbsid BY kunnr bldat belnr hdate hbelnr.
      SORT it_hbsid BY kunnr bldat belnr srno.
      CLEAR:v_s,v_h,wa_sbsid,wa_hbsid,zterm,zterm1,wa_t052,wa_kna1,wa_tvkbt,days,p_caldate1,p_caldate,wa_matrix,s_int,wa_tvarv,zstd_days,ls_final_data.
      EXIT.
*      ENDIF.
*  ENDIF.

    ENDLOOP.
***********    add 25/01/2019
*      if dmbtr1 is INITIAL AND wa_hbsid-ind <> 'N'.
*      wa_sbsid-kunnr = wa_hbsid-kunnr.
*      wa_sbsid-hdate =  wa_hbsid-bldat.
*      wa_sbsid-hbelnr = wa_hbsid-belnr.
*      wa_sbsid-hdmbtr = wa_hbsid-dmbtr.
*      wa_sbsid-hwrbtr = wa_hbsid-wrbtr.
*      wa_sbsid-hblart = wa_hbsid-blart.
**      wa_sbsid-v_h1 =  wa_hbsid-dmbtr.
**       wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
*
*      APPEND wa_sbsid to it_sbsid.
*      SORT it_sbsid BY kunnr hdate hbelnr.
*      clear: wa_sbsid,dmbtr1.
*      endif.
************      end 25/01/2019
  ENDLOOP.

  DELETE it_sbsid WHERE ind = 'N'.

*  *************************** Payment header text add
  SELECT bukrs belnr budat bktxt
    FROM bkpf INTO TABLE it_pbkpf
     FOR ALL ENTRIES IN it_sbsid
      WHERE bukrs = it_sbsid-bukrs
      AND   belnr = it_sbsid-hbelnr
      AND   budat = it_sbsid-hdate.

  SELECT bukrs belnr budat bktxt
    FROM bkpf INTO TABLE it_bkpf
     FOR ALL ENTRIES IN it_sbsid
      WHERE bukrs = it_sbsid-bukrs
      AND   belnr = it_sbsid-belnr
      AND   budat = it_sbsid-budat.
************************

  LOOP AT it_sbsid INTO wa_sbsid.
*****    add 25/01/2019
*    IF wa_sbsid-dmbtr <> '0.00'.
********      end 25/01/2019
    IF wa_sbsid-v_h1 = '0.00'.
      wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
    ENDIF.

    IF wa_sbsid-v_h1 NE '0.00'.
      wa_sbsid-closing = wa_sbsid-v_h2 - wa_sbsid-hdmbtr.
*      v_closing = wa_sbsid-closing.
*      lv_h2     = wa_sbsid-dmbtr.
    ELSE.
*      wa_sbsid-closing = wa_sbsid-v_h2 + wa_sbsid-closing.
*       lv_h2     = wa_sbsid-dmbtr.
      wa_sbsid-closing = v_closing + wa_sbsid-v_h2.
    ENDIF.
**********    add 25/01/2019
*    else.
*      wa_sbsid-closing = v_closing1 + wa_sbsid-hdmbtr.
*    endif.
***********    end 25/01/2019

*    IF wa_sbsid-dmbtr <> '0.00'."***********    add 25/01/2019
    v_closing = wa_sbsid-closing.
    lv_h2     = wa_sbsid-dmbtr.
*    endif.                      "***********    add 25/01/2019
*    if wa_sbsid-dmbtr = '0.00'.
*      v_closing1 = wa_sbsid-closing.
*    endif.
****************    end 25/01/2019

    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
      wa_sbsid-name1 = wa_kna1-name1.
    ENDIF.



    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
*****  Added to display Sales Office code and payment terms by Carina Jose on 16.12.2019
*      wa_sbsid-vkbur = wa_knvv-vkbur.
*      wa_sbsid-kvgr1 = wa_knvv-kvgr1.
*      wa_sbsid-kvgr2 = wa_knvv-kvgr2.


**      wa_sbsid-zterm = wa_knvv-zterm. """COMMENTED BY AKSHAY DT.23.07.2025
***** End of changes to display Sales Office code and payment terms  by Carina Jose on 16.12.2019
      READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_sbsid-vkbur.
      IF sy-subrc = 0.
        wa_sbsid-soffice = wa_tvkbt-bezei.
      ENDIF.
    ENDIF.
    wa_sbsid-wrbtr = wa_sbsid-dmbtr1.
************   due date
    READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
    IF sy-subrc = 0.
      zterm1 = wa_t052-ztag1.
      zterm = zterm1 + s_days.
    ENDIF.

    IF wa_sbsid-duedate IS INITIAL.
*      days = zterm. """COMMENTED BY AKSHAY DT.23.07.2025
      days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025
     IF  wa_sbsid-blart = 'UE'.
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
         date      = wa_sbsid-bldat
*          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
     ELSE.

      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
     ENDIF.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.
    ENDIF.
**********
**********************    payment Docuemnt header text add
    READ TABLE it_pbkpf INTO wa_pbkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-hbelnr budat = wa_sbsid-hdate.
    IF sy-subrc = 0.
      wa_sbsid-pbktxt = wa_pbkpf-bktxt.
    ENDIF.

    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-belnr budat = wa_sbsid-budat.
    IF sy-subrc = 0.
      wa_sbsid-bktxt = wa_bkpf-bktxt.
    ENDIF.
************
*        MOVE-CORRESPONDING wa_sbsid1 to wa_sbsid.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING closing v_h2 name1 soffice wrbtr duedate vkbur zterm bktxt pbktxt.
    CLEAR : wa_kna1,wa_sbsid,wa_tvkbt,wa_t052,wa_knvv,p_caldate1,p_caldate2,days,wa_bkpf,wa_pbkpf.

  ENDLOOP.

  lt_sbsid[] = it_sbsid[].

  LOOP AT lt_sbsid INTO lw_sbsid.
    v_invbal = v_invbal + lw_sbsid-v_h2.
    l_invbal = lw_sbsid-v_h2.
    l_budat  = lw_sbsid-budat.
    AT END OF belnr.
      wa_sbsid3-kunnr = lw_sbsid-kunnr.
      wa_sbsid3-belnr = lw_sbsid-belnr.
      wa_sbsid3-invbal = v_invbal.
      wa_sbsid3-linvbal = l_invbal.
      wa_sbsid3-budat =  l_budat.

      APPEND wa_sbsid3 TO it_sbsid3.
      CLEAR: wa_sbsid3,v_invbal,lw_sbsid,l_invbal,l_budat.
    ENDAT.
  ENDLOOP.

  LOOP AT it_sbsid INTO wa_sbsid.
*   at last .
    READ TABLE it_sbsid3 INTO wa_sbsid3 WITH KEY kunnr = wa_sbsid-kunnr
                                                 belnr = wa_sbsid-belnr
                                                 linvbal = wa_sbsid-v_h2.
    IF sy-subrc = 0.
      IF wa_sbsid-v_h2 <> '0.00'."invoice balnce amount
        IF wa_sbsid-wrbtr <> wa_sbsid3-invbal.
          wa_sbsid-invbalind = 'R'.
        ENDIF.
      ENDIF.
    ENDIF.
***************    for yet not paid amount
    IF wa_sbsid-hdate IS INITIAL .
*      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat."comment 22.08.2023
      IF WA_SBSID-BLART = 'UE'.
      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat. "added 22.08.2023
      ELSE.
      wa_sbsid-udays = s_bldat-high - wa_sbsid-budat. "added 22.08.2023
      ENDIF.
*      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate. "comment 22.08.2023
      IF WA_SBSID-BLART = 'UE'.
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-bldat. " added 22.08.2023
      else.
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-budat. " added 22.08.2023
      endif.
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
***********************    for remaining balance
    IF  wa_sbsid-invbalind = 'R'.
*      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat."comment 22.08.2023
      if wa_sbsid-blart = 'UE'.
      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat." added 22.08.2023
      ELSE.
      wa_sbsid-udays = s_bldat-high - wa_sbsid-budat." added 22.08.2023
      ENDIF.
*      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate." comment 22.08.2023
      if wa_sbsid-blart = 'UE'.
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-bldat.  "added 22.08.2023
      else.
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-budat.  "added 22.08.2023
      endif.
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
************

*   ON CHANGE OF wa_sbsid-belnr.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING invbalind uedays pint1 udays.
*   endon.
    CLEAR: wa_sbsid,wa_sbsid3.
*ENDAT.
  ENDLOOP.
*  loop at lt_sbsid
  """"""added by akshay dt.23.07.2025
  LOOP AT it_sbsid ASSIGNING FIELD-SYMBOL(<lf_sbsid>).
    AT NEW kunnr.
      CALL FUNCTION 'CUSTOMER_OPEN_ITEMS'
        EXPORTING
          bukrs         = <lf_sbsid>-bukrs
          kunnr         = <lf_sbsid>-kunnr
        TABLES
          t_postab      = lt_openitems[]
        EXCEPTIONS
          no_open_items = 1
          OTHERS        = 2.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      DELETE lt_openitems WHERE umskz = '5'.

      LOOP AT lt_openitems ASSIGNING <ls_openitems>.
        <lf_sbsid>-outstanding_amount = <lf_sbsid>-outstanding_amount + <ls_openitems>-dmshb.
      ENDLOOP.
    ENDAT.
  ENDLOOP.

  """"""eoc dt.23.07.2025

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_LISTHEADER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_listheader .
  DATA : frmdt(10)  TYPE c,
         todt(10)   TYPE c,
         v_str(200) TYPE c.
*  IF chk <> 'X'.
  t_listheader-typ = 'S'.
  t_listheader-key = ' '.
  t_listheader-info = 'PENAL INTREST REPORT (Based on Document Date)'.
  APPEND t_listheader.


  IF s_bldat-low NE '00000000' AND  s_bldat-high NE '00000000'      .
    WRITE s_bldat-low  TO frmdt USING EDIT MASK '__.__.____'.
    WRITE s_bldat-high TO todt  USING EDIT MASK '__.__.____'.
    CONCATENATE 'FROM'
                 frmdt
                 'TO'
                 todt
           INTO v_str SEPARATED BY space.
  ELSEIF s_bldat-low NE '00000000' AND  s_bldat-high EQ '00000000'      .
    WRITE s_bldat-low  TO frmdt USING EDIT MASK '__.__.____'.
    CONCATENATE 'ON'
                 frmdt
           INTO v_str SEPARATED BY space.
  ELSEIF s_bldat-low EQ '00000000' AND  s_bldat-high NE '00000000'      .
    WRITE s_bldat-high  TO todt USING EDIT MASK '__.__.____'.
    CONCATENATE 'ON'
                 todt
           INTO v_str SEPARATED BY space.
  ENDIF.
  t_listheader-typ = 'S'.
  t_listheader-key = ' '.
  t_listheader-info = v_str.
  APPEND t_listheader.

  IF chk = 'X'.
    WRITE p_bldat TO frmdt USING EDIT MASK '__.__.____'.
    CONCATENATE 'Interest calculation from' frmdt 'for op.balance items' INTO v_str SEPARATED BY space.
    t_listheader-typ = 'S'.
    t_listheader-key = ' '.
    t_listheader-info = v_str.
    APPEND t_listheader.
  ENDIF.





ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'KUNNR'               'Customer Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'NAME1'               'Customer Name'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'BLDAT'               'Document Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*****  Added to display Sales Office code by Carina Jose on 16.12.2019
  PERFORM fieldcat_append  USING  'VKBUR'               'Sales Office Code'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*****  End of changes to display Sales Office code by Carina Jose on 16.12.2019
  PERFORM fieldcat_append  USING  'SOFFICE'               'Sales Head'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'BELNR'               'Document Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'XBLNR'               'ODN No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'BUDAT'               'Posting Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'DUEDATE'               'Due Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'BLART'               'Doucment Type'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'XREF1'               'Reference Key 1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING 'BKTXT'               'Header text'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'WRBTR'               'Invoice Amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'DMBTR'               'Interest base amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'V_H1'               'Cleared amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'V_H2'               'Invoice balance amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'INTRATE'             'Intrest Rate'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'XBLNR'               'ODN No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'AUGDT'               'Clearing Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'HDATE'               'Payment Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'HBELNR'              'Payment Document Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'HWRBTR'               'Payment Amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'HDMBTR'               'Payment balance amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'HBLART'               'Payment Type'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'DAYS'               'Payment Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       ."""COMMENTED BY AKSHAY DT.23.07.2025
*  PERFORM fieldcat_append  USING  'ZBD1T'               'Payment Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       ."""ADDED BY AKSHAY DT.23.07.2025
*****  Added to display  payment terms by Carina Jose on 16.12.2019
  PERFORM fieldcat_append  USING  'ZTERM'               'Payment Terms'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'ZUONR'               'Refrence No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
***** End of changes to  payment terms  by Carina Jose on 16.12.2019
  PERFORM fieldcat_append  USING  'PBKTXT'               'Payment header text'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*  PERFORM fieldcat_append  USING  'KDGRP'               'Customer Group Code'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'KVGR1'               'Customer Group Code 1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'KVGR2'               'Customer Group Code 2'                'X'  'IT_SBSID'   ' '    ' '  ' '       .

  PERFORM fieldcat_append  USING  'IDAYS'               'Exceeds Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'IPDAYS'              'Exceeds Days-1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'ZSTD_DAYS_F'         'Standard Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'ZSTD_DAYS'            'Exceeds Days-1 - Standard Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'PINT'               'Penal Intrest'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*  PERFORM fieldcat_append  USING  'OIPINT'               'Open Invoice Penal Intrest'                'X'  'IT_SBSID'   ' '    ' '  ' '       ."""added by akshay dt.30.08.2025
  PERFORM fieldcat_append  USING  'UDAYS'               'Unpaid Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'UEDAYS'               'Unpaid Exceeds Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'PINT1'               'Penal Intrest-Payment not Received yet'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'INVBALIND'               'Ind'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'CLOSING'               'Cumulative balance'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*  PERFORM fieldcat_append  USING  'ZLEGAL_REMARK'               'Legal Remark'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append  USING  'OUTSTANDING_AMOUNT'               'Outstanding amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
*  PERFORM fieldcat_append  USING  'CUST_GROUP'               'Customer Group Txt'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append  USING  'CUST_GROUP1'               'Customer Group Txt 1'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append  USING  'CUST_GROUP2'               'Customer Group Txt 2'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_1158   text
*      -->P_1159   text
*      -->P_1160   text
*      -->P_1161   text
*      -->P_1162   text
*      -->P_1163   text
*      -->P_1164   text
*----------------------------------------------------------------------*
FORM fieldcat_append USING VALUE(p_fname)
                           VALUE(p_ftext)
                           VALUE(p_fixcol)
                           VALUE(p_table)
                           VALUE(p_dosum)
                           VALUE(p_hotspot)
                           VALUE(p_length).

  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  t_fieldcatalog-do_sum      = p_dosum.
  t_fieldcatalog-hotspot     = p_hotspot.
  t_fieldcatalog-outputlen   = p_length.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_layout .
  t_event-name = slis_ev_top_of_page.
  t_event-form = 'TOP_OF_PAGE'.
  APPEND t_event.
  fs_layout-colwidth_optimize = 'X'.
ENDFORM. " FILL_LAYOUT

*&---------------------------------------------------------------------*
*&      FORM  TOP_OF_PAGE                                              *
*&---------------------------------------------------------------------*
FORM top_of_page.
  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = t_listheader[].

ENDFORM. " TOP_OF_PAGE
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-repid
      i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout              = fs_layout
      it_fieldcat            = t_fieldcatalog[]
      it_events              = t_event[]
      i_save                 = 'A'
    TABLES
      t_outtab               = it_sbsid
    EXCEPTIONS
      program_error          = 1
      OTHERS                 = 2.
  IF sy-subrc <> 0.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT bukrs
  INTO TABLE it_bukrs
   FROM t001
WHERE bukrs IN s_bukrs.

  LOOP AT it_bukrs INTO wa_bukrs.
    AUTHORITY-CHECK OBJECT 'Z_PINT_BUK'
    ID 'BUKRS' FIELD wa_bukrs-bukrs
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc NE 0.
*      MESSAGE 'YOU ARE NOT AUTHORIZED FOR THIS COMAPNY CODE' TYPE 'E'.
      MESSAGE e014(zsd) WITH wa_bukrs-bukrs.
    ENDIF.
  ENDLOOP.

  AUTHORITY-CHECK OBJECT 'Z_PINT_VKG'
  ID 'VKORG' FIELD p_vkorg
  ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e013(zsd) WITH p_vkorg.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_CUST_OPEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_cust_open .
  p_bldat = s_bldat-low.
  CLEAR: s_int.

  CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
    EXPORTING
      begda    = s_bldat-low
      endda    = s_bldat-high
    IMPORTING
      c_months = zmonth.
  zmonth = zmonth + 1.

  SELECT sign
          opti
          low high
            FROM tvarvc  INTO TABLE it_tvarv
               WHERE name = c_var_namep.

  IF zmonth LE '12'.
    SELECT kunnr,vkorg
      FROM knvv
      INTO TABLE @DATA(it_knvv1)
      WHERE kunnr IN @s_kunnr
      AND   vkorg = @p_vkorg.
*      AND spart IN @s_spart. """added by akshay dt.23.07.2025
    """added by akshay dt.23.07.2025
    SELECT * FROM zfi_legal_case INTO TABLE @DATA(it_legal_case) FOR ALL ENTRIES IN @it_knvv1
      WHERE kunnr = @it_knvv1-kunnr AND vkorg = @it_knvv1-vkorg.
    """eoc dt.23.07.2025


    IF it_knvv1 IS NOT INITIAL.

      SELECT kunnr belnr bldat shkzg  budat
              blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm  FROM bsid INTO TABLE it_sbsid
                                                    FOR ALL ENTRIES IN it_knvv1
                                                    WHERE bukrs IN s_bukrs
*                                                  AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                    AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN s_umskz
                                                    AND budat LT s_bldat-low.
*                                                    AND shkzg = 'S'.

    ENDIF.
  ELSE.
    MESSAGE 'DATE RANGE IS MAXIMUM ONE YEAR' TYPE 'E'.
  ENDIF.

  IF it_sbsid IS NOT INITIAL.
*    SELECT kunnr zterm vkbur kdgrp FROM knvv INTO TABLE it_knvv
    SELECT kunnr zterm vkbur kvgr1 kvgr2 FROM knvv INTO TABLE it_knvv
    FOR ALL ENTRIES IN it_sbsid
     WHERE kunnr = it_sbsid-kunnr
     AND   vkorg = p_vkorg. " Added by Carina Jose on 03.03.2022


* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
    SORT it_knvv BY kunnr.

* End of Quick Fix
    SELECT kunnr name1 FROM kna1 INTO TABLE it_kna1
       FOR ALL ENTRIES IN it_sbsid
       WHERE kunnr = it_sbsid-kunnr.
  ENDIF.

  DELETE ADJACENT DUPLICATES FROM it_knvv COMPARING kunnr.
  IF it_knvv IS NOT INITIAL.
    SELECT * FROM tvkbt INTO TABLE it_tvkbt
      FOR ALL ENTRIES IN it_knvv
      WHERE vkbur = it_knvv-vkbur.
  ENDIF.

  SELECT * FROM t052 INTO TABLE it_t052 FOR ALL ENTRIES IN it_knvv WHERE zterm = it_knvv-zterm.

  SELECT * FROM zcr_matx_new INTO TABLE it_matrix.

  SORT it_sbsid BY kunnr belnr bldat.
  SELECT * FROM zfi_mis_kdgrp  INTO TABLE @DATA(gt_div)  WHERE vkorg = @p_vkorg. "AND kdgrp = @it_knvv-kdgrp.

  SELECT * FROM tvv1t INTO TABLE @DATA(gt_tvv1t) FOR ALL ENTRIES IN @it_knvv WHERE kvgr1 = @it_knvv-kvgr1 AND spras = 'E'.
  SELECT * FROM tvv2t INTO TABLE @DATA(gt_tvv2t) FOR ALL ENTRIES IN @it_knvv WHERE kvgr2 = @it_knvv-kvgr2 AND spras = 'E'.

  LOOP AT  it_sbsid INTO wa_sbsid ."WHERE kunnr = wa_hbsid-kunnr AND belnr = wa_hbsid-belnr AND bldat = wa_hbsid-bldat.
    """""added by akshay dt.23.07.2025
    READ TABLE  it_legal_case INTO DATA(wa_legal_case) WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
      wa_sbsid-zlegal_remark = 'Yes'.
    ENDIF.

    """""eoc dt.23.07.2025

    """""added by akshay dt.20.08.2025
*    READ TABLE  gt_div INTO DATA(wa_div) WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*    IF sy-subrc = 0.
*      wa_sbsid-cust_group = wa_div-txt.
*    ENDIF.

    READ TABLE gt_tvv1t INTO DATA(ls_tvv1t) WITH KEY kvgr1 = wa_sbsid-kvgr1.
    IF sy-subrc = 0.
      wa_sbsid-cust_group1 = ls_tvv1t-bezei.
    ENDIF.
    READ TABLE gt_tvv2t INTO DATA(ls_tvv2t) WITH KEY kvgr2 = wa_sbsid-kvgr2.
    IF sy-subrc = 0.
      wa_sbsid-cust_group2 = ls_tvv2t-bezei.
    ENDIF.

    READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_sbsid-vkbur.
    IF sy-subrc = 0.
      wa_sbsid-soffice = wa_tvkbt-bezei.
    ENDIF.

    """""eoc dt.20.07.2025
    wa_sbsid-umskz = wa_sbsid-umskz.
    wa_sbsid-blart = wa_sbsid-blart.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING umskz blart zlegal_remark cust_group1 cust_group2.
    CLEAR: wa_sbsid.
  ENDLOOP.

  IF s_umskz IS NOT INITIAL.
    DELETE it_sbsid WHERE umskz IN s_umskz.
  ENDIF.

  IF s_blart IS NOT INITIAL.
    DELETE it_sbsid WHERE blart = s_blart.
  ENDIF.
  SORT it_sbsid BY kunnr bldat belnr.



  LOOP AT it_sbsid INTO wa_sbsid ."WHERE kunnr = wa_hbsid-kunnr AND ind <> 'Y' AND dmbtr <> '0.00'.

*    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
*    IF sy-subrc = 0.
*      wa_sbsid-kvgr2 = wa_knvv-kvgr2.
*    ENDIF.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE KDGRP_AUFT , vkbur FROM VBRP INTO @Data(wa_vbrp) WHERE vbeln = @wa_sbsid-XBLNR.

*    SELECT kdgrp_auft , vkbur FROM vbrp INTO @DATA(wa_vbrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*    SELECT kvgr2 , vkbur FROM vbrp INTO @DATA(wa_vbrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*     ORDER BY PRIMARY KEY .
*    ENDSELECT.

* End of Quick Fix

*      wa_sbsid-vkbur = wa_vbrp-vkbur.
*      wa_sbsid-kvgr2 = wa_vbrp-kvgr2.
*      READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_vbrp-vkbur.
*      IF sy-subrc = 0.
*        wa_sbsid-soffice = wa_tvkbt-bezei.
*      ENDIF.

    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
      wa_sbsid-name1 = wa_kna1-name1.
    ENDIF.

***      READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
***      IF sy-subrc = 0.
***        zterm1 = wa_t052-ztag1.
***        zterm = zterm1 + s_days.
***      ENDIF.
*    ENDIF.
******************      logic add 24/01/2019
    DATA: p_caldate TYPE sy-datum.
    DATA: p_caldate1 TYPE sy-datum.
    DATA: p_caldate2 TYPE bsid-budat.
    DATA: days LIKE t5a4a-dlydy.
*      days = zterm. """COMMENTED BY AKSHAY DT.23.07.2025
    days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025

    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
*       date      = wa_sbsid-bldat
        date      = wa_sbsid-budat
        days      = days
        months    = 00
        signum    = '+'
        years     = 00
      IMPORTING
        calc_date = p_caldate1.

    p_caldate2 = p_caldate1.
    wa_sbsid-duedate = p_caldate2.
    """"added by akshay dt.30.08.2025
    DATA:lv_pint TYPE c.
    CLEAR:lv_pint.
    IF wa_sbsid-duedate IS INITIAL.
      wa_sbsid-duedate = s_bldat-high.
      lv_pint = abap_true.
    ENDIF.
    """"eoc dt.30.08.2025
*      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-budat. "added 05.10.2023

    wa_sbsid-idays = p_bldat - wa_sbsid-duedate.
    wa_sbsid-ipdays = p_bldat - wa_sbsid-duedate.
    wa_sbsid-days = p_bldat - wa_sbsid-duedate.
    IF wa_sbsid-idays < 0.
      wa_sbsid-idays = 0.
    ENDIF.

    LOOP AT it_matrix INTO wa_matrix WHERE zkvgr1 = wa_sbsid-kvgr1 AND zkvgr2 = wa_sbsid-kvgr2. "wa_sbsid-kdgrp.

      IF wa_matrix-zday_to IS NOT INITIAL.
        IF wa_sbsid-ipdays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
          s_int = wa_matrix-zyr_per.
          wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
        ENDIF.
      ENDIF.
      IF wa_matrix-zday_to IS INITIAL.
        IF wa_sbsid-ipdays GE wa_matrix-zday_from.
          s_int = wa_matrix-zyr_per.
          wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
        ENDIF.
      ENDIF.
    ENDLOOP.

    wa_sbsid-zstd_days = wa_sbsid-ipdays - wa_sbsid-zstd_days_f.

    IF wa_sbsid-zstd_days  > 0.

      wa_sbsid-int = ( v_calc * s_int ) / 100.

      IF lv_pint = abap_true.   """added by akshay dt.30.08.2025
        wa_sbsid-oipint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365. """added by akshay dt.30.08.2025
      ELSE. """added by akshay dt.30.08.2025
        wa_sbsid-pint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365.
      ENDIF.  """added by akshay dt.30.08.2025
    ENDIF.
    wa_sbsid-intrate =  s_int.
    dmbtr1 = wa_sbsid-dmbtr1.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING days  idays ipdays pint soffice name1  intrate  duedate vkbur zterm zstd_days
           kvgr1 kvgr2 zstd_days_f int.

*  ENDIF.
    SORT it_sbsid BY kunnr bldat belnr hdate hbelnr.
    CLEAR:v_s,v_h,wa_sbsid,wa_hbsid,zterm,zterm1,wa_t052,wa_kna1,wa_tvkbt,days,p_caldate1,p_caldate,wa_matrix,s_int,wa_tvarv,zstd_days.
*    EXIT.

  ENDLOOP.

**************************************** 23.07.2025 comment
*  DELETE it_sbsid WHERE ind = 'N'.
*
**  *************************** Payment header text add
*  SELECT bukrs belnr budat bktxt
*    FROM bkpf INTO TABLE it_pbkpf
*     FOR ALL ENTRIES IN it_sbsid
*      WHERE bukrs = it_sbsid-bukrs
*      AND   belnr = it_sbsid-hbelnr
*      AND   budat = it_sbsid-hdate.
*
*  SELECT bukrs belnr budat bktxt
*    FROM bkpf INTO TABLE it_bkpf
*     FOR ALL ENTRIES IN it_sbsid
*      WHERE bukrs = it_sbsid-bukrs
*      AND   belnr = it_sbsid-belnr
*      AND   budat = it_sbsid-budat.
*************************
*
  LOOP AT it_sbsid INTO wa_sbsid.
*
*    IF wa_sbsid-v_h1 = '0.00'.
*      wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
*    ENDIF.
*
*    IF wa_sbsid-v_h1 NE '0.00'.
*      wa_sbsid-closing = wa_sbsid-v_h2 - wa_sbsid-hdmbtr.
*    ELSE.
*
*      wa_sbsid-closing = v_closing + wa_sbsid-v_h2.
*    ENDIF.
*    v_closing = wa_sbsid-closing.
*    lv_h2     = wa_sbsid-dmbtr.
*
*    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
*    IF sy-subrc = 0.
*      wa_sbsid-name1 = wa_kna1-name1.
*    ENDIF.
*
*    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
*    IF sy-subrc = 0.
*      wa_sbsid-vkbur = wa_knvv-vkbur.
*      READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_knvv-vkbur.
*      IF sy-subrc = 0.
*        wa_sbsid-soffice = wa_tvkbt-bezei.
*      ENDIF.
*    ENDIF.
*    wa_sbsid-wrbtr = wa_sbsid-dmbtr1.
*
*    READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
*    IF sy-subrc = 0.
*      zterm1 = wa_t052-ztag1.
*      zterm = zterm1 + s_days.
*    ENDIF.
*
    IF wa_sbsid-duedate IS INITIAL.
      days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.
    ENDIF.
***********
***********************    payment Docuemnt header text add
*    READ TABLE it_pbkpf INTO wa_pbkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-hbelnr budat = wa_sbsid-hdate.
*    IF sy-subrc = 0.
*      wa_sbsid-pbktxt = wa_pbkpf-bktxt.
*    ENDIF.
*
*    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-belnr budat = wa_sbsid-budat.
*    IF sy-subrc = 0.
*      wa_sbsid-bktxt = wa_bkpf-bktxt.
*    ENDIF.
*************
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING duedate.
*    CLEAR : wa_kna1,wa_sbsid,wa_tvkbt,wa_t052,wa_knvv,p_caldate1,p_caldate2,days,wa_bkpf,wa_pbkpf.
*
  ENDLOOP.
*
*  lt_sbsid[] = it_sbsid[].
*
*  LOOP AT lt_sbsid INTO lw_sbsid.
*    v_invbal = v_invbal + lw_sbsid-v_h2.
*    l_invbal = lw_sbsid-v_h2.
*    l_budat  = lw_sbsid-budat.
*    AT END OF belnr.
*      wa_sbsid3-kunnr = lw_sbsid-kunnr.
*      wa_sbsid3-belnr = lw_sbsid-belnr.
*      wa_sbsid3-invbal = v_invbal.
*      wa_sbsid3-linvbal = l_invbal.
*      wa_sbsid3-budat =  l_budat.
*
*      APPEND wa_sbsid3 TO it_sbsid3.
*      CLEAR: wa_sbsid3,v_invbal,lw_sbsid,l_invbal,l_budat.
*    ENDAT.
*  ENDLOOP.
*
  LOOP AT it_sbsid INTO wa_sbsid.
*   at last .
    READ TABLE it_sbsid3 INTO wa_sbsid3 WITH KEY kunnr = wa_sbsid-kunnr
                                                 belnr = wa_sbsid-belnr
                                                 linvbal = wa_sbsid-v_h2.
    IF sy-subrc = 0.
      IF wa_sbsid-v_h2 <> '0.00'."invoice balnce amount
        IF wa_sbsid-wrbtr <> wa_sbsid3-invbal.
          wa_sbsid-invbalind = 'R'.
        ENDIF.
      ENDIF.
    ENDIF.
****************    for yet not paid amount
    IF wa_sbsid-hdate IS INITIAL .
      wa_sbsid-udays = s_bldat-high - wa_sbsid-budat. "added 22.08.2023
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-budat. " added 22.08.2023
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
************************    for remaining balance
    IF  wa_sbsid-invbalind = 'R'.
*      wa_sbsid-udays = s_bldat-high - wa_sbsid-budat." added 22.08.2023
      wa_sbsid-udays = s_bldat-high - wa_sbsid-budat." added 22.08.2023

      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-budat.  "added 22.08.2023
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING invbalind uedays pint1 udays.
    CLEAR: wa_sbsid,wa_sbsid3.

  ENDLOOP.

  """"""added by akshay dt.23.07.2025
  LOOP AT it_sbsid ASSIGNING FIELD-SYMBOL(<lf_sbsid>).
    AT NEW kunnr.
      CALL FUNCTION 'CUSTOMER_OPEN_ITEMS'
        EXPORTING
          bukrs         = <lf_sbsid>-bukrs
          kunnr         = <lf_sbsid>-kunnr
        TABLES
          t_postab      = lt_openitems[]
        EXCEPTIONS
          no_open_items = 1
          OTHERS        = 2.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      DELETE lt_openitems WHERE umskz = '5'.

      LOOP AT lt_openitems ASSIGNING <ls_openitems>.
        <lf_sbsid>-outstanding_amount = <lf_sbsid>-outstanding_amount + <ls_openitems>-dmshb.
      ENDLOOP.
    ENDAT.
  ENDLOOP.

  """"""eoc dt.23.07.2025
ENDFORM.

FORM fieldcat_append_open USING VALUE(p_fname)
                           VALUE(p_ftext)
                           VALUE(p_fixcol)
                           VALUE(p_table)
                           VALUE(p_dosum)
                           VALUE(p_hotspot)
                           VALUE(p_length).

  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  t_fieldcatalog-do_sum      = p_dosum.
  t_fieldcatalog-hotspot     = p_hotspot.
  t_fieldcatalog-outputlen   = p_length.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG_OPEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog_open .
  PERFORM fieldcat_append_open  USING  'KUNNR'               'Customer Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'NAME1'               'Customer Name'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'BLDAT'               'Document Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*****  Added to display Sales Office code by Carina Jose on 16.12.2019
  PERFORM fieldcat_append_open  USING  'VKBUR'               'Sales Office Code'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*****  End of changes to display Sales Office code by Carina Jose on 16.12.2019
  PERFORM fieldcat_append_open  USING  'SOFFICE'               'Sales Head'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'BELNR'               'Document Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'XBLNR'               'ODN No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'BUDAT'               'Posting Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'DUEDATE'               'Due Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'BLART'               'Doucment Type'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'XREF1'               'Reference Key 1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING 'BKTXT'               'Header text'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'WRBTR'               'Invoice Amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'DMBTR'               'Interest base amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'V_H1'               'Cleared amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'V_H2'               'Invoice balance amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'INTRATE'             'Intrest Rate'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'XBLNR'               'ODN No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'AUGDT'               'Clearing Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'HDATE'               'Payment Date'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'HBELNR'              'Payment Document Number'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'HWRBTR'               'Payment Amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'HDMBTR'               'Payment balance amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'HBLART'               'Payment Type'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append  USING  'DAYS'               'Payment Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       ."""COMMENTED BY AKSHAY DT.23.07.2025
*  PERFORM fieldcat_append_open  USING  'ZBD1T'               'Payment Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       ."""ADDED BY AKSHAY DT.23.07.2025
*****  Added to display  payment terms by Carina Jose on 16.12.2019
  PERFORM fieldcat_append_open  USING  'ZTERM'               'Payment Terms'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'ZUONR'               'Refrence No.'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
***** End of changes to  payment terms  by Carina Jose on 16.12.2019
  PERFORM fieldcat_append_open  USING  'PBKTXT'               'Payment header text'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
*  PERFORM fieldcat_append_open  USING  'KDGRP'               'Customer Group Code'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'KVGR1'               'Cust Grp1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'KVGR2'               'Cust Grp2'                'X'  'IT_SBSID'   ' '    ' '  ' '       .

  PERFORM fieldcat_append_open  USING  'IDAYS'               'Exceeds Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'IPDAYS'              'Exceeds Days-1'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'OPEDAYS'              'Open Item Exceeds days = ( Unpaid Exceeds Days - Standard Days )'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'ZSTD_DAYS_F'         'Standard Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'ZSTD_DAYS'            'Exceeds Days-1 - Standard Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'PINT'               'Penal Intrest'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'PINT_O'               'Open Item Penal Intrest'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'UDAYS'               'Unpaid Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'UEDAYS'               'Unpaid Exceeds Days'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'PINT1'               'Penal Intrest-Payment not Received yet'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'INVBALIND'               'Ind'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'CLOSING'               'Cumulative balance'                'X'  'IT_SBSID'   ' '    ' '  ' '       .
  PERFORM fieldcat_append_open  USING  'ZLEGAL_REMARK'               'Legal Remark'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append_open  USING  'OUTSTANDING_AMOUNT'               'Outstanding amount'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append  USING  'CUST_GROUP1'               'Cust Group2 Txt'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025
  PERFORM fieldcat_append  USING  'CUST_GROUP2'               'Cust Group1 Txt'                'X'  'IT_SBSID'   ' '    ' '  ' '       . """added by akshay dt.23.07.2025

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_CUST1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_cust1 .
  p_bldat = s_bldat-low.
  CLEAR: s_int.

  CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
    EXPORTING
      begda    = s_bldat-low
      endda    = s_bldat-high
*     TAB_MODE = ' '
*     IV_LEAP_YEAR_MODE       =
    IMPORTING
*     DAYS     = zdays
*     C_WEEKS  =
      c_months = zmonth
*     C_YEARS  =
*     WEEKS    =
*     MONTHS   =
*     YEARS    =
*     D_MONTHS =
*     MONTH_TAB               =
    .
  zmonth = zmonth + 1.

  SELECT sign
          opti
          low high
            FROM tvarvc  INTO TABLE it_tvarv
               WHERE name = c_var_namep.

  SELECT sign
        opti
        low high
          FROM tvarvc  INTO TABLE it_biltyp
             WHERE name = c_var_name1.

**************Added by Raj on 10.10.2023**************************
*********for opening
***  IF zmonth LE '12'. """commented by akshay dt.19.09.2025
**** Added by Carina Jose on 03.03.2022
  SELECT kunnr,vkorg
    FROM knvv
    INTO TABLE @DATA(it_knvv1)
    WHERE kunnr IN @s_kunnr
    AND   vkorg = @p_vkorg.
*      AND spart IN @s_spart. """added by akshay dt.23.07.2025
**** End of changes by Carina Jose on 03.03.2022
  """added by akshay dt.23.07.2025
  SELECT * FROM zfi_legal_case INTO TABLE @DATA(it_legal_case) FOR ALL ENTRIES IN @it_knvv1
    WHERE kunnr = @it_knvv1-kunnr AND vkorg = @it_knvv1-vkorg.
  """eoc dt.23.07.2025


  IF it_knvv1 IS NOT INITIAL. " Added by Carina Jose on 03.03.2022

    SELECT kunnr belnr bldat shkzg  budat
            blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid INTO TABLE it_sbsid
                                                  FOR ALL ENTRIES IN it_knvv1
                                                  WHERE bukrs IN s_bukrs
*                                                  AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                  AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN s_umskz
                                                  AND budat LT s_bldat-low
                                                  AND shkzg = 'S'.

    SELECT kunnr belnr bldat shkzg  budat
            blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_sbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                  WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                  AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN  s_umskz
                                                  AND budat LT s_bldat-low
                                                  AND augdt GE s_bldat-low
                                                  AND shkzg = 'S'.

    SELECT kunnr belnr bldat shkzg  budat
           blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid INTO TABLE it_hbsid
                                                  FOR ALL ENTRIES IN it_knvv1
                                                 WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                 AND umskz IN s_umskz
                                                 AND budat LT s_bldat-low
                                                 AND shkzg = 'H'.

    SELECT kunnr belnr bldat shkzg  budat
            blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_hbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                  WHERE bukrs IN s_bukrs
*                                                 AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                  AND umskz IN s_umskz
                                                  AND budat LT s_bldat-low
                                                  AND augdt GE s_bldat-low
                                                  AND shkzg = 'H'.

*********** for line item
    SELECT kunnr belnr bldat shkzg  budat
             blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_sbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                   WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                   AND umskz IN s_umskz
                                                   AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                   AND shkzg = 'S'.

    SELECT kunnr belnr bldat shkzg  budat
          blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsad APPENDING TABLE it_hbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                AND umskz IN s_umskz
                                                AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                AND shkzg = 'H'.

    SELECT kunnr belnr bldat shkzg  budat
             blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid APPENDING TABLE it_sbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                   WHERE bukrs IN s_bukrs
*                                                   AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                   AND umskz IN s_umskz
                                                   AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                               AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                   AND shkzg = 'S'.

    SELECT kunnr belnr bldat shkzg  budat
          blart xref1 bukrs dmbtr wrbtr xblnr augdt umskz zbd1t zterm zuonr FROM bsid APPENDING TABLE it_hbsid
                                                 FOR ALL ENTRIES IN it_knvv1
                                                WHERE bukrs IN s_bukrs
*                                                AND kunnr IN s_kunnr "Commented on 03.03.2022
                                                 AND kunnr = it_knvv1-kunnr "Added on 03.03.2022
*                                                AND umskz IN s_umskz
                                                AND budat BETWEEN s_bldat-low AND s_bldat-high
*                                              AND augdt BETWEEN s_bldat-low AND s_bldat-high
                                                AND shkzg = 'H'.
*

*
  ENDIF. " Added by Carina Jose on 03.03.2022
********************************  11.06.2021 for date
*  ELSE.  """commented by akshay dt.19.09.2025
*    MESSAGE 'DATE RANGE IS MAXIMUM ONE YEAR' TYPE 'E'. """commented by akshay dt.19.09.2025
*  ENDIF. """commented by akshay dt.19.09.2025


  IF it_sbsid IS NOT INITIAL.
    SELECT kunnr zterm vkbur kvgr1 kvgr2 FROM knvv INTO TABLE it_knvv
    FOR ALL ENTRIES IN it_sbsid
     WHERE kunnr = it_sbsid-kunnr
     AND   vkorg = p_vkorg. " Added by Carina Jose on 03.03.2022

    "Start of change by Ranjan 30.10.2025

* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
    SORT it_knvv BY kunnr.

* End of Quick Fix
    " " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*SELECT vbeln, xblnr
*     FROM vbrk
*     INTO TABLE @DATA(it_vbrk)
*     FOR ALL ENTRIES IN @it_sbsid
*     WHERE xblnr = @it_sbsid-xblnr
*       AND fkart IN @it_biltyp.
    SELECT  billingdocument AS vbeln , documentreferenceid AS xblnr FROM
   i_billingdocumentbasic INTO TABLE  @DATA(it_vbrk) FOR  ALL
   ENTRIES  IN  @it_sbsid  WHERE documentreferenceid = @it_sbsid-xblnr AND
*   ENTRIES  IN  @it_sbsid  WHERE documentreferenceid = @it_sbsid-zuonr AND
   billingdocumenttype IN @it_biltyp.
    " " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    "End of change by Ranjan 30.10.2025

    SELECT kunnr name1 FROM kna1 INTO TABLE it_kna1
   FOR ALL ENTRIES IN it_sbsid
   WHERE kunnr = it_sbsid-kunnr.
  ENDIF.

  IF it_hbsid IS NOT INITIAL.
    SELECT kunnr zterm vkbur FROM knvv APPENDING TABLE it_knvv
     FOR ALL ENTRIES IN it_hbsid
      WHERE kunnr = it_hbsid-kunnr
      AND   vkorg = p_vkorg. " Added by Carina Jose on 03.03.2022

* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
    SORT it_knvv BY kunnr.

* End of Quick Fix
  ENDIF.


  DELETE ADJACENT DUPLICATES FROM it_knvv COMPARING kunnr.
  IF it_knvv IS NOT INITIAL.
    SELECT * FROM tvkbt INTO TABLE it_tvkbt
      FOR ALL ENTRIES IN it_knvv
      WHERE vkbur = it_knvv-vkbur.
  ENDIF.





  SELECT * FROM t052 INTO TABLE it_t052 FOR ALL ENTRIES IN it_knvv WHERE zterm = it_knvv-zterm.

  SELECT * FROM zcr_matx_new INTO TABLE it_matrix.

  SELECT * FROM zfi_mis_kdgrp  INTO TABLE @DATA(gt_div) WHERE vkorg = @p_vkorg. """added by akshay dt.20.08.2025

  SELECT * FROM tvv1t INTO TABLE @DATA(gt_tvv1t) FOR ALL ENTRIES IN @it_knvv WHERE kvgr1 = @it_knvv-kvgr1 AND spras = 'E'.
  SELECT * FROM tvv2t INTO TABLE @DATA(gt_tvv2t) FOR ALL ENTRIES IN @it_knvv WHERE kvgr2 = @it_knvv-kvgr2 AND spras = 'E'.

  SORT it_sbsid BY kunnr belnr bldat.
  SORT it_hbsid BY kunnr belnr bldat.




  LOOP AT it_hbsid INTO wa_hbsid.
    LOOP AT  it_sbsid INTO wa_sbsid WHERE kunnr = wa_hbsid-kunnr AND belnr = wa_hbsid-belnr AND bldat = wa_hbsid-bldat.
      """""added by akshay dt.23.07.2025
      READ TABLE  it_legal_case INTO DATA(wa_legal_case) WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
        wa_sbsid-zlegal_remark = 'Yes'.
      ENDIF.

      """""eoc dt.23.07.2025

      """""added by akshay dt.20.08.2025
*      READ TABLE  gt_div INTO DATA(wa_div) WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        wa_sbsid-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO DATA(ls_tvv1t) WITH KEY kvgr1 = wa_sbsid-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO DATA(ls_tvv2t) WITH KEY kvgr2 = wa_sbsid-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.


      """""eoc dt.20.07.2025

      wa_sbsid-umskz = wa_hbsid-umskz.
      wa_sbsid-blart = wa_hbsid-blart.
      MODIFY it_sbsid FROM wa_sbsid TRANSPORTING umskz blart zlegal_remark cust_group1 cust_group2.
      CLEAR: wa_sbsid.
    ENDLOOP.
    CLEAR: wa_hbsid.
  ENDLOOP.
*****
**************** add logic for club document number amount
  LOOP AT it_sbsid INTO wa_sbsid.
    wa_sbsid-dmbtr2 = wa_sbsid-dmbtr.
    wa_sbsid-wrbtr2 = wa_sbsid-wrbtr.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING dmbtr2 wrbtr2.
    MOVE-CORRESPONDING wa_sbsid TO wa_shbsid.
    APPEND wa_shbsid TO it_shbsid.
  ENDLOOP.

  LOOP AT it_hbsid INTO wa_hbsid.
    wa_hbsid-dmbtr2 = wa_hbsid-dmbtr * -1.
    wa_hbsid-wrbtr2 = wa_hbsid-wrbtr * -1.
    MODIFY it_hbsid FROM wa_hbsid TRANSPORTING dmbtr2 wrbtr2.
    MOVE-CORRESPONDING wa_hbsid TO wa_shbsid.
    APPEND wa_shbsid TO it_shbsid.
  ENDLOOP.

  SORT it_shbsid BY kunnr bldat belnr.
********************
  LOOP AT it_shbsid INTO wa_shbsid.
    IF wa_shbsid-shkzg = 'S'.
      v_sdmbtr = v_sdmbtr + wa_shbsid-dmbtr2.
      v_swrbtr = v_swrbtr + wa_shbsid-wrbtr2.
    ELSE.
      v_hdmbtr = v_hdmbtr + wa_shbsid-dmbtr2.
      v_hwrbtr = v_hwrbtr + wa_shbsid-wrbtr2.
    ENDIF.
    v_bldat = wa_shbsid-bldat.
    v_shkzg = wa_shbsid-shkzg.
    v_budat = wa_shbsid-budat.
    v_blart = wa_shbsid-blart.
    v_bukrs1 = wa_shbsid-bukrs.
    v_xblnr = wa_shbsid-xblnr.
    v_augdt = wa_shbsid-augdt.
    v_umskz = wa_shbsid-umskz.
    v_umskz = wa_shbsid-umskz.
    v_zbd1t = wa_shbsid-zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
    v_zterm = wa_shbsid-zterm.  """"ADDED BY AKSHAY DT.23.07.2025
    wa_1sbsid-zuonr = wa_shbsid-zuonr.
    AT END OF belnr.
      wa_1hbsid-kunnr = wa_shbsid-kunnr.
      wa_1hbsid-belnr = wa_shbsid-belnr.
**      wa_1hbsid-zbd1t = v_zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
**      wa_1hbsid-zterm = v_zterm.  """"ADDED BY AKSHAY DT.23.07.2025
      wa_1hbsid-bldat = v_bldat.
      wa_1hbsid-shkzg = v_shkzg.
      wa_1hbsid-budat = v_budat.
      wa_1hbsid-blart = v_blart.
      wa_1hbsid-umskz = v_umskz.
      wa_1hbsid-bukrs = v_bukrs1.
      wa_1hbsid-dmbtr = v_hdmbtr + v_sdmbtr.
      wa_1hbsid-wrbtr = v_hwrbtr + v_swrbtr.
      wa_1hbsid-xblnr = v_xblnr.
      wa_1hbsid-augdt = v_augdt.
      IF wa_1hbsid-dmbtr < 0.
        IF wa_1hbsid-budat LE p_bldat.
          wa_1hbsid-opind = 'X'.
        ENDIF.
        wa_1hbsid-dmbtr = wa_1hbsid-dmbtr * -1.
        wa_1hbsid-wrbtr = wa_1hbsid-wrbtr * -1.
        APPEND wa_1hbsid TO it_1hbsid.

      ENDIF.
*    **********  for s
      wa_1sbsid-kunnr = wa_shbsid-kunnr.
      wa_1sbsid-belnr = wa_shbsid-belnr.
      wa_1sbsid-zbd1t = v_zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
      wa_1sbsid-zterm = v_zterm.  """"ADDED BY AKSHAY DT.23.07.2025
      wa_1sbsid-bldat = v_bldat.
      wa_1sbsid-shkzg = v_shkzg.
      wa_1sbsid-budat = v_budat.
      wa_1sbsid-blart = v_blart.
      wa_1sbsid-bukrs = v_bukrs1.
      wa_1sbsid-umskz = v_umskz.
      wa_1sbsid-dmbtr = v_hdmbtr + v_sdmbtr.
      wa_1sbsid-wrbtr = v_hwrbtr + v_swrbtr.
      wa_1sbsid-xblnr = v_xblnr.
      wa_1sbsid-augdt = v_augdt.
      IF wa_1sbsid-dmbtr > 0.

        IF wa_1sbsid-budat LE p_bldat.
          wa_1sbsid-opind = 'X'.
        ENDIF.

        APPEND wa_1sbsid TO it_1sbsid.

      ENDIF.
      CLEAR:v_shkzg,v_budat,v_blart,v_bukrs,v_dmbtr,v_wrbtr,v_xblnr,v_augdt,wa_1hbsid,v_hdmbtr,v_sdmbtr,v_hwrbtr, v_swrbtr,v_hdmbtr1,v_hwrbtr1,wa_1sbsid,wa_1hbsid,v_umskz,v_zbd1t,v_zterm.
    ENDAT.
  ENDLOOP.

  IF s_umskz IS NOT INITIAL.
    DELETE it_1hbsid WHERE umskz IN s_umskz.
    DELETE it_1sbsid WHERE umskz IN s_umskz.
  ENDIF.

  IF s_blart IS NOT INITIAL.
    DELETE it_1hbsid WHERE blart = s_blart.
    DELETE it_1sbsid WHERE blart = s_blart.
  ENDIF.

  it_hbsid[] = it_1hbsid[].
  it_sbsid[] = it_1sbsid[].
***********
  SORT it_sbsid BY kunnr bldat belnr.
  SORT it_hbsid BY kunnr bldat belnr.
*  commnet logic 17/01/2019
*
*  LOOP AT it_hbsid INTO wa_hbsid.
*    v_dmbtr = v_dmbtr + wa_hbsid-dmbtr.
*    v_wrbtr = v_wrbtr + wa_hbsid-wrbtr.
*    v_bldat = wa_hbsid-bldat.
*    v_shkzg = wa_hbsid-shkzg.
*    v_budat = wa_hbsid-budat.
*    v_blart = wa_hbsid-blart.
*    v_bukrs1 = wa_hbsid-bukrs.
*    v_xblnr = wa_hbsid-xblnr.
*    v_augdt = wa_hbsid-augdt.
*
*    AT END OF belnr.
*      wa_1hbsid-kunnr = wa_hbsid-kunnr.
*      wa_1hbsid-belnr = wa_hbsid-belnr.
*      wa_1hbsid-bldat = v_bldat.
*      wa_1hbsid-shkzg = v_shkzg.
*      wa_1hbsid-budat = v_budat.
*      wa_1hbsid-blart = v_blart.
*      wa_1hbsid-bukrs = v_bukrs1.
*      wa_1hbsid-dmbtr = v_dmbtr.
*      wa_1hbsid-wrbtr = v_wrbtr.
*      wa_1hbsid-xblnr = v_xblnr.
*      wa_1hbsid-augdt = v_augdt.
*      APPEND wa_1hbsid TO it_1hbsid.
*      CLEAR:v_shkzg,v_budat,v_blart,v_bukrs,v_dmbtr,v_wrbtr,v_xblnr,v_augdt,wa_1hbsid.
*    ENDAT.
*  ENDLOOP.
*  it_hbsid[] = it_1hbsid[].
************end comment logic 17/01/2019
  LOOP AT it_sbsid INTO wa_sbsid.
    wa_sbsid-dmbtr1 = wa_sbsid-dmbtr.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING dmbtr1.
  ENDLOOP.

  LOOP AT it_hbsid INTO wa_hbsid.
*LOOP AT it_sbsid INTO wa_sbsid where ind <> 'Y'.
    CLEAR:dmbtr1.
*    LOOP AT it_hbsid INTO wa_hbsid WHERE kunnr = wa_sbsid-kunnr .

    LOOP AT it_sbsid INTO wa_sbsid WHERE kunnr = wa_hbsid-kunnr AND ind <> 'Y' AND dmbtr <> '0.00'.
*      IF sy-subrc = 0.
      wa_sbsid-wrbtr = wa_sbsid-dmbtr1.
      v_h1 = wa_hbsid-dmbtr - wa_sbsid-dmbtr.
      v_s = wa_sbsid-dmbtr - wa_hbsid-dmbtr.
      v_h = wa_hbsid-dmbtr - wa_sbsid-dmbtr.
      IF v_h > 0.
        v_calc = wa_sbsid-dmbtr.
      ELSE.
        v_calc = wa_hbsid-dmbtr.
      ENDIF.
*      IF V_H > 0.
*        CONTINUE.
*      ELSE.
*        IF v_s < 0.
*          wa_sbsid-dmbtr = v_s * -1.
*        ELSE.


*        ENDIF.

      wa_sbsid-bldat = wa_sbsid-bldat.
      wa_sbsid-budat = wa_sbsid-budat.
      wa_sbsid-belnr = wa_sbsid-belnr.
      wa_sbsid-xblnr = wa_sbsid-xblnr.
      wa_sbsid-hdate = wa_hbsid-bldat.
      wa_sbsid-hbelnr = wa_hbsid-belnr.
      wa_sbsid-hdmbtr = wa_hbsid-dmbtr.
      wa_sbsid-hwrbtr = wa_hbsid-wrbtr.
      wa_sbsid-hblart = wa_hbsid-blart.
      wa_sbsid-xref1  = wa_hbsid-xref1.
**      wa_sbsid-zbd1t = wa_hbsid-zbd1t. """"ADDED BY AKSHAY DT.23.07.2025
**      wa_sbsid-zterm = wa_hbsid-zterm.  """"ADDED BY AKSHAY DT.23.07.2025


      IF  wa_sbsid-hdmbtr < wa_sbsid-dmbtr.
        wa_sbsid-hdmbtr = '0.00'.
      ELSE.
        wa_sbsid-hdmbtr = wa_sbsid-hdmbtr -  wa_sbsid-dmbtr.
      ENDIF.
      IF wa_sbsid-hdmbtr  > '0.00'.
*          wa_sbsid-v_h1 = wa_sbsid-hwrbtr -  wa_sbsid-hdmbtr.
        wa_sbsid-v_h1 = wa_hbsid-dmbtr -  wa_sbsid-hdmbtr.
      ELSE.
        wa_sbsid-v_h1 = wa_hbsid-dmbtr.
      ENDIF.
      wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
      wa_sbsid-dmbtr = v_s .
      wa_hbsid-dmbtr = v_h .

*


*
*       if wa_sbsid-v_h1 ne '0.00'.
*          wa_sbsid-closing = wa_sbsid-v_h2 - wa_sbsid-hdmbtr.
*       else.
*          wa_sbsid-closing = wa_sbsid-v_h2 + wa_sbsid-closing.
*        endif.

      wa_hbsid-bldat = wa_hbsid-bldat.
      wa_hbsid-belnr = wa_hbsid-belnr.
      wa_hbsid-ind = 'Y'.
*********************      logic comment 24/01/2019
*      IF chk <> 'X'.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*      ELSE.
*        if wa_sbsid-budat ge p_bldat.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*        else.
*        wa_sbsid-days = wa_sbsid-hdate - p_bldat.
*        endif.
*      ENDIF.
*****************      logic comment 24/01/2019
      wa_sbsid-ind = 'Y'.

      DATA: lv_is_numeric TYPE char4.

      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
*          string_in = wa_sbsid-xblnr
          string_in = wa_sbsid-zuonr
        IMPORTING
          htype     = lv_is_numeric.

      IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT SINGLE KDGRP_AUFT , vkbur FROM VBRP INTO @Data(wa_vbrp) WHERE vbeln = @wa_sbsid-XBLNR.

*        SELECT kdgrp_auft , vkbur FROM vbrp INTO @DATA(wa_vbrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*        SELECT kvgr2 , vkbur FROM vbrp INTO @DATA(wa_vbrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
        SELECT kvgr2 , vkbur FROM vbrp INTO @DATA(wa_vbrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-zuonr
         ORDER BY PRIMARY KEY .
        ENDSELECT.

* End of Quick Fix

      ENDIF.
      CLEAR lv_is_numeric.
      READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
*****  Added to display Sales Office code and payment terms by Carina Jose on 16.12.2019
        wa_sbsid-vkbur = wa_vbrp-vkbur.
*        wa_sbsid-zterm = wa_knvv-zterm. """COMMENTED BY AKSHAY DT.23.07.2025
*        wa_sbsid-kdgrp = wa_vbrp-kdgrp_auft.
        wa_sbsid-kvgr2 = wa_vbrp-kvgr2.
        wa_sbsid-kvgr1 = wa_knvv-kvgr1.
***** End of changes to display Sales Office code and payment terms  by Carina Jose on 16.12.2019
        READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_knvv-vkbur.
        IF sy-subrc = 0.
          wa_sbsid-soffice = wa_tvkbt-bezei.
        ENDIF.

        READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
        IF sy-subrc = 0.
          wa_sbsid-name1 = wa_kna1-name1.
        ENDIF.

        READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
        IF sy-subrc = 0.
          zterm1 = wa_t052-ztag1.
          zterm = zterm1 + s_days.
*            SHIFT zterm LEFT DELETING LEADING '0'.
        ENDIF.
      ENDIF.
      """"added by akshay dt.20.08.2025
      READ TABLE  it_legal_case INTO wa_legal_case WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
        wa_sbsid-zlegal_remark = 'Yes'.
      ENDIF.

*      READ TABLE  gt_div INTO wa_div WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        wa_sbsid-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO ls_tvv1t WITH KEY kvgr1 = wa_sbsid-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO ls_tvv2t WITH KEY kvgr2 = wa_sbsid-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.


      """"end of changes dt.20.08.2025
******************      logic add 24/01/2019
      DATA: p_caldate TYPE sy-datum.
      DATA: p_caldate1 TYPE sy-datum.
      DATA: p_caldate2 TYPE bsid-budat.
      DATA: days LIKE t5a4a-dlydy.
*      days = zterm. """COMMENTED BY AKSHAY DT.23.07.2025
      days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025

*      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
*        EXPORTING
*          date      = wa_sbsid-bldat
*          days      = days
*          months    = 00
*          signum    = '+'
*          years     = 00
*        IMPORTING
*          calc_date = p_caldate.
**      P_caldate = wa_sbsid-bldat +
*      IF chk <> 'X'.
*        wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*      ELSE.
**         if .
*        IF p_caldate GE p_bldat AND wa_sbsid-opind = 'X'.
*          wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat.
*        ELSE.
*          wa_sbsid-days = wa_sbsid-hdate - p_bldat.
*        ENDIF.
*      ENDIF.
**************
**********  due date calculation
******************** comment 22.08.2023
if wa_sbsid-blart = 'UE'.
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
 ELSE.

    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
  endif.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.
********************      end comment 22.08.2023
      """"added by akshay dt.30.08.2025
      DATA:lv_pint TYPE c.
      CLEAR:lv_pint.
      IF wa_sbsid-duedate IS INITIAL.
        wa_sbsid-duedate = s_bldat-high.
        lv_pint = abap_true.
      ENDIF.
      """"eoc dt.30.08.2025
*      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat."comment 05.10.2023
       IF wa_sbsid-BLART = 'UE'.
       wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-bldat. "added 05.10.2023
       else.
      wa_sbsid-days = wa_sbsid-hdate - wa_sbsid-budat. "added 05.10.2023
      endif.
******************* comment for exceed days 28/03/2019
*      IF wa_sbsid-budat LE p_bldat AND wa_sbsid-duedate LE p_bldat.
*        wa_sbsid-idays = wa_sbsid-hdate - p_bldat.
*        IF wa_sbsid-idays < 0.
*          wa_sbsid-idays = 0.
*        ENDIF.
*      ELSE.
*        wa_sbsid-idays = wa_sbsid-hdate - wa_sbsid-duedate.
*        IF wa_sbsid-idays < 0.
*          wa_sbsid-idays = 0.
*        ENDIF.
*      ENDIF.
****************    end 28/03/2019
*************** add 28/03/2019
      IF chk = 'X' AND wa_sbsid-budat LE p_bldat.
        wa_sbsid-idays = wa_sbsid-hdate - p_bldat.
        IF wa_sbsid-idays < 0.
          wa_sbsid-idays = 0.
        ENDIF.
      ELSE.
        wa_sbsid-idays = wa_sbsid-hdate - wa_sbsid-duedate."comment 22.08.2023
        IF wa_sbsid-BLART = 'UE'.
        wa_sbsid-ipdays = wa_sbsid-hdate - wa_sbsid-bldat. "added 27.10.2023
        else.
        wa_sbsid-ipdays = wa_sbsid-hdate - wa_sbsid-budat. "added 27.10.2023
        endif.
        IF wa_sbsid-idays < 0.
          wa_sbsid-idays = 0.
        ENDIF.
        IF wa_sbsid-ipdays < 0.
          wa_sbsid-ipdays = 0.
        ENDIF.
      ENDIF.

*        READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*        IF wa_tvarv IS NOT INITIAL.
*          IF wa_sbsid-zterm = wa_tvarv-low.
*            wa_sbsid-idays = 0.
*          ENDIF .
*        ENDIF.

************   END 28/03/2019



      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
          string_in = wa_sbsid-zuonr
*          string_in = wa_sbsid-xblnr
        IMPORTING
          htype     = lv_is_numeric.
      .

      IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT SINGLE KDGRP_AUFT FROM VBRP INTO @Data(lv_kdgrp) WHERE vbeln = @wa_sbsid-XBLNR.

*        SELECT kdgrp_auft FROM vbrp INTO @DATA(lv_kdgrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*        SELECT kvgr2 FROM vbrp INTO @DATA(lv_kdgrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
        SELECT kvgr2 FROM vbrp INTO @DATA(lv_kdgrp) UP TO 1 ROWS WHERE vbeln = @wa_sbsid-zuonr
         ORDER BY PRIMARY KEY .
        ENDSELECT.

* End of Quick Fix

        "" added by ranjan
      ENDIF.
      CLEAR lv_is_numeric.
*      READ TABLE it_vbrk WITH KEY vbeln = wa_sbsid-xblnr TRANSPORTING NO FIELDS.
      READ TABLE it_vbrk WITH KEY vbeln = wa_sbsid-zuonr TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
      ELSE.
        LOOP AT it_matrix INTO wa_matrix WHERE zkvgr1 = wa_sbsid-kvgr1 AND zkvgr2 = wa_sbsid-kvgr2."wa_sbsid-kdgrp.

          IF wa_matrix-zday_to IS NOT INITIAL.
            IF wa_sbsid-ipdays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
              s_int = wa_matrix-zyr_per.
              wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
          IF wa_matrix-zday_to IS INITIAL.
            IF wa_sbsid-ipdays GE wa_matrix-zday_from.
              s_int = wa_matrix-zyr_per.
              wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.
*      READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*      IF wa_tvarv IS NOT INITIAL.
*        IF wa_sbsid-zterm = wa_tvarv-low.
*          wa_sbsid-ipdays = 0.
*          s_int = 0.
*        ENDIF .
*      ENDIF.



*      IF wa_sbsid-days > zterm.
*        wa_sbsid-idays = wa_sbsid-days - zterm.
      wa_sbsid-zstd_days = wa_sbsid-ipdays - wa_sbsid-zstd_days_f.

*      IF wa_sbsid-ipdays > 0. "comment by parth 12.12.2023
      IF wa_sbsid-zstd_days  > 0.

        wa_sbsid-int = ( v_calc * s_int ) / 100.

*       wa_sbsid-pint =  ( wa_sbsid-int * wa_sbsid-ipdays ) / 365. "comment by parth 12.12.2023
        IF lv_pint = abap_true.   """added by akshay dt.30.08.2025
          wa_sbsid-oipint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365. """added by akshay dt.30.08.2025
        ELSE. """added by akshay dt.30.08.2025
          wa_sbsid-pint =  ( wa_sbsid-int * wa_sbsid-zstd_days ) / 365.
        ENDIF.  """added by akshay dt.30.08.2025
      ENDIF.
      wa_sbsid-intrate =  s_int.
      dmbtr1 = wa_sbsid-dmbtr1.
      MODIFY it_sbsid FROM wa_sbsid TRANSPORTING ind hbelnr hdate days hdmbtr hblart idays ipdays pint soffice name1 hwrbtr v_h1 v_h2 intrate wrbtr duedate vkbur zterm zstd_days zlegal_remark
      cust_group1 cust_group2 kvgr1 kvgr2 zstd_days_f int.
      MODIFY it_hbsid FROM wa_hbsid TRANSPORTING ind.
      IF v_s <> 0.
        wa_sbsid-ind = 'N'.
      ENDIF.
      IF v_h <> 0.
        wa_hbsid-ind = 'N'.
      ENDIF.
      IF wa_sbsid-dmbtr > 0 .
        wa_sbsid-split = 'S'.
        APPEND wa_sbsid TO it_sbsid.
      ELSEIF wa_hbsid-dmbtr > 0 .
        wa_hbsid-split = 'S'.
        wa_hbsid-srno = wa_hbsid-srno + 1.

*****************Added  by Raj on 10.10.2023**********************
*        READ TABLE it_tvarv INTO wa_tvarv WITH KEY low = wa_knvv-zterm.
*        IF wa_tvarv IS NOT INITIAL.
*          IF wa_sbsid-zterm = wa_tvarv-low.
*            wa_hbsid-idays = 0.
*          ENDIF .
*        ENDIF.

****************Added  by Raj on 10.10.2023***********************
        APPEND wa_hbsid TO it_hbsid.



      ENDIF.
      SORT it_sbsid BY kunnr bldat belnr hdate hbelnr.
      SORT it_hbsid BY kunnr bldat belnr srno.
      CLEAR:v_s,v_h,wa_sbsid,wa_hbsid,zterm,zterm1,wa_t052,wa_kna1,wa_tvkbt,days,p_caldate1,p_caldate,wa_matrix,s_int,wa_tvarv,zstd_days,lv_kdgrp.
      EXIT.
*      ENDIF.
*  ENDIF.

    ENDLOOP.
***********    add 25/01/2019
*      if dmbtr1 is INITIAL AND wa_hbsid-ind <> 'N'.
*      wa_sbsid-kunnr = wa_hbsid-kunnr.
*      wa_sbsid-hdate =  wa_hbsid-bldat.
*      wa_sbsid-hbelnr = wa_hbsid-belnr.
*      wa_sbsid-hdmbtr = wa_hbsid-dmbtr.
*      wa_sbsid-hwrbtr = wa_hbsid-wrbtr.
*      wa_sbsid-hblart = wa_hbsid-blart.
**      wa_sbsid-v_h1 =  wa_hbsid-dmbtr.
**       wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
*
*      APPEND wa_sbsid to it_sbsid.
*      SORT it_sbsid BY kunnr hdate hbelnr.
*      clear: wa_sbsid,dmbtr1.
*      endif.
************      end 25/01/2019
  ENDLOOP.

  DELETE it_sbsid WHERE ind = 'N'.

*  *************************** Payment header text add
  SELECT bukrs belnr budat bktxt
    FROM bkpf INTO TABLE it_pbkpf
     FOR ALL ENTRIES IN it_sbsid
      WHERE bukrs = it_sbsid-bukrs
      AND   belnr = it_sbsid-hbelnr
      AND   budat = it_sbsid-hdate.

  SELECT bukrs belnr budat bktxt
    FROM bkpf INTO TABLE it_bkpf
     FOR ALL ENTRIES IN it_sbsid
      WHERE bukrs = it_sbsid-bukrs
      AND   belnr = it_sbsid-belnr
      AND   budat = it_sbsid-budat.
************************

  LOOP AT it_sbsid INTO wa_sbsid.
*****    add 25/01/2019
*    IF wa_sbsid-dmbtr <> '0.00'.
********      end 25/01/2019
    IF wa_sbsid-v_h1 = '0.00'.
      wa_sbsid-v_h2 = wa_sbsid-dmbtr - wa_sbsid-v_h1.
    ENDIF.

    IF wa_sbsid-v_h1 NE '0.00'.
      wa_sbsid-closing = wa_sbsid-v_h2 - wa_sbsid-hdmbtr.
*      v_closing = wa_sbsid-closing.
*      lv_h2     = wa_sbsid-dmbtr.
    ELSE.
*      wa_sbsid-closing = wa_sbsid-v_h2 + wa_sbsid-closing.
*       lv_h2     = wa_sbsid-dmbtr.
      wa_sbsid-closing = v_closing + wa_sbsid-v_h2.
    ENDIF.
**********    add 25/01/2019
*    else.
*      wa_sbsid-closing = v_closing1 + wa_sbsid-hdmbtr.
*    endif.
***********    end 25/01/2019

*    IF wa_sbsid-dmbtr <> '0.00'."***********    add 25/01/2019
    v_closing = wa_sbsid-closing.
    lv_h2     = wa_sbsid-dmbtr.
*    endif.                      "***********    add 25/01/2019
*    if wa_sbsid-dmbtr = '0.00'.
*      v_closing1 = wa_sbsid-closing.
*    endif.
****************    end 25/01/2019

    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
      wa_sbsid-name1 = wa_kna1-name1.
    ENDIF.



    CALL FUNCTION 'NUMERIC_CHECK'
      EXPORTING
*        string_in = wa_sbsid-xblnr
        string_in = wa_sbsid-zuonr
      IMPORTING
        htype     = lv_is_numeric.
    .

    IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE KDGRP_AUFT , vkbur FROM VBRP INTO @wa_vbrp WHERE vbeln = @wa_sbsid-XBLNR.

*      SELECT kdgrp_auft , vkbur FROM vbrp INTO @wa_vbrp UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*      SELECT kvgr2 , vkbur FROM vbrp INTO @wa_vbrp UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
      SELECT kvgr2 , vkbur FROM vbrp INTO @wa_vbrp UP TO 1 ROWS WHERE vbeln = @wa_sbsid-zuonr
       ORDER BY PRIMARY KEY .
      ENDSELECT.

* End of Quick Fix

    ENDIF.
    CLEAR lv_is_numeric.
    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_sbsid-kunnr.
    IF sy-subrc = 0.
*****  Added to display Sales Office code and payment terms by Carina Jose on 16.12.2019
      wa_sbsid-vkbur = wa_vbrp-vkbur.
      wa_sbsid-kvgr2 = wa_vbrp-kvgr2.
      wa_sbsid-kvgr1 = wa_knvv-kvgr1.
**      wa_sbsid-zterm = wa_knvv-zterm. """COMMENTED BY AKSHAY DT.23.07.2025
***** End of changes to display Sales Office code and payment terms  by Carina Jose on 16.12.2019
      READ TABLE it_tvkbt INTO wa_tvkbt WITH KEY vkbur = wa_knvv-vkbur.
      IF sy-subrc = 0.
        wa_sbsid-soffice = wa_tvkbt-bezei.
      ENDIF.
    ENDIF.
    wa_sbsid-wrbtr = wa_sbsid-dmbtr1.
************   due date
    READ TABLE it_t052 INTO wa_t052 WITH KEY zterm = wa_knvv-zterm.
    IF sy-subrc = 0.
      zterm1 = wa_t052-ztag1.
      zterm = zterm1 + s_days.
    ENDIF.

    IF wa_sbsid-duedate IS INITIAL.
      if wa_sbsid-blart = 'UE'.
*      days = zterm. """COMMENTED BY AKSHAY DT.23.07.2025
      days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
         date      = wa_sbsid-bldat
*          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
     else.
        days = wa_sbsid-zbd1t. """ADDED BY AKSHAY DT.23.07.2025
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = wa_sbsid-bldat
          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
      endif.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.
    ENDIF.
**********
**********************    payment Docuemnt header text add
    READ TABLE it_pbkpf INTO wa_pbkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-hbelnr budat = wa_sbsid-hdate.
    IF sy-subrc = 0.
      wa_sbsid-pbktxt = wa_pbkpf-bktxt.
    ENDIF.

    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_sbsid-bukrs  belnr = wa_sbsid-belnr budat = wa_sbsid-budat.
    IF sy-subrc = 0.
      wa_sbsid-bktxt = wa_bkpf-bktxt.
    ENDIF.
************
*        MOVE-CORRESPONDING wa_sbsid1 to wa_sbsid.
    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING closing v_h2 name1 soffice wrbtr duedate vkbur zterm bktxt pbktxt KVGR2 KVGR1.
    CLEAR : wa_kna1,wa_sbsid,wa_tvkbt,wa_t052,wa_knvv,p_caldate1,p_caldate2,days,wa_bkpf,wa_pbkpf.

  ENDLOOP.

  lt_sbsid[] = it_sbsid[].

  LOOP AT lt_sbsid INTO lw_sbsid.
    v_invbal = v_invbal + lw_sbsid-v_h2.
    l_invbal = lw_sbsid-v_h2.
    l_budat  = lw_sbsid-budat.
    AT END OF belnr.
      wa_sbsid3-kunnr = lw_sbsid-kunnr.
      wa_sbsid3-belnr = lw_sbsid-belnr.
      wa_sbsid3-invbal = v_invbal.
      wa_sbsid3-linvbal = l_invbal.
      wa_sbsid3-budat =  l_budat.

      APPEND wa_sbsid3 TO it_sbsid3.
      CLEAR: wa_sbsid3,v_invbal,lw_sbsid,l_invbal,l_budat.
    ENDAT.
  ENDLOOP.

  LOOP AT it_sbsid INTO wa_sbsid.
*   at last .
    READ TABLE it_sbsid3 INTO wa_sbsid3 WITH KEY kunnr = wa_sbsid-kunnr
                                                 belnr = wa_sbsid-belnr
                                                 linvbal = wa_sbsid-v_h2.
    IF sy-subrc = 0.
      IF wa_sbsid-v_h2 <> '0.00'."invoice balnce amount
        IF wa_sbsid-wrbtr <> wa_sbsid3-invbal.
          wa_sbsid-invbalind = 'R'.
        ENDIF.
      ENDIF.
    ENDIF.
***************    for yet not paid amount
    IF wa_sbsid-hdate IS INITIAL .
*      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat."comment 22.08.2023
      wa_sbsid-udays = s_bldat-high - wa_sbsid-duedate."wa_sbsid-budat. "added 22.08.2023
*      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate. "comment 22.08.2023
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate."wa_sbsid-budat. " added 22.08.2023
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
***********************    for remaining balance
    IF  wa_sbsid-invbalind = 'R'.
*      wa_sbsid-udays = s_bldat-high - wa_sbsid-bldat."comment 22.08.2023
      wa_sbsid-udays = s_bldat-high - wa_sbsid-duedate."wa_sbsid-budat." added 22.08.2023
*      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate." comment 22.08.2023
      wa_sbsid-uedays =  s_bldat-high - wa_sbsid-duedate."wa_sbsid-budat.  "added 22.08.2023
      IF wa_sbsid-uedays < 0.
        wa_sbsid-uedays = 0.
      ENDIF.
      IF wa_sbsid-uedays > 0.
        wa_sbsid-int = ( wa_sbsid-v_h2 * wa_sbsid-intrate ) / 100.
        wa_sbsid-pint1 =  ( wa_sbsid-int * wa_sbsid-uedays ) / 365.
      ENDIF.
    ENDIF.
************


    MODIFY it_sbsid FROM wa_sbsid TRANSPORTING invbalind uedays pint1 udays.

    CLEAR: wa_sbsid,wa_sbsid3.

  ENDLOOP.
  """""added by akshay dt.22.09.2025
  REFRESH :gt_div.
  SELECT * FROM zfi_mis_kdgrp INTO TABLE gt_div WHERE vkorg = p_vkorg.

  SELECT * FROM tvv1t INTO TABLE @gt_tvv1t FOR ALL ENTRIES IN @it_knvv WHERE kvgr1 = @it_knvv-kvgr1 AND spras = 'E'.
  SELECT * FROM tvv2t INTO TABLE @gt_tvv2t FOR ALL ENTRIES IN @it_knvv WHERE kvgr2 = @it_knvv-kvgr2 AND spras = 'E'.

  LOOP AT it_sbsid ASSIGNING FIELD-SYMBOL(<ls_update>) WHERE ( hdate = '00000000'  OR invbalind = 'R' ).
    CLEAR:s_int,lv_kdgrp.
    """"added by akshay dt.20.08.2025
    IF <ls_update>-hdate = '00000000'.

      READ TABLE  it_legal_case INTO wa_legal_case WITH KEY kunnr = <ls_update>-kunnr.
      IF sy-subrc = 0.
        <ls_update>-zlegal_remark = 'Yes'.
      ENDIF.

*      READ TABLE  gt_div INTO wa_div WITH KEY kdgrp = <ls_update>-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        <ls_update>-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO ls_tvv1t WITH KEY kvgr1 = <ls_update>-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO ls_tvv2t WITH KEY kvgr2 = <ls_update>-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.


      days = <ls_update>-zbd1t.
  if wa_sbsid-blart = 'UE'.
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
         date      = <ls_update>-bldat
*          date      = <ls_update>-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
  else.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = <ls_update>-bldat
          date      = <ls_update>-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
   endif.

      p_caldate2 = p_caldate1.
      <ls_update>-duedate = p_caldate2.

      CLEAR:lv_pint.
      IF <ls_update>-duedate IS INITIAL.
        <ls_update>-duedate = s_bldat-high.
        lv_pint = abap_true.
      ENDIF.

      <ls_update>-days = s_bldat-high - <ls_update>-budat. "added 05.10.2023
      CLEAR:lv_kdgrp.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE KDGRP_AUFT FROM VBRP INTO @lv_kdgrp WHERE vbeln = @<ls_update>-XBLNR.

*      SELECT kdgrp_auft FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @<ls_update>-xblnr
*      SELECT kvgr2 FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @<ls_update>-xblnr
      SELECT kvgr2 FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @<ls_update>-zuonr
       ORDER BY PRIMARY KEY .
      ENDSELECT.

* End of Quick Fix

      <ls_update>-kvgr2 = lv_kdgrp.

*      READ TABLE it_vbrk INTO DATA(wa1_vbrk) WITH KEY vbeln = <ls_update>-xblnr.
      READ TABLE it_vbrk INTO DATA(wa1_vbrk) WITH KEY vbeln = <ls_update>-zuonr.
      IF sy-subrc = 0.
      ELSE.

        SELECT SINGLE zday_to FROM zcr_matx_new INTO @DATA(lv_todays) WHERE zkvgr1 = @<ls_update>-kvgr1 AND zkvgr2 = @<ls_update>-kvgr2 AND zday_from = '000'.

*    <ls_update>-UEDAYS = <ls_update>-UDAYS - <ls_update>-ZSTD_DAYS_F.
*      <ls_update>-OPedays = <ls_update>-UEDAYS - lv_todays. "comment by parth 10.10.2025
        <ls_update>-opedays = <ls_update>-days - lv_todays. " added by parth 10.10.2025 "comment by parth 01.12.2025
*      <ls_update>-days = <ls_update>-DAYS . " added by parth 01.12.2025
        LOOP AT it_matrix INTO wa_matrix WHERE zkvgr1 = <ls_update>-kvgr1 AND zkvgr2 = <ls_update>-kvgr2.

          IF wa_matrix-zday_to IS NOT INITIAL.
*        IF <ls_update>-ipdays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
*          IF <ls_update>-OPedays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
            IF <ls_update>-days BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
              s_int = wa_matrix-zyr_per.
              <ls_update>-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
          IF wa_matrix-zday_to IS INITIAL.
*        IF <ls_update>-ipdays GE wa_matrix-zday_from.
*          IF <ls_update>-OPedays GE wa_matrix-zday_from.
            IF <ls_update>-days GE wa_matrix-zday_from.
              s_int = wa_matrix-zyr_per.
              <ls_update>-zstd_days_f = wa_matrix-zstd_days.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.



      IF <ls_update>-opedays  > 0.
*      IF <ls_update>-UEDAYS  > 0.

*        <ls_update>-int = ( v_calc * s_int ) / 100.
        <ls_update>-int = ( <ls_update>-v_h2 * s_int ) / 100.

        IF lv_pint = abap_true.
          <ls_update>-oipint =  ( <ls_update>-int * <ls_update>-opedays ) / 365.
        ELSE.
*        <ls_update>-pint =  ( <ls_update>-int * <ls_update>-zstd_days ) / 365.
          <ls_update>-pint_o =  ( <ls_update>-int * <ls_update>-opedays ) / 365.
        ENDIF.
      ENDIF.
      <ls_update>-intrate =  s_int.
      """""added by akshay dt.20.08.2025
*      READ TABLE  gt_div INTO wa_div WITH KEY kdgrp = <ls_update>-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        <ls_update>-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO ls_tvv1t WITH KEY kvgr1 = <ls_update>-kvgr1.
      IF sy-subrc = 0.
        <ls_update>-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO ls_tvv2t WITH KEY kvgr2 = <ls_update>-kvgr2.
      IF sy-subrc = 0.
        <ls_update>-cust_group2 = ls_tvv2t-bezei.
      ENDIF.

    ELSE.
      MOVE-CORRESPONDING  <ls_update> TO wa_sbsid.
      CLEAR: wa_sbsid-v_h1, wa_sbsid-hdate, wa_sbsid-hbelnr, wa_sbsid-hwrbtr, wa_sbsid-hdmbtr,  wa_sbsid-hblart,wa_sbsid-idays,wa_sbsid-zstd_days_f,wa_sbsid-zstd_days,wa_sbsid-ipdays,wa_sbsid-pint1,
           wa_sbsid-pint,lv_kdgrp.
      wa_sbsid-dmbtr = wa_sbsid-v_h2.
      wa_sbsid-wrbtr = wa_sbsid-v_h2.
      wa_sbsid-invbalind = 'S'.
      READ TABLE  it_legal_case INTO wa_legal_case WITH KEY kunnr = wa_sbsid-kunnr.
      IF sy-subrc = 0.
        wa_sbsid-zlegal_remark = 'Yes'.
      ENDIF.

*      READ TABLE  gt_div INTO wa_div WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        wa_sbsid-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO ls_tvv1t WITH KEY kvgr1 = <ls_update>-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO ls_tvv2t WITH KEY kvgr2 = <ls_update>-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.

      days = wa_sbsid-zbd1t.

    if wa_sbsid-blart = 'UE'.
      CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
         date      = <ls_update>-bldat
*          date      = wa_sbsid-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
    else.
       CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
        EXPORTING
*         date      = WA_sbsid-bldat
          date      = <ls_update>-budat
          days      = days
          months    = 00
          signum    = '+'
          years     = 00
        IMPORTING
          calc_date = p_caldate1.
     endif.

      p_caldate2 = p_caldate1.
      wa_sbsid-duedate = p_caldate2.

      CLEAR:lv_pint.
      IF <ls_update>-duedate IS INITIAL.
        <ls_update>-duedate = s_bldat-high.
        lv_pint = abap_true.
      ENDIF.

      if <ls_update>-blart = 'UE'.
      wa_sbsid-days = s_bldat-high - <ls_update>-bldat. "added 05.10.2023
      ELSE.
      wa_sbsid-days = s_bldat-high - <ls_update>-budat. "added 05.10.2023
      ENDIF.
      CLEAR:lv_kdgrp.


      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
*          string_in = wa_sbsid-xblnr
          string_in = <ls_update>-zuonr
        IMPORTING
          htype     = lv_is_numeric.
      .

      IF lv_is_numeric = 'NUMC'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT SINGLE KDGRP_AUFT FROM VBRP INTO @lv_kdgrp WHERE vbeln = @WA_sbsid-XBLNR.

*        SELECT kdgrp_auft FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
*        SELECT kvgr2 FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @wa_sbsid-xblnr
        SELECT kvgr2 FROM vbrp INTO @lv_kdgrp UP TO 1 ROWS WHERE vbeln = @<ls_update>-zuonr
         ORDER BY PRIMARY KEY .
        ENDSELECT.

* End of Quick Fix

        <ls_update>-kvgr2 = lv_kdgrp.
      ENDIF.
      CLEAR lv_is_numeric.

      SELECT SINGLE zday_to FROM zcr_matx_new INTO @lv_todays WHERE zkvgr1 = @<ls_update>-kvgr1 AND zkvgr2 = @<ls_update>-kvgr2 AND zday_from = '000'.

*    WA_sbsid-UEDAYS = WA_sbsid-UDAYS - WA_sbsid-ZSTD_DAYS_F.
      <ls_update>-opedays = <ls_update>-uedays - lv_todays.
      LOOP AT it_matrix INTO wa_matrix WHERE zkvgr1 = <ls_update>-kvgr1 AND zkvgr2 = <ls_update>-kvgr2.

        IF wa_matrix-zday_to IS NOT INITIAL.
*        IF WA_sbsid-ipdays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
          IF wa_sbsid-opedays BETWEEN wa_matrix-zday_from AND wa_matrix-zday_to.
            s_int = wa_matrix-zyr_per.
            wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
          ENDIF.
        ENDIF.
        IF wa_matrix-zday_to IS INITIAL.
*        IF WA_sbsid-ipdays GE wa_matrix-zday_from.
          IF wa_sbsid-opedays GE wa_matrix-zday_from.
            s_int = wa_matrix-zyr_per.
            wa_sbsid-zstd_days_f = wa_matrix-zstd_days.
          ENDIF.
        ENDIF.
      ENDLOOP.



      IF wa_sbsid-opedays  > 0.

*        WA_sbsid-int = ( v_calc * s_int ) / 100.
        wa_sbsid-int = ( <ls_update>-v_h2 * s_int ) / 100.

        IF lv_pint = abap_true.
          wa_sbsid-oipint =  ( wa_sbsid-int * wa_sbsid-opedays ) / 365.
        ELSE.
*        WA_sbsid-pint =  ( WA_sbsid-int * WA_sbsid-zstd_days ) / 365.
          wa_sbsid-pint_o =  ( wa_sbsid-int * wa_sbsid-opedays ) / 365.
        ENDIF.
      ENDIF.
      wa_sbsid-intrate =  s_int.
      """""added by akshay dt.20.08.2025
*      READ TABLE  gt_div INTO wa_div WITH KEY kdgrp = wa_sbsid-kdgrp vkorg = p_vkorg.
*      IF sy-subrc = 0.
*        wa_sbsid-cust_group = wa_div-txt.
*      ENDIF.

      READ TABLE gt_tvv1t INTO ls_tvv1t WITH KEY kvgr1 = wa_sbsid-kvgr1.
      IF sy-subrc = 0.
        wa_sbsid-cust_group1 = ls_tvv1t-bezei.
      ENDIF.
      READ TABLE gt_tvv2t INTO ls_tvv2t WITH KEY kvgr2 = wa_sbsid-kvgr2.
      IF sy-subrc = 0.
        wa_sbsid-cust_group2 = ls_tvv2t-bezei.
      ENDIF.

      READ TABLE it_sbsid INTO DATA(wa_sbsid_in) WITH KEY xblnr = wa_sbsid-xblnr kunnr = wa_sbsid-kunnr invbalind = 'R' belnr =  wa_sbsid-belnr blart = wa_sbsid-blart.
      IF sy-subrc = 0.
        DATA(lv_index) = sy-tabix + 1.
        INSERT  wa_sbsid INTO it_sbsid INDEX lv_index.
        CLEAR:wa_sbsid.
      ENDIF.
    ENDIF.

  ENDLOOP.

  """"eoc dt.22.09.2025


  """"""added by akshay dt.23.07.2025
  LOOP AT it_sbsid ASSIGNING FIELD-SYMBOL(<lf_sbsid>).
    AT NEW kunnr.
      CALL FUNCTION 'CUSTOMER_OPEN_ITEMS'
        EXPORTING
          bukrs         = <lf_sbsid>-bukrs
          kunnr         = <lf_sbsid>-kunnr
        TABLES
          t_postab      = lt_openitems[]
        EXCEPTIONS
          no_open_items = 1
          OTHERS        = 2.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      DELETE lt_openitems WHERE umskz = '5'.

      LOOP AT lt_openitems ASSIGNING <ls_openitems>.
        <lf_sbsid>-outstanding_amount = <lf_sbsid>-outstanding_amount + <ls_openitems>-dmshb.
      ENDLOOP.
    ENDAT.
  ENDLOOP.

  """"""eoc dt.23.07.2025

ENDFORM.
