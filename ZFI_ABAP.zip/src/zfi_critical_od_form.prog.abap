*&---------------------------------------------------------------------*
*       MODULE :                                                       *
*----------------------------------------------------------------------*
*       Objective : CUSTOMER MASTER CREATE                             *
*       Program   : Updates Tables (   )     Downloads data (  )       *
*                   Outputs List   (   )                               *
*                                                                      *
*                                                                      *
*       Date Created :                                                 *
*       Instructed by:                                                 *
*       Devloped by:                                                   *
*                                                                      *
*----------------------------------------------------------------------*
*       External Dependencies                                          *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
* Amendment History                                                    *
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR           CR/ID                   *
*......................................................................*
* <001>  Hemang Joshi         DEVK902453 ( Req By : Kalpit Oza )       *
* Reason: Defect Resolution for structure mismatch on 23/02/2026       *
*......................................................................*

*&---------------------------------------------------------------------*
*&  Include           ZFI_CRITICAL_OD_FORM
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data.

  DATA: lv_ageslb1(3) TYPE n,
        lv_ageslb2(3) TYPE n,
        lv_ageslb3(3) TYPE n,
        lv_ageslb4(3) TYPE n,
        lv_ageslb5(3) TYPE n,
        lv_ageslb6(3) TYPE n,
        lv_ageslb7(4) TYPE n.

  DATA lv_date TYPE sy-datum.
  DATA lv_days TYPE dlydy.

  SELECT * FROM zfi_mis_kdgrp INTO TABLE lt_mis_kdgrp WHERE vkorg IN vkorg.
  SELECT * FROM zfi_logic_days INTO TABLE @DATA(lt_logic).

  PERFORM fill_slabs.


*-- Begin of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
*
  FREE MEMORY ID 'ZCRITICALODFINAL'.
  FREE MEMORY ID 'ZCRITICALODDETAIL'.
  FREE MEMORY ID 'ZCUSTAGEDUE'.
*-- Begin of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
*


  SUBMIT zfi_cust_ageing_new WITH regio IN regio
                             WITH party IN party
                             WITH s_vkbur IN s_vkbur
                             WITH fsyr  = fsyr
                             WITH s_date = s_date
                             WITH code = code
                             WITH vkorg IN vkorg
                             WITH akont IN akont
                             WITH s_bzirk IN s_bzirk
                             WITH s_vkgrp IN s_vkgrp
                             WITH ageslb1 = ageslb1
                             WITH ageslb2 = ageslb2
                             WITH ageslb3 = ageslb3
                             WITH ageslb4 = ageslb4
                             WITH ageslb5 = ageslb5
                             WITH ageslb6 = ageslb6
                             WITH ageslb7 = ageslb7
*-- Begin of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
                             WITH ageslb8 = ageslb8
                             WITH ageslb9 = ageslb9
                             WITH ageslb10 = ageslb10
*-- End of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
                             EXPORTING LIST TO MEMORY AND RETURN.

  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*   IMPORT it_head FROM MEMORY ID 'ZCRITICALODFINAL'.



  IMPORT it_head FROM MEMORY ID 'ZCRITICALODFINAL'  ACCEPTING PADDING .
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*   IMPORT it_detail FROM MEMORY ID 'ZCRITICALODDETAIL'.
  IMPORT it_detail FROM MEMORY ID 'ZCRITICALODDETAIL'  ACCEPTING PADDING .
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  DELETE it_detail WHERE blart NE 'RV' AND blart = 'UE'.
  SORT   it_detail BY kunnr budat DESCENDING.


  FREE MEMORY ID 'ZCRITICALODFINAL'.
  FREE MEMORY ID 'ZCRITICALODDETAIL'.
  FREE MEMORY ID 'ZCUSTAGEDUE'.

  SUBMIT zfi_cust_ageing_duedt WITH regio IN regio
                               WITH party IN party
                               WITH s_vkbur IN s_vkbur
                               WITH fsyr  = fsyr
                               WITH s_date = s_date
                               WITH code = code
                               WITH vkorg IN vkorg
                               WITH akont IN akont
                               WITH ageslb1 = ageslb1
                               WITH ageslb2 = ageslb2
                               WITH ageslb3 = ageslb3
                               WITH ageslb4 = ageslb4
                               WITH ageslb5 = ageslb5
                               WITH ageslb6 = ageslb6
                               WITH ageslb7 = ageslb7
*-- Begin of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
*                             WITH ageslb8 = ageslb8
*                             WITH ageslb9 = ageslb9
*                             WITH ageslb10 = ageslb10
*-- End of changes by Hemang to match IT_HEAD structure from ageing program on 23/02/2026 Req By : Kalpit Oza
                                EXPORTING LIST TO MEMORY AND RETURN.

  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*   IMPORT it_head_due FROM MEMORY ID 'ZCUSTAGEDUE'.



  IMPORT it_head_due FROM MEMORY ID 'ZCUSTAGEDUE'  ACCEPTING PADDING .
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

  IF it_head[] IS NOT INITIAL.
    SELECT kunnr,
           vkorg,
           vtweg,
           spart FROM knvv INTO TABLE @DATA(it_knvv)
           FOR ALL ENTRIES IN @it_head WHERE kunnr = @it_head-kunnr
                                         AND vkorg IN @vkorg.

    SELECT kunnr, adrnr FROM kna1 INTO TABLE @DATA(it_address)
    FOR ALL ENTRIES IN @it_head WHERE kunnr = @it_head-kunnr.

    SELECT addrnumber, extension1 FROM adrc INTO TABLE @DATA(it_ext)
    FOR ALL ENTRIES IN @it_address WHERE addrnumber = @it_address-adrnr.

    SELECT bukrs,
           kunnr,
           umsks,
           umskz,
           augdt,
           augbl,
           zuonr,
           gjahr,
           belnr,
           buzei,
           dmbtr FROM bsid INTO TABLE @DATA(it_bsid)
           FOR ALL ENTRIES IN @it_head WHERE bukrs = @code
                                         AND kunnr = @it_head-kunnr
*                                         AND umsks = '5'.
                                         AND umsks IN ( 'I' , 'Q' ) .

    SELECT zterm,
           ztagg,
           ztag1,
           ztag2,
           ztag3 FROM t052 INTO TABLE @DATA(it_t052)
           FOR ALL ENTRIES IN @it_head WHERE zterm = @it_head-zterm.

    SELECT * FROM zfi_legal_case INTO TABLE @DATA(it_legal_case)
    FOR ALL ENTRIES IN @it_head WHERE kunnr = @it_head-kunnr
                                  AND vkorg IN @vkorg.
  ENDIF.

  LOOP AT it_head .
    READ TABLE it_knvv INTO DATA(wa_knvv) WITH KEY kunnr = it_head-kunnr.
    IF sy-subrc = 0.
      READ TABLE lt_mis_kdgrp INTO ls_mis_kdgrp WITH KEY vkorg = wa_knvv-vkorg
                                                         kvgr1 = it_head-kvgr1.
      IF sy-subrc = 0.
        wa_final-division = ls_mis_kdgrp-txt.
        " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*        SELECT SINGLE groupping FROM zfi_cod_mail_div INTO wa_final-group WHERE division = wa_final-division.
        SELECT groupping FROM zfi_cod_mail_div   UP TO 1 ROWS INTO
       wa_final-group WHERE division = wa_final-division  ORDER BY PRIMARY KEY.
        ENDSELECT.
        " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
      ENDIF.
    ENDIF.
    wa_final-sales_office = it_head-vktxt.
    wa_final-tsm_sales_grp = it_head-vkgrp_txt.
    wa_final-kunnr = it_head-kunnr.
    IF p_chk IS INITIAL AND p_chk1 IS INITIAL AND p_chk2 IS INITIAL.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = wa_final-kunnr
        IMPORTING
          output = wa_final-kunnr.
    ENDIF.
    wa_final-name  = it_head-name1.
    wa_final-cdam1 = it_head-cdam1.
    wa_final-cdam2 = it_head-cdam2.
    wa_final-cdam3 = it_head-cdam3.
    wa_final-cdam4 = it_head-cdam4.
    wa_final-cdam5 = it_head-cdam5.
    wa_final-cdam6 = it_head-cdam6.
    wa_final-cdam7 = it_head-cdam7.
    wa_final-cdam8 = it_head-cdam8.
    IF it_head-netot LE 0.
      CLEAR: ls_mis_kdgrp,wa_knvv,it_head,wa_final.
      CONTINUE.
    ENDIF.
    READ TABLE it_address INTO DATA(wa_address) WITH KEY kunnr = it_head-kunnr.
    IF sy-subrc = 0.
      READ TABLE it_ext INTO DATA(wa_ext) WITH KEY addrnumber = it_head-extension1.
      IF sy-subrc = 0.
        wa_final-default = wa_ext-extension1.
      ENDIF.
    ENDIF.
    wa_final-netot = it_head-netot.
    wa_final-zterm = it_head-zterm.
    wa_final-text1 = it_head-text1.
    LOOP AT it_bsid INTO DATA(wa_bsid) WHERE bukrs = it_head-bukrs
                                         AND kunnr = it_head-kunnr.
      wa_final-sec_dep = wa_bsid-dmbtr +  wa_final-sec_dep.
    ENDLOOP.
    READ TABLE it_head_due WITH KEY kunnr = it_head-kunnr
                                    bukrs = it_head-bukrs.
    IF sy-subrc = 0.
      wa_final-due4 = it_head_due-due4.
      wa_final-notdue = it_head_due-notdue.
    ENDIF.
    READ TABLE it_t052 INTO DATA(wa_t052) WITH KEY zterm = it_head-zterm.
    IF sy-subrc = 0.
      IF wa_t052-ztag3 IS NOT INITIAL.
        wa_final-pay_trm_days = wa_t052-ztag3.
      ELSEIF wa_t052-ztag2 IS NOT INITIAL.
        wa_final-pay_trm_days = wa_t052-ztag2.
      ELSEIF wa_t052-ztag1 IS NOT INITIAL.
        wa_final-pay_trm_days = wa_t052-ztag1.
      ENDIF.
    ENDIF.

    IF wa_final-due4 IS NOT INITIAL.
      IF wa_final-sec_dep LT wa_final-netot.
        READ TABLE lt_logic INTO DATA(ls_logic) WITH KEY payment_termdays = wa_final-pay_trm_days.
        IF sy-subrc = 0.

          lv_days = ls_logic-billing_days.

          CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'       "Fetch date for previous month
            EXPORTING
              date      = s_date
              days      = lv_days
              months    = '00'
              signum    = '-'
              years     = '00'
            IMPORTING
              calc_date = lv_date.

          LOOP AT it_detail WHERE kunnr = it_head-kunnr
                             AND  bukrs = it_head-bukrs
                             AND  blart = 'RV'
                             AND  blart = 'UE'
                             AND  shkzg = 'S'
                             AND  budat BETWEEN lv_date AND s_date
                             AND  zuonr IS NOT INITIAL.

            DATA(lv_flag) = 'X'.
            EXIT.
          ENDLOOP.
        ENDIF.
*        READ TABLE it_detail WITH KEY kunnr = it_head-kunnr
*                                      bukrs = it_head-bukrs
*                                      blart = 'RV'
*                                      shkzg = 'S'.
        IF lv_flag = 'X'.
*          IF it_detail-zuonr IS INITIAL.
*            wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
*            wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
*          ELSE.
          DATA(lv_cnt) = s_date - it_detail-budat.
*            READ TABLE lt_logic INTO DATA(ls_logic) WITH KEY payment_termdays = wa_final-pay_trm_days.
*            IF sy-subrc = 0.
          IF lv_cnt LE ls_logic-billing_days.
            lv_ageslb1 = ageslb1 + 1.
            lv_ageslb2 = ageslb2 + 1.
            lv_ageslb3 = ageslb3 + 1.
            lv_ageslb4 = ageslb4 + 1.
            lv_ageslb5 = ageslb5 + 1.
            lv_ageslb6 = ageslb6 + 1.
            lv_ageslb7 = ageslb7 + 1.
            IF ls_logic-aging_days BETWEEN 0 AND ageslb1.
              IF wa_final-cdam1 IS NOT INITIAL OR wa_final-cdam2 IS NOT INITIAL OR wa_final-cdam3 IS NOT INITIAL
                OR wa_final-cdam4 IS NOT INITIAL OR wa_final-cdam5 IS NOT INITIAL OR wa_final-cdam6 IS NOT INITIAL
                OR wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
*              ELSEIF ls_logic-aging_days BETWEEN lv_ageslb1 AND ageslb2.
            ELSEIF ls_logic-aging_days GE ageslb1 AND ls_logic-aging_days LT ageslb2.
              IF wa_final-cdam2 IS NOT INITIAL OR wa_final-cdam3 IS NOT INITIAL OR wa_final-cdam4 IS NOT INITIAL
                OR wa_final-cdam5 IS NOT INITIAL OR wa_final-cdam6 IS NOT INITIAL OR wa_final-cdam7 IS NOT INITIAL
                OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
*              ELSEIF ls_logic-aging_days BETWEEN lv_ageslb2 AND ageslb3.
            ELSEIF ls_logic-aging_days GE ageslb2 AND ls_logic-aging_days LT ageslb3.
              IF wa_final-cdam3 IS NOT INITIAL OR wa_final-cdam4 IS NOT INITIAL OR wa_final-cdam5 IS NOT INITIAL
                OR wa_final-cdam6 IS NOT INITIAL OR wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
            ELSEIF ls_logic-aging_days GE ageslb3 AND ls_logic-aging_days LT ageslb4.
              IF  wa_final-cdam4 IS NOT INITIAL OR wa_final-cdam5 IS NOT INITIAL OR wa_final-cdam6 IS NOT INITIAL
                OR wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
*              ELSEIF ls_logic-aging_days BETWEEN lv_ageslb4 AND ageslb5.
            ELSEIF ls_logic-aging_days GE ageslb4 AND ls_logic-aging_days LT ageslb5.
              IF wa_final-cdam5 IS NOT INITIAL OR wa_final-cdam6 IS NOT INITIAL
                OR wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
*              ELSEIF ls_logic-aging_days BETWEEN lv_ageslb5 AND ageslb6.
            ELSEIF ls_logic-aging_days GE ageslb5 AND ls_logic-aging_days LT ageslb6.
              IF  wa_final-cdam6 IS NOT INITIAL OR wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
*              ELSEIF ls_logic-aging_days BETWEEN lv_ageslb6 AND ageslb7.
            ELSEIF ls_logic-aging_days GE ageslb6 AND ls_logic-aging_days LT ageslb7.
              IF wa_final-cdam7 IS NOT INITIAL OR wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
            ELSEIF ls_logic-aging_days GT ageslb7.
              IF  wa_final-cdam8 IS NOT INITIAL.
                wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
                IF wa_final-sec_dep LT wa_final-due4.
                  wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
                ENDIF.
              ENDIF.
            ENDIF.
          ELSE.
            wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
            IF wa_final-sec_dep LT wa_final-due4.
              wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
            ENDIF.
          ENDIF.
*            ELSEIF wa_final-pay_trm_days IS INITIAL.
*              wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
*              IF wa_final-sec_dep LT wa_final-due4.
*                wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
*              ENDIF.
*            ELSE.
*              CLEAR: ls_mis_kdgrp,wa_knvv,it_head,wa_final.
*              CONTINUE.
*            ENDIF.
*          ENDIF.
        ELSE.
          READ TABLE lt_logic INTO ls_logic WITH KEY payment_termdays = wa_final-pay_trm_days.
          IF sy-subrc = 0.
            wa_final-cos_amt = wa_final-netot - wa_final-sec_dep.
            wa_final-cod_amt = wa_final-due4 - wa_final-sec_dep.
          ELSE.
            CLEAR: ls_mis_kdgrp,wa_knvv,it_head,wa_final.
            CONTINUE.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
    READ TABLE it_legal_case INTO DATA(wa_legal_case) WITH KEY kunnr = it_head-kunnr
                                                               vkorg = wa_knvv-vkorg.
    IF sy-subrc = 0.
      wa_final-legalcase = it_head-netot.
      CLEAR: wa_final-cos_amt, wa_final-cod_amt.
    ENDIF.
    IF wa_final-netot IS NOT INITIAL.
      wa_final-od_os_pr = ( wa_final-due4 / wa_final-netot ) * 100.
      wa_final-cod_cos_pr = ( wa_final-cod_amt / wa_final-netot ) * 100.
    ENDIF.

    IF wa_final-cos_amt < 0.
      wa_final-cos_amt = '0.00'.
    ENDIF.

    IF wa_final-cod_amt < 0.
      wa_final-cod_amt = '0.00'.
    ENDIF.


    APPEND wa_final TO it_final.
    CLEAR: ls_mis_kdgrp,wa_knvv,it_head,wa_final,wa_bsid,wa_t052,it_detail,it_head_due.
  ENDLOOP.

  REFRESH: it_head, it_detail,it_head_due,it_knvv,it_legal_case, it_manage, it_sale_head.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fcat.

  DATA: pit_slabsdays(4) TYPE n.
  DATA: lbcdam1(10)      TYPE c.
  DATA: tcounter(1)      TYPE n.

  REFRESH it_fcat.

  wa_fcat-fieldname = 'DIVISION'.
  wa_fcat-seltext_l = 'Division'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'SALES_OFFICE'.
  wa_fcat-seltext_l = 'Sales Office'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'TSM_SALES_GRP'.
  wa_fcat-seltext_l = 'TSM Sales Group'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'KUNNR'.
  wa_fcat-seltext_l = 'Party Code'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'NAME'.
  wa_fcat-seltext_l = 'Name'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  LOOP AT it_slabs.
    CLEAR wa_fcat.

    WRITE it_slabs-days NO-ZERO TO it_slabs-days.
    WRITE pit_slabsdays NO-ZERO TO pit_slabsdays.

    CONCATENATE 'CDAM' it_slabs-slab INTO wa_fcat-fieldname .
*    wa_fcat-fieldname    = fldname.

    IF sy-tabix = 1.
      CONCATENATE '0 - ' it_slabs-days INTO lbcdam1.
      pit_slabsdays = it_slabs-days + 1.
    ELSE.
      CONCATENATE pit_slabsdays ' - ' it_slabs-days INTO lbcdam1.
      pit_slabsdays = it_slabs-days + 1.
    ENDIF.
    wa_fcat-seltext_m = lbcdam1.
    wa_fcat-do_sum = 'X'.
    wa_fcat-outputlen    = 14.
    wa_fcat-just = 'R'.
    APPEND wa_fcat TO it_fcat.
    tcounter = tcounter + 1.
  ENDLOOP.

  tcounter = tcounter + 1.
  CLEAR wa_fcat.
  CONCATENATE 'CDAM' tcounter INTO wa_fcat-fieldname.
*  wa_fcat-fieldname    = fldname.
  WRITE pit_slabsdays NO-ZERO TO pit_slabsdays.
  CONCATENATE ' > ' pit_slabsdays INTO lbcdam1.
  wa_fcat-seltext_m = lbcdam1.
  wa_fcat-do_sum = 'X'.
  wa_fcat-outputlen    = 14.
  wa_fcat-just = 'R'.
  APPEND wa_fcat TO it_fcat.

  wa_fcat-fieldname = 'NETOT'.
  wa_fcat-seltext_l = 'Net Outstanding'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'NOTDUE'.
  wa_fcat-seltext_l = 'Not Due Amount'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'SEC_DEP'.
  wa_fcat-seltext_l = 'Security Deposit'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'DUE4'.
  wa_fcat-seltext_l = 'Overdue Amount'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'COS_AMT'.
  wa_fcat-seltext_l = 'Critical Outstanding'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'COD_AMT'.
  wa_fcat-seltext_l = 'Critical Overdue'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'ZTERM'.
  wa_fcat-seltext_l = 'Payment term KEY'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'TEXT1'.
  wa_fcat-seltext_l = 'Payment Term desc.'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'PAY_TRM_DAYS'.
  wa_fcat-seltext_l = 'Payment term days'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'LEGALCASE'.
  wa_fcat-seltext_l = 'Legal Case filed'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'OD_OS_PR'.
  wa_fcat-seltext_l = 'OD Vs. OS in%'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'COD_COS_PR'.
  wa_fcat-seltext_l = 'Critical OD Vs. OS in %'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-fieldname = 'DEFAULT'.
  wa_fcat-seltext_l = 'Default %'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      i_save             = 'A'
      it_fieldcat        = it_fcat
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_SLABS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_slabs .

  IF ageslb1 IS NOT INITIAL.
    CLEAR it_slabs.
    DATA(agex) = ageslb1.
    it_slabs-slab = 1.
    it_slabs-days = ageslb1.
    APPEND it_slabs.
  ENDIF.
  IF ageslb2 IS NOT INITIAL.
    CLEAR it_slabs.
    agex = ageslb2.
    it_slabs-slab = 2.
    it_slabs-days = ageslb2.
    APPEND it_slabs.
  ENDIF.
  IF ageslb3 IS NOT INITIAL.
    CLEAR it_slabs.
    agex = ageslb3.
    it_slabs-slab = 3.
    it_slabs-days = ageslb3.
    APPEND it_slabs.
  ENDIF.
  IF ageslb4 IS NOT INITIAL.
    CLEAR it_slabs.
    agex = ageslb4.
    it_slabs-slab = 4.
    it_slabs-days = ageslb4.
    APPEND it_slabs.
  ENDIF.
  IF ageslb5 IS NOT INITIAL.
    agex = ageslb5.
    CLEAR it_slabs.
    it_slabs-slab = 5.
    it_slabs-days = ageslb5.
    APPEND it_slabs.
  ENDIF.
  IF ageslb6 IS NOT INITIAL.
    agex = ageslb6.
    CLEAR it_slabs.
    it_slabs-slab = 6.
    it_slabs-days = ageslb6.
    APPEND it_slabs.
  ENDIF.

  IF ageslb7 IS NOT INITIAL.
    agex = ageslb7.
    CLEAR it_slabs.
    it_slabs-slab = 7.
    it_slabs-days = ageslb7.
    APPEND it_slabs.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORITY_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authority_check .

  DATA lv_msg TYPE char100.

  LOOP AT vkorg.
    AUTHORITY-CHECK OBJECT 'ZFI_VKORG'
             ID 'ACTVT' FIELD '03'
             ID 'VKORG' FIELD vkorg-low.
    IF sy-subrc <> 0.
      CONCATENATE 'You are not authorized for Sales Organizaion' vkorg-low INTO lv_msg.
      MESSAGE lv_msg TYPE 'E'.
    ENDIF.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SENT_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM sent_mail .

  DATA : main_text      TYPE bcsy_text,
         binary_content TYPE solix_tab,
         size           TYPE so_obj_len,
         send_to_all    TYPE os_boolean,
         lv_attachname  TYPE so_obj_des,
         lv_string      TYPE string.

  DATA : lv_mailtext TYPE char255.
  DATA : gc_tab         TYPE c VALUE cl_bcs_convert=>gc_tab,
         gc_crlf        TYPE c VALUE cl_bcs_convert=>gc_crlf,
         send_request   TYPE REF TO cl_bcs,
         sender         TYPE REF TO cl_cam_address_bcs,
         document       TYPE REF TO cl_document_bcs,
         recipient      TYPE REF TO if_recipient_bcs,
         recipient_cc   TYPE REF TO if_recipient_bcs,
         lv_mail        TYPE adr6-smtp_addr,
         bcs_exception  TYPE REF TO cx_bcs,
         lv_tot_n       TYPE bsid-dmbtr,
         lv_tot_od      TYPE bsid-dmbtr,
         lv_tot_cos     TYPE bsid-dmbtr,
         lv_tot_cod     TYPE bsid-dmbtr,
         lv_tot_l       TYPE bsid-dmbtr,
         lv_tot_osdp    TYPE bsid-dmbtr,
         lv_tot_cosdp   TYPE bsid-dmbtr,
         lv_tot_osdp_n  TYPE i,
         lv_tot_cosdp_n TYPE i,
         lv_tot_nc      TYPE char20,
         lv_tot_odc     TYPE char20,
         lv_tot_cosc    TYPE char20,
         lv_tot_codc    TYPE char20,
         lv_tot_lc      TYPE char20,
         lv_tot_osdpc   TYPE char20,
         lv_tot_cosdpc  TYPE char20.

  DATA: lv_slab1 TYPE char3,
        lv_slab2 TYPE char3,
        lv_slab3 TYPE char3,
        lv_slab4 TYPE char3,
        lv_slab5 TYPE char3,
        lv_slab6 TYPE char3.

  DATA: lv_age1 TYPE char10,
        lv_age2 TYPE char10,
        lv_age3 TYPE char10,
        lv_age4 TYPE char10,
        lv_age5 TYPE char10,
        lv_age6 TYPE char10,
        lv_age7 TYPE char10,
        lv_age8 TYPE char10.

  DATA: lv_cdam1  TYPE char20,
        lv_cdam2  TYPE char20,
        lv_cdam3  TYPE char20,
        lv_cdam4  TYPE char20,
        lv_cdam5  TYPE char20,
        lv_cdam6  TYPE char20,
        lv_cdam7  TYPE char20,
        lv_cdam8  TYPE char20,
        lv_nettot TYPE char20.

  DATA: lv_slb1 TYPE char3,
        lv_slb2 TYPE char3,
        lv_slb3 TYPE char3,
        lv_slb4 TYPE char3,
        lv_slb5 TYPE char3,
        lv_slb6 TYPE char3,
        lv_slb7 TYPE char4.

  DATA: lv_mail1 TYPE char100,
        lv_mail2 TYPE char100,
        lv_mail3 TYPE char100,
        lv_mail4 TYPE char100,
        lv_mail5 TYPE char100,
        lv_email TYPE string.

  SELECT SINGLE low FROM tvarvc INTO @DATA(lv_switch) WHERE name = 'ZCHK_EMAIL_TRIGGER'.

  IF sy-subrc = 0.
    IF p_chk IS NOT INITIAL.

      lv_mailtext = |<!DOCTYPE html>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<head>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</head>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<body>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = 'Dear Sir,'.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = '<br>'.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<p font-size: 10>Please find below division wise summary of | & | <b> Overdue Vs Outstanding comparison </b> | &
                    | as on | & |{ s_date+6(2) }| & |.| & |{ s_date+4(2) }| & |.| & |{ s_date+0(4) }| & |</p>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

*      lv_mailtext = '<br>'.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.


*      lv_mailtext = '<u> DIVISION WISE COMPARISON OF CRITICAL AND TOTAL OD VS OS </u> '.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

*      lv_mailtext = '<br>'.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

      lv_mailtext = '<br>'.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = 'Summary in lakh'.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = '<br>'.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<table style="width:50%;border:1px solid black;border-collapse:collapse">|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<tr  style = "border:1px solid black;border-collapse:collapse">|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Division </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Net OS </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Overdue Amt. </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OS </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

*      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OD(OD-SD) </th>|.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Legal Case Filled </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> OD Vs. OS in %  </th>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

*      lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OD Vs. OS in % </th>|.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

      lv_mailtext = |</tr>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb1
        IMPORTING
          output = ageslb1.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb2
        IMPORTING
          output = ageslb2.


      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb3
        IMPORTING
          output = ageslb3.


      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb4
        IMPORTING
          output = ageslb4.


      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb5
        IMPORTING
          output = ageslb5.


      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb6
        IMPORTING
          output = ageslb6.


      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ageslb7
        IMPORTING
          output = ageslb7.

      DATA(lv_ageslb1) = ageslb1 + 1.
      DATA(lv_ageslb2) = ageslb2 + 1.
      DATA(lv_ageslb3) = ageslb3 + 1.
      DATA(lv_ageslb4) = ageslb4 + 1.
      DATA(lv_ageslb5) = ageslb5 + 1.
      DATA(lv_ageslb6) = ageslb6 + 1.
      DATA(lv_ageslb7) = ageslb7 + 1.

      lv_slab1 = lv_ageslb1.
      lv_slab2 = lv_ageslb2.
      lv_slab3 = lv_ageslb3.
      lv_slab4 = lv_ageslb4.
      lv_slab5 = lv_ageslb5.
      lv_slab6 = lv_ageslb6.

      lv_slb1 = ageslb1.
      lv_slb2 = ageslb2.
      lv_slb3 = ageslb3.
      lv_slb4 = ageslb4.
      lv_slb5 = ageslb5.
      lv_slb6 = ageslb6.
      lv_slb7 = ageslb7.

      CONDENSE: lv_slb1,lv_slab2, lv_slb3, lv_slb4, lv_slb5, lv_slb6, lv_slb7,
                lv_slab1, lv_slab2, lv_slab3, lv_slab4, lv_slab5, lv_slab6.

      CONCATENATE '0 -' lv_slb1 INTO lv_age1 SEPARATED BY space.
      CONCATENATE lv_slab1 '-' lv_slb2 INTO lv_age2 SEPARATED BY space.
      CONCATENATE lv_slab2 '-' lv_slb3 INTO lv_age3 SEPARATED BY space.
      CONCATENATE lv_slab3 '-' lv_slb4 INTO lv_age4 SEPARATED BY space.
      CONCATENATE lv_slab4 '-' lv_slb5 INTO lv_age5.
      CONCATENATE lv_slab5 '-' lv_slb6 INTO lv_age6.
      CONCATENATE lv_slab6 '-' lv_slb7 INTO lv_age7.
      CONCATENATE '>' lv_slb7 INTO lv_age8.

      CONCATENATE 'Division'                  gc_tab
                  'Sales Office'              gc_tab
                  'Sales Group'               gc_tab
                  'Customer'                  gc_tab
                  'Name'                      gc_tab
                  lv_age1                     gc_tab
                  lv_age2                     gc_tab
                  lv_age3                     gc_tab
                  lv_age4                     gc_tab
                  lv_age5                     gc_tab
                  lv_age6                     gc_tab
                  lv_age7                     gc_tab
                  lv_age8                     gc_tab
                  'Net OS'                    gc_tab
                  'Not Due'                   gc_tab
                  'Security Deposit'          gc_tab
                  'OD Amt.'                   gc_tab
                  'Critical OS(OS-SD)'        gc_tab
*                  'Critical OD(OD-SD)'        gc_tab
                  'Payment terms'             gc_tab
                  'payment term Description'  gc_tab
                  'payment term Days'         gc_tab
                  'Legal Case Filled'         gc_tab
                  'OD Vs. OS in %'            gc_tab
*                  'Critical OD Vs. OS in %'   gc_crlf
                  INTO lv_string.

      SELECT * FROM tvarvc INTO TABLE @DATA(it_tvarvc) WHERE name = 'ZFI_MIS_KDGRP_SEQ'.
      SORT it_final BY division.
      LOOP AT it_tvarvc INTO DATA(wa_tvarvc).
        LOOP AT it_final INTO wa_final WHERE division = wa_tvarvc-low+2(52).
          lv_tot_netot      = lv_tot_netot + wa_final-netot.
          lv_tot_due4       = lv_tot_due4 + wa_final-due4.
          lv_tot_cos_amt    = lv_tot_cos_amt + wa_final-cos_amt.
          lv_tot_cod_amt    = lv_tot_cod_amt + wa_final-cod_amt.
          lv_tot_legalcase  = lv_tot_legalcase + wa_final-legalcase.
          AT END OF division.
            lv_tot_netot      = lv_tot_netot / 100000.
            lv_tot_due4       = lv_tot_due4 / 100000.
            lv_tot_cos_amt    = lv_tot_cos_amt / 100000.
            lv_tot_cod_amt    = lv_tot_cod_amt / 100000.
            lv_tot_legalcase  = lv_tot_legalcase / 100000.
            lv_tot_od_os_pr = ( lv_tot_due4 / lv_tot_netot ) * 100.
            lv_tot_cod_cos_pr = ( lv_tot_cod_amt / lv_tot_netot ) * 100.
            wa_manage-division   = wa_final-division.
            wa_manage-netot      = lv_tot_netot.
            wa_manage-due4       = lv_tot_due4.
            wa_manage-cos_amt    = lv_tot_cos_amt.
*            wa_manage-cod_amt    = lv_tot_cod_amt.
            wa_manage-legalcase  = lv_tot_legalcase.
            wa_manage-od_os_pr   = lv_tot_od_os_pr.
*            wa_manage-cod_cos_pr = lv_tot_cod_cos_pr.
            APPEND wa_manage TO it_manage.
            CLEAR: wa_manage, lv_tot_netot, lv_tot_due4, lv_tot_cos_amt,
            lv_tot_cod_amt, lv_tot_legalcase, lv_tot_od_os_pr, lv_tot_cod_cos_pr.
          ENDAT.

          lv_cdam1      = wa_final-cdam1.
          lv_cdam2      = wa_final-cdam2.
          lv_cdam3      = wa_final-cdam3.
          lv_cdam4      = wa_final-cdam4.
          lv_cdam5      = wa_final-cdam5.
          lv_cdam6      = wa_final-cdam6.
          lv_cdam7      = wa_final-cdam7.
          lv_cdam8      = wa_final-cdam8.
          lv_nettot     = wa_final-netot.
          lv_notdue     = wa_final-notdue.
          lv_sec_dep    = wa_final-sec_dep.
          lv_due4       = wa_final-due4.
          lv_cos        = wa_final-cos_amt.
*          lv_cod        = wa_final-cod_amt.
          lv_paytrmdays = wa_final-pay_trm_days.
          lv_odospr     = wa_final-od_os_pr.
*          lv_codospr    = wa_final-cod_cos_pr.

          CONDENSE: lv_cdam1,
                    lv_cdam2,
                    lv_cdam3,
                    lv_cdam4,
                    lv_cdam5,
                    lv_cdam6,
                    lv_cdam7,
                    lv_cdam8,
                    lv_nettot,
                    lv_notdue,
                    lv_sec_dep,
                    lv_due4,
                    lv_cos,
*                    lv_cod,
                    lv_paytrmdays,
                    lv_odospr.
*                    lv_codospr.

          CONCATENATE lv_string
                      wa_final-division      gc_tab
                      wa_final-sales_office  gc_tab
                      wa_final-tsm_sales_grp gc_tab
                      wa_final-kunnr         gc_tab
                      wa_final-name          gc_tab
                      lv_cdam1               gc_tab
                      lv_cdam2               gc_tab
                      lv_cdam3               gc_tab
                      lv_cdam4               gc_tab
                      lv_cdam5               gc_tab
                      lv_cdam6               gc_tab
                      lv_cdam7               gc_tab
                      lv_cdam8               gc_tab
                      lv_nettot              gc_tab
                      lv_notdue              gc_tab
                      lv_sec_dep             gc_tab
                      lv_due4                gc_tab
                      lv_cos                 gc_tab
*                      lv_cod                 gc_tab
                      wa_final-zterm         gc_tab
                      wa_final-text1         gc_tab
                      lv_paytrmdays          gc_tab
                      wa_final-legalcase     gc_tab
                      lv_odospr              gc_crlf"gc_tab
*                      lv_codospr             gc_crlf
                      INTO lv_string.
        ENDLOOP.
      ENDLOOP.

      LOOP AT it_manage INTO wa_manage.
        lv_mailtext = |<tr> <td style="border:1px solid black;border-collapse: collapse"> { wa_manage-division } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_tot_netot      = wa_manage-netot.
        lv_tot_due4       = wa_manage-due4.
        lv_tot_cos_amt    = wa_manage-cos_amt.
*        lv_tot_cod_amt    = wa_manage-cod_amt.
        lv_tot_legalcase  = wa_manage-legalcase.
        lv_tot_od_os_pr   = wa_manage-od_os_pr.
*        lv_tot_cod_cos_pr = wa_manage-cod_cos_pr.

        lv_tot_n          = lv_tot_netot + lv_tot_n.
        lv_tot_od         = lv_tot_due4 + lv_tot_od.
        lv_tot_cos        = lv_tot_cos_amt + lv_tot_cos.
*        lv_tot_cod        = lv_tot_cod_amt + lv_tot_cod.
        lv_tot_l          = lv_tot_legalcase + lv_tot_l.
        lv_tot_osdp       = ( lv_tot_od / lv_tot_n ) * 100.
*        lv_tot_cosdp      = ( lv_tot_cod / lv_tot_n ) * 100.

        lv_tot_nc     =  lv_tot_n.
        CONDENSE lv_tot_nc.
        lv_tot_odc    =  lv_tot_od.
        CONDENSE lv_tot_odc.
        lv_tot_cosc   =  lv_tot_cos.
        CONDENSE lv_tot_cosc.
        lv_tot_codc   =  lv_tot_cod.
        CONDENSE lv_tot_codc.
        lv_tot_lc     =  lv_tot_l.
        CONDENSE lv_tot_lc.
        lv_tot_osdpc  =  lv_tot_osdp.
        CONDENSE lv_tot_osdpc.
        lv_tot_cosdpc =  lv_tot_cosdp.
        CONDENSE lv_tot_cosdpc.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_manage-netot } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_manage-due4 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_manage-cos_amt } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

*        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_manage-cod_amt } </td>|.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_manage-legalcase } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_od_os_pr = abs( wa_manage-od_os_pr ).
        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { lv_od_os_pr }% </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext,lv_od_os_pr.

*        lv_cod_cos_pr = abs( wa_manage-cod_cos_pr ).
*        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { lv_cod_cos_pr }% </td> </tr>|.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext,lv_od_os_pr,lv_cod_cos_pr.

      ENDLOOP.

      lv_mailtext = |<tr style="border:1px solid black;border-collapse: collapse"> <td> <b> Total </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = | <td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_n } </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_od } </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cos } </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

*      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cod } </b> </td>|.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_l } </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_tot_osdp_n = abs( lv_tot_osdp ).
      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_osdp_n }% </b> </td>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

*      lv_tot_cosdp_n = abs( lv_tot_cosdp ).
*      lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cosdp_n }%  </b> </td> </tr>|.
*      APPEND lv_mailtext TO main_text.
*      CLEAR : lv_mailtext.

      lv_mailtext = |</table>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</br>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<h5> Note:- </h5>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<h5> 1. The amount for critical cases is calculated separately, excluding legal cases. </h5>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<h5> 2. Critical Outstanding amount mentioned after adjusting SD. </h5>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<br>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |Thanks & Regards,|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<br>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<b>Team Credit Control - Astral Adhesive Division</b>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<br>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<br>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |*This is system generated e-mail, do not reply to this e-mail id.* |.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</body>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</html>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      TRY .
          send_request = cl_bcs=>create_persistent( ).
          sender = cl_cam_address_bcs=>create_internet_address(
            i_address_string = 'SAP.ASTRAL@ASTRALLTD.COM'
*           i_incl_sapuser   = 'X'
          ).

          CALL METHOD send_request->set_sender( sender ).
          document = cl_document_bcs=>create_document(
            i_type    = 'HTM'
            i_subject = 'Division wise comparison of critical and total OD vs OS as on ' && ' ' &&
                        s_date+6(2) && '.' && s_date+4(2) && '.' && s_date+0(4)
            i_text    = main_text ).

          cl_bcs_convert=>string_to_solix(
            EXPORTING
              iv_string   = lv_string   " Input data
              iv_codepage = '4103'   " Target Code Page in SAP Form  (Default = SAPconnect Setting)
              iv_add_bom  = 'X'   " Add Byte-Order Mark
            IMPORTING
              et_solix    = binary_content  " Output data
              ev_size     = size  " Size of Document Content
          ).


          document->add_attachment(
            EXPORTING
              i_attachment_type    = 'XLS'  " Document Class for Attachment
              i_attachment_subject = 'Critical and total OD vs OS' && s_date+6(2) && '.' && s_date+4(2) && '.' && s_date+0(4)  " Attachment Title
              i_attachment_size    = size   " Size of Document Content
              i_att_content_hex    = binary_content   " Content (Binary)
          ).

          send_request->set_document( document ).

          SELECT * FROM tvarvc INTO TABLE @DATA(lt_mail) WHERE name = 'COD_MAN_TO '.
          SELECT * FROM tvarvc INTO TABLE @DATA(lt_mail_cc) WHERE name = 'COD_MAN_CC '.

          LOOP AT lt_mail INTO DATA(ls_mail).
            lv_mail = ls_mail-low."'SAP.ABAP@ASTRALLTD.COM'. "
            recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
            send_request->add_recipient( recipient ).
          ENDLOOP.

          LOOP AT lt_mail_cc INTO DATA(ls_mail_cc).
            lv_mail = ls_mail_cc-low."'SAP.ABAP@ASTRALLTD.COM'. "
            recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
            send_request->add_recipient( EXPORTING i_recipient = recipient
                                                   i_copy      = abap_true ).
          ENDLOOP.

          send_to_all = send_request->send( i_with_error_screen = 'X' ).
          IF send_to_all IS NOT INITIAL.
            COMMIT WORK.
            MESSAGE 'Mail Send Successfully' TYPE 'S'.
          ELSE.
            MESSAGE 'Error While Send Email' TYPE 'S' DISPLAY LIKE 'E'.
            RETURN.
          ENDIF.
        CATCH cx_bcs INTO bcs_exception.

      ENDTRY.
      "MAIL ENDS
      CLEAR: lv_string, lv_age1,lv_age2,lv_age3,lv_age4,lv_age5,lv_age6,lv_age7,lv_age8,lv_ageslb1,lv_ageslb2,lv_ageslb3,lv_ageslb4,
             lv_ageslb5,lv_ageslb6,lv_ageslb7,lv_attachname,lv_cdam1,lv_cdam2,lv_cdam3,lv_cdam4,lv_cdam5,lv_cdam6,lv_cdam7,lv_cdam8,
             lv_string,lv_cod,lv_codospr,lv_cos,lv_due4,lv_mail,lv_mailtext,lv_nettot,lv_notdue,lv_odospr,lv_paytrmdays,lv_sec_dep,
             lv_slab1,lv_slab2,lv_slab3,lv_slab4,lv_slab5,lv_slab6,lv_slb1,lv_slb2,lv_slb3,lv_slb4,lv_slb5,lv_slb6,lv_slb7,lv_tot_cod,
             lv_tot_cod_amt,lv_tot_cod_cos_pr,lv_tot_codc,lv_tot_cos,lv_tot_cos_amt,lv_tot_cosc,lv_tot_cosdp,lv_tot_cosdpc,lv_tot_due4,
             lv_tot_l,lv_tot_lc,lv_tot_legalcase,lv_tot_n,lv_tot_nc,lv_tot_netot,lv_tot_od,lv_tot_od_os_pr,lv_tot_odc,lv_tot_osdp,
             lv_tot_osdpc.
    ENDIF.

    IF p_chk1 IS NOT INITIAL.

      IF it_final IS NOT INITIAL.

        SELECT * FROM zfi_cod_mail_div INTO TABLE @DATA(it_mail_div)
          FOR ALL ENTRIES IN @it_final WHERE division = @it_final-division.

      ENDIF.

      SORT it_mail_div BY groupping.
      DATA(it_mail_div_t) = it_mail_div.
      DELETE ADJACENT DUPLICATES FROM it_mail_div_t COMPARING groupping.
      LOOP AT it_mail_div_t INTO DATA(wa_mail_div_t).
        lv_mailtext = |<!DOCTYPE html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<body>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = 'Dear All,'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<br>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p font-size: 10> Please find attached customer wise detail along below comparison of critical and total OD vs OS | &
                      | as on | & |{ s_date+6(2) }| & |.| & |{ s_date+4(2) }| & |.| & |{ s_date+0(4) }</p>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<br>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = 'Summary in lakh'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<br>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<table style="width:50%;border:1px solid black;border-collapse: collapse">|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<tr style="border:1px solid black;border-collapse: collapse">|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> RSM Name </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Net OS </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> OD Amt. </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OS(OS-SD) </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OD(OD-SD) </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Legal Case Filled </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> OD Vs. OS in %  </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Critical OD Vs. OS in % </th> </tr>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb1
          IMPORTING
            output = ageslb1.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb2
          IMPORTING
            output = ageslb2.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb3
          IMPORTING
            output = ageslb3.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb4
          IMPORTING
            output = ageslb4.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb5
          IMPORTING
            output = ageslb5.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb6
          IMPORTING
            output = ageslb6.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb7
          IMPORTING
            output = ageslb7.

        lv_ageslb1 = ageslb1 + 1.
        lv_ageslb2 = ageslb2 + 1.
        lv_ageslb3 = ageslb3 + 1.
        lv_ageslb4 = ageslb4 + 1.
        lv_ageslb5 = ageslb5 + 1.
        lv_ageslb6 = ageslb6 + 1.
        lv_ageslb7 = ageslb7 + 1.

        lv_slab1 = lv_ageslb1.
        lv_slab2 = lv_ageslb2.
        lv_slab3 = lv_ageslb3.
        lv_slab4 = lv_ageslb4.
        lv_slab5 = lv_ageslb5.
        lv_slab6 = lv_ageslb6.

        lv_slb1 = ageslb1.
        lv_slb2 = ageslb2.
        lv_slb3 = ageslb3.
        lv_slb4 = ageslb4.
        lv_slb5 = ageslb5.
        lv_slb6 = ageslb6.
        lv_slb7 = ageslb7.

        CONDENSE: lv_slb1,lv_slab2, lv_slb3, lv_slb4, lv_slb5, lv_slb6, lv_slb7,
                  lv_slab1, lv_slab2, lv_slab3, lv_slab4, lv_slab5, lv_slab6.

        CONCATENATE '0 -' lv_slb1 INTO lv_age1 SEPARATED BY space.
        CONCATENATE lv_slab1 '-' lv_slb2 INTO lv_age2 SEPARATED BY space.
        CONCATENATE lv_slab2 '-' lv_slb3 INTO lv_age3 SEPARATED BY space.
        CONCATENATE lv_slab3 '-' lv_slb4 INTO lv_age4 SEPARATED BY space.
        CONCATENATE lv_slab4 '-' lv_slb5 INTO lv_age5.
        CONCATENATE lv_slab5 '-' lv_slb6 INTO lv_age6.
        CONCATENATE lv_slab6 '-' lv_slb7 INTO lv_age7.
        CONCATENATE '>' lv_slb7 INTO lv_age8.

        CONCATENATE 'Division'                  gc_tab
                    'Sales Office'              gc_tab
                    'Sales Group'               gc_tab
                    'Customer'                  gc_tab
                    'Name'                      gc_tab
                    lv_age1                     gc_tab
                    lv_age2                     gc_tab
                    lv_age3                     gc_tab
                    lv_age4                     gc_tab
                    lv_age5                     gc_tab
                    lv_age6                     gc_tab
                    lv_age7                     gc_tab
                    lv_age8                     gc_tab
                    'Net OS'                    gc_tab
                    'Not Due'                   gc_tab
                    'Security Deposit'          gc_tab
                    'OD Amt.'                   gc_tab
                    'Critical OS(OS-SD)'        gc_tab
                    'Critical OD(OD-SD)'        gc_tab
                    'Payment terms'             gc_tab
                    'payment term Description'  gc_tab
                    'payment term Days'         gc_tab
                    'Legal Case Filled'         gc_tab
                    'OD Vs. OS in %'            gc_tab
                    'Critical OD Vs. OS in %'   gc_crlf
                    INTO lv_string.

        SORT it_final BY sales_office group.
        LOOP AT it_final INTO wa_final WHERE group = wa_mail_div_t-groupping.
          wa_sale_head-group = wa_mail_div_t-groupping.
          wa_sale_head-sales_office = wa_final-sales_office.
          wa_sale_head-netot = wa_final-netot.
          wa_sale_head-due4 = wa_final-due4.
          wa_sale_head-cos_amt = wa_final-cos_amt.
          wa_sale_head-cod_amt = wa_final-cod_amt.
          wa_sale_head-legalcase = wa_final-legalcase.
          COLLECT wa_sale_head INTO it_sale_head.
          CLEAR wa_sale_head.
          lv_cdam1      = wa_final-cdam1.
          lv_cdam2      = wa_final-cdam2.
          lv_cdam3      = wa_final-cdam3.
          lv_cdam4      = wa_final-cdam4.
          lv_cdam5      = wa_final-cdam5.
          lv_cdam6      = wa_final-cdam6.
          lv_cdam7      = wa_final-cdam7.
          lv_cdam8      = wa_final-cdam8.
          lv_nettot     = wa_final-netot.
          lv_notdue     = wa_final-notdue.
          lv_sec_dep    = wa_final-sec_dep.
          lv_due4       = wa_final-due4.
          lv_cos        = wa_final-cos_amt.
          lv_cod        = wa_final-cod_amt.
          lv_paytrmdays = wa_final-pay_trm_days.
          lv_odospr     = wa_final-od_os_pr.
          lv_codospr    = wa_final-cod_cos_pr.

          CONDENSE: lv_cdam1,
                    lv_cdam2,
                    lv_cdam3,
                    lv_cdam4,
                    lv_cdam5,
                    lv_cdam6,
                    lv_cdam7,
                    lv_cdam8,
                    lv_nettot,
                    lv_notdue,
                    lv_sec_dep,
                    lv_due4,
                    lv_cos,
                    lv_cod,
                    lv_paytrmdays,
                    lv_odospr,
                    lv_codospr.

          CONCATENATE lv_string
                      wa_final-division      gc_tab
                      wa_final-sales_office  gc_tab
                      wa_final-tsm_sales_grp gc_tab
                      wa_final-kunnr         gc_tab
                      wa_final-name          gc_tab
                      lv_cdam1               gc_tab
                      lv_cdam2               gc_tab
                      lv_cdam3               gc_tab
                      lv_cdam4               gc_tab
                      lv_cdam5               gc_tab
                      lv_cdam6               gc_tab
                      lv_cdam7               gc_tab
                      lv_cdam8               gc_tab
                      lv_nettot              gc_tab
                      lv_notdue              gc_tab
                      lv_sec_dep             gc_tab
                      lv_due4                gc_tab
                      lv_cos                 gc_tab
                      lv_cod                 gc_tab
                      wa_final-zterm         gc_tab
                      wa_final-text1         gc_tab
                      lv_paytrmdays          gc_tab
                      wa_final-legalcase     gc_tab
                      lv_odospr              gc_tab
                      lv_codospr             gc_crlf
                      INTO lv_string.
        ENDLOOP.

        LOOP AT it_sale_head INTO wa_sale_head." WHERE group = wa_mail_div-groupping.
          wa_sale_head_t = wa_sale_head.
          wa_sale_head-netot =  wa_sale_head-netot / 100000.
          wa_sale_head-due4 =  wa_sale_head-due4 / 100000.
          wa_sale_head-cos_amt =  wa_sale_head-cos_amt / 100000.
          wa_sale_head-cod_amt =  wa_sale_head-cod_amt / 100000.
          wa_sale_head-legalcase =  wa_sale_head-legalcase / 100000.
          lv_tot_n         = lv_tot_n + wa_sale_head-netot.
          lv_tot_od        = lv_tot_od + wa_sale_head-due4.
          lv_tot_cos       = lv_tot_cos + wa_sale_head-cos_amt.
          lv_tot_cod       = lv_tot_cod + wa_sale_head-cod_amt.
          lv_tot_l         = lv_tot_l + wa_sale_head-legalcase.

          IF lv_tot_n IS NOT INITIAL.
            lv_tot_osdp      = ( lv_tot_od / lv_tot_n ) * 100.
            lv_tot_cosdp     = ( lv_tot_cod / lv_tot_n ) * 100.
          ENDIF.

          IF wa_sale_head-netot IS NOT INITIAL.
            wa_sale_head-od_os_pr = ( wa_sale_head-due4 / wa_sale_head-netot ) * 100.
            wa_sale_head-cod_cos_pr = ( wa_sale_head-cod_amt / wa_sale_head-netot ) * 100.
          ENDIF.
          lv_tot_nc     = lv_tot_n.
          CONDENSE lv_tot_nc.
          lv_tot_odc    = lv_tot_od.
          CONDENSE lv_tot_odc.
          lv_tot_cosc   = lv_tot_cos.
          CONDENSE lv_tot_cosc.
          lv_tot_codc   = lv_tot_cod.
          CONDENSE lv_tot_codc.
          lv_tot_lc     = lv_tot_l.
          CONDENSE lv_tot_lc.
          lv_tot_osdpc  = lv_tot_osdp.
          CONDENSE lv_tot_osdpc.
          lv_tot_cosdpc = lv_tot_cosdp.
          CONDENSE lv_tot_cosdpc.

          wa_manage-netot     = wa_sale_head-netot.
          CONDENSE wa_manage-netot.
          wa_manage-due4      = wa_sale_head-due4.
          CONDENSE wa_manage-due4.
          wa_manage-cos_amt   = wa_sale_head-cos_amt.
          CONDENSE wa_manage-cos_amt.
          wa_manage-cod_amt   = wa_sale_head-cod_amt.
          CONDENSE wa_manage-cod_amt.
          wa_manage-legalcase = wa_sale_head-legalcase.
          CONDENSE wa_manage-legalcase.
          wa_manage-od_os_pr  = wa_sale_head-od_os_pr.
          CONDENSE wa_manage-od_os_pr.
          wa_manage-cod_cos_pr = wa_sale_head-cod_cos_pr.
          CONDENSE wa_manage-cod_cos_pr.

          lv_mailtext = |<tr> <td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-sales_office } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-netot } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-due4 } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-cos_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-cod_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_sale_head-legalcase } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_od_os_pr = abs( wa_sale_head-od_os_pr ).
          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { lv_od_os_pr }% </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext,lv_od_os_pr.

          lv_cod_cos_pr = abs( wa_sale_head-cod_cos_pr ).
          lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { lv_cod_cos_pr }% </td> </tr>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext,lv_cod_cos_pr.
        ENDLOOP.

        lv_mailtext = |<tr style="border:1px solid black;border-collapse: collapse"> <td> <b> Total </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = | <td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_n } </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_od } </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cos } </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cod } </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_l } </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_tot_osdp_n = abs( lv_tot_osdp ).
        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_osdp_n }% </b> </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_tot_cosdp_n = abs( lv_tot_cosdp ).
        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> <b> { lv_tot_cosdp_n }% </b> </td> </tr>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</table>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<h5> Note:- The amount for critical cases is calculated separately, excluding legal cases. </h5>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

*        lv_mailtext = |<b> 1. </b> |.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext.
*
*        lv_mailtext = |</br>|.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext.
*
*        lv_mailtext = |<b> 2. All figures are expressed in lakhs </b>|.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext.

*        lv_mailtext = |<br>|.
*        APPEND lv_mailtext TO main_text.
*        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |Thanks & Regards,|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<b>Team Credit Control - Astral Adhesive Division</b>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |*This is system generated e-mail, do not reply to this e-mail id.* |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</body>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        TRY .
            send_request = cl_bcs=>create_persistent( ).
            sender = cl_cam_address_bcs=>create_internet_address(
              i_address_string = 'SAP.ASTRAL@ASTRALLTD.COM'
*             i_incl_sapuser   = 'X'
            ).

            CALL METHOD send_request->set_sender( sender ).
            document = cl_document_bcs=>create_document(
              i_type    = 'HTM'
              i_subject = 'Comparison: Critical & Total OD vs OS (' && ' ' &&
                          s_date+6(2) && '.' && s_date+4(2) && '.' && s_date+0(4) && ')'
              i_text    = main_text ).

            cl_bcs_convert=>string_to_solix(
              EXPORTING
                iv_string   = lv_string   " Input data
                iv_codepage = '4103'   " Target Code Page in SAP Form  (Default = SAPconnect Setting)
                iv_add_bom  = 'X'   " Add Byte-Order Mark
              IMPORTING
                et_solix    = binary_content  " Output data
                ev_size     = size  " Size of Document Content
            ).


            document->add_attachment(
              EXPORTING
                i_attachment_type    = 'XLS'  " Document Class for Attachment
                i_attachment_subject = 'Critical and total OD vs OS' && s_date+6(2) && '.' && s_date+4(2) && '.' && s_date+0(4)  " Attachment Title
                i_attachment_size    = size   " Size of Document Content
                i_att_content_hex    = binary_content   " Content (Binary)
            ).

            send_request->set_document( document ).

            LOOP AT it_mail_div INTO DATA(wa_mail_div) WHERE groupping = wa_sale_head_t-group.
              lv_mail = wa_mail_div-email_id_to."'SAP.ABAP@ASTRALLTD.COM'. "
              recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
              send_request->add_recipient( recipient ).
            ENDLOOP.

            LOOP AT it_mail_div INTO wa_mail_div WHERE groupping = wa_sale_head_t-group.
              IF wa_mail_div-email_id_cc IS NOT INITIAL.
                lv_mail = wa_mail_div-email_id_cc."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.
            ENDLOOP.
*          ENDIF.
            send_to_all = send_request->send( i_with_error_screen = 'X' ).
            IF send_to_all IS NOT INITIAL.
              COMMIT WORK.
              MESSAGE 'Mail Send Successfully' TYPE 'S'.
            ELSE.
              MESSAGE 'Error While Send Email' TYPE 'S' DISPLAY LIKE 'E'.
              RETURN.
            ENDIF.
          CATCH cx_bcs INTO bcs_exception.

        ENDTRY.
        "MAIL ENDS
        REFRESH: main_text,it_sale_head.
        CLEAR: lv_string, lv_age1,lv_age2,lv_age3,lv_age4,lv_age5,lv_age6,lv_age7,lv_age8,lv_ageslb1,lv_ageslb2,lv_ageslb3,lv_ageslb4,
            lv_ageslb5,lv_ageslb6,lv_ageslb7,lv_attachname,lv_cdam1,lv_cdam2,lv_cdam3,lv_cdam4,lv_cdam5,lv_cdam6,lv_cdam7,lv_cdam8,
            lv_string,lv_cod,lv_codospr,lv_cos,lv_due4,lv_mail,lv_mailtext,lv_nettot,lv_notdue,lv_odospr,lv_paytrmdays,lv_sec_dep,
            lv_slab1,lv_slab2,lv_slab3,lv_slab4,lv_slab5,lv_slab6,lv_slb1,lv_slb2,lv_slb3,lv_slb4,lv_slb5,lv_slb6,lv_slb7,lv_tot_cod,
            lv_tot_cod_amt,lv_tot_cod_cos_pr,lv_tot_codc,lv_tot_cos,lv_tot_cos_amt,lv_tot_cosc,lv_tot_cosdp,lv_tot_cosdpc,lv_tot_due4,
            lv_tot_l,lv_tot_lc,lv_tot_legalcase,lv_tot_n,lv_tot_nc,lv_tot_netot,lv_tot_od,lv_tot_od_os_pr,lv_tot_odc,lv_tot_osdp,
            lv_tot_osdpc.
      ENDLOOP.
    ENDIF.

    IF p_chk2 IS NOT INITIAL.

      IF it_final IS NOT INITIAL.
        SELECT kunnr,adrnr FROM kna1 INTO TABLE @DATA(it_kna1)
        FOR ALL ENTRIES IN @it_final WHERE kunnr = @it_final-kunnr.

        IF it_kna1 IS NOT INITIAL.
          SELECT addrnumber, smtp_addr FROM adr6 INTO TABLE @DATA(it_adr6)
          FOR ALL ENTRIES IN @it_kna1 WHERE addrnumber = @it_kna1-adrnr.
        ENDIF.
      ENDIF.

      LOOP AT it_final INTO wa_final.

        lv_mailtext = |<!DOCTYPE html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<body>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = 'Dear Channel Partner,'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<br>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p font-size: 10>We hope email finds you well !!</p> |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p font-size: 10> We are writing to bring your immediate attention that| && | | &&
                      |your account with us has a critical overdue balance mentioned below.| && | | &&
                      |Despite our precious reminders, we have yet to receive payment for invoice.</p> |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p font-size: 10>This matter is now critical, and <b>we urgently request that the outstanding amount | &&
                      |settled by within 48 hours to avoid any further action.</b>| && | | &&
                      |If you have already made the payment, please disregard this notice,|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |and kindly send us the payment confirmation at your earliest convenience. </p> |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<br>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<table style="width:50%;border:1px solid black;border-collapse: collapse">|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<tr style="border:1px solid black;border-collapse: collapse">|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Customer code </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Name </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_ageslb1 = ageslb1 + 1.
        lv_ageslb2 = ageslb2 + 1.
        lv_ageslb3 = ageslb3 + 1.
        lv_ageslb4 = ageslb4 + 1.
        lv_ageslb5 = ageslb5 + 1.
        lv_ageslb6 = ageslb6 + 1.
        lv_ageslb7 = ageslb7 + 1.

        lv_slab1 = lv_ageslb1.
        lv_slab2 = lv_ageslb2.
        lv_slab3 = lv_ageslb3.
        lv_slab4 = lv_ageslb4.
        lv_slab5 = lv_ageslb5.
        lv_slab6 = lv_ageslb6.

        lv_slb1 = ageslb1.
        lv_slb2 = ageslb2.
        lv_slb3 = ageslb3.
        lv_slb4 = ageslb4.
        lv_slb5 = ageslb5.
        lv_slb6 = ageslb6.
        lv_slb7 = ageslb7.

        CONDENSE: lv_slb1,lv_slab2, lv_slb3, lv_slb4, lv_slb5, lv_slb6, lv_slb7,
                  lv_slab1, lv_slab2, lv_slab3, lv_slab4, lv_slab5, lv_slab6.

        CONCATENATE '0 -' lv_slb1 INTO lv_age1 SEPARATED BY space.
        CONCATENATE lv_slab1 '-' lv_slb2 INTO lv_age2 SEPARATED BY space.
        CONCATENATE lv_slab2 '-' lv_slb3 INTO lv_age3 SEPARATED BY space.
        CONCATENATE lv_slab3 '-' lv_slb4 INTO lv_age4 SEPARATED BY space.
        CONCATENATE lv_slab4 '-' lv_slb5 INTO lv_age5.
        CONCATENATE lv_slab5 '-' lv_slb6 INTO lv_age6.
        CONCATENATE lv_slab6 '-' lv_slb7 INTO lv_age7.
        CONCATENATE '>' lv_slb7 INTO lv_age8.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb1
          IMPORTING
            output = ageslb1.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb2
          IMPORTING
            output = ageslb2.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb3
          IMPORTING
            output = ageslb3.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb4
          IMPORTING
            output = ageslb4.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb5
          IMPORTING
            output = ageslb5.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb6
          IMPORTING
            output = ageslb6.


        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ageslb7
          IMPORTING
            output = ageslb7.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> 0 - { ageslb1 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb1 } - { ageslb2 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb2 } - { ageslb3 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb3 } - { ageslb4 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb4 } - { ageslb5 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb5 } - { ageslb6 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> { lv_ageslb6 } - { ageslb7 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> >{ ageslb7 } </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th style = "border:1px solid black;border-collapse:collapse" ; bgcolor = "#C0C0C0"> Net Outstanding </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</tr>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_cdam1 = wa_final-cdam1.
        lv_cdam2 = wa_final-cdam2.
        lv_cdam3 = wa_final-cdam3.
        lv_cdam4 = wa_final-cdam4.
        lv_cdam5 = wa_final-cdam5.
        lv_cdam6 = wa_final-cdam6.
        lv_cdam7 = wa_final-cdam7.
        lv_cdam8 = wa_final-cdam8.
        lv_nettot = wa_final-netot.
        CONDENSE: lv_cdam1,lv_cdam2,lv_cdam3,lv_cdam4,lv_cdam5,lv_cdam6,lv_cdam7,lv_cdam8,lv_nettot.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = wa_final-kunnr
          IMPORTING
            output = wa_final-kunnr.

        lv_mailtext = |<tr style="border:1px solid black;border-collapse: collapse"> <td>{ wa_final-kunnr }</td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-name } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam1 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam2 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam3 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam4 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam5 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam6 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam7 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-cdam8 } </td>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<td style="border:1px solid black;border-collapse: collapse"> { wa_final-netot } </td> </tr>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</table>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<h5> Should you need any assistance or have any queries regarding this matter, please do not hesitate to contact us directly on below email IDs. </h5>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*        SELECT * FROM tvarvc INTO TABLE @DATA(it_email) WHERE name = 'ZFI_EMAIL'.
        SELECT * FROM tvarvc INTO TABLE @DATA(it_email) WHERE name = 'ZFI_EMAIL' ORDER BY PRIMARY KEY.
        " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
        LOOP AT it_email INTO DATA(wa_mail).
          IF sy-tabix NE 1.
            CONCATENATE lv_email wa_mail-low INTO lv_email SEPARATED BY ' & '.
          ELSE.
            lv_email = wa_mail-low.
          ENDIF.
        ENDLOOP.

        lv_mailtext = | { lv_email } |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p> We highly value you partnership and are eager to resolve this matter promptly. </p>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<p> Thank you for your immediate attention to this matter. </p>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |Thanks & Regards,|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<b>Team Credit Control - Astral Adhesive Division</b>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<br>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |*This is system generated e-mail, do not reply to this e-mail id.* |.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</body>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        TRY .
            send_request = cl_bcs=>create_persistent( ).
            sender = cl_cam_address_bcs=>create_internet_address(
              i_address_string = 'SAP.ASTRAL@ASTRALLTD.COM'
            ).

            CALL METHOD send_request->set_sender( sender ).
            document = cl_document_bcs=>create_document(
              i_type    = 'HTM'
              i_subject = |Urgent Attention: Overdue Invoice Payment Require|
              i_text    = main_text ).

            send_request->set_document( document ).

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = wa_final-kunnr
              IMPORTING
                output = wa_final-kunnr.

            READ TABLE it_kna1 INTO DATA(wa_kna1) WITH KEY kunnr = wa_final-kunnr.
            IF sy-subrc = 0.
              READ TABLE it_adr6 INTO DATA(wa_adr6) WITH KEY addrnumber = wa_kna1-adrnr.
              IF sy-subrc = 0.
                lv_mail = wa_adr6-smtp_addr."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( recipient ).
              ENDIF.
            ENDIF.

            " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*            SELECT SINGLE vkbur,vkgrp FROM knvv INTO @DATA(wa_knvv) WHERE kunnr = @wa_final-kunnr
*                                                                      AND vkorg IN @vkorg.
            SELECT vkbur , vkgrp FROM knvv   UP TO 1 ROWS INTO @DATA(wa_knvv)
           WHERE kunnr = @wa_final-kunnr AND vkorg IN @vkorg  ORDER BY PRIMARY KEY.
            ENDSELECT.
            " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

            SELECT SINGLE * FROM zsd_email1 INTO @DATA(wa_email) WHERE vkbur = @wa_knvv-vkbur
                                                                  AND vkgrp = @wa_knvv-vkgrp.
            IF sy-subrc = 0.
              SPLIT wa_email-smtp_addr AT space INTO lv_mail1
                                                      lv_mail2
                                                      lv_mail3
                                                      lv_mail4
                                                      lv_mail5.
              IF lv_mail1 IS NOT INITIAL.
                lv_mail = lv_mail1."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.

              IF lv_mail2 IS NOT INITIAL.
                lv_mail = lv_mail2."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.

              IF lv_mail3 IS NOT INITIAL.
                lv_mail = lv_mail3."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.

              IF lv_mail4 IS NOT INITIAL.
                lv_mail = lv_mail4."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.

              IF lv_mail5 IS NOT INITIAL.
                lv_mail = lv_mail5."'SAP.ABAP@ASTRALLTD.COM'. "
                recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
                send_request->add_recipient( EXPORTING i_recipient = recipient
                                                       i_copy      = abap_true ).
              ENDIF.
            ENDIF.

            send_to_all = send_request->send( i_with_error_screen = 'X' ).
            IF send_to_all IS NOT INITIAL.
              COMMIT WORK.
              MESSAGE 'Mail Send Successfully' TYPE 'S'.
            ELSE.
              MESSAGE 'Error While Send Email' TYPE 'S' DISPLAY LIKE 'E'.
              RETURN.
            ENDIF.
          CATCH cx_bcs INTO bcs_exception.

        ENDTRY.
        "MAIL ENDS
        CLEAR: lv_string, lv_age1,lv_age2,lv_age3,lv_age4,lv_age5,lv_age6,lv_age7,lv_age8,lv_ageslb1,lv_ageslb2,lv_ageslb3,lv_ageslb4,
            lv_ageslb5,lv_ageslb6,lv_ageslb7,lv_attachname,lv_cdam1,lv_cdam2,lv_cdam3,lv_cdam4,lv_cdam5,lv_cdam6,lv_cdam7,lv_cdam8,
            lv_string,lv_cod,lv_codospr,lv_cos,lv_due4,lv_mail,lv_mailtext,lv_nettot,lv_notdue,lv_odospr,lv_paytrmdays,lv_sec_dep,
            lv_slab1,lv_slab2,lv_slab3,lv_slab4,lv_slab5,lv_slab6,lv_slb1,lv_slb2,lv_slb3,lv_slb4,lv_slb5,lv_slb6,lv_slb7,lv_tot_cod,
            lv_tot_cod_amt,lv_tot_cod_cos_pr,lv_tot_codc,lv_tot_cos,lv_tot_cos_amt,lv_tot_cosc,lv_tot_cosdp,lv_tot_cosdpc,lv_tot_due4,
            lv_tot_l,lv_tot_lc,lv_tot_legalcase,lv_tot_n,lv_tot_nc,lv_tot_netot,lv_tot_od,lv_tot_od_os_pr,lv_tot_odc,lv_tot_osdp,
            lv_tot_osdpc.
        REFRESH: main_text.
      ENDLOOP.
    ENDIF.
  ENDIF.

ENDFORM.

FORM sql.
  DATA : dbs TYPE dbcon-con_name.
  DATA : wa_flag(1).
  CLEAR: wa_flag,dbs.

  dbs = 'MSSQL2'.
  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
  EXEC SQL.
    CONNECT TO :DBS
  ENDEXEC.                                              "#EC CI_EXECSQL
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

  IF wa_flag = 0.
    " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
    EXEC SQL.

      DELETE FROM FI_CRITICAL_OD

    ENDEXEC.                                            "#EC CI_EXECSQL
    " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    wa_flag = 1.
  ENDIF.

  LOOP AT it_final INTO wa_final.
    " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
    EXEC SQL.
      Insert into FI_CRITICAL_OD ( Party_code, Critical_outstanding )
      values ( :wa_final-kunnr, :wa_final-cos_amt )
    ENDEXEC.                                            "#EC CI_EXECSQL
    " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    CLEAR:wa_final.

  ENDLOOP.

  MESSAGE 'Data successfully sent to external database FI_CRITICAL_OD.' TYPE 'S'.

ENDFORM.
