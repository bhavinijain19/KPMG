*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_OD_KDGRP....................................*
DATA:  BEGIN OF STATUS_ZFI_OD_KDGRP                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_OD_KDGRP                  .
CONTROLS: TCTRL_ZFI_OD_KDGRP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_OD_KDGRP                  .
TABLES: ZFI_OD_KDGRP                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
