FUNCTION-POOL ZFI_PIPES_BANK             MESSAGE-ID SV.

* INCLUDE LZFI_PIPES_BANKD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PIPES_BANKT00                      . "view rel. data dcl.
