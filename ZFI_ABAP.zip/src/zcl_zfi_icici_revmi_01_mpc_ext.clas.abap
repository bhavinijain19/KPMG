CLASS zcl_zfi_icici_revmi_01_mpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_zfi_icici_revmi_01_mpc
  CREATE PUBLIC .

  PUBLIC SECTION.


    TYPES:
      BEGIN OF ty_deep_entity,
        filename TYPE zicici_reverse-file_name,
        status   TYPE zicici_reverse-zstatus,
        message  TYPE zicici_reverse-zmessage,
        toitems  TYPE STANDARD TABLE OF ts_revitem WITH DEFAULT KEY,
      END OF ty_deep_entity .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_ICICI_REVMI_01_MPC_EXT IMPLEMENTATION.
ENDCLASS.
