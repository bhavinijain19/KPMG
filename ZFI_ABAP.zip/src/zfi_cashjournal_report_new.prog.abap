*&---------------------------------------------------------------------*
*& Report  ZFI_CASHJOURNAL_REPORT_NEW
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zfi_cashjournal_report_new.
TABLES : tcj_c_journals .
TYPE-POOLS : slis.

DATA: it_tcj_j TYPE STANDARD TABLE OF tcj_c_journals,
      wa_tcj_j TYPE tcj_c_journals.
DATA: it_cj_names TYPE STANDARD TABLE OF tcj_cj_names,
      wa_cj_names TYPE tcj_cj_names.

DATA: it_limit TYPE STANDARD TABLE OF zfi_cash_limit,
      wa_limit TYPE zfi_cash_limit.

DATA: it_skat TYPE STANDARD TABLE OF skat,
      wa_skat TYPE skat.

DATA:  ld_beg_balance  TYPE cjamount,
       ld_run_balance2 TYPE cjamount,
       e_payments      TYPE cjamount,
       e_receipts      TYPE cjamount.

TYPES: BEGIN OF ty_final,
         bukrs       TYPE tcj_c_journals-comp_code,
         cajo_number TYPE tcj_c_journals-cajo_number,
         cajo_name   TYPE tcj_cj_names-cajo_name,
         gl_account(10),  "TYPE tcj_c_journals-gl_account,
         currency    TYPE tcj_c_journals-currency,
         gldesc      TYPE skat-txt50,
         opbalance   TYPE cjamount,
         receipts    TYPE cjamount,
         payments    TYPE cjamount,
         clbalance   TYPE cjamount,
         climit      TYPE cjamount,
         slimit      TYPE cjamount,
         color(04),
       END OF ty_final.
DATA: it_final TYPE STANDARD TABLE OF ty_final,
      wa_final TYPE ty_final.

**************** Deatils
TYPES : BEGIN OF ty_data,
          comp_code           TYPE tcj_documents-comp_code,
          cajo_number         TYPE tcj_documents-cajo_number,
          posting_number      TYPE tcj_documents-posting_number,
          posting_date        TYPE tcj_documents-posting_date,
          document_date       TYPE tcj_documents-document_date,
          document_status(60),
          d_posting_numb      TYPE tcj_documents-d_posting_numb,
          h_net_amount        TYPE tcj_documents-h_net_amount,
          bukrs               TYPE bkpf-bukrs,
          belnr               TYPE bkpf-belnr,
          awkey               TYPE bkpf-awkey,
          cajo_name           TYPE tcj_cj_names-cajo_name,
          gl_account          TYPE tcj_positions-gl_account,
          txt50               TYPE skat-txt50,
          transact_name       TYPE tcj_trans_names-transact_name,
          position_text       TYPE tcj_positions-position_text,
          vendor_no           TYPE tcj_positions-vendor_no,
          customer            TYPE tcj_positions-customer,
          accountant          TYPE tcj_documents-accountant,
          bupla               TYPE tcj_documents-bupla,
          prctr               TYPE tcj_positions-prctr,
          kostl               TYPE tcj_positions-kostl,
          aufnr               TYPE tcj_positions-aufnr,
          transact_number     TYPE tcj_positions-transact_number,
          h_receipts          TYPE tcj_documents-h_receipts,
          h_payments          TYPE tcj_documents-h_payments,
          opbalance           TYPE cjamount,
          clbalance           TYPE cjamount,
          currency            TYPE tcj_documents-currency,
          climit              TYPE cjamount,
          slimit              TYPE cjamount,
          color(4),
          text(20),
*          posting_number      TYPE tcj_positions-posting_number,
        END OF ty_data.
*********
DATA: v_opning TYPE cjamount.
DATA: ind(01).

DATA: gi_final   TYPE STANDARD TABLE OF ty_data,
      wa_final_d TYPE ty_data.

DATA : flag TYPE i VALUE 1.

TYPES : BEGIN OF ty_tcjdoc,
          comp_code           TYPE tcj_documents-comp_code,
          cajo_number         TYPE tcj_documents-cajo_number,
          posting_date        TYPE tcj_documents-posting_date,
          posting_number      TYPE tcj_documents-posting_number,

          document_status(10),
          d_posting_numb      TYPE tcj_documents-d_posting_numb,
          h_net_amount        TYPE tcj_documents-h_net_amount,
          accountant          TYPE tcj_documents-accountant,
          document_date       TYPE tcj_documents-document_date,
          h_receipts          TYPE tcj_documents-h_receipts,
          h_payments          TYPE tcj_documents-h_payments,
          currency            TYPE tcj_documents-currency,
          bupla               TYPE tcj_documents-bupla,
        END OF ty_tcjdoc.

DATA : it_tcjdoc TYPE STANDARD TABLE OF ty_tcjdoc,
       wa_tcjdoc TYPE ty_tcjdoc.

TYPES : BEGIN OF ty_tcjpos,
          comp_code       TYPE tcj_positions-comp_code,
          cajo_number     TYPE tcj_positions-cajo_number,
          posting_number  TYPE tcj_positions-posting_number,
          transact_number TYPE tcj_positions-transact_number,
          gl_account      TYPE tcj_positions-gl_account,
          position_text   TYPE tcj_positions-position_text,
          vendor_no       TYPE tcj_positions-vendor_no,
          customer        TYPE tcj_positions-customer,
          prctr           TYPE tcj_positions-prctr,
          kostl           TYPE tcj_positions-kostl,
          aufnr           TYPE tcj_positions-aufnr,
        END OF ty_tcjpos.

DATA: it_tcjpos TYPE STANDARD TABLE OF ty_tcjpos,
      wa_tcjpos TYPE ty_tcjpos.

TYPES : BEGIN OF ty_tcjtrans_nam,
          comp_code       TYPE tcj_trans_names-comp_code,
          transact_number TYPE tcj_trans_names-transact_number,
          transact_name   TYPE tcj_trans_names-transact_name,

        END OF ty_tcjtrans_nam.

DATA:it_tcjtrans_nam TYPE STANDARD TABLE OF ty_tcjtrans_nam,
     wa_tcjtrans_nam TYPE ty_tcjtrans_nam.

TYPES : BEGIN OF ty_dd07v,
          domname    TYPE dd07v-domname,
          domvalue_l TYPE dd07v-domvalue_l,
          ddtext     TYPE dd07v-ddtext,
        END OF ty_dd07v .
DATA: it_dd07v TYPE STANDARD TABLE OF ty_dd07v,
      wa_dd07v TYPE ty_dd07v.

CONSTANTS:
  c_domname(30) TYPE c VALUE 'CJDOCSTAT'.

TYPES : BEGIN OF ty_awkey,
          awkey TYPE bkpf-awkey,
        END OF ty_awkey.

DATA:v_awkey(20) TYPE c.
DATA:wa_awkey TYPE ty_awkey,
     it_awkey TYPE TABLE OF ty_awkey.

TYPES : BEGIN OF ty_cjnames,
          comp_code   TYPE tcj_cj_names-comp_code,
          cajo_number TYPE tcj_cj_names-cajo_number,
          cajo_name   TYPE tcj_cj_names-cajo_name,
        END OF ty_cjnames.

DATA: it_cjnames TYPE STANDARD TABLE OF ty_cjnames,
      wa_cjnames TYPE ty_cjnames.

TYPES : BEGIN OF ty_bkpf,
          bukrs TYPE bkpf-bukrs,
          belnr TYPE bkpf-belnr,
          gjahr TYPE bkpf-gjahr,
          awkey TYPE bkpf-awkey,
        END OF ty_bkpf.
DATA: it_bkpf TYPE STANDARD TABLE OF ty_bkpf,
      wa_bkpf TYPE ty_bkpf.

TYPES: BEGIN OF ty_bseg,
         bukrs TYPE bseg-bukrs,
         belnr TYPE bseg-belnr,
         gjahr TYPE bseg-gjahr,
         hkont TYPE bseg-hkont,
         kostl TYPE bseg-kostl,
         prctr TYPE bseg-prctr,
       END OF ty_bseg.
DATA: it_bseg TYPE STANDARD TABLE OF ty_bseg,
      wa_bseg TYPE ty_bseg.

DATA: lt_dummy_table1 LIKE iscj_postings OCCURS 0 WITH HEADER LINE,
      lt_dummy_table2 LIKE tcj_wtax_items OCCURS 0 WITH HEADER LINE,
      lt_dummy_table3 LIKE iscj_postings OCCURS 0 WITH HEADER LINE,
      lt_dummy_table4 LIKE tcj_cpd       OCCURS 0 WITH HEADER LINE.

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       gd_layout      TYPE slis_layout_alv,
       t_events       TYPE slis_t_event WITH HEADER LINE.

DATA:wa_fcat TYPE slis_fieldcat_alv,
     it_fcat TYPE slis_t_fieldcat_alv.

************************************************************************
* Selection screen definition ******************************************
************************************************************************
SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.
PARAMETERS : s_ccode TYPE tcj_c_journals-comp_code OBLIGATORY.
*             s_cjno  TYPE tcj_documents-cajo_number OBLIGATORY.
SELECT-OPTIONS : s_cjno  FOR tcj_c_journals-cajo_number OBLIGATORY.
PARAMETERS :   s_pdate TYPE sy-datum.
SELECT-OPTIONS : s_date FOR sy-datum.

SELECTION-SCREEN : END OF BLOCK a1 .

SELECTION-SCREEN: BEGIN OF BLOCK a2 WITH FRAME TITLE text-002.
PARAMETER : summary RADIOBUTTON GROUP rad2 USER-COMMAND xyz DEFAULT 'X',
*            deloite RADIOBUTTON GROUP rad2,
            details RADIOBUTTON GROUP rad2.
SELECTION-SCREEN: END OF BLOCK a2.

AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF summary = 'X'.
      IF screen-name = 'S_DATE-LOW' OR screen-name = 'S_DATE-HIGH' OR screen-name = '%_S_DATE_%_APP_%-TEXT' .
        screen-active = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDIF.

    IF details = 'X'.
      IF screen-name = 'S_PDATE' OR screen-name = '%_S_PDATE_%_APP_%-TEXT' .
        screen-active = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDIF.
  ENDLOOP.

START-OF-SELECTION.
  IF summary = 'X'.
    IF s_pdate IS INITIAL.
      MESSAGE 'Please enter date' TYPE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.
    PERFORM get_data_cal.

  ELSE.
    IF s_date IS INITIAL.
      MESSAGE 'Please enter date' TYPE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.
    PERFORM get_data_dtl_cal.
  ENDIF.
  IF summary = 'X'.
    IF it_final IS INITIAL .
      MESSAGE 'No data for inputted values!! Please enter valid data.' TYPE 'S' DISPLAY LIKE 'E'.
    ELSE.
      PERFORM fill_fieldcatalog.
      PERFORM display_grid.
    ENDIF.
  ELSE.
    IF gi_final IS INITIAL .
      MESSAGE 'No data for inputted values!! Please enter valid data.' TYPE 'S' DISPLAY LIKE 'E'.
    ELSE.
      PERFORM fill_fieldcatalog.
      PERFORM display_grid.
    ENDIF.


  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA_CAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data_cal .
  SELECT * FROM tcj_c_journals
    INTO TABLE it_tcj_j
    WHERE comp_code = s_ccode
    AND   cajo_number IN s_cjno.

  PERFORM authorization.

  IF it_tcj_j IS NOT INITIAL.

    SELECT * FROM tcj_cj_names
      INTO TABLE it_cj_names
       FOR ALL ENTRIES IN it_tcj_j
        WHERE langu = 'E' AND
       comp_code = s_ccode AND
       cajo_number = it_tcj_j-cajo_number.

    SELECT * FROM skat
      INTO TABLE it_skat
      FOR ALL ENTRIES IN it_tcj_j
      WHERE spras = 'E'
      AND   ktopl = 'ASTL'
      AND   saknr = it_tcj_j-gl_account.

    SELECT * FROM zfi_cash_limit
      INTO TABLE it_limit
      FOR ALL ENTRIES IN it_tcj_j
      WHERE bukrs = s_ccode
      AND cajo_number = it_tcj_j-cajo_number
      AND endda GE s_pdate
      AND begda LE s_pdate.





    LOOP AT it_tcj_j INTO wa_tcj_j.

      CALL FUNCTION 'FCJ_GET_DATA_FOR_SCREEN'
        EXPORTING
          i_comp_code         = wa_tcj_j-comp_code
          i_cajo_number       = wa_tcj_j-cajo_number
          i_display_period_lo = s_pdate
          i_display_period_hi = s_pdate
        IMPORTING
          e_beginning_balance = ld_beg_balance
          e_running_balance   = ld_run_balance2
          e_total_receipts    = e_receipts
*         E_TOTAL_REC_NUMBER  =
          e_total_payments    = e_payments
*         E_TOTAL_PAYM_NUMBER =
*         E_TOTAL_CHECKS      =
*         E_TOTAL_CHECKS_NUMBER       =
*         E_COMP_NAME         =
*         E_CAJO_NAME         =
*         E_CURRENCY1         =
*         E_CURRENCY2         =
*         E_CURRENCY3         =
*         E_CURRENCY4         =
*         E_CURRENCY5         =
        TABLES
          e_postings          = lt_dummy_table1
          e_wtax_items        = lt_dummy_table2
          e_split_postings    = lt_dummy_table3
          e_cpd               = lt_dummy_table4.

      wa_final-bukrs = wa_tcj_j-comp_code.
      wa_final-cajo_number = wa_tcj_j-cajo_number.
      wa_final-gl_account  = wa_tcj_j-gl_account.
      wa_final-currency  = wa_tcj_j-currency.
      wa_final-opbalance  = ld_beg_balance.
      wa_final-receipts   = e_receipts.
      wa_final-payments   = e_payments.
      wa_final-clbalance  = ld_run_balance2.

      READ TABLE it_cj_names INTO wa_cj_names WITH KEY cajo_number = wa_final-cajo_number.
      IF sy-subrc = 0.
        wa_final-cajo_name = wa_cj_names-cajo_name.
      ENDIF.

      READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_tcj_j-gl_account.
      IF sy-subrc = 0.
        wa_final-gldesc = wa_skat-txt50.
      ENDIF.

      READ TABLE it_limit INTO wa_limit WITH KEY bukrs = s_ccode cajo_number = wa_final-cajo_number.
      IF sy-subrc = 0.
        wa_final-climit = wa_limit-climit.
      ENDIF.

      wa_final-slimit = wa_final-climit - wa_final-clbalance.

       IF wa_final-currency = 'INR' AND wa_final-slimit < '0.00'.
        wa_final-color = 'C310'.
       ENDIF.
      APPEND wa_final TO it_final.
      CLEAR: wa_final,ld_beg_balance,e_receipts,e_payments,ld_run_balance2,wa_cj_names .



    ENDLOOP.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  IF summary = 'X'.
*  CLEAR wa_fcat.
*  wa_fcat-fieldname = 'BUKRS'.
**  wa_fcat-key       = 'X'.
*  wa_fcat-seltext_m = 'Co Code'.
*  wa_fcat-seltext_l = 'Co Code'.
**  wa_fcat-tabname = 'IT_FINAL'.
*  wa_fcat-outputlen = 5.
**  wa_fcat-col_pos = 1.
*  APPEND wa_fcat TO it_fcat.
*
*  CLEAR wa_fcat.
*  wa_fcat-fieldname = 'BUKRS'.
**  wa_fcat-key       = 'X'.
*  wa_fcat-seltext_m = 'Co Code'.
*  wa_fcat-seltext_l = 'Co Code'.
**  wa_fcat-tabname = 'IT_FINAL'.
*  wa_fcat-outputlen = 5.
**  wa_fcat-col_pos = 1.
*  APPEND wa_fcat TO it_fcat.
*
*  CLEAR wa_fcat.
*  wa_fcat-fieldname  = 'CAJO_NUMBER'.
**  wa_fcat-key       = 'X'.
*  wa_fcat-seltext_m = 'Cash Journal No'.
*  wa_fcat-seltext_l = 'Cash Journal No'.
**  wa_fcat-tabname = 'IT_FINAL'.
*  wa_fcat-outputlen = 5.
**  wa_fcat-col_pos = 1.
*  APPEND wa_fcat TO it_fcat.
*
*
*
*   CLEAR wa_fcat.
*  wa_fcat-fieldname  = 'CAJO_NAME'.
**  wa_fcat-key       = 'X'.
*  wa_fcat-seltext_m = 'Cash Journal Name'.
*  wa_fcat-seltext_l = 'Cash Journal Name'.
**  wa_fcat-tabname = 'IT_FINAL'.
*  wa_fcat-outputlen = 5.
**  wa_fcat-col_pos = 1.
*  APPEND wa_fcat TO it_fcat.
*
*  CLEAR wa_fcat.
*  wa_fcat-fieldname  = 'GL_ACCOUNT'.
**  wa_fcat-key       = 'X'.
*  wa_fcat-seltext_m = 'Gl Code'.
*  wa_fcat-seltext_l = 'Gl Code'.
**  wa_fcat-tabname = 'IT_FINAL'.
*  wa_fcat-outputlen = 30.
**  wa_fcat-col_pos = 1.
*  APPEND wa_fcat TO it_fcat.


*
    PERFORM fieldcat_append  USING  'BUKRS'               'Co Code'                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CAJO_NUMBER'         'Cash Journal No'                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CAJO_NAME'         'Cash Journal Name'                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'Gl Code      '                'X'  'IT_FINAL' ' ' '50'  .
*  PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'GL CODE '                'X'  'IT_FINAL' ' '  .
    PERFORM fieldcat_append  USING  'GLDESC'          'Gl Description '                'X'  'IT_FINAL' ' ' '10' .
*  PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'GL DISCRIPTION '                'X'  'IT_FINAL' ' '  .
    PERFORM fieldcat_append  USING  'CURRENCY'            'Currency'                'X'  'IT_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'OPBALANCE'            'Opening Balance'                'X'  'IT_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'RECEIPTS'               'Receipt'                'X'  'IT_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'PAYMENTS'               'Payments'                'X'  'IT_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'CLBALANCE'               'Closing Balance'                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CLIMIT'               'Cash Limit'                'X'  'IT_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'SLIMIT'               'Short/Excess'                'X'  'IT_FINAL' ' ' '10' .

**************
*     PERFORM fieldcat_append  USING  'BUKRS'               'Co Code'                'X'   ' ' '10'  .
*    PERFORM fieldcat_append  USING  'CAJO_NUMBER'         'Cash Journal No'                'X'  ' ' '10'  .
*    PERFORM fieldcat_append  USING  'CAJO_NAME'         'Cash Journal Name'                'X'  ' ' '10'  .
*    PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'Gl Code      '                'X'  ' ' '50'  .
**  PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'GL CODE '                'X'  'IT_FINAL' ' '  .
*    PERFORM fieldcat_append  USING  'GLDESC'          'Gl Description '                'X'  ' ' '10' .
**  PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'GL DISCRIPTION '                'X'  'IT_FINAL' ' '  .
*    PERFORM fieldcat_append  USING  'CURRENCY'            'Currency'                'X'  ' ' '10' .
*    PERFORM fieldcat_append  USING  'OPBALANCE'            'Opening Balance'                'X'  ' ' '10' .
*    PERFORM fieldcat_append  USING  'RECEIPTS'               'Receipt'                'X'  ' ' '10' .
*    PERFORM fieldcat_append  USING  'PAYMENTS'               'Payments'                'X' ' ' '10' .
*    PERFORM fieldcat_append  USING  'CLBALANCE'               'Closing Balance'                'X'  ' ' '10'  .
*    PERFORM fieldcat_append  USING  'CLIMIT'               'Cash Limit'                'X' ' ' '10' .
*    PERFORM fieldcat_append  USING  'SLIMIT'               'Short/Excess'                'X' ' ' '10' .
*************
  ELSE.
    PERFORM fieldcat_append  USING  'BUKRS'               'Co Code'                'X'  'GI_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'CAJO_NUMBER'               'Cash Journal'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CAJO_NAME'               'Cash Journal Name'                'X'  'GI_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'GL_ACCOUNT'          'GL Code'                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'TXT50'          'GL Description '                'X'  'IT_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'D_POSTING_NUMB'               'Document Number'                'X'  'GI_FINAL' 'C100' '10'  .
    PERFORM fieldcat_append  USING  'BELNR'               'FI Doc.Number'                'X'  'GI_FINAL' 'C100' '10' .
    PERFORM fieldcat_append  USING  'POSTING_DATE'               'Posting Date'                'X'  'GI_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'DOCUMENT_DATE'               'Document Date'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'POSTING_NUMBER'               'Internal Doc. Number'                'X'  'GI_FINAL' ' ' '10'  .

    PERFORM fieldcat_append  USING  'TRANSACT_NAME'               'Business Transaction'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CURRENCY'               'Currency'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'OPBALANCE'               'Opening Balance'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'H_RECEIPTS'               'Receipt '                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'H_PAYMENTS'               'Payment'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CLBALANCE'               'Closing Balance'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'CLIMIT'               'Cash Limit'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'SLIMIT'               'Short/Excess'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'PRCTR'               'Profit Centre'                'X'  'GI_FINAL' ' '  '10' .
    PERFORM fieldcat_append  USING  'KOSTL'               'Cost Centre'                'X'  'GI_FINAL' ' ' '10' .
    PERFORM fieldcat_append  USING  'AUFNR'               'Internal Order'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'BUPLA'               'Bus.Place'                'X'  'GI_FINAL' ' ' '10' .







    PERFORM fieldcat_append  USING  'DOCUMENT_STATUS'               'Status Indicator'                'X'  'GI_FINAL' ' ' '10'  .
    PERFORM fieldcat_append  USING  'POSITION_TEXT'               'Text'                'X'  'GI_FINAL' ' ' '10' .

    PERFORM fieldcat_append  USING  'ACCOUNTANT'               'User ID'                'X'  'GI_FINAL' ' ' '10'  .
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0099   text
*      -->P_0100   text
*      -->P_0101   text
*      -->P_0102   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table)
                               VALUE(p_emph)
                               VALUE(p_outpt).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  t_fieldcatalog-emphasize   = p_emph.
  t_fieldcatalog-outputlen   = p_outpt.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .

  gd_layout-zebra = 'X'.
  gd_layout-info_fieldname = 'COLOR'.
  gd_layout-colwidth_optimize = 'X'.


  IF summary = 'X'.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = sy-repid
*       is_layout              = wa_layout
        is_layout              = gd_layout
*       i_callback_user_command = 'USER_COMMAND'
        i_callback_top_of_page = 'TOP_PAGE'
        it_fieldcat            = t_fieldcatalog[]
*       it_special_groups      = i_sp_group[]
*       IT_SORT                =
        i_save                 = 'A'
        it_events              = t_events[]
      TABLES
        t_outtab               = it_final
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

  ELSE.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = sy-repid
*       is_layout              = wa_layout
        is_layout              = gd_layout
*       i_callback_user_command = 'USER_COMMAND'
        i_callback_top_of_page = 'TOP_PAGE'
        it_fieldcat            = t_fieldcatalog[]
*       it_special_groups      = i_sp_group[]
*       IT_SORT                =
        i_save                 = 'A'
        it_events              = t_events[]
      TABLES
        t_outtab               = gi_final
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.


ENDFORM.
FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).
  DATA: v_times(10).

  IF details = 'X'.
    wa_header-typ = 'H'.

    wa_header-info = 'Cash Balance Details Report'.
*  ENDIF.
    APPEND wa_header TO it_header.
    CLEAR wa_header.


    wa_header-typ = 'S'.
    IF NOT s_date-high IS INITIAL.
      CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
      CONCATENATE s_date-high+6(2) '-' s_date-high+4(2) '-' s_date-high+0(4) INTO v_highdate.
      CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
    ELSE.
      CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
      LOOP AT s_date.
        IF NOT wa_header-info IS INITIAL.
          IF NOT s_date-low IS INITIAL.
            CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
          ENDIF.
        ELSE.
          CONCATENATE sy-uzeit+0(2)':' sy-uzeit+2(2)':' sy-uzeit+4(2) INTO v_times.
          CONCATENATE 'Date & time :- ' v_lowdate  v_times INTO wa_header-info SEPARATED BY space.
        ENDIF.
      ENDLOOP.
    ENDIF.
    APPEND wa_header TO it_header.
    CLEAR wa_header.
    CLEAR : v_lowdate,v_highdate.
  ELSE.

    wa_header-typ = 'H'.

    wa_header-info = 'Cash Balance Summary Report'.
*  ENDIF.
    APPEND wa_header TO it_header.
    CLEAR wa_header.


    wa_header-typ = 'S'.
*  IF NOT s_pdate-high IS INITIAL.
*    CONCATENATE s_pdate-low+6(2) '-' s_pdate-low+4(2) '-' s_pdate-low+0(4) INTO v_lowdate.
*    CONCATENATE s_pdate-high+6(2) '-' s_pdate-high+4(2) '-' s_pdate--high+0(4) INTO v_highdate.
*    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
*  ELSE.
    CONCATENATE s_pdate+6(2) '-' s_pdate+4(2) '-' s_pdate+0(4) INTO v_lowdate.
*    LOOP AT s_pdate .
    IF NOT wa_header-info IS INITIAL.
      IF NOT s_pdate IS INITIAL.
        CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
      ENDIF.
    ELSE.
      CONCATENATE sy-uzeit+0(2)':' sy-uzeit+2(2)':' sy-uzeit+4(2) INTO v_times.
      CONCATENATE 'Cash on hand as on :- ' v_lowdate  v_times INTO wa_header-info SEPARATED BY space.
    ENDIF.
*    ENDLOOP.
*  ENDIF.
    APPEND wa_header TO it_header.
    CLEAR wa_header.
    CLEAR : v_lowdate,v_highdate.

  ENDIF.



  wa_header-typ = 'S'.
  SELECT SINGLE butxt
                INTO wa_header-info
                FROM t001
                WHERE bukrs = s_ccode.

  APPEND wa_header TO it_header.
  CLEAR wa_header.




  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_header.
*      I_LOGO             = 'ASTRALS'.


ENDFORM.         " DISPLAY
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization .
  LOOP AT it_tcj_j INTO wa_tcj_j.

    AUTHORITY-CHECK OBJECT 'Z_FBCJ'
    ID 'ZCJNO' FIELD wa_tcj_j-cajo_number
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e023(zfi) WITH wa_tcj_j-cajo_number.
    ENDIF.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA_DTL_CAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data_dtl_cal .
  SELECT comp_code cajo_number posting_date posting_number h_net_amount  document_status d_posting_numb accountant document_date bupla
        h_receipts h_payments currency
   FROM tcj_documents
   INTO CORRESPONDING FIELDS OF TABLE it_tcjdoc
   WHERE comp_code         = s_ccode AND
         cajo_number      IN s_cjno  AND
         posting_date     IN  s_date .

  IF  it_tcjdoc[] IS NOT INITIAL.
    SELECT comp_code cajo_number posting_number transact_number gl_account position_text vendor_no customer prctr kostl aufnr
      FROM tcj_positions
      INTO CORRESPONDING FIELDS OF TABLE it_tcjpos
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE comp_code       = it_tcjdoc-comp_code AND
            cajo_number     = it_tcjdoc-cajo_number AND
            posting_number  = it_tcjdoc-posting_number .
  ENDIF.

  IF it_tcjpos IS NOT INITIAL.
    SELECT *
      FROM skat
      INTO CORRESPONDING FIELDS OF TABLE it_skat
      FOR ALL ENTRIES IN it_tcjpos
      WHERE saknr = it_tcjpos-gl_account AND
            spras = sy-langu .

    SELECT comp_code transact_number transact_name
        FROM tcj_trans_names
        INTO CORRESPONDING FIELDS OF TABLE it_tcjtrans_nam
        FOR ALL ENTRIES IN it_tcjpos
        WHERE comp_code = it_tcjpos-comp_code AND
              transact_number = it_tcjpos-transact_number AND
              langu = sy-langu .
  ENDIF.

  IF it_tcjdoc IS NOT INITIAL.
    SELECT domname domvalue_l ddtext
     FROM dd07v
      INTO CORRESPONDING FIELDS OF TABLE it_dd07v
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE domname = c_domname AND
            ddlanguage = sy-langu AND
            domvalue_l = it_tcjdoc-document_status .

    LOOP AT it_tcjdoc INTO wa_tcjdoc.
      CONCATENATE wa_tcjdoc-posting_number wa_tcjdoc-cajo_number wa_tcjdoc-comp_code INTO wa_awkey-awkey.
      APPEND wa_awkey TO it_awkey.
      CLEAR:wa_awkey,wa_tcjdoc.
    ENDLOOP.

    SELECT comp_code cajo_number cajo_name
      FROM tcj_cj_names
      INTO CORRESPONDING FIELDS OF TABLE it_cjnames
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE comp_code    = it_tcjdoc-comp_code AND
            cajo_number  = it_tcjdoc-cajo_number AND
            langu  = sy-langu.
  ENDIF.

  IF it_awkey IS NOT INITIAL.
    SELECT bukrs belnr gjahr awkey
      FROM bkpf
      INTO CORRESPONDING FIELDS OF TABLE it_bkpf
      FOR ALL ENTRIES IN it_awkey
      WHERE bukrs = s_ccode AND
           awtyp = 'CAJO'   AND
           awkey = it_awkey-awkey.

    IF it_bkpf IS NOT INITIAL.
      SELECT bukrs belnr gjahr hkont kostl prctr
        FROM bseg
        INTO CORRESPONDING FIELDS OF TABLE it_bseg
        FOR ALL ENTRIES IN it_bkpf
        WHERE bukrs = it_bkpf-bukrs
        AND   belnr = it_bkpf-belnr
        AND   gjahr = it_bkpf-gjahr.
    ENDIF.
  ENDIF.

************************************* READ TABLES *****************************************
  SORT it_tcjdoc BY comp_code cajo_number posting_date.

  LOOP AT it_tcjdoc INTO wa_tcjdoc.
    wa_final_d-d_posting_numb  = wa_tcjdoc-d_posting_numb.
    wa_final_d-cajo_number     = wa_tcjdoc-cajo_number.
    wa_final_d-posting_date    = wa_tcjdoc-posting_date.
    wa_final_d-document_date    = wa_tcjdoc-document_date.
    wa_final_d-h_net_amount    = wa_tcjdoc-h_net_amount.
    wa_final_d-accountant      = wa_tcjdoc-accountant.
    wa_final_d-bukrs           = wa_tcjdoc-comp_code.
    wa_final_d-h_payments           = wa_tcjdoc-h_payments.
    wa_final_d-h_receipts           = wa_tcjdoc-h_receipts.
    wa_final_d-currency           = wa_tcjdoc-currency.
    wa_final_d-bupla          = wa_tcjdoc-bupla.

    READ TABLE it_tcjpos INTO wa_tcjpos WITH KEY cajo_number = wa_tcjdoc-cajo_number
                                                 posting_number = wa_tcjdoc-posting_number .
    wa_final_d-gl_account = wa_tcjpos-gl_account.
    wa_final_d-position_text  = wa_tcjpos-position_text .
    wa_final_d-vendor_no    = wa_tcjpos-vendor_no.
    wa_final_d-customer     = wa_tcjpos-customer.
    wa_final_d-prctr        = wa_tcjpos-prctr.
    wa_final_d-kostl        = wa_tcjpos-kostl.
    wa_final_d-aufnr        = wa_tcjpos-aufnr.
    wa_final_d-posting_number = wa_tcjpos-posting_number.
    READ TABLE it_tcjtrans_nam INTO wa_tcjtrans_nam WITH KEY transact_number = wa_tcjpos-transact_number.
    wa_final_d-transact_name = wa_tcjtrans_nam-transact_name .

    READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_tcjpos-gl_account.
    wa_final_d-txt50  = wa_skat-txt50.

    READ TABLE it_dd07v INTO wa_dd07v WITH KEY domvalue_l = wa_tcjdoc-document_status.
    wa_final_d-document_status = wa_dd07v-ddtext .

*    IF wa_tcjdoc-document_status EQ 'P'.
*      wa_final-document_status = 'Posted'.
*    ELSEIF wa_tcjdoc-document_status EQ 'S'.
*      wa_final-document_status = 'Saved'.
*    ENDIF.

    READ TABLE it_cjnames INTO wa_cjnames WITH KEY comp_code   = wa_tcjdoc-comp_code
                                                   cajo_number  = wa_tcjdoc-cajo_number .
    wa_final_d-cajo_name = wa_cjnames-cajo_name.

    CONCATENATE wa_tcjdoc-posting_number wa_tcjdoc-cajo_number wa_tcjdoc-comp_code INTO v_awkey.
    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_tcjdoc-comp_code
                                             awkey = v_awkey .
    IF sy-subrc EQ 0.
      wa_final_d-belnr = wa_bkpf-belnr .
    ENDIF.
    READ TABLE it_bseg INTO wa_bseg WITH KEY bukrs = wa_bkpf-bukrs belnr = wa_bkpf-belnr gjahr = wa_bkpf-gjahr hkont = wa_tcjpos-gl_account.
    IF sy-subrc = 0.
      wa_final_d-prctr        =  wa_bseg-prctr.
      wa_final_d-kostl        =  wa_bseg-kostl.
    ENDIF.
*************************    FOR OPENING/CLOSING
    AT NEW posting_date.
*     Clear: v_opning.
      CALL FUNCTION 'FCJ_GET_DATA_FOR_SCREEN'
        EXPORTING
          i_comp_code         = wa_final_d-bukrs
          i_cajo_number       = wa_final_d-cajo_number
          i_display_period_lo = wa_final_d-posting_date
          i_display_period_hi = wa_final_d-posting_date
        IMPORTING
          e_beginning_balance = ld_beg_balance
          e_running_balance   = ld_run_balance2
*         e_total_receipts    = e_receipts
*         E_TOTAL_REC_NUMBER  =
*         e_total_payments    = e_payments
*         E_TOTAL_PAYM_NUMBER =
*         E_TOTAL_CHECKS      =
*         E_TOTAL_CHECKS_NUMBER       =
*         E_COMP_NAME         =
*         E_CAJO_NAME         =
*         E_CURRENCY1         =
*         E_CURRENCY2         =
*         E_CURRENCY3         =
*         E_CURRENCY4         =
*         E_CURRENCY5         =
        TABLES
          e_postings          = lt_dummy_table1
          e_wtax_items        = lt_dummy_table2
          e_split_postings    = lt_dummy_table3
          e_cpd               = lt_dummy_table4.
*************
      wa_final_d-opbalance = ld_beg_balance.
*      wa_final_d-clbalance = wa_final_d-opbalance + wa_final_d-h_receipts - wa_final_d-h_payments.
*      v_opning = wa_final_d-clbalance.
*      ind = 'X'.
    ENDAT.

     AT NEW cajo_number.
       wa_final_d-text = 'Cash Journal'.
*      CONCATENATE 'Cash Journal' wa_final_d-cajo_number into wa_final_d-text.
     ENDAT .
*******************     at last
    AT END OF posting_date.
*     Clear: v_opning.
      CALL FUNCTION 'FCJ_GET_DATA_FOR_SCREEN'
        EXPORTING
          i_comp_code         = wa_final_d-bukrs
          i_cajo_number       = wa_final_d-cajo_number
          i_display_period_lo = wa_final_d-posting_date
          i_display_period_hi = wa_final_d-posting_date
        IMPORTING
*         e_beginning_balance = ld_beg_balance
          e_running_balance   = ld_run_balance2
*         e_total_receipts    = e_receipts
*         E_TOTAL_REC_NUMBER  =
*         e_total_payments    = e_payments
*         E_TOTAL_PAYM_NUMBER =
*         E_TOTAL_CHECKS      =
*         E_TOTAL_CHECKS_NUMBER       =
*         E_COMP_NAME         =
*         E_CAJO_NAME         =
*         E_CURRENCY1         =
*         E_CURRENCY2         =
*         E_CURRENCY3         =
*         E_CURRENCY4         =
*         E_CURRENCY5         =
        TABLES
          e_postings          = lt_dummy_table1
          e_wtax_items        = lt_dummy_table2
          e_split_postings    = lt_dummy_table3
          e_cpd               = lt_dummy_table4.
*************
      wa_final_d-clbalance = ld_run_balance2.
*      wa_final_d-clbalance = wa_final_d-opbalance + wa_final_d-h_receipts - wa_final_d-h_payments.
*      v_opning = wa_final_d-clbalance.
*      ind = 'X'.

******      cash limit

      SELECT SINGLE climit FROM zfi_cash_limit
      INTO wa_final_d-climit
      WHERE bukrs = s_ccode
      AND cajo_number = wa_final_d-cajo_number
      AND endda GE wa_final_d-posting_date
      AND begda LE wa_final_d-posting_date.

      wa_final_d-slimit = wa_final_d-climit - wa_final_d-clbalance.
***********
    ENDAT.
**************

*     if ind <> 'X'.
*     wa_final_d-clbalance = v_opning  + wa_final_d-h_receipts - wa_final_d-h_payments.
*     v_opning  = wa_final_d-clbalance.
*     wa_final_d-opbalance = v_opning  .
*    ENDIF.
    if  wa_final_d-document_status <> 'Document was deleted'.
    APPEND wa_final_d TO gi_final.
    ENDIF.
    CLEAR : wa_tcjdoc,wa_cjnames,wa_bkpf,wa_dd07v,wa_skat,wa_tcjpos,wa_final_d,ld_beg_balance,ld_run_balance2,ind,wa_bseg.

  ENDLOOP.

*  SORT gi_final BY bukrs cajo_number.

  LOOP AT gi_final INTO wa_final_d.

    AUTHORITY-CHECK OBJECT 'Z_FBCJ'
   ID 'ZCJNO' FIELD wa_final_d-cajo_number
   ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e023(zfi) WITH wa_final_d-cajo_number.
    ENDIF.


    IF wa_final_d-text CP 'Cash Journal'.
    wa_final_d-color = 'C310'.
    else.
    IF flag = 1.
      wa_final_d-color = 'C410'.
    ELSEIF flag = 0.
      wa_final_d-color = 'C810'.
    ENDIF.
   endif.
    MODIFY gi_final FROM wa_final_d TRANSPORTING color.

    AT END OF cajo_number.
      IF flag = 1.
        flag = 0.
      ELSEIF flag = 0.
        flag = 1.
      ENDIF.
    ENDAT.
    CLEAR wa_final_d.

  ENDLOOP.

ENDFORM.
