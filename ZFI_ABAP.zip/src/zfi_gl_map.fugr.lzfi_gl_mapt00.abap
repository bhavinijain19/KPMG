*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GL_MAPPING..................................*
DATA:  BEGIN OF STATUS_ZFI_GL_MAPPING                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GL_MAPPING                .
CONTROLS: TCTRL_ZFI_GL_MAPPING
            TYPE TABLEVIEW USING SCREEN '2000'.
*.........table declarations:.................................*
TABLES: *ZFI_GL_MAPPING                .
TABLES: ZFI_GL_MAPPING                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
