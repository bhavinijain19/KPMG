FUNCTION-POOL ZFI_GL_CHECK               MESSAGE-ID SV.

* INCLUDE LZFI_GL_CHECKD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GL_CHECKT00                        . "view rel. data dcl.
