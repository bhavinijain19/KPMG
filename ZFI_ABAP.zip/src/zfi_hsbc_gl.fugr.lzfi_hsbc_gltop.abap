FUNCTION-POOL ZFI_HSBC_GL                MESSAGE-ID SV.

* INCLUDE LZFI_HSBC_GLD...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_HSBC_GLT00                         . "view rel. data dcl.
