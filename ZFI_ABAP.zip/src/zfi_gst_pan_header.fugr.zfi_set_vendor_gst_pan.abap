FUNCTION zfi_set_vendor_gst_pan.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_LIFNR) TYPE  LIFNR
*"----------------------------------------------------------------------

  g_lifnr = i_lifnr.

ENDFUNCTION.
