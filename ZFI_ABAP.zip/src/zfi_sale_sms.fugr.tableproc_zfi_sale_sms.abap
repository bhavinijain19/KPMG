*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_SALE_SMS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_SALE_SMS        .

  PERFORM TABLEPROC.

ENDFUNCTION.
