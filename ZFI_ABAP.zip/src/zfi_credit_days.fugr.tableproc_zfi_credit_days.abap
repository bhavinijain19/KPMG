*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_CREDIT_DAYS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_CREDIT_DAYS     .

  PERFORM TABLEPROC.

ENDFUNCTION.
