*&---------------------------------------------------------------------*
*& Include          ZFI_CUSTLEDGER2CPI_V2_FORM
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  GET_CUST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_cust .
  IF p_mins IS NOT INITIAL.
    GET TIME STAMP FIELD lv_tstmp.
    cl_abap_tstmp=>subtractsecs( EXPORTING tstmp = lv_tstmp secs = CONV #( p_mins * 60 ) RECEIVING r_tstmp = lv_tstmp ).
    CONVERT TIME STAMP lv_tstmp TIME ZONE sy-zonlo INTO DATE lv_date TIME lv_time.
  ELSE.
    CLEAR lv_tstmp.
  ENDIF.

  SELECT * FROM bkpf INTO TABLE @it_bkpf
    WHERE bukrs IN @s_bukrs
      AND budat IN @s_budat
      AND blart IN @s_blart
      AND last_change_datetime >= @lv_tstmp.

  IF it_bkpf IS NOT INITIAL.

    " --- STEP 2: Fetch Open Items (BSID) for Delta Headers ---
    SELECT bukrs, kunnr, umskz, augdt, augbl, zuonr, gjahr, belnr, buzei, budat, bldat,
           waers, xblnr, blart, bschl, shkzg, mwskz, dmbtr, wrbtr, saknr, hkont, sgtxt, zbd1t
      FROM bsid INTO TABLE @it_bsid
      FOR ALL ENTRIES IN @it_bkpf
      WHERE bukrs = @it_bkpf-bukrs
        AND belnr = @it_bkpf-belnr
        AND gjahr = @it_bkpf-gjahr
        AND kunnr IN @s_kunnr.

    " --- STEP 3: Fetch Cleared Items (BSAD) for Delta Headers ---
    SELECT bukrs, kunnr, umskz, augdt, augbl, zuonr, gjahr, belnr, buzei, budat, bldat,
           waers, xblnr, blart, bschl, shkzg, mwskz, dmbtr, wrbtr, saknr, hkont, sgtxt, zbd1t
      FROM bsad INTO TABLE @it_bsad
      FOR ALL ENTRIES IN @it_bkpf
      WHERE bukrs = @it_bkpf-bukrs
        AND belnr = @it_bkpf-belnr
        AND gjahr = @it_bkpf-gjahr
        AND kunnr IN @s_kunnr.

    " --- STEP 4: Fetch Line Item Details (BSEG/CDS) ---
    " Using your I_OperationalAcctgDocItem CDS View
    SELECT companycode AS bukrs, accountingdocument AS belnr, fiscalyear AS gjahr,
           clearingaccountingdocument AS augbl, assignmentreference AS zuonr,
           profitcenter AS prctr, glaccount AS hkont
      FROM i_operationalacctgdocitem
      INTO TABLE @it_bseg
      FOR ALL ENTRIES IN @it_bkpf
      WHERE companycode        = @it_bkpf-bukrs
        AND accountingdocument = @it_bkpf-belnr
        AND fiscalyear         = @it_bkpf-gjahr
        AND profitcenter       <> ''.

    IF it_bsid IS NOT INITIAL.
      SELECT kunnr vkorg FROM knvv
        INTO TABLE it_knvv
        FOR ALL ENTRIES IN it_bsid
        WHERE kunnr = it_bsid-kunnr
          AND vkorg IN s_vkorg.
    ENDIF.
    IF it_bsad IS NOT INITIAL.
      SELECT kunnr vkorg FROM knvv
        APPENDING TABLE it_knvv
        FOR ALL ENTRIES IN it_bsad
        WHERE kunnr = it_bsad-kunnr
          AND vkorg IN s_vkorg.
    ENDIF.
  ENDIF.

  SELECT saknr txt50 FROM skat INTO TABLE it_skat WHERE spras EQ 'EN'.

  SELECT blart ltext FROM t003t INTO TABLE it_t003t WHERE spras EQ 'EN' ORDER BY PRIMARY KEY .

  SELECT werks name1 FROM t001w INTO TABLE it_t001w.

  SORT it_bsid BY kunnr budat.
  SORT it_bsad BY kunnr budat.

  DATA: lr_kunnr TYPE RANGE OF kunnr.

  lr_kunnr = VALUE #( FOR wa IN it_knvv ( sign = 'I' option = 'EQ' low = wa-kunnr ) ).

  IF lr_kunnr IS NOT INITIAL.
    DELETE it_bsid WHERE kunnr NOT IN lr_kunnr.
    DELETE it_bsad WHERE kunnr NOT IN lr_kunnr.
  ELSEIF lr_kunnr IS INITIAL.
    CLEAR : it_bsad, it_bsad.
  ENDIF.

  LOOP AT it_bsid INTO wa_bsid.

    IF p_open = 'X'. " opening balance
      AT NEW kunnr.

        CALL FUNCTION 'OIL_LAST_DAY_OF_PREVIOUS_MONTH'
          EXPORTING
            i_date_old = s_budat-low
          IMPORTING
            e_date_new = v_date1.

        CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'
          EXPORTING
            companycode = wa_bsid-bukrs
            customer    = wa_bsid-kunnr
            keydate     = v_date1
          TABLES
            keybalance  = it_open.

        READ TABLE it_open INTO wa_open INDEX 1.
        IF sy-subrc EQ 0.
          wa_final-bukrs = wa_bsid-bukrs.
          wa_final-kunnr = wa_bsid-kunnr.
          wa_final-budat = v_date1.
          IF wa_open-lc_bal > 0.
            wa_final-debit = wa_open-lc_bal.
          ELSE.
            wa_final-credit = wa_open-lc_bal  * ( -1 ).
          ENDIF.

          wa_final-ltext = 'Opening Balance'.
          wa_final-color = 'C510'.
          APPEND wa_final TO it_final.
          CLEAR:wa_final,wa_open,v_date1.
        ENDIF.
      ENDAT.
    ENDIF.

    MOVE-CORRESPONDING wa_bsid TO wa_final.

    READ TABLE it_bseg INTO wa_bseg WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.

    IF sy-subrc EQ 0.
      wa_final-prctr = wa_bseg-prctr.
      wa_final-werks = wa_bseg-prctr+0(4).
      CLEAR:wa_bseg1.
    ENDIF.

    READ TABLE it_t001w INTO wa_t001w WITH KEY werks = wa_final-werks.
    IF sy-subrc EQ 0.
      wa_final-plant = wa_t001w-name1.
      CLEAR:wa_t001w.
    ENDIF.

    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.
    IF sy-subrc = 0.
      wa_final-ref1 = wa_bkpf-xblnr.
      CLEAR: wa_bkpf.
    ENDIF.

    IF wa_final-blart EQ 'DZ'.
      READ TABLE it_bseg INTO wa_bseg WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.
      IF sy-subrc EQ 0.
        wa_final-zuonr = wa_bseg-zuonr.
        wa_final-hkont = wa_bseg-hkont.
        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bseg-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ELSE.

        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bsid-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.
      ENDIF.

    ENDIF.

    IF wa_bsid-shkzg EQ 'S'.
      wa_final-debit = wa_bsid-dmbtr." * ( -1 ).

      IF wa_bsid-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt Reversal'.
      ELSEIF wa_bsid-blart EQ 'RV'.
        wa_final-ltext = 'Invoice'.
      ELSEIF wa_bsid-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsid-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note Reversal'.
      ELSEIF wa_bsid-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note'.
      ELSEIF wa_bsid-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ELSE.
      wa_final-credit = wa_bsid-dmbtr.

      IF wa_bsid-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt'.
      ELSEIF wa_bsid-blart EQ 'RV'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsid-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsid-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsid-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note Reversal'.
      ELSEIF wa_bsid-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ENDIF.

    days = wa_bsid-zbd1t.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = wa_bsid-budat
        days      = days
        months    = 00
        signum    = '+'
        years     = 00
      IMPORTING
        calc_date = v_cldate.

    wa_final-due_dat = v_cldate.
    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_bsid-kunnr.
    IF sy-subrc = 0.
      wa_final-vkorg = wa_knvv-vkorg.
    ENDIF.
    APPEND wa_final TO it_final.
    CLEAR:wa_final,wa_bsid,wa_t003t,wa_bseg,wa_knvv,v_cldate,days.
  ENDLOOP.

  LOOP AT it_bsad INTO wa_bsad.
    IF p_open = 'X'.
      AT NEW kunnr.
        READ TABLE it_bsid INTO wa_bsid WITH KEY kunnr = wa_bsad-kunnr.
        IF sy-subrc EQ 0.

        ELSE.
          CALL FUNCTION 'OIL_LAST_DAY_OF_PREVIOUS_MONTH'
            EXPORTING
              i_date_old = s_budat-low
            IMPORTING
              e_date_new = v_date1.


          CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'
            EXPORTING
              companycode = wa_bsad-bukrs
              customer    = wa_bsad-kunnr
              keydate     = v_date1
            TABLES
              keybalance  = it_open.

          READ TABLE it_open INTO wa_open INDEX 1.
          IF sy-subrc EQ 0.
            wa_final-bukrs = wa_bsad-bukrs.
            wa_final-kunnr = wa_bsad-kunnr.
            wa_final-budat = v_date1.

            IF wa_open-lc_bal > 0.
              wa_final-debit = wa_open-lc_bal.
            ELSE.
              wa_final-credit = wa_open-lc_bal  * ( -1 ).
            ENDIF.
            wa_final-ltext = 'Opening Balance'.
            wa_final-color = 'C510'.
            APPEND wa_final TO it_final.
            CLEAR:wa_final,wa_open,v_date1.
          ENDIF.

        ENDIF.
      ENDAT.
    ENDIF.

    MOVE-CORRESPONDING wa_bsad TO wa_final.

    READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
    IF sy-subrc EQ 0.

      wa_final-prctr = wa_bseg1-prctr.
      wa_final-werks = wa_bseg1-prctr+0(4).
      CLEAR:wa_bseg1.

    ENDIF.

    READ TABLE it_t001w INTO wa_t001w WITH KEY werks = wa_final-werks.
    IF sy-subrc EQ 0.

      wa_final-plant = wa_t001w-name1.
      CLEAR:wa_t001w.

    ENDIF.

    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
    IF sy-subrc = 0.
      wa_final-ref1 = wa_bkpf-xblnr.

      CLEAR: wa_bkpf.
    ENDIF.



    IF wa_final-blart EQ 'DZ'.

      READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
      IF sy-subrc EQ 0.
        wa_final-zuonr = wa_bseg1-zuonr.
        wa_final-hkont = wa_bseg1-hkont.
*        wa_final-prctr = wa_bseg1-prctr.

        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bseg1-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ELSE.
        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bsad-saknr.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ENDIF.

    ENDIF.

    IF wa_bsad-shkzg EQ 'S'.
      wa_final-debit = wa_bsad-dmbtr." * ( -1 ).

      IF wa_bsad-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt Reversal'.
      ELSEIF wa_bsad-blart EQ 'RV'.
        wa_final-ltext = 'Invoice'.
      ELSEIF wa_bsad-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsad-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note Reversal'.
      ELSEIF wa_bsad-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note'.
      ELSEIF wa_bsad-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ELSE.
      wa_final-credit = wa_bsad-dmbtr.

      IF wa_bsad-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt'.
      ELSEIF wa_bsad-blart EQ 'RV'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsad-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsad-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsad-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note Reversal'.
      ELSEIF wa_bsad-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.
    ENDIF.

    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_bsad-kunnr.
    IF sy-subrc = 0.
      wa_final-vkorg = wa_knvv-vkorg.
    ENDIF.

    days = wa_bsad-zbd1t.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = wa_bsad-budat
        days      = days
        months    = 00
        signum    = '+'
        years     = 00
      IMPORTING
        calc_date = v_cldate.

    wa_final-due_dat = v_cldate.

    APPEND wa_final TO it_final.
    CLEAR:wa_final,wa_bsad,wa_bseg1,wa_knvv,v_cldate,days.
  ENDLOOP.

  SELECT sign
         opti
         low
         high
    INTO TABLE it_tvarvc
    FROM tvarvc
    WHERE name = c_tvarvc
      AND type = c_type_user.

  DELETE it_final WHERE vkorg NOT IN it_tvarvc.

  SELECT kunnr name1 name2 ort01 FROM kna1 INTO TABLE it_kna1 FOR ALL ENTRIES IN it_final WHERE kunnr = it_final-kunnr ORDER BY PRIMARY KEY .

  SORT it_final BY kunnr budat.

  IF p_chk EQ 'X'.
    LOOP AT it_final INTO wa_final.
      v_debit = wa_final-debit.
      v_credit = wa_final-credit.
      AT NEW kunnr.
        v_total = v_total + v_debit - v_credit.
        wa_final-ind1 = 'X'.
        MODIFY it_final FROM wa_final TRANSPORTING ind1.
      ENDAT.
      AT LAST.
        DELETE it_final WHERE ind1 EQ 'X'.
      ENDAT.
    ENDLOOP.

    LOOP AT it_final INTO wa_final.
      v_customer = wa_final-kunnr.
      v_text     = 'Opening Balance'.
      AT FIRST.
        CLEAR:wa_final.
        wa_final-kunnr = v_customer.
        wa_final-ltext = v_text.
        IF v_total LT 0.
          wa_final-credit = v_total.
        ELSE.
          wa_final-debit = v_total.
        ENDIF.
        wa_final-color = 'C510'.
        APPEND wa_final TO it_final.
      ENDAT.
    ENDLOOP.

    SORT it_final BY kunnr budat.

    LOOP AT it_final INTO wa_final.
      READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
      IF sy-subrc EQ 0.
        CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name1 SEPARATED BY ' '.
        MODIFY it_final FROM wa_final TRANSPORTING name1.
        CLEAR:wa_kna1.
      ENDIF.

      IF wa_final-debit IS NOT INITIAL.
        wa_final-closing = v_closing + wa_final-debit.
        v_closing = wa_final-closing.
      ELSE.
        IF v_closing IS NOT INITIAL.
          wa_final-closing = v_closing - wa_final-credit.
          v_closing = wa_final-closing.
        ELSE.
          wa_final-closing = v_closing - wa_final-credit * ( -1 ).
          v_closing = wa_final-closing.
        ENDIF.
      ENDIF.
      CONCATENATE wa_final-blart wa_final-kunnr wa_final-belnr wa_final-budat wa_final-bukrs wa_final-buzei INTO wa_final-prkey.
      MODIFY it_final FROM wa_final TRANSPORTING closing prkey.
    ENDLOOP.
  ELSE.

    SORT it_final BY kunnr budat.
    LOOP AT it_final INTO wa_final.
      READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
      IF sy-subrc EQ 0.
        CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name1 SEPARATED BY ' '.
        MODIFY it_final FROM wa_final TRANSPORTING name1.
        CLEAR:wa_kna1.
      ENDIF.

      IF wa_final-debit IS NOT INITIAL.
        wa_final-closing = v_closing + wa_final-debit.
        v_closing = wa_final-closing.
      ELSE.
        wa_final-closing = v_closing - wa_final-credit.
        v_closing = wa_final-closing.
      ENDIF.
      wa_final-amount = '0.00'.
      CONCATENATE wa_final-blart '/' wa_final-belnr INTO wa_final-doctype.
      SHIFT wa_final-kunnr LEFT DELETING LEADING '0'.
      wa_final-kunnr = wa_final-kunnr.

      CONCATENATE wa_final-blart wa_final-kunnr wa_final-belnr wa_final-budat wa_final-bukrs wa_final-buzei INTO wa_final-prkey.
      MODIFY it_final FROM wa_final TRANSPORTING closing amount doctype kunnr prkey .
      AT END OF kunnr.
        CLEAR:wa_final, v_closing.
      ENDAT.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " GET_CUST
*&---------------------------------------------------------------------*
*& Form send2cpi
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM send2cpi .
  " Outbound CPI Push
  SELECT SINGLE low FROM tvarvc INTO @DATA(lv_endpoint) WHERE name = 'ZFI_CUSTLEDGER_EP' AND type = 'P'.
  IF sy-subrc = 0 AND it_final IS NOT INITIAL.
    zcl_http_util=>post_to_cpi(
      EXPORTING
        iv_json        = /ui2/cl_json=>serialize( data        = it_final
                                                  pretty_name = /ui2/cl_json=>pretty_mode-low_case )
        iv_path_suffix = CONV string( lv_endpoint )
      IMPORTING
        ev_status      = DATA(lv_status)
        ev_response    = DATA(lv_resp)
    ).

    IF lv_status BETWEEN 200 AND 202.
      WRITE: / 'API Response processed. Status:', lv_status, lv_resp. "/ 'Success: Data synced to CPI for Company Codes in selection.'.
    ELSE.
      WRITE: / 'Error Posting to CPI:', lv_status, lv_resp.
    ENDIF.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_CAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_cat .

  DEFINE fillcat.

    wa_fcat-col_pos    = &1.
    wa_fcat-tabname    = &2.
    wa_fcat-fieldname  = &3.
    wa_fcat-seltext_m  = &4.
    wa_fcat-no_out     = &5.
    wa_fcat-do_sum     = &6.
    wa_fcat-no_zero    = &7.
    wa_fcat-hotspot    = &8.
    APPEND wa_fcat TO it_fcat.

  END-OF-DEFINITION.


  fillcat 1 'IT_FINAL' 'bukrs'      'Company Code'                ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'VKORG'      'Sales Organization'          ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'kunnr'      'Customer Number'             ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'NAME1'      'Customer Name'               'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'belnr'      'Document Number'             ' '     ' '  ' ' 'X'.
  fillcat 1 'IT_FINAL' 'budat'      'Posting Date'                ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'xblnr'      'Reference Document Number'   ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'bldat'      'Document Date'               ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'blart'      'Document Type'               ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'LTEXT'      'Doc. Type Text'              ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'UMSKZ'      'Spl. G/L Indicator'          ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'zuonr'      'Cheque No./ NEFT/ RTGS No.'  ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'DEBIT '     'Debit Amount'                ' '     ' '  'X' ' '.
  fillcat 1 'IT_FINAL' 'CREDIT'     'Credit Amount'               ' '     ' '  'X' ' '.
  fillcat 1 'IT_FINAL' 'CLOSING'    'Closing'                     ' '     ' '  'X' ' '.
  fillcat 1 'IT_FINAL' 'PRCTR'      'Profit Center'               ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'WERKS'      'Plant'                       ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'PLANT'      'Plant Desc.'                 ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'AUGBL'      'Clearing Doc. Num'           ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'augdt'      'Clearing Date'               ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'SGTXT'      'Text'                        ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'saknr'      'G/L Account Number'          ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'hkont'      'General Ledger Account'      ' '     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'TXT50'      'G/L Account Text'            ' '     ' '  ' ' ' '.


  fillcat 1 'IT_FINAL' 'gjahr'      'Fiscal Year'                 'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'bschl'      'Posting Key'                 'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'shkzg'      'Debit/Credit Indicator'      'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'mwskz'      'Tax on sales/purchases code' 'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'dmbtr'      'Amount'                      'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'wrbtr'      'Amount In Global'            'X'     ' '  ' ' ' '.
  fillcat 1 'IT_FINAL' 'DUE_DAT'    'Due Date'                    'X'     ' '  ' ' ' '.
*    fillcat 1 'IT_FINAL' 'OPENING'    'Opening'                    'X'     'X'  'X'  .


  wa_layout-zebra = 'X'.
  wa_layout-colwidth_optimize = 'X'.
  wa_layout-info_fieldname = 'COLOR'.

ENDFORM.                    " FILL_CAT
*&---------------------------------------------------------------------*
*&      Form  SMARTFORM1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM smartform1 .


*  SORT it_final BY kunnr budat.
*  SORT IT_FINAL BY KUNNR BLDAT.
  DATA:m_adrnr TYPE ad_addrnum,
       m_email TYPE ad_smtpadr.

  CLEAR:v_customer.
  IF s_kunnr-high IS INITIAL.

    LOOP AT s_kunnr.
      SHIFT s_kunnr-low LEFT DELETING LEADING '0'.
      CONCATENATE v_customer ', ' s_kunnr-low INTO v_customer.
    ENDLOOP.

    SHIFT v_customer LEFT DELETING LEADING ','.

    IF s_bukrs-low EQ '1000'.
      v_header = 'ASTRAL POLY TECHNIK LIMITED'.
    ELSE.
      v_header = 'ADVANCED ADHESIVES LIMITED'.
    ENDIF.

    READ TABLE it_kna1 INTO wa_kna1 INDEX 1.
    IF sy-subrc EQ 0.
      CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO v_name.
      v_city = wa_kna1-ort01.
    ENDIF.

    CONCATENATE s_budat-low+6(2) '/' s_budat-low+4(2) '/' s_budat-low+0(4) INTO v_low.
    CONCATENATE                               s_budat-high+6(2) '/' s_budat-high+4(2) '/' s_budat-high+0(4) INTO v_high.
    CONCATENATE v_low 'to' v_high INTO v_date SEPARATED BY ' '.

    it_form_final = CORRESPONDING #( it_final ).

    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname = 'ZFI_LEDGER_CUSTOMER'
      IMPORTING
        fm_name  = fmname.

    CALL FUNCTION fmname
      EXPORTING
        v_customer = v_customer
        v_name     = v_name
        v_date     = v_date
        v_low      = v_low
        v_high     = v_high
        v_city     = v_city
        v_header   = v_header
        v_bukrs    = s_bukrs-low
        wa_kunnr   = wa_kna1-kunnr
*      importing
*       job_output_info = gs_otfdata
      TABLES
        it_final   = it_form_final.
  ENDIF.

  CLEAR:v_customer.



ENDFORM.                    " SMARTFORM1
*&---------------------------------------------------------------------*
*&      Form  DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
      i_callback_user_command = 'USER_COMMAND'
      i_callback_top_of_page  = 'TOP_PAGE'
      is_layout               = wa_layout
      it_fieldcat             = it_fcat
*     it_sort                 = wa_sort
      i_save                  = 'X'
*     IT_EVENTS               =
    TABLES
      t_outtab                = it_final.


ENDFORM.                    " DISPLAY


FORM top_page.

  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.

  IF s_kunnr-high IS INITIAL.
    CLEAR:v_customer.
    LOOP AT s_kunnr.

      SHIFT s_kunnr-low LEFT DELETING LEADING '0'.
      CONCATENATE v_customer ', ' s_kunnr-low INTO v_customer.
    ENDLOOP.
    SHIFT v_customer LEFT DELETING LEADING ','.

    CONCATENATE 'Customer Number' v_customer INTO v_customer SEPARATED BY ':'.

    IF s_bukrs-low EQ '1000'.

      wa_header-info = 'ASTRAL POLY TECHNIK LIMITED'.
      wa_header-typ = 'S'.
      APPEND wa_header TO it_header.

    ELSE.

      wa_header-info = 'ADVANCED ADHESIVES LIMITED'.
      wa_header-typ = 'S'.
      APPEND wa_header TO it_header.

    ENDIF.

    wa_header-info = v_customer.
    wa_header-typ = 'S'.
    APPEND wa_header TO it_header.

    READ TABLE it_kna1 INTO wa_kna1 INDEX 1.
    IF sy-subrc EQ 0.
      CONCATENATE 'Customer Name:' wa_kna1-name1 wa_kna1-name2 INTO v_name.
    ENDIF.

    wa_header-info = v_name.
    wa_header-typ = 'S'.
    APPEND wa_header TO it_header.

    CONCATENATE 'City:' wa_kna1-ort01 INTO wa_kna1-ort01 SEPARATED BY ' '.

    wa_header-info = wa_kna1-ort01.
    wa_header-typ = 'S'.
    APPEND wa_header TO it_header.

    CONCATENATE 'Statement of Account from:' s_budat-low+6(2) '/' s_budat-low+4(2) '/' s_budat-low+0(4) INTO v_low."  'to'
    CONCATENATE                               s_budat-high+6(2) '/' s_budat-high+4(2) '/' s_budat-high+0(4) INTO v_high.
    CONCATENATE v_low 'to' v_high INTO v_date SEPARATED BY ' '.

    wa_header-info = v_date.
    wa_header-typ = 'S'.
    APPEND wa_header TO it_header.

    CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
      EXPORTING
        it_list_commentary = it_header.
*      I_LOGO             = 'ASTRALS'.

    CLEAR: wa_header,v_customer,v_name, wa_kna1.
    REFRESH it_header.

  ENDIF.


ENDFORM.

FORM user_command USING ucomm LIKE sy-ucomm
                        selfield TYPE slis_selfield.
  CASE ucomm.
    WHEN '&IC1'.
      CLEAR wa_final.
      READ TABLE it_final INTO wa_final INDEX selfield-tabindex.
      SET PARAMETER ID: 'BLN' FIELD wa_final-belnr,
                        'BUK' FIELD wa_final-bukrs,
                        'GJR' FIELD wa_final-gjahr.
      CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN.
  ENDCASE.
ENDFORM.
