*&---------------------------------------------------------------------*
*& Modulpool SAPMZFI_BANK_RECO_MANUAL
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
PROGRAM SAPMZFI_BANK_RECO_MANUAL.

INCLUDE sapmzfi_bank_reco_manual_top            .  " global Data

INCLUDE sapmzfi_bank_reco_manual_o01            .  " PBO-Modules
INCLUDE sapmzfi_bank_reco_manual_i01            .  " PAI-Modules
INCLUDE sapmzfi_bank_reco_manual_f01            .  " FORM-Routines
