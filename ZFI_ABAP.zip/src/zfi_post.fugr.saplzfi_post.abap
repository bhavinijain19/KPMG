*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_POSTTOP.                      " Global Declarations
  INCLUDE LZFI_POSTUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_POSTF...                      " Subroutines
* INCLUDE LZFI_POSTO...                      " PBO-Modules
* INCLUDE LZFI_POSTI...                      " PAI-Modules
* INCLUDE LZFI_POSTE...                      " Events
* INCLUDE LZFI_POSTP...                      " Local class implement.
* INCLUDE LZFI_POSTT99.                      " ABAP Unit tests
