*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_OD_SMS_GP_CSTOP.              " Global Declarations
  INCLUDE LZFI_OD_SMS_GP_CSUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_OD_SMS_GP_CSF...              " Subroutines
* INCLUDE LZFI_OD_SMS_GP_CSO...              " PBO-Modules
* INCLUDE LZFI_OD_SMS_GP_CSI...              " PAI-Modules
* INCLUDE LZFI_OD_SMS_GP_CSE...              " Events
* INCLUDE LZFI_OD_SMS_GP_CSP...              " Local class implement.
* INCLUDE LZFI_OD_SMS_GP_CST99.              " ABAP Unit tests
  INCLUDE LZFI_OD_SMS_GP_CSF00                    . " subprograms
  INCLUDE LZFI_OD_SMS_GP_CSI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
