*&---------------------------------------------------------------------*
*& Report  ZFI_CASH_DISC
*&----------------------------------------------------------------------------*
*& Title: Cash Discount Report (Customer)
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey,   KPIT Technologies Ltd, Pune
*& Functional Consultant : Biswajit Sahoo, KPIT Technologies Ltd, Pune
*& Report Creation Date  : 01/11/2014
*& Transaction Code      :
*& Request Number        : DEVK900585
*&----------------------------------------------------------------------------*
REPORT zfi_cash_disc_rcl_auto.
*&---------------------------------------------------------------------*
*&   Type pools declaration
*&---------------------------------------------------------------------*
TYPE-POOLS:trux,slis.
*&---------------------------------------------------------------------*
*&   Tables
*&---------------------------------------------------------------------*
TABLES:zfi_cash_day_rcl,bsid.

*&----------------------------------------------------------------------------*
*&    TYPES
*&----------------------------------------------------------------------------*

TYPES:BEGIN OF ty_final,
        kunnr     TYPE kunnr,       "Customer
        bukrs     TYPE bukrs,       "Company Code
        name1     TYPE name1_gp,    "Customer Name,
        vbeln     TYPE vbeln_vf,    "Billing Doc No
        fblnr     TYPE belnr_d,     "FI Doc No
        fblrt     TYPE blart,       "Document Type
        fbdat     TYPE budat,       "Posting Date
        gjahr     TYPE gjahr,       "Fiscal Year
        belnr     TYPE belnr_d,     "Document No
        blart     TYPE blart,       "Document Type
        budat     TYPE budat,       "Posting Date
*        zzdayd TYPE zde_zzdayd,  "No Of Days "comment by parth
        zzdayd    TYPE i,  "No Of Days
        zzperc    TYPE zde_zzperc,  "Percentage
        zkvgr1    TYPE vbrp-kvgr1,  "changed by Ranjan 18.02.2026
        zkvgr2    TYPE vbrp-kvgr2,  "changed by Ranjan 18.02.2026
        Desc(100),
        dmbtr     TYPE dmbtr,       "Amount
        zzint     TYPE dmbtr,       "Interest amount,
        messg     TYPE string,      "Message
        sel       TYPE c,           "Selection
        nodays    TYPE numc3,
        bldat     TYPE budat,       "Document date
        werks     TYPE vbrp-werks,   "plant
        xblnr(16) TYPE c,
      END OF ty_final.

TYPES:BEGIN OF ty_final_temp,
        belnr     TYPE belnr_d,     "Document No
        kunnr     TYPE kunnr,       "Customer
        bukrs     TYPE bukrs,       "Company Code
        name1     TYPE name1_gp,    "Customer Name,
        vbeln     TYPE vbeln_vf,    "Billing Doc No
        fblnr     TYPE belnr_d,     "FI Doc No
        fblrt     TYPE blart,       "Document Type
        fbdat     TYPE budat,       "Posting Date
        gjahr     TYPE gjahr,       "Fiscal Year
        blart     TYPE blart,       "Document Type
        budat     TYPE budat,       "Posting Date
*        zzdayd TYPE zde_zzdayd,  "No Of Days
        zzdayd    TYPE i,  "No Of Days
        zzperc    TYPE zde_zzperc,  "Percentage
        zkvgr1    TYPE vbrp-kvgr1,  "changed by Ranjan 18.02.2026
        zkvgr2    TYPE vbrp-kvgr2,  "changed by Ranjan 18.02.2026
        Desc(100),
        dmbtr     TYPE dmbtr,       "Amount
        zzint     TYPE dmbtr,       "Interest amount,
        messg     TYPE string,      "Message
        sel       TYPE c,           "Selection
        ind       TYPE char1,
      END OF ty_final_temp.

TYPES:BEGIN OF ty_bsad,
        bukrs     TYPE bukrs,       "Company Code
        kunnr     TYPE kunnr,       "Customer
        augdt     TYPE erdat,
        augbl     TYPE augbl,       "Billing Doc No
        gjahr     TYPE gjahr,       "Fiscal Year
        belnr     TYPE belnr_d,     "Document No
        budat     TYPE budat,       "Posting Date
        blart     TYPE blart,       "Document Type
        shkzg     TYPE shkzg,       "Debit/Credit Indicator
        dmbtr     TYPE dmbtr,       "Amount
        vbeln     TYPE vbeln_vf,     "Billing Document
        xblnr     TYPE xblnr,
        bldat     TYPE bldat,        "Document Date
        zuonr(10),
        xref1     TYPE xref1,
        flag,
      END OF ty_bsad.

TYPES:BEGIN OF ty_kna1,
        kunnr TYPE kunnr,       "Customer
        name1 TYPE name1_gp,    "Customer Name,
      END OF ty_kna1.

TYPES : BEGIN OF ty_t001w,
          werks      TYPE t001w-werks,
          j_1bbranch TYPE t001w-j_1bbranch,
        END OF ty_t001w.

DATA: it_t001w TYPE STANDARD TABLE OF ty_t001w,
      wa_t001w TYPE ty_t001w.

TYPES:BEGIN OF ty_bsid,
        bukrs TYPE bukrs,       "Company Code
        kunnr TYPE kunnr,       "Customer
        umskz TYPE umskz,       "Special G/L Indicator
        gjahr TYPE gjahr,       "Fiscal Year
        belnr TYPE belnr_d,     "Document No
        budat TYPE budat,       "Posting Date
        blart TYPE blart,       "Document Type
        shkzg TYPE shkzg,       "Debit/Credit Indicator
        dmbtr TYPE dmbtr,       "Amount
        zterm TYPE dzterm,      "Terms of Payment Key
        rebzg TYPE rebzg,       "Number of the Invoice the Transaction Belongs to
        rebzj TYPE rebzj,       "Fiscal Year of the Relevant Invoice (for Credit Memo)
        vbeln TYPE vbeln_vf,    "Billing Doc No
        flag,
      END OF ty_bsid.
TYPES: BEGIN OF ty_bdc,
         bukrs    TYPE bukrs,
         accnt    TYPE newko,
         bldat    TYPE char10,   "Hard Code System Date
         budat    TYPE char10,
         wrbtr    TYPE char16, "wrbtr,
         xblnr    TYPE xblnr,
         hkont    TYPE hkont,   "Hard Code 62130101
         wrbt1    TYPE char16,   "
         kostl    TYPE kostl,   "Hard Code 1600311004
         zuonr    TYPE dzuonr,
         bus_area TYPE werks,
         bupla    TYPE t001w-j_1bbranch,
       END OF ty_bdc.
TYPES: BEGIN OF ty_tvarvc,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE tvarv_val,
         high TYPE tvarv_val,
       END OF ty_tvarvc.
**************************   added by parth 29/06/2019
TYPES: BEGIN OF ty_tka3c,
         bukrs TYPE  tka3c-bukrs,
         kstar TYPE  tka3c-kstar,
         gsber TYPE  tka3c-gsber, " chngs by aarti VSD 26.03.2026
         kostl TYPE tka3c-kostl,
       END OF ty_tka3c.
**************************   ended by parth 29/06/2019

TYPES: BEGIN OF ty_fplant,
         werks TYPE vbrp-werks,
       END OF ty_fplant.

*&----------------------------------------------------------------------------*
*&    INTERNAL TABLES
*&----------------------------------------------------------------------------*
DATA : wa_layout TYPE slis_layout_alv,
       gt_fcat   TYPE slis_t_fieldcat_alv,
       gt_sort   TYPE  slis_t_sortinfo_alv,
       wa_fcat   TYPE slis_fieldcat_alv,
       wa_sort   TYPE slis_sortinfo_alv.
DATA : gt_final      TYPE STANDARD TABLE OF ty_final,
       lt_acc_key    TYPE STANDARD TABLE OF ty_tvarvc,
       wa_final      TYPE ty_final,
       lt_vbrp       TYPE STANDARD TABLE OF vbrp,
       lt_vbrp1      TYPE STANDARD TABLE OF vbrp,
       lwa_vbrp      TYPE vbrp,
       lwa_vbrp1     TYPE vbrp,
       gt_final_temp TYPE STANDARD TABLE OF ty_final_temp,
       wa_final_temp TYPE ty_final_temp,
       wa_final1     TYPE ty_final,
       gt_knbw       TYPE STANDARD TABLE OF knbw,
       wa_knbw       TYPE knbw,
       gt_bsis       TYPE STANDARD TABLE OF bsis,
       wa_bsis       TYPE bsis,
       gt_vbrk       TYPE STANDARD TABLE OF vbrk,
       gt_vbrk4      TYPE STANDARD TABLE OF vbrk,
       lt_konv       TYPE STANDARD TABLE OF konv,
       lwa_konv      TYPE konv,
       wa_vbrk4      TYPE vbrk,
       wa_vbrk       TYPE vbrk,
       gt_knvv       TYPE STANDARD TABLE OF knvv,
       wa_knvv       TYPE knvv,
       gt_cost       TYPE STANDARD TABLE OF zfi_cost,
       wa_cost       TYPE zfi_cost,
       gt_bsad       TYPE STANDARD TABLE OF ty_bsad,
       gt_bsad1      TYPE STANDARD TABLE OF ty_bsad,
       gt_bsadt      TYPE STANDARD TABLE OF ty_bsad,
       gt_bsid       TYPE STANDARD TABLE OF ty_bsid,
       gt_bsidt      TYPE STANDARD TABLE OF ty_bsid,
       gt_uebsad     TYPE STANDARD TABLE OF ty_bsad,
       wa_bsad       TYPE ty_bsad,
       wa_bsadt      TYPE ty_bsad,
       wa_bsid       TYPE ty_bsid,
       wa_bsidt      TYPE ty_bsid,
       wa_uebsad     TYPE ty_bsad,
       gt_bkpf       TYPE STANDARD TABLE OF bkpf,
       wa_bkpf       TYPE bkpf,
       gt_vbsegs     TYPE STANDARD TABLE OF vbsegs,
       wa_vbsegs     TYPE vbsegs,
       gt_day        TYPE STANDARD TABLE OF zfi_cash_day_rcl,
       wa_day        TYPE zfi_cash_day_rcl,
       gt_kna1       TYPE STANDARD TABLE OF ty_kna1,
       wa_kna1       TYPE ty_kna1,
       gt_bdc        TYPE STANDARD TABLE OF ty_bdc,
       wa_bdc        TYPE ty_bdc,
       it_kostl      TYPE STANDARD TABLE OF ty_tka3c,
       wa_kostl      TYPE ty_tka3c,
       gt_plant      TYPE STANDARD TABLE OF zsd_on_plant,
       wa_plant      TYPE zsd_on_plant,
       it_fplant     TYPE STANDARD TABLE OF ty_fplant,
       wa_fplant     TYPE ty_fplant.
FIELD-SYMBOLS: <fs_final> LIKE LINE OF gt_final.
FIELD-SYMBOLS: <fs_final1> LIKE LINE OF gt_final.

DATA : bdcdata      LIKE bdcdata OCCURS 0 WITH HEADER LINE,
       gt_msgtype   LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE,
       params       TYPE ctu_params,
       lv_msg       TYPE string,
       gv_tabix     TYPE sy-tabix,
       gv_count     TYPE i,
       v_lines      TYPE i,
       gv_fld(2)    TYPE c,
       lv_findmbtr  TYPE dmbtr,
       gv_field     TYPE char50,
       gv_flag,
       lv_ki5       TYPE dmbtr,
       lv_ki51      TYPE dmbtr,
       lv_amt       TYPE dmbtr,
       lv_kwert     TYPE dmbtr,
       lv_amt_c(16) TYPE c,
       count        TYPE i,
       v_text       TYPE string,
       v_text2      TYPE string,
       v_text1(255),
       lv_len       TYPE i,
       lv_dmbtr     TYPE dmbtr,
       zkvgr1       TYPE vbrp-kvgr1,  "changed by Ranjan 18.02.2026
       zkvgr2       TYPE vbrp-kvgr2.  "changed by Ranjan 18.02.2026
DATA : diff TYPE i.

DATA: ls_new_plant TYPE zsd_on_plant.
******************
*********************************************************
TYPES : BEGIN OF ty_pknkk,
          kunnr TYPE knkk-kunnr,
          knkli TYPE knkk-knkli,
        END OF ty_pknkk.
TYPES : BEGIN OF ty_cknkk,
          kunnr   TYPE knkk-kunnr,
          knkli   TYPE knkk-knkli,
          ind(01),
        END OF ty_cknkk.

TYPES: BEGIN OF ty_kvgr1_2,
         kunnr TYPE knvv-kunnr,
         kvgr1 TYPE knvv-kvgr1,
         kvgr2 TYPE knvv-kvgr2,
       END OF ty_kvgr1_2.


DATA: it_pknkk TYPE STANDARD TABLE OF ty_pknkk,
      wa_pknkk TYPE ty_pknkk.

DATA: it_cknkk TYPE STANDARD TABLE OF ty_cknkk,
      wa_cknkk TYPE ty_cknkk.

DATA: it_sknkk TYPE STANDARD TABLE OF ty_cknkk,
      wa_sknkk TYPE ty_cknkk.

DATA: gt_zsig_amount TYPE TABLE OF zsig_amount,
      gs_zsig_amount TYPE zsig_amount.

DATA: gt_kvgr1_2 TYPE TABLE OF ty_kvgr1_2,
      gs_kvgr1_2 TYPE ty_kvgr1_2.

TYPES:BEGIN OF ty_absid,
        kunnr      TYPE bsid-kunnr,
        budat      TYPE bsid-budat,
        bldat      TYPE bsid-bldat,
        belnr      TYPE bsid-belnr,
        shkzg      TYPE bsid-shkzg,
        blart      TYPE bsid-blart,
        bukrs      TYPE bsid-bukrs,
        dmbtr      TYPE bsid-dmbtr,
        wrbtr      TYPE bsid-wrbtr,
        xblnr      TYPE bsid-xblnr,
        augdt      TYPE bsid-augdt,
        zfbdt      TYPE bsid-zfbdt,
        zbd1t      TYPE bsid-zbd1t,
        duedat     TYPE bsid-zfbdt,

        pdmbtr     TYPE bsid-dmbtr,
        days       TYPE i,
        knkli      TYPE knkk-knkli,
        dueind(01),
      END OF ty_absid.
DATA: it_sbsid TYPE STANDARD TABLE OF ty_absid,
      wa_sbsid TYPE ty_absid.

DATA: it_dsbsid TYPE STANDARD TABLE OF ty_absid,
      wa_dsbsid TYPE ty_absid.

DATA : it_hbsid TYPE STANDARD TABLE OF ty_absid,
       wa_hbsid TYPE ty_absid.

***********
*********
*&----------------------------------------------------------------------------*
*&    Variables
*&----------------------------------------------------------------------------*
DATA : gv_bukrs TYPE bukrs,
       gv_kunnr TYPE kunnr,
       gv_datum TYPE i . "LENGTH 3.
*&----------------------------------------------------------------------------*
*&    Constants
*&----------------------------------------------------------------------------*
*CONSTANTS : gc_rv    TYPE blart VALUE 'RV',
CONSTANTS : gc_dz    TYPE blart VALUE 'DZ',
            gc_dg    TYPE blart VALUE 'DG',
            gc_s     TYPE shkzg VALUE 'S',
            gc_hkont TYPE hkont VALUE '0062130102'.

DATA: s_rv TYPE blart.
RANGES : gc_rv FOR s_rv.

CONSTANTS : c_var_name TYPE rvari_vnam VALUE 'ZFI_PLANT',
            c_type_s   TYPE rsscr_kind VALUE 'S'.

*&----------------------------------------------------------------------------*
*&    Selection Screen
*&----------------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-000.
  SELECT-OPTIONS: s_bukrs FOR gv_bukrs NO INTERVALS DEFAULT '1000',
                  s_kunnr FOR gv_kunnr. "OBLIGATORY.
  PARAMETERS : p_vkorg TYPE knvv-vkorg OBLIGATORY. " Added by Carina Jose on 03.03.2022
SELECTION-SCREEN END OF BLOCK b1.
SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-001.
*PARAMETERS : p_datum TYPE datum OBLIGATORY."Comment by parth 12.03.2022
  SELECT-OPTIONS : p_datum FOR bsid-budat OBLIGATORY."Added by parth 12.03.2022
SELECTION-SCREEN END OF BLOCK b2.

*AT SELECTION-SCREEN OUTPUT.
*  LOOP AT SCREEN.
*    IF screen-name = 'S_BUKRS-LOW'.
*      screen-input = '0'.
*      MODIFY SCREEN.
*    ENDIF.
*  ENDLOOP .

AT SELECTION-SCREEN.
*  IF p_datum IS INITIAL .
*    p_datum = sy-datum.
*  ELSEIF p_datum GT sy-datum.
*    MESSAGE e007(zfi)." 'Key date can not be future date' TYPE 'E'.
*  ENDIF.
  IF p_datum-high IS NOT INITIAL.
    diff = p_datum-high - p_datum-low.
    IF diff > 365.
      MESSAGE 'Please enter CD date range for not more than 1 year' TYPE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.
  ENDIF.

  IF p_datum-high GT sy-datum.
    MESSAGE e007(zfi)." 'Key date can not be future date' TYPE 'E'.
  ENDIF.

START-OF-SELECTION.
  PERFORM authorization_check. " Added by Carina Jose on 03.03.2022
  PERFORM f_get_data.
  PERFORM f_set_data.
  IF gt_final[] IS INITIAL .
    MESSAGE s002(zfi)."'No data For given Selection' TYPE 'S'.
  ENDIF.

END-OF-SELECTION.

  CHECK NOT gt_final[] IS INITIAL.
  PERFORM f_alv_fcat.
  PERFORM f_alv_layout.
  PERFORM f_alv_display.
*&---------------------------------------------------------------------*
*&      Form  F_GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_data .
**  ***********************  for 3 days ageing
*
*  SELECT kunnr knkli FROM knkk
*      INTO TABLE it_pknkk
*      WHERE kunnr IN s_kunnr.
*
*  SELECT kunnr knkli FROM knkk
*       INTO TABLE it_cknkk
*       FOR ALL ENTRIES IN it_pknkk
*       WHERE knkli = it_pknkk-knkli.
*
*
**  LOOP AT it_cknkk INTO wa_cknkk.
**
**    CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'
**      EXPORTING
**        companycode = s_bukrs
**        customer    = wa_cknkk-kunnr
**        keydate     = p_datum-low
**       BALANCESPGLI       = ' '
**       NOTEDITEMS  = ' '
**     IMPORTING
**       RETURN      =
**      TABLES
**        keybalance  = it_balance.
**    LOOP AT it_balance INTO wa_balance.
**
**      IF wa_balance-db_cr_ind = 'S' AND wa_balance-t_curr_bal GT '0.00'.
**        wa_cknkk-ind = 'N'.
**        MODIFY it_cknkk FROM wa_cknkk TRANSPORTING ind.
**        CLEAR: wa_cknkk,wa_balance.
**     ENDIF.
**      ENDLOOP.
**    ENDLOOP.
**
**it_sknkk[] = it_cknkk[].
**
**delete it_sknkk where ind <> 'N'.
*if it_cknkk is not INITIAL.
*
*  SELECT kunnr budat bldat belnr  shkzg
*           blart bukrs dmbtr wrbtr xblnr augdt zfbdt zbd1t FROM bsid INTO TABLE it_sbsid
*                                            FOR ALL ENTRIES IN it_cknkk
*                                                 WHERE bukrs = s_bukrs
*                                                 AND kunnr = it_cknkk-kunnr
*                                                 AND budat LT p_datum-low
*                                                 AND shkzg = 'S'.
*
*  SELECT kunnr budat bldat belnr  shkzg
*           blart bukrs dmbtr wrbtr xblnr augdt zfbdt zbd1t FROM bsad APPENDING TABLE it_sbsid
*                                            FOR ALL ENTRIES IN it_cknkk
*                                                 WHERE bukrs = s_bukrs
*                                                 AND kunnr = it_cknkk-kunnr
*                                                 AND budat LT p_datum-low
*                                                 AND augdt GE p_datum-low
*                                                 AND shkzg = 'S'.
*  ENDIF.
**
*  SORT it_sbsid BY kunnr budat bldat.
*
*  loop at it_sbsid into wa_sbsid.
*
*    wa_sbsid-duedat = wa_sbsid-zfbdt + wa_sbsid-zbd1t.
*
*    READ TABLE it_cknkk into wa_cknkk with key kunnr = wa_sbsid-kunnr.
*    if sy-subrc = 0.
*    wa_sbsid-knkli = wa_cknkk-knkli.
*    endif.
*
*    if wa_sbsid-duedat ge p_datum-low.
*      wa_sbsid-dueind = 'Y'.
*    ENDIF.
*
*    MODIFY it_sbsid from wa_sbsid TRANSPORTING duedat knkli dueind.
*  ENDLOOP.
*
*  it_dsbsid[] = it_sbsid[].
*
*  delete it_dsbsid where dueind <> 'Y'.
*
*  LOOP AT it_sbsid into wa_sbsid.
*
*    READ TABLE it_dsbsid into wa_dsbsid with key knkli = wa_sbsid-knkli.
*    if sy-subrc = 0.
*      wa_sbsid-dueind = 'Y'.
*    endif.
*     MODIFY it_sbsid from wa_sbsid TRANSPORTING dueind.
*  endloop.
*




*  SORT it_hbsid BY kunnr budat bldat.
*
*  LOOP AT it_hbsid INTO wa_hbsid.
*
*    dmbtr = dmbtr + wa_hbsid-dmbtr.
*
*    AT END OF kunnr.
*      wa_hbsid_t-kunnr =  wa_hbsid-kunnr.
*      wa_hbsid_t-dmbtr = dmbtr.
*      APPEND wa_hbsid_t TO it_hbsid_t.
*      CLEAR: dmbtr,wa_hbsid_t.
*    ENDAT.
*    CLEAR wa_hbsid.
*  ENDLOOP.
*
*  data: srno type i.
*  data: v_dmbtr type bsid-dmbtr.
*
*  loop at it_hbsid_t into wa_hbsid_t.
*
*    loop at it_sbsid into wa_sbsid where kunnr = wa_hbsid_t-kunnr.
*
*      srno = srno + 1.
*      IF srno = '1'.
*      v_dmbtr = wa_hbsid_t-dmbtr - wa_sbsid-dmbtr.
*      wa_sbsid-pdmbtr = v_dmbtr.
*      if v_dmbtr le '0.00'.
*        exit.
*       endif.
*      else.
*       wa_sbsid-pdmbtr = v_dmbtr - wa_sbsid-dmbtr.
*       v_dmbtr = wa_sbsid-pdmbtr.
*       if v_dmbtr le '0.00'.
*        exit.
*       endif.
*      endif.
*
*
*
*      MODIFY it_sbsid from wa_sbsid TRANSPORTING pdmbtr.
*      clear: wa_sbsid.
*    endloop.
*
*      clear: wa_hbsid_t,v_dmbtr,srno.
*  endloop.
*
*delete it_sbsid where pdmbtr <> '0.00'.

******************* for days calculation & parent code add

*loop at it_sbsid into wa_sbsid .
*
*   wa_sbsid-days = p_datum-high - wa_sbsid-budat.
*    if wa_sbsid-days gt disc_days.
*
*    READ TABLE it_cknkk into wa_cknkk with key kunnr = wa_sbsid-kunnr.
*    wa_sbsid-knkli = wa_cknkk-knkli.
*    MODIFY it_sbsid from wa_sbsid TRANSPORTING days knkli.
*    clear: wa_sbsid,wa_cknkk.
*    endif.
*
*endloop.
************************* assigned ind for not process for cd.
*  LOOP AT it_cknkk INTO wa_cknkk.
*
*    READ TABLE it_sknkk INTO wa_sknkk WITH KEY knkli = wa_cknkk-knkli.
*    IF sy-subrc = 0.
*      wa_cknkk-ind = 'N'.
*
*      MODIFY it_cknkk FROM wa_cknkk TRANSPORTING ind.
*      CLEAR: wa_sknkk,wa_cknkk.
*    ENDIF.
*  ENDLOOP.

************** delete recode not consider ageing in 3 days
*  LOOP AT s_kunnr.
*
*    READ TABLE it_sbsid INTO wa_sbsid WITH KEY kunnr = s_kunnr-low.
*    IF sy-subrc = 0.
*      IF wa_sbsid-dueind = 'Y'.
*        DELETE TABLE s_kunnr.
*      ENDIF.
*    ENDIF.
*    CLEAR: wa_sbsid.
*  ENDLOOP.

*************
*
*********** end code for ageing calculation

  REFRESH: gt_bsad[],gt_kna1[],gc_rv.

  CLEAR: gc_rv.

  gc_rv-sign = 'I'.
  gc_rv-option = 'EQ'.
  gc_rv-low = 'RV'.
  APPEND gc_rv.
  gc_rv-low = 'UE'.
  APPEND gc_rv.

**** Added changes by Carina Jose on 03.03.2022
  SELECT kunnr,vkorg
    FROM knvv
    INTO TABLE @DATA(it_knvv)
    WHERE kunnr IN @s_kunnr
  AND   vkorg = @p_vkorg.

  IF it_knvv IS NOT INITIAL.
    SELECT bukrs
             kunnr
             augdt
             augbl
             gjahr
             belnr
             budat
             blart
             shkzg
             dmbtr
             vbeln
             xblnr
             bldat
             zuonr
             xref1
        FROM bsad
          INTO TABLE gt_bsad
          FOR ALL ENTRIES IN it_knvv
            WHERE bukrs IN s_bukrs
*              AND kunnr IN s_kunnr
              AND kunnr = it_knvv-kunnr
*              AND budat LE p_datum
              AND budat IN p_datum
    AND blart IN gc_rv.
  ENDIF.

**** End of changes by Carina Jose on 03.03.2022
  "commented below code updated it
*  SELECT bukrs
*         kunnr
*         augdt
*         augbl
*         gjahr
*         belnr
*         budat
*         blart
*         shkzg
*         dmbtr
*         vbeln
*         xblnr
*         bldat
*    FROM bsad
*      INTO TABLE gt_bsad
*        WHERE bukrs IN s_bukrs
*          AND kunnr IN s_kunnr
*          AND budat LE p_datum
*          AND blart IN gc_rv.

  IF sy-subrc EQ 0.
    gt_bsadt[] = gt_bsad[].
    SORT gt_bsadt BY kunnr.
    DELETE ADJACENT DUPLICATES FROM gt_bsadt COMPARING kunnr.
    IF gt_bsadt[] IS NOT INITIAL.
      SELECT kunnr
             name1
         FROM kna1
           INTO TABLE gt_kna1
              FOR ALL ENTRIES IN gt_bsadt
      WHERE kunnr = gt_bsadt-kunnr.
    ENDIF.
    REFRESH gt_bsadt[].
    SELECT bukrs
           kunnr
           augdt
           augbl
           gjahr
           belnr
           budat
           blart
           shkzg
           dmbtr
           vbeln
           xblnr
           bldat
      FROM bsad
        INTO TABLE gt_bsadt
           FOR ALL ENTRIES IN gt_bsad
              WHERE bukrs = gt_bsad-bukrs
                AND kunnr = gt_bsad-kunnr
*                AND belnr = gt_bsad-augbl. "comment by parth 14.03.2022
                AND augbl = gt_bsad-augbl  " added by parth 14.03.2022
                AND augdt = gt_bsad-augdt  " added by parth 14.03.2022
    AND blart IN gc_rv.  " added by parth 14.03.2022
*                AND blart = gc_dz.
  ENDIF.
  SELECT bukrs
         kunnr
         umskz
         gjahr
         belnr
         budat
         blart
         shkzg
         dmbtr
         zterm
         rebzg
         rebzj
         vbeln
    FROM bsid
      INTO TABLE gt_bsid
        FOR ALL ENTRIES IN it_knvv " Added on 03.03.2022
         WHERE bukrs IN s_bukrs
*           AND kunnr IN s_kunnr " Commented on 03.03.2022
           AND kunnr = it_knvv-kunnr " Added on 03.03.2022
*           AND budat LE p_datum
           AND budat IN p_datum
  AND blart IN gc_rv.
  IF sy-subrc EQ 0.
    gt_bsidt[] = gt_bsid[].
    SORT gt_bsidt BY kunnr.
    DELETE ADJACENT DUPLICATES FROM gt_bsidt COMPARING kunnr.
    IF gt_bsidt[] IS NOT INITIAL.
      SELECT kunnr
             name1
         FROM kna1
         APPENDING TABLE gt_kna1
              FOR ALL ENTRIES IN gt_bsidt
      WHERE kunnr = gt_bsidt-kunnr.
      SORT gt_kna1 BY kunnr.
      DELETE ADJACENT DUPLICATES FROM gt_kna1 COMPARING kunnr.
    ENDIF.
    REFRESH gt_bsidt[].
    SELECT bukrs
           kunnr
           umskz
           gjahr
           belnr
           budat
           blart
           shkzg
           dmbtr
           zterm
           rebzg
           rebzj
           vbeln
      FROM bsid
        INTO TABLE gt_bsidt
          FOR ALL ENTRIES IN gt_bsid
           WHERE bukrs IN s_bukrs
*             AND kunnr IN s_kunnr
             AND kunnr = gt_bsid-kunnr " Added by Carina Jose on 03.03.2022
             AND umskz EQ space
             AND blart EQ gc_dz
             AND rebzg = gt_bsid-belnr
    AND rebzj = gt_bsid-gjahr.
  ENDIF.
  SELECT *
    FROM zfi_cash_day_rcl
  INTO TABLE gt_day.

  SELECT *
    FROM knbw
      INTO TABLE gt_knbw
      FOR ALL ENTRIES IN it_knvv
*        WHERE kunnr IN s_kunnr " Commented on 03.03.2022
        WHERE kunnr = it_knvv-kunnr " Added by Carina Jose on 03.03.2022
  AND bukrs IN s_bukrs.
ENDFORM.                    " F_GET_DATA
*&---------------------------------------------------------------------*
*&      Form  F_SET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_set_data .
  SORT gt_kna1 BY  kunnr.
  SORT gt_bsadt BY belnr shkzg .
  SORT gt_day.
*  gt_bsad1[] = gt_bsadt[].
*  refresh : gt_bsadt[].
*  gt_bsadt[] = gt_bsad[].
  gt_bsad1[] = gt_bsadt[].
  REFRESH gt_bsadt[].
  LOOP AT gt_bsad1 INTO wa_bsad.
    COLLECT wa_bsad INTO gt_bsadt.
  ENDLOOP.
**  LOOP AT gt_bsad INTO wa_bsad.
**    DATA: lv_int TYPE dmbtr.
***    wa_final-vbeln = wa_bsad-vbeln.
**    PERFORM f_get_dz_data.
**
**    CLEAR : wa_bsad.
**  ENDLOOP.

  LOOP AT gt_bsad INTO wa_bsad.

    IF wa_bsad-blart = 'UE'.

      DELETE  gt_bsad WHERE xref1 <> 'RV' AND blart = 'UE'.

    ENDIF.
    CLEAR: wa_bsad .
  ENDLOOP.



  gt_uebsad[] = gt_bsad[].

  DELETE gt_uebsad WHERE blart <> 'UE'.

  IF gt_bsad[] IS NOT INITIAL.
    SELECT     sign
               opti
               low
               high INTO TABLE lt_acc_key
                    FROM tvarvc
                    WHERE name = c_var_name AND
    type = c_type_s.

    SELECT * FROM vbrp
             INTO TABLE lt_vbrp
             FOR ALL ENTRIES IN gt_bsad
             WHERE vbeln = gt_bsad-vbeln
               AND werks IN lt_acc_key
    AND prsfd <> 'B'.
*               AND kdgrp_auft <> '11'.


    SELECT * FROM vbrp
             INTO TABLE lt_vbrp1
             FOR ALL ENTRIES IN gt_bsad
             WHERE vbeln = gt_bsad-vbeln
    AND   prsfd <> 'B'.
********************
    SELECT *
    FROM vbrk
     INTO TABLE gt_vbrk
       FOR ALL ENTRIES IN lt_vbrp1
         WHERE vbeln = lt_vbrp1-vbeln
           AND fkart IN ('F2')
           AND fksto = space.
***************
*             AND kdgrp_auft <> '11'.
****************      FOR UE
****************      FOR UE
    IF gt_uebsad[] IS NOT INITIAL.
*      SELECT * FROM vbrp
*             APPENDING  TABLE lt_vbrp1
*             FOR ALL ENTRIES IN gt_uebsad
*             WHERE vbeln = gt_uebsad-xblnr
*      AND   prsfd <> 'B'.
********Added by Manish Paul*******************
      SELECT * FROM zsig_amount
  INTO TABLE gt_zsig_amount
FOR ALL ENTRIES IN gt_uebsad
WHERE invoiceno = gt_uebsad-zuonr
     AND sales_or = p_vkorg.

      IF gt_zsig_amount[] IS NOT INITIAL.
        SELECT kunnr,
               kvgr1,
               kvgr2 FROM knvv
            INTO TABLE @gt_kvgr1_2
              WHERE kunnr IN @s_kunnr.
      ENDIF.
    ENDIF.
*********************************** added 22.03.2022
    SELECT * FROM zsd_on_plant INTO TABLE gt_plant.

    LOOP AT lt_vbrp1 INTO lwa_vbrp1.

      READ TABLE gt_plant INTO wa_plant WITH KEY owerks = lwa_vbrp1-werks.
      IF sy-subrc = 0.
        lwa_vbrp1-werks = wa_plant-nwerks.
*      else.
*      wa_fplant-werks = lwa_vbrp1-werks.
      ENDIF.
      MODIFY lt_vbrp1 FROM lwa_vbrp1 TRANSPORTING werks.
      CLEAR: wa_fplant,lwa_vbrp1.
    ENDLOOP.
*****************************    end 22.03.2022
*****************   added by parth 29/06/2019

    SELECT bukrs kstar gsber kostl
      FROM tka3c
      INTO TABLE it_kostl
      FOR ALL ENTRIES IN it_fplant
        WHERE bukrs IN s_bukrs
        AND   kstar = gc_hkont
    AND   gsber = it_fplant-werks.           " chngs by aarti VSD 26.03.2026           "#EC CI_NOORDER
**************************      ended 29/06/2019

    IF lt_vbrp[] IS NOT INITIAL.
      SORT lt_vbrp[] BY vbeln.
      LOOP AT lt_vbrp INTO lwa_vbrp.
        lv_ki5 = lv_ki5 + lwa_vbrp-kzwi5.
        zkvgr1 = lwa_vbrp-kvgr1.
        zkvgr2 = lwa_vbrp-kvgr2.
        AT END OF vbeln.
          lwa_vbrp-kzwi5 = lv_ki5.
          lwa_vbrp-rrrel = 'Z'.
          lwa_vbrp-kvgr1 = zkvgr1.
          lwa_vbrp-kvgr2 = zkvgr2.

          MODIFY lt_vbrp FROM lwa_vbrp TRANSPORTING kzwi5 rrrel kvgr1 kvgr2.
          CLEAR : lv_ki5,zkvgr1, zkvgr2.
        ENDAT.
      ENDLOOP.
      DELETE lt_vbrp[] WHERE rrrel NE 'Z'.
    ENDIF.
  ENDIF.
  IF lt_vbrp1[] IS NOT INITIAL.
    SORT lt_vbrp1[] BY vbeln.
    LOOP AT lt_vbrp1 INTO lwa_vbrp1.
      READ TABLE gt_vbrk INTO wa_vbrk WITH KEY vbeln = lwa_vbrp1-vbeln.
      IF sy-subrc = 0.
        lv_ki51 = lv_ki51 + lwa_vbrp1-kzwi5. "added by parth
        zkvgr1 = lwa_vbrp1-kvgr1.
        zkvgr2 = lwa_vbrp1-kvgr2.
*      lv_ki51 = lv_ki51 + ( lwa_vbrp1-NETWR + LWA_VBRP1-MWSBP )."comment by parth 16/05/2019
        AT END OF vbeln.
          lwa_vbrp1-kzwi5 = lv_ki51.
          lwa_vbrp1-rrrel = 'Z'.
          lwa_vbrp1-kvgr1 = zkvgr1.
          lwa_vbrp1-kvgr2 = zkvgr2.
          MODIFY lt_vbrp1 FROM lwa_vbrp1 TRANSPORTING kzwi5 rrrel kvgr1 kvgr2.
          CLEAR : lv_ki51,zkvgr2, zkvgr1.
        ENDAT.
      ENDIF.
    ENDLOOP.
    DELETE lt_vbrp1[] WHERE rrrel NE 'Z'.
  ENDIF.

  LOOP AT gt_bsad INTO wa_bsad.
    DATA: lv_int TYPE dmbtr.
*    wa_final-vbeln = wa_bsad-vbeln.
    PERFORM f_get_dz_data.

    CLEAR : wa_bsad.
  ENDLOOP.

*  SORT gt_final[] BY belnr.
*  DELETE ADJACENT DUPLICATES FROM gt_final[] COMPARING belnr.
**  LOOP AT gt_bsid INTO wa_bsid.
**    PERFORM f_get_dz_data_bsid.
**    CLEAR : wa_bsid.
**  ENDLOOP.
  IF gt_final[] IS NOT INITIAL.
    SELECT *
      FROM bsis
        INTO TABLE gt_bsis
          FOR ALL ENTRIES IN gt_final
            WHERE bukrs = gt_final-bukrs
              AND hkont = gc_hkont
    AND blart = gc_dg.

    SELECT *
      FROM vbrk
        INTO TABLE gt_vbrk
          FOR ALL ENTRIES IN gt_final
            WHERE vbeln = gt_final-vbeln
              AND fkart IN ('F2')
              AND fksto = space.

    TYPES: BEGIN OF ty_vbeln,
             sign   TYPE tvarv_sign,
             option TYPE tvarv_opti,
             low    TYPE vbeln,
             high   TYPE vbeln,
           END OF ty_vbeln.
    DATA: lt_vbeln TYPE STANDARD TABLE OF ty_vbeln,
          wa_vbeln TYPE ty_vbeln.
    LOOP AT gt_vbrk INTO wa_vbrk.
      wa_vbeln-sign   = 'I'.
      wa_vbeln-option = 'EQ'.
      wa_vbeln-low    = wa_vbrk-vbeln.
      APPEND wa_vbeln TO lt_vbeln.
      CLEAR: wa_vbeln.
    ENDLOOP.

    SELECT *
        FROM vbrk
          INTO TABLE gt_vbrk4
            FOR ALL ENTRIES IN gt_final
              WHERE vbeln = gt_final-vbeln
                AND fkart = 'F2'
    AND fksto = space.
    LOOP AT gt_vbrk4 INTO wa_vbrk4.
      wa_vbeln-sign   = 'I'.
      wa_vbeln-option = 'EQ'.
      wa_vbeln-low    = wa_vbrk4-vbeln.
      APPEND wa_vbeln TO lt_vbeln.
      CLEAR: wa_vbeln.
    ENDLOOP.
    IF gt_vbrk4[] IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT * FROM konv
*               INTO TABLE lt_konv
*               FOR ALL ENTRIES IN gt_vbrk4
*               WHERE knumv = gt_vbrk4-knumv
*      AND kschl = 'ZPST'.

      " " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
* SELECT * FROM konv
      SELECT * FROM v_konv_cds
      " ATC Correction for S4 HANA **END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
                     INTO TABLE lt_konv
                     FOR ALL ENTRIES IN gt_vbrk4
                     WHERE knumv = gt_vbrk4-knumv
            AND kschl = 'ZPST' ORDER BY PRIMARY KEY .

* End of Quick Fix

      SORT lt_konv[] BY knumv.
      LOOP AT lt_konv INTO lwa_konv.
        lv_kwert = lv_kwert + lwa_konv-kwert.
        AT END OF knumv.
          lwa_konv-kwert = lv_kwert.
          lwa_konv-txjlv = 'X'.
          MODIFY lt_konv FROM lwa_konv TRANSPORTING kwert txjlv.
          CLEAR : lv_kwert.
        ENDAT.
      ENDLOOP.
      DELETE lt_konv[] WHERE txjlv NE 'X'.
    ENDIF.
    IF gt_vbrk[] IS NOT INITIAL.
      SELECT *
        FROM knvv
          INTO TABLE gt_knvv
            FOR ALL ENTRIES IN gt_vbrk
              WHERE kunnr = gt_vbrk-kunag
                AND vkorg = gt_vbrk-vkorg
                AND vtweg = gt_vbrk-vtweg
      AND spart = gt_vbrk-spart.
    ENDIF.
    IF gt_vbrk4[] IS NOT INITIAL.
      SELECT *
        FROM knvv
          APPENDING TABLE gt_knvv
            FOR ALL ENTRIES IN gt_vbrk4
              WHERE kunnr = gt_vbrk4-kunag
                AND vkorg = gt_vbrk4-vkorg
                AND vtweg = gt_vbrk4-vtweg
      AND spart = gt_vbrk4-spart.
    ENDIF.
    IF gt_knvv[] IS NOT INITIAL.
*******      comment by parth 29/06/2019
*      SELECT *
*        FROM zfi_cost
*          INTO TABLE gt_cost
*            FOR ALL ENTRIES IN gt_knvv
*              WHERE vkbur = gt_knvv-vkbur.
*********      ended by parth 29/06/2019
    ENDIF.
    SELECT *
      FROM bkpf
        INTO TABLE gt_bkpf
          FOR ALL ENTRIES IN gt_final
            WHERE bukrs = gt_final-bukrs
              AND blart = gc_dg
              AND tcode = sy-tcode
    AND bstat = 'V'.
    IF gt_bkpf[] IS NOT INITIAL.
      SELECT *
        FROM vbsegs
          INTO TABLE gt_vbsegs
            FOR ALL ENTRIES IN gt_bkpf
              WHERE ausbk = gt_bkpf-bukrs
                AND belnr = gt_bkpf-belnr
                AND gjahr = gt_bkpf-gjahr
                AND bukrs = gt_bkpf-bukrs
      AND saknr = gc_hkont.
    ENDIF.

    LOOP AT gt_final ASSIGNING <fs_final>.
      IF <fs_final>-vbeln IS NOT INITIAL.
        READ TABLE gt_bsis INTO wa_bsis WITH KEY bukrs = <fs_final>-bukrs
                                                 hkont = gc_hkont
                                                 xblnr = <fs_final>-vbeln
                                                 blart = gc_dg.
        IF sy-subrc EQ 0.
*          'Document' v_obj_key+0(10) 'Was successfully posted in company code' v_obj_key+10(4)
          CONCATENATE TEXT-006 "'Document'
                      wa_bsis-belnr
                      TEXT-018 "'was successfully posted in company code'
                      wa_bsis-bukrs INTO <fs_final>-messg SEPARATED BY space.
        ELSE.
          READ TABLE gt_bsis INTO wa_bsis WITH KEY bukrs = <fs_final>-bukrs
                                                   hkont = gc_hkont
                                                   zuonr = <fs_final>-vbeln
                                                   blart = gc_dg.
          IF sy-subrc EQ 0.
*          'Document' v_obj_key+0(10) 'Was successfully posted in company code' v_obj_key+10(4)
            CONCATENATE TEXT-006 "'Document'
                        wa_bsis-belnr
                        TEXT-018 "'was successfully posted in company code'
                        wa_bsis-bukrs INTO <fs_final>-messg SEPARATED BY space.
          ELSE.
            READ TABLE gt_vbsegs INTO wa_vbsegs WITH KEY ausbk = <fs_final>-bukrs
                                                         bukrs = <fs_final>-bukrs
                                                         zuonr = <fs_final>-vbeln
                                                         saknr = gc_hkont.
            IF sy-subrc EQ 0.
              CONCATENATE TEXT-006 "'Document'
                          wa_vbsegs-belnr
                          TEXT-019 "'was successfully Parked in company code'
                          wa_vbsegs-bukrs INTO <fs_final>-messg SEPARATED BY space.
            ELSE.
              READ TABLE gt_bkpf INTO wa_bkpf WITH KEY bukrs = <fs_final>-bukrs
                                                       blart = gc_dg
                                                       tcode = sy-tcode
                                                       xblnr = <fs_final>-vbeln.
              IF sy-subrc EQ 0.
                CONCATENATE TEXT-006 "'Document'
                            wa_bkpf-belnr
                            TEXT-019 "'was successfully Parked in company code'
                            wa_bkpf-bukrs INTO <fs_final>-messg SEPARATED BY space.
              ENDIF.

            ENDIF.

          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.

  LOOP AT gt_final INTO wa_final.
    MOVE-CORRESPONDING wa_final TO wa_final_temp.
    APPEND wa_final_temp TO gt_final_temp.
    CLEAR :wa_final_temp.
  ENDLOOP.

  SORT gt_final_temp BY belnr.
  LOOP AT gt_final_temp INTO wa_final_temp.
    lv_dmbtr = lv_dmbtr + wa_final_temp-dmbtr.
    AT END OF belnr.
      wa_final_temp-dmbtr = lv_dmbtr.
      wa_final_temp-ind = 'X'.
      MODIFY gt_final_temp FROM wa_final_temp TRANSPORTING dmbtr ind.
      CLEAR : wa_final_temp.
    ENDAT.
  ENDLOOP.

  LOOP AT gt_final INTO wa_final.
*    CLEAR : wa_vbrk4.
*    READ TABLE gt_vbrk4 INTO wa_vbrk4 WITH KEY vbeln = wa_final-vbeln.
*    IF sy-subrc EQ 0.
*      CLEAR : lwa_konv.
*      READ TABLE lt_konv INTO lwa_konv WITH KEY knumv = wa_vbrk4-knumv.
*      IF sy-subrc EQ 0.
*        wa_final-dmbtr = lwa_konv-kwert.
*
*        CLEAR : wa_day.
*       READ TABLE gt_day INTO wa_day WITH KEY zzdayd = wa_final-nodays ZKVGR1 = wa_final-zkvgr1 zkvgr2 = wa_final-zkvgr2 .
*        IF sy-subrc EQ 0.
*          wa_final-zzint = wa_final-dmbtr * ( wa_day-zzperc / 100 ).
*        ENDIF.
*      ENDIF.
*    ENDIF.

    CLEAR : wa_final_temp.
    READ TABLE gt_final_temp INTO wa_final_temp WITH KEY belnr = wa_final-belnr dmbtr = '0' ind = 'X' .
    IF sy-subrc EQ 0.
      wa_final-dmbtr = '0'.
    ENDIF.


* Quick Fix Add type conversion
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    CALL FUNCTION 'J_1I6_ROUND_TO_NEAREST_AMT'
*      EXPORTING
*        i_amount = wa_final-zzint
*      IMPORTING
*        e_amount = wa_final-zzint.

    DATA l_1065_2 TYPE j_1itaxvar-j_1itaxam1.
    l_1065_2 = wa_final-zzint.
    DATA l_1065_1 TYPE j_1itaxvar-j_1itaxam1.
    l_1065_1 = wa_final-zzint.
    CALL FUNCTION 'J_1I6_ROUND_TO_NEAREST_AMT'
      EXPORTING
        i_amount = l_1065_1
      IMPORTING
        e_amount = l_1065_2.
    wa_final-zzint = l_1065_2.

* End of Quick Fix


    MODIFY gt_final FROM wa_final TRANSPORTING dmbtr zzint.
  ENDLOOP.
  DELETE gt_final WHERE dmbtr = '0.00'.
  DELETE gt_final WHERE dmbtr <= '0.00'.
  PERFORM auto_post.
********  Added on 03.06.2015
**  IF gt_final[] IS NOT INITIAL.
**    SELECT     sign
**               opti
**               low
**               high INTO TABLE lt_acc_key
**                    FROM tvarvc
**                    WHERE name = c_var_name AND
**                          type = c_type_s.
**
**    SELECT * FROM vbrp
**             INTO TABLE lt_vbrp
**             FOR ALL ENTRIES IN gt_final
**             WHERE vbeln = gt_final-vbeln
**               AND werks IN lt_acc_key.
**    IF lt_vbrp[] IS NOT INITIAL.
**      SORT lt_vbrp[] BY vbeln.
**      LOOP AT lt_vbrp INTO lwa_vbrp.
**        lv_ki5 = lv_ki5 + lwa_vbrp-kzwi5.
**        AT END OF vbeln.
**          lwa_vbrp-kzwi5 = lv_ki5.
**          lwa_vbrp-rrrel = 'Z'.
**          MODIFY lt_vbrp FROM lwa_vbrp TRANSPORTING kzwi5 rrrel.
**          CLEAR : lv_ki5.
**        ENDAT.
**      ENDLOOP.
**      DELETE lt_vbrp[] WHERE rrrel NE 'Z'.
**      LOOP AT gt_final INTO wa_final.
**        CLEAR : lwa_vbrp.
**        READ TABLE lt_vbrp INTO lwa_vbrp WITH KEY vbeln = wa_final-vbeln.
**        IF sy-subrc EQ 0.
**          wa_final-dmbtr = ( lwa_vbrp-kzwi5 * 100 ) / ( 11236 / 100 ).
**          MODIFY gt_final FROM wa_final TRANSPORTING dmbtr.
**        ENDIF.
**      ENDLOOP.
**    ENDIF.
**  ENDIF.
ENDFORM.                    " F_SET_DATA
*&---------------------------------------------------------------------*
*&      Form  F_ALV_FCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_alv_fcat .
  PERFORM build_fieldcat USING 'BUKRS'  TEXT-002 'X'.
  PERFORM build_fieldcat USING 'KUNNR'  TEXT-003 'X'.
  PERFORM build_fieldcat USING 'NAME1'  TEXT-004 ' '.
  PERFORM build_fieldcat USING 'VBELN'  TEXT-005 ' '.
  PERFORM build_fieldcat USING 'XBLNR'  TEXT-027 ' '.
*  PERFORM build_fieldcat USING 'XREF1'  TEXT-028 ' '.
  PERFORM build_fieldcat USING 'FBLNR'  TEXT-014 ' '.
  PERFORM build_fieldcat USING 'FBLRT'  TEXT-007 ' '.
  PERFORM build_fieldcat USING 'FBDAT'  TEXT-008 ' '.
  PERFORM build_fieldcat USING 'BELNR'  TEXT-006 ' '.
  PERFORM build_fieldcat USING 'BLART'  TEXT-007 ' '.
  PERFORM build_fieldcat USING 'BUDAT'  TEXT-022 ' '.
  PERFORM build_fieldcat USING 'BLDAT'  TEXT-024 ' '.
  PERFORM build_fieldcat USING 'ZZDAYD' TEXT-009 ' '.
  PERFORM build_fieldcat USING 'ZKVGR1' TEXT-023 ' '.
  PERFORM build_fieldcat USING 'ZKVGR2' TEXT-025 ' '.
  PERFORM build_fieldcat USING 'DESC' TEXT-026 ' '.
  PERFORM build_fieldcat USING 'ZZPERC' TEXT-015 ' '.
  PERFORM build_fieldcat USING 'DMBTR'  TEXT-010 ' '.
  PERFORM build_fieldcat USING 'ZZINT'  TEXT-011 ' '.
  PERFORM build_fieldcat USING 'MESSG'  TEXT-016 ' '.

ENDFORM.                    " F_ALV_FCAT
*&---------------------------------------------------------------------*
*&      Form  F_ALV_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_alv_layout .
  wa_layout-colwidth_optimize = 'X'. "optimizes the column width
  wa_layout-zebra = 'X'.             "output in the striped pattern
  wa_layout-box_fieldname = 'SEL'.
  wa_layout-box_tabname   = 'GT_FINAL'.

  wa_sort-fieldname = 'KUNNR'.
  wa_sort-tabname = 'GT_FINAL'.
  wa_sort-up = 'X'.
  wa_sort-subtot = 'X'.
  APPEND wa_sort TO gt_sort .
ENDFORM.                    " F_ALV_LAYOUT
*&---------------------------------------------------------------------*
*&      Form  F_ALV_DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_alv_display .

  DATA: ls_variant TYPE disvariant.
  ls_variant-report = sy-repid.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS'
      i_callback_user_command  = 'USER_COMMAND'
      i_grid_title             = TEXT-013
      is_layout                = wa_layout
      it_fieldcat              = gt_fcat
      it_sort                  = gt_sort
      i_save                   = 'A'          " Allow both Global and User-specific saves
      is_variant               = ls_variant
    TABLES
      t_outtab                 = gt_final
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
    MESSAGE 'Error In ALV Display' TYPE 'E'.
  ENDIF.

ENDFORM.                    " F_ALV_DISPLAY
*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0539   text
*      -->P_TEXT_001  text
*      -->P_0541   text
*----------------------------------------------------------------------*
FORM build_fieldcat USING lv_fieldname TYPE slis_fieldname
                          lv_seltext_l TYPE any
                          lv_fix_column TYPE any.
  wa_fcat-fieldname = lv_fieldname.
  wa_fcat-seltext_l = lv_seltext_l.
  wa_fcat-fix_column = lv_fix_column.
  IF lv_fieldname = 'DMBTR' OR lv_fieldname = 'ZZINT'.
    wa_fcat-do_sum = 'X'.
  ENDIF.
  APPEND wa_fcat TO gt_fcat.
  CLEAR wa_fcat.
ENDFORM. " BUILD_FIELDCAT
*&---------------------------------------------------------------------*
*&      Form  F_GET_DZ_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_dz_data .

  SELECT * FROM tvv2t INTO TABLE @DATA(it_tvv2t).

  DATA: lv_int TYPE dmbtr.
*  LOOP AT gt_bsad INTO wa_bsad ."WHERE belnr = wa_bsad-augbl.
  CLEAR : wa_bsadt.
*  READ TABLE gt_bsadt INTO wa_bsadt WITH KEY belnr = wa_bsad-augbl ."BINARY SEARCH. "Comment by parth 14.03.2022
  READ TABLE gt_bsadt INTO wa_bsadt WITH KEY augbl = wa_bsad-augbl ."BINARY SEARCH.  "added by parth 14.03.2022
*  READ TABLE gt_bsadt INTO wa_bsadt WITH KEY belnr = wa_bsad-belnr ."BINARY SEARCH.

  wa_final-bukrs = wa_bsad-bukrs.
  wa_final-kunnr = wa_bsad-kunnr.
  wa_final-xblnr = wa_bsad-xblnr.
  IF wa_bsad-vbeln IS NOT INITIAL.
    wa_final-vbeln = wa_bsad-vbeln.
  ELSE.
*    wa_final-vbeln = wa_bsad-xblnr.
    wa_final-vbeln = wa_bsad-zuonr.
    CONCATENATE '' wa_bsad-zuonr+0(4) INTO wa_final-werks.
    CONDENSE wa_final-werks.
  ENDIF.

  wa_final-fblnr = wa_bsad-belnr.
  wa_final-fblrt = wa_bsad-blart.
  wa_final-fbdat = wa_bsad-budat.
  wa_final-bldat = wa_bsad-bldat.
  READ TABLE gt_kna1 INTO wa_kna1 WITH KEY kunnr = wa_bsad-kunnr
                                           BINARY SEARCH.
  IF sy-subrc = 0.
    wa_final-name1 = wa_kna1-name1.
  ENDIF.
***** DZ Document
  wa_final-belnr = wa_bsadt-belnr.
  wa_final-blart = wa_bsadt-blart.
*  gv_datum = wa_bsadt-budat - wa_bsad-budat."comment by parth 17/08/2019
  IF wa_bsad-blart = 'UE'. "ADDED 22.02.2022
    gv_datum = wa_bsadt-augdt - wa_bsad-bldat. "ADDED 22.02.2022
  ELSE.
    gv_datum = wa_bsadt-augdt - wa_bsad-budat. " added by parth 17/08/2019
  ENDIF.

*  IF gv_datum LT 3.
*    gv_datum = 3.
*  ENDIF.
  wa_final-nodays = gv_datum.
  CLEAR : lwa_vbrp.
  READ TABLE lt_vbrp INTO lwa_vbrp WITH KEY vbeln = wa_bsad-vbeln.
  IF sy-subrc EQ 0.
*    wa_final-dmbtr = ( lwa_vbrp-kzwi5 * 100 ) / ( 11236 / 100 ).
    lv_findmbtr = ( lwa_vbrp-kzwi5 * 100 ) / ( 11250 / 100 ).
*    MODIFY gt_final FROM wa_final TRANSPORTING dmbtr.
  ELSE.
    CLEAR : lwa_vbrp1.
    READ TABLE lt_vbrp1 INTO lwa_vbrp1 WITH KEY vbeln = wa_bsad-vbeln.
    IF sy-subrc EQ 0.
      lv_findmbtr = lwa_vbrp1-kzwi5.
      wa_final-zkvgr1  = lwa_vbrp1-kvgr1.
      wa_final-zkvgr2  = lwa_vbrp1-kvgr2.
      wa_final-werks  = lwa_vbrp1-werks.
    ELSE.
      READ TABLE lt_vbrp1 INTO lwa_vbrp1 WITH KEY vbeln = wa_bsad-xblnr.
      IF sy-subrc EQ 0.
        lv_findmbtr = lwa_vbrp1-kzwi5.
        wa_final-zkvgr1  = lwa_vbrp1-kvgr1.
        wa_final-zkvgr2 = lwa_vbrp1-kvgr2.
        wa_final-werks  = lwa_vbrp1-werks.
      ENDIF.
    ENDIF.

*****************Added by Manish Paul********************************

    READ TABLE gt_zsig_amount INTO gs_zsig_amount WITH KEY invoiceno = wa_bsad-zuonr.
    IF sy-subrc = 0.
      lv_findmbtr = gs_zsig_amount-gl_amount.
      READ TABLE gt_kvgr1_2 INTO gs_kvgr1_2 WITH KEY kunnr = wa_bsad-kunnr.
      IF sy-subrc = 0.
        wa_final-zkvgr1  = gs_kvgr1_2-kvgr1.
        wa_final-zkvgr2  = gs_kvgr1_2-kvgr2.
      ENDIF.
    ENDIF.

  ENDIF.
**  IF lv_findmbtr IS INITIAL.
**    CLEAR : wa_vbrp4.
**    READ TABLE gt_vbrp4 INTO wa_vbrp4 WITH KEY vbeln = wa_bsad-vbeln.
**    IF sy-subrc EQ 0.
**      CLEAR : lwa_konv.
**      READ TABLE lt_konv INTO lwa_konv WITH KEY knumv = wa_vbrp4-knumv.
**      IF sy-subrc EQ 0.
**        lv_findmbtr = lwa_konv-kwert.
**      ENDIF.
**    ENDIF.
**  ENDIF.
  IF wa_bsad-blart = 'UE'.
    READ TABLE gt_day INTO wa_day WITH KEY zzdayd = gv_datum zkvgr1 = wa_final-zkvgr1 zkvgr2 = wa_final-zkvgr2.
  ELSE.
    READ TABLE gt_day INTO wa_day WITH KEY zzdayd = gv_datum zkvgr1 = lwa_vbrp1-kvgr1 zkvgr2 = lwa_vbrp1-kvgr2.
  ENDIF.

  IF sy-subrc EQ 0.
    IF lv_findmbtr IS NOT INITIAL.
      IF wa_bsadt-dmbtr LE lv_findmbtr.
*        PERFORM f_calc_cash USING wa_bsadt-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "COMMENT BY PARTH 17.08.2019
        PERFORM f_calc_cash USING wa_bsadt-augdt lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "ADDE BY PARTH 17.08.2019
*        PERFORM f_calc_cash USING wa_bsad-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int.
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ELSE.
*        PERFORM f_calc_cash USING wa_bsadt-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int.""COMMENT BY PARTH 17.08.2019
        PERFORM f_calc_cash USING wa_bsadt-augdt lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "ADDE BY PARTH 17.08.2019
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ENDIF.
    ELSE.
*******start change on 17/12/2025*****
      DATA lv_dmbtr1 TYPE dmbtr.
*******End change on 17/12/2025*****
      IF wa_bsadt-dmbtr LE lwa_vbrp-kzwi5.
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr wa_bsad-shkzg CHANGING lv_int.
*        PERFORM f_calc_cash USING wa_bsad-budat lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int.""COMMENT BY PARTH 17.08.2019
*******start change on 17/12/2025*****
*        PERFORM f_calc_cash USING wa_bsad-augdt lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int.""ADDED BY PARTH 17.08.2019
        CLEAR lv_dmbtr1.
        lv_dmbtr1 = CONV dmbtr( lwa_vbrp-kzwi5 ).
        PERFORM f_calc_cash USING wa_bsad-augdt lv_dmbtr1  wa_bsad-shkzg CHANGING lv_int.""ADDED BY PARTH 17.08.2019
*******End change on 17/12/2025*****
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ELSE.
*        PERFORM f_calc_cash USING wa_bsadt-budat lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int." "COMMENT BY PARTH 17.08.2019
*******start change on 17/12/2025*****
*        PERFORM f_calc_cash USING wa_bsadt-augdt lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int. ""ADDED BY PARTH 17.08.2019
        CLEAR lv_dmbtr.
        lv_dmbtr1 = CONV dmbtr( lwa_vbrp-kzwi5 ).
        PERFORM f_calc_cash USING wa_bsadt-augdt lv_dmbtr1 wa_bsad-shkzg CHANGING lv_int. ""ADDED BY PARTH 17.08.2019
*******End change on 17/12/2025*****
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ENDIF.

*      IF wa_bsadt-dmbtr LE wa_bsad-dmbtr.
**      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr wa_bsad-shkzg CHANGING lv_int.
*        PERFORM f_calc_cash USING wa_bsad-budat wa_bsad-dmbtr wa_bsad-shkzg CHANGING lv_int.
**      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr CHANGING lv_int.
*        wa_final-zzint = lv_int.
*      ELSE.
*        PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr wa_bsad-shkzg CHANGING lv_int.
**      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr CHANGING lv_int.
*        wa_final-zzint = lv_int.
*      ENDIF.
    ENDIF.
**************************    for other then maintain table 20.03.2021
  ELSE .
    READ TABLE gt_day INTO wa_day WITH KEY zzdayd = gv_datum zkvgr1  = ' ' zkvgr2  = ' ' .
    IF sy-subrc = 0.
      IF lv_findmbtr IS NOT INITIAL.
        IF wa_bsadt-dmbtr LE lv_findmbtr.
*        PERFORM f_calc_cash USING wa_bsadt-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "COMMENT BY PARTH 17.08.2019
          PERFORM f_calc_cash USING wa_bsadt-augdt lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "ADDE BY PARTH 17.08.2019
*        PERFORM f_calc_cash USING wa_bsad-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int.
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr CHANGING lv_int.
          wa_final-zzint = lv_int.
        ELSE.
*        PERFORM f_calc_cash USING wa_bsadt-budat lv_findmbtr wa_bsad-shkzg CHANGING lv_int.""COMMENT BY PARTH 17.08.2019
          PERFORM f_calc_cash USING wa_bsadt-augdt lv_findmbtr wa_bsad-shkzg CHANGING lv_int. "ADDE BY PARTH 17.08.2019
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr CHANGING lv_int.
          wa_final-zzint = lv_int.
        ENDIF.
      ELSE.
        IF wa_bsadt-dmbtr LE lwa_vbrp-kzwi5.
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr wa_bsad-shkzg CHANGING lv_int.
*        PERFORM f_calc_cash USING wa_bsad-budat lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int.""COMMENT BY PARTH 17.08.2019
*******start change on 17/12/2025*****
          CLEAR lv_dmbtr1.
          lv_dmbtr1 = CONV dmbtr( lwa_vbrp-kzwi5 ).
*          PERFORM f_calc_cash USING wa_bsad-augdt lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int.""ADDED BY PARTH 17.08.2019
          PERFORM f_calc_cash USING wa_bsad-augdt lv_dmbtr1 wa_bsad-shkzg CHANGING lv_int.""ADDED BY PARTH 17.08.2019
*******End change on 17/12/2025*****
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsadt-dmbtr CHANGING lv_int.
          wa_final-zzint = lv_int.
        ELSE.
*        PERFORM f_calc_cash USING wa_bsadt-budat lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int." "COMMENT BY PARTH 17.08.2019
*******start change on 17/12/2025*****
          CLEAR lv_dmbtr1.
          lv_dmbtr1 = CONV dmbtr( lwa_vbrp-kzwi5 ).
*          PERFORM f_calc_cash USING wa_bsadt-augdt lwa_vbrp-kzwi5 wa_bsad-shkzg CHANGING lv_int. ""ADDED BY PARTH 17.08.2019
          PERFORM f_calc_cash USING wa_bsadt-augdt lv_dmbtr1 wa_bsad-shkzg CHANGING lv_int. ""ADDED BY PARTH 17.08.2019
*******End change on 17/12/2025*****
*      PERFORM f_calc_cash USING wa_bsadt-budat wa_bsad-dmbtr CHANGING lv_int.
          wa_final-zzint = lv_int.
        ENDIF.

*
      ENDIF.
    ENDIF.

**************


  ENDIF.

  wa_final-zzperc = wa_day-zzperc.
  wa_final-zzdayd = wa_day-zzdayd.

  IF wa_final-zzdayd IS INITIAL.
    wa_final-zzdayd = gv_datum.
  ENDIF.
  IF wa_final-budat IS INITIAL.
    wa_final-budat = wa_bsad-augdt.
  ENDIF.

  READ TABLE it_tvv2t INTO DATA(wa_tvv2t) WITH KEY kvgr2 = wa_final-zkvgr2.

  IF sy-subrc = 0.
    wa_final-desc = wa_tvv2t-bezei.
  ENDIF.

  APPEND wa_final TO gt_final.
  CLEAR: wa_final,gv_datum,wa_day,lv_int,lv_findmbtr.
*  ENDLOOP.

    ""start of change from Ranjan
  SELECT * FROM zsd_on_plant INTO TABLE gt_plant.

  LOOP AT gt_final INTO wa_final.

    READ TABLE gt_plant INTO wa_plant WITH KEY owerks = wa_final-werks.
    IF sy-subrc = 0.
      wa_final-werks = wa_plant-nwerks.
    ENDIF.
    MODIFY gt_final FROM wa_final TRANSPORTING werks.
    CLEAR: wa_plant,wa_final.
  ENDLOOP.
  ""End of change by Ranjan

ENDFORM.                    " F_GET_DZ_DATA
*&---------------------------------------------------------------------*
*&      Form  F_CALC_CASH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_WA_BSADT_DMBTR  text
*      <--P_LV_INT  text
*----------------------------------------------------------------------*
FORM f_calc_cash  USING    p_date  TYPE datum
                           p_dmbtr TYPE dmbtr
                           p_shkzg TYPE shkzg
                  CHANGING p_int.
  IF p_shkzg = 'H'.
    p_dmbtr = p_dmbtr * ( -1 ).
  ENDIF.
  wa_final-budat = p_date.
  wa_final-dmbtr = p_dmbtr.

  p_int = p_int + ( p_dmbtr * ( wa_day-zzperc / 100 ) ).
ENDFORM.                    " F_CALC_CASH
*&---------------------------------------------------------------------*
*&      Form  F_GET_DZ_DATA_BSID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_dz_data_bsid .
  DATA: lv_int TYPE dmbtr.
  LOOP AT gt_bsidt INTO wa_bsidt WHERE rebzg = wa_bsid-belnr
                                   AND rebzj = wa_bsid-gjahr.
    wa_final-bukrs = wa_bsid-bukrs.
    wa_final-kunnr = wa_bsid-kunnr.
    wa_final-vbeln = wa_bsid-vbeln.
    wa_final-fblnr = wa_bsid-belnr.
    wa_final-fblrt = wa_bsid-blart.
    wa_final-fbdat = wa_bsid-budat.
    READ TABLE gt_kna1 INTO wa_kna1 WITH KEY kunnr = wa_bsid-kunnr
                                             BINARY SEARCH.
    IF sy-subrc = 0.
      wa_final-name1 = wa_kna1-name1.
    ENDIF.

***** DZ Document
    wa_final-belnr = wa_bsidt-belnr.
    wa_final-blart = wa_bsidt-blart.
    gv_datum = wa_bsidt-budat - wa_bsid-budat.
    READ TABLE gt_day INTO wa_day WITH KEY zzdayd = gv_datum.
    IF sy-subrc EQ 0.
      IF wa_bsidt-dmbtr LE wa_bsid-dmbtr.
        PERFORM f_calc_cash USING wa_bsidt-budat wa_bsidt-dmbtr wa_bsidt-shkzg CHANGING lv_int.
*        PERFORM f_calc_cash USING wa_bsidt-budat wa_bsidt-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ELSE.
        PERFORM f_calc_cash USING wa_bsidt-budat wa_bsid-dmbtr wa_bsidt-shkzg CHANGING lv_int.
*        PERFORM f_calc_cash USING wa_bsidt-budat wa_bsid-dmbtr CHANGING lv_int.
        wa_final-zzint = lv_int.
      ENDIF.
      wa_final-zzperc = wa_day-zzperc.
      wa_final-zzdayd = wa_day-zzdayd.
      APPEND wa_final TO gt_final.
    ENDIF.
    CLEAR: wa_final,gv_datum,wa_day,lv_int.

  ENDLOOP.

ENDFORM.                    " F_GET_DZ_DATA_BSID
FORM user_command USING p_ucomm TYPE sy-ucomm
                        wa_selfield TYPE slis_selfield.
  p_ucomm = sy-ucomm.
  CASE p_ucomm.
*    WHEN 'FB75'.
*      REFRESH: gt_bdc[].
*      CLEAR wa_bdc.
*      CLEAR gv_tabix.
*      LOOP AT gt_final ASSIGNING <fs_final> WHERE sel = 'X' AND messg IS INITIAL.
*        gv_tabix = sy-tabix.
*        wa_bdc-bukrs = <fs_final>-bukrs.
*        wa_bdc-accnt = <fs_final>-kunnr.
*        CONDENSE wa_bdc-accnt.
*        PERFORM f_date_external USING sy-datum CHANGING wa_bdc-bldat.
*        wa_bdc-wrbtr = <fs_final>-zzint.
*        CONDENSE wa_bdc-wrbtr.
*        wa_bdc-xblnr = <fs_final>-vbeln.
*        wa_bdc-hkont = gc_hkont.
*        PERFORM f_get_cost_center USING <fs_final>.
*        IF wa_bdc-kostl IS INITIAL.
*          <fs_final>-messg = text-017." 'Cost Center Does not exist'.
*          CONTINUE.
*        ENDIF.
**        wa_bdc-kostl = '1600311004'.
*        wa_bdc-wrbt1 = <fs_final>-zzint.
*        APPEND wa_bdc TO gt_bdc.
*        PERFORM f_bapi_fb75.
*        REFRESH gt_bdc[].
**        PERFORM f_post_fb75 USING wa_bdc.
*        CLEAR : wa_bdc.
*      ENDLOOP.
*    WHEN 'FB75A'.
*      PERFORM f_get_bdc.
*      PERFORM f_get_aggregate.
*      CLEAR gv_tabix.
*      PERFORM f_post_fb75a .
    WHEN 'CANC'.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT'.
      LEAVE PROGRAM.
  ENDCASE.
*  PERFORM f_alv_display.
ENDFORM.
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
*  IF FVAL <> NODATA.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
*  ENDIF.
ENDFORM. "BDC_FIELD

FORM pf_status USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'PF_STATUS'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  F_POST_FB75
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_post_fb75 USING wa_bdc LIKE LINE OF gt_bdc.
  REFRESH bdcdata[].
*  PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
*  PERFORM bdc_field       USING 'BDC_OKCODE'
*                                '/ECCDE'.
*
*  PERFORM bdc_dynpro      USING 'SAPLACHD' '1000'.
*  PERFORM bdc_field       USING 'BDC_OKCODE'
*                                '=ENTR'.
*  PERFORM bdc_field       USING 'BKPF-BUKRS'
*                                wa_bdc-bukrs.
  PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.
  PERFORM bdc_field       USING 'RF05A-BUSCS'
                                'G'.

  PERFORM bdc_field       USING 'INVFO-ACCNT'
                                wa_bdc-accnt.
  PERFORM bdc_field       USING 'INVFO-BLDAT'
                                wa_bdc-bldat.
  PERFORM bdc_field       USING 'INVFO-XBLNR'
                                wa_bdc-xblnr.
  PERFORM bdc_field       USING 'INVFO-WRBTR'
                                wa_bdc-wrbtr.
  PERFORM bdc_field       USING 'ACGL_ITEM-HKONT(01)'
                                wa_bdc-hkont.
  PERFORM bdc_field       USING 'ACGL_ITEM-WRBTR(01)'
                                '*'.
  PERFORM bdc_field       USING 'ACGL_ITEM-KOSTL(01)'
                                wa_bdc-kostl.

  PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BU'.
  params-dismode = 'A'.
  params-updmode = 'S'.
  params-defsize = 'X'.
*  params-nobinpt = 'X'.
  CALL TRANSACTION 'FB75' USING bdcdata OPTIONS FROM params
                                 MESSAGES INTO gt_msgtype  ." MODE MOd UPDATE upd.
  IF gt_msgtype[] IS NOT INITIAL.
    READ TABLE gt_msgtype WITH KEY msgtyp = 'S'
                                   msgid  = 'F5'
                                   msgnr  = '312'.
    IF sy-subrc EQ 0.
      CLEAR lv_msg.
      CALL FUNCTION 'FORMAT_MESSAGE'
        EXPORTING
          id        = gt_msgtype-msgid
          lang      = sy-langu
          no        = gt_msgtype-msgnr
          v1        = gt_msgtype-msgv1
          v2        = gt_msgtype-msgv2
          v3        = gt_msgtype-msgv3
          v4        = gt_msgtype-msgv4
        IMPORTING
          msg       = lv_msg
        EXCEPTIONS
          not_found = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.
      CONCATENATE wa_final-messg lv_msg INTO wa_final-messg.
    ELSE.
      LOOP AT gt_msgtype.
        CLEAR lv_msg.
        CALL FUNCTION 'FORMAT_MESSAGE'
          EXPORTING
            id        = gt_msgtype-msgid
            lang      = sy-langu
            no        = gt_msgtype-msgnr
            v1        = gt_msgtype-msgv1
            v2        = gt_msgtype-msgv2
            v3        = gt_msgtype-msgv3
            v4        = gt_msgtype-msgv4
          IMPORTING
            msg       = lv_msg
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ENDIF.
        CONCATENATE wa_final-messg lv_msg INTO wa_final-messg.
      ENDLOOP.
    ENDIF.
    IF gv_tabix IS NOT INITIAL.

      MODIFY gt_final INDEX gv_tabix FROM wa_final
                      TRANSPORTING messg.
    ENDIF.
  ENDIF.
ENDFORM.                    " F_POST_FB75
*&---------------------------------------------------------------------*
*&      Form  F_DATE_EXTERNAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_SY_DATUM  text
*      <--P_WA_BDC_BLDAT  text
*----------------------------------------------------------------------*
FORM f_date_external  USING    p_int
                      CHANGING p_ext.
  CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
    EXPORTING
      date_internal = p_int
    IMPORTING
      date_external = p_ext.

ENDFORM.                    " F_DATE_EXTERNAL
*&---------------------------------------------------------------------*
*&      Form  F_GET_BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_bdc .
  LOOP AT gt_final INTO wa_final WHERE sel = 'X' .
    PERFORM f_get_sel_mark.
  ENDLOOP.
  LOOP AT gt_final INTO wa_final1 WHERE sel = 'X'.
    gv_tabix = sy-tabix.
    wa_final = wa_final1.
*    AT NEW kunnr.
*    ENDAT.
    lv_amt = lv_amt + wa_final-zzint.
    AT END OF kunnr.
      wa_bdc-accnt = wa_final-kunnr.
      CONDENSE wa_bdc-accnt.
      PERFORM f_date_external USING sy-datum CHANGING wa_bdc-bldat.
*      wa_bdc-xblnr = wa_final-belnr.
*        wa_bdc-kostl = '1600311004'.
      PERFORM f_get_cost_center USING wa_final.
      wa_bdc-hkont = gc_hkont."'62130101'.
*      wa_bdc-kostl = '1600311004'.
      wa_bdc-wrbt1 = '*'.
*      PERFORM f_date_external USING sy-datum CHANGING wa_bdc-zfbdt.
      IF wa_bdc-kostl IS INITIAL.
        wa_final-messg = 'Cost Center Does not exist'.
        MODIFY gt_final FROM wa_final INDEX gv_tabix.
        EXIT.
      ENDIF.
      wa_bdc-wrbtr = lv_amt.
      CONDENSE wa_bdc-wrbtr.
      APPEND wa_bdc TO gt_bdc.
      CLEAR: wa_bdc,lv_amt.
    ENDAT.
  ENDLOOP.
ENDFORM.                    " F_GET_BDC
*&---------------------------------------------------------------------*
*&      Form  F_GET_SEL_MARK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_sel_mark .
  LOOP AT gt_final ASSIGNING <fs_final> WHERE kunnr = wa_final-kunnr
                                          AND sel IS INITIAL AND messg IS INITIAL.
    <fs_final>-sel = 'X'.

  ENDLOOP.
  LOOP AT gt_final ASSIGNING <fs_final> WHERE messg IS NOT INITIAL AND sel IS NOT INITIAL .
    <fs_final>-sel = ''.

  ENDLOOP.
ENDFORM.                    " F_GET_SEL_MARK
*&---------------------------------------------------------------------*
*&      Form  F_GET_COST_CENTER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_cost_center USING p_final LIKE LINE OF gt_final.
  READ TABLE gt_vbrk INTO wa_vbrk WITH KEY vbeln = p_final-vbeln.
  IF sy-subrc EQ 0.
    READ TABLE gt_knvv INTO wa_knvv WITH KEY kunnr = wa_vbrk-kunag
                                             vkorg = wa_vbrk-vkorg
                                             vtweg = wa_vbrk-vtweg
                                             spart = wa_vbrk-spart.
    IF sy-subrc EQ 0.
      READ TABLE lt_vbrp1 INTO lwa_vbrp1 WITH KEY vbeln = p_final-vbeln.
      IF sy-subrc EQ 0.
        READ TABLE it_kostl INTO wa_kostl WITH KEY kstar = gc_hkont gsber = lwa_vbrp1-werks. " chngs by aarti VSD 26.03.2026
        IF sy-subrc EQ 0.
          wa_bdc-kostl = wa_kostl-kostl.
        ENDIF.
      ENDIF.
*******       commetn by parth 29/06/2019
*      READ TABLE gt_cost INTO wa_cost WITH KEY vkbur = wa_knvv-vkbur.
*      IF sy-subrc EQ 0.
*        wa_bdc-kostl = wa_cost-kostl.
*      ENDIF.
************       end by parth 29/06/2019
    ENDIF.
  ELSE.
    READ TABLE gt_vbrk4 INTO wa_vbrk4 WITH KEY vbeln = p_final-vbeln.
    IF sy-subrc EQ 0.
      READ TABLE gt_knvv INTO wa_knvv WITH KEY kunnr = wa_vbrk4-kunag
                                               vkorg = wa_vbrk4-vkorg
                                               vtweg = wa_vbrk4-vtweg
                                              spart = wa_vbrk4-spart.
*********      comment by parth 29/06/2019
*      IF sy-subrc EQ 0.
*        READ TABLE gt_cost INTO wa_cost WITH KEY vkbur = wa_knvv-vkbur.
*        IF sy-subrc EQ 0.
*          wa_bdc-kostl = wa_cost-kostl.
*        ENDIF.
*      ENDIF.
**********      end by parth 29/062019
      IF sy-subrc EQ 0.
        READ TABLE lt_vbrp1 INTO lwa_vbrp1 WITH KEY vbeln = p_final-vbeln.
        IF sy-subrc EQ 0.
          READ TABLE it_kostl INTO wa_kostl WITH KEY kstar = gc_hkont gsber = lwa_vbrp1-werks. " chngs by aarti VSD 26.03.2026
          IF sy-subrc EQ 0.
            wa_bdc-kostl = wa_kostl-kostl.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

*********************Added by Manish Paul***********************

  IF wa_bdc-kostl IS INITIAL.
    READ TABLE it_kostl INTO wa_kostl WITH KEY kstar = gc_hkont gsber = p_final-werks. " chngs by aarti VSD 26.03.2026
    wa_bdc-kostl = wa_kostl-kostl.

    IF sy-subrc <> 0.

      SELECT SINGLE nwerks
        FROM zsd_on_plant
         INTO CORRESPONDING FIELDS OF @ls_new_plant
      WHERE owerks = @p_final-werks.

      IF sy-subrc = 0.

        READ TABLE it_kostl INTO wa_kostl WITH KEY kstar = gc_hkont gsber = ls_new_plant-nwerks. " chngs by aarti VSD 26.03.2026
        wa_bdc-kostl = wa_kostl-kostl.
**        wa_bdc-bus_area = ls_new_plant-nwerks.

      ENDIF.

    ENDIF.

  ENDIF.

ENDFORM.                    " F_GET_COST_CENTER
*&---------------------------------------------------------------------*
*&      Form  F_POST_FB75A
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_post_fb75a .
  IF gv_flag IS INITIAL.
    PERFORM f_bapi_fb75.
***    READ TABLE gt_bdc INTO wa_bdc INDEX 1.
***    IF sy-subrc EQ 0.
***      REFRESH bdcdata[].
***      REFRESH gt_msgtype[].
****      PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
****      PERFORM bdc_field       USING 'BDC_OKCODE'
****                                    '/ECCDE'.
****
****      PERFORM bdc_dynpro      USING 'SAPLACHD' '1000'.
****      PERFORM bdc_field       USING 'BDC_OKCODE'
****                                    '=ENTR'.
****      PERFORM bdc_field       USING 'BKPF-BUKRS'
****                                    wa_bdc-bukrs.
***
***      PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
***      PERFORM bdc_field       USING 'BDC_OKCODE'
***                                    '=0005'.
***      PERFORM bdc_field       USING 'RF05A-BUSCS'
***                                    'G'.
***
***      PERFORM bdc_field       USING 'INVFO-ACCNT'
***                                    wa_bdc-accnt.
***      PERFORM bdc_field       USING 'INVFO-BLDAT'
***                                    wa_bdc-bldat.
***      PERFORM bdc_field       USING 'INVFO-XBLNR'
***                                    wa_bdc-xblnr.
***      lv_amt_c = lv_amt.
***      CONDENSE lv_amt_c.
***      PERFORM bdc_field       USING 'INVFO-WRBTR'
***                                    lv_amt_c.
***      CLEAR :wa_bdc.
***      DESCRIBE TABLE gt_bdc LINES v_lines.
***      LOOP AT gt_bdc INTO wa_bdc.
***        gv_tabix = sy-tabix.
***        IF gv_count LE 4.
***          gv_count = gv_count + 1.
***          gv_fld = gv_count.
***          UNPACK gv_fld TO gv_fld.
***        ENDIF.
***        IF gv_count EQ 5 AND gv_tabix NE v_lines.
***          PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
***          PERFORM bdc_field       USING 'BDC_OKCODE'
***                                        '=0005'.
***          gv_count = gv_count - 1.
***          gv_fld = gv_count.
***          UNPACK gv_fld TO gv_fld.
***        ELSEIF  gv_tabix EQ v_lines.
***          PERFORM bdc_dynpro      USING 'SAPMF05A' '1200'.
***          PERFORM bdc_field       USING 'BDC_OKCODE'
***                                        '=BP'.
***          gv_count = gv_count - 1.
***          gv_fld = gv_count.
***          UNPACK gv_fld TO gv_fld.
***        ENDIF.
***
***        CLEAR gv_field.
***        CONCATENATE 'ACGL_ITEM-HKONT(' gv_fld ')' INTO gv_field.
***        PERFORM bdc_field       USING gv_field
***                                      wa_bdc-hkont.
***
***        CLEAR gv_field.
***        CONCATENATE 'ACGL_ITEM-WRBTR(' gv_fld ')' INTO gv_field.
***        PERFORM bdc_field       USING gv_field
***                                      wa_bdc-wrbt1.
***
***        CLEAR gv_field.
***        CONCATENATE 'ACGL_ITEM-KOSTL(' gv_fld ')' INTO gv_field.
***        PERFORM bdc_field       USING gv_field
***                                      wa_bdc-kostl.
***        CLEAR gv_field.
***        CONCATENATE 'ACGL_ITEM-ZUONR(' gv_fld ')' INTO gv_field.
***        PERFORM bdc_field       USING gv_field
***                                      wa_bdc-zuonr.
***
***      ENDLOOP.
***      params-dismode = 'A'.
***      params-updmode = 'S'.
***      params-defsize = 'X'.
***      params-nobinpt = 'X'.
****      CALL TRANSACTION 'FB75' USING bdcdata OPTIONS FROM params
****                                     MESSAGES INTO gt_msgtype  ." MODE MOd UPDATE upd.
***      IF gt_msgtype[] IS NOT INITIAL.
***        READ TABLE gt_msgtype WITH KEY msgtyp = 'S'
***                                       msgid  = 'F5'
***                                       msgnr  = '312'.
***        IF sy-subrc EQ 0.
***          CLEAR lv_msg.
***          CALL FUNCTION 'FORMAT_MESSAGE'
***            EXPORTING
***              id        = gt_msgtype-msgid
***              lang      = sy-langu
***              no        = gt_msgtype-msgnr
***              v1        = gt_msgtype-msgv1
***              v2        = gt_msgtype-msgv2
***              v3        = gt_msgtype-msgv3
***              v4        = gt_msgtype-msgv4
***            IMPORTING
***              msg       = lv_msg
***            EXCEPTIONS
***              not_found = 1
***              OTHERS    = 2.
***          IF sy-subrc <> 0.
***            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
***                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
***          ENDIF.
***          CONCATENATE wa_final-messg lv_msg INTO wa_final-messg.
***        ELSE.
***          LOOP AT gt_msgtype WHERE msgtyp EQ 'E' OR msgtyp EQ 'A'.
***            CLEAR lv_msg.
***            CALL FUNCTION 'FORMAT_MESSAGE'
***              EXPORTING
***                id        = gt_msgtype-msgid
***                lang      = sy-langu
***                no        = gt_msgtype-msgnr
***                v1        = gt_msgtype-msgv1
***                v2        = gt_msgtype-msgv2
***                v3        = gt_msgtype-msgv3
***                v4        = gt_msgtype-msgv4
***              IMPORTING
***                msg       = lv_msg
***              EXCEPTIONS
***                not_found = 1
***                OTHERS    = 2.
***            IF sy-subrc <> 0.
***              MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
***                      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
***            ENDIF.
***            CONCATENATE wa_final-messg lv_msg INTO wa_final-messg.
***          ENDLOOP.
***        ENDIF.
***        LOOP AT gt_final ASSIGNING <fs_final> WHERE sel = 'X' AND messg IS INITIAL.
***          <fs_final>-messg = wa_final-messg.
***        ENDLOOP.
***      ENDIF.
***
***    ENDIF.
  ENDIF.
***  CLEAR wa_final.

ENDFORM.                    " F_POST_FB75A
*&---------------------------------------------------------------------*
*&      Form  F_GET_AGGREGATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_aggregate .
  CLEAR : lv_amt,count.
  REFRESH : gt_bdc[].
  CLEAR wa_bdc.
  DATA: gt_final1 TYPE STANDARD TABLE OF ty_final.

  LOOP AT gt_final ASSIGNING <fs_final> WHERE sel = 'X' AND messg IS INITIAL.
    PERFORM f_get_cost_center USING <fs_final>.
    IF wa_bdc-kostl IS INITIAL.
      gv_flag = 'X'.
      <fs_final>-messg = TEXT-017. "'Cost Center Does not exist'.
      EXIT.
    ENDIF.
    count = count + 1.
    IF count > 7.
      MESSAGE 'Select only 7 Line for posting' TYPE 'E'.
    ENDIF.
    APPEND <fs_final> TO gt_final1.
  ENDLOOP.
  CHECK gv_flag IS INITIAL.
  CLEAR gv_flag.

    SELECT werks j_1bbranch  FROM t001w INTO TABLE it_t001w
    FOR ALL ENTRIES IN gt_final
    WHERE werks = gt_final-werks.

  LOOP AT gt_final1 ASSIGNING <fs_final> . "WHERE sel = 'X' AND messg IS INITIAL.
    AT NEW kunnr.
      CLEAR lv_amt.
    ENDAT.
    CLEAR gv_flag.
    gv_tabix = sy-tabix.
    wa_bdc-bukrs = <fs_final>-bukrs.
    wa_bdc-accnt = <fs_final>-kunnr.
    CONDENSE wa_bdc-accnt.
    PERFORM f_date_external USING sy-datum CHANGING wa_bdc-bldat.
    lv_amt = lv_amt + <fs_final>-zzint.
*    wa_bdc-wrbtr = <fs_final>-zzint.
    CONDENSE wa_bdc-wrbtr.
*    wa_bdc-xblnr = <fs_final>-vbeln.
    wa_bdc-hkont = gc_hkont.
    wa_bdc-wrbt1 = <fs_final>-zzint.

    IF <fs_final>-blart = 'RV'.
      wa_bdc-zuonr   = <fs_final>-xblnr.
    ELSE.
      wa_bdc-zuonr = <fs_final>-vbeln.
    ENDIF.


    CONCATENATE wa_bdc-zuonr ',' v_text INTO v_text SEPARATED BY  space.

    """"" added by aarti kumari ....
    READ TABLE it_t001w INTO wa_t001w WITH KEY werks = <fs_final>-werks.
    IF sy-subrc = 0.
      wa_bdc-bupla = wa_t001w-j_1bbranch.
    ENDIF.
    """"" ended by aarti kumari ....

    PERFORM f_get_cost_center USING <fs_final>.
*    IF wa_bdc-kostl IS INITIAL.
*      gv_flag = 'X'.
*      <fs_final>-messg = 'Cost Center Does not exist'.
*      EXIT.
*    ENDIF.
*        wa_bdc-kostl = '1600311004'.
    APPEND wa_bdc TO gt_bdc.
    CLEAR : wa_bdc.
    AT END OF kunnr.
      PERFORM f_bapi_fb75.
      REFRESH gt_bdc[].
      CLEAR wa_bdc.
    ENDAT.
  ENDLOOP.
ENDFORM.                    " F_GET_AGGREGATE
*&---------------------------------------------------------------------*
*&      Form  F_BAPI_FB75
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_bapi_fb75 .
*BAPI Structure
  DATA: s_dochead  LIKE bapiache09,
        t_agl      LIKE STANDARD TABLE OF bapiacgl09 WITH HEADER LINE,
        t_cust     LIKE STANDARD TABLE OF bapiacar09 WITH HEADER LINE,
        t_currency LIKE STANDARD TABLE OF bapiaccr09 WITH HEADER LINE,
        t_return   LIKE STANDARD TABLE OF bapiret2 WITH HEADER LINE,
        t_ext      LIKE STANDARD TABLE OF bapiacextc WITH HEADER LINE,
        t_error    TYPE STANDARD TABLE OF ty_error,
        t_success  TYPE STANDARD TABLE OF ty_error,
        t_withtx   TYPE STANDARD TABLE OF bapiacwt09 WITH HEADER LINE,
        s_error    TYPE ty_error,
        v_obj_type TYPE bapiache09-obj_type,
        v_obj_key  TYPE bapiache09-obj_key,
        v_obj_sys  TYPE bapiache09-obj_sys.
  DATA: v_item   TYPE posnr_acc.
  DATA: v_sgtxt(50).
  DATA: l_dt(10).
  DATA: h_dt(10).
  FIELD-SYMBOLS :<fs_ret>   TYPE bapiret2.  "Return parameter

  READ TABLE gt_bdc INTO wa_bdc INDEX 1.
  IF sy-subrc EQ 0.
**--Fill Doc Header
    s_dochead-username    = sy-uname.           "User name
    sy-tcode = 'ZFI_CD_RCL_AUTO'.
*    s_dochead-ref_doc_no  = s_header-ref.       "Reference Doc No.
    s_dochead-comp_code   = wa_bdc-bukrs.     "Company Code
*    IF sy-ucomm EQ 'FB75'. "comment on 09/11/2022
    s_dochead-ref_doc_no   = wa_bdc-xblnr.    "Reference No
*    ENDIF.  "comment on 09/11/2022

    s_dochead-doc_date    = sy-datum. "s_header-ddate.     "Doc. Date
    s_dochead-pstng_date  = sy-datum. "s_header-pdate.     "Posting date
*    s_dochead-header_txt  = s_header-htext.     "Header Text
    s_dochead-doc_type    = 'DG'.  "Doc. Type
    v_item = v_item + 1.
*    t_agl-itemno_acc = v_item.
*    t_agl-gl_account = '0034010001'."gc_hkont.
*    t_agl-customer   = wa_bdc-accnt.
**  t_agl-item_text  = s_item-text.
*    t_agl-doc_type   = 'DG'.
*    t_agl-comp_code = wa_bdc-bukrs.
*    t_agl-pstng_date = sy-datum. "s_header-pdate.
*    t_agl-costcenter = wa_bdc-kostl.
*    t_agl-alloc_nmbr = wa_bdc-zuonr.
*    APPEND t_agl.
*    CLEAR t_agl.


    t_cust-itemno_acc = v_item.
    t_cust-customer = wa_bdc-accnt.
    t_cust-c_ctr_area = '2000'."wa_bdc-bukrs.
*    t_cust-gl_account = '0034010001'.
    t_cust-bline_date = sy-datum.
    t_cust-comp_code = wa_bdc-bukrs.
    t_cust-bus_area = wa_bdc-bus_area.
***********************************    26.11.2022
    CONCATENATE p_datum-low+6(2) '-' p_datum-low+4(2) '-' p_datum-low+0(4) INTO l_dt.
    CONCATENATE p_datum-high+6(2) '-' p_datum-high+4(2) '-' p_datum-high+0(4) INTO h_dt.
    CONCATENATE 'CD:-'  l_dt 'TO' h_dt INTO v_sgtxt SEPARATED BY space.
    t_cust-item_text = v_sgtxt.
    t_cust-businessplace = wa_bdc-bupla.
    t_cust-sectioncode = wa_bdc-bupla.
**********************************************  26.11.2022
    APPEND t_cust.
    CLEAR: v_sgtxt.
    t_currency-itemno_acc = v_item.
    t_currency-currency = 'INR' .
*    IF sy-ucomm EQ 'FB75A'.
    t_currency-amt_doccur = lv_amt * -1 .
*    ELSEIF sy-ucomm EQ 'FB75'.
*      t_currency-amt_doccur = wa_bdc-wrbtr * -1 .
*    ENDIF.
    APPEND t_currency.
    CLEAR t_currency.

    LOOP AT gt_knbw INTO wa_knbw WHERE kunnr = wa_bdc-accnt
                                   AND bukrs = wa_bdc-bukrs.
      t_withtx-itemno_acc = v_item.
      t_withtx-wt_type    = wa_knbw-witht . "'S1'.
      APPEND t_withtx.
      CLEAR t_withtx.
    ENDLOOP.
    LOOP AT gt_bdc INTO wa_bdc.
      v_item = v_item + 1.
      t_agl-itemno_acc = v_item.

      t_agl-gl_account = gc_hkont.
*  t_agl-item_text  = s_item-text.
      t_agl-doc_type   = 'DG'.
      t_agl-comp_code = wa_bdc-bukrs.
      t_agl-pstng_date = sy-datum. "s_header-pdate.
      t_agl-costcenter = wa_bdc-kostl.
      t_agl-businessplace = wa_bdc-bupla.
      t_agl-sectioncode = wa_bdc-bupla.
************************************   for gl line item 16.02.2023
      CONCATENATE p_datum-low+6(2) '-' p_datum-low+4(2) '-' p_datum-low+0(4) INTO l_dt.
      CONCATENATE p_datum-high+6(2) '-' p_datum-high+4(2) '-' p_datum-high+0(4) INTO h_dt.
      CONCATENATE 'CD:-'  l_dt 'TO' h_dt INTO v_sgtxt SEPARATED BY space.
      t_agl-item_text = v_sgtxt.
*************************************  end comment 16.02.2023

*      IF sy-ucomm EQ 'FB75A'.
      t_agl-alloc_nmbr = wa_bdc-zuonr.
*      ENDIF.
      APPEND t_agl.
      CLEAR t_agl.
      CLEAR: v_sgtxt.


      t_currency-itemno_acc = v_item.
      t_currency-currency = 'INR' .
      t_currency-amt_doccur = wa_bdc-wrbt1.
      APPEND t_currency.
      CLEAR t_currency.
    ENDLOOP.
    " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
    CALL FUNCTION 'BAPI_ACC_DOCUMENT_CHECK' "#EC CI_USAGE_OK[2628704]
      EXPORTING                            "#EC CI_USAGE_OK[2438131]
        " ATC Correction for S4 HANA **END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
        documentheader    = s_dochead
      TABLES
        accountgl         = t_agl
        accountreceivable = t_cust
        currencyamount    = t_currency
        return            = t_return
        accountwt         = t_withtx.

    READ TABLE t_return ASSIGNING <fs_ret> WITH KEY type = 'E'.
    IF sy-subrc NE 0.
      UNASSIGN <fs_ret>.
      t_ext-field1 = sy-tcode.
      t_ext-field2 = 'FB75A'."sy-ucomm.
      APPEND t_ext.
      " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
      CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST' "#EC CI_USAGE_OK[2628704]
        EXPORTING                               "#EC CI_USAGE_OK[2438131]
          " ATC Correction for S4 HANA **END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
          documentheader    = s_dochead
        IMPORTING
          obj_type          = v_obj_type
          obj_key           = v_obj_key
          obj_sys           = v_obj_sys
        TABLES
          accountgl         = t_agl
          accountreceivable = t_cust
          currencyamount    = t_currency
          extension1        = t_ext
          return            = t_return
          accountwt         = t_withtx.
      SORT  t_return BY
            type
            id
            number
            message.
      DELETE ADJACENT DUPLICATES FROM t_return
      COMPARING type
                id
                number
                message.
      READ TABLE t_return WITH KEY type = 'E' TRANSPORTING NO FIELDS .
      IF sy-subrc NE 0.
        UNASSIGN <fs_ret>.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = 'X'.
        LOOP AT t_return ASSIGNING <fs_ret>.
          IF <fs_ret>-type EQ 'S' AND
             <fs_ret>-id EQ 'RW' AND
             <fs_ret>-number EQ '605'.
            CONCATENATE TEXT-006 "'Document'
                        v_obj_key+0(10)
                        TEXT-019 "'was successfully posted in company code'
                        v_obj_key+10(4) INTO wa_final-messg SEPARATED BY space.

*               ********** LONG TEXT.
            DATA: ls_header LIKE thead,
                  lt_lines  TYPE STANDARD TABLE OF tline WITH HEADER LINE.
            DATA: v_club(70).

*  CONCATENATE pf_vbeln pf_posnr INTO ls_header-tdname.
*   CONCATENATE v_obj_key+10(4) v_obj_key+0(10) v_obj_key+14(4) '001' into v_club.
            CONDENSE v_text.
            lv_len = strlen( v_text ).
            lv_len = lv_len - 1.
            v_text2 = v_text+0(lv_len).
            CONCATENATE v_obj_key+10(4) v_obj_key+0(10) v_obj_key+14(4) INTO v_club.
            CONCATENATE 'Cash discount for invoice number' v_text2 '.' INTO v_text1 SEPARATED BY space.
            ls_header-tdname   = v_club.
            ls_header-tdspras   = sy-langu.
            ls_header-tdobject  = 'BELEG'.
            ls_header-tdid      = '0002'.
*  ls_header-tdtitle   = pf_title.

            lt_lines-tdline   = v_text1.
            lt_lines-tdformat = '*'.
            APPEND lt_lines.

            CALL FUNCTION 'SAVE_TEXT'
              EXPORTING
                client          = sy-mandt
                header          = ls_header
                savemode_direct = 'X'
              TABLES
                lines           = lt_lines
              EXCEPTIONS
                OTHERS          = 1.

            IF sy-subrc NE 0.
              EXIT.
            ENDIF.
**************
          ELSEIF <fs_ret>-type EQ 'W'.

          ELSE.
            wa_final-messg = <fs_ret>-message.


*  *            ********** LONG TEXT.
*            DATA: ls_header LIKE thead,
*                  lt_lines  TYPE STANDARD TABLE OF tline WITH HEADER LINE.
*            DATA: v_club(70).

*  CONCATENATE pf_vbeln pf_posnr INTO ls_header-tdname.
*   CONCATENATE v_obj_key+10(4) v_obj_key+0(10) v_obj_key+14(4) '001' into v_club.
            CONDENSE v_text.
            lv_len = strlen( v_text ).
            lv_len = lv_len - 1.
            v_text2 = v_text+0(lv_len).
            CONCATENATE v_obj_key+10(4) v_obj_key+0(10) v_obj_key+14(4) INTO v_club.
            CONCATENATE 'Cash discount for invoice number' v_text2 '.' INTO v_text1 SEPARATED BY space.
            ls_header-tdname   = v_club.
            ls_header-tdspras   = sy-langu.
            ls_header-tdobject  = 'BELEG'.
            ls_header-tdid      = '0002'.
*  ls_header-tdtitle   = pf_title.

            lt_lines-tdline   = v_text1.
            lt_lines-tdformat = '*'.
            APPEND lt_lines.

            CALL FUNCTION 'SAVE_TEXT'
              EXPORTING
                client          = sy-mandt
                header          = ls_header
                savemode_direct = 'X'
              TABLES
                lines           = lt_lines
              EXCEPTIONS
                OTHERS          = 1.

            IF sy-subrc NE 0.
              EXIT.
            ENDIF.
**************


          ENDIF.
        ENDLOOP.
*        IF sy-ucomm EQ 'FB75A'.
        LOOP AT gt_final ASSIGNING <fs_final1> WHERE messg IS INITIAL AND kunnr = wa_bdc-accnt. "sel = 'X' AND
          <fs_final1>-messg = wa_final-messg.
        ENDLOOP.
*          CLEAR wa_final.
        IF sy-ucomm EQ 'FB75'.
          <fs_final>-messg = wa_final-messg.
        ENDIF.
      ENDIF.
    ELSE.
      wa_final-messg = <fs_ret>-message.
*      IF sy-ucomm EQ 'FB75A'.
      LOOP AT gt_final ASSIGNING <fs_final1> WHERE  messg IS INITIAL AND kunnr = wa_bdc-accnt.  "sel = 'X' AND
        <fs_final1>-messg = wa_final-messg.
      ENDLOOP.
*        CLEAR wa_final.
      IF sy-ucomm EQ 'FB75'.
        <fs_final>-messg = wa_final-messg.
      ENDIF.
    ENDIF.
  ENDIF.
  CLEAR: wa_final,v_text1,v_text2,v_text,v_club.


ENDFORM.                    " F_BAPI_FB75
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check . " Added by Carina Jose on 03.03.2022
  AUTHORITY-CHECK OBJECT 'Z_VKORG_CD'
  ID 'VKORG' FIELD p_vkorg
  ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e013(zsd) WITH p_vkorg.
  ENDIF.
ENDFORM. "End of changes on 03.03.2022
*&---------------------------------------------------------------------*
*&      Form  AUTO_POST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM auto_post .
*   REFRESH: gt_bdc[].
*      CLEAR wa_bdc.
*      CLEAR gv_tabix.
*      LOOP AT gt_final ASSIGNING <fs_final> WHERE  messg IS INITIAL. "sel = 'X' AND.
*        gv_tabix = sy-tabix.
*        wa_bdc-bukrs = <fs_final>-bukrs.
*        wa_bdc-accnt = <fs_final>-kunnr.
*        CONDENSE wa_bdc-accnt.
*        PERFORM f_date_external USING sy-datum CHANGING wa_bdc-bldat.
*        wa_bdc-wrbtr = <fs_final>-zzint.
*        CONDENSE wa_bdc-wrbtr.
*        wa_bdc-xblnr = <fs_final>-vbeln.
*        wa_bdc-hkont = gc_hkont.
*        PERFORM f_get_cost_center USING <fs_final>.
*        IF wa_bdc-kostl IS INITIAL.
*          <fs_final>-messg = text-017." 'Cost Center Does not exist'.
*          CONTINUE.
*        ENDIF.
*        wa_bdc-kostl = '1600311004'.
*        wa_bdc-wrbt1 = <fs_final>-zzint.
*        APPEND wa_bdc TO gt_bdc.
*        PERFORM f_bapi_fb75.
*        REFRESH gt_bdc[].
*        PERFORM f_post_fb75 USING wa_bdc.
*        CLEAR : wa_bdc.
*      ENDLOOP.

  CLEAR : lv_amt,count.
  REFRESH : gt_bdc[].
  CLEAR wa_bdc.
  DATA: gt_final1 TYPE STANDARD TABLE OF ty_final.

    SELECT werks j_1bbranch  FROM t001w INTO TABLE it_t001w
    FOR ALL ENTRIES IN gt_final
    WHERE werks = gt_final-werks.

  LOOP AT gt_final ASSIGNING <fs_final> WHERE  messg IS INITIAL.
    PERFORM f_get_cost_center USING <fs_final>.
    IF wa_bdc-kostl IS INITIAL.
      gv_flag = 'X'.
      <fs_final>-messg = TEXT-017. "'Cost Center Does not exist'.
      EXIT.
    ENDIF.
    count = count + 1.
*    IF count > 7.
*      MESSAGE 'Select only 7 Line for posting' TYPE 'E'.
*    ENDIF.
    APPEND <fs_final> TO gt_final1.
  ENDLOOP.
  CHECK gv_flag IS INITIAL.
  CLEAR gv_flag.
  LOOP AT gt_final1 ASSIGNING <fs_final> . "WHERE sel = 'X' AND messg IS INITIAL.
    AT NEW kunnr.
      CLEAR lv_amt.
    ENDAT.
    CLEAR gv_flag.
    gv_tabix = sy-tabix.
    wa_bdc-bukrs = <fs_final>-bukrs.
    wa_bdc-accnt = <fs_final>-kunnr.
    CONDENSE wa_bdc-accnt.
    PERFORM f_date_external USING sy-datum CHANGING wa_bdc-bldat.
    lv_amt = lv_amt + <fs_final>-zzint.
*    wa_bdc-wrbtr = <fs_final>-zzint.
    CONDENSE wa_bdc-wrbtr.
*    wa_bdc-xblnr = <fs_final>-vbeln.
    wa_bdc-hkont = gc_hkont.
    wa_bdc-wrbt1 = <fs_final>-zzint.
    wa_bdc-zuonr = <fs_final>-vbeln.
    CONCATENATE wa_bdc-zuonr ',' v_text INTO v_text SEPARATED BY  space.
        READ TABLE it_t001w INTO wa_t001w WITH KEY werks = <fs_final>-werks.
    IF sy-subrc = 0.
      wa_bdc-bupla = wa_t001w-j_1bbranch.
    ENDIF.
    PERFORM f_get_cost_center USING <fs_final>.
*    IF wa_bdc-kostl IS INITIAL.
*      gv_flag = 'X'.
*      <fs_final>-messg = 'Cost Center Does not exist'.
*      EXIT.
*    ENDIF.
*        wa_bdc-kostl = '1600311004'.
    APPEND wa_bdc TO gt_bdc.
    CLEAR : wa_bdc.
    AT END OF kunnr.
      PERFORM f_bapi_fb75.
      REFRESH gt_bdc[].
      CLEAR wa_bdc.
    ENDAT.
  ENDLOOP.
ENDFORM.
