*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_EXP_SALES...................................*
DATA:  BEGIN OF STATUS_ZFI_EXP_SALES                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_EXP_SALES                 .
CONTROLS: TCTRL_ZFI_EXP_SALES
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_EXP_SALES                 .
TABLES: ZFI_EXP_SALES                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
