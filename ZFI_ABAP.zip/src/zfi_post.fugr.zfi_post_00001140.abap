FUNCTION zfi_post_00001140.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_PARKED) TYPE  XFELD OPTIONAL
*"  TABLES
*"      T_BKPF STRUCTURE  BKPF
*"      T_BSEG STRUCTURE  BSEG
*"      T_EXCTAB STRUCTURE  EXCLTAB_LINE
*"----------------------------------------------------------------------
*  IF sy-ucomm = 'BU'.
*    DATA: lt_srgbtbrel TYPE TABLE OF srgbtbrel.
*    IF t_bkpf[] IS NOT INITIAL.
*      LOOP AT t_bkpf INTO DATA(ls_bkpf) .
*        select single * from bkpf
*          into @Data(ls_bstat)
*          where BUKRS = @ls_bkpf-bukrs
*          and BELNR = @ls_bkpf-belnr
*          and GJAHR =  @ls_bkpf-gjahr.
*
*        if ls_bstat-bstat = 'V' OR ls_bstat-bstat = 'W' .
*        DATA(lv_instid_a) = |{ ls_bkpf-bukrs }| && |{ ls_bkpf-belnr }| && |{ ls_bkpf-gjahr }| .
*
*        SELECT *
*           FROM srgbtbrel
*           INTO TABLE @lt_srgbtbrel
*           WHERE instid_a = @lv_instid_a
*          AND reltype =  'ATTA'
*          AND  typeid_a  = 'FIPP'
*         AND catid_a = 'BO'.
**      lt_srgbtbrel = VALUE #( FOR ls_bkpf IN t_bkpf[]
**                               (  instid_a = |{ ls_bkpf-bukrs }| && |{ ls_bkpf-belnr }| && |{ ls_bkpf-gjahr }|
**                                  reltype =  'ATTA'
**                                  typeid_a  = 'FIPP'
**                                  catid_a = 'BO'
**                                  client = sy-mandt ) ).
*        IF lt_srgbtbrel IS INITIAL .
*          MESSAGE e000(zfi_abap) WITH 'ATTACHMENTS NOT AVAILABLE' DISPLAY LIKE 'S'.
*        ENDIF.
*        ENDIF.
*
*      ENDLOOP.
*    ENDIF.
*  ENDIF.
ENDFUNCTION.
