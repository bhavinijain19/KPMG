FUNCTION-POOL ZFI_CREDIT_DAYS            MESSAGE-ID SV.

* INCLUDE LZFI_CREDIT_DAYSD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_CREDIT_DAYST00                     . "view rel. data dcl.
