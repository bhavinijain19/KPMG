class ZCL_ZFI_IM_ACC_DOC_BKPFF definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ACC_DOCUMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_IM_ACC_DOC_BKPFF IMPLEMENTATION.


  METHOD if_ex_acc_document~change.

    "---- Defensive: should be routed by filter AWTYP=BKPFF already
    IF c_acchd-awtyp <> 'BKPFF'.
      RETURN.
    ENDIF.


    DATA: ls_accit     TYPE accit,
          lv_werks     TYPE werks_d,
          lv_prctr     TYPE prctr,
          lv_gsber     TYPE gsber,
          wa_accit     TYPE accit,
          wa_lfa1      TYPE lfa1,
          lv_country   TYPE land1,
          lv_ind       TYPE c,
          lv_matnr     TYPE matnr,
          lv_ref_prctr TYPE prctr.

*    IF c_accit IS NOT INITIAL.
*      SELECT matnr, werks, prctr
*        INTO TABLE @DATA(lt_marc)
*        FROM marc
*        FOR ALL ENTRIES IN @c_accit
*        WHERE matnr = @c_accit-matnr AND
*              werks = @c_accit-werks.
*
*      IF sy-subrc IS INITIAL AND lt_marc IS NOT INITIAL.
*        SELECT prctr, gsber
*            INTO TABLE @DATA(lt_csks)
*            FROM csks
*            FOR ALL ENTRIES IN @lt_marc
*            WHERE prctr = @lt_marc-prctr.
*
*      ENDIF.
*    ENDIF.


    LOOP AT c_accit INTO wa_accit.

      "prctr , gsber ( business area)

*      IF wa_accit-matnr  IS NOT INITIAL AND wa_accit-werks IS NOT INITIAL.
*
*        READ TABLE lt_marc ASSIGNING FIELD-SYMBOL(<lfs_marc>) WITH KEY matnr = wa_accit-matnr
*                                                                        werks = wa_accit-werks BINARY SEARCH.
*
*        IF sy-subrc IS INITIAL AND <lfs_marc> IS ASSIGNED.
*          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*            EXPORTING
*              input  = <lfs_marc>-prctr
*            IMPORTING
*              output = <lfs_marc>-prctr.
*
*          wa_accit-prctr = <lfs_marc>-prctr.
*
*          READ TABLE lt_csks ASSIGNING FIELD-SYMBOL(<lfs_csks>) WITH KEY prctr = wa_accit-prctr BINARY SEARCH.
*
*          IF sy-subrc IS INITIAL AND <lfs_csks> IS ASSIGNED.
*            wa_accit-gsber = <lfs_csks>-gsber.
*          ENDIF.
*        ENDIF.
*      ENDIF.

      CALL FUNCTION 'J_1BSA_COMPONENT_ACTIVE'
        EXPORTING
          bukrs            = wa_accit-bukrs
          component        = '**'
*         COUNTRY          =
        IMPORTING
          active_component = lv_country
*         OUT_COUNTRY      =
* EXCEPTIONS
*         COMPONENT_NOT_ACTIVE = 1
*         OTHERS           = 2
        .
      IF lv_country = 'IN'.
        lv_ind = 'X'.
      ELSE.
        EXIT.
      ENDIF.
      IF wa_accit-lifnr IS NOT INITIAL AND lv_ind = 'X'.
        wa_accit-gst_part = wa_accit-lifnr.
        CALL FUNCTION 'GET_VENDOR_DETAILS'
          EXPORTING
            i_lifnr         = wa_accit-lifnr
*           I_GET_ADDRESS   = ' '
          IMPORTING
            e_lfa1          = wa_lfa1
*           E_NAME          =
*           E_ADDR1         =
*           E_ADDR2         =
*           E_ADDR3         =
*           E_ADDR4         =
          EXCEPTIONS
            not_found       = 1
            parameter_error = 2
            OTHERS          = 3.
        wa_accit-plc_sup = wa_lfa1-regio.
        MODIFY c_accit FROM wa_accit TRANSPORTING gst_part plc_sup .  "prctr gsber
        CLEAR: wa_accit.
      ELSEIF ( wa_accit-shkzg = 'S' AND wa_accit-koart = 'S' AND wa_accit-taxit = ' ' ) AND lv_ind = 'X'.
        CALL FUNCTION 'J_1IG_GET_HSN_SAC'
          EXPORTING
            im_matnr   = wa_accit-matnr
            im_werks   = wa_accit-werks
*           im_asnum   =
            im_country = 'IN'
          IMPORTING
            ex_hsn_sac = wa_accit-hsn_sac.
        MODIFY c_accit FROM wa_accit TRANSPORTING hsn_sac.
        CLEAR: wa_accit.
      ENDIF.
    ENDLOOP.

    " Begin of changes by hemang : changes based on GST STO posting requirement

    IF c_accit IS NOT INITIAL.

      "Pick the first non-initial WERKS in c_accit
      CLEAR lv_werks.
      LOOP AT c_accit INTO ls_accit WHERE werks IS NOT INITIAL.
        lv_werks = ls_accit-werks.
        lv_matnr = ls_accit-matnr.
        EXIT.
      ENDLOOP.

      IF lv_werks IS NOT INITIAL.

        " to determine a reference PRCTR from MARC for this plant
        "    - use the first line that has MATNR (and same WERKS) and a non-initial MARC-PRCTR
        CLEAR lv_ref_prctr.

        IF lv_matnr IS NOT INITIAL AND lv_werks IS NOT INITIAL.
          SELECT SINGLE prctr
            FROM marc
            INTO @lv_ref_prctr
           WHERE werks = @lv_werks
             AND matnr = @lv_matnr.
        ENDIF.

        " 3) Read mapping from ZFI_GST_SPLIT for the plant,
        "    preferring the entry whose PRCTR matches lv_ref_prctr (if we have one)
        CLEAR: lv_prctr, lv_gsber.

        IF lv_ref_prctr IS NOT INITIAL.
          SELECT SINGLE prctr, gsber
            FROM zfi_gst_split
            INTO (@lv_prctr, @lv_gsber)
           WHERE werks = @lv_werks
             AND prctr = @lv_ref_prctr.
        ELSE.
          SELECT SINGLE prctr, gsber
            FROM zfi_gst_split
            INTO (@lv_prctr, @lv_gsber)
           WHERE werks = @lv_werks.
        ENDIF.

        IF lv_prctr IS INITIAL AND lv_ref_prctr IS NOT INITIAL.
          lv_prctr = lv_ref_prctr.
          " Assumes lv_ref_prctr already contains the Profit Center
          lv_gsber = lv_gsber = lv_ref_prctr+4(4).
        ENDIF.

        " If we have a mapping, fill PRCTR & GSBER into all c_accit lines
        IF  lv_prctr IS NOT INITIAL AND lv_gsber IS NOT INITIAL.
          LOOP AT c_accit ASSIGNING FIELD-SYMBOL(<lfs_accit>).

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = lv_prctr
              IMPORTING
                output = lv_prctr.

            <lfs_accit>-prctr = lv_prctr.
            <lfs_accit>-gsber = lv_gsber.
          ENDLOOP.
        ENDIF.

      ENDIF.
    ENDIF.

    " End of changes by hemang : changes based on GST STO posting requirement

  ENDMETHOD.


  method IF_EX_ACC_DOCUMENT~FILL_ACCIT.
  endmethod.
ENDCLASS.
