FUNCTION-POOL ZFI_MIS_KDGRP              MESSAGE-ID SV.

* INCLUDE LZFI_MIS_KDGRPD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_MIS_KDGRPT00                       . "view rel. data dcl.
