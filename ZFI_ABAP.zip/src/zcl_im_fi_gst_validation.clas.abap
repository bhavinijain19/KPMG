class ZCL_IM_FI_GST_VALIDATION definition
  public
  final
  create public .

public section.

  interfaces IF_EX_FAGL_SET_SEGMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_FI_GST_VALIDATION IMPLEMENTATION.


  METHOD if_ex_fagl_set_segment~change_segment_psegment.
*&----------------------Development Details----------------------------*
*&--Enhancement      : BADI EN. for FAGL_SET_SEGMENT                ---*
*&--Package          : ZFI_ABAP                                     ---*
*&--Description      : Enhancement for GST Validation for MM & FI   ---*
*&--Transaction Code : ALL STANDARD TCODE for FI Posting            ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP )                      ---*
*&--Functional Owner : MAHESH KOKULU / BRIJESH SHAH                 ---*
*&--TR No            : DEVK944461                                   ---*
*&---------------------------------------------------------------------*

    DATA : lv_vregio       TYPE lfa1-regio,
           lv_lifnr1       TYPE lfa1-lifnr,
           lv_ktokk        TYPE lfa1-ktokk,
           lv_msg          TYPE c LENGTH 250,
           lv_region       TYPE csks-regio,
           lv_bupla_region TYPE csks-regio,
           lv_adrnr        TYPE adrnr.

    DATA : it_accit TYPE TABLE OF accit,
           wa_accit TYPE accit.

***    GST TAX CODE CHECK VALIDATIONS STARTS
    it_accit = ct_accit.
    CLEAR lv_lifnr1.
    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_new) WHERE name = 'ZFI_GSTIN_NEW_TCODE' AND type = 'S' AND low = @sy-tcode.
    IF sy-subrc = 0.
      lv_lifnr1 = VALUE #( it_accit[ koart = 'K' ]-gst_part OPTIONAL ).
    ELSE.
      lv_lifnr1 = VALUE #( it_accit[ koart = 'K' ]-lifnr OPTIONAL ).
    ENDIF.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_gstswitch) WHERE name = 'ZFI_GSTIN_EN_SWITCH' AND type = 'P'.
    SELECT name , low FROM tvarvc INTO @DATA(ls_gstswitch) UP TO 1 ROWS WHERE name = 'ZFI_GSTIN_EN_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF ls_gstswitch-low = abap_true.
      SELECT SINGLE ktokk FROM lfa1 INTO lv_ktokk WHERE lifnr = lv_lifnr1.
      SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_ktokk) WHERE name = 'ZFI_GSTIN_EN_KTOKK' AND type = 'S' AND low = @lv_ktokk.
*        IF lv_ktokk <> 'ZCEM'. "Comment by Rahul Vasita on 18.07.2024 15:26:02
      IF sy-subrc <> 0. "add by Rahul Vasita on 18.07.2024 15:26:02
        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_import) WHERE name = 'ZFI_GSTIN_IMPORT' AND type = 'S' AND low = @lv_ktokk.
        IF sy-subrc = 0.
          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_endetail) WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = @sy-tcode.
          IF ls_endetail IS NOT INITIAL.
            LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_imtax) WHERE name = 'ZFI_GSTIN_IMPORT_TX' AND type = 'S' AND low = @wa_accit-mwskz.
              IF sy-subrc <> 0.
                MESSAGE e007(zrcm_gst_en).
              ENDIF."End of LS_IMTAX
              CLEAR wa_accit.
            ENDLOOP.
          ENDIF."IF ls_endetail IS NOT INITIAL.
        ELSE.
          CLEAR : ls_endetail.
          SELECT SINGLE name  low FROM tvarvc INTO ls_endetail WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = sy-tcode.
          IF ls_endetail IS NOT INITIAL.
            SELECT SINGLE * FROM zfi_gstin_exl INTO @DATA(ls_splifnr) WHERE lifnr = @lv_lifnr1.
            IF sy-subrc <> 0.
              LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE lifnr , ven_class FROM j_1imovend INTO @DATA(ls_j_1imovend) WHERE lifnr = @lv_lifnr1.
                SELECT SINGLE lifnr , ven_class FROM LFA1 INTO @DATA(ls_j_1imovend) WHERE lifnr = @lv_lifnr1.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                IF ls_j_1imovend-ven_class = '0'.
                  SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_excep) WHERE name = 'ZFI_GSTIN_P1_V2_EX' AND type = 'S' AND low = @wa_accit-mwskz.
                  IF sy-subrc <> 0.
                    IF wa_accit-blart = 'RM'.
                      SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v2) WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = @wa_accit-mwskz.
                      IF sy-subrc <> 0.
                        "Error Message for Validation No 2
                        MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
                      ELSE.
                        "If Doc. Type is RM Starts
                        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v3) WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = @wa_accit-mwskz.
                        IF sy-subrc <> 0.
                          "Error Message for Validation No 3
                          MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
                        ELSE.
                          "Validation Code 6 Starts
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_excep40) WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = @sy-tcode.
                          SELECT name , low FROM tvarvc INTO @DATA(ls_excep40) UP TO 1 ROWS WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = @sy-tcode ORDER BY PRIMARY KEY.
                          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                          IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL ) OR
                             ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL ).
                            CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                            SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                            SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
                            SELECT adrnr FROM p_businessplace UP TO 1 ROWS INTO @lv_adrnr WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.
                            ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                            IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                              SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                              SELECT region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.
                              ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                            ENDIF.
                            IF lv_region <> lv_bupla_region.
                              "IGST Code ZFI_GSTIN_P1_IGST
                              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v6) WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = @wa_accit-mwskz.
                              IF sy-subrc <> 0.
                                "Error Only IGST Allowed
                                MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
                              ENDIF."ls_p1v6
                            ELSE.
                              "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v7) WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = @wa_accit-mwskz.
                              IF sy-subrc <> 0.
                                "Error Only C/S GST Allowed
                                MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
                              ENDIF."ls_p1v7
                            ENDIF."IF lv_region <> lv_bupla_region.
                          ENDIF."IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' ) OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' ).
                          "Validation Code 6 Ends
                        ENDIF."ls_p1v3
                        "If Doc. Type is RM Ends
                      ENDIF."sy-subrc <> 0.
                      CLEAR : ls_p1v2.
                    ELSE.
                      MESSAGE e004(zrcm_gst_en).
                    ENDIF."IF wa_accit-blart = 'RM'.
                  ENDIF."ls_excep
                ELSE.""IF ls_j_1imovend-ven_class = '0'.
                  CLEAR: ls_splifnr.
                  SELECT SINGLE * FROM zfi_gstin_inc INTO ls_splifnr WHERE lifnr = lv_lifnr1.
                  IF sy-subrc = 0.
                    "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
                    IF wa_accit-blart = 'RM'.
                      SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
                      IF sy-subrc <> 0.
                        "Error Message for Validation No 2
                        MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
                      ELSE.
                        "If Doc. Type is RM Starts
                        SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
                        IF sy-subrc <> 0.
                          "Error Message for Validation No 3
                          MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
                        ELSE.
                          "Validation Code 6 Starts
                          CLEAR: ls_excep40.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                          SELECT SINGLE name low FROM tvarvc INTO ls_excep40 WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode.
                          SELECT name low FROM tvarvc INTO ls_excep40 UP TO 1 ROWS WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode ORDER BY PRIMARY KEY.
                          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

                          IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL )
                          OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL ).

                            CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                            SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                            SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*                            SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.
                            SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.
                            ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                            IF lv_adrnr IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                              SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                              SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.
                              ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                            ENDIF.
                            IF lv_region <> lv_bupla_region.
                              "IGST Code ZFI_GSTIN_P1_IGST
                              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = wa_accit-mwskz.
                              IF sy-subrc <> 0.
                                "Error Only IGST Allowed
                                MESSAGE e003(zrcm_gst_en).
                              ENDIF."ls_p1v6
                            ELSE.
                              "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
                              IF sy-subrc <> 0.
                                "Error Only C/S GST Allowed
                                MESSAGE e002(zrcm_gst_en).
                              ENDIF."ls_p1v7
                            ENDIF."IF lv_region <> lv_bupla_region.
                          ENDIF."( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' ) OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' )
                          "Validation Code 6 Ends
                        ENDIF."ls_p1v3
                        "If Doc. Type is RM Ends
                      ENDIF."sy-subrc <> 0.
                      CLEAR : ls_p1v2.
                    ELSE.
                      MESSAGE e004(zrcm_gst_en).
                    ENDIF."IF wa_accit-blart = 'RM'.
                    "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
                  ELSE.
                    IF wa_accit-blart = 'RM'.
                      MESSAGE e005(zrcm_gst_en).
                    ELSE.
                      SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
                      IF sy-subrc = 0.
                        MESSAGE e006(zrcm_gst_en).
                      ELSE.
*                      GST PHASE 2 STARTS
                        "Validation Code 6 Starts
                        CLEAR: ls_excep40.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                        SELECT SINGLE name low FROM tvarvc INTO ls_excep40 WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode.
                        SELECT name low FROM tvarvc UP TO 1 ROWS INTO ls_excep40 WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode ORDER BY PRIMARY KEY.
                        ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                        IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL )
                        OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL ).
                          CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                          SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                          SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
                          SELECT adrnr FROM p_businessplace UP TO 1 ROWS INTO @lv_adrnr WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.
                          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                          IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                            SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                            SELECT region FROM adrc UP TO 1 ROWS INTO lv_bupla_region WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.
                            ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                          ENDIF.
                          CLEAR: ls_p1v6 , ls_p1v7.
                          IF lv_region <> lv_bupla_region.
                            "IGST Code ZFI_GSTIN_P1_IGST
                            SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P2_IGST' AND type = 'S' AND low = wa_accit-mwskz.
                            IF sy-subrc <> 0.
                              "Error Only IGST Allowed
                              MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
                            ENDIF."ls_p1v6
                          ELSE.
                            "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                            SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P2_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
                            IF sy-subrc <> 0.
                              "Error Only C/S GST Allowed
                              MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
                            ENDIF."ls_p1v7
                          ENDIF."IF lv_region <> lv_bupla_region.
                        ENDIF."IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' ) OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' ).
                        "Validation Code 6 Ends
*                      GST PHASE 2 ENDS
                      ENDIF."End of V2 TAX CODE
                    ENDIF."wa_accit-blart = 'RM'.
                  ENDIF."ENd of Include Vendor
                ENDIF."IF ls_j_1imovend-ven_class = '0'.
                CLEAR : wa_accit , ls_j_1imovend.
              ENDLOOP.
            ELSE.
              LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
                IF wa_accit-blart = 'RM'.
                  SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
                  IF sy-subrc <> 0.
                    "Error Message for Validation No 2
                    MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
                  ELSE.
                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
                    IF sy-subrc <> 0.
                      "Error Message for Validation No 3
                      MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
                    ELSE.
                      "Validation Code 6 Starts
                      CLEAR: ls_excep40.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                      SELECT SINGLE name low FROM tvarvc INTO ls_excep40 WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode.
                      SELECT name low FROM tvarvc UP TO 1 ROWS INTO ls_excep40 WHERE name = 'ZFI_GSTIN_EXCEP40' AND type = 'S' AND low = sy-tcode ORDER BY PRIMARY KEY.
                      ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                      IF ( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL )
                      OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' AND ls_excep40 IS NOT INITIAL ).
                        CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                        SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                        SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*                        SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.
                        SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.
                        ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                        IF lv_adrnr IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*                          SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                          SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.
                          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                        ENDIF.
                        IF lv_region <> lv_bupla_region.
                          "IGST Code ZFI_GSTIN_P1_IGST
                          SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = wa_accit-mwskz.
                          IF sy-subrc <> 0.
                            "Error Only IGST Allowed
                            MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
                          ENDIF."ls_p1v6
                        ELSE.
                          "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                          SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
                          IF sy-subrc <> 0.
                            "Error Only C/S GST Allowed
                            MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
                          ENDIF."ls_p1v7
                        ENDIF."IF lv_region <> lv_bupla_region.
                      ENDIF."( wa_accit-bschl <> '40' AND wa_accit-buzid <> 'S' ) OR ( wa_accit-bschl <> '50' AND wa_accit-buzid <> 'S' ).
                      "Validation Code 6 Ends
                    ENDIF."ls_p1v3
                    "If Doc. Type is RM Ends
                  ENDIF."sy-subrc <> 0.
                  CLEAR : ls_p1v2.
                ELSE.
                  SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
                  IF sy-subrc = 0.
                    MESSAGE e006(zrcm_gst_en).
                  ENDIF."ls_p1v2
                ENDIF."IF wa_accit-blart = 'RM'.
              ENDLOOP.
            ENDIF."LS_SPLIFNR
          ENDIF."IF ls_endetail IS NOT INITIAL.
          CLEAR : ls_endetail.
        ENDIF."END OF IMPORT ACC. GRP.

      ENDIF."IF lv_ktokk <> 'ZCEM'.
    ENDIF."IF ls_gstswitch-low = abap_true.
    ct_accit = it_accit.
    CLEAR ls_gstswitch.
**    "Adding End by Rahul Vasita on 13.05.2024 11:26:26  Ticket - APLITSS00034
***    GST TAX CODE CHECK VALIDATIONS ENDS

  ENDMETHOD.
ENDCLASS.
