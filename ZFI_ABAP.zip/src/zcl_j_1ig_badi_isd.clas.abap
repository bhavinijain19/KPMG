class ZCL_J_1IG_BADI_ISD definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_J1IG_ISD .
protected section.
private section.
ENDCLASS.



CLASS ZCL_J_1IG_BADI_ISD IMPLEMENTATION.


  METHOD if_ex_j1ig_isd~fill_bapi_extension.

  data: lv_acc_itm     TYPE posnr_acc.
    lv_acc_itm = 0000000000.
*    FIELD-SYMBOLS: <lv_acc_itm> TYPE any.
*    DATA(lv_cnt) = '(J_1IG_CL_ISDN=================CP)LV_ACC_ITM'.
*    ASSIGN (lv_cnt) TO <lv_acc_itm>.
*    IF <lv_acc_itm> IS ASSIGNED.
      SELECT SINGLE *
        FROM zfi_isd_split
        WHERE bupla = @IM_REC_BUPLA
        INTO @DATA(ls_isd_split) .
      DATA ls_extension2 TYPE bapiparex.
      IF ls_isd_split IS NOT INITIAL.
    lv_acc_itm = lv_acc_itm + 1.
        ls_extension2-valuepart1 = 'GSBER'.
        ls_extension2-valuepart2 = ls_isd_split-gsber."FIll Profit Center/Business Area values.
*       ls_extension2-valuepart3 = lv_acc_itm."FIll Line item(POSNR) for which the PRCTR/GSBER applies.
        APPEND ls_extension2 TO ch_t_bapiexten.

        ls_extension2-valuepart1 = 'PRCTR'.
        ls_extension2-valuepart2 = ls_isd_split-prctr."FIll Profit Center/Business Area values.
*       ls_extension2-valuepart3 = lv_acc_itm."FIll Line item(POSNR) for which the PRCTR/GSBER applies.
        APPEND ls_extension2 TO ch_t_bapiexten.

      ENDIF.
*      ENDIF.
    ENDMETHOD.


  method IF_EX_J1IG_ISD~SUMMARIZE.

  endmethod.
ENDCLASS.
