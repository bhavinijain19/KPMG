*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_EXP_SALES
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_EXP_SALES       .

  PERFORM TABLEPROC.

ENDFUNCTION.
