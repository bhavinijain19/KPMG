*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GSTIN_EXL...................................*
DATA:  BEGIN OF STATUS_ZFI_GSTIN_EXL                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GSTIN_EXL                 .
CONTROLS: TCTRL_ZFI_GSTIN_EXL
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_GSTIN_EXL                 .
TABLES: ZFI_GSTIN_EXL                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
