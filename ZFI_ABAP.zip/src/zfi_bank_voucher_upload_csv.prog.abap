*&---------------------------------------------------------------------*
*& Report  ZFI_BANK_VOUCHER_UPLOAD_CSV
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT ZFI_BANK_VOUCHER_UPLOAD_CSV.

TYPE-POOLS: kcde.

*include bdcrecx1.
SELECTION-SCREEN:BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.

PARAMETERS:p_file TYPE rlgrap-filename.

SELECTION-SCREEN:END OF BLOCK b1.

TYPES:BEGIN OF ty_bank,
        GJAHR(4)    TYPE c,
        type(4)     TYPE c,
        bukrs(4)    TYPE c,
        lifnr(10)   TYPE c,
        iden(5)     TYPE c,
        value(17)   TYPE c,
        text2(100)  TYPE c,
        text3(100)  TYPE c,
        text4(100)  TYPE c,
        text5(100)  TYPE c,
        text6(100)  TYPE c,
        text7(100)  TYPE c,
        text8(100)  TYPE c,
        text9(100)  TYPE c,
        text10(100) TYPE c,
      END OF ty_bank.

DATA:wa_bank TYPE ty_bank,
     it_bank TYPE TABLE OF ty_bank. " WITH HEADER LINE.


TYPES:BEGIN OF ty_bank1,
        a  TYPE  string,
        b  TYPE  string,
        c  TYPE  string,
        d  TYPE  string,
        e  TYPE  string,
        f  TYPE  string,
        g  TYPE  string,
        h  TYPE  string,
        i  TYPE  string,
        j  TYPE  string,
        k  TYPE  string,
        l  TYPE  string,
        m  TYPE  string,
        n  TYPE  string,
        o  TYPE  string,
        p  TYPE  string,
        q  TYPE  string,
        r  TYPE  string,
        s  TYPE  string,
        t  TYPE  string,
        u  TYPE  string,
        v  TYPE  string,
        w  TYPE  string,
        x  TYPE  string,
        y  TYPE  string,
        z  TYPE  string,
        aa TYPE  string,


      END OF ty_bank1.

DATA:wa_bank1 TYPE ty_bank1,
     it_bank1 TYPE TABLE OF ty_bank1. " WITH HEADER LINE.

DATA:filename TYPE string.

DATA: it_raw TYPE truxs_t_text_data.

TYPES:BEGIN OF ty_iden,
*        date(10) TYPE c,
        GJAHR type GJAHR  ,
        bukrs   TYPE bukrs,
        lifnr   TYPE lifnr,
        zuonr   TYPE dzuonr,
        dmbtr   TYPE dmbtr,
        ref(40) TYPE c,
        tbudat(10),
        budat type budat,
      END OF ty_iden.

DATA:wa_bsak TYPE ty_iden,
     it_bsak TYPE TABLE OF ty_iden.

TYPES: BEGIN OF ty_bsak1,
         bukrs TYPE bsak-bukrs,
         lifnr TYPE bsak-lifnr,
         zuonr TYPE bsak-zuonr,
         gjahr TYPE bsak-gjahr,
         belnr TYPE bsak-belnr,
         buzei TYPE bsak-buzei,
         xblnr TYPE bsak-xblnr,
         dmbtr TYPE bsak-dmbtr,
         budat TYPE bsak-budat,

       END OF ty_bsak1.

DATA:wa_bsak1 TYPE ty_bsak1,
     it_bsak1 TYPE TABLE OF ty_bsak1.

DATA:wa_bdc TYPE bdcdata,
     it_bdc TYPE TABLE OF bdcdata.

CONSTANTS: c_separator TYPE c VALUE ','.

DATA: gt_intern    TYPE kcde_intern,
      gwa_intern   TYPE kcde_intern_struc.


AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.

  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = 'P_FILE'
    IMPORTING
      file_name     = p_file.

START-OF-SELECTION.

  PERFORM upload.
  PERFORM fetch.
  PERFORM bdc.
*&---------------------------------------------------------------------*
*&      Form  UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload .
   DATA: lv_filename TYPE rlgrap-filename.
  DATA: lv_index TYPE i.
  FIELD-SYMBOLS: <field> TYPE ANY.

*  BREAK-POINT.

  lv_filename = p_file.

*  *Read the CSV file data to an internal table
  CALL FUNCTION 'KCD_CSV_FILE_TO_INTERN_CONVERT'
    EXPORTING
      i_filename      = lv_filename
      i_separator     = c_separator
    TABLES
      e_intern        = gt_intern
    EXCEPTIONS
      upload_csv      = 1
      upload_filetype = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
   LOOP AT gt_intern INTO gwa_intern.
    MOVE : gwa_intern-col TO lv_index.
    ASSIGN COMPONENT lv_index OF STRUCTURE wa_bank1 TO <field>.
    MOVE : gwa_intern-value TO <field>.
    AT END OF row.
      APPEND wa_bank1 TO it_bank1.
      CLEAR wa_bank1.
    ENDAT.
  ENDLOOP.

*  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
*    EXPORTING
*      i_field_seperator    = 'X'
*      i_line_header        = 'X'
*      i_tab_raw_data       = it_raw
*      i_filename           = p_file
*    TABLES
*      i_tab_converted_data = it_bank.

  DATA:v_char(20),
       v_char1(20).
  DATA:  lv_len TYPE i.
 delete it_bank1 index 1.
loop at it_bank1 into wa_bank1.

     IF NOT wa_bank1-t  IS INITIAL.
      wa_bsak-tbudat = wa_bank1-t.
      REPLACE ALL OCCURRENCES OF '-' IN WA_BSAK-TBUDAT WITH ''.
      CONDENSE WA_BSAK-TBUDAT.
      wa_bsak-budat = wa_bsak-tbudat.
      clear :lv_len.
    endif.

     IF NOT wa_bank1-s  IS INITIAL.
      lv_len = strlen( wa_bank1-s ).
      lv_len = lv_len - 12 .
      wa_bsak-bukrs  = wa_bank1-S+0(lv_len).
       clear :lv_len.
    endif.

     IF NOT wa_bank1-s  IS INITIAL.
      lv_len = strlen( wa_bank1-s ).
      lv_len = lv_len - 9 .
      wa_bsak-lifnr  = wa_bank1-S+4(lv_len).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = wa_bsak-lifnr
      IMPORTING
        output = wa_bsak-lifnr.

      clear :lv_len.
    endif.

      IF NOT wa_bank1-s  IS INITIAL.
      lv_len = strlen( wa_bank1-s ).
      lv_len = lv_len - 11.
      wa_bsak-zuonr  = wa_bank1-S+11(lv_len).

       clear :lv_len.
    endif.

    IF NOT wa_bank1-k  IS INITIAL.
      SHIFT wa_bank1-k LEFT DELETING LEADING '"'.
      SHIFT wa_bank1-k RIGHT DELETING TRAILING '"'.
      wa_bsak-dmbtr = wa_bank1-k.
    endif.

     IF wa_bank1-m CP '*HSBC*'.
       SHIFT wa_bank1-m RIGHT DELETING TRAILING '"'.
      SPLIT wa_bank1-m AT 'HSBC' INTO v_char v_char1.
    ENDIF.
*    SHIFT v_char1 LEFT DELETING LEADING 'N'.
*    SHIFT v_char1 LEFT DELETING LEADING 'R'.
*    SHIFT v_char1 RIGHT DELETING TRAILING '"'.


     wa_bsak-ref = v_char1.
   APPEND wa_bsak TO it_bsak.
   CLEAR: WA_BSAK.

  ENDLOOP.

ENDFORM.                    " UPLOAD
*&---------------------------------------------------------------------*
*&      Form  FETCH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fetch .

  IF it_bsak IS NOT INITIAL.

    SELECT bukrs lifnr zuonr gjahr belnr buzei xblnr dmbtr budat  FROM bsak
                                                     INTO TABLE it_bsak1
                                                     FOR ALL ENTRIES IN it_bsak
                                                     WHERE bukrs = it_bsak-bukrs
                                                     AND lifnr = it_bsak-lifnr
                                                     AND zuonr = it_bsak-zuonr
                                                      AND budat = it_bsak-budat.
*                                                     AND gjahr = it_bsak-GJAHR.

    SELECT bukrs lifnr zuonr gjahr belnr buzei xblnr dmbtr budat  FROM bsik
                                                    APPENDING TABLE it_bsak1
                                                     FOR ALL ENTRIES IN it_bsak
                                                     WHERE bukrs = it_bsak-bukrs
                                                     AND lifnr = it_bsak-lifnr
                                                     AND zuonr = it_bsak-zuonr
*                                                     AND gjahr = it_bsak-gjahr.
                                                     AND budat = it_bsak-budat.


  ENDIF.
ENDFORM.                    " FETCH
*&---------------------------------------------------------------------*
*&      Form  BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc .

  LOOP AT it_bsak1 INTO wa_bsak1.

    REFRESH:it_bdc.

    READ TABLE it_bsak INTO wa_bsak WITH KEY bukrs = wa_bsak1-bukrs
                                             lifnr = wa_bsak1-lifnr
                                             zuonr = wa_bsak1-zuonr
*                                             gjahr = wa_bsak1-gjahr.
                                             budat  = wa_bsak1-budat.

    IF sy-subrc EQ 0.


      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RF05L-BUZEI'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RF05L-BELNR'
                                    wa_bsak1-belnr.
      PERFORM bdc_field       USING 'RF05L-BUKRS'
                                     wa_bsak1-bukrs.
      PERFORM bdc_field       USING 'RF05L-GJAHR'
                                    wa_bsak1-gjahr.
      PERFORM bdc_field       USING 'RF05L-BUZEI' "line item comment
                                    wa_bsak1-BUZEI.
      PERFORM bdc_field       USING 'RF05L-XKKRE'
                                    'X'.
      PERFORM bdc_dynpro      USING 'SAPMF05L' '0302'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'BSEG-ZUONR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=AE'.
      PERFORM bdc_field       USING 'BSEG-ZUONR'
                                    wa_bsak-ref.

        perform bdc_dynpro      using 'SAPLKACB' '0002'.
      perform bdc_field       using 'BDC_CURSOR'
                              'COBL-PRCTR'.
      perform bdc_field       using 'BDC_OKCODE'
                              '=ENTE'.
*      PERFORM bdc_transaction USING 'FB09'.
   endif.
  CALL TRANSACTION 'FB09' USING it_bdc MODE 'A' UPDATE 'S'.
  ENDLOOP.

  LOOP AT it_bsak1 INTO wa_bsak1.

    REFRESH:it_bdc.

    READ TABLE it_bsak INTO wa_bsak WITH KEY bukrs = wa_bsak1-bukrs
                                             lifnr = wa_bsak1-lifnr
                                             zuonr = wa_bsak1-zuonr
*                                             gjahr = wa_bsak1-gjahr.
                                             budat  = wa_bsak1-budat.
    if sy-subrc = 0.

      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RF05L-XKSAK'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RF05L-BELNR'
                                    wa_bsak1-belnr.
      PERFORM bdc_field       USING 'RF05L-BUKRS'
                                    wa_bsak1-bukrs.
      PERFORM bdc_field       USING 'RF05L-GJAHR'
                                    wa_bsak1-gjahr.
      PERFORM bdc_field       USING 'RF05L-BUZEI'
                                    ''.
      PERFORM bdc_field       USING 'RF05L-XKSAK'
                                    'X'.
      PERFORM bdc_dynpro      USING 'SAPMF05L' '0300'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'BSEG-ZUONR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=AE'.
      PERFORM bdc_field       USING 'BSEG-ZUONR'
                                    wa_bsak-ref.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=AE'.

      perform bdc_dynpro      using 'SAPLKACB' '0002'.
      perform bdc_field       using 'BDC_CURSOR'
                              'COBL-PRCTR'.
      perform bdc_field       using 'BDC_OKCODE'
                              '=ENTE'.

*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'RF05L-BELNR'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
*      PERFORM bdc_field       USING 'RF05L-BELNR'
*                                    wa_bsak1-belnr.       "'2000000033'.
*      PERFORM bdc_field       USING 'RF05L-BUKRS'
*                                    wa_bsak1-bukrs.      "'1000'.
*      PERFORM bdc_field       USING 'RF05L-GJAHR'
*                                    wa_bsak1-gjahr.      "'2016'.
*      PERFORM bdc_field       USING 'RF05L-BUZEI'
*                                    wa_bsak1-buzei.      "'1'.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0302'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'BSEG-ZUONR'.
*      PERFORM bdc_field       USING 'BSEG-ZUONR'
*                                    wa_bsak-ref.            "'13073'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '=AE'.
*
    ENDIF.
    CALL TRANSACTION 'FB09' USING it_bdc MODE 'A' UPDATE 'S'.
****Addded changes for GL account by Carina Jose on 03.07.2019
*    IF sy-subrc EQ 0.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'RF05L-XKSAK'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
*      PERFORM bdc_field       USING 'RF05L-BELNR'
*                                    wa_bsak1-belnr.
*      PERFORM bdc_field       USING 'RF05L-BUKRS'
*                                    wa_bsak1-bukrs.
*      PERFORM bdc_field       USING 'RF05L-GJAHR'
*                                    wa_bsak1-gjahr.
*      PERFORM bdc_field       USING 'RF05L-BUZEI'
*                                    ' '.
*      PERFORM bdc_field       USING 'RF05L-XKSAK'   "============================
*                                    'X'.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0300'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'BSEG-ZUONR'.
**      PERFORM bdc_field       USING 'BDC_OKCODE'
**                                    '=AE'.
*      PERFORM bdc_field       USING 'BSEG-ZUONR'
*                                    wa_bsak-ref.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '=AE'.
*    ENDIF.
*    CALL TRANSACTION 'FB09' USING it_bdc MODE 'A' UPDATE 'S'.
****End of changes by Carina Jose on 03.07.2019

  ENDLOOP.

ENDFORM.                    " BDC


FORM bdc_dynpro USING program screen.

  wa_bdc-program = program.
  wa_bdc-dynpro = screen.
  wa_bdc-dynbegin = 'X'.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.

ENDFORM.

FORM bdc_field USING field value.

  wa_bdc-fnam = field.
  wa_bdc-fval = value.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.

ENDFORM.
*ENDFORM.
