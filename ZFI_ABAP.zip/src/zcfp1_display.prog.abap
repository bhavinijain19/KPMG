*&---------------------------------------------------------------------*
*& Report ZCFP1_DISPLAY
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZCFP1_DISPLAY.
TABLES :  zfi_partner_data.

DATA : it_fcat      TYPE slis_t_fieldcat_alv,
       wa_fcat      TYPE slis_fieldcat_alv,
       fs_layout    TYPE slis_layout_alv,
       t_listheader TYPE slis_t_listheader WITH HEADER LINE,
       t_event      TYPE slis_t_event WITH HEADER LINE.
*       wa_fcat  eldcat,

CONSTANTS : c_x           TYPE c VALUE 'X',
            c_gtfinal(10) TYPE c VALUE 'GT_FINAL'.

CONSTANTS : c_v3 TYPE periv VALUE 'V3'.
DATA : w_fy(4) TYPE c.
DATA : w_lastfy(4) TYPE c.
*&---------------------------------------------------------------------*
*  Data Declaration
*&---------------------------------------------------------------------*
TYPES : BEGIN OF ty_final,

          bukrs          TYPE zfi_cheq_detail-bukrs,
          kunnr          TYPE zfi_cheq_detail-kunnr,
          zsrno          type zfi_partner_data-zsrno,
          zsrno1          type zfi_partner_data-zsrno1,
          zlimit         TYPE zfi_partner_data-zlimit,
          zenhancement   TYPE zfi_partner_data-zenhancement,
          zdecrease      TYPE zfi_partner_data-zdecrease,
          zchange_dt     TYPE zfi_partner_data-zchange_dt,
          zbank          TYPE zfi_partner_data-zbank,
          zfrom_date     TYPE zfi_partner_data-zfrom_date,
          zto_date       TYPE zfi_partner_data-zto_date,
          zpulling_by    TYPE zfi_partner_data-zpulling_by,
          zagr_status    TYPE zfi_partner_data-zagr_status,
          zagr_date      TYPE zfi_partner_data-zagr_date,
          zagr_exp_date  TYPE zfi_partner_data-zagr_exp_date,
          zlog_date(10)  TYPE c,
          zlog_time(8)   TYPE c,
          zlog_user(12)  TYPE c,
          zagr_ren_dt    TYPE zfi_partner_data-zagr_ren_dt,
          zinterest_rate TYPE zfi_partner_data-zinterest_rate,
          zcredit_period TYPE zfi_partner_data-zcredit_period,
          zacc_status    TYPE zfi_partner_data-zacc_status,
          zfees          TYPE zfi_partner_data-zfees,
          zcash_disc     TYPE zfi_cheq_detail-zcash_disc,
          zchq_status    TYPE zfi_cheq_detail-zchq_status,
          zpayee_name    TYPE zfi_cheq_detail-zpayee_name,
          zbank_name     TYPE zfi_cheq_detail-zbank_name,
          zchq_1         TYPE zfi_cheq_detail-zchq_1,
          zchq_2         TYPE zfi_cheq_detail-zchq_2,
          zchq_3         TYPE zfi_cheq_detail-zchq_3,
          zdate          TYPE zfi_cheq_detail-zdate,
          zmat           TYPE zfi_cheq_detail-zmat,
          zdate_chk_dep  TYPE zfi_cheq_detail-zdate_chk_dep,
          zamt_chk_dep   TYPE zfi_cheq_detail-zamt_chk_dep,

          total          TYPE zfi_partner_data-zlimit,
          curyr_aud      TYPE c,
          lastyr_aud     TYPE c,
          curyr_itr      TYPE c,
          lastyr_itr     TYPE c,
        END OF ty_final.

DATA : gt_final TYPE TABLE OF ty_final,
       wa_final TYPE ty_final.

*&---------------------------------------------------------------------*
* Selection Screen
*&---------------------------------------------------------------------*

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : so_bukrs FOR  zfi_partner_data-bukrs,
                 so_kunnr FOR  zfi_partner_data-kunnr.
SELECTION-SCREEN END OF BLOCK b1.

*&---------------------------------------------------------------------*
* START OF SELECTION
*&---------------------------------------------------------------------*

START-OF-SELECTION.

  PERFORM select_data.
  PERFORM build_fieldcatlog.
  PERFORM display_data.
*&---------------------------------------------------------------------*
* FORMS
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SELECT_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM select_data .
  DATA : l_fy TYPE i.
  SELECT * FROM zfi_partner_data INTO TABLE @DATA(lt_part) WHERE bukrs IN @so_bukrs AND kunnr IN @so_kunnr.
  SELECT * FROM zfi_cheq_detail INTO TABLE @DATA(lt_cheq) WHERE bukrs IN @so_bukrs AND kunnr IN @so_kunnr.
  SELECT * FROM zfi_itr INTO TABLE @DATA(lt_itr) WHERE bukrs IN @so_bukrs AND kunnr IN @so_kunnr.
  IF sy-subrc = 0.
    SORT lt_itr BY bukrs kunnr zyear DESCENDING.
*    DELETE ADJACENT DUPLICATES FROM lt_itr COMPARING bukrs kunnr.
  ENDIF.

  CLEAR w_fy.
  CALL FUNCTION 'GM_GET_FISCAL_YEAR'
    EXPORTING
      i_date                     = sy-datum
      i_fyv                      = 'V3'
    IMPORTING
      e_fy                       = w_fy
    EXCEPTIONS
      fiscal_year_does_not_exist = 1
      not_defined_for_date       = 2
      OTHERS                     = 3.
  IF sy-subrc = 0.
* Implement suitable error handling here
    MOVE w_fy TO l_fy.
    l_fy = l_fy - 1.
    WRITE l_fy TO w_lastfy.

  ENDIF.
  SORT lt_part BY bukrs kunnr zsrno DESCENDING zbank zsrno1.
*  DELETE ADJACENT DUPLICATES FROM lt_part COMPARING bukrs kunnr zsrno zbank.

  DATA : l_new   TYPE c,
         l_total TYPE zfi_partner_data-zlimit.
  LOOP AT lt_part INTO DATA(ls_part).

    AT NEW zsrno.
      l_new = 'X'.
    ENDAT.
    MOVE-CORRESPONDING ls_part TO wa_final.

    CLEAR : wa_final-zlog_date, wa_final-zlog_time, wa_final-zlog_user.
    CONCATENATE ls_part-zlog_date+6(2) ls_part-zlog_date+4(2) ls_part-zlog_date+0(4) INTO wa_final-zlog_date SEPARATED BY '.'.
    CONCATENATE ls_part-zlog_time+0(2) ls_part-zlog_time+2(2) ls_part-zlog_time+4(2) INTO wa_final-zlog_time SEPARATED BY ':'.
    wa_final-zlog_user = ls_part-zlog_user.

    READ TABLE lt_cheq INTO DATA(ls_cheq) WITH KEY bukrs = ls_part-bukrs kunnr = ls_part-kunnr.
    IF sy-subrc IS INITIAL.
      MOVE-CORRESPONDING ls_cheq TO wa_final.
    ENDIF.

    READ TABLE lt_itr INTO DATA(ls_itr) WITH KEY bukrs = ls_part-bukrs kunnr = ls_part-kunnr zyear = w_fy.
    IF sy-subrc IS INITIAL.
      IF ls_itr-zacknow_itr IS NOT INITIAL.
        wa_final-curyr_itr = 'Y'.
        wa_final-curyr_aud = 'Y'.
      ELSE.
        wa_final-curyr_itr = 'N'.
        wa_final-curyr_aud = 'N'.
      ENDIF.
    ENDIF.


    READ TABLE lt_itr INTO ls_itr WITH KEY bukrs = ls_part-bukrs kunnr = ls_part-kunnr zyear = w_lastfy.
    IF sy-subrc IS INITIAL.
      IF ls_itr-zacknow_itr IS NOT INITIAL.
        wa_final-lastyr_itr = 'Y'.
        wa_final-lastyr_aud = 'Y'.
      ELSE.
        wa_final-lastyr_itr = 'N'.
        wa_final-lastyr_aud = 'N'.
      ENDIF.
    ENDIF.

    IF l_new = 'X'.
      CLEAR l_total.
      wa_final-total = wa_final-zlimit + wa_final-zenhancement - wa_final-zdecrease.
      l_total = wa_final-total.
    ELSE.
      wa_final-total = l_total + wa_final-zenhancement - wa_final-zdecrease.
      l_total = wa_final-total.
    ENDIF.

    APPEND wa_final TO gt_final.

    CLEAR : wa_final, ls_part, ls_itr, ls_cheq, l_new.
  ENDLOOP.
  SORT gt_final BY bukrs kunnr zsrno zbank zsrno1 DESCENDING.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .
  fs_layout-colwidth_optimize = c_x.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-repid
      i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout              = fs_layout
      it_fieldcat            = it_fcat[]
      it_events              = t_event[]
      i_save                 = 'X'
    TABLES
      t_outtab               = gt_final
    EXCEPTIONS
      program_error          = 0
      OTHERS                 = 0.
  IF sy-subrc <> 0.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCATLOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_fieldcatlog .
  PERFORM  fcadt USING : 'KUNNR'        text-001 c_gtfinal '',
                         'ZLIMIT'       text-002 c_gtfinal '',
                         'ZENHANCEMENT' text-003 c_gtfinal '',
                         'ZDECREASE'    text-004 c_gtfinal '',
                         'ZCHANGE_DT'   text-005 c_gtfinal '',
                         'TOTAL'        text-006 c_gtfinal '',
                         'ZBANK'        text-007 c_gtfinal '',
                         'ZFROM_DATE'   text-008 c_gtfinal '',
                         'ZTO_DATE'     text-009 c_gtfinal '',
                         'ZCASH_DISC'   text-010 c_gtfinal '',
                         'ZPULLING_BY'  text-011 c_gtfinal '',
                         'CURYR_AUD'    text-012 c_gtfinal '',
                         'LASTYR_AUD'   text-013 c_gtfinal '',
                         'CURYR_ITR'    text-014 c_gtfinal '',
                         'LASTYR_ITR'   text-015 c_gtfinal '',
                         'ZAGR_STATUS'  text-016 c_gtfinal '',
                         'ZAGR_DATE'    text-017 c_gtfinal '',
                         'ZAGR_EXP_DATE' text-018 c_gtfinal '',
                         'ZCHQ_STATUS'   text-019 c_gtfinal '',
                         'ZPAYEE_NAME'   text-020 c_gtfinal '',
                         'ZBANK_NAME'    text-021 c_gtfinal '',
                         'ZCHQ_1'        text-022 c_gtfinal '',
                         'ZCHQ_2'        text-023 c_gtfinal '',
                         'ZCHQ_3'        text-024 c_gtfinal '',
                         'ZDATE'         text-025 c_gtfinal '',
                         'ZAMT'          text-026 c_gtfinal '',
                         'ZDATE_CHK_DEP' text-027 c_gtfinal '',
                         'ZAMT_CHK_DEP'  text-028 c_gtfinal '',
                         'ZLOG_DATE'     text-029 c_gtfinal '',
                         'ZLOG_TIME'     text-030 c_gtfinal '',
                         'ZLOG_USER'     text-031 c_gtfinal '',
                         'ZINTEREST_RATE' text-032 c_gtfinal '',
                         'ZCREDIT_PERIOD' text-033 c_gtfinal '',
                         'ZACC_STATUS'    text-034 c_gtfinal '',
                         'ZFEES'          text-035 c_gtfinal '',
                         'ZAGR_REN_DT'    text-036 c_gtfinal ''.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FCADT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0218   text
*      -->P_0219   text
*      -->P_0220   text
*      -->P_0221   text
*----------------------------------------------------------------------*
FORM fcadt  USING    fname
                     seltxt
                     tabname
                     no_out.
  CLEAR wa_fcat.
  wa_fcat-fieldname = fname.
  wa_fcat-seltext_l = seltxt.
  wa_fcat-tabname = tabname.
  wa_fcat-no_out = no_out.

  APPEND wa_fcat TO it_fcat.

ENDFORM.

FORM top_of_page.
  DATA :        gt_header TYPE slis_t_listheader,
                gs_header TYPE slis_listheader.


  DATA : gs_t247 LIKE t247.

  DATA : mon(2)  TYPE n,
         year(4) TYPE n.
*  REFRESH gt_header.
  IF gt_header IS INITIAL.
    gs_header-typ  = 'S'.
    gs_header-info = 'Channel Financing Partner data'.
    APPEND gs_header TO gt_header.
    CLEAR gs_header.



    CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
      EXPORTING
        it_list_commentary = gt_header.

  ENDIF.
ENDFORM.                    "top-of-page
