*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_CRM_LEDGER_CUSTTOP.           " Global Declarations
  INCLUDE LZFI_CRM_LEDGER_CUSTUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_CRM_LEDGER_CUSTF...           " Subroutines
* INCLUDE LZFI_CRM_LEDGER_CUSTO...           " PBO-Modules
* INCLUDE LZFI_CRM_LEDGER_CUSTI...           " PAI-Modules
* INCLUDE LZFI_CRM_LEDGER_CUSTE...           " Events
* INCLUDE LZFI_CRM_LEDGER_CUSTP...           " Local class implement.
* INCLUDE LZFI_CRM_LEDGER_CUSTT99.           " ABAP Unit tests
