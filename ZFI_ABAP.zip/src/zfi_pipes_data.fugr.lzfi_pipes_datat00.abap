*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PIPES_DATA..................................*
DATA:  BEGIN OF STATUS_ZFI_PIPES_DATA                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PIPES_DATA                .
CONTROLS: TCTRL_ZFI_PIPES_DATA
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PIPES_DATA                .
TABLES: ZFI_PIPES_DATA                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
