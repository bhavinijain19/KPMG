*&---------------------------------------------------------------------*
*& Include          ZFI_ASSET_ACQ_POST_TOP
*&---------------------------------------------------------------------*

TYPES: BEGIN OF ty_excel,
         comp_code       TYPE bukrs,                                " Company Code
         doc_date        TYPE char10,                               " Doc Date (DD.MM.YYYY)
         pstng_date      TYPE char10,                               " Posting Date (DD.MM.YYYY)
         doc_type        TYPE blart,                                " Doc Type
         assetmaino      TYPE char12,                               " Asset Main Number
         assetsubno      TYPE char4,                                " Asset Sub Number
         assettrtyp      TYPE bf_anbwa,                             " Asset Transaction Type
         amount          TYPE bf_anbtr,                             " Amount
         currency        TYPE waers,                                " Currency
         quantity        TYPE menge_d,                              " Quantity
         base_uom        TYPE meins,                                " UoM
         valuedate       TYPE char10,                               " Value Date (DD.MM.YYYY)
         offset_account  TYPE hkont,                                " Offsetting Account
         bus_area        TYPE gsber,                                " Business Area
         descript        TYPE txa50_anlt,                           " Description
         header_txt      TYPE bktxt,                                " Header Text
         ref_doc_no      TYPE xblnr,                                " Reference Doc Number
         ref_doc_no_long TYPE xblnr_long,                           " Reference Doc Number Long
         item_text       TYPE sgtxt,                                " Item Text
       END OF ty_excel.

DATA : gt_excel TYPE STANDARD TABLE OF ty_excel,
       gs_excel TYPE ty_excel.

TYPES: BEGIN OF ty_results.
         INCLUDE TYPE ty_excel. " This brings in all your Excel fields
TYPES:   status  TYPE icon_d,    " Icon for Success/Error
         message TYPE bapi_msg,  " Final readable error message
       END OF ty_results.

DATA: gt_result TYPE TABLE OF ty_results,
      gs_result TYPE ty_results.

DATA: lo_alv TYPE REF TO cl_salv_table.
