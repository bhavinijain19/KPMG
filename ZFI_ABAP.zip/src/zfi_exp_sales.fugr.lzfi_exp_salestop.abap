FUNCTION-POOL ZFI_EXP_SALES              MESSAGE-ID SV.

* INCLUDE LZFI_EXP_SALESD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_EXP_SALEST00                       . "view rel. data dcl.
