FUNCTION ZMM_LICENSE_UPDATE.
*"----------------------------------------------------------------------
*"*"Update Function Module:
*"
*"*"Local Interface:
*"  TABLES
*"      T_LIC_I STRUCTURE  ZMM_LICENSE OPTIONAL
*"      T_LIC_U STRUCTURE  ZMM_LICENSE OPTIONAL
*"----------------------------------------------------------------------

* insert
  IF NOT t_lic_i[] IS INITIAL.
    INSERT zmm_license FROM TABLE t_lic_i.
    IF sy-subrc NE 0.
      MESSAGE a007(zsd).
    ENDIF.
  ENDIF.

* update
  IF NOT t_lic_u[] IS INITIAL.
    UPDATE zmm_license FROM TABLE t_lic_u.
    IF sy-subrc NE 0.
      MESSAGE a007(zsd).
    ENDIF.
  ENDIF.


ENDFUNCTION.
