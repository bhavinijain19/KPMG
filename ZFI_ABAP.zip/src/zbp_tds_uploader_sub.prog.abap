*&---------------------------------------------------------------------*
*& Include          ZBP_TDS_UPLOADER_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form GET_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_data .

  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
    EXPORTING
      filename                = p_file
      i_begin_col             = 1
      i_begin_row             = 2
      i_end_col               = 16
      i_end_row               = 9999
    TABLES
      intern                  = gt_out
    EXCEPTIONS
      inconsistent_parameters = 1
      upload_ole              = 2
      OTHERS                  = 3.

  LOOP AT gt_out INTO gs_out.
    lv_idx = gs_out-col.
    ASSIGN COMPONENT lv_idx OF STRUCTURE gs_final TO <fs_field>.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.
    ASSIGN COMPONENT 'VALUE' OF STRUCTURE gs_out TO <fs_data>.
    IF sy-subrc NE 0.
      EXIT.
    ELSE.
      <fs_field> = <fs_data>.
    ENDIF.

    AT END OF row.
      CLEAR lv_idx.
      APPEND gs_final TO gt_final.
      CLEAR gs_final.
    ENDAT.
  ENDLOOP.

  IF gt_final IS NOT INITIAL.

**    DATA: lt_error_vendors TYPE TABLE OF lifnr. " To store vendors without PAN

    LOOP AT gt_final ASSIGNING FIELD-SYMBOL(<fs_final>).
      <fs_final>-accno = |{ <fs_final>-accno ALPHA = IN }|.
    ENDLOOP.

    SELECT lifnr, j_1ipanno FROM lfa1 INTO TABLE @DATA(lt_pan)
      FOR ALL ENTRIES IN @gt_final WHERE lifnr = @gt_final-accno.
    IF sy-subrc NE 0.
      CLEAR lt_pan.
    ENDIF.

    LOOP AT gt_final ASSIGNING <fs_final>.

      " Check if PAN exists for this vendor
      READ TABLE lt_pan WITH KEY lifnr = <fs_final>-accno ASSIGNING FIELD-SYMBOL(<fs_pan>).
      IF sy-subrc <> 0 OR <fs_pan>-j_1ipanno IS INITIAL.
        <fs_final>-status = 'Error: Missing PAN'.
        CONTINUE.
      ELSEIF <fs_pan>-j_1ipanno IS NOT INITIAL.
        gs_tds-pan_no  = <fs_pan>-j_1ipanno.
      ENDIF.

      REPLACE ALL OCCURRENCES OF ',' IN <fs_final>-fiwtin_exem_thr WITH ''.
      MOVE-CORRESPONDING <fs_final> TO gs_tds.

      gs_tds-accno = |{ gs_tds-accno ALPHA = IN }|.
      gs_tds-koart = 'K'.

      gs_tds-wt_exdf = |{ <fs_final>-wt_exdf+6(4) }{ <fs_final>-wt_exdf+3(2) }{ <fs_final>-wt_exdf+0(2) }|.
      gs_tds-wt_exdt = |{ <fs_final>-wt_exdt+6(4) }{ <fs_final>-wt_exdt+3(2) }{ <fs_final>-wt_exdt+0(2) }|.

      APPEND gs_tds TO gt_tds.
      <fs_final>-status = 'Success: Data updated successfully'.
      CLEAR gs_tds.
    ENDLOOP.

    " Update only if we have valid records
    IF gt_tds IS NOT INITIAL.
      CALL FUNCTION 'J_1ITAN_EXEM_SAVE'
        TABLES
          it_tan_exem = gt_tds.

      IF sy-subrc = 0.
        MESSAGE 'Data updated successfully' TYPE 'S'.
      ENDIF.
    ENDIF.

    IF gt_final IS NOT INITIAL.
      WRITE: / 'Processing Results:'.
      ULINE.
      LOOP AT gt_final INTO DATA(ls_disp).
        WRITE: / ls_disp-accno, ls_disp-status.
      ENDLOOP.
    ENDIF.

  ELSE.
    MESSAGE 'Data not found!' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form display_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM display_data .

  TRY.
      CALL METHOD cl_salv_table=>factory
        IMPORTING
          r_salv_table = lo_alv
        CHANGING
          t_table      = gt_final.
    CATCH cx_salv_msg .
  ENDTRY.

  lo_columns = lo_alv->get_columns( ).
  lo_columns->set_optimize('X').
  lo_alv->get_functions( )->set_all( ).

  TRY.
      lo_column ?= lo_columns->get_column( 'WT_EXDF' ).
      lo_column->set_long_text( 'Exemption From' ).
      lo_column->set_medium_text( 'Exemption From' ).
      lo_column->set_short_text( 'Exm. From' ).

      lo_column ?= lo_columns->get_column( 'WT_EXDT' ).
      lo_column->set_long_text( 'Exemption To' ).
      lo_column->set_medium_text( 'Exemption To' ).
      lo_column->set_short_text( 'Exm. To' ).

      lo_column ?= lo_columns->get_column( 'FIWTIN_EXEM_THR' ).
      lo_column->set_long_text( 'Exemption thr amm' ).
      lo_column->set_medium_text( 'Exemption amm' ).
      lo_column->set_short_text( 'Exmpt. amm' ).

      lo_column ?= lo_columns->get_column( 'SECCODE' ).
      lo_column->set_long_text( 'Section Group' ).
      lo_column->set_medium_text( 'Section Group' ).
      lo_column->set_short_text( 'Sect. Grp.' ).
*
*      lo_column ?= lo_columns->get_column( 'STATUS' ).
*      lo_column->set_long_text( 'Status' ).
*      lo_column->set_medium_text( 'Status' ).
*      lo_column->set_short_text( 'Status' ).

    CATCH cx_salv_not_found.
  ENDTRY.
  lo_alv->display( ).

ENDFORM.
