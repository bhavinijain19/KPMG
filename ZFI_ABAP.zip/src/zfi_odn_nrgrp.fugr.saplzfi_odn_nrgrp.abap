*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_ODN_NRGRPTOP.                 " Global Declarations
  INCLUDE LZFI_ODN_NRGRPUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_ODN_NRGRPF...                 " Subroutines
* INCLUDE LZFI_ODN_NRGRPO...                 " PBO-Modules
* INCLUDE LZFI_ODN_NRGRPI...                 " PAI-Modules
* INCLUDE LZFI_ODN_NRGRPE...                 " Events
* INCLUDE LZFI_ODN_NRGRPP...                 " Local class implement.
* INCLUDE LZFI_ODN_NRGRPT99.                 " ABAP Unit tests
  INCLUDE LZFI_ODN_NRGRPF00                       . " subprograms
  INCLUDE LZFI_ODN_NRGRPI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
