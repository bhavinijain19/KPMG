*&---------------------------------------------------------------------*
*& Include          ZFI_ASSET_ACQ_POST_MAIN
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form upload_excel
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM upload_excel.

  DATA: gt_raw     TYPE solix_tab,
        gv_bin_len TYPE i.

  DATA: lv_xstring    TYPE xstring,
        lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
        lv_docname    TYPE string,
        lt_worksheets TYPE STANDARD TABLE OF string,
        lv_worksheet  TYPE string,
        lv_lines      TYPE i,
        lo_data       TYPE REF TO data.

  DATA: lv_fname   TYPE string.

  FIELD-SYMBOLS: <lt_data>      TYPE STANDARD TABLE,
                 <ls_data>      TYPE any,
                 <lv_value_tmp> TYPE any,
                 <lv_value>     TYPE any.
  lv_fname = p_file.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  CREATE OBJECT lo_excel
    EXPORTING
      document_name = lv_docname
      xdocument     = lv_xstring.

  IF lo_excel IS NOT INITIAL.
    lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
      IMPORTING
        worksheet_names = lt_worksheets ).
  ENDIF.

  DESCRIBE TABLE lt_worksheets LINES lv_lines.

  IF lt_worksheets[] IS NOT INITIAL.
    READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
    lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
    ASSIGN lo_data->* TO <lt_data>.
  ENDIF.

  IF <lt_data> IS ASSIGNED.
    LOOP AT <lt_data> ASSIGNING <ls_data> FROM 2.
      CLEAR: gs_excel.
      DO.
        ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data> TO <lv_value_tmp>.
        IF sy-subrc EQ 0.
          ASSIGN COMPONENT sy-index OF STRUCTURE gs_excel TO <lv_value>.
          IF sy-subrc EQ 0.
            <lv_value> = <lv_value_tmp>.
          ENDIF.
        ELSE.
          EXIT.
        ENDIF.
      ENDDO.
      IF gs_excel IS NOT INITIAL.
        APPEND gs_excel TO gt_excel.
      ENDIF.
    ENDLOOP.
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*& Form process_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM process_data.

  DATA: ls_general_posting TYPE bapifapo_gen_info,
        ls_acquisition     TYPE bapifapo_acq,
*        ls_acct_assignment TYPE bapi_fass_acct_assign,
        ls_further_posting TYPE bapifapo_add_info,
        lt_prop_values     TYPE TABLE OF bapifapo_areavalues_prop,
        lt_return          TYPE TABLE OF bapiret2.

  LOOP AT gt_excel INTO gs_excel.

    CLEAR: ls_general_posting, ls_acquisition, lt_return.

    " Mapping from Excel structure to BAPI structure
*    ls_general_posting-username   = sy-uname.
    ls_general_posting-comp_code  = gs_excel-comp_code.
    ls_general_posting-doc_type   = gs_excel-doc_type.
    ls_general_posting-assetmaino = |{ gs_excel-assetmaino ALPHA = IN }|.
    ls_general_posting-assetsubno = |{ gs_excel-assetsubno ALPHA = IN }|.
    ls_general_posting-assettrtyp = gs_excel-assettrtyp.
    ls_general_posting-doc_date   = |{ gs_excel-doc_date+6(4) }{ gs_excel-doc_date+3(2) }{ gs_excel-doc_date+0(2) }|.
    ls_general_posting-pstng_date = |{ gs_excel-pstng_date+6(4) }{ gs_excel-pstng_date+3(2) }{ gs_excel-pstng_date+0(2) }|.

    " 2. ACQUISITIONDATA Mapping
    ls_acquisition-amount         = gs_excel-amount.
    ls_acquisition-currency       = gs_excel-currency.
    ls_acquisition-quantity       = gs_excel-quantity.
    ls_acquisition-base_uom       = gs_excel-base_uom.
    ls_acquisition-offset_account = |{ gs_excel-offset_account ALPHA = IN }|.
    ls_acquisition-bus_area       = gs_excel-bus_area.
    ls_acquisition-descript       = gs_excel-descript.
    ls_acquisition-valuedate      = |{ gs_excel-valuedate+6(4) }{ gs_excel-valuedate+3(2) }{ gs_excel-valuedate+0(2) }|.

    " 3. FURTHERPOSTINGDATA Mapping
    ls_further_posting-header_txt      = gs_excel-header_txt.
    ls_further_posting-ref_doc_no      = gs_excel-ref_doc_no.
    ls_further_posting-ref_doc_no_long = gs_excel-ref_doc_no_long.
    ls_further_posting-item_text       = gs_excel-item_text.

    CALL FUNCTION 'BAPI_ASSET_ACQUISITION_POST'
      EXPORTING
        generalpostingdata = ls_general_posting
        acquisitiondata    = ls_acquisition
        furtherpostingdata = ls_further_posting
      TABLES
        propareavalues     = lt_prop_values
        return_all         = lt_return.

    gs_result = CORRESPONDING ty_excel( gs_excel ).

    IF NOT line_exists( lt_return[ type = 'E' ] ).
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait = 'X'.

      READ TABLE lt_return INTO DATA(ls_success) WITH KEY type = 'S' id = 'RW' number = '605'.
      IF sy-subrc = 0.
        " MESSAGE_V2 usually holds the document number in this BAPI context
        DATA(lv_doc_no) = ls_success-message_v2.
        gs_result-message = |Document { lv_doc_no } Posted Successfully.|.
      ELSE.
        gs_result-message = |Posted Successfully.|.
      ENDIF.
      gs_result-status  = '@0V@'. " Green Check Icon
    ELSE.

      READ TABLE lt_return INTO DATA(ls_err) WITH KEY type = 'E'.

      MESSAGE ID ls_err-id TYPE ls_err-type NUMBER ls_err-number
              WITH ls_err-message_v1 ls_err-message_v2
                   ls_err-message_v3 ls_err-message_v4
              INTO gs_result-message.

      gs_result-status  = '@0W@'.
    ENDIF.

    APPEND gs_result TO gt_result.
  ENDLOOP.

  TRY.
      cl_salv_table=>factory(
        IMPORTING
          r_salv_table = lo_alv
        CHANGING
          t_table      = gt_result ). " Ensure this matches your table name

      lo_alv->get_columns( )->set_optimize( abap_true ).
      lo_alv->display( ).
    CATCH cx_salv_msg.
  ENDTRY.


ENDFORM.
*&---------------------------------------------------------------------*
*& Form download_template
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM download_template .

  DATA: lv_fname TYPE string,
        lv_path  TYPE string,
        lv_full  TYPE string.

  TYPES: BEGIN OF ty_template,
           col TYPE string,
         END OF ty_template.
  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  CLEAR lt_template.

  CONCATENATE 'Company Code' 'Doc Date' 'Posting Date' 'Doc Type' 'Asset Number' 'Sub Number' 'Trans. Type' 'Amount'
              'Currency' 'Quantity' 'Unit' 'Value Date' 'Offset Account' 'Bus. Area' 'Description' 'Header Text'
              'Reference' 'Ref Long' 'Item Text'
      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
  APPEND ls_template TO lt_template.

  "Save dialog & download"
  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING default_extension = 'xls'
              default_file_name = COND string(
                 WHEN r_down = 'X' THEN 'Asset_Acq_post.xls' )
    CHANGING  filename = lv_fname path = lv_path fullpath = lv_full ).

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  cl_gui_frontend_services=>gui_download(
    EXPORTING filename = lv_full filetype = 'ASC' write_field_separator = abap_true
    CHANGING  data_tab = lt_template ).

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.


ENDFORM.
