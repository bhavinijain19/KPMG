*----------------------------------------------------------------------*
***INCLUDE ZFI_CRM_CUSTLEDGER2CPI_F01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form get_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_data .
  DATA(lv_today)      = sy-datum.
  DATA(lv_start_date) = cl_abap_context_info=>get_system_date( ) - 60.

  " Get last day of previous month for Opening Balance BAPI
  DATA(lv_key_date) = cl_abap_context_info=>get_system_date( ).
  lv_key_date+6(2) = '01'.
  lv_key_date      = lv_key_date - 1.

****  SELECT bukrs, "kunnr,
****    "umskz,
****    zuonr, belnr, budat, xblnr, blart, shkzg, dmbtr, sgtxt
****    FROM bsis_view
****    WHERE bukrs IN @s_bukrs
****      "AND kunnr IN @s_kunnr
****      AND budat BETWEEN @lv_start_date AND @sy-datum
****    ORDER BY
****    "kunnr,
****    budat
****    INTO TABLE @DATA(it_ledger_src).
****
****  IF it_ledger_src IS INITIAL.
****    MESSAGE 'No ledger data found.' TYPE 'S' DISPLAY LIKE 'E'. RETURN.
****  ENDIF.
****
****  SELECT companycode, accountingdocument, profitcenter, assignmentreference
****    FROM i_operationalacctgdocitem
****    FOR ALL ENTRIES IN @it_ledger_src
****    WHERE companycode = @it_ledger_src-bukrs
****      AND accountingdocument = @it_ledger_src-belnr
****      AND profitcenter <> ''
****    INTO TABLE @DATA(it_cds_details).

****LOOP AT it_ledger_src ASSIGNING FIELD-SYMBOL(<src>).
****
****    " Opening Balance Logic (Per Customer)
****    AT NEW kunnr.
****      IF p_open = 'X'.
****        CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'
****          EXPORTING
****            companycode = <src>-bukrs
****            customer    = <src>-kunnr
****            keydate     = lv_key_date
****          TABLES
****            keybalance  = it_open.
****
****        DATA(wa_bal) = VALUE #( it_open[ 1 ] OPTIONAL ).
****        IF wa_bal IS NOT INITIAL AND wa_bal-lc_bal <> 0.
****          APPEND VALUE #(
****            companycode        = <src>-bukrs
****            distributorsynchid = |{ <src>-kunnr ALPHA = OUT }|
****            postingdate        = lv_key_date
****            transactiontype    = 'Opening Balance'
****            dramount           = COND #( WHEN wa_bal-lc_bal > 0 THEN wa_bal-lc_bal ELSE 0 )
****            cramount           = COND #( WHEN wa_bal-lc_bal < 0 THEN abs( wa_bal-lc_bal ) ELSE 0 )
****          ) TO lt_cpi_payload.
****        ENDIF.
****      ENDIF.
****    ENDAT.
****
****    " Map Ledger Item
****    APPEND VALUE #(
****      companycode        = <src>-bukrs
****      postingdate        = <src>-budat
****      narration          = <src>-sgtxt
****      refnumber          = <src>-xblnr
****      spglind            = <src>-umskz
****      distributorsynchid = |{ <src>-kunnr ALPHA = OUT }|
****      primaryid          = |{ <src>-blart }{ <src>-kunnr }{ <src>-belnr }{ <src>-budat }{ <src>-bukrs }|
****      docid              = |{ <src>-blart }/{ <src>-belnr }|
****      amount             = <src>-dmbtr
****      dramount           = COND #( WHEN <src>-shkzg = 'S' THEN <src>-dmbtr ELSE 0 )
****      cramount           = COND #( WHEN <src>-shkzg = 'H' THEN <src>-dmbtr ELSE 0 )
****      transactiontype    = SWITCH #( <src>-blart
****                             WHEN 'DZ' THEN COND #( WHEN <src>-shkzg = 'S' THEN 'Receipt Reversal' ELSE 'Receipt' )
****                             WHEN 'RV' THEN COND #( WHEN <src>-shkzg = 'S' THEN 'Invoice' ELSE 'Credit Note' )
****                             WHEN 'UE' THEN 'Opening'
****                             ELSE 'Accounting Document' )
****      plant              = VALUE #( it_cds_details[ companycode = <src>-bukrs
****                                                   accountingdocument = <src>-belnr ]-profitcenter(4) OPTIONAL )
****    ) TO lt_cpi_payload.
****
****  ENDLOOP.

****  SELECT
****      companycode                AS bukrs,
****      customer                   AS kunnr,
****      specialglcode              AS umskz,
****      assignmentreference        AS zuonr,
****      accountingdocument         AS belnr,
****      postingdate                AS budat,
****      originalreferencedocument  AS xblnr,
****      accountingdocumenttype     AS blart,
****      debitcreditcode            AS shkzg,
****      amountincompanycodecurrency AS dmbtr,
****      documentitemtext           AS sgtxt,
****      profitcenter               AS prctr,
****      netduedate                 AS due_dat,
****      fiscalyear                 AS gjahr,
****      clearingaccountingdocument AS augbl,
****      clearingdocfiscalyear      AS augdt,
****      glaccount                  AS hkont
****    FROM i_operationalacctgdocitem
****    WHERE companycode         IN @s_bukrs
****      AND customer            IN @s_kunnr
****      AND postingdate         BETWEEN @lv_start_date AND @sy-datum
****      AND financialaccounttype = 'D'
****    ORDER BY customer, postingdate
****    INTO TABLE @DATA(it_ledger_src).

  SELECT
        companycode AS bukrs,
        customer AS kunnr,
        accountingdocument AS belnr,
        postingdate AS budat,
        originalreferencedocument AS xblnr,
        documentdate AS bldat,
        accountingdocumenttype AS blart,
        specialglcode AS umskz,
        assignmentreference AS zuonr,
        debitcreditcode AS shkzg,
        amountincompanycodecurrency AS dmbtr,
        documentitemtext AS sgtxt,
        fiscalyear AS gjahr,
        clearingaccountingdocument AS augbl,
        clearingdate AS augdt,
        glaccount AS hkont,
        profitcenter AS prctr,
        postingkey AS bschl,
        taxcode AS mwskz,
        amountintransactioncurrency AS wrbtr
      FROM i_operationalacctgdocitem
      WHERE companycode IN @s_bukrs AND customer IN @s_kunnr
        AND postingdate BETWEEN @lv_start_date AND @sy-datum
        AND financialaccounttype = 'D'
        AND clearingjournalentry = ' '
      INTO TABLE @DATA(it_ledger_src).

  IF it_ledger_src IS INITIAL.
    MESSAGE 'No items found.' TYPE 'S' DISPLAY LIKE 'E'. RETURN.
  ENDIF.

  SELECT kunnr, name1 FROM kna1 FOR ALL ENTRIES IN @it_ledger_src WHERE kunnr = @it_ledger_src-kunnr INTO TABLE @DATA(it_kna1).
  SELECT saknr, txt50 FROM skat FOR ALL ENTRIES IN @it_ledger_src WHERE saknr = @it_ledger_src-hkont AND spras = 'E' INTO TABLE @DATA(it_skat).

  SORT it_ledger_src BY kunnr budat.
  LOOP AT it_ledger_src ASSIGNING FIELD-SYMBOL(<s_row>).

    " A. Opening Balance Logic (BAPI Call per Customer)
    AT NEW kunnr.
      IF p_open = 'X'.
        CLEAR it_open.
        CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'
          EXPORTING
            companycode = <s_row>-bukrs
            customer    = <s_row>-kunnr
            keydate     = lv_key_date
          TABLES
            keybalance  = it_open.
        READ TABLE it_open INTO DATA(wa_open) INDEX 1.
        IF sy-subrc = 0 AND wa_open-lc_bal <> 0.
          APPEND VALUE #(
            bukrs      = <s_row>-bukrs
            kunnr      = <s_row>-kunnr
            budat      = lv_key_date
            ltext      = 'Opening Balance'
            debit      = COND #( WHEN wa_open-lc_bal > 0 THEN wa_open-lc_bal ELSE 0 )
            credit     = COND #( WHEN wa_open-lc_bal < 0 THEN abs( wa_open-lc_bal ) ELSE 0 )
            dist_sync  = |{ <s_row>-kunnr ALPHA = OUT }|
            color      = 'C510'
          ) TO it_final.
        ENDIF.
      ENDIF.
    ENDAT.

    " B. Mapping Main Ledger Item
    APPEND VALUE #(
      bukrs      = <s_row>-bukrs
      kunnr      = <s_row>-kunnr
      name1      = VALUE #( it_kna1[ kunnr = <s_row>-kunnr ]-name1 OPTIONAL )
      belnr      = <s_row>-belnr
      budat      = <s_row>-budat
      xblnr      = <s_row>-xblnr
      bldat      = <s_row>-bldat
      blart      = <s_row>-blart
      umskz      = <s_row>-umskz
      zuonr      = <s_row>-zuonr
      prctr      = <s_row>-prctr
      werks      = <s_row>-prctr(4)
      augbl      = <s_row>-augbl
      augdt      = <s_row>-augdt
      sgtxt      = <s_row>-sgtxt
      hkont      = <s_row>-hkont
      txt50      = VALUE #( it_skat[ saknr = <s_row>-hkont ]-txt50 OPTIONAL )
      gjahr      = <s_row>-gjahr
      bschl      = <s_row>-bschl
      shkzg      = <s_row>-shkzg
      mwskz      = <s_row>-mwskz
      dmbtr      = <s_row>-dmbtr
      wrbtr      = <s_row>-wrbtr
      debit      = COND #( WHEN <s_row>-shkzg = 'S' THEN <s_row>-dmbtr ELSE 0 )
      credit     = COND #( WHEN <s_row>-shkzg = 'H' THEN <s_row>-dmbtr ELSE 0 )
      primaryid  = |{ <s_row>-blart }{ <s_row>-kunnr }{ <s_row>-belnr }{ <s_row>-budat }|
      docid      = |{ <s_row>-blart }/{ <s_row>-belnr }|
      dist_sync  = |{ <s_row>-kunnr ALPHA = OUT }|
      ltext      = SWITCH #( <s_row>-blart
                    WHEN 'DZ' THEN COND #( WHEN <s_row>-shkzg = 'S' THEN 'Receipt Reversal' ELSE 'Receipt' )
                    WHEN 'RV' THEN COND #( WHEN <s_row>-shkzg = 'S' THEN 'Invoice' ELSE 'Credit Note' )
                    ELSE 'Accounting Document' )
    ) TO it_final.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form send2cpi
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM send2cpi .
  " Outbound CPI Push
  SELECT SINGLE low FROM tvarvc INTO @DATA(lv_endpoint) WHERE name = 'ZSD_CUSTLEDGER_EP' AND type = 'P'.

  IF sy-subrc = 0 AND it_final IS NOT INITIAL.

    zcl_http_util=>post_to_cpi(
      EXPORTING
        iv_json        = /ui2/cl_json=>serialize( data        = it_final
                                                  pretty_name = /ui2/cl_json=>pretty_mode-low_case )
        iv_path_suffix = CONV string( lv_endpoint )
      IMPORTING
        ev_status      = DATA(lv_status)
        ev_response    = DATA(lv_resp)
    ).

    IF lv_status BETWEEN 200 AND 202.
      WRITE: / 'Success: Data synced to CPI for Company Codes in selection.'.
    ELSE.
      WRITE: / 'Error Posting to CPI:', lv_status, lv_resp.
    ENDIF.

  ENDIF.

ENDFORM.

****FORM build_fcat.
****  fillcat 1  'BUKRS'    'Co. Code'          'X' ' ' ' ' ' '.
****  fillcat 2  'KUNNR'    'Customer'          'X' ' ' ' ' ' '.
****  fillcat 3  'NAME1'    'Name'              ' ' ' ' ' ' ' '.
****  fillcat 4  'BELNR'    'Doc. Number'       ' ' ' ' ' ' 'X'.
****  fillcat 5  'POSTINGDATE' 'Post. Date'     ' ' ' ' ' ' ' '.
****  fillcat 6  'REFNUMBER' 'Reference'        ' ' ' ' ' ' ' '.
****  fillcat 7  'DOCID'    'Doc. ID'           ' ' ' ' ' ' ' '.
****  fillcat 8  'SPGLIND'  'Spl. G/L'          ' ' ' ' ' ' ' '.
****  fillcat 9  'ASSNUM'   'Assignment'        ' ' ' ' ' ' ' '.
****  fillcat 10 'DRAMOUNT' 'Debit'             ' ' ' ' 'X' ' '.
****  fillcat 11 'CRAMOUNT' 'Credit'            ' ' ' ' 'X' ' '.
****  fillcat 12 'CLOSING'  'Closing'           ' ' ' ' 'X' ' '.
****  fillcat 13 'PLANT'    'Plant'             ' ' ' ' ' ' ' '.
****  fillcat 14 'PRCTR'    'Profit Center'     ' ' ' ' ' ' ' '.
****  fillcat 15 'NARRATION' 'Text'             ' ' ' ' ' ' ' '.
****ENDFORM.
FORM build_fcat.
  REFRESH it_fcat.
  " fillcat pos tab field label no_out sum zero hotspot
  fillcat 1  'IT_FINAL' 'bukrs'      'Company Code'                'X' ' ' ' ' ' '.
  fillcat 2  'IT_FINAL' 'kunnr'      'Customer Number'             ' ' ' ' ' ' ' '.
  fillcat 3  'IT_FINAL' 'NAME1'      'Customer Name'               ' ' ' ' ' ' ' '.
  fillcat 4  'IT_FINAL' 'belnr'      'Document Number'             ' ' ' ' ' ' 'X'.
  fillcat 5  'IT_FINAL' 'budat'      'Posting Date'                ' ' ' ' ' ' ' '.
  fillcat 6  'IT_FINAL' 'xblnr'      'Reference Document Number'   ' ' ' ' ' ' ' '.
  fillcat 7  'IT_FINAL' 'bldat'      'Document Date'               ' ' ' ' ' ' ' '.
  fillcat 8  'IT_FINAL' 'blart'      'Document Type'               ' ' ' ' ' ' ' '.
  fillcat 9  'IT_FINAL' 'LTEXT'      'Doc. Type Text'              ' ' ' ' ' ' ' '.
  fillcat 10 'IT_FINAL' 'UMSKZ'      'Spl. G/L Indicator'          ' ' ' ' ' ' ' '.
  fillcat 11 'IT_FINAL' 'zuonr'      'Cheque No./ NEFT/ RTGS No.'  ' ' ' ' ' ' ' '.
  fillcat 12 'IT_FINAL' 'debit'      'Debit Amount'                ' ' ' ' 'X' ' '.
  fillcat 13 'IT_FINAL' 'credit'     'Credit Amount'               ' ' ' ' 'X' ' '.
  fillcat 14 'IT_FINAL' 'closing'    'Closing'                     ' ' ' ' 'X' ' '.
  fillcat 15 'IT_FINAL' 'prctr'      'Profit Center'               ' ' ' ' ' ' ' '.
  fillcat 16 'IT_FINAL' 'werks'      'Plant'                       ' ' ' ' ' ' ' '.
  fillcat 17 'IT_FINAL' 'plant'      'Plant Desc.'                 ' ' ' ' ' ' ' '.
  fillcat 18 'IT_FINAL' 'augbl'      'Clearing Doc. Num'           ' ' ' ' ' ' ' '.
  fillcat 19 'IT_FINAL' 'augdt'      'Clearing Date'               ' ' ' ' ' ' ' '.
  fillcat 20 'IT_FINAL' 'sgtxt'      'Text'                        ' ' ' ' ' ' ' '.
  fillcat 21 'IT_FINAL' 'saknr'      'G/L Account Number'          ' ' ' ' ' ' ' '.
  fillcat 22 'IT_FINAL' 'hkont'      'General Ledger Account'      ' ' ' ' ' ' ' '.
  fillcat 23 'IT_FINAL' 'txt50'      'G/L Account Text'            ' ' ' ' ' ' ' '.
  fillcat 24 'IT_FINAL' 'gjahr'      'Fiscal Year'                 'X' ' ' ' ' ' '.
  fillcat 25 'IT_FINAL' 'bschl'      'Posting Key'                 'X' ' ' ' ' ' '.
  fillcat 26 'IT_FINAL' 'shkzg'      'Debit/Credit Indicator'      'X' ' ' ' ' ' '.
  fillcat 27 'IT_FINAL' 'mwskz'      'Tax on sales/purchases code' 'X' ' ' ' ' ' '.
  fillcat 28 'IT_FINAL' 'dmbtr'      'Amount'                      'X' ' ' ' ' ' '.
  fillcat 29 'IT_FINAL' 'wrbtr'      'Amount In Global'            'X' ' ' ' ' ' '.
ENDFORM.

FORM display.
  wa_layout-zebra             = 'X'.
  wa_layout-colwidth_optimize = 'X'.
  wa_layout-info_fieldname    = 'COLOR'.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
      i_callback_user_command = 'USER_COMMAND'
      i_callback_top_of_page  = 'TOP_PAGE'
      is_layout               = wa_layout
      it_fieldcat             = it_fcat
      i_save                  = 'X'
    TABLES
      t_outtab                = it_final.
ENDFORM.

FORM top_page.
  DATA: it_header TYPE slis_t_listheader, wa_header TYPE slis_listheader.

  IF s_kunnr-high IS INITIAL.
    CLEAR v_customer.
    LOOP AT s_kunnr.
      DATA(lv_low) = |{ s_kunnr-low ALPHA = OUT }|.
      v_customer = COND #( WHEN v_customer IS INITIAL THEN lv_low ELSE |{ v_customer }, { lv_low }| ).
    ENDLOOP.

    wa_header-typ = 'S'.
    wa_header-info = |{ COND #( WHEN s_bukrs-low = '1000' THEN 'ASTRAL POLY TECHNIK LIMITED' ELSE 'ADVANCED ADHESIVES LIMITED' ) }|.
    APPEND wa_header TO it_header.

    wa_header-info = |Customer Number: { v_customer }|.
    APPEND wa_header TO it_header.

    READ TABLE it_kna1_header INTO wa_kna1_header INDEX 1.
    IF sy-subrc = 0.
      wa_header-info = |Customer Name: { wa_kna1_header-name1 } { wa_kna1_header-name2 }|.
      APPEND wa_header TO it_header.
      wa_header-info = |City: { wa_kna1_header-ort01 }|.
      APPEND wa_header TO it_header.
    ENDIF.

    wa_header-info = |Statement from: { s_budat-low DATE = USER } to { s_budat-high DATE = USER }|.
    APPEND wa_header TO it_header.

    CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE' EXPORTING it_list_commentary = it_header.
  ENDIF.
ENDFORM.

FORM user_command USING ucomm LIKE sy-ucomm
                        selfield TYPE slis_selfield.
  CASE ucomm.
    WHEN '&IC1'. " Double Click / Hotspot
      READ TABLE it_final INTO DATA(wa_final) INDEX selfield-tabindex.
      IF sy-subrc = 0 AND wa_final-belnr IS NOT INITIAL.
        SET PARAMETER ID 'BLN' FIELD wa_final-belnr.
        SET PARAMETER ID 'BUK' FIELD wa_final-bukrs.
        SET PARAMETER ID 'GJR' FIELD wa_final-gjahr.
        CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN.
      ENDIF.
  ENDCASE.
ENDFORM.
