*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_BUPLA_CON
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_BUPLA_CON       .

  PERFORM TABLEPROC.

ENDFUNCTION.
