*&---------------------------------------------------------------------*
*& Include SAPMZFI_BANK_RECO_MANUAL_TOP                      Module Pool      SAPMZFI_BANK_RECO_MANUAL
*&
*&---------------------------------------------------------------------*

*PROGRAM sapmzfi_bank_reco_manual.

*&---------------------------------------------------------------------*
*&              TYPES
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_final,
         mark     TYPE c,
         bukrs    TYPE bukrs,
         vgman    TYPE vgman_eb,
         hkont    TYPE hkont,
         gjahr    TYPE gjahr,
         belnr    TYPE belnr_d,
         blart    TYPE blart,
         bldat    TYPE bldat,
         budat    TYPE budat,
         valut    TYPE datum,
         dmbtr    TYPE dmbtr,
         messg    TYPE char100,
         zuonr    TYPE bseg-zuonr,
         name(50) TYPE c,
         kidno    TYPE kidno,       "Added By Raj on 15-May-2023
       END OF ty_final,

       BEGIN OF ty_t012k,
         bukrs TYPE febmka-bukrs,           "COMPANY CODE
         hbkid TYPE febmka-hbkid,          " Short Key for a House Bank
         hkont TYPE febko-hkont,           "GL ACCOUNT
       END OF ty_t012k,
       BEGIN OF ty_febko,
         aznum TYPE aznum_eb,
         esvoz TYPE esvoz_eb,
         esbtr TYPE ssald_eb,
       END OF ty_febko,
       BEGIN OF ty_bsis,
         bukrs TYPE bsis-bukrs,
         hkont TYPE bsis-hkont,
         zuonr TYPE bsis-zuonr,
         gjahr TYPE gjahr,
         belnr TYPE bsis-belnr,
         budat TYPE bsis-budat,
         bldat TYPE bldat,
         blart TYPE blart,
         dmbtr TYPE bsis-dmbtr, "(15) TYPE C,
         wrbtr TYPE bsis-wrbtr, "(15) TYPE C,
         valut TYPE valut,
         kidno TYPE kidno,            "Added By Raj on 15-May-2023
       END OF ty_bsis  ,
       BEGIN OF ty_header ,
         bukrs         TYPE febmka-bukrs,          " Company Code
         hbkid         TYPE febmka-hbkid,          " Short Key for a House Bank
         hktid         TYPE febmka-hktid,          " ID for Account Details
         waers         TYPE febko-waers,           " currency
         aznum         TYPE febko-aznum,           " Statement number
         azdat         TYPE  c LENGTH 10,          " Statement Date
         ssald         TYPE c LENGTH 19 ,          " Opening Balance
         close_balance TYPE c LENGTH 19 ,          " Closing Balance
         budtm         TYPE  c LENGTH 10,          " posting date
         bankl         TYPE febvw-bankl,           " bank key
         bankn         TYPE febko-ktonr,           "account no
         hkont         TYPE febko-hkont,
       END OF ty_header ,
       BEGIN OF ty_item ,
         bukrs     TYPE bsis-bukrs,        "febmka-bukrs,
         vgman     TYPE gsber ,                       " Transaction Id
         budat     TYPE  c LENGTH 10,                  " Value date
         dmbtr     TYPE c LENGTH 19,                 " Amount
         kwbtr     TYPE febmka-kwbtr,          ""  ÄMOUNT
         belnr     TYPE bsis-belnr,
         zuonr     TYPE bsis-zuonr,        "FEBMKK-zuonr,
         waers     TYPE febko-waers,
         kursf_kf  TYPE kursf_eb,
         wrbtr     TYPE c LENGTH 20,
         hkont     TYPE bsis-hkont,          "FEBKO-HKONT,
         budat1    TYPE  c LENGTH 10,                  " Value BACK date BY 3MONTHS
         dmbtr1    TYPE c LENGTH 19,                 " Amount
         budatl    TYPE p0001-begda,
         date_back TYPE bsis-budat,
       END OF ty_item .

TYPES: BEGIN OF ty_table,
         mark     TYPE c,
         bukrs    TYPE bukrs,
         vgman    TYPE vgman_eb,
         hkont    TYPE hkont,
         gjahr    TYPE gjahr,
         belnr    TYPE belnr_d,
         blart    TYPE blart,
         bldat    TYPE bldat,
         budat    TYPE budat,
         valut    TYPE datum,
         dmbtr    TYPE dmbtr,
         cldat    TYPE budat,
         zuonr    TYPE bseg-zuonr,
         name(50) TYPE c,
         del      TYPE char1,
         kidno    TYPE kidno,               "Added By Raj on 15-May-2023
       END OF ty_table.

TYPES: BEGIN OF ty_bseg,
         bukrs TYPE bseg-bukrs,
         belnr TYPE bseg-belnr,
         gjahr TYPE bseg-gjahr,
         koart TYPE bseg-koart,
         zuonr TYPE bseg-zuonr,
         hkont TYPE bseg-hkont,
         kunnr TYPE bseg-kunnr,
         lifnr TYPE bseg-lifnr,
       END OF ty_bseg.

DATA:wa_bseg TYPE ty_bseg,
     it_bseg TYPE TABLE OF ty_bseg.

DATA:wa_bseg1 TYPE ty_bseg,
     it_bseg1 TYPE TABLE OF ty_bseg.


TYPES: BEGIN OF ty_kna1,
         kunnr TYPE kna1-kunnr,
         name1 TYPE kna1-name1,
         name2 TYPE kna1-name2,
       END OF ty_kna1.

DATA:wa_kna1 TYPE ty_kna1,
     it_kna1 TYPE TABLE OF ty_kna1.

TYPES:BEGIN OF ty_lfa1,
        lifnr TYPE lfa1-lifnr,
        name1 TYPE lfa1-name1,
        name2 TYPE lfa1-name2,
      END OF ty_lfa1.

DATA:wa_lfa1 TYPE ty_lfa1,
     it_lfa1 TYPE TABLE OF ty_lfa1.

TYPES: BEGIN OF ty_skat,
*         spras TYPE skat-spras,
*         ktopl TYPE skat-ktopl,
         saknr TYPE skat-saknr,
         txt50 TYPE skat-txt50,
       END OF ty_skat.

DATA:wa_skat TYPE ty_skat,
     it_skat TYPE TABLE OF ty_skat.
*&---------------------------------------------------------------------*
*&              INTERNALS TABLES
*&---------------------------------------------------------------------*
DATA : bdcdata    LIKE bdcdata OCCURS 0 WITH HEADER LINE.
DATA : gt_msgtype LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA : params     TYPE ctu_params.
DATA : gt_t012k  TYPE STANDARD TABLE OF ty_t012k,
       gt_febko  TYPE STANDARD TABLE OF ty_febko,
       gt_bsis   TYPE STANDARD TABLE OF ty_bsis,
       gt_final  TYPE STANDARD TABLE OF ty_final,
       gt_header TYPE STANDARD TABLE OF ty_header,
       gt_item   TYPE STANDARD TABLE OF ty_item.
DATA: gt_table TYPE STANDARD TABLE OF ty_table,
      wa_table TYPE ty_table.
DATA : wa_layout TYPE slis_layout_alv,
       gt_fcat   TYPE slis_t_fieldcat_alv,
       wa_fcat   TYPE slis_fieldcat_alv.
DATA : BEGIN OF gt_bank OCCURS 0,
         bankl TYPE bnka-bankl,
       END OF gt_bank .
*&---------------------------------------------------------------------*
*&              WORK AREA
*&---------------------------------------------------------------------*
DATA: wa_t012k  TYPE ty_t012k,
      wa_febko  TYPE ty_febko,
      wa_bsis   TYPE ty_bsis,
      wa_final  TYPE ty_final,
      wa_header TYPE ty_header,
      wa_item   TYPE ty_item.
FIELD-SYMBOLS: <fs_bsis>  TYPE ty_bsis.
FIELD-SYMBOLS: <fs_final> TYPE ty_final.

DATA: gv_dmbtr TYPE dmbtr.

*&---------------------------------------------------------------------*
*&             vaiables
*&---------------------------------------------------------------------*
DATA: local(5)       TYPE p DECIMALS 2,
      close_balance  TYPE c LENGTH 19,
      close_balance1 TYPE c LENGTH 19..

DATA : count(2)  TYPE n,
       temp      TYPE bdcdata-fnam,
       v_string  TYPE string,
       count1(3) TYPE n,
       gv_idx    TYPE sy-tabix,
       cnt       TYPE i,
       bukrs_l   TYPE bukrs,
       waers_l   TYPE waers,
       hkont_l   TYPE hkont,
       budat1    TYPE p0001-begda,
       budatl    TYPE p0001-begda,
       var_exc   TYPE c LENGTH 9.
*&---------------------------------------------------------------------*
*&             Global Variables
*&---------------------------------------------------------------------*
DATA: gv_bukrs  TYPE bukrs,      "Company Code
      gv_hbkid  TYPE hbkid,      "House Bank
      gv_hktid  TYPE hktid,      "Account ID
      gv_aznum  TYPE aznum_eb,   "Statement No
      gv_azdat  TYPE azdat_eb,   "Statement Date
      gv_ssald  TYPE ssald_eb,   "Opening Balance
      gv_esald  TYPE esald_eb,   "Closing Balance
      gv_hkont  TYPE hkont,        "G/L Acount Main
      gv_hkont1 TYPE hkont,        "G/L Acount Incoming
      gv_hkont2 TYPE hkont,        "G/L Acount Outgoing
      gv_flag,
      gv_amt,
      gv_get,
      gv_ucomm  TYPE sy-ucomm.


" Needed for table control declaration
DATA :    gv_ok_code TYPE sy-ucomm.
*** Data Declaration For Subscreen Areas
DATA: gv_sub_8001 TYPE sy-dynnr,
      gv_sub_8002 TYPE sy-dynnr.

CONSTANTS : gc_9000 TYPE dynnr VALUE '9000',
            gc_8001 TYPE dynnr VALUE '8001',
            gc_8002 TYPE dynnr VALUE '8002',
            gc_8999 TYPE dynnr VALUE '8999'.







*&---------------------------------------------------------------------*
*&              Ranges
*&---------------------------------------------------------------------*
RANGES: r_hkont FOR hkont_l.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'T_TABL_CTRL' ITSELF
CONTROLS: t_tabl_ctrl TYPE TABLEVIEW USING SCREEN 8002.

*&SPWIZARD: LINES OF TABLECONTROL 'T_TABL_CTRL'
DATA:     g_t_tabl_ctrl_lines  LIKE sy-loopc.

DATA:     ok_code LIKE sy-ucomm.
