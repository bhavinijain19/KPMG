*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_BUPLA_CON...................................*
DATA:  BEGIN OF STATUS_ZFI_BUPLA_CON                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_BUPLA_CON                 .
CONTROLS: TCTRL_ZFI_BUPLA_CON
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_BUPLA_CON                 .
TABLES: ZFI_BUPLA_CON                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
