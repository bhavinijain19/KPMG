FUNCTION-POOL ZFI_OD_SMS_GP_CS           MESSAGE-ID SV.

* INCLUDE LZFI_OD_SMS_GP_CSD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_OD_SMS_GP_CST00                    . "view rel. data dcl.
