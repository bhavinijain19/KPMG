*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PIPES_CON
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PIPES_CON       .

  PERFORM TABLEPROC.

ENDFUNCTION.
