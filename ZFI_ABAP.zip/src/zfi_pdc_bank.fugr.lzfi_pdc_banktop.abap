FUNCTION-POOL ZFI_PDC_BANK               MESSAGE-ID SV.

* INCLUDE LZFI_PDC_BANKD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PDC_BANKT00                        . "view rel. data dcl.
