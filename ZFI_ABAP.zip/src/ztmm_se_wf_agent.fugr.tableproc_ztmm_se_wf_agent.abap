*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTMM_SE_WF_AGENT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTMM_SE_WF_AGENT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
