FUNCTION-POOL ZFI_CRM_LEDGER_CUST.          "MESSAGE-ID ..

* INCLUDE LZFI_CRM_LEDGER_CUSTD...           " Local class definition
