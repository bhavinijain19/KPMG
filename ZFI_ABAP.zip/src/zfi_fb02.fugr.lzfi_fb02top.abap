FUNCTION-POOL ZFI_FB02.                     "MESSAGE-ID ..

* INCLUDE LZFI_FB02D...                      " Local class definition
