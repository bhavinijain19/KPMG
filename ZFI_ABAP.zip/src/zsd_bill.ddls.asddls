@AbapCatalog.sqlViewName: 'ZSD_BILL_DETAILS'
@AbapCatalog.compiler.CompareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Header and Item Details of Billing Invoice'
define view ZSD_BILL as select from vbrk as a
 inner join vbrp as b on a.vbeln = b.vbeln
 inner join mara as c on b.matnr = c.matnr
{
        key a.vbeln as vbeln,
        key b.posnr as posnr,
            a.bukrs as bukrs,
            a.fkart as fkart,
            a.waerk as waerk,
            a.kurrf as kurrf,
            a.zterm as ZTERM,
            a.vkorg as vkorg,
            a.vtweg as vtweg,
            a.knumv as knumv,
            a.fkdat as fkdat,
            a.kdgrp as kdgrp,
            a.bzirk as bzirk,
            a.kunrg as kunrg,
            a.kunag as kunag,
            a.fksto as fksto,
            a.spart as spart,
            a.regio as regio,
            a.vbtyp as VBTYP,
            b.fkimg as fkimg,
            b.matnr as matnr,
            b.werks as werks,
            b.vgbel as vgbel,
            b.aubel as aubel,
            b.prsfd as PRSFD,
            b.vkgrp as vkgrp,
            b.vkbur as vkbur,
            b.netwr as netwr,
            b.mwsbp as MWSBP,    
            c.mtart as mtart     
}
