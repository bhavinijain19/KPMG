*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_BUPLA_CONTOP.                 " Global Declarations
  INCLUDE LZFI_BUPLA_CONUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_BUPLA_CONF...                 " Subroutines
* INCLUDE LZFI_BUPLA_CONO...                 " PBO-Modules
* INCLUDE LZFI_BUPLA_CONI...                 " PAI-Modules
* INCLUDE LZFI_BUPLA_CONE...                 " Events
* INCLUDE LZFI_BUPLA_CONP...                 " Local class implement.
* INCLUDE LZFI_BUPLA_CONT99.                 " ABAP Unit tests
  INCLUDE LZFI_BUPLA_CONF00                       . " subprograms
  INCLUDE LZFI_BUPLA_CONI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
