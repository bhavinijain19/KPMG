@AbapCatalog.sqlViewName: 'ZFI_COVP'
@AbapCatalog.compiler.CompareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'CDS view for COVPWBS'
define view ZF_COVP_DATA as select from prps as a
association [1..*] to covp as _covp
    on a.objnr = _covp.objnr
{
    key a.pspnr as pspnr,
    key a.objnr as objnr,
        _covp.kokrs as kokrs,
        _covp.belnr as belnr,
        _covp.buzei as buzei,
        _covp.wrttp as wrttp,
        _covp.refbn as refbn,
        _covp.refbk as refbk,
        _covp.refgj as refgj,
        _covp.awtyp as awtyp,
    _covp // Make association public
}
