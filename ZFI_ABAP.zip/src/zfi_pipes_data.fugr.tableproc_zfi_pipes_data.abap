*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PIPES_DATA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PIPES_DATA      .

  PERFORM TABLEPROC.

ENDFUNCTION.
