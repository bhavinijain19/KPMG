*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_CREDIT_DAYSTOP.               " Global Declarations
  INCLUDE LZFI_CREDIT_DAYSUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_CREDIT_DAYSF...               " Subroutines
* INCLUDE LZFI_CREDIT_DAYSO...               " PBO-Modules
* INCLUDE LZFI_CREDIT_DAYSI...               " PAI-Modules
* INCLUDE LZFI_CREDIT_DAYSE...               " Events
* INCLUDE LZFI_CREDIT_DAYSP...               " Local class implement.
* INCLUDE LZFI_CREDIT_DAYST99.               " ABAP Unit tests
  INCLUDE LZFI_CREDIT_DAYSF00                     . " subprograms
  INCLUDE LZFI_CREDIT_DAYSI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
