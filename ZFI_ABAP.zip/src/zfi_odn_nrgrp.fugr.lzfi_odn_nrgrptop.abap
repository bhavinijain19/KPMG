FUNCTION-POOL ZFI_ODN_NRGRP              MESSAGE-ID SV.

* INCLUDE LZFI_ODN_NRGRPD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_ODN_NRGRPT00                       . "view rel. data dcl.
