"Name: \PR:SAPLV60A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:END\EI
ENHANCEMENT 0 ZSD_REFDOC_UPDATE.
    DATA: lv_indicator TYPE char1,
          lv_fy        TYPE char4,
          lv_fyear     TYPE char2,
          lv_state     TYPE regio,
          lv_plant     TYPE werks_d,
          lv_number    TYPE nrlevel,
          lv_nr_padded TYPE n LENGTH 10,
          lv_nr_7      TYPE char7.

    DATA: lv_adrnr TYPE p_businessplace-adrnr.

    FIELD-SYMBOLS: <lt_xvbrp> TYPE table,
                   <ls_xvbrp> TYPE vbrpvb.

    IF sy-tcode = 'VF01' OR sy-tcode = 'VF04'.
      CALL FUNCTION 'GM_GET_FISCAL_YEAR'
        EXPORTING
          i_date                     = sy-datum
          i_fyv                      = 'V3'
        IMPORTING
          e_fy                       = lv_fy
        EXCEPTIONS
          fiscal_year_does_not_exist = 1
          not_defined_for_date       = 2
          OTHERS                     = 3.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      lv_fyear = lv_fy+2(2).

      SELECT SINGLE adrnr
        INTO lv_adrnr
        FROM pbusinessplace
        WHERE bukrs  = vbrk-bukrs
          AND branch = vbrk-bupla.
      IF sy-subrc = 0.
        SELECT SINGLE region
          INTO lv_state
          FROM adrc
          WHERE addrnumber = lv_adrnr.
      ENDIF.

      ASSIGN ('(SAPLV60A)XVBRP[]') TO <lt_xvbrp>.
      IF <lt_xvbrp> IS ASSIGNED AND <lt_xvbrp> IS NOT INITIAL.
        READ TABLE <lt_xvbrp> ASSIGNING <ls_xvbrp> INDEX 1.
        IF sy-subrc = 0.
          lv_plant = <ls_xvbrp>-werks.
        ENDIF.
      ENDIF.
      IF lv_plant IS NOT INITIAL AND vbrk-fkart IS NOT INITIAL.
        zcl_odn_handler=>generate_xblnr(
          EXPORTING
            iv_fkart = vbrk-fkart
            iv_werks = <ls_xvbrp>-werks
            iv_regio = lv_state
            iv_year  = lv_fyear
          IMPORTING
            ev_subrc = DATA(ev_subrc)
          CHANGING
            cv_xblnr = vbrk-xblnr
        ).
        IF ev_subrc = 0.
          xvbrk-xblnr = vbrk-xblnr.
        ENDIF.
      ENDIF.
    ENDIF.
ENDENHANCEMENT.
