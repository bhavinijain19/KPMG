*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_CASH_LIMITTOP.                " Global Declarations
  INCLUDE LZFI_CASH_LIMITUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_CASH_LIMITF...                " Subroutines
* INCLUDE LZFI_CASH_LIMITO...                " PBO-Modules
* INCLUDE LZFI_CASH_LIMITI...                " PAI-Modules
* INCLUDE LZFI_CASH_LIMITE...                " Events
* INCLUDE LZFI_CASH_LIMITP...                " Local class implement.
* INCLUDE LZFI_CASH_LIMITT99.                " ABAP Unit tests
  INCLUDE LZFI_CASH_LIMITF00                      . " subprograms
  INCLUDE LZFI_CASH_LIMITI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzfi_cash_limitf01.

INCLUDE lzfi_cash_limitf02.
