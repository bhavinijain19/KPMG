*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_MAILID......................................*
DATA:  BEGIN OF STATUS_ZFI_MAILID                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_MAILID                    .
CONTROLS: TCTRL_ZFI_MAILID
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_MAILID                    .
TABLES: ZFI_MAILID                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
