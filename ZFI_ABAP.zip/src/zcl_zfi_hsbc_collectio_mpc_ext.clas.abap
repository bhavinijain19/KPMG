class ZCL_ZFI_HSBC_COLLECTIO_MPC_EXT definition
  public
  inheriting from ZCL_ZFI_HSBC_COLLECTIO_MPC
  create public .

public section.

  types:
    BEGIN OF ty_deep_entity,
      filename TYPE zfi_colle_log-filename,
      toitems  TYPE STANDARD TABLE OF ts_hsbccollection WITH DEFAULT KEY,
    END OF ty_deep_entity .

  methods DEFINE
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_HSBC_COLLECTIO_MPC_EXT IMPLEMENTATION.


  METHOD define.
    super->define( ).
    DATA(lo_entity_type) = model->get_entity_type( iv_entity_name = 'HSBCCollectionHead' ). " Your wrapper entity name
    lo_entity_type->bind_structure( iv_structure_name = 'ZCL_ZFI_HSBC_COLLECTIO_MPC_EXT=>TY_DEEP_ENTITY' ).
  ENDMETHOD.
ENDCLASS.
