FUNCTION-POOL ZFI_CASH_LIMIT             MESSAGE-ID SV.

* INCLUDE LZFI_CASH_LIMITD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_CASH_LIMITT00                      . "view rel. data dcl.
