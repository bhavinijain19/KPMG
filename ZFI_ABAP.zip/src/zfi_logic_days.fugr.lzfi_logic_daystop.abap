FUNCTION-POOL ZFI_LOGIC_DAYS             MESSAGE-ID SV.

* INCLUDE LZFI_LOGIC_DAYSD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_LOGIC_DAYST00                      . "view rel. data dcl.
