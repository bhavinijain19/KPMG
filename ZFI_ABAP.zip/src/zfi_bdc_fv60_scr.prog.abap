*&---------------------------------------------------------------------*
*& Include          ZFI_BDC_FV60_SCR
*&---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* Selection-screen (same pattern as your reference)
*---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS : ctu_mode LIKE ctu_params-dismode DEFAULT 'A',

               p_fname  LIKE ibipparms-path OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.


*---------------------------------------------------------------------*
* F4 help for file (same as reference)
*---------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_fname.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = ' '
    IMPORTING
      file_name     = p_fname.
