FUNCTION zsample_interface_rwbapi01.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  TABLES
*"      IT_ACCIT STRUCTURE  ACCIT
*"      IT_ACCCR STRUCTURE  ACCCR
*"      RETURN STRUCTURE  BAPIRET2
*"      EXTENSION STRUCTURE  BAPIACEXTC
*"      IT_ACCWT STRUCTURE  ACCIT_WT
*"  CHANGING
*"     VALUE(DOCUMENT_HEADER) LIKE  ACCHD STRUCTURE  ACCHD
*"----------------------------------------------------------------------
  FIELD-SYMBOLS : <fs_accit> TYPE accit.
  DATA: lw_ext TYPE bapiacextc.
*  BREAK-POINT.
  CHECK it_accit[] IS NOT INITIAL.


  IF sy-tcode EQ 'ZIMP_TE' OR sy-tcode EQ 'ZFI_CU_VE'.
    LOOP AT it_accit ASSIGNING <fs_accit>.
      READ TABLE extension INTO lw_ext WITH KEY field1 = <fs_accit>-posnr.
      IF sy-subrc EQ 0.
        CONDENSE lw_ext-field3.
        <fs_accit>-bschl = lw_ext-field3.
        <fs_accit>-rebzg = lw_ext-field4.
        IF sy-tcode EQ 'ZFI_CU_VE'.
*          <fs_accit>-rebzg = lw_ext-field4.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.

*************************************************Added by Raj on  15.03.2024*********************************

*  IF sy-tcode = 'ZIMP_TE_MAN'.
*    LOOP AT it_accit ASSIGNING <fs_accit>.
*      IF  <fs_accit>-bschl = '40' OR <fs_accit>-bschl = '50'.
*        READ TABLE extension INTO lw_ext WITH KEY field1 = <fs_accit>-posnr.
*        IF sy-subrc EQ 0.
**          CONDENSE lw_ext-field3.
**          <fs_accit>-xref1 = lw_ext-field4+0(12).
**          <fs_accit>-xref2 = lw_ext-field4+12(25).
**          <fs_accit>-xref3 = lw_ext-field4+37(18).
*          <fs_accit>-XREF1_HD =  <fs_accit>-xref1 .
*          <fs_accit>-XREF2_HD =  <fs_accit>-xref2 .
*          <fs_accit>-xref3 =  <fs_accit>-xref3 .
*
*        ENDIF.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*************************************************Added by Raj on  15.03.2024*********************************









*  *  ***************  ADDED BY PARTH FOR 13.11.2019/11.11.2020
  CONSTANTS:
   c_tvarvc_name TYPE rvari_vnam VALUE 'ZFI_DP_CLEAR_V'.

  TYPES: BEGIN OF ty_tvarvc,
           low TYPE tvarv_val,
         END OF ty_tvarvc.
  DATA: it_tvarvc  TYPE STANDARD TABLE OF ty_tvarvc.
  DATA: wa_tvarvc TYPE ty_tvarvc.

  SELECT low
   INTO CORRESPONDING FIELDS OF TABLE it_tvarvc
               FROM tvarvc
               WHERE name = c_tvarvc_name.

* IF sy-tcode EQ 'ZFI_CUST_DP_AUTO' OR sy-tcode EQ 'ZFI_CUST_DP' OR SY-TCODE EQ 'ZFI_CUST_DP_CSV'. "Comment 11.11.2020
  READ TABLE it_tvarvc INTO wa_tvarvc WITH KEY low = sy-tcode.
  IF sy-subrc = 0.
    LOOP AT it_accit ASSIGNING <fs_accit> WHERE rebzg = 'V'.
      <fs_accit>-rebzg = ' '.
      MODIFY it_accit INDEX sy-tabix FROM <fs_accit>.
    ENDLOOP.
  ENDIF.
****************** ended by parth 13.11.2019
  "Adding Start by Rahul Vasita on 13.12.2023 15:56:59
  IF sy-tcode = 'ZFI_FBS1'.

******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE name,
*                  low
*          FROM tvarvc
*          INTO @DATA(ls_tvarvc)
*          WHERE name = 'ZFI_FBS1_BDC_BTE'
*            AND type = 'P'.
    SELECT name,
                  low
          FROM tvarvc UP TO 1 ROWS
          INTO @DATA(ls_tvarvc)
          WHERE name = 'ZFI_FBS1_BDC_BTE'
            AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF ls_tvarvc-low = 'X'.
      READ TABLE extension WITH KEY field1 = 'STODT'.
      IF sy-subrc = 0.
        LOOP AT it_accit ASSIGNING <fs_accit>.
          <fs_accit>-stodt = extension-field2.
          MODIFY it_accit FROM <fs_accit> INDEX sy-tabix.
        ENDLOOP.
      ENDIF.
    ENDIF."End of TVARVC
  ENDIF."sy-tcode = 'ZFI_FBS1'.
  "Adding End by Rahul Vasita on 13.12.2023 15:56:59

  "Adding Start by Rahul Vasita on 08.01.2024 11:59:29
  IF sy-tcode = 'ZFI_PDC'.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE name,
*                  low
*          FROM tvarvc
*          INTO @DATA(ls_tvarvc1)
*          WHERE name = 'ZFI_PDC_BTE'
*            AND type = 'P'.
    SELECT name,
                  low
          FROM tvarvc UP TO 1 ROWS
          INTO @DATA(ls_tvarvc1)
          WHERE name = 'ZFI_PDC_BTE'
            AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF ls_tvarvc1-low = 'X'.
      READ TABLE extension WITH KEY field1 = 'GST_PART'.
      IF sy-subrc = 0.
        LOOP AT it_accit ASSIGNING <fs_accit> WHERE bschl = '01'.
          <fs_accit>-gst_part = extension-field2.
        ENDLOOP.
      ENDIF."End of EXTENTION
    ENDIF.
    CLEAR : ls_tvarvc1.
  ENDIF.
  "Adding End by Rahul Vasita on 08.01.2024 11:59:29

  CHECK extension-field1 = 'ZFI_CD' OR extension-field1 = 'ZFI_CR' OR extension-field1 = 'ZFI_CD_RCL' OR extension-field1 = 'ZFI_CD_CLR'.
  CHECK extension-field2 = 'FB75A' OR extension-field2 = 'FB75' .
  document_header-status_new = '2'.



ENDFUNCTION.
