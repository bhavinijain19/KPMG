FUNCTION-POOL ZFI_SALE_SMS_GP            MESSAGE-ID SV.

* INCLUDE LZFI_SALE_SMS_GPD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_SALE_SMS_GPT00                     . "view rel. data dcl.
