*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_LOGIC_DAYS..................................*
DATA:  BEGIN OF STATUS_ZFI_LOGIC_DAYS                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_LOGIC_DAYS                .
CONTROLS: TCTRL_ZFI_LOGIC_DAYS
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_LOGIC_DAYS                .
TABLES: ZFI_LOGIC_DAYS                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
