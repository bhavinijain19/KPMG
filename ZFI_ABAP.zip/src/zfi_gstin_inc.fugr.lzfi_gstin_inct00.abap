*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GSTIN_INC...................................*
DATA:  BEGIN OF STATUS_ZFI_GSTIN_INC                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GSTIN_INC                 .
CONTROLS: TCTRL_ZFI_GSTIN_INC
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_GSTIN_INC                 .
TABLES: ZFI_GSTIN_INC                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
