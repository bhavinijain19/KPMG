*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_CREDIT_DAYS.................................*
DATA:  BEGIN OF STATUS_ZFI_CREDIT_DAYS               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CREDIT_DAYS               .
CONTROLS: TCTRL_ZFI_CREDIT_DAYS
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_CREDIT_DAYS               .
TABLES: ZFI_CREDIT_DAYS                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
