FUNCTION Z_FIEB_904_ALGORITHM.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_NOTE_TO_PAYEE) TYPE  STRING OPTIONAL
*"     REFERENCE(I_COUNTRY) TYPE  LAND1 OPTIONAL
*"  TABLES
*"      T_AVIP_IN STRUCTURE  AVIP OPTIONAL
*"      T_AVIP_OUT STRUCTURE  AVIP
*"      T_FILTER1 OPTIONAL
*"      T_FILTER2 OPTIONAL
*"--------------------------------------------------------------------


  DATA: BEGIN OF kidno_tab OCCURS 10,
          nummer LIKE febep-zuonr,
        END OF kidno_tab,
        s_bsis   TYPE STANDARD TABLE OF bsis,
        h_bsis   TYPE bsis,
        lv_zuonr TYPE dzuonr.

  FIELD-SYMBOLS : <fs_febep> TYPE febep,
                  <fs_zuonr> TYPE dzuonr.

  DATA: lv_fname1(40),lv_febep TYPE febep.
  FIELD-SYMBOLS: <lw_febep> TYPE febep.

  lv_fname1 = '(RFEBBU10)FEBEP'.
  ASSIGN (lv_fname1) TO <lw_febep>.
  IF <lw_febep>-zuonr IS INITIAL.
    kidno_tab-nummer = 'HSBC000000'.
    APPEND kidno_tab.
  ELSE.
    kidno_tab-nummer = <lw_febep>-zuonr.
    APPEND kidno_tab.
  ENDIF.

  LOOP AT t_avip_in WHERE bukrs IS NOT INITIAL.
    DATA(lv_bukrs) = t_avip_in-bukrs.
    IF lv_bukrs IS NOT INITIAL.
      EXIT.
    ENDIF.
  ENDLOOP.

***Selecting the table based on Check
  SELECT * FROM bsis INTO TABLE s_bsis WHERE zuonr = kidno_tab-nummer AND bschl = '50' AND hkont LIKE '%%%%%%%%%2'
*End of change
  AND xopvw = 'X'.
*    AND xref1 = lv_sub .
  IF sy-subrc = 0.
    LOOP AT s_bsis INTO h_bsis.
      t_avip_out-koart = 'S'.
      t_avip_out-konto = h_bsis-hkont.
      t_avip_out-sfeld = 'ZUONR'.
      t_avip_out-swert = h_bsis-zuonr.
      APPEND t_avip_out.
    ENDLOOP.
  ELSE.
    TRANSLATE kidno_tab-nummer TO LOWER CASE.
    SELECT * FROM bsis INTO TABLE s_bsis
     WHERE zuonr = kidno_tab-nummer
     AND bschl = '50' AND hkont LIKE '%%%%%%%%%2' AND xopvw = 'X'.
    IF sy-subrc = 0.
      LOOP AT s_bsis INTO h_bsis.
        t_avip_out-koart = 'S'.
        t_avip_out-konto = h_bsis-hkont.
        t_avip_out-sfeld = 'ZUONR'.
        t_avip_out-swert = h_bsis-zuonr.
        APPEND t_avip_out.
      ENDLOOP.
    ELSE.
    ENDIF.
  ENDIF.
*  ENDLOOP.

  IF t_avip_out IS INITIAL.
    t_avip_out-swert = <lw_febep>-zuonr.
*    t_avip_out-swert+10(4) = '0000'.
    t_avip_out-sfeld  = 'ZUONR'.
    t_avip_out-koart = 'S'.
    APPEND t_avip_out.
  ENDIF.
  """"vd~end changes""""""""""""""""""""""""""""""""""
ENDFUNCTION.
