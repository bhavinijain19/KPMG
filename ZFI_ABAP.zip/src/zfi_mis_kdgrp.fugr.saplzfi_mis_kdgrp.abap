*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_MIS_KDGRPTOP.                 " Global Declarations
  INCLUDE LZFI_MIS_KDGRPUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_MIS_KDGRPF...                 " Subroutines
* INCLUDE LZFI_MIS_KDGRPO...                 " PBO-Modules
* INCLUDE LZFI_MIS_KDGRPI...                 " PAI-Modules
* INCLUDE LZFI_MIS_KDGRPE...                 " Events
* INCLUDE LZFI_MIS_KDGRPP...                 " Local class implement.
* INCLUDE LZFI_MIS_KDGRPT99.                 " ABAP Unit tests
  INCLUDE LZFI_MIS_KDGRPF00                       . " subprograms
  INCLUDE LZFI_MIS_KDGRPI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
