*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_TE_BUPLA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_TE_BUPLA        .

  PERFORM TABLEPROC.

ENDFUNCTION.
