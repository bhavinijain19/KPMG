FUNCTION ZFI_WITH_00001030.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_BKDF) LIKE  BKDF STRUCTURE  BKDF
*"     VALUE(I_UF05A) LIKE  UF05A STRUCTURE  UF05A
*"     VALUE(I_XVBUP) LIKE  OFIWA-XVBUP DEFAULT 'X'
*"  TABLES
*"      T_AUSZ1 STRUCTURE  AUSZ1 OPTIONAL
*"      T_AUSZ2 STRUCTURE  AUSZ2 OPTIONAL
*"      T_AUSZ3 STRUCTURE  AUSZ_CLR OPTIONAL
*"      T_BKP1 STRUCTURE  BKP1
*"      T_BKPF STRUCTURE  BKPF
*"      T_BSEC STRUCTURE  BSEC
*"      T_BSED STRUCTURE  BSED
*"      T_BSEG STRUCTURE  BSEG
*"      T_BSET STRUCTURE  BSET
*"      T_BSEU STRUCTURE  BSEU
*"--------------------------------------------------------------------

  IF sy-tcode = 'MIRO' OR sy-tcode = 'MIR7' OR sy-tcode = 'MIR4'.

    IF t_bseg IS NOT INITIAL.
      DATA(lv_tax_found) = abap_false.

      LOOP AT t_bseg ASSIGNING FIELD-SYMBOL(<fs_bseg>) WHERE
        qsskz IS NOT INITIAL AND ktosl = 'WIT'.
*        IF <fs_bseg>-ktosl = 'WIT'.
        lv_tax_found = abap_true.
        EXIT.
*        ENDIF.
      ENDLOOP.

      IF lv_tax_found = abap_false.
        MESSAGE 'Withholding tax is mandatory.' TYPE 'E'.
      ENDIF.
    ENDIF.

  ENDIF.




ENDFUNCTION.
