*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PIPES_BANK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PIPES_BANK      .

  PERFORM TABLEPROC.

ENDFUNCTION.
