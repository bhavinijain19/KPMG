*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_ISD_SPLITTOP.                 " Global Declarations
  INCLUDE LZFI_ISD_SPLITUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_ISD_SPLITF...                 " Subroutines
* INCLUDE LZFI_ISD_SPLITO...                 " PBO-Modules
* INCLUDE LZFI_ISD_SPLITI...                 " PAI-Modules
* INCLUDE LZFI_ISD_SPLITE...                 " Events
* INCLUDE LZFI_ISD_SPLITP...                 " Local class implement.
* INCLUDE LZFI_ISD_SPLITT99.                 " ABAP Unit tests
  INCLUDE LZFI_ISD_SPLITF00                       . " subprograms
  INCLUDE LZFI_ISD_SPLITI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
