@AbapCatalog.sqlViewName: 'ZFI_RSEG_PO'
@AbapCatalog.compiler.CompareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'CDS view for RSEG Table'
define view ZFI_RSEG_POCDS as select from rseg as b
{
    key b.belnr as belnr,
    key b.gjahr as gjahr,
    key b.buzei as buzei,
        b.ebeln as ebeln,
        b.ebelp as ebelp,
        b.matnr as matnr ,
        b.bukrs as bukrs,
        b.werks as werks,
        b.menge as menge,
        b.kschl as kschl,
        b.wrbtr as wrbtr,
        b.shkzg as shkzg,
        b.lifnr as lifnr,
        b.bklas as bklas,
        b.bnkan as bnkan,
        b.xblnr as xblnr,
        b.tbtkz as tbtkz
        
}
