*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_EXP_SALESTOP.                 " Global Data
  INCLUDE LZFI_EXP_SALESUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_EXP_SALESF...                 " Subroutines
* INCLUDE LZFI_EXP_SALESO...                 " PBO-Modules
* INCLUDE LZFI_EXP_SALESI...                 " PAI-Modules
* INCLUDE LZFI_EXP_SALESE...                 " Events
* INCLUDE LZFI_EXP_SALESP...                 " Local class implement.
* INCLUDE LZFI_EXP_SALEST99.                 " ABAP Unit tests
  INCLUDE LZFI_EXP_SALESF00                       . " subprograms
  INCLUDE LZFI_EXP_SALESI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
