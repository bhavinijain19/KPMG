FUNCTION-POOL ZFI_GSTIN_EXL              MESSAGE-ID SV.

* INCLUDE LZFI_GSTIN_EXLD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GSTIN_EXLT00                       . "view rel. data dcl.
