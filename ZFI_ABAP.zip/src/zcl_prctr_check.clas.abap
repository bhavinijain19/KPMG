class ZCL_PRCTR_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_BADI_PCA_ASSIGNMT_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_PRCTR_CHECK IMPLEMENTATION.


  method IF_EX_BADI_PCA_ASSIGNMT_CHECK~ASSIGNMENT_CHECK.


  endmethod.
ENDCLASS.
