*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_EXP_EXTRA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_EXP_EXTRA       .

  PERFORM TABLEPROC.

ENDFUNCTION.
