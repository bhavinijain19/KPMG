*----------------------------------------------------------------------*
***INCLUDE LZFI_GSTIN_INCF01.
*----------------------------------------------------------------------*
FORM create_data.
  IF zfi_gstin_inc-lifnr IS NOT INITIAL.
    zfi_gstin_inc-change_by = sy-uname.
    zfi_gstin_inc-change_date = sy-datum.
    zfi_gstin_inc-change_time = sy-uzeit.
  ENDIF.
ENDFORM.
