*&---------------------------------------------------------------------*
*& Report  ZFI_CRITICAL_OD
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zfi_critical_od.

INCLUDE zfi_critical_od_top.
INCLUDE zfi_critical_od_ss.
INCLUDE zfi_critical_od_form.

START-OF-SELECTION.



  IF p_chk IS NOT INITIAL OR p_chk1 IS NOT INITIAL OR p_chk2 IS NOT INITIAL.
    PERFORM authority_check.
    PERFORM get_data.
    PERFORM sent_mail.
  ELSE.
    PERFORM authority_check.
    PERFORM get_data.
    IF P_SQL IS NOT INITIAL.
    PERFORM SQL.
    ENDIF.
    PERFORM fcat.
    PERFORM display.
  ENDIF.
