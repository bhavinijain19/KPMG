*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GSTIN_INCTOP.                 " Global Data
  INCLUDE LZFI_GSTIN_INCUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GSTIN_INCF...                 " Subroutines
* INCLUDE LZFI_GSTIN_INCO...                 " PBO-Modules
* INCLUDE LZFI_GSTIN_INCI...                 " PAI-Modules
* INCLUDE LZFI_GSTIN_INCE...                 " Events
* INCLUDE LZFI_GSTIN_INCP...                 " Local class implement.
* INCLUDE LZFI_GSTIN_INCT99.                 " ABAP Unit tests
  INCLUDE LZFI_GSTIN_INCF00                       . " subprograms
  INCLUDE LZFI_GSTIN_INCI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzfi_gstin_incf01.
