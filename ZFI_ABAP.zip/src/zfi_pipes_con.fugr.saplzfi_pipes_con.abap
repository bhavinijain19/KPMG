*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PIPES_CONTOP.                 " Global Declarations
  INCLUDE LZFI_PIPES_CONUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PIPES_CONF...                 " Subroutines
* INCLUDE LZFI_PIPES_CONO...                 " PBO-Modules
* INCLUDE LZFI_PIPES_CONI...                 " PAI-Modules
* INCLUDE LZFI_PIPES_CONE...                 " Events
* INCLUDE LZFI_PIPES_CONP...                 " Local class implement.
* INCLUDE LZFI_PIPES_CONT99.                 " ABAP Unit tests
  INCLUDE LZFI_PIPES_CONF00                       . " subprograms
  INCLUDE LZFI_PIPES_CONI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
