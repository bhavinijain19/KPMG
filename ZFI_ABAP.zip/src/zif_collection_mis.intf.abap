interface ZIF_COLLECTION_MIS
  public .


  methods GET_DATA
    importing
      !KVGR1 type ANY TABLE optional
      !KVGR2 type ANY TABLE optional
      !VKBUR type ANY TABLE optional
      !KUNNR type ANY TABLE optional
      !SPART type ANY TABLE
      !VTWEG type ANY TABLE
      !VKORG type ANY TABLE
    changing
      !LT_KNVV type ZFI_COLL_MIS_KNVV_TT .
  methods PROCESS_DATA
    importing
      !START_DATE type DATUM
      !END_DATE type DATUM
      !BLART type ANY TABLE
      !BUKRS type ANY TABLE
      !LT_KNVV type ZFI_COLL_MIS_KNVV_TT
    changing
      !LT_FINAL type ZFI_COLLECTION_MIS_TT .
  methods DISPLAY_DATA .
  methods FILTER_DATA
    importing
      !START_DATE type DATUM
      !END_DATE type DATUM
      !BLART type ANY TABLE
      !BUKRS type ANY TABLE
      !LT_KNVV type ZFI_COLL_MIS_KNVV_TT
    changing
      !LT_DETAIL type ZFI_COLLECTION_MIS_DETAIL_TT .
endinterface.
