*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_OD_LEGAL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_OD_LEGAL        .

  PERFORM TABLEPROC.

ENDFUNCTION.
