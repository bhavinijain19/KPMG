*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_GSTIN_INC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_GSTIN_INC       .

  PERFORM TABLEPROC.

ENDFUNCTION.
