FUNCTION-POOL ZFI_OD_LEGAL               MESSAGE-ID SV.

* INCLUDE LZFI_OD_LEGALD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_OD_LEGALT00                        . "view rel. data dcl.
