*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_COST
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_COST            .

  PERFORM TABLEPROC.

ENDFUNCTION.
