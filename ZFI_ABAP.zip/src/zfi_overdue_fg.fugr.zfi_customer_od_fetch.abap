FUNCTION zfi_customer_od_fetch.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(KUNNR) TYPE  KUNNR
*"     REFERENCE(BUKRS) TYPE  BUKRS
*"     REFERENCE(VKORG) TYPE  VKORG OPTIONAL
*"     REFERENCE(VTWEG) TYPE  VTWEG OPTIONAL
*"     REFERENCE(SPART) TYPE  SPART OPTIONAL
*"     REFERENCE(ZTERM) TYPE  DZTERM OPTIONAL
*"  EXPORTING
*"     REFERENCE(OD_AMT) TYPE  DMBTR
*"     REFERENCE(MESSAGE_DETAIL) TYPE  CHAR100
*"----------------------------------------------------------------------
  TYPES: BEGIN OF ty_credit,
           bukrs         TYPE bsid-bukrs,
           kunnr         TYPE bsid-kunnr,
           shkzg         TYPE bsid-shkzg,
           credit_amount TYPE p LENGTH 16 DECIMALS 2,
         END OF ty_credit,

         BEGIN OF ty_debit,
           bukrs    TYPE bsid-bukrs,
           kunnr    TYPE bsid-kunnr,
           umsks    TYPE bsid-umsks,
           umskz    TYPE bsid-umskz,
           augdt    TYPE bsid-augdt,
           augbl    TYPE bsid-augbl,
           zuonr    TYPE bsid-zuonr,
           gjahr    TYPE bsid-gjahr,
           belnr    TYPE bsid-belnr,
           buzei    TYPE bsid-buzei,
           budat    TYPE bsid-budat,
           blart    TYPE bsid-blart,
           shkzg    TYPE bsid-shkzg,
           dmbtr    TYPE bsid-dmbtr,
           due_date TYPE bsid-budat,
         END OF ty_debit.
  DATA: lt_credit TYPE TABLE OF ty_credit,
        lt_debit  TYPE TABLE OF ty_debit,
        ls_debit  TYPE ty_debit.
  DATA: lv_zterm  TYPE knvv-zterm,
        lv_credit TYPE p LENGTH 16 DECIMALS 2,
        lv_days   TYPE dztage,
        lv_diff   TYPE i.

  SELECT bukrs,
         kunnr,
         shkzg,
         SUM( dmbtr ) AS credit_amount
    FROM bsid
    INTO TABLE @lt_credit
    WHERE bukrs = @bukrs
      AND kunnr = @kunnr
      AND shkzg = 'H'
*      AND umskz NOT IN ( '4' , '5' ) "Added By Sahil Patel on 06.09.2024
      AND umskz NOT IN ( 'I' , 'Q' ) "Changed by UDAYABAP03 on 31.03.2026
    GROUP BY bukrs , kunnr , shkzg.

" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
  lv_credit = VALUE #( lt_credit[ 1 ]-credit_amount OPTIONAL ). "#EC CI_NOORDER
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC

  IF zterm IS INITIAL.
    SELECT SINGLE zterm
         FROM knvv
         INTO lv_zterm
         WHERE kunnr = kunnr
           AND vkorg = vkorg
           AND vtweg = vtweg
           AND spart = spart.
  ELSE.
    lv_zterm = zterm.
  ENDIF."IF ZTERM IS INITIAL.

  IF lv_zterm IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE * FROM t052 INTO @DATA(ls_t052) WHERE zterm = @lv_zterm.
    SELECT * FROM t052 INTO @DATA(ls_t052) UP TO 1 ROWS WHERE zterm = @lv_zterm ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

    IF ls_t052 IS NOT INITIAL.
      IF ls_t052-ztag3 IS NOT INITIAL.
        lv_days = ls_t052-ztag3.
      ELSEIF ls_t052-ztag2 IS NOT INITIAL.
        lv_days = ls_t052-ztag2.
      ELSEIF ls_t052-ztag1 IS NOT INITIAL.
        lv_days = ls_t052-ztag1.
      ENDIF."IF ls_t052-ztag3 IS NOT INITIAL.
    ENDIF.


    SELECT bukrs
           kunnr
           umsks
           umskz
           augdt
           augbl
           zuonr
           gjahr
           belnr
           buzei
           budat
           blart
           shkzg
           dmbtr
      FROM bsid
      INTO CORRESPONDING FIELDS OF TABLE lt_debit
      WHERE bukrs = bukrs
        AND kunnr = kunnr
*        AND umskz NOT IN ( '4' , '5' ).
        AND umskz NOT IN ( 'I' , 'Q' ). "Changed by UDAYABAP03 on 30.03.2026

    LOOP AT lt_debit ASSIGNING FIELD-SYMBOL(<ls_debit>) WHERE shkzg = 'S'. "" SHKZG = 'S' is Added By Sahil Patel on 06.09.2024
      <ls_debit>-due_date = <ls_debit>-budat + lv_days.

      lv_diff = sy-datum - <ls_debit>-due_date.
      IF lv_diff > 0.
        od_amt = od_amt + <ls_debit>-dmbtr.
      ENDIF.
    ENDLOOP.

    od_amt = od_amt - lv_credit.

    IF od_amt > 0.
      message_detail = 'OVERDUE DEBIT IS HIGH'.
    ELSEIF od_amt < 0.
      message_detail = 'OVERDUE CREDIT IS HIGH'.
    ENDIF.

  ELSE.
    message_detail = 'PAYMENT TERMS NOT MAINTAINED FOR CUSTOMER'.
  ENDIF."  IF lv_zterm IS NOT INITIAL.



ENDFUNCTION.
