*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_CASH_DAYS...................................*
DATA:  BEGIN OF STATUS_ZFI_CASH_DAYS                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CASH_DAYS                 .
CONTROLS: TCTRL_ZFI_CASH_DAYS
            TYPE TABLEVIEW USING SCREEN '9002'.
*...processing: ZFI_CASH_DAY_RCL................................*
DATA:  BEGIN OF STATUS_ZFI_CASH_DAY_RCL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CASH_DAY_RCL              .
CONTROLS: TCTRL_ZFI_CASH_DAY_RCL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_CASH_DAYS                 .
TABLES: *ZFI_CASH_DAY_RCL              .
TABLES: ZFI_CASH_DAYS                  .
TABLES: ZFI_CASH_DAY_RCL               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
