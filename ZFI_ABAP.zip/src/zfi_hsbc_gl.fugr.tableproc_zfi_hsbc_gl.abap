*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_HSBC_GL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_HSBC_GL         .

  PERFORM TABLEPROC.

ENDFUNCTION.
