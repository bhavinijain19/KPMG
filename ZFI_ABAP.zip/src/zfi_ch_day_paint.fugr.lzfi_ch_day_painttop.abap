FUNCTION-POOL ZFI_CH_DAY_PAINT           MESSAGE-ID SV.

* INCLUDE LZFI_CH_DAY_PAINTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_CH_DAY_PAINTT00                    . "view rel. data dcl.
