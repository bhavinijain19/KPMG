*&---------------------------------------------------------------------*
*& Report ZFI_CUSTLEDGER2CPI_V2
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zfi_custledger2cpi_v2.

INCLUDE zfi_custledger2cpi_v2_top.
INCLUDE zfi_custledger2cpi_v2_form.

START-OF-SELECTION.

  PERFORM get_cust.
  PERFORM fill_cat.

  IF it_final[] IS NOT INITIAL.
    IF p_pdf EQ 'X'.
      PERFORM smartform1.
    ELSEIF p_alv EQ 'X'.
      PERFORM display.
    ELSEIF p_cpi EQ 'X'.
      PERFORM send2cpi.
    ENDIF.
  ELSE.
    MESSAGE 'Data not Exist' TYPE 'E'.
    LEAVE TO SCREEN 0.
  ENDIF.
