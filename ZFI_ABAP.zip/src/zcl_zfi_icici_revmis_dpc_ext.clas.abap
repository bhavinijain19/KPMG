class ZCL_ZFI_ICICI_REVMIS_DPC_EXT definition
  public
  inheriting from ZCL_ZFI_ICICI_REVMIS_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_ENTITY
    redefinition .
protected section.

  methods ICICIREVMISSET_CREATE_ENTITY
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_ZFI_ICICI_REVMIS_DPC_EXT IMPLEMENTATION.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY.
  endmethod.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_ENTITY.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_ENTITY
*  EXPORTING
**    iv_entity_name          =
**    iv_entity_set_name      =
**    iv_source_name          =
*    IO_DATA_PROVIDER        =
**    it_key_tab              =
**    it_navigation_path      =
**    io_tech_request_context =
**  IMPORTING
**    er_entity               =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.


  method ICICIREVMISSET_CREATE_ENTITY.


   DATA: ls_request_input TYPE ZCL_ZFI_ICICI_REVMIS_MPC_EXT=>ts_icicirevmis,
lt_rundate       TYPE TABLE OF zicici_log,
        ls_rundate       TYPE zicici_log,
        lt_bkpf          TYPE TABLE OF bkpf,
        lt_bseg          TYPE TABLE OF bseg,
        ls_bseg          TYPE bseg,
        " Corrected Interface Name below
        lo_msg           TYPE REF TO /iwbep/if_message_container.

  " Get the message container from the framework context
  lo_msg = me->/iwbep/if_mgw_conv_srv_runtime~get_message_container( ).

  " 1. Read incoming data
  io_data_provider->read_entry_data( IMPORTING es_data = ls_request_input ).

  " 2. Check if log already exists
  SELECT * FROM zicici_log
    INTO TABLE lt_rundate
    WHERE paydocno = ls_request_input-unique_ref_no.

  IF sy-subrc <> 0.
    lo_msg->add_message_text_only(
      EXPORTING
        iv_msg_type = /iwbep/if_message_container=>gcs_message_type-error
        iv_msg_text = |No existing log record found for: { ls_request_input-unique_ref_no }| ).

    RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
      EXPORTING
        message_container = lo_msg.
  ENDIF.

  " 3. Process Updates using MODIFY
  TRY.
      LOOP AT lt_rundate INTO ls_rundate.

        " Update log work area
        ls_rundate-status         = ls_request_input-status.
        ls_rundate-payment_method = ls_request_input-pay_prod_code.

        IF ls_request_input-pay_prod_code = 'AUTORTGS'.
          ls_rundate-utr_no = ls_request_input-proce_remark.
        ELSE.
          ls_rundate-utr_no = ls_request_input-unique_ref_no.
        ENDIF.

        " Update Database table using MODIFY
        MODIFY zicici_log FROM ls_rundate.

        " 4. Update FI Documents if paid
        IF ls_request_input-status = 'paid'.
          SELECT * FROM bkpf INTO TABLE lt_bkpf
            WHERE bukrs = ls_rundate-bukrs AND belnr = ls_rundate-belnr AND gjahr = ls_rundate-gjahr.

          SELECT * FROM bseg INTO TABLE lt_bseg
            WHERE bukrs = ls_rundate-bukrs AND belnr = ls_rundate-belnr AND gjahr = ls_rundate-gjahr.

          LOOP AT lt_bseg INTO ls_bseg.
            ls_bseg-xref3 = COND #( WHEN ls_request_input-pay_prod_code = 'AUTORTGS'
                                    THEN ls_request_input-proce_remark
                                    ELSE ls_request_input-unique_ref_no ).
            " Use MODIFY for internal table update
            MODIFY lt_bseg FROM ls_bseg.
          ENDLOOP.

          CALL FUNCTION 'CHANGE_DOCUMENT'
            TABLES
              t_bkpf = lt_bkpf
              t_bseg = lt_bseg.
        ENDIF.
      ENDLOOP.

  CATCH cx_root INTO DATA(lo_ex).
      " Convert String to BAPI_MSG type
      DATA(lv_error_text) = lo_ex->get_text( ).

      lo_msg->add_message_text_only(
        EXPORTING
          iv_msg_type = /iwbep/if_message_container=>gcs_message_type-error
          iv_msg_text = CONV #( lv_error_text ) ). " Cast string to compatible type

      RAISE EXCEPTION TYPE /iwbep/cx_mgw_tech_exception
        EXPORTING
          message_container = lo_msg.
  ENDTRY.

  er_entity = ls_request_input.



  endmethod.
ENDCLASS.
