*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GSTIN_EXLTOP.                 " Global Data
  INCLUDE LZFI_GSTIN_EXLUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GSTIN_EXLF...                 " Subroutines
* INCLUDE LZFI_GSTIN_EXLO...                 " PBO-Modules
* INCLUDE LZFI_GSTIN_EXLI...                 " PAI-Modules
* INCLUDE LZFI_GSTIN_EXLE...                 " Events
* INCLUDE LZFI_GSTIN_EXLP...                 " Local class implement.
* INCLUDE LZFI_GSTIN_EXLT99.                 " ABAP Unit tests
  INCLUDE LZFI_GSTIN_EXLF00                       . " subprograms
  INCLUDE LZFI_GSTIN_EXLI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzfi_gstin_exlf01.
