class ZCL_ZFI_ICICI_REVMI_01_DPC_EXT definition
  public
  inheriting from ZCL_ZFI_ICICI_REVMI_01_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_ICICI_REVMI_01_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    DATA: ls_deep_data TYPE zcl_zfi_icici_revmi_01_mpc_ext=>ty_deep_entity,
          lt_db_insert TYPE TABLE OF zicici_reverse.
    DATA: it_rundate TYPE TABLE OF zicici_log,
          wa_rundate TYPE zicici_log.

    DATA: w_len            TYPE i,
          lv_off           TYPE i,
          final_utr_eft_no TYPE c LENGTH 18.
    DATA: lt_bkdf TYPE TABLE OF bkdf.
    DATA : lt_bkpf  TYPE TABLE OF bkpf,
           wa_bkpf  TYPE bkpf,
           lt_bsec  TYPE TABLE OF bsec,
           wa_bseg  TYPE bseg,
           lt_bsed  TYPE TABLE OF bsed,
           lt_bseg  TYPE TABLE OF bseg,
           lt_bseg2 TYPE TABLE OF bseg,
           wa_bseg2 TYPE bseg,
           lt_bset  TYPE TABLE OF bset.
    io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_data ).
    IF ls_deep_data-toitems IS NOT INITIAL.
      SELECT * FROM zicici_reverse
        FOR ALL ENTRIES IN @ls_deep_data-toitems
        WHERE pay_prod_code = @ls_deep_data-toitems-pay_prod_code
        AND bene_code = @ls_deep_data-toitems-bene_code
        AND unique_ref_no = @ls_deep_data-toitems-unique_ref_no
        INTO TABLE @DATA(lt_existing).
    ENDIF.
    LOOP AT ls_deep_data-toitems ASSIGNING FIELD-SYMBOL(<fs_item>).

      DATA(lv_error_flag) = abap_false.
      READ TABLE lt_existing TRANSPORTING NO FIELDS
                  WITH KEY pay_prod_code = <fs_item>-pay_prod_code
                  bene_code = <fs_item>-bene_code
                  unique_ref_no = <fs_item>-unique_ref_no             .
      IF sy-subrc = 0.
        <fs_item>-zmessage = <fs_item>-zmessage && 'ReverseMIS file Data Exists'."<fs_item>-zmessage && 'DATA EXIST; '.
        <fs_item>-zstatus = 'FALSE'.
        <fs_item>-zstatuscode = '500'.
        ls_deep_data-status = 'FALSE'.
        ls_deep_data-message = 'ReverseMIS file Data Exists'.
        lv_error_flag = abap_true.
      ENDIF.
      IF <fs_item>-pay_prod_code IS INITIAL OR <fs_item>-bene_code IS INITIAL
              OR <fs_item>-unique_ref_no IS INITIAL.
        <fs_item>-zmessage = <fs_item>-zmessage && 'Mandatory keys missing; '.
        <fs_item>-zstatus = 'FALSE'.
        <fs_item>-zstatuscode = '500'.
        ls_deep_data-status = 'FALSE'.
        ls_deep_data-message = 'Mandatory keys missing'.
        lv_error_flag = abap_true.
      ENDIF.

      SELECT * INTO TABLE it_rundate
FROM zicici_log
WHERE paydocno = <fs_item>-unique_ref_no.
      LOOP AT it_rundate INTO wa_rundate.
        UPDATE zicici_log
                SET utr_no         = <fs_item>-cms_no
                    status         = <fs_item>-status
                    payment_method = <fs_item>-pay_prod_code
                WHERE paydocno = <fs_item>-unique_ref_no
                  AND belnr    = wa_rundate-belnr
                  AND gjahr    = wa_rundate-gjahr
                  AND bukrs    = wa_rundate-bukrs.
        TRANSLATE <fs_item>-status TO UPPER CASE.
        IF <fs_item>-status = 'PAID'.

          SELECT * INTO TABLE lt_bkpf
            FROM bkpf
            WHERE bukrs = wa_rundate-bukrs
              AND belnr = wa_rundate-belnr
              AND gjahr = wa_rundate-gjahr.

          SELECT * INTO TABLE lt_bseg
            FROM bseg
            WHERE bukrs = wa_rundate-bukrs
              AND belnr = wa_rundate-belnr
              AND gjahr = wa_rundate-gjahr.

          LOOP AT lt_bseg INTO wa_bseg.

            "pt
            w_len = strlen( <fs_item>-cms_no ).

            IF w_len > 18.
              lv_off = w_len - 18.
              final_utr_eft_no = <fs_item>-cms_no+lv_off(18).
            ELSE.
              final_utr_eft_no = <fs_item>-cms_no.
            ENDIF.
            "pt

*            IF <fs_item>-pay_prod_code = 'AUTORTGS'.
*              wa_bseg-xref3 = <fs_item>-proce_remark.

*     wa_bseg-kidno = FINAL_utr_eft_no.
            wa_bseg-zuonr = final_utr_eft_no.

*            ELSE.

*              wa_bseg-xref3 = <fs_item>-unique_ref_no.
*            ENDIF.

            MODIFY lt_bseg FROM wa_bseg.

          ENDLOOP.

          CALL FUNCTION 'CHANGE_DOCUMENT'
            TABLES
*             t_bkpf = lt_bkpf
*             t_bseg = lt_bseg
              t_bkdf = lt_bkdf
              t_bkpf = lt_bkpf
              t_bsec = lt_bsec
              t_bsed = lt_bsed
              t_bseg = lt_bseg
              t_bset = lt_bset.

          COMMIT WORK.

        ENDIF.

      ENDLOOP.
      IF lv_error_flag = abap_false.
        <fs_item>-zmessage = 'ReverseMIS file for payment modal transfered'.
        <fs_item>-zstatus = 'TRUE'.
        <fs_item>-zstatuscode = '200'.
        ls_deep_data-status = 'TRUE'.
        ls_deep_data-message = 'ReverseMIS file for payment modal transfered'.
        APPEND INITIAL LINE TO lt_db_insert ASSIGNING FIELD-SYMBOL(<fs_db>).
        MOVE-CORRESPONDING <fs_item> TO <fs_db>.
*        <fs_item>-zmessage = 'ReverseMIS file for payment modal transfered'.
*        <fs_item>-zstatus = 'TRUE'.
*        <fs_item>-zstatuscode = '200'.
      ENDIF.
    ENDLOOP.
    IF lt_db_insert IS NOT INITIAL.
      MODIFY zicici_reverse FROM TABLE lt_db_insert.
      IF sy-subrc = 0.
        COMMIT WORK.
      ELSE.
        ROLLBACK WORK.
      ENDIF.
    ENDIF.
    copy_data_to_ref( EXPORTING is_data = ls_deep_data
                  CHANGING  cr_data = er_deep_entity ).
  ENDMETHOD.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
**  EXPORTING
**    iv_entity_name          =
**    iv_entity_set_name      =
**    iv_source_name          =
**    it_key_tab              =
**    it_navigation_path      =
**    io_tech_request_context =
**  IMPORTING
**    er_entity               =
**    es_response_context     =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
**  EXPORTING
**    iv_entity_name           =
**    iv_entity_set_name       =
**    iv_source_name           =
**    it_filter_select_options =
**    it_order                 =
**    is_paging                =
**    it_navigation_path       =
**    it_key_tab               =
**    iv_filter_string         =
**    iv_search_string         =
**    io_tech_request_context  =
**  IMPORTING
**    er_entityset             =
**    es_response_context      =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.
ENDCLASS.
