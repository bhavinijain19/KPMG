*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_COD_MAIL_DIV................................*
DATA:  BEGIN OF STATUS_ZFI_COD_MAIL_DIV              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_COD_MAIL_DIV              .
CONTROLS: TCTRL_ZFI_COD_MAIL_DIV
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_COD_MAIL_DIV              .
TABLES: ZFI_COD_MAIL_DIV               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
