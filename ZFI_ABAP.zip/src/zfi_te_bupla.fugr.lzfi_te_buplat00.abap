*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_TE_BUPLA....................................*
DATA:  BEGIN OF STATUS_ZFI_TE_BUPLA                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_TE_BUPLA                  .
CONTROLS: TCTRL_ZFI_TE_BUPLA
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_TE_BUPLA                  .
TABLES: ZFI_TE_BUPLA                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
