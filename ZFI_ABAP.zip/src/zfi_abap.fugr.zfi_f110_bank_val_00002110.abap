FUNCTION zfi_f110_bank_val_00002110.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_REGUH) LIKE  REGUH STRUCTURE  REGUH
*"  TABLES
*"      T_REGUP STRUCTURE  REGUP
*"      T_REGUP_LST STRUCTURE  REGUP_LST
*"  CHANGING
*"     VALUE(C_REGUH_LST) LIKE  REGUH_LST STRUCTURE  REGUH_LST
*"----------------------------------------------------------------------

  IF c_reguh_lst IS NOT INITIAL.

    SELECT lifnr, bukrs FROM lfb1 INTO TABLE @DATA(lt_lfb1)
      WHERE lifnr = @c_reguh_lst-lifnr.

    IF sy-subrc = 0.
      SELECT lifnr, banks, bankl, bankn, bkont FROM lfbk
        INTO TABLE @DATA(lt_lfbk) FOR ALL ENTRIES IN @lt_lfb1
        WHERE lifnr = @lt_lfb1-lifnr AND bkont = @c_reguh_lst-zbkon.
      IF lt_lfbk IS NOT INITIAL.
        LOOP AT lt_lfbk ASSIGNING FIELD-SYMBOL(<fs_lfbk>).
          IF <fs_lfbk>-bankn <> c_reguh_lst-zbnkn.
            MESSAGE i005(zfi_msgs) WITH 'Invalid Bank Account' DISPLAY LIKE 'E'.
          ELSEIF <fs_lfbk>-bkont <> c_reguh_lst-zbkon.
            MESSAGE i006(zfi_msgs) WITH 'Invalid Bank Control Key' DISPLAY LIKE 'E'.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.

  ENDIF.

ENDFUNCTION.
