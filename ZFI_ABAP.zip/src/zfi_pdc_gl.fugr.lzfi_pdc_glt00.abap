*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PDC_GL......................................*
DATA:  BEGIN OF STATUS_ZFI_PDC_GL                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PDC_GL                    .
CONTROLS: TCTRL_ZFI_PDC_GL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_PDC_GL                    .
TABLES: ZFI_PDC_GL                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
