*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_CASH_LIMIT..................................*
DATA:  BEGIN OF STATUS_ZFI_CASH_LIMIT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CASH_LIMIT                .
CONTROLS: TCTRL_ZFI_CASH_LIMIT
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_CASH_LIMIT                .
TABLES: ZFI_CASH_LIMIT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
