*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PIPES_BANK..................................*
DATA:  BEGIN OF STATUS_ZFI_PIPES_BANK                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PIPES_BANK                .
CONTROLS: TCTRL_ZFI_PIPES_BANK
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PIPES_BANK                .
TABLES: ZFI_PIPES_BANK                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
