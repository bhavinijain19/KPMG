*&---------------------------------------------------------------------*
*& Include          ZBP_TDS_UPLOADER_TOP
*&---------------------------------------------------------------------*

TYPES: BEGIN OF g_ty_final,
         bukrs            TYPE fiwtin_tan_exem-bukrs,
         koart            TYPE fiwtin_tan_exem-koart,
         accno            TYPE fiwtin_tan_exem-accno,
         fiwtin_tanex_sub TYPE fiwtin_tan_exem-fiwtin_tanex_sub,
         seccode          TYPE fiwtin_tan_exem-seccode,
         witht            TYPE fiwtin_tan_exem-witht,
         wt_withcd        TYPE fiwtin_tan_exem-wt_withcd,
         wt_exdf          TYPE char10,
**         pan_no           TYPE fiwtin_tan_exem-pan_no,
         wt_exdt          TYPE char10,
         wt_exnr          TYPE fiwtin_tan_exem-wt_exnr,
         wt_exrt          TYPE fiwtin_tan_exem-wt_exrt,
         wt_wtexrs        TYPE fiwtin_tan_exem-wt_wtexrs,
         fiwtin_exem_thr  TYPE char30,
         waers            TYPE fiwtin_tan_exem-waers,
**         message          TYPE char100,
         status           TYPE string,
       END OF g_ty_final.

DATA: gt_final TYPE TABLE OF g_ty_final,
      gs_final TYPE g_ty_final,
      gt_out   TYPE TABLE OF alsmex_tabline,
      gs_out   TYPE alsmex_tabline.

DATA: gt_tds TYPE TABLE OF fiwtin_tan_exem,
      gs_tds TYPE fiwtin_tan_exem.

FIELD-SYMBOLS: <fs_data>  TYPE any,
               <fs_field> TYPE any.

DATA : msgno LIKE sy-msgno,
       msgv1 LIKE sy-msgv1,
       msgv2 LIKE sy-msgv2,
       msgv3 LIKE sy-msgv3,
       msgv4 LIKE sy-msgv4.

DATA: lv_mode TYPE char1,
      lv_idx  TYPE kcd_ex_col_n.

DATA: lo_alv     TYPE REF TO cl_salv_table,
      lo_columns TYPE REF TO cl_salv_columns,
      lo_column  TYPE REF TO cl_salv_column_list.
