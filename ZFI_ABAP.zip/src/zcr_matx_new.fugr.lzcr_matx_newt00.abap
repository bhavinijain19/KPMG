*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCR_MATX_NEW....................................*
DATA:  BEGIN OF STATUS_ZCR_MATX_NEW                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCR_MATX_NEW                  .
CONTROLS: TCTRL_ZCR_MATX_NEW
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZCR_MATX_NEW                  .
TABLES: ZCR_MATX_NEW                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
