*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_SALE_SMSTOP.                  " Global Declarations
  INCLUDE LZFI_SALE_SMSUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_SALE_SMSF...                  " Subroutines
* INCLUDE LZFI_SALE_SMSO...                  " PBO-Modules
* INCLUDE LZFI_SALE_SMSI...                  " PAI-Modules
* INCLUDE LZFI_SALE_SMSE...                  " Events
* INCLUDE LZFI_SALE_SMSP...                  " Local class implement.
* INCLUDE LZFI_SALE_SMST99.                  " ABAP Unit tests
  INCLUDE LZFI_SALE_SMSF00                        . " subprograms
  INCLUDE LZFI_SALE_SMSI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
