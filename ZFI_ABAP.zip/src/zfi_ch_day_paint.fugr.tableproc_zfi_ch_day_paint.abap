*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_CH_DAY_PAINT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_CH_DAY_PAINT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
