*&---------------------------------------------------------------------*
*& Report  ZFI_AUC
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

REPORT zfi_auc.
TABLES : bseg, anla.

**======================================================================*
*& TYPE POOLS - USED FOR ALL ALV RELATED OBJECT DECLARATION            *
*======================================================================*
TYPE-POOLS : slis.

DATA: lt_fieldcat  TYPE slis_t_fieldcat_alv,
      lwa_fieldcat TYPE slis_fieldcat_alv,
      gd_layout    TYPE slis_layout_alv,
      gd_repid     LIKE sy-repid,
      lv_ind       TYPE char1,
      lv_ebeln     TYPE ebeln,
      lv_ebelp     TYPE ebelp,
      lv_bwart     TYPE bwart.

DATA: lv_id     LIKE  thead-tdid,
      lv_id1    LIKE  thead-tdid,
      lv_name   LIKE  thead-tdname,
      lv_name1  LIKE  thead-tdname,
      lv_object LIKE  thead-tdobject,
      lt_line1  TYPE TABLE OF tline,
      lt_line2  TYPE TABLE OF tline,
      lt_line3  TYPE TABLE OF tline,
      lwa_line1 TYPE tline,
      lwa_line3 TYPE tline,
      lwa_line2 TYPE tline.

TYPES: BEGIN OF ty_bseg,
         bukrs TYPE bseg-bukrs,
         belnr TYPE bseg-belnr,
         gjahr TYPE bseg-gjahr,
         buzei TYPE bseg-buzei,
         anln1 TYPE bseg-anln1,
         prctr TYPE bseg-prctr,
       END OF ty_bseg.

DATA : it_bseg  TYPE STANDARD TABLE OF ty_bseg,
       it_bseg1 TYPE STANDARD TABLE OF ty_bseg,
       wa_bseg  TYPE ty_bseg.

TYPES: BEGIN OF ty_final,

         bukrs TYPE bseg-bukrs,
         belnr TYPE bseg-belnr,
         gjahr TYPE bseg-gjahr,
         buzei TYPE bseg-buzei,
         bschl TYPE bseg-bschl,
         koart TYPE bseg-koart,
         shkzg TYPE bseg-shkzg,
         dmbtr TYPE bseg-dmbtr,
         sgtxt TYPE bseg-sgtxt,
         anln1 TYPE bseg-anln1,
         anln2 TYPE bseg-anln2,  "Added by Rutvi on 12.06.2024
         anbwa TYPE bseg-anbwa,
         bzdat TYPE bseg-bzdat,
         hkont TYPE bseg-hkont,
         asst  TYPE bseg-anln1,
         prctr TYPE bseg-prctr,
       END OF ty_final.

DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.
*****" Added for auth. at company level by Carina Jose on 30.07.2020
TYPES: BEGIN OF ty_t001,
         bukrs TYPE bukrs,
       END OF ty_t001.
DATA : gt_t001 TYPE STANDARD TABLE OF ty_t001,
       wa_t001 TYPE ty_t001.
*****" Added for auth. at company level by Carina Jose on 30.07.2020

************* Added by Carina Jose on 21.07.2021
TYPES : BEGIN OF ty_anla,
          bukrs TYPE anla-bukrs,
          anln1 TYPE anla-anln1,
          anlkl TYPE anla-anlkl,
        END OF ty_anla.
DATA :  it_anla TYPE STANDARD TABLE OF ty_anla,
        wa_anla TYPE ty_anla.
TYPES: BEGIN OF ty_tvarvc1,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE bseg-anbwa,
         high TYPE tvarv_val,
       END OF ty_tvarvc1.

DATA: lt_acc_key1  TYPE STANDARD TABLE OF ty_tvarvc1.
DATA: lwa_acc_key1 TYPE ty_tvarvc1.

TYPES: BEGIN OF ty_tvarvc2,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE anla-anlkl,
         high TYPE tvarv_val,
       END OF ty_tvarvc2.
DATA: it_tvarvc_ac  TYPE STANDARD TABLE OF ty_tvarvc2.
DATA: wa_tvarvc_ac TYPE ty_tvarvc2.

TYPES : BEGIN OF ty_anep,
          bukrs TYPE anep-bukrs,
          anln1 TYPE anep-anln1,
          gjahr TYPE anep-gjahr,
*            belnr TYPE anep-belnr,
          belnr TYPE bkpf-awkey,
          bwasl TYPE anep-bwasl,
        END OF  ty_anep.
DATA : it_anep  TYPE STANDARD TABLE OF ty_anep,
       it_anep2 TYPE STANDARD TABLE OF ty_anep,
       wa_anep  TYPE ty_anep.

TYPES : BEGIN OF ty_anep1,
          bukrs TYPE anep-bukrs,
          anln1 TYPE anep-anln1,
          gjahr TYPE anep-gjahr,
          belnr TYPE anep-belnr,
          bwasl TYPE anep-bwasl,
          awkey TYPE bkpf-awkey,
          awtyp TYPE anek-awtyp,
        END OF  ty_anep1.
DATA : it_anep1 TYPE STANDARD TABLE OF ty_anep1,
       wa_anep1 TYPE ty_anep1.



TYPES : BEGIN OF ty_bkpf,
          bukrs TYPE bkpf-bukrs,
          belnr TYPE bkpf-belnr,
          gjahr TYPE bkpf-gjahr,
          awtyp TYPE bkpf-awtyp,
          awkey TYPE bkpf-awkey,
        END OF ty_bkpf.
DATA : it_bkpf  TYPE STANDARD TABLE OF ty_bkpf,
       it_bkpf1 TYPE STANDARD TABLE OF ty_bkpf,
       wa_bkpf  TYPE ty_bkpf.

TYPES : BEGIN OF ty_anek,
          bukrs TYPE anek-bukrs,
          anln1 TYPE anek-anln1,
          gjahr TYPE anek-gjahr,
          belnr TYPE bkpf-awkey,
          awtyp TYPE anek-awtyp,
        END OF ty_anek.
DATA : it_anek  TYPE STANDARD TABLE OF ty_anek,
       it_anek1 TYPE STANDARD TABLE OF ty_anek,
       wa_anek  TYPE ty_anek.



CONSTANTS :  c_var_user1  TYPE rvari_vnam VALUE 'ZFI_AUC_TYPE',
             c_type_user1 TYPE rsscr_kind VALUE 'S'.

************* End of changes on 21.07.2021

CONSTANTS : c_aclass TYPE rvari_vnam VALUE 'Z_AUC_ASTCLASS'.

*======================================================================*
*                     SELECTION SCREEN                                 *
*======================================================================*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS : s_bukrs TYPE bseg-bukrs OBLIGATORY. " Updated by Carina Jose on 30.07.2020
PARAMETERS : s_gjahr TYPE bseg-gjahr OBLIGATORY.
*  SELECT-OPTIONS : s_anlkl FOR anla-anlkl OBLIGATORY. " Added by Carina Jose on 30.07.2020
SELECT-OPTIONS : s_anln1 FOR bseg-anln1 OBLIGATORY. " Added by Carina Jose on 30.07.2020
SELECTION-SCREEN END OF BLOCK b1.


START-OF-SELECTION.
  PERFORM authorization_check . " Added for Auth. check by Carina Jose on 30.07.2020
  PERFORM process_data.
  IF it_final IS NOT INITIAL.
    PERFORM build_fieldcatalog.
    PERFORM build_layout.
    PERFORM display_alv_report.
  ELSE.
    MESSAGE 'No data available for the inputted values' TYPE 'S' DISPLAY LIKE 'E'.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  PROCESS_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_data .
***********  Added by Carina Jose on 21.07.2021
*  SELECT bukrs anln1 anlkl
*    FROM anla
*    INTO CORRESPONDING FIELDS OF TABLE it_anla
*    WHERE bukrs = s_bukrs
*    AND   anlkl IN s_anlkl.
*********** End of changes on 21.07.2021

  SELECT sign
   opti
   low
   high INTO CORRESPONDING FIELDS OF TABLE lt_acc_key1
             FROM tvarvc
             WHERE name = c_var_user1 AND
                   type = c_type_user1.
***************************


  SELECT bukrs anln1 gjahr belnr bwasl
    INTO CORRESPONDING FIELDS OF TABLE it_anep
    FROM anep
    FOR ALL ENTRIES IN lt_acc_key1
    WHERE bukrs = s_bukrs
    AND   anln1  IN s_anln1
    AND   gjahr = s_gjahr
    AND   bwasl = lt_acc_key1-low.


  IF it_anep IS NOT INITIAL.
    SELECT bukrs,anln1,gjahr,belnr,awtyp
    INTO CORRESPONDING FIELDS OF TABLE @it_anek
    FROM  anek
    FOR ALL ENTRIES IN @it_anep
    WHERE bukrs = @it_anep-bukrs
    AND   anln1 = @it_anep-anln1
    AND   gjahr = @it_anep-gjahr.
  ENDIF.


  LOOP AT it_anep INTO wa_anep.
    MOVE-CORRESPONDING wa_anep TO wa_anep1.
    READ TABLE it_anek ASSIGNING FIELD-SYMBOL(<fs_anek>) WITH KEY bukrs = wa_anep1-bukrs
                                                                  anln1 = wa_anep1-anln1
                                                                  gjahr = wa_anep1-gjahr
                                                                  belnr = wa_anep1-belnr.
    IF <fs_anek> IS ASSIGNED.
      wa_anep1-awtyp = <fs_anek>-awtyp.
    ENDIF.


    CONCATENATE wa_anep-belnr wa_anep-bukrs wa_anep-gjahr INTO wa_anep1-awkey.

    APPEND wa_anep1 TO it_anep1.
    CLEAR : wa_anep, wa_anep1.
    UNASSIGN : <fs_anek>.
  ENDLOOP.



*************************
  IF it_anep1 IS NOT INITIAL.
    SELECT bukrs belnr gjahr awtyp awkey
    INTO CORRESPONDING FIELDS OF TABLE it_bkpf
    FROM bkpf
    FOR ALL ENTRIES IN it_anep1
    WHERE bukrs = it_anep1-bukrs
    AND   gjahr = it_anep1-gjahr
    AND   awtyp = it_anep1-awtyp
    AND  awkey = it_anep1-awkey.
  ENDIF.


  IF it_bkpf IS NOT INITIAL.
    SELECT bukrs belnr gjahr buzei anln1 prctr FROM bseg INTO TABLE it_bseg
     FOR ALL ENTRIES IN it_bkpf  " added by Carina Jose on 21.07.2021
     WHERE bukrs EQ s_bukrs AND
           belnr = it_bkpf-belnr AND
           gjahr EQ s_gjahr AND
           koart EQ 'A' AND
*          anbwa = lt_acc_key1-low AND
           bschl EQ '75' AND
*          ANLN1 BETWEEN '000003000000' AND '000003999999' . " commented on 21.07.2021
*          ANLN1  = it_anla-anln1. "  added on 21.07.2021
           anln1  IN s_anln1. "  added on 21.07.2021
  ENDIF.

  IF  it_bseg IS NOT INITIAL.
    SELECT bukrs belnr gjahr buzei bschl koart shkzg dmbtr sgtxt anln1 anln2 anbwa bzdat hkont prctr FROM bseg INTO CORRESPONDING FIELDS OF TABLE it_final
      FOR ALL ENTRIES IN it_bseg
       WHERE bukrs EQ s_bukrs AND
             gjahr EQ s_gjahr AND
             koart EQ 'A' AND
             bschl EQ '70' AND
             belnr EQ it_bseg-belnr.
  ENDIF.

  LOOP AT it_final INTO wa_final.

    READ TABLE it_bseg INTO wa_bseg WITH KEY belnr = wa_final-belnr.
    IF sy-subrc = 0.
      wa_final-asst = wa_bseg-anln1.
    ENDIF.

*     if  wa_final-BSCHL = '75'.
*       wa_final-dmbtr = wa_Final-dmbtr *  -1.
*      endif.
    MODIFY it_final FROM wa_final TRANSPORTING asst.
    CLEAR : wa_bseg,wa_final.
  ENDLOOP.

****** Added by Carina Jose on 11/07/2022

  SELECT sign
   opti
   low
   high INTO CORRESPONDING FIELDS OF TABLE it_tvarvc_ac
             FROM tvarvc
             WHERE name = c_aclass AND
                   type = c_type_user1.

  IF it_tvarvc_ac IS NOT INITIAL.
    SELECT bukrs,anln1,anlkl
      INTO TABLE @DATA(it_anla)
      FROM anla
      FOR ALL ENTRIES IN @it_tvarvc_ac
      WHERE bukrs = @s_bukrs
      AND   anln1 IN @s_anln1
      AND   anlkl = @it_tvarvc_ac-low.


    IF it_anla IS NOT INITIAL.
      SELECT bukrs anln1 gjahr belnr bwasl
     INTO CORRESPONDING FIELDS OF TABLE it_anep2
     FROM anep
     FOR ALL ENTRIES IN lt_acc_key1
     WHERE bukrs = s_bukrs
     AND   anln1  IN s_anln1
     AND   gjahr = s_gjahr
     AND   bwasl = lt_acc_key1-low.
    ENDIF.



    IF it_anep IS NOT INITIAL.
      SELECT bukrs,anln1,gjahr,belnr,awtyp
     INTO CORRESPONDING FIELDS OF TABLE @it_anek1
     FROM  anek
     FOR ALL ENTRIES IN @it_anep2
     WHERE bukrs = @it_anep2-bukrs
     AND   anln1 = @it_anep2-anln1
     AND   gjahr = @it_anep2-gjahr.
    ENDIF.

    IF it_anep IS NOT INITIAL.
      SELECT bukrs belnr gjahr awtyp awkey
      INTO CORRESPONDING FIELDS OF TABLE it_bkpf1
      FROM bkpf
      FOR ALL ENTRIES IN it_anek1
      WHERE bukrs = it_anek1-bukrs
      AND   gjahr = it_anek1-gjahr
      AND   awtyp = it_anek1-awtyp
      AND   awkey = it_anek1-belnr.
    ENDIF.

*  IF it_bkpf IS NOT INITIAL.
*    SELECT bukrs belnr gjahr buzei bschl koart shkzg dmbtr sgtxt anln1 anbwa bzdat hkont prctr FROM bseg APPENDING CORRESPONDING FIELDS OF TABLE it_final
*      FOR ALL ENTRIES IN it_bkpf
*       WHERE bukrs =  it_bkpf-bukrs
*       AND   gjahr = it_bkpf-gjahr
*       AND   koart EQ 'A'
*       AND   bschl EQ '70'
*       AND   belnr EQ it_bkpf-belnr.
*  ENDIF.

    IF it_bkpf1 IS NOT INITIAL.
      SELECT bukrs belnr gjahr buzei anln1 prctr FROM bseg INTO TABLE it_bseg1
       FOR ALL ENTRIES IN it_bkpf1  " added by Carina Jose on 21.07.2021
       WHERE bukrs EQ s_bukrs AND
             belnr = it_bkpf1-belnr AND
             gjahr EQ s_gjahr AND
             koart EQ 'A' AND
*          anbwa = lt_acc_key1-low AND
             bschl EQ '75' AND
*          ANLN1 BETWEEN '000003000000' AND '000003999999' . " commented on 21.07.2021
*          ANLN1  = it_anla-anln1. "  added on 21.07.2021
             anln1  IN s_anln1. "  added on 21.07.2021
    ENDIF.

    IF  it_bseg1 IS NOT INITIAL.
      SELECT bukrs belnr gjahr buzei bschl koart shkzg dmbtr sgtxt anln1 anln2 anbwa bzdat hkont prctr FROM bseg APPENDING TABLE it_final
        FOR ALL ENTRIES IN it_bseg1
         WHERE bukrs EQ s_bukrs AND
               gjahr EQ s_gjahr AND
               koart EQ 'A' AND
               bschl EQ '70' AND
               belnr EQ it_bseg1-belnr.
    ENDIF.
    LOOP AT it_final INTO wa_final.

      READ TABLE it_bseg1 INTO wa_bseg WITH KEY belnr = wa_final-belnr.
      IF sy-subrc = 0.
        wa_final-asst = wa_bseg-anln1.
      ENDIF.

*     if  wa_final-BSCHL = '75'.
*       wa_final-dmbtr = wa_Final-dmbtr *  -1.
*      endif.
      MODIFY it_final FROM wa_final TRANSPORTING asst.
      CLEAR : wa_final, wa_bseg.
    ENDLOOP.


****** End of changes by Carina Jose on 11/07/2022

  ENDIF.




  LOOP AT it_final INTO wa_final.
****  Added auth. CHECK by Carina Jose ON 01.03.2022
    AUTHORITY-CHECK OBJECT 'Z_AUC_PRCT'
    ID 'PRCTR' FIELD wa_final-prctr
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc NE 0.
*      MESSAGE e018(zfi) WITH wa_final-prctr.
      DELETE it_final WHERE asst = wa_final-asst AND anln1 = wa_final-anln1 AND bukrs = wa_final-bukrs AND belnr = wa_final-belnr AND gjahr = wa_final-gjahr.
    ENDIF.
    CLEAR : wa_final.
****  End of Channges by carina Jose on 01.03.2022
  ENDLOOP.

*SORT IT_FINAL BY BUZEI ANLN1 BSCHL BELNR.
ENDFORM.                    " PROCESS_DATA
*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_fieldcatalog .
  DEFINE fill_fieldcat.
    lwa_fieldcat-col_pos       = &1.
    lwa_fieldcat-tabname       = &2.
    lwa_fieldcat-fieldname     = &3.
    lwa_fieldcat-ref_tabname   = &4.
    lwa_fieldcat-ref_fieldname = &5.
    lwa_fieldcat-seltext_l     = &6.
*    lwa_fieldcat-key           = &7.
*    lwa_fieldcat-fix_column    = &8.

    append lwa_fieldcat to lt_fieldcat.
    clear  lwa_fieldcat.
  END-OF-DEFINITION.

  fill_fieldcat 1    'IT_FINAL' 'ASST'  ''  'ASST'   'Main Asset'  .
  fill_fieldcat 2    'IT_FINAL' 'ANLN1'  ''  'ANLN1'  'Asset'  .
  fill_fieldcat 3    'IT_FINAL' 'ANLN2'  ''  'ANLN2'  'Sub Asset'  .
  fill_fieldcat 4    'IT_FINAL' 'BUKRS'  ''  'BUKRS'  'Company Code'  .
  fill_fieldcat 5    'IT_FINAL' 'BELNR'  ''  'BELNR'  'Document Number'  .

  fill_fieldcat 6    'IT_FINAL' 'GJAHR'  ''  'GJAHR'  'Fiscal Year' .
  fill_fieldcat 7    'IT_FINAL' 'BUZEI'  ''  'BUZEI'  'INDEX'  .
  fill_fieldcat 8    'IT_FINAL' 'BSCHL'  ''  'BSCHL'  'Posting Key' .
  fill_fieldcat 9    'IT_FINAL' 'KOART'  ''  'KOART'  'Account Type' .


  fill_fieldcat 10    'IT_FINAL' 'SHKZG'  ''  'SHKZG'  'Debit/Credit Ind.'  .
  fill_fieldcat 11    'IT_FINAL' 'DMBTR'  ''  'DMBTR'  'Amount in LC'  .


  fill_fieldcat 12   'IT_FINAL' 'SGTXT'  ''  'SGTXT'  'Text'  .

  fill_fieldcat 13   'IT_FINAL' 'ANBWA'  ''  'ANBWA'  'Transact. type'  .
  fill_fieldcat 14  'IT_FINAL' 'BZDAT'  ''  'BZDAT'  'Asset Value Date'  .
  fill_fieldcat 15  'IT_FINAL' 'HKONT'  ''  'HKONT'  'G/L Account'  .


ENDFORM.                    " BUILD_FIELDCATALOG
*&---------------------------------------------------------------------*
*&      Form  BUILD_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_layout .

  gd_layout-zebra             = 'X'.
  gd_layout-colwidth_optimize = 'X'.
  gd_layout-coltab_fieldname = 'CELLCOLOR'.
ENDFORM.                    " BUILD_LAYOUT
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_REPORT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv_report .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-repid
      is_layout              = gd_layout
      i_callback_top_of_page = 'TOP-OF-PAGE'
      it_fieldcat            = lt_fieldcat
      i_save                 = 'A'
    TABLES
      t_outtab               = it_final
    EXCEPTIONS
      program_error          = 1
      OTHERS                 = 2.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.
FORM top-of-page.
**  *ALV Header declarations
  DATA: t_header  TYPE slis_t_listheader,
        wa_header TYPE slis_listheader.
* Title
  wa_header-typ  = 'H'.

  wa_header-info = 'AUC Report'.

*  endif.
  APPEND wa_header TO t_header.
  CLEAR wa_header.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = t_header.
ENDFORM.                    "alv_fill_html_top                   " DISPLAY_ALV_REPORT
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
**** Added changes by Carina Jose on 30.07.2020
FORM authorization_check .
  SELECT bukrs FROM t001 INTO TABLE gt_t001 WHERE bukrs = s_bukrs.
  LOOP AT gt_t001 INTO wa_t001.
    AUTHORITY-CHECK OBJECT 'Z_FI_BUKRS'
    ID 'BUKRS' FIELD wa_t001-bukrs
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e014(zsd) WITH wa_t001-bukrs.
    ENDIF.
  ENDLOOP.
ENDFORM.
**** End of changes by Carina Jose on 30.07.2020
