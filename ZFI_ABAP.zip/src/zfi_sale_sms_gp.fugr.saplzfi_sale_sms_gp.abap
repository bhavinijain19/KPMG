*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_SALE_SMS_GPTOP.               " Global Declarations
  INCLUDE LZFI_SALE_SMS_GPUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_SALE_SMS_GPF...               " Subroutines
* INCLUDE LZFI_SALE_SMS_GPO...               " PBO-Modules
* INCLUDE LZFI_SALE_SMS_GPI...               " PAI-Modules
* INCLUDE LZFI_SALE_SMS_GPE...               " Events
* INCLUDE LZFI_SALE_SMS_GPP...               " Local class implement.
* INCLUDE LZFI_SALE_SMS_GPT99.               " ABAP Unit tests
  INCLUDE LZFI_SALE_SMS_GPF00                     . " subprograms
  INCLUDE LZFI_SALE_SMS_GPI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
