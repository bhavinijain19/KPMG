class ZCL_FDCB_SUBBAS09 definition
  public
  final
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_FDCB_SUBBAS09 IMPLEMENTATION.
ENDCLASS.
