*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_FB60TOP.                      " Global Declarations
  INCLUDE LZFI_FB60UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_FB60F...                      " Subroutines
* INCLUDE LZFI_FB60O...                      " PBO-Modules
* INCLUDE LZFI_FB60I...                      " PAI-Modules
* INCLUDE LZFI_FB60E...                      " Events
* INCLUDE LZFI_FB60P...                      " Local class implement.
* INCLUDE LZFI_FB60T99.                      " ABAP Unit tests
