class ZCL_HSN_BADI_ACC_DOCUMENT definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ACC_DOCUMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_HSN_BADI_ACC_DOCUMENT IMPLEMENTATION.


METHOD if_ex_acc_document~change.

  IF c_extension2 IS NOT INITIAL.
    LOOP AT c_accit INTO DATA(wa_accit).
      READ TABLE c_extension2 INTO DATA(lt_accit) WITH KEY valuepart3 = wa_accit-posnr .
      "  select single * from C_EXTENSION2 into @data(lt_accit) where VALUEPART1 = 'HSN_SAC'.
      wa_accit-hsn_sac = lt_accit-valuepart2.
      MODIFY c_accit FROM wa_accit TRANSPORTING hsn_sac.
    ENDLOOP.
  ENDIF.

ENDMETHOD.


  method IF_EX_ACC_DOCUMENT~FILL_ACCIT.
  endmethod.
ENDCLASS.
