FUNCTION-POOL ZFI_BUPLA_CON              MESSAGE-ID SV.

* INCLUDE LZFI_BUPLA_COND...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_BUPLA_CONT00                       . "view rel. data dcl.
