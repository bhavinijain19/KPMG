FUNCTION-POOL ZFI_WITH_TAX.                 "MESSAGE-ID ..

* INCLUDE LZFI_WITH_TAXD...                  " Local class definition
