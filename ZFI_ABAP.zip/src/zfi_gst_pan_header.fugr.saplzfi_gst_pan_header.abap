*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GST_PAN_HEADERTOP.            " Global Declarations
  INCLUDE LZFI_GST_PAN_HEADERUXX.            " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GST_PAN_HEADERF...            " Subroutines
* INCLUDE LZFI_GST_PAN_HEADERO...            " PBO-Modules
* INCLUDE LZFI_GST_PAN_HEADERI...            " PAI-Modules
* INCLUDE LZFI_GST_PAN_HEADERE...            " Events
* INCLUDE LZFI_GST_PAN_HEADERP...            " Local class implement.
* INCLUDE LZFI_GST_PAN_HEADERT99.            " ABAP Unit tests

INCLUDE lzfi_gst_pan_headero01.
