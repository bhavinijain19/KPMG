*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_OD_SMS_GP_CO................................*
DATA:  BEGIN OF STATUS_ZFI_OD_SMS_GP_CO              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_OD_SMS_GP_CO              .
CONTROLS: TCTRL_ZFI_OD_SMS_GP_CO
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_OD_SMS_GP_CO              .
TABLES: ZFI_OD_SMS_GP_CO               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
