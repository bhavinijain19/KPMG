*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_COD_MAIL_DIVTOP.              " Global Data
  INCLUDE LZFI_COD_MAIL_DIVUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_COD_MAIL_DIVF...              " Subroutines
* INCLUDE LZFI_COD_MAIL_DIVO...              " PBO-Modules
* INCLUDE LZFI_COD_MAIL_DIVI...              " PAI-Modules
* INCLUDE LZFI_COD_MAIL_DIVE...              " Events
* INCLUDE LZFI_COD_MAIL_DIVP...              " Local class implement.
* INCLUDE LZFI_COD_MAIL_DIVT99.              " ABAP Unit tests
  INCLUDE LZFI_COD_MAIL_DIVF00                    . " subprograms
  INCLUDE LZFI_COD_MAIL_DIVI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
