*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PIPES_CON...................................*
DATA:  BEGIN OF STATUS_ZFI_PIPES_CON                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PIPES_CON                 .
CONTROLS: TCTRL_ZFI_PIPES_CON
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PIPES_CON                 .
TABLES: ZFI_PIPES_CON                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
