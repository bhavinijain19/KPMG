*&---------------------------------------------------------------------*
*&  Include           ZFI_COLLECTION_MIS_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
***  SELECT kdgrp,
***       txt
***  FROM zfi_mis_kdgrp
***  INTO TABLE @DATA(lt_kd).

***  LOOP AT lt_kd INTO DATA(ls_kd).
***    s_kdgrp-sign = 'I'.
***    s_kdgrp-option = 'EQ'.
***    s_kdgrp-low = ls_kd-kdgrp.
***
***    APPEND s_kdgrp.
***    CLEAR : s_kdgrp , ls_kd.
***  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_vtweg)
    WHERE name = 'ZFI_MIS_VTWEG'
      AND type = 'S'.

  LOOP AT lt_vtweg INTO DATA(ls_vtweg).
    s_vtweg-sign = 'I'.
    s_vtweg-option = 'EQ'.
    s_vtweg-low = ls_vtweg-low.

    APPEND s_vtweg.
    CLEAR : s_vtweg , ls_vtweg.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_spart)
    WHERE name = 'ZFI_MIS_SPART'
      AND type = 'S'.

  LOOP AT lt_spart INTO DATA(ls_spart).
    s_spart-sign = 'I'.
    s_spart-option = 'EQ'.
    s_spart-low = ls_spart-low.

    APPEND s_spart.
    CLEAR : s_spart , ls_spart.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_blart)
    WHERE name = 'ZFI_MIS_BLART'
      AND type = 'S'.

  LOOP AT lt_blart INTO ls_spart.
    s_blart-sign = 'I'.
    s_blart-option = 'EQ'.
    s_blart-low = ls_spart-low.

    APPEND s_blart.
    CLEAR : s_blart , ls_spart.
  ENDLOOP.

  REFRESH : lt_vtweg[] , lt_spart[]." , lt_kd[].

  CREATE OBJECT lo_cwip.

  lo_cwip->zif_collection_mis~get_data(
    EXPORTING
*     kdgrp   = s_kdgrp[]
      kvgr1   = s_kvgr1[]
      kvgr2   = s_kvgr2[]
      kunnr   = s_kunnr[]
      vkbur   = s_vkbur[]
      spart   = s_spart[]
      vtweg   = s_vtweg[]
      vkorg   = s_vkorg[]
    CHANGING
      lt_knvv = lt_knvv[]    " Table Type for KNVV Table
  ).

***  DELETE lt_knvv WHERE kdgrp NOT IN s_kdgrp.
  IF p_rb1 = 'X' OR p_rb3 = 'X' OR p_rb4 = 'X'.
    IF p_rd1 = 'X'.
      lo_cwip->zif_collection_mis~process_data(
        EXPORTING
          start_date = s_budat-low
          end_date   = s_budat-high
          blart      = s_blart[]
          bukrs      = s_bukrs[]
          lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
        CHANGING
          lt_final   = lt_final[]    " Table Type for Final Collection MIS Report
      ).
    ELSEIF p_rd2 = 'X'.
      CLEAR : lv_start , lv_end.
      CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
        EXPORTING
          iv_date             = sy-datum
        IMPORTING
          ev_month_begin_date = lv_start.
*          ev_month_end_date   = lv_end.
      lv_end = sy-datum.
      lo_cwip->zif_collection_mis~process_data(
        EXPORTING
          start_date = lv_start
          end_date   = lv_end
          blart      = s_blart[]
          bukrs      = s_bukrs[]
          lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
        CHANGING
          lt_final   = lt_final[]    " Table Type for Final Collection MIS Report
      ).
    ENDIF."End of RD1

  ELSEIF p_rb2 = 'X' OR p_rb5 = 'X'.
    IF p_rd1 = 'X'.
      lo_cwip->zif_collection_mis~filter_data(
        EXPORTING
          start_date = s_budat-low
          end_date   = s_budat-high
          blart      = s_blart[]
          bukrs      = s_bukrs[]
          lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
        CHANGING
          lt_detail  = lt_detail[]    " Table Type for Detailed Data in MIS Report
      ).
    ELSEIF p_rd2 = 'X'.
      CLEAR : lv_start , lv_end.
      CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
        EXPORTING
          iv_date             = sy-datum
        IMPORTING
          ev_month_begin_date = lv_start.
*          ev_month_end_date   = lv_end.
      lv_end = sy-datum.
      lo_cwip->zif_collection_mis~filter_data(
        EXPORTING
          start_date = lv_start
          end_date   = lv_end
          blart      = s_blart[]
          bukrs      = s_bukrs[]
          lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
        CHANGING
          lt_detail  = lt_detail[]    " Table Type for Detailed Data in MIS Report
      ).
    ENDIF.

  ENDIF."IF p_rb1 = 'X' OR p_rb3 = 'X'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .
  DATA lv_colpos TYPE i VALUE 0.
  REFRESH : lt_fieldcat[].
  CLEAR : ls_layout.
  SELECT vkorg,
*         kdgrp,
         kvgr1,
         kvgr2,
         txt
    FROM zfi_mis_kdgrp
    INTO TABLE @DATA(lt_kdgrp)
    WHERE vkorg IN @s_vkorg.
  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_kd)
    WHERE name = 'ZFI_MIS_KDGRP_SEQ'
      AND type = 'S'.

  DATA lv_seq TYPE char10.
  REFRESH lt_kdgrpseq[].
  LOOP AT lt_kd INTO DATA(ls_kd).
    SPLIT ls_kd-low AT '-' INTO lv_seq ls_kdgrpseq-custgrp.

    IF ls_kdgrpseq IS NOT INITIAL.
      ls_kdgrpseq-seq_no = lv_seq.
      APPEND ls_kdgrpseq TO lt_kdgrpseq.
      CLEAR : ls_kdgrpseq.
    ENDIF."ls_kdgrp is not INITIAL.

  ENDLOOP.

  IF p_rb1 = 'X' OR p_rb3 = 'X' OR p_rb4 = 'X'.
    IF lt_final[] IS NOT INITIAL.
      IF p_rb1 = 'X'.
        REFRESH : lt_pivot_d[].
        LOOP AT lt_kdgrp INTO DATA(ls_kdgrp).
          ls_pivot_d-vkorg    = ls_kdgrp-vkorg.
          ls_pivot_d-kvgr1    = ls_kdgrp-kvgr1.
          ls_pivot_d-division = ls_kdgrp-kvgr1.
          TRY.
              ls_pivot_d-seq = lt_kdgrpseq[ custgrp = ls_pivot_d-division ]-seq_no.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
          APPEND ls_pivot_d TO lt_pivot_d.
          CLEAR : ls_pivot_d , ls_kdgrp.
        ENDLOOP.
*        SORT lt_pivot_d BY seq division.
        SORT lt_pivot_d BY seq division.
        DELETE ADJACENT DUPLICATES FROM lt_pivot_d COMPARING seq division.

        LOOP AT lt_pivot_d ASSIGNING <ls_pivot>.
          LOOP AT lt_final INTO ls_final WHERE division = <ls_pivot>-division AND budat = sy-datum.
            <ls_pivot>-dz_amt = <ls_pivot>-dz_amt + ls_final-dz_amt.
            <ls_pivot>-dg_amt = <ls_pivot>-dg_amt + ls_final-dg_amt.

            <ls_pivot>-total = ( <ls_pivot>-total + ( ls_final-dz_amt + ls_final-dg_amt ) ).
          ENDLOOP.
          <ls_pivot>-dz_amt = ( <ls_pivot>-dz_amt / 100000 ).
          <ls_pivot>-dg_amt = ( <ls_pivot>-dg_amt / 100000 ).

          <ls_pivot>-total = ( <ls_pivot>-total / 100000 ).
        ENDLOOP.

        DEFINE fieldcat.
          lv_colpos = lv_colpos + 1.
          ls_fieldcat-col_pos = lv_colpos.
          ls_fieldcat-fieldname = &1.
          ls_fieldcat-seltext_l = &2.
          ls_fieldcat-outputlen = &3.
          ls_fieldcat-do_sum = &4.
*        ls_fieldcat-ref_fieldname = &5.
*        ls_fieldcat-ref_tabname = &6.
*        ls_fieldcat-just = &7.
          APPEND ls_fieldcat TO lt_fieldcat.
          CLEAR ls_fieldcat.
        END-OF-DEFINITION.

        fieldcat : 'DIVISION' 'Division' '' ''.
        fieldcat : 'DZ_AMT' 'Collection Amount(Value in Lac)' '30' 'X'.
        fieldcat : 'DG_AMT' 'Credit Note Amount(Value in Lac)' '30' 'X'.
        fieldcat : 'TOTAL' 'Total(Value in Lac)' '30' 'X'.

        ls_layout-zebra = 'X'.
*      ls_layout-colwidth_optimize = 'X'.

        CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
          EXPORTING
            i_callback_program     = sy-repid
            i_callback_top_of_page = 'TOP_OF_PAGE_RB1'
            is_layout              = ls_layout
            it_fieldcat            = lt_fieldcat[]
            i_save                 = 'A'                """"added by akshay dt.28.04.2025
          TABLES
            t_outtab               = lt_pivot_d[].
      ELSEIF p_rb3 = 'X' OR p_rb4 = 'X'.
        REFRESH : lt_pivot_m[].
*------------Month Wise Pivot Table --------------
        LOOP AT lt_kdgrp INTO ls_kdgrp.
          ls_pivot_m-vkorg = ls_kdgrp-vkorg.
          ls_pivot_m-division = ls_kdgrp-kvgr1.
          TRY.
              ls_pivot_m-seq = lt_kdgrpseq[ custgrp = ls_pivot_m-division ]-seq_no.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
          APPEND ls_pivot_m TO lt_pivot_m.
          CLEAR : ls_pivot_m , ls_kdgrp.
        ENDLOOP.
        SORT lt_pivot_m BY seq division.
        DELETE ADJACENT DUPLICATES FROM lt_pivot_m COMPARING seq division.

        LOOP AT lt_pivot_m ASSIGNING <ls_pivot>.
          LOOP AT lt_final INTO ls_final WHERE division = <ls_pivot>-division." AND budat = sy-datum.
            <ls_pivot>-dz_amt = <ls_pivot>-dz_amt + ls_final-dz_amt.
            <ls_pivot>-dg_amt = <ls_pivot>-dg_amt + ls_final-dg_amt.

*          <ls_pivot>-total = <ls_pivot>-total + ( <ls_pivot>-dz_amt + <ls_pivot>-dg_amt ).
            <ls_pivot>-total = ( <ls_pivot>-total + ( ls_final-dz_amt + ls_final-dg_amt ) ).
          ENDLOOP.
          <ls_pivot>-dz_amt = ( <ls_pivot>-dz_amt / 100000 ).
          <ls_pivot>-dg_amt = ( <ls_pivot>-dg_amt / 100000 ).

          <ls_pivot>-total = ( <ls_pivot>-total / 100000 ).
        ENDLOOP.

        fieldcat : 'DIVISION' 'Division' '' ''.
        fieldcat : 'DZ_AMT' 'Collection Amount(Value in Lac)' '30' 'X'.
        fieldcat : 'DG_AMT' 'Credit Note Amount(Value in Lac)' '30' 'X'.
        fieldcat : 'TOTAL' 'Total(Value in Lac)' '30' 'X'.

        ls_layout-zebra = 'X'.
*      ls_layout-colwidth_optimize = 'X'.

        CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
          EXPORTING
            i_callback_program     = sy-repid
            i_callback_top_of_page = 'TOP_OF_PAGE_RB3'
            is_layout              = ls_layout
            it_fieldcat            = lt_fieldcat[]
            i_save                 = 'A'                """"added by akshay dt.28.04.2025
          TABLES
            t_outtab               = lt_pivot_m[].

*------------Month Wise Pivot Table --------------
      ENDIF.
    ELSE.
      MESSAGE 'No Data Found' TYPE 'S' DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.
  ELSEIF p_rb2 = 'X' OR p_rb5 = 'X'.

    IF lt_detail[] IS NOT INITIAL.
      DEFINE fieldcat.
        lv_colpos = lv_colpos + 1.
        ls_fieldcat-col_pos = lv_colpos.
        ls_fieldcat-fieldname = &1.
        ls_fieldcat-seltext_l = &2.
        ls_fieldcat-outputlen = &3.
        ls_fieldcat-do_sum = &4.

        APPEND ls_fieldcat TO lt_fieldcat.
        CLEAR ls_fieldcat.
      END-OF-DEFINITION.
      fieldcat : 'KUNNR' 'CUSTOMER' '' ''.
      fieldcat : 'BELNR' 'DOCUMENT NO.' '' ''.
      fieldcat : 'NAME1' 'NAME' '' ''.
      fieldcat : 'BEZEI' 'SHS NAME' '' ''.
      fieldcat : 'DIVISION' 'DIVISION' '' ''.
      fieldcat : 'BUDAT' 'POSTING DATE' '' ''.
      fieldcat : 'KIDNO' 'PAYMENT REFERENCE' '' ''.
      fieldcat : 'DZ_AMT' 'COLLECTION AMOUNT' '' 'X'.
      fieldcat : 'DG_AMT' 'CREDIT NOTE AMOUNT' '' 'X'.
      fieldcat : 'TOTAL' 'TOTAL AMOUNT' '' 'X'.

      ls_layout-zebra = 'X'.
      ls_layout-colwidth_optimize = 'X'.

      CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
        EXPORTING
          i_callback_program     = sy-repid
          i_callback_top_of_page = 'TOP_OF_PAGE_RB2'
          is_layout              = ls_layout
          it_fieldcat            = lt_fieldcat
          i_save                 = 'A'                """"added by akshay dt.28.04.2025
        TABLES
          t_outtab               = lt_detail.
    ELSE.
      MESSAGE 'NO DATA FOUND' TYPE 'S' DISPLAY LIKE 'E'.
      RETURN.
    ENDIF."lt_detail[] IS NOT INITIAL.

  ENDIF."p_rb1 = 'X' OR p_rb3 = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BG_TASK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bg_task .
  DATA : lv_start TYPE d,
         lv_end   TYPE d.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_vtweg)
    WHERE name = 'ZFI_MIS_VTWEG'
      AND type = 'S'.

  LOOP AT lt_vtweg INTO DATA(ls_vtweg).
    s_vtweg-sign = 'I'.
    s_vtweg-option = 'EQ'.
    s_vtweg-low = ls_vtweg-low.

    APPEND s_vtweg.
    CLEAR : s_vtweg , ls_vtweg.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_spart)
    WHERE name = 'ZFI_MIS_SPART'
      AND type = 'S'.

  LOOP AT lt_spart INTO DATA(ls_spart).
    s_spart-sign = 'I'.
    s_spart-option = 'EQ'.
    s_spart-low = ls_spart-low.

    APPEND s_spart.
    CLEAR : s_spart , ls_spart.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_blart)
    WHERE name = 'ZFI_MIS_BLART'
      AND type = 'S'.

  LOOP AT lt_blart INTO ls_spart.
    s_blart-sign = 'I'.
    s_blart-option = 'EQ'.
    s_blart-low = ls_spart-low.

    APPEND s_blart.
    CLEAR : s_blart , ls_spart.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_kd)
    WHERE name = 'ZFI_MIS_KDGRP_SEQ'
      AND type = 'S'.

  DATA lv_seq TYPE char10.
  LOOP AT lt_kd INTO DATA(ls_kd).
    SPLIT ls_kd-low AT '-' INTO lv_seq ls_kdgrpseq-custgrp.

    IF ls_kdgrpseq IS NOT INITIAL.
      ls_kdgrpseq-seq_no = lv_seq.
      APPEND ls_kdgrpseq TO lt_kdgrpseq.
      CLEAR : ls_kdgrpseq.
    ENDIF."ls_kdgrp is not INITIAL.

  ENDLOOP.


  REFRESH : lt_vtweg[] , lt_spart[] , lt_kd[].

  CREATE OBJECT lo_cwip.

  lo_cwip->zif_collection_mis~get_data(
    EXPORTING
      kvgr1   = s_kvgr1[]
      kvgr2   = s_kvgr2[]
      kunnr   = s_kunnr[]
      vkbur   = s_vkbur[]
      spart   = s_spart[]
      vtweg   = s_vtweg[]
      vkorg   = s_vkorg[]
    CHANGING
      lt_knvv = lt_knvv[]    " Table Type for KNVV Table
  ).

  IF p_rd1 = 'X'.
    lo_cwip->zif_collection_mis~process_data(
      EXPORTING
        start_date = s_budat-low
        end_date   = s_budat-high
        blart      = s_blart[]
        bukrs      = s_bukrs[]
        lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
      CHANGING
        lt_final   = lt_final[]    " Table Type for Final Collection MIS Report
    ).
  ELSEIF p_rd2 = 'X'.
    CLEAR : lv_start , lv_end.
    CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
      EXPORTING
        iv_date             = sy-datum
      IMPORTING
        ev_month_begin_date = lv_start.
*        ev_month_end_date   = lv_end.
    lv_end = sy-datum.
    lo_cwip->zif_collection_mis~process_data(
      EXPORTING
        start_date = lv_start
        end_date   = lv_end
        blart      = s_blart[]
        bukrs      = s_bukrs[]
        lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
      CHANGING
        lt_final   = lt_final[]    " Table Type for Final Collection MIS Report
    ).
  ENDIF."End of RD1

  IF p_rd1 = 'X'.
    lo_cwip->zif_collection_mis~filter_data(
      EXPORTING
        start_date = s_budat-low
        end_date   = s_budat-high
        blart      = s_blart[]
        bukrs      = s_bukrs[]
        lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
      CHANGING
        lt_detail  = lt_detail[]    " Table Type for Detailed Data in MIS Report
    ).
  ELSEIF p_rd2 = 'X'.
    CLEAR : lv_start , lv_end.
    CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
      EXPORTING
        iv_date             = sy-datum
      IMPORTING
        ev_month_begin_date = lv_start.
*        ev_month_end_date   = lv_end.
    lv_end = sy-datum.
    lo_cwip->zif_collection_mis~filter_data(
      EXPORTING
        start_date = lv_start
        end_date   = lv_end
        blart      = s_blart[]
        bukrs      = s_bukrs[]
        lt_knvv    = lt_knvv[]    " Table Type for KNVV Table
      CHANGING
        lt_detail  = lt_detail[]    " Table Type for Detailed Data in MIS Report
    ).
  ENDIF."ENd of RD1

  CLEAR : longtext.
  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_mail)
    WHERE name = 'ZFI_COLL_CRN'
      AND type = 'S'.
  SELECT vkorg,
*         kdgrp,
         kvgr1,
         kvgr2,
         txt
    FROM zfi_mis_kdgrp
    INTO TABLE @DATA(lt_kdgrp)
    WHERE vkorg IN @s_vkorg.

  " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  CALL FUNCTION 'ISP_GET_MONTH_NAME'
*    EXPORTING
*      date        = sy-datum
*      language    = sy-langu
**     MONTH_NUMBER       = '00'
*    IMPORTING
*      longtext    = longtext
*    EXCEPTIONS
*      calendar_id = 1
*      date_error  = 2
*      not_found   = 3
*      wrong_input = 4
*      OTHERS      = 5.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.

  DATA : lt_month TYPE TABLE OF t247,
         ls_month TYPE t247.

  CLEAR : lt_month, ls_month.

  CALL FUNCTION 'MONTH_NAMES_GET'
    EXPORTING
      language              = sy-langu
*   IMPORTING
*     RETURN_CODE           =
    TABLES
      month_names           = lt_month
    EXCEPTIONS
      month_names_not_found = 1
      OTHERS                = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  READ TABLE lt_month INTO ls_month WITH KEY mnr = sy-datum+4(2).
  IF sy-subrc = 0.
    longtext = ls_month-ltx.
  ENDIF.

  " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

  CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
    EXPORTING
      iv_date             = sy-datum
    IMPORTING
      ev_month_begin_date = lv_start
      ev_month_end_date   = lv_end.
  IF lt_detail[] IS NOT INITIAL.
    REFRESH : lt_pivot_d[] , lt_pivot_m[].
    LOOP AT lt_kdgrp INTO DATA(ls_kdgrp).
      ls_pivot_d-vkorg    = ls_kdgrp-vkorg.
      ls_pivot_d-division = ls_kdgrp-txt.
      TRY.
          ls_pivot_d-seq = lt_kdgrpseq[ custgrp = ls_pivot_d-division ]-seq_no.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.
      APPEND ls_pivot_d TO lt_pivot_d.
      CLEAR : ls_pivot_d , ls_kdgrp.
    ENDLOOP.
    SORT lt_pivot_d BY seq division.
    DELETE ADJACENT DUPLICATES FROM lt_pivot_d COMPARING seq division.

***    ls_pivot_d-division = 'MNT'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_d-division = 'WOOD'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_d-division = 'IND'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_d-division = 'CC'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_d-division = 'EXPORT'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_d-division = 'OTHERS'.
***    APPEND ls_pivot_d TO lt_pivot_d.
***    CLEAR : ls_pivot_d.

    ls_pivot_d-division = 'TOTAL'.
    APPEND ls_pivot_d TO lt_pivot_d.
    CLEAR : ls_pivot_d.

    LOOP AT lt_pivot_d ASSIGNING <ls_pivot>.
      LOOP AT lt_final INTO ls_final WHERE division = <ls_pivot>-division AND budat = sy-datum.
        <ls_pivot>-dz_amt = <ls_pivot>-dz_amt + ls_final-dz_amt.
        <ls_pivot>-dg_amt = <ls_pivot>-dg_amt + ls_final-dg_amt.

        <ls_pivot>-total = <ls_pivot>-total + ( ls_final-dz_amt + ls_final-dg_amt ).
      ENDLOOP.
      <ls_pivot>-dz_amt = ( <ls_pivot>-dz_amt / 100000 ).
      <ls_pivot>-dg_amt = ( <ls_pivot>-dg_amt / 100000 ).

      <ls_pivot>-total = ( <ls_pivot>-total / 100000 ).
    ENDLOOP.

***    ls_pivot_m-division = 'MNT'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_d.
***
***    ls_pivot_m-division = 'WOOD'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_m.
***
***    ls_pivot_m-division = 'IND'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_m.
***
***    ls_pivot_m-division = 'CC'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_m.
***
***    ls_pivot_m-division = 'EXPORT'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_m.
***
***    ls_pivot_m-division = 'OTHERS'.
***    APPEND ls_pivot_m TO lt_pivot_m.
***    CLEAR : ls_pivot_m.
    LOOP AT lt_kdgrp INTO ls_kdgrp.
      ls_pivot_m-vkorg = ls_kdgrp-vkorg.
      ls_pivot_m-division = ls_kdgrp-txt.

      TRY.
          ls_pivot_m-seq = lt_kdgrpseq[ custgrp = ls_pivot_m-division ]-seq_no.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.

      APPEND ls_pivot_m TO lt_pivot_m.
      CLEAR : ls_pivot_m , ls_kdgrp.
    ENDLOOP.
    SORT lt_pivot_m BY seq division.
    DELETE ADJACENT DUPLICATES FROM lt_pivot_m COMPARING seq division.

    ls_pivot_m-division = 'TOTAL'.
    APPEND ls_pivot_m TO lt_pivot_m.
    CLEAR : ls_pivot_m.

    LOOP AT lt_pivot_m ASSIGNING <ls_pivot>.
      LOOP AT lt_final INTO ls_final WHERE division = <ls_pivot>-division." AND budat = sy-datum.
        <ls_pivot>-dz_amt = <ls_pivot>-dz_amt + ls_final-dz_amt.
        <ls_pivot>-dg_amt = <ls_pivot>-dg_amt + ls_final-dg_amt.

        <ls_pivot>-total = <ls_pivot>-total + ( ls_final-dz_amt + ls_final-dg_amt ).
      ENDLOOP.
      <ls_pivot>-dz_amt = ( <ls_pivot>-dz_amt / 100000 ).
      <ls_pivot>-dg_amt = ( <ls_pivot>-dg_amt / 100000 ).

      <ls_pivot>-total = ( <ls_pivot>-total / 100000 ).
    ENDLOOP.
*-----------------Mail Logic Starts -------------
    REFRESH : main_text[].
    IF lt_pivot_d[] IS NOT INITIAL AND lt_pivot_m[] IS NOT INITIAL.
      lv_mailtext = |<!DOCTYPE html>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<head>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</head>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<body>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

                                                            "20241211
      lv_mailtext = |<h5>Collection MIS Pivot for Date : { sy-datum+6(2) }.{ sy-datum+4(2) }.{ sy-datum+0(4) } </h5>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |<table style="width:50%;border:1px solid black">|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.
      lv_mailtext = |<tr> <th bgcolor="#C0C0C0"> Division </th> <th bgcolor="#C0C0C0"> Collection Amount (Value in Lac) </th> <th bgcolor="#C0C0C0"> Credit Note Amount (Value in Lac)  </th> <th bgcolor="#C0C0C0"> Total (Value in Lac)  </th> </tr>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      CLEAR : lv_dztotal , lv_dgtotal , lv_totamt.
      LOOP AT lt_pivot_d INTO ls_pivot_d." WHERE division <> 'TOTAL'.

        IF ls_pivot_d-division = 'TOTAL'.
          lv_totamt = lv_dztotal + lv_dgtotal.
          lv_mailtext = |<tr bgcolor="#C0C0C0"> <td> { ls_pivot_d-division } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_dztotal } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_dgtotal } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_totamt } </td> </tr>|.
*          CLEAR : lv_mailtext.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext .
        ELSE.
          lv_mailtext = |<tr> <td> { ls_pivot_d-division } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_d-dz_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_d-dg_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_d-total } </td> </tr>|.
*          CLEAR : lv_mailtext.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext .
          lv_dztotal = lv_dztotal + ls_pivot_d-dz_amt.
          lv_dgtotal = lv_dgtotal + ls_pivot_d-dg_amt.
        ENDIF."ls_pivot_d-division <> 'TOTAL'.
        CLEAR ls_pivot_d.
      ENDLOOP.

      lv_mailtext = |</table>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      IF p_rd1 = 'X'.
        lv_mailtext = |<h5>Collection MIS Pivot From Date : { s_budat-low+6(2) }.{ s_budat-low+4(2) }.{ s_budat-low+0(4) } To { s_budat-high+6(2) }.{ s_budat-high+4(2) }.{ s_budat-high+0(4) } </h5>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.
      ELSEIF p_rd2 = 'X'.
        lv_mailtext = |<h5>Collection MIS Pivot From Date : { lv_start+6(2) }.{ lv_start+4(2) }.{ lv_start+0(4) } To { sy-datum+6(2) }.{ sy-datum+4(2) }.{ sy-datum+0(4) } </h5>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.
      ENDIF.

      lv_mailtext = |<table style="width:50%;border:1px solid black">|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.
      lv_mailtext = |<tr> <th bgcolor="#C0C0C0"> Division </th> <th bgcolor="#C0C0C0"> Collection Amount (Value in Lac) </th> <th bgcolor="#C0C0C0"> Credit Note Amount (Value in Lac) </th> <th bgcolor="#C0C0C0"> Total (Value in Lac) </th> </tr>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.


      CLEAR : lv_dztotal , lv_dgtotal , lv_totamt.
      LOOP AT lt_pivot_m INTO ls_pivot_m." WHERE division <> 'TOTAL'.

        IF ls_pivot_m-division = 'TOTAL'.
          lv_totamt = lv_dztotal + lv_dgtotal.
          lv_mailtext = |<tr bgcolor="#C0C0C0"> <td> { ls_pivot_m-division } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_dztotal } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_dgtotal } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { lv_totamt } </td> </tr>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext .
        ELSE.
          lv_dztotal = lv_dztotal + ls_pivot_m-dz_amt.
          lv_dgtotal = lv_dgtotal + ls_pivot_m-dg_amt.
          lv_mailtext = |<tr> <td> { ls_pivot_m-division } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_m-dz_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_m-dg_amt } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
          lv_mailtext = |<td> { ls_pivot_m-total } </td> </tr>|.
          APPEND lv_mailtext TO main_text.
          CLEAR lv_mailtext.
        ENDIF."ls_pivot_m-division <> 'TOTAL'.
        CLEAR : lv_mailtext , ls_pivot_m.
      ENDLOOP.

      lv_mailtext = |</table>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      lv_mailtext = |</body>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.
      lv_mailtext = |</html>|.
      APPEND lv_mailtext TO main_text.
      CLEAR : lv_mailtext.

      CONCATENATE 'CUSTOMER CODE' lc_tab
                  'DOCUMENT NO.' lc_tab
                  'NAME' lc_tab
                  'SHS NAME' lc_tab
                  'DIVISION' lc_tab
                  'POSTING DATE' lc_tab
                  'PAYMENT REFERENCE' lc_tab
                  'COLLECTION AMOUNT' lc_tab
                  'CREDIT NOTE AMOUNT' lc_tab
                  'TOTAL AMOUNT' lc_crlf INTO ld_string.
      LOOP AT lt_detail INTO ls_detail.
        CLEAR : lv_dz , lv_dg , lv_total.
        WRITE : ls_detail-dz_amt TO lv_dz,
                ls_detail-dg_amt TO lv_dg,
                ls_detail-total TO lv_total.
        CONDENSE : lv_dz , lv_dg , lv_total.
        IF ls_detail-dz_amt < 0.
          CALL FUNCTION 'CLOI_PUT_SIGN_IN_FRONT'
            CHANGING
              value = lv_dz.
        ENDIF.

        IF ls_detail-dg_amt < 0.
          CALL FUNCTION 'CLOI_PUT_SIGN_IN_FRONT'
            CHANGING
              value = lv_dg.
        ENDIF.

        IF ls_detail-total < 0.
          CALL FUNCTION 'CLOI_PUT_SIGN_IN_FRONT'
            CHANGING
              value = lv_total.
        ENDIF.
        lv_date1 = |{ ls_detail-budat+6(2) }.{ ls_detail-budat+4(2) }.{ ls_detail-budat+0(4) }|.
        CONCATENATE ld_string ls_detail-kunnr lc_tab
                              ls_detail-belnr lc_tab
                              ls_detail-name1 lc_tab
                              ls_detail-bezei lc_tab
                              ls_detail-division lc_tab
                              lv_date1 lc_tab
                              ls_detail-kidno lc_tab
                              lv_dz lc_tab
                              lv_dg lc_tab
                              lv_total lc_crlf INTO ld_string.
        CLEAR : ls_detail , lv_date1.
      ENDLOOP.
      TRY .
          send_request = cl_bcs=>create_persistent( ).
          sender = cl_cam_address_bcs=>create_internet_address(
            i_address_string = 'SAP.ASTRAL@ASTRALLTD.COM'
*           i_incl_sapuser   = 'X'
          ).

          CALL METHOD send_request->set_sender( sender ).
          cl_bcs_convert=>string_to_solix(
            EXPORTING
              iv_string   = ld_string   " Input data
              iv_codepage = '4103'   " Target Code Page in SAP Form  (Default = SAPconnect Setting)
              iv_add_bom  = 'X'   " Add Byte-Order Mark
            IMPORTING
              et_solix    = binary_content  " Output data
              ev_size     = size  " Size of Document Content
          ).

          document = cl_document_bcs=>create_document(
            i_type    = 'HTM'
            i_subject = 'COLLECTION MIS INFORMATION'
            i_text    = main_text
          ).
          document->add_attachment(
            EXPORTING
              i_attachment_type    = 'XLS'  " Document Class for Attachment
              i_attachment_subject = 'COLLECTION REPORT ON : ' && sy-datum+6(2) && '.' && sy-datum+4(2) && '.' && sy-datum+0(4)  " Attachment Title
              i_attachment_size    = size   " Size of Document Content
              i_att_content_hex    = binary_content   " Content (Binary)
          ).

          send_request->set_document( document ).

          LOOP AT lt_mail INTO DATA(ls_mail).
            lv_mail = ls_mail-low."'SAP.ABAP@ASTRALLTD.COM'.
            recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
            send_request->add_recipient( recipient ).
          ENDLOOP.

          send_to_all = send_request->send( i_with_error_screen = 'X' ).
          IF send_to_all IS NOT INITIAL.
            COMMIT WORK.
            MESSAGE 'Mail Send Successfully' TYPE 'S'.
          ELSE.
            MESSAGE 'Error While Send Email' TYPE 'S' DISPLAY LIKE 'E'.
            RETURN.
          ENDIF.
        CATCH cx_bcs INTO bcs_exception.

      ENDTRY.
    ENDIF."lt_pivot_d[] IS NOT INITIAL AND lt_pivot_m[] IS NOT INITIAL.
*-----------------Mail Logic Ends   -------------
  ELSE.
    MESSAGE 'No Data to Send Mail' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF."lt_final[] is NOT INITIAL.
ENDFORM.
FORM top_of_page_rb1.
  REFRESH lt_header[].
  ls_header-typ  = 'H'.
  ls_header-info = 'Collection MIS Pivot View'." for Date :' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4) .
  APPEND ls_header TO lt_header.
  CLEAR ls_header.

  ls_header-typ  = 'S'.
  ls_header-info = 'Date : ' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4) .
  APPEND ls_header TO lt_header.
  CLEAR ls_header.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = lt_header.

  REFRESH:lt_header.
ENDFORM.
FORM top_of_page_rb3.
  REFRESH lt_header[].
  DATA : lv_start TYPE d.
  CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
    EXPORTING
      iv_date             = sy-datum
    IMPORTING
      ev_month_begin_date = lv_start.
  IF p_rb4 = 'X'.
    ls_header-typ  = 'H'.
    ls_header-info = 'Collection MIS Pivot View for Custom Month'." for Date :' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4) .
    APPEND ls_header TO lt_header.
    CLEAR ls_header.
  ELSE.
    ls_header-typ  = 'H'.
    ls_header-info = 'Collection MIS Pivot View for Current Month'." for Date :' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4) .
    APPEND ls_header TO lt_header.
    CLEAR ls_header.
  ENDIF.


  IF p_rd1 = 'X'.
    ls_header-typ  = 'S'.
    ls_header-info = 'Date : ' &&  s_budat-low+6(2) && '.' &&  s_budat-low+4(2) && '.' && s_budat-low+0(4)  && '_TO_' &&  s_budat-high+6(2) && '.' &&  s_budat-high+4(2) && '.' && s_budat-high+0(4).
    APPEND ls_header TO lt_header.
    CLEAR ls_header.
  ELSEIF p_rd2 = 'X'.
    ls_header-typ  = 'S'.
    ls_header-info = 'Date : ' &&  lv_start+6(2) && '.' &&  lv_start+4(2) && '.' && lv_start+0(4)  && '_TO_' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4).
    APPEND ls_header TO lt_header.
    CLEAR ls_header.
  ENDIF.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = lt_header.

  REFRESH:lt_header.
ENDFORM.
FORM top_of_page_rb2.
  REFRESH lt_header[].
  ls_header-typ  = 'H'.
  ls_header-info = 'Collection MIS Detailed View'." for Date :' &&  sy-datum+6(2) && '.' &&  sy-datum+4(2) && '.' && sy-datum+0(4) .
  APPEND ls_header TO lt_header.
  CLEAR ls_header.

  ls_header-typ  = 'S'.
  ls_header-info = 'Date : ' &&  s_budat-low+6(2) && '.' &&  s_budat-low+4(2) && '.' && s_budat-low+0(4) && '_TO_' && s_budat-high+6(2) && '.' &&  s_budat-high+4(2) && '.' && s_budat-high+0(4).
  APPEND ls_header TO lt_header.
  CLEAR ls_header.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = lt_header.

  REFRESH:lt_header.
ENDFORM.
