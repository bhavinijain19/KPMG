class ZCL_ZFI_ICICI_MT940_DPC_EXT definition
  public
  inheriting from ZCL_ZFI_ICICI_MT940_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_STREAM
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_ICICI_MT940_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_stream.
    DATA: lv_filename  TYPE string,
          lv_path      TYPE string,
          lv_base_dir  TYPE tvarvc-low,
          lv_error_msg TYPE bapi_msg.

    IF iv_slug IS INITIAL.
      lv_error_msg = 'HTTP Header "Slug" (filename) is missing.'.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING
          textid  = /iwbep/cx_mgw_busi_exception=>business_error
          message = lv_error_msg.
    ENDIF.

    IF iv_slug IS NOT INITIAL.
      SELECT SINGLE low FROM tvarvc INTO lv_base_dir WHERE name = 'ZICICI_MT940_AL11_PATH'  AND type = 'P'.
      IF sy-subrc <> 0.
        lv_base_dir = '/usr/sap/tmp/'.
      ENDIF.

      lv_filename = iv_slug.

      lv_path = condense( lv_base_dir ) && lv_filename.

      " 3. Write binary content to AL11
      OPEN DATASET lv_path FOR OUTPUT IN BINARY MODE.
      IF sy-subrc = 0.
        TRANSFER is_media_resource-value TO lv_path.
        CLOSE DATASET lv_path.

        " 4. Prepare response (optional, but good practice)
        DATA(ls_entity) = VALUE zcl_zfi_icici_mt940_mpc=>ts_mt940file(
                            filename = lv_filename
                            mimetype = is_media_resource-mime_type ).

        copy_data_to_ref( EXPORTING is_data = ls_entity
                          CHANGING  cr_data = er_entity ).
      ELSE.
        lv_error_msg = |Failed to open file at { lv_path }. Check AL11 permissions.|.
        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
          EXPORTING
            textid  = /iwbep/cx_mgw_busi_exception=>business_error
            message = lv_error_msg.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entity.

  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entityset.

  ENDMETHOD.
ENDCLASS.
