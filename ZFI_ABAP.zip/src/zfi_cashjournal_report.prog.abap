*&---------------------------------------------------------------------*
*& Report  ZFI_CASHJOURNAL_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zfi_cashjournal_report.


TABLES : tcj_documents,tcj_positions,bkpf,dd07v .
TYPE-POOLS : slis.

TYPES : BEGIN OF ty_data,
          comp_code           TYPE tcj_documents-comp_code,
          cajo_number         TYPE tcj_documents-cajo_number,
          posting_number      TYPE tcj_documents-posting_number,
          posting_date        TYPE tcj_documents-posting_date,
          document_status(60),
          d_posting_numb      TYPE tcj_documents-d_posting_numb,
          h_net_amount        TYPE tcj_documents-h_net_amount,
          bukrs               TYPE bkpf-bukrs,
          belnr               TYPE bkpf-belnr,
          awkey               TYPE bkpf-awkey,
          cajo_name           TYPE tcj_cj_names-cajo_name,
          gl_account          TYPE tcj_positions-gl_account,
          txt50               TYPE skat-txt50,
          transact_name       TYPE tcj_trans_names-transact_name,
          position_text       TYPE tcj_positions-position_text,
          vendor_no           TYPE tcj_positions-vendor_no,
          customer            TYPE tcj_positions-customer,
          accountant          TYPE tcj_documents-accountant,
          prctr               TYPE tcj_positions-prctr,
        END OF ty_data.

TYPES : BEGIN OF ty_tcjdoc,
          comp_code           TYPE tcj_documents-comp_code,
          cajo_number         TYPE tcj_documents-cajo_number,
          posting_number      TYPE tcj_documents-posting_number,
          posting_date        TYPE tcj_documents-posting_date,
          document_status(10),
          d_posting_numb      TYPE tcj_documents-d_posting_numb,
          h_net_amount        TYPE tcj_documents-h_net_amount,
          accountant          TYPE tcj_documents-accountant,
        END OF ty_tcjdoc.

TYPES : BEGIN OF ty_bkpf,
          bukrs TYPE bkpf-bukrs,
          belnr TYPE bkpf-belnr,
          awkey TYPE bkpf-awkey,
        END OF ty_bkpf.

TYPES : BEGIN OF ty_awkey,
          awkey TYPE bkpf-awkey,
        END OF ty_awkey.


TYPES : BEGIN OF ty_cjnames,
          comp_code   TYPE tcj_cj_names-comp_code,
          cajo_number TYPE tcj_cj_names-cajo_number,
          cajo_name   TYPE tcj_cj_names-cajo_name,
        END OF ty_cjnames.

TYPES : BEGIN OF ty_dd07v,
          domname    TYPE dd07v-domname,
          domvalue_l TYPE dd07v-domvalue_l,
          ddtext     TYPE dd07v-ddtext,
        END OF ty_dd07v .

TYPES : BEGIN OF ty_tcjpos,
          comp_code       TYPE tcj_positions-comp_code,
          cajo_number     TYPE tcj_positions-cajo_number,
          posting_number  TYPE tcj_positions-posting_number,
          transact_number TYPE tcj_positions-transact_number,
          gl_account      TYPE tcj_positions-gl_account,
          position_text   TYPE tcj_positions-position_text,
          vendor_no       TYPE tcj_positions-vendor_no,
          customer        TYPE tcj_positions-customer,
          prctr           TYPE tcj_positions-prctr,
        END OF ty_tcjpos.

TYPES : BEGIN OF ty_skat,
          saknr TYPE skat-saknr,
          txt50 TYPE skat-txt50,
        END OF ty_skat.

TYPES : BEGIN OF ty_tcjtrans_nam,
          comp_code       TYPE tcj_trans_names-comp_code,
          transact_number TYPE tcj_trans_names-transact_number,
          transact_name   TYPE tcj_trans_names-transact_name,

        END OF ty_tcjtrans_nam.

DATA:v_awkey(20) TYPE c.
DATA:wa_awkey TYPE ty_awkey,
     it_awkey TYPE TABLE OF ty_awkey.

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE.

DATA : it_tcjdoc       TYPE STANDARD TABLE OF ty_tcjdoc,
       wa_tcjdoc       TYPE ty_tcjdoc,
       it_bkpf         TYPE STANDARD TABLE OF ty_bkpf,
       wa_bkpf         TYPE ty_bkpf,
       it_cjnames      TYPE STANDARD TABLE OF ty_cjnames,
       wa_cjnames      TYPE ty_cjnames,
       it_tcjpos       TYPE STANDARD TABLE OF ty_tcjpos,
       wa_tcjpos       TYPE ty_tcjpos,
       it_skat         TYPE STANDARD TABLE OF ty_skat,
       wa_skat         TYPE ty_skat,
       it_tcjtrans_nam TYPE STANDARD TABLE OF ty_tcjtrans_nam,
       wa_tcjtrans_nam TYPE ty_tcjtrans_nam,
       it_dd07v        TYPE STANDARD TABLE OF ty_dd07v,
       wa_dd07v        TYPE ty_dd07v,
       gi_final        TYPE STANDARD TABLE OF ty_data,
       wa_final        TYPE ty_data.

DATA : diff TYPE i.
*data: diff like P0347-SCRDD.

CONSTANTS:
  c_domname(30) TYPE c VALUE 'CJDOCSTAT'.

SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.
PARAMETERS : s_ccode TYPE tcj_documents-comp_code OBLIGATORY.
*             s_cjno  TYPE tcj_documents-cajo_number OBLIGATORY.
SELECT-OPTIONS : s_cjno  FOR tcj_documents-cajo_number OBLIGATORY,
                 s_pdate FOR tcj_documents-posting_date OBLIGATORY.
PARAMETERS : s_dstat TYPE tcj_documents-document_status .
SELECTION-SCREEN : END OF BLOCK a1 .

START-OF-SELECTION.

*CALL FUNCTION 'HR_HK_DIFF_BT_2_DATES'
*  EXPORTING
*    DATE1                         = s_pdate-high
*    DATE2                         = s_pdate-low
*   OUTPUT_FORMAT                 = '02'
* IMPORTING
*
*  DAYS                          = diff         .

CALL FUNCTION 'HR_SGPBS_YRS_MTHS_DAYS'
  EXPORTING
    beg_da              = s_pdate-low
    end_da              = s_pdate-high
 IMPORTING
*   NO_DAY              =
   NO_MONTH            = diff
*   NO_YEAR             =
*   NO_CAL_DAY          =
* EXCEPTIONS
*   DATEINT_ERROR       = 1
*   OTHERS              = 2
          .
IF sy-subrc <> 0.
* Implement suitable error handling here
ENDIF.

DATA: date TYPE p0001-begda.
DATA: date1 TYPE p0001-begda.
DATA: date2 TYPE p0001-begda.

CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
    EXPORTING
      date      = s_pdate-low
      days      = '01'
      months    = '00'
      signum    = '-'
      years     = '00'
    IMPORTING
      calc_date = date.

CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
    EXPORTING
      date      = date
      days      = '00'
      months    = '03'
      signum    = '+'
      years     = '00'
    IMPORTING
      calc_date = date1.




*  IF diff > 3.
date2 = s_pdate-high .
  if date1 < date2.
    MESSAGE 'Please enter posting date within 3 months' TYPE 'S' DISPLAY LIKE 'E'.
  ELSE.
    PERFORM get_data.
    IF it_tcjdoc[] IS INITIAL.
      MESSAGE 'Please enter valid data' TYPE 'S' DISPLAY LIKE 'E'.
    ElSE.
      PERFORM fill_fieldcatalog.
      PERFORM display_grid.
    ENDIF.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  IF s_dstat IS INITIAL.
    SELECT comp_code cajo_number posting_number h_net_amount posting_date document_status d_posting_numb accountant
    FROM tcj_documents
    INTO CORRESPONDING FIELDS OF TABLE it_tcjdoc
    WHERE comp_code         = s_ccode AND
          cajo_number      IN s_cjno  AND
          posting_date     IN  s_pdate .
  ELSE.
   SELECT comp_code cajo_number posting_number h_net_amount posting_date document_status d_posting_numb accountant
   FROM tcj_documents
   INTO CORRESPONDING FIELDS OF TABLE it_tcjdoc
   WHERE comp_code         = s_ccode AND
         cajo_number      IN s_cjno  AND
         posting_date     IN  s_pdate AND
         document_status  = s_dstat .
  ENDIF.

  IF  it_tcjdoc[] IS NOT INITIAL.
    SELECT comp_code cajo_number posting_number transact_number gl_account position_text vendor_no customer prctr
      FROM tcj_positions
      INTO CORRESPONDING FIELDS OF TABLE it_tcjpos
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE comp_code       = it_tcjdoc-comp_code AND
            cajo_number     = it_tcjdoc-cajo_number AND
            posting_number  = it_tcjdoc-posting_number .
  ENDIF.
  IF it_tcjpos IS NOT INITIAL.
    SELECT saknr txt50
      FROM skat
      INTO CORRESPONDING FIELDS OF TABLE it_skat
      FOR ALL ENTRIES IN it_tcjpos
      WHERE saknr = it_tcjpos-gl_account AND
            spras = sy-langu .

    SELECT comp_code transact_number transact_name
      FROM tcj_trans_names
      INTO CORRESPONDING FIELDS OF TABLE it_tcjtrans_nam
      FOR ALL ENTRIES IN it_tcjpos
      WHERE comp_code = it_tcjpos-comp_code AND
            transact_number = it_tcjpos-transact_number AND
            langu = sy-langu .
  ENDIF.

  IF it_tcjdoc IS NOT INITIAL.
    SELECT domname domvalue_l ddtext
     FROM dd07v
      INTO CORRESPONDING FIELDS OF TABLE it_dd07v
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE domname = c_domname AND
            ddlanguage = sy-langu AND
            domvalue_l = it_tcjdoc-document_status .

    LOOP AT it_tcjdoc INTO wa_tcjdoc.
      CONCATENATE wa_tcjdoc-posting_number wa_tcjdoc-cajo_number wa_tcjdoc-comp_code INTO wa_awkey-awkey.
      APPEND wa_awkey TO it_awkey.
      CLEAR:wa_awkey,wa_tcjdoc.
    ENDLOOP.

    SELECT comp_code cajo_number cajo_name
      FROM tcj_cj_names
      INTO CORRESPONDING FIELDS OF TABLE it_cjnames
      FOR ALL ENTRIES IN it_tcjdoc
      WHERE comp_code    = it_tcjdoc-comp_code AND
            cajo_number  = it_tcjdoc-cajo_number AND
            langu  = sy-langu.
  ENDIF.

  IF it_awkey IS NOT INITIAL.
    SELECT bukrs belnr awkey
      FROM bkpf
      INTO CORRESPONDING FIELDS OF TABLE it_bkpf
      FOR ALL ENTRIES IN it_awkey
      WHERE bukrs = s_ccode AND
            awkey = it_awkey-awkey .
  ENDIF.

************************************* READ TABLES *****************************************
  LOOP AT it_tcjdoc INTO wa_tcjdoc.
    wa_final-d_posting_numb  = wa_tcjdoc-d_posting_numb.
    wa_final-cajo_number     = wa_tcjdoc-cajo_number.
    wa_final-posting_date    = wa_tcjdoc-posting_date.
    wa_final-h_net_amount    = wa_tcjdoc-h_net_amount.
    wa_final-accountant      = wa_tcjdoc-accountant.

    READ TABLE it_tcjpos INTO wa_tcjpos WITH KEY cajo_number = wa_tcjdoc-cajo_number
                                                 posting_number = wa_tcjdoc-posting_number .
    wa_final-gl_account = wa_tcjpos-gl_account.
    wa_final-position_text  = wa_tcjpos-position_text .
    wa_final-vendor_no    = wa_tcjpos-vendor_no.
    wa_final-customer     = wa_tcjpos-customer.
    wa_final-prctr        = wa_tcjpos-prctr.
    READ TABLE it_tcjtrans_nam INTO wa_tcjtrans_nam WITH KEY transact_number = wa_tcjpos-transact_number.
    wa_final-transact_name = wa_tcjtrans_nam-transact_name .

    READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_tcjpos-gl_account.
    wa_final-txt50  = wa_skat-txt50.

    READ TABLE it_dd07v INTO wa_dd07v WITH KEY domvalue_l = wa_tcjdoc-document_status.
    wa_final-document_status = wa_dd07v-ddtext .

*    IF wa_tcjdoc-document_status EQ 'P'.
*      wa_final-document_status = 'Posted'.
*    ELSEIF wa_tcjdoc-document_status EQ 'S'.
*      wa_final-document_status = 'Saved'.
*    ENDIF.

    READ TABLE it_cjnames INTO wa_cjnames WITH KEY comp_code   = wa_tcjdoc-comp_code
                                                   cajo_number  = wa_tcjdoc-cajo_number .
    wa_final-cajo_name = wa_cjnames-cajo_name.

    CONCATENATE wa_tcjdoc-posting_number wa_tcjdoc-cajo_number wa_tcjdoc-comp_code INTO v_awkey.
    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_tcjdoc-comp_code
                                             awkey = v_awkey .
    IF sy-subrc EQ 0.
      wa_final-belnr = wa_bkpf-belnr .
    ENDIF.

    APPEND wa_final TO gi_final.
    CLEAR : wa_tcjdoc,wa_cjnames,wa_bkpf,wa_dd07v,wa_skat,wa_tcjpos,wa_final.

  ENDLOOP.

LOOP AT gi_final INTO wa_final.
****  Added auth. CHECK by Carina Jose ON 01.03.2022
  authority-check object 'Z_CJR_PRCT'
  id 'PRCTR' field wa_final-prctr
  id 'ACTVT' field '03'.
    IF sy-subrc NE 0.
*      MESSAGE e018(zfi) WITH wa_final-prctr.
      DELETE gi_final WHERE d_posting_numb = wa_final-d_posting_numb AND belnr = wa_final-belnr AND cajo_number = wa_final-cajo_number .
    ENDIF.
   CLEAR : wa_final.
****  End of Channges by carina Jose on 01.03.2022

ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'TRANSACT_NAME'               'Business Transaction'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'D_POSTING_NUMB'               'Saved Document No.'                'X'  'GI_FINAL' 'C100'  .
  PERFORM fieldcat_append  USING  'BELNR'               'Posted Document No.'                'X'  'GI_FINAL' 'C100'  .
  PERFORM fieldcat_append  USING  'POSTING_DATE'               'Posting Date'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'CAJO_NUMBER'               'Cash Journal'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'CAJO_NAME'               'Cash Journal Name'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'H_NET_AMOUNT'               'Amount'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'GL_ACCOUNT'               'G/L'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'TXT50'               'G/L Desc.'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'DOCUMENT_STATUS'               'Status Indicator'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'POSITION_TEXT'               'Text'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'VENDOR_NO'               'Vendor'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'CUSTOMER'               'Customer'                'X'  'GI_FINAL' ' '  .
  PERFORM fieldcat_append  USING  'ACCOUNTANT'               'User ID'                'X'  'GI_FINAL' ' '  .
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0099   text
*      -->P_0100   text
*      -->P_0101   text
*      -->P_0102   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table)
                               VALUE(p_emph).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  t_fieldcatalog-emphasize   = p_emph.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
      it_events          = t_event[]
      i_save             = 'A'
    TABLES
      t_outtab           = gi_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
  ENDIF.
ENDFORM.
