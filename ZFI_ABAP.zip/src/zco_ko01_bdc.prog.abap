REPORT zco_ko01_bdc.
*&---------------------------------------------- DATA DECLARATION -------------------------------------------------------------&*
TYPES: BEGIN OF ty_ko01,
         kokrs(04),
         auart(04),
         aufnr(10),
         ktext(40),
         bukrs(04),
         gsber(04),
         werks(04),
         scope(04),
         prctr(10),
         kostv(10),
         user(12),
         waers(05),
         astkz(01),
         user0(20),
         user2(20),

       END OF ty_ko01.

DATA :it_type TYPE truxs_t_text_data.
DATA : file_name TYPE string.
DATA : it_data TYPE STANDARD TABLE OF ty_ko01 WITH HEADER LINE,
       wa_data TYPE ty_ko01.

DATA:wa_bdc TYPE bdcdata,
     it_bdc TYPE TABLE OF bdcdata.

DATA:wa_msg TYPE bdcmsgcoll,
     it_msg TYPE TABLE OF bdcmsgcoll.

TYPES : BEGIN OF ty_error,
          sno          TYPE i,
*          efield(200),
          message(100) TYPE c,
        END OF ty_error.
DATA: wa_error TYPE ty_error,
      it_error TYPE STANDARD TABLE OF ty_error.
TYPES : BEGIN OF ty_header,
          text(20),
        END OF ty_header.
TYPES :  BEGIN OF t_message   ,
           lifnr   TYPE char10  , " Customer Number
           status  TYPE char4   , " Light Indicator
           type    TYPE char4   , " Error Type
           message TYPE char255 , " Message Description
         END OF t_message    .

DATA :  it_header TYPE STANDARD TABLE OF ty_header,
        wa_header TYPE ty_header.
DATA: i_field     TYPE slis_t_fieldcat_alv,
      it_fieldcat TYPE slis_t_fieldcat_alv WITH HEADER LINE,
      i_message   TYPE STANDARD TABLE OF t_message.

DATA:count  TYPE i.

FIELD-SYMBOLS :
  <x_message> TYPE t_message,
  <x_field>   TYPE slis_fieldcat_alv,
  <x_bdcdata> TYPE bdcdata,
  <x_msg>     TYPE bdcmsgcoll.

CONSTANTS:
  c_x    TYPE char1 VALUE 'X',
  c_e    TYPE char1 VALUE 'E',
  c_i    TYPE char1 VALUE 'I',
  c_s    TYPE char1 VALUE 'S',
  c_l    TYPE char1 VALUE 'L',
  c_a    TYPE char1 VALUE 'A',
  c_n    TYPE char1 VALUE 'N',
  c_xls  TYPE char4 VALUE '.XLS',
" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  c_xd01 TYPE char4 VALUE 'XD01',    "#EC CI_USAGE_OK[2226131]
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  c_en   TYPE char2 VALUE 'EN'.

DATA: gv_sno(02),
      gv_fname(60).
DATA: cursor TYPE i.

*&---------------------------------------------- SELECTION SCREEN -------------------------------------------------------------&*
SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
PARAMETERS:p_file  TYPE rlgrap-filename OBLIGATORY,
*           p_file1 TYPE rlgrap-filename OBLIGATORY, " Download FileName
           p_mode  LIKE ctu_params-dismode DEFAULT 'A'.         " Mode .
SELECTION-SCREEN:END OF BLOCK a1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'WS_FILENAME_GET'
    EXPORTING
      def_filename     = space
      def_path         = space
      mask             = ',*.*,*.*.'
      mode             = space
      title            = space
    IMPORTING
      filename         = p_file
*     RC               =
    EXCEPTIONS
      inv_winsys       = 1
      no_batch         = 2
      selection_cancel = 3
      selection_error  = 4
      OTHERS           = 5.
  IF sy-subrc <> 0 AND sy-subrc <> 3.
    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
  ENDIF.
*
*AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file1.
*  PERFORM f4_help1.

START-OF-SELECTION.
  PERFORM upload.
  PERFORM authorization_check.
  PERFORM bdc.
  PERFORM field_catalog.
  PERFORM append_header.
  PERFORM alv_display.          " Display Return Message In ALV


*&---------------------------------------------------------------------*
*&      Form  F4_HELP1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_help1 .
*  CALL FUNCTION 'F4_FILENAME'
*    EXPORTING
*      program_name = sy-repid
*    IMPORTING
*      file_name    = p_file1.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload .

  file_name  = p_file.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = it_data
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
  ENDIF.

*include bdcrecx1.
*
*start-of-selection.
*
*perform open_group.


*perform close_group.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc .
  LOOP AT IT_DATA INTO WA_DATA.

  PERFORM bdc_dynpro      USING 'SAPMKAUF' '0100'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'COAS-KOKRS'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.
  PERFORM bdc_field       USING 'COAS-KOKRS'
                                 wa_data-kokrs. "'1000'.
  perform bdc_field       using 'COAS-AUART'
                                wa_data-auart."'Y002'.
  PERFORM bdc_dynpro      USING 'SAPMKAUF' '0600'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BUT2'.
  perform bdc_field       using 'COAS-AUFNR'
                                wa_data-aufnr." '1756'.
  PERFORM bdc_field       USING 'COAS-KTEXT'
                                 wa_data-ktext."'Test'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'COAS-VERAA_USER'.
  PERFORM bdc_field       USING 'COAS-BUKRS'
                                wa_data-bukrs."'1000'.
  PERFORM bdc_field       USING 'COAS-GSBER'
                                wa_data-gsber."'0001'.
  PERFORM bdc_field       USING 'COAS-WERKS'
                                wa_data-werks."'1000'.
  PERFORM bdc_field       USING 'COAS-SCOPE'
                                wa_data-scope."'OCOST'.
  PERFORM bdc_field       USING 'COAS-PRCTR'
                                wa_data-prctr."'1000010226'.
  PERFORM bdc_field       USING 'COAS-KOSTV'
                                 wa_data-kostv."'1030550098'.
  PERFORM bdc_field       USING 'COAS-VERAA_USER'
                                 wa_data-user."'APLCO01'.
  PERFORM bdc_dynpro      USING 'SAPMKAUF' '0600'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BUT4'.
  PERFORM bdc_field       USING 'COAS-KTEXT'
                                wa_data-ktext."'Test'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'COAS-ASTKZ'.
  PERFORM bdc_field       USING 'COAS-WAERS'
                                wa_data-waers."'INR'.
  PERFORM bdc_field       USING 'COAS-ASTKZ'
                                wa_data-astkz."'X'.
  PERFORM bdc_dynpro      USING 'SAPMKAUF' '0600'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=SICH'.
  PERFORM bdc_field       USING 'COAS-KTEXT'
                                wa_data-ktext." 'Test'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'COAS-USER1'.
  PERFORM bdc_field       USING 'COAS-USER0'
                                wa_data-user0."'abcd'.
*  PERFORM bdc_field       USING 'COAS-USER5'
*                                '10.08.2022'.
*  PERFORM bdc_field       USING 'COAS-USER1'
*                                '123456789'.
  PERFORM bdc_field       USING 'COAS-USER2'
                                wa_data-user2."'NILESH'.
  CALL TRANSACTION 'KO01' USING it_bdc MODE p_mode UPDATE 'S' MESSAGES INTO it_msg.
*  PERFORM bdc_transaction USING 'KO01'.

   IF  it_msg IS NOT INITIAL.
      PERFORM populate_error.
    ENDIF.

  REFRESH it_bdc.
  CLEAR : wa_data.
ENDLOOP.

ENDFORM.
FORM bdc_dynpro USING program screen.

  wa_bdc-program = program.
  wa_bdc-dynpro = screen.
  wa_bdc-dynbegin = 'X'.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
FORM bdc_field USING field value.

  wa_bdc-fnam = field.
  wa_bdc-fval = value.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  POPULATE_ERROR
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM populate_error .
  DATA : lv_msg TYPE string.
  LOOP AT it_msg INTO wa_msg.
    CALL FUNCTION 'FORMAT_MESSAGE'
      EXPORTING
        id   = wa_msg-msgid
        lang = sy-langu
        no   = wa_msg-msgnr
        v1   = wa_msg-msgv1
        v2   = wa_msg-msgv2
        v3   = wa_msg-msgv3
        v4   = wa_msg-msgv4
      IMPORTING
        msg  = lv_msg.

    IF wa_msg-msgtyp = c_s  AND wa_msg-msgid = 'KO'.
*                              AND wa_msg-msgnr = '271' OR wa_msg-msgnr = '175'.
      UNASSIGN <x_message>.
      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
      IF <x_message> IS ASSIGNED.
        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message>-status       = icon_led_green        .
        <x_message>-type         =  wa_msg-msgtyp       .
        <x_message>-message      = lv_msg                .
      ENDIF.
*      ELSEIF wa_msg-msgtyp = c_i  .
*        UNASSIGN <x_message>.
*        APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
*        IF <x_message> IS ASSIGNED.
*          <x_message>-lifnr        = wa_msg-msgv1         .
*          <x_message>-status       = icon_led_yellow        .
*          <x_message>-type         =  wa_msg-msgtyp       .
*          <x_message>-message      = lv_msg                .
*        ENDIF.

      ELSEIF wa_msg-msgtyp = c_s  AND wa_msg-msgid = '06'.
        UNASSIGN <x_message>.
        APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
        IF <x_message> IS ASSIGNED.
          <x_message>-lifnr        = wa_msg-msgv1         .
          <x_message>-status       = icon_led_green        .
          <x_message>-type         =  wa_msg-msgtyp       .
          <x_message>-message      = lv_msg                .
        ENDIF.
      ELSEIF wa_msg-msgtyp = c_e.
        UNASSIGN <x_message>.
        APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
        IF <x_message> IS ASSIGNED.

*          <x_message>-lifnr        = wa_msg-msgv1                       .
          <x_message>-status       = icon_led_red          .
          <x_message>-type         = wa_msg-msgtyp        .
          IF wa_msg-msgid = 'AM' AND wa_msg-msgnr = '214'
            OR wa_msg-msgid = 'AM' AND wa_msg-msgnr = '215'.
            <x_message>-type = c_e.
          ENDIF.
          <x_message>-message      = lv_msg                .
        ENDIF.
      ENDIF.

      DELETE it_msg WHERE msgnr = wa_msg-msgnr.
*      IF <x_message>-kunnr IS NOT INITIAL.
*        EXIT.
*      ENDIF.
    ENDLOOP.

    IF sy-subrc = 0 .
      count = count + 1.
      wa_error-sno = count.
*    CONCATENATE wa_msg-msgv1 wa_msg-msgv2 wa_msg-msgv3 wa_msg-msgv4 INTO wa_error-efield.
      wa_error-message = lv_msg.
*    wa_error-matnr = wa_msg-msgv1.
*    wa_error-werks = wa_msg-msgv2.
      APPEND wa_error TO it_error.
      CLEAR:wa_error.
    ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELD_CATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM field_catalog .
  PERFORM fieldcat_append  USING  'STATUS'               'STATUS'                'X'  'I_MESSAGE'    '5'.
  PERFORM fieldcat_append  USING  'TYPE'               'TYPE'                'X'  'I_MESSAGE'    '5'.
  PERFORM fieldcat_append  USING  'MESSAGE'               'MESSAGE DESCRIPTION'                'X'  'I_MESSAGE'  '60'  .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_1546   text
*      -->P_1547   text
*      -->P_1548   text
*      -->P_1549   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table)
                                 VALUE(p_outlen).
  it_fieldcat-fieldname   = p_fname.
  it_fieldcat-seltext_l   = p_ftext.
  it_fieldcat-fix_column  = p_fixcol.
  it_fieldcat-tabname     = p_table.
  it_fieldcat-outputlen   = p_outlen.
  APPEND it_fieldcat.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  APPEND_HEADER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM append_header .
 wa_header-text = 'Sr. No.'.
  APPEND wa_header TO it_header.
  CLEAR :wa_header.

  wa_header-text = 'Message'.
  APPEND wa_header TO it_header.
  CLEAR :wa_header.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  ALV_DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_display .
  DATA : lv_repid TYPE sy-repid.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = lv_repid
      it_fieldcat        = it_fieldcat[]
      i_save             = 'A'
    TABLES
      t_outtab           = i_message
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
   LOOP AT it_data INTO wa_data.
    AUTHORITY-CHECK OBJECT 'ZAUFK_ART'
        ID 'AUFART' FIELD wa_data-auart
        ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e025(zfi) WITH wa_data-auart.
    ENDIF.
    CLEAR : wa_data.
  ENDLOOP.
ENDFORM.
