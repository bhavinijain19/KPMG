class ZCL_ZFI_ASSET_VAL definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_FAA_GENERAL_SERVICES .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_ASSET_VAL IMPLEMENTATION.


  method IF_FAA_GENERAL_SERVICES~PROVIDE_DEPR_POSTING_DATA.
  endmethod.


  METHOD if_faa_general_services~provide_master_data.

    IF it_anlz IS NOT INITIAL.
      READ TABLE it_anlz INTO DATA(ls_anlz) INDEX 1.

      IF ls_anlz-werks IS INITIAL OR ls_anlz-werks IS INITIAL.
        SELECT SINGLE * FROM anlz INTO @DATA(ls_anlz_old)
           WHERE bukrs = @ls_anlz-bukrs AND anln1 = @ls_anlz-anln1.
        ls_anlz-werks = ls_anlz_old-werks.
        ls_anlz-gsber = ls_anlz_old-gsber.
      ENDIF.

      IF ls_anlz-prctr IS NOT INITIAL.
        DATA(lv_prctr) = ls_anlz-prctr+4(4).
        IF NOT ( ls_anlz-gsber = ls_anlz-werks AND ls_anlz-gsber = lv_prctr ).
          MESSAGE 'Business area, Plant and Profit center - First four digit should be match'
                    TYPE 'E' DISPLAY LIKE 'W'. "e004(zfi_msgs).
        ENDIF.
      ELSEIF ls_anlz-gsber IS NOT INITIAL AND ls_anlz-werks IS NOT INITIAL.
        IF ls_anlz-gsber NE ls_anlz-werks .
          MESSAGE 'Business area and Plant should be match'
          TYPE 'E' DISPLAY LIKE 'W'. "e004(zfi_msgs).
        ENDIF.
      ENDIF.


    ENDIF.

  ENDMETHOD.


  method IF_FAA_GENERAL_SERVICES~PROVIDE_POSTING_DATA.
  endmethod.


  method IF_FAA_GENERAL_SERVICES~PREPARE_DEPR_POSTING_DATA.
  endmethod.


  method IF_FAA_GENERAL_SERVICES~PROCESS_BADI_CALL_IN_TEST_RUN.
  endmethod.


  method IF_FAA_GENERAL_SERVICES~PROVIDE_DEPR_RECALC_DATA.
  endmethod.
ENDCLASS.
