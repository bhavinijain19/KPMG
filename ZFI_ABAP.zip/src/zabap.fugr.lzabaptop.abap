FUNCTION-POOL ZABAP                      MESSAGE-ID SV.

* INCLUDE LZABAPD...                         " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZABAPT00                               . "view rel. data dcl.
