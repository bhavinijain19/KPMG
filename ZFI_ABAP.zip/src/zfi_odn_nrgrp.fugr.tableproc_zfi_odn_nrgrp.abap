*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_ODN_NRGRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_ODN_NRGRP       .

  PERFORM TABLEPROC.

ENDFUNCTION.
