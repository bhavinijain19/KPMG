PROCESS BEFORE OUTPUT.
  MODULE set_screen_attr.
*
PROCESS AFTER INPUT.
  CHAIN.
    FIELD gv_bukrs.
    FIELD gv_hbkid.
    FIELD gv_hktid.
    field gv_aznum.
    MODULE m_get_inv ON CHAIN-REQUEST.
    field gv_esald MODULE m_esald.
  ENDCHAIN.
  FIELD gv_ssald MODULE m_check.

  MODULE user_command_8001.
