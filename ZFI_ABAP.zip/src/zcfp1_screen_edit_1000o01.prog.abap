*&---------------------------------------------------------------------*
*&  Include  ZCFP1_SCREEN_EDIT_1000O01
*&---------------------------------------------------------------------*

*&SPWIZARD: OUTPUT MODULE FOR TC 'TC_REG'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: UPDATE LINES FOR EQUIVALENT SCROLLBAR
MODULE tc_reg_change_tc_attr OUTPUT.
  DESCRIBE TABLE it_part LINES tc_reg-lines.

  IF it_part[] IS INITIAL.
    CLEAR wa_part.

    DO 4 TIMES.
      APPEND wa_part TO it_part.
    ENDDO.
  ENDIF.
ENDMODULE.

*&SPWIZARD: OUTPUT MODULE FOR TC 'TC_REG'. DO NOT CHANGE THIS LINE!

MODULE tc_reg_get_lines OUTPUT.
  g_tc_reg_lines = sy-loopc.

  IF wa_part-kunnr IS NOT INITIAL.
    LOOP AT SCREEN.
      IF screen-group1 = c_g1 OR screen-name = 'WA_PART-ZTOTAL'.
        screen-input = c_0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.
  SET PF-STATUS c_status.
*  SET TITLEBAR 'xxx'.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  SCREEN_EDIT_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE screen_edit_0100 OUTPUT.
  DATA : l_okcode TYPE sy-ucomm.

  IF sy-ucomm = c_new or sy-ucomm = c_fetch.
    l_okcode = sy-ucomm.
  ENDIF.

  IF sy-ucomm = c_save.
    CLEAR : w_kunnr, w_bukrs, l_okcode.
  ENDIF.
  IF w_kunnr IS INITIAL.
    LOOP AT SCREEN.
      IF screen-name = c_name OR screen-name = c_cust_name.
        screen-invisible = c_1.
        MODIFY SCREEN.
      ENDIF.

*      IF screen-name = 'ZFETCH' OR screen-name = 'NEW_DATA'.
*        screen-input = c_0.
*        screen-invisible = c_1.
*        MODIFY SCREEN.
*      ENDIF.

      tc_reg-invisible = c_x.
      MODIFY SCREEN.
    ENDLOOP.

  ELSE.
    IF sy-ucomm = c_new OR sy-ucomm = c_fetch.

      CLEAR tc_reg-invisible.
    ENDIF.
  ENDIF.

  IF sy-ucomm = 'SAVE'.
    REFRESH it_part[].
  ENDIF.

*  IF sy-ucomm = c_new.
  IF l_okcode = c_new.
    LOOP AT SCREEN.
      IF screen-name = 'ZFETCH'.
        screen-input = c_0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.

*  IF sy-ucomm = c_fetch.
  IF l_okcode = c_fetch.
    LOOP AT SCREEN.
      IF screen-name = 'NEW_DATA'.
        screen-input = c_0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDMODULE.
