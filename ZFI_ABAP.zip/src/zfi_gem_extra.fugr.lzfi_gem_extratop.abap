FUNCTION-POOL ZFI_GEM_EXTRA              MESSAGE-ID SV.

* INCLUDE LZFI_GEM_EXTRAD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GEM_EXTRAT00                       . "view rel. data dcl.
