"Name: \PR:SAPLRKPM\FO:SET_LOCKS_FOR_KHINR\SE:BEGIN\EI
ENHANCEMENT 0 ZFI_PROFIT_CENTER_CHECK.
IF prct_v IS NOT INITIAL.
  DATA(lv_prctr) = prct_v-prctr+4(4).
  IF prct_v-khinr NE lv_prctr.
    MESSAGE '"Please select correct profit center hierarchy/group'
    TYPE 'E' DISPLAY LIKE 'E'.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
