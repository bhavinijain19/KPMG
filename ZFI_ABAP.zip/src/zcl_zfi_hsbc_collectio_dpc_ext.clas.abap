class ZCL_ZFI_HSBC_COLLECTIO_DPC_EXT definition
  public
  inheriting from ZCL_ZFI_HSBC_COLLECTIO_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_HSBC_COLLECTIO_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    DATA: lt_db_insert TYPE TABLE OF zfi_colle_log,
          lv_has_error TYPE abap_bool VALUE abap_false.
    DATA: ls_deep_data      TYPE zcl_zfi_hsbc_collectio_mpc_ext=>ty_deep_entity. " Replace with your MPC type
    DATA: lv_bank_acc TYPE bankn,
          lv_date     TYPE char10.

    io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_data ).

    READ TABLE ls_deep_data-toitems ASSIGNING FIELD-SYMBOL(<fs_filename>) INDEX 1.
    IF sy-subrc = 0.
      IF <fs_filename>-filename+0(7) = 'CAMT054'.
        SELECT bukrs, zuonr
          FROM zfi_colle_log_ap
          FOR ALL ENTRIES IN @ls_deep_data-toitems
          WHERE zuonr = @ls_deep_data-toitems-zuonr
          INTO TABLE @DATA(lt_existing).
      ELSE.
        SELECT bukrs, zuonr
          FROM zfi_colle_log
          FOR ALL ENTRIES IN @ls_deep_data-toitems
          WHERE zuonr = @ls_deep_data-toitems-zuonr
          INTO TABLE @lt_existing.
      ENDIF.
    ENDIF.

    LOOP AT ls_deep_data-toitems ASSIGNING FIELD-SYMBOL(<fs_item>).
      DATA(lv_error_flag) = abap_false.

      lv_bank_acc = <fs_item>-message.
      CONDENSE lv_bank_acc.
      CLEAR:<fs_item>-message.

      CONDENSE <fs_item>-zuonr NO-GAPS.

      IF <fs_item>-van IS NOT INITIAL.
        IF <fs_item>-van+0(6) = 'ASTRAL' OR <fs_item>-van+0(6) = 'RESINO'.
        ELSE.
          CONTINUE.
        ENDIF.
      ENDIF.

      IF <fs_item>-filename EQ 'CAMT054'.
        <fs_item>-filename = |{ <fs_item>-filename }_{ sy-datum }_{ sy-uzeit }|.
        IF <fs_item>-bukrs IS INITIAL.
          <fs_item>-bukrs = '1000'.
        ENDIF.
        IF <fs_item>-blart IS INITIAL.
          <fs_item>-blart = 'DZ'.
        ENDIF.
        IF <fs_item>-bldat IS NOT INITIAL.
          lv_date = |{ <fs_item>-bldat+8(2) }.{ <fs_item>-bldat+5(2) }.{ <fs_item>-bldat+0(4) }|.
          <fs_item>-bldat = lv_date.
        ENDIF.
        IF <fs_item>-budat IS NOT INITIAL.
          lv_date = |{ <fs_item>-budat+8(2) }.{ <fs_item>-budat+5(2) }.{ <fs_item>-budat+0(4) }|.
          <fs_item>-budat = lv_date.
        ENDIF.
        IF <fs_item>-vdate IS NOT INITIAL.
          lv_date = |{ <fs_item>-vdate+8(2) }.{ <fs_item>-vdate+5(2) }.{ <fs_item>-vdate+0(4) }|.
          <fs_item>-vdate = lv_date.
        ENDIF.
        IF <fs_item>-van IS NOT INITIAL.
          <fs_item>-kunnr = substring( val = <fs_item>-van off = strlen( <fs_item>-van ) - 7 ).
        ENDIF.

        SELECT SINGLE hkont
          FROM zfi_hsbc_gl
          WHERE bankn = @lv_bank_acc
          INTO @<fs_item>-hkont.
        IF sy-subrc <> 0.
          <fs_item>-message = 'Bank Account & GL Account mapping not found; '.
          lv_error_flag = abap_true.
        ENDIF.
      ENDIF.

      IF <fs_item>-bukrs IS INITIAL OR <fs_item>-zuonr IS INITIAL.
        <fs_item>-message = <fs_item>-message && 'Mandatory keys Bukrs/Zuonr missing; '.
        lv_error_flag = abap_true.
      ENDIF.

      READ TABLE lt_existing TRANSPORTING NO FIELDS
           WITH KEY bukrs = <fs_item>-bukrs
                    zuonr = <fs_item>-zuonr.
      IF sy-subrc = 0.
        <fs_item>-message = <fs_item>-message && 'EXIST; '.
        lv_error_flag = abap_true.
      ENDIF.

      IF lv_error_flag = abap_false.
        APPEND INITIAL LINE TO lt_db_insert ASSIGNING FIELD-SYMBOL(<fs_db>).
        MOVE-CORRESPONDING <fs_item> TO <fs_db>.

        <fs_item>-message = 'SUCCESS'.
      ENDIF.
      CLEAR: lv_bank_acc.
    ENDLOOP.

    IF lt_db_insert IS NOT INITIAL.
      READ TABLE ls_deep_data-toitems ASSIGNING <fs_filename> INDEX 1.
      IF sy-subrc = 0.
        IF <fs_filename>-filename+0(7) = 'CAMT054'.
          " Modify the specific table for CAMT054
          MODIFY zfi_colle_log_ap FROM TABLE lt_db_insert.
        ELSE.
          " Modify the general log table for other filenames
          MODIFY zfi_colle_log FROM TABLE lt_db_insert.
        ENDIF.
      ENDIF.
      IF sy-subrc = 0.
        COMMIT WORK.
      ELSE.
        ROLLBACK WORK.
      ENDIF.
    ENDIF.

    copy_data_to_ref( EXPORTING is_data = ls_deep_data
                      CHANGING  cr_data = er_deep_entity ).

  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entity.
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entityset.
    DATA: lt_header TYPE TABLE OF zcl_zfi_hsbc_collectio_mpc_ext=>ty_deep_entity,
          ls_header LIKE LINE OF lt_header,
          ls_item   TYPE zcl_zfi_hsbc_collectio_mpc_ext=>ts_hsbccollection.

    ls_header-filename = 'SAMPLE_PAYMENT_FILE.csv'.

    ls_item-bukrs     = '1000'.
    ls_item-zuonr     = '20260001'.
    ls_item-filename  = 'SAMPLE_PAYMENT_FILE.csv'.
    ls_item-bldat     = sy-datum.
    ls_item-blart     = 'DZ'.
    ls_item-budat     = sy-datum.
    ls_item-monat     = '03'.
    ls_item-waers     = 'INR'.
    ls_item-hkont     = '0011002233'.
    ls_item-dmbtr     = '15250'.
    ls_item-vdate     = sy-datum.
    ls_item-text      = 'Sample Collection Text'.
    ls_item-kunnr     = '1234567890'.
    ls_item-message   = 'Sample Success Message'.

    APPEND ls_item TO ls_header-toitems.

    APPEND ls_header TO lt_header.

    copy_data_to_ref(
      EXPORTING
        is_data = lt_header
      CHANGING
        cr_data = er_entityset
    ).

  ENDMETHOD.
ENDCLASS.
