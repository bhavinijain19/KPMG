**&-------------------------------------------------------------------*
**& REPORT AUTHOR         : Mahir Maniar
**& FUNCTIONAL CONSULTANT :
**& REPORT CREATION DATE  : 18/06/2016
**& TRANSACTION CODE      : ZFI_VOUCHER
**& REQUEST NUMBER        :
**& PURPOSE               : Uploading Voucher Details of Bank in Customer after uploading F-110
**&-------------------------------------------------------------------*

REPORT zfi_bank_voucher_upload_al11 MESSAGE-ID zsd..

*include bdcrecx1.
SELECTION-SCREEN:BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.
*
*PARAMETERS:p_file TYPE rlgrap-filename.
PARAMETERS: p_mode LIKE ctu_params-dismode DEFAULT 'E' NO-DISPLAY.

SELECTION-SCREEN:END OF BLOCK b1.



DATA:wa_msg TYPE bdcmsgcoll,
     it_msg TYPE TABLE OF bdcmsgcoll.

TYPES:BEGIN OF ty_bank,
        gjahr(4)    TYPE c,
        type(4)     TYPE c,
        bukrs(4)    TYPE c,
        lifnr(10)   TYPE c,
        iden(5)     TYPE c,
        value(17)   TYPE c,
        text2(100)  TYPE c,
        text3(100)  TYPE c,
        text4(100)  TYPE c,
        text5(100)  TYPE c,
        text6(100)  TYPE c,
        text7(100)  TYPE c,
        text8(100)  TYPE c,
        text9(100)  TYPE c,
        text10(100) TYPE c,
      END OF ty_bank.

DATA:wa_bank TYPE ty_bank,
     it_bank TYPE TABLE OF ty_bank. " WITH HEADER LINE.

TYPES:BEGIN OF ty_bank1,
        a  TYPE  string,
        b  TYPE  string,
        c  TYPE  string,
        d  TYPE  string,
        e  TYPE  string,
        f  TYPE  string,
        g  TYPE  string,
        h  TYPE  string,
        i  TYPE  string,
        j  TYPE  string,
        k  TYPE  string,
        l  TYPE  string,
        m  TYPE  string,
        n  TYPE  string,
        o  TYPE  string,
        p  TYPE  string,
        q  TYPE  string,
        r  TYPE  string,
        s  TYPE  string,
        t  TYPE  string,
        u  TYPE  string,
        v  TYPE  string,
        w  TYPE  string,
        x  TYPE  string,
        y  TYPE  string,
        z  TYPE  string,
        aa TYPE  string,


      END OF ty_bank1.

DATA:wa_bank1 TYPE ty_bank1,
     it_bank1 TYPE TABLE OF ty_bank1. " WITH HEADER LINE.

DATA:wa_bank2 TYPE ty_bank1,
     it_bank2 TYPE TABLE OF ty_bank1. " WITH HEADER LINE.

DATA:wa_bank3 TYPE ty_bank1,
     it_bank3 TYPE TABLE OF ty_bank1. " WITH HEADER LINE.

DATA:filename TYPE string.

DATA: it_raw TYPE truxs_t_text_data.

TYPES:BEGIN OF ty_iden,
*        date(10) TYPE c,
        gjahr      TYPE gjahr,
        bukrs      TYPE bukrs,
        lifnr      TYPE lifnr,
        zuonr      TYPE dzuonr,
        dmbtr      TYPE dmbtr,
        ref(40)    TYPE c,
        tbudat(10),
        budat      TYPE budat,
      END OF ty_iden.

DATA:wa_bsak TYPE ty_iden,
     it_bsak TYPE TABLE OF ty_iden.

TYPES: BEGIN OF ty_bsak1,
         bukrs TYPE bsak-bukrs,
         lifnr TYPE bsak-lifnr,
         zuonr TYPE bsak-zuonr,
         gjahr TYPE bsak-gjahr,
         belnr TYPE bsak-belnr,
         buzei TYPE bsak-buzei,
         xblnr TYPE bsak-xblnr,
         dmbtr TYPE bsak-dmbtr,
         budat TYPE bsak-budat,
         umskz TYPE bsak-umskz,

       END OF ty_bsak1.

***********************************************************Added by Raj on 04.05.2023************************************
TYPES : BEGIN OF ty_bseg,
          bukrs TYPE bseg-bukrs,
          belnr TYPE bseg-belnr,
          gjahr TYPE bseg-gjahr,
          buzei TYPE bseg-buzei,
          zuonr TYPE bseg-zuonr,
        END OF ty_bseg.

DATA : it_bseg TYPE STANDARD TABLE OF ty_bseg,
       wa_bseg TYPE ty_bseg.
*********************************************************Added by Raj on 04.05.2023**************************************

DATA:wa_bsak1 TYPE ty_bsak1,
     it_bsak1 TYPE TABLE OF ty_bsak1.

DATA:wa_bdc TYPE bdcdata,
     it_bdc TYPE TABLE OF bdcdata.

DATA: wrk_file1 LIKE epsf-epsdirnam.
DATA: wrk_file2 LIKE epsf-epsdirnam.
DATA :lv_count        TYPE  char4.

TYPES  :      BEGIN OF ty_files,
                appsrv_fname TYPE localfile, " rlgrap-filename,
              END   OF ty_files.

DATA: t_file_list  TYPE TABLE OF epsfili WITH HEADER LINE,
      t_files      TYPE TABLE OF ty_files WITH HEADER LINE,
      lv_filename1 TYPE sapb-sappfad, "rcgfiletr-ftappl,
      lv_filename2 TYPE rcgfiletr-ftappl.
*data :  t_files      TYPE TABLE OF ty_files WITH HEADER LINE."Added by Raj on 05.06.2024
*DATA: gv_fname(60)   VALUE '\\SAPDEV\sapmnt\trans\hsbcpmt\inward'."
CONSTANTS:con_tab TYPE c VALUE cl_abap_char_utilities=>horizontal_tab.

DATA: c_tvarvc_name TYPE rvari_vnam VALUE 'HSBCPMT_INWARD'.
CONSTANTS : c_tvarvc_name1 TYPE rvari_vnam VALUE 'HSBCPMT_INWARD_DELE'.

*AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
*
*  CALL FUNCTION 'F4_FILENAME'
*    EXPORTING
*      program_name  = syst-cprog
*      dynpro_number = syst-dynnr
*      field_name    = 'P_FILE'
*    IMPORTING
*      file_name     = p_file.

START-OF-SELECTION.
*  PERFORM background_job_validation.
*  PERFORM read_file_frm_remote.
  PERFORM upload.
* PERFORM clubdata.
* PERFORM fetch.
* PERFORM bdc.

*&---------------------------------------------------------------------*
*&      Form  UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM  upload .


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low
*        INTO wrk_file1
*        FROM tvarvc
*        WHERE name = c_tvarvc_name .

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = C_TVARVC_NAME
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


  SELECT SINGLE low
      INTO wrk_file2
      FROM tvarvc
      WHERE name = c_tvarvc_name1 .



  CALL FUNCTION 'EPS_GET_DIRECTORY_LISTING '
    EXPORTING
*     dir_name     = '/usr/sap/trans/' "p_dirnam "'/usr/sap/trans/RTGS'
*     dir_name     = '\\SAPDEV\sapmnt\trans\hsbcpmt\inward'
      dir_name     = wrk_file1
      file_mask    = '*.*'
    TABLES
      dir_list     = t_file_list
    EXCEPTIONS
      access_error = 1
      OTHERS       = 2.
  IF sy-subrc IS INITIAL.
    LOOP AT t_file_list .
      t_files-appsrv_fname = t_file_list-name.
      APPEND t_files.
      CLEAR  t_files.
    ENDLOOP.
  ENDIF.

  IF t_files[] IS INITIAL.
    MESSAGE 'Files not found !!!!' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.

  DATA:lv_string TYPE string.
*  DATA:lv_string TYPE char255.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE name,LOW    "ADDED BY RAJ ON 03.06.2024
*      FROM tvarvc
*      INTO @DATA(LV_TEXT)
*      WHERE name = 'ZFI_FILE_TEXT'
*        AND type = 'P'.

SELECT NAME , LOW
 FROM TVARVC INTO @DATA(LV_TEXT) UP TO 1 ROWS WHERE NAME = 'ZFI_FILE_TEXT' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix



  LOOP AT t_files.


    FIND LV_TEXT-low IN t_files.  "Added by Raj on 03.06.2024******** "it will check wheather that Text is contains in file or not
    IF SY-SUBRC NE 0.             "Added by Raj on 03.06.2024******** "if file name has this text then it will be skipped
    REFRESH: it_bsak,it_bsak1,it_bank1.
    CLEAR: lv_count.

*    CONCATENATE  wrk_file1 '\' t_files-appsrv_fname INTO lv_filename1.
    CONCATENATE  wrk_file1  t_files-appsrv_fname INTO lv_filename1.
    CONDENSE: lv_filename1.
    OPEN DATASET  lv_filename1 FOR INPUT IN TEXT MODE ENCODING DEFAULT.
    IF sy-subrc NE 0.
      MESSAGE e000 WITH 'File not readable'.
    ELSE.

      DO.
        CLEAR: lv_string.

        READ DATASET  lv_filename1 INTO lv_string .
        IF sy-subrc NE 0.
          EXIT.
        ELSE.
          SPLIT lv_string AT ',' INTO  wa_bank1-a
                                          wa_bank1-b
                                          wa_bank1-c
                                          wa_bank1-d
                                          wa_bank1-e
                                          wa_bank1-f
                                          wa_bank1-g
                                          wa_bank1-h
                                          wa_bank1-i
                                          wa_bank1-j
                                          wa_bank1-k
                                          wa_bank1-l
                                          wa_bank1-m
                                          wa_bank1-n
                                          wa_bank1-o
                                          wa_bank1-p
                                          wa_bank1-q
                                          wa_bank1-r
                                          wa_bank1-s
                                          wa_bank1-t
                                          wa_bank1-u
                                          wa_bank1-v
                                          wa_bank1-w
                                          wa_bank1-x
                                          wa_bank1-y
                                          wa_bank1-z
                                          wa_bank1-aa  .

          APPEND wa_bank1 TO it_bank1.

          CLEAR wa_bank1.
        ENDIF.
      ENDDO.
      CLOSE DATASET  lv_filename1.
    ENDIF.

    PERFORM clubdata.
    PERFORM fetch.
    PERFORM bdc.
    PERFORM movefile.
      ENDIF."Added by Raj on 03.06.2024**********************************

  ENDLOOP.

*  BREAK-POINT.

*  filename = p_file.
*
*  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
*    EXPORTING
*      i_field_seperator    = 'X'
*      i_line_header        = 'X'
*      i_tab_raw_data       = it_raw
*      i_filename           = p_file
*    TABLES
*      i_tab_converted_data = it_bank.


*  DATA:v_char(20),
*       v_char1(20).
*
*  DELETE it_bank WHERE type EQ 'TFR+'.
*
*  LOOP AT it_bank INTO wa_bank.
*
**    wa_bsak-date  = wa_bank-date .
*    wa_bsak-gjahr  = wa_bank-gjahr .
*    wa_bsak-bukrs = wa_bank-bukrs.
*    wa_bsak-lifnr = wa_bank-lifnr.
*    wa_bsak-zuonr = wa_bank-iden.
*    wa_bsak-dmbtr = wa_bank-value.
*
*    IF wa_bank-text2 CP '*HSBC*'.
*      SPLIT wa_bank-text2 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text3 CP '*HSBC*'.
*      SPLIT wa_bank-text3 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text4 CP '*HSBC*'.
*      SPLIT wa_bank-text4 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text5 CP '*HSBC*'.
*      SPLIT wa_bank-text5 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text6 CP '*HSBC*'.
*      SPLIT wa_bank-text6 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text7 CP '*HSBC*'.
*      SPLIT wa_bank-text7 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text8 CP '*HSBC*'.
*      SPLIT wa_bank-text8 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text9 CP '*HSBC*'.
*      SPLIT wa_bank-text9 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*    IF wa_bank-text10 CP '*HSBC*'.
*      SPLIT wa_bank-text10 AT 'HSBC' INTO v_char v_char1.
*    ENDIF.
*
*    SHIFT v_char1 LEFT DELETING LEADING 'N'.
*    SHIFT v_char1 LEFT DELETING LEADING 'R'.
*
**    IF v_char1 IS NOT INITIAL.
**      CONCATENATE 'HSBC' v_char1 INTO wa_bsak-ref.
**    ENDIF.
*
*    wa_bsak-ref = v_char1.
*
*    APPEND wa_bsak TO it_bsak.
*  ENDLOOP.

ENDFORM.                    " UPLOAD
*&---------------------------------------------------------------------*
*&      Form  FETCH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fetch .

  IF it_bsak IS NOT INITIAL.

    SELECT bukrs lifnr zuonr gjahr belnr buzei xblnr dmbtr budat umskz  FROM bsak
                                                     INTO TABLE it_bsak1
                                                     FOR ALL ENTRIES IN it_bsak
                                                     WHERE bukrs = it_bsak-bukrs
                                                     AND lifnr = it_bsak-lifnr
                                                     AND zuonr = it_bsak-zuonr
*                                                     AND gjahr = it_bsak-gjahr.
                                                     AND budat = it_bsak-budat.

    SELECT bukrs lifnr zuonr gjahr belnr buzei xblnr dmbtr budat umskz  FROM bsik
                                                    APPENDING TABLE it_bsak1
                                                     FOR ALL ENTRIES IN it_bsak
                                                     WHERE bukrs = it_bsak-bukrs
                                                     AND lifnr = it_bsak-lifnr
                                                     AND zuonr = it_bsak-zuonr
*                                                     AND gjahr = it_bsak-gjahr.
                                                     AND budat = it_bsak-budat.
****************************************************************************************Added by Raj on 04.03.2023************
    IF it_bsak1 IS NOT INITIAL.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*       SELECT bukrs belnr gjahr buzei zuonr FROM bseg INTO TABLE it_bseg
*                                                      FOR ALL ENTRIES IN it_bsak1
*                                                      WHERE bukrs = it_bsak1-bukrs
*                                                      AND gjahr = it_bsak1-gjahr
*                                                     AND belnr = it_bsak1-belnr
*                                                      AND koart = 'S'.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*SELECT bukrs belnr gjahr buzei zuonr FROM bseg INTO TABLE it_bseg
*                                                      FOR ALL ENTRIES IN it_bsak1
*                                                      WHERE bukrs = it_bsak1-bukrs
*                                                      AND gjahr = it_bsak1-gjahr
*                                                     AND belnr = it_bsak1-belnr
*                                                      AND koart = 'S' ORDER BY PRIMARY KEY .
 SELECT  COMPANYCODE AS BUKRS , ACCOUNTINGDOCUMENT AS BELNR ,
FISCALYEAR AS GJAHR , ACCOUNTINGDOCUMENTITEM AS BUZEI ,
ASSIGNMENTREFERENCE AS ZUONR FROM I_OPERATIONALACCTGDOCITEM INTO TABLE
@IT_BSEG  FOR  ALL  ENTRIES  IN  @IT_BSAK1  WHERE COMPANYCODE =
@IT_BSAK1-BUKRS AND FISCALYEAR = @IT_BSAK1-GJAHR AND ACCOUNTINGDOCUMENT
= @IT_BSAK1-BELNR AND FINANCIALACCOUNTTYPE = 'S' ORDER BY PRIMARY KEY.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

* End of Quick Fix

      ENDIF.
****************************************************************************************Added by Raj on 04.03.2023*************

  ENDIF.
ENDFORM.                    " FETCH
*&---------------------------------------------------------------------*
*&      Form  BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc .

  LOOP AT it_bsak1 INTO wa_bsak1.
    WAIT UP TO 3 SECONDS.

    REFRESH:it_bdc.
    CLEAR: wa_bsak.

    READ TABLE it_bsak INTO wa_bsak WITH KEY bukrs = wa_bsak1-bukrs
                                             lifnr = wa_bsak1-lifnr
                                             zuonr = wa_bsak1-zuonr
*                                             gjahr = wa_bsak1-gjahr.
                                             budat  = wa_bsak1-budat.

    IF sy-subrc EQ 0.


      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RF05L-BUZEI'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RF05L-BELNR'
                                    wa_bsak1-belnr.
      PERFORM bdc_field       USING 'RF05L-BUKRS'
                                     wa_bsak1-bukrs.
      PERFORM bdc_field       USING 'RF05L-GJAHR'
                                    wa_bsak1-gjahr.
      PERFORM bdc_field       USING 'RF05L-BUZEI' "line item comment
                                    wa_bsak1-buzei.
      PERFORM bdc_field       USING 'RF05L-XKKRE'
                                    'X'.
      IF wa_bsak1-umskz IS INITIAL.
        PERFORM bdc_dynpro      USING 'SAPMF05L' '0302'.
      ELSE.
        PERFORM bdc_dynpro      USING 'SAPMF05L' '0304'.
      ENDIF.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'BSEG-ZUONR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=AE'.
      PERFORM bdc_field       USING 'BSEG-ZUONR'
                                    wa_bsak-ref.
**      ************** Added changes on 25.02.2020 by Carina Jose
*      perform bdc_field       using 'DKACB-FMORE'
*                              'X'.
      PERFORM bdc_dynpro      USING 'SAPLKACB' '0002'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                              'COBL-PRCTR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                              '=ENTE'.
************* End of changes on 25.02.2020 by Carina Jose
*
*      PERFORM bdc_transaction USING 'FB09'.
    ENDIF.
    CALL TRANSACTION 'FB09' USING it_bdc MODE p_mode UPDATE 'E'  MESSAGES INTO it_msg.
  ENDLOOP.

********************************************************************************************Added by Raj on 04.05.2023*******************
*  IF it_bseg IS NOT INITIAL.
*    LOOP AT it_bseg INTO wa_bseg.
*      WAIT UP TO 3 SECONDS.
*
*      REFRESH:it_bdc.
*      CLEAR: wa_bsak.
*
*      IF sy-subrc EQ 0.
*
*
*        PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
*        PERFORM bdc_field       USING 'BDC_CURSOR'
*                                      'RF05L-BUZEI'.
*        PERFORM bdc_field       USING 'BDC_OKCODE'
*                                      '/00'.
*        PERFORM bdc_field       USING 'RF05L-BELNR'
*                                      wa_bseg-belnr."Document no
*        PERFORM bdc_field       USING 'RF05L-BUKRS'
*                                      wa_bseg-bukrs."Company code
*        PERFORM bdc_field       USING 'RF05L-GJAHR'
*                                       wa_bseg-gjahr."Fiscal Year
*        PERFORM bdc_field       USING 'RF05L-BUZEI' "line item comment
*                                       wa_bseg-buzei.
*        PERFORM bdc_field       USING 'RF05L-XKKRE'
*                                      'X'.
*        IF wa_bsak1-umskz IS INITIAL.
*          PERFORM bdc_dynpro      USING 'SAPMF05L' '0302'.
*        ELSE.
*          PERFORM bdc_dynpro      USING 'SAPMF05L' '0304'.
*        ENDIF.
*        PERFORM bdc_field       USING 'BDCd_CURSOR'
*                                      'BSEG-ZUONR'.
*        PERFORM bdc_field       USING 'BDC_OKCODE'
*                                      '=AE'.
*        PERFORM bdc_field       USING 'BSEG-ZUONR'
*                                       wa_bseg-zuonr."Assignment Field
*
*        PERFORM bdc_dynpro      USING 'SAPLKACB' '0002'.
*        PERFORM bdc_field       USING 'BDC_CURSOR'
*                                'COBL-PRCTR'.
*        PERFORM bdc_field       USING 'BDC_OKCODE'
*                                '=ENTE'.
*      ENDIF.
*      CALL TRANSACTION 'FB09' USING it_bdc MODE p_mode UPDATE 'E'  MESSAGES INTO it_msg.
*    ENDLOOP.
*  ENDIF.
*********************************************************************************************Added by Raj on 04.05.2023*******************

  WAIT UP TO 3 SECONDS.
*  LOOP AT it_bsak1 INTO wa_bsak1.
********************************************Added by Raj on 06.06.2024******************
   SELECT bukrs,zuonr,gjahr,belnr   FROM bsak  INTO TABLE @data(it_bsak_gl)
                                                   FOR ALL ENTRIES IN @it_bseg
                                                    WHERE bukrs = @it_bseg-bukrs
                                                   AND gjahr = @it_bseg-gjahr
                                                   AND belnr = @it_bseg-belnr.


  SELECT bukrs,zuonr,gjahr,belnr   FROM bsik   APPENDING TABLE @it_bsak_gl
                                                  FOR ALL ENTRIES IN @it_bseg
                                                  WHERE bukrs = @it_bseg-bukrs
                                                  AND gjahr = @it_bseg-gjahr
                                                  AND belnr = @it_bseg-belnr.



******************************Added by Raj on 06.06.2024***********************************

  IF it_bseg IS NOT INITIAL.
    clear : wa_bseg.
    LOOP AT it_bseg INTO wa_bseg.

REFRESH:it_bdc.
*    CLEAR: wa_bseg."Commented by Raj on 05.06.2024
WAIT UP TO 2 SECONDS.

      REFRESH:it_bdc.

      READ TABLE it_bsak_gl INTO data(wa_bsak_gl) WITH KEY  bukrs = wa_bseg-bukrs gjahr = wa_bseg-gjahr
                                                       belnr = wa_bseg-belnr.

    IF sy-subrc = 0.

      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RF05L-XKSAK'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RF05L-BELNR'
                                    wa_bseg-belnr.
      PERFORM bdc_field       USING 'RF05L-BUKRS'
                                    wa_bseg-bukrs.
      PERFORM bdc_field       USING 'RF05L-GJAHR'
                                    wa_bseg-gjahr.
      PERFORM bdc_field       USING 'RF05L-BUZEI'
                                    wa_bseg-BUZEI. "''.
      PERFORM bdc_field       USING 'RF05L-XKSAK'
                                    'X'.
      PERFORM bdc_dynpro      USING 'SAPMF05L' '0300'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'BSEG-ZUONR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=AE'.
      PERFORM bdc_field       USING 'BSEG-ZUONR'
                                    wa_bsak_gl-zuonr.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=AE'.
**      ************** Added changes on 25.02.2020 by Carina Jose
*      perform bdc_field       using 'DKACB-FMORE'
*                              'X'.
      PERFORM bdc_dynpro      USING 'SAPLKACB' '0002'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                              'COBL-PRCTR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                              '=ENTE'.
************* End of changes on 25.02.2020 by Carina Jose
*


*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'RF05L-BELNR'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
*      PERFORM bdc_field       USING 'RF05L-BELNR'
*                                    wa_bsak1-belnr.       "'2000000033'.
*      PERFORM bdc_field       USING 'RF05L-BUKRS'
*                                    wa_bsak1-bukrs.      "'1000'.
*      PERFORM bdc_field       USING 'RF05L-GJAHR'
*                                    wa_bsak1-gjahr.      "'2016'.
*      PERFORM bdc_field       USING 'RF05L-BUZEI'
*                                    wa_bsak1-buzei.      "'1'.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0302'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'BSEG-ZUONR'.
*      PERFORM bdc_field       USING 'BSEG-ZUONR'
*                                    wa_bsak-ref.            "'13073'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '=AE'.
*
    ENDIF.

    CALL TRANSACTION 'FB09' USING it_bdc MODE p_mode UPDATE 'E' MESSAGES INTO it_msg.

****Addded changes for GL account by Carina Jose on 03.07.2019
*    IF sy-subrc EQ 0.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0102'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'RF05L-XKSAK'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
*      PERFORM bdc_field       USING 'RF05L-BELNR'
*                                    wa_bsak1-belnr.
*      PERFORM bdc_field       USING 'RF05L-BUKRS'
*                                    wa_bsak1-bukrs.
*      PERFORM bdc_field       USING 'RF05L-GJAHR'
*                                    wa_bsak1-gjahr.
*      PERFORM bdc_field       USING 'RF05L-BUZEI'
*                                    ' '.
*      PERFORM bdc_field       USING 'RF05L-XKSAK'   "============================
*                                    'X'.
*      PERFORM bdc_dynpro      USING 'SAPMF05L' '0300'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'BSEG-ZUONR'.
**      PERFORM bdc_field       USING 'BDC_OKCODE'
**                                    '=AE'.
*      PERFORM bdc_field       USING 'BSEG-ZUONR'
*                                    wa_bsak-ref.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '=AE'.
*    ENDIF.
*    CALL TRANSACTION 'FB09' USING it_bdc MODE 'A' UPDATE 'S'.
****End of changes by Carina Jose on 03.07.2019
   clear : wa_bsak_gl,wa_bseg."Added by Raj on 05.06.2024
  ENDLOOP.
 endif.

ENDFORM.                    " BDC


FORM bdc_dynpro USING program screen.

  wa_bdc-program = program.
  wa_bdc-dynpro = screen.
  wa_bdc-dynbegin = 'X'.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.

ENDFORM.

FORM bdc_field USING field value.

  wa_bdc-fnam = field.
  wa_bdc-fval = value.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  MOVEFILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM movefile .
  DATA:  lv_tpath  LIKE sapb-sappfad.

  DATA : lv_lines TYPE char4.
*Begin of comment by JKT on 09.04.2020
*    CONCATENATE '/usr/sap/trans/archfile/' t_files-appsrv_fname INTO lv_tpath.
*End of commnet by JKT on 09.04.2020
*Added by JKT on 09.04.2020
  DESCRIBE TABLE it_bsak1 LINES lv_lines.

*  IF  lv_lines EQ lv_count .


*  CONCATENATE  wrk_file2 t_files-appsrv_fname INTO lv_tpath.
**--DELETE FILE ON THE APPLICATION SERVER AFTER DOWNLOAD
*  CALL FUNCTION 'ARCHIVFILE_SERVER_TO_SERVER'
*    EXPORTING
*      sourcepath       = lv_filename1
**     sourcepath       = t_files-appsrv_fname
*      targetpath       = lv_tpath
*    EXCEPTIONS
*      error_file       = 1
*      no_authorization = 2
*      OTHERS           = 3.
*  IF sy-subrc <> 0.
*
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**      WRITE :  50  'NO' COLOR 7.
*  ELSE.
**      WRITE :  50  'YES' COLOR 5.
*  ENDIF.

  DELETE DATASET lv_filename1.
*  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BACKGROUND_JOB_VALIDATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM background_job_validation .
  IF sy-batch = 'X'.
*
    SELECT COUNT(*) FROM tbtcp INTO @DATA(lv_count)
              WHERE progname EQ @sy-repid
              AND status EQ 'R'
              AND variant = @sy-slset.
    IF lv_count > 1.
      MESSAGE 'Another background job is already in process with the same variant'(001) TYPE 'E'.
    ENDIF.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  READ_FILE_FRM_REMOTE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM read_file_frm_remote .
  DATA:lv_cmd    TYPE sxpgcolist-name VALUE 'ZPAYMENT',
       lv_status TYPE extcmdexex-status,
       lv_code   TYPE extcmdexex-exitcode.

  DATA: t_result         TYPE STANDARD TABLE OF btcxpm.

  CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
    EXPORTING
      commandname                   = lv_cmd
*     ADDITIONAL_PARAMETERS         = lv_parm
*     OPERATINGSYSTEM               = SY-OPSYS
*     TARGETSYSTEM                  = SY-HOST
*     DESTINATION                   =
*     STDOUT                        = 'X'
*     STDERR                        = 'X'
*     TERMINATIONWAIT               = 'X'
*     TRACE                         =
*     DIALOG                        =
    IMPORTING
      status                        = lv_status
      exitcode                      = lv_code
    TABLES
      exec_protocol                 = t_result
    EXCEPTIONS
      no_permission                 = 1
      command_not_found             = 2
      parameters_too_long           = 3
      security_risk                 = 4
      wrong_check_call_interface    = 5
      program_start_error           = 6
      program_termination_error     = 7
      x_error                       = 8
      parameter_expected            = 9
      too_many_parameters           = 10
      illegal_command               = 11
      wrong_asynchronous_parameters = 12
      cant_enq_tbtco_entry          = 13
      jobcount_generation_error     = 14
      OTHERS                        = 15.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
     WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CLUBDATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM clubdata .
  DATA:  lv_len TYPE i.
  DATA:  lv_len1 TYPE i.
  DATA:  lv_len2 TYPE i.
  DATA:v_char(20),
       v_char1(20).
  DATA: utr TYPE string.
  DELETE it_bank1 INDEX 1.
  REFRESH : it_bank2,it_bank3.
  it_bank2[] = it_bank1[].
  LOOP AT it_bank2 INTO wa_bank2.
    IF NOT wa_bank2-s IS INITIAL.
      SHIFT wa_bank2-s LEFT DELETING LEADING '"'.
      SHIFT wa_bank2-s RIGHT DELETING TRAILING '"'.

      IF NOT wa_bank2-s IS INITIAL.
        CONDENSE wa_bank2-s.
        CONCATENATE '"' wa_bank2-s '"' INTO utr.
        CLEAR: wa_bank2-s.
        wa_bank2-s = utr.
        MOVE-CORRESPONDING wa_bank2 TO wa_bank3.
        APPEND wa_bank3 TO it_bank3.
        CLEAR:utr.
      ENDIF.
      CLEAR: wa_bank2-s.
    ENDIF.
  ENDLOOP.

  REFRESH: it_bank1.
  it_bank1[] = it_bank3[].
  LOOP AT it_bank1 INTO wa_bank1.

    IF NOT wa_bank1-t  IS INITIAL.
      lv_len = strlen( wa_bank1-t ).
      lv_len = lv_len - 1 .
      wa_bsak-tbudat  = wa_bank1-t+1(lv_len).
      REPLACE ALL OCCURRENCES OF '-' IN wa_bsak-tbudat WITH ''.
      CONDENSE wa_bsak-tbudat.
      wa_bsak-budat = wa_bsak-tbudat.
      CLEAR :lv_len.
    ENDIF.

    IF NOT wa_bank1-s  IS INITIAL.
      lv_len = strlen( wa_bank1-s ).
      lv_len1 = lv_len.
*      lv_len = lv_len - 14 .
*      wa_bsak-bukrs  = wa_bank1-s+1(lv_len).
      wa_bsak-bukrs  = wa_bank1-s+1(4).
      SHIFT wa_bsak-bukrs LEFT DELETING LEADING '"'.
      CLEAR :lv_len.
    ENDIF.

    IF NOT wa_bank1-s  IS INITIAL.
      lv_len = strlen( wa_bank1-s ).
      lv_len = lv_len - 6.
      lv_len2 = lv_len.
      wa_bsak-zuonr  = wa_bank1-s+lv_len(5).

      CLEAR :lv_len.
    ENDIF.

    IF NOT wa_bank1-s  IS INITIAL.
*      lv_len = strlen( wa_bank1-s ).
*      lv_len = lv_len - 11 .
*      wa_bsak-lifnr  = wa_bank1-s+5(lv_len).

      lv_len = lv_len1 - lv_len2.

      lv_len = lv_len2 - 5.
      if lv_len > 0.
      wa_bsak-lifnr  = wa_bank1-s+5(lv_len).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = wa_bsak-lifnr
        IMPORTING
          output = wa_bsak-lifnr.
      endif.
      CLEAR :lv_len.
    ENDIF.



    IF NOT wa_bank1-k  IS INITIAL.
      SHIFT wa_bank1-k LEFT DELETING LEADING '"'.
      SHIFT wa_bank1-k RIGHT DELETING TRAILING '"'.
      wa_bsak-dmbtr = wa_bank1-k.
    ENDIF.

    IF wa_bank1-m CP '*HSBC*'.
      SHIFT wa_bank1-m RIGHT DELETING TRAILING '"'.
      SPLIT wa_bank1-m AT 'HSBC' INTO v_char v_char1.
    ELSE.
      SHIFT wa_bank1-m RIGHT DELETING TRAILING '"'.
      SPLIT wa_bank1-m AT '"' INTO v_char v_char1.
*      v_char1 = wa_bank1-m.

    ENDIF.
*    SHIFT v_char1 LEFT DELETING LEADING 'N'.
*    SHIFT v_char1 LEFT DELETING LEADING 'R'.
*    SHIFT v_char1 RIGHT DELETING TRAILING '"'.


    wa_bsak-ref = v_char1.
    lv_count  = lv_count + 1 .


    APPEND wa_bsak TO it_bsak.
*   endif.
    CLEAR: wa_bsak,v_char1,v_char.

  ENDLOOP.
ENDFORM.
