FUNCTION-POOL ZFI_GST_SPLIT              MESSAGE-ID SV.

* INCLUDE LZFI_GST_SPLITD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GST_SPLITT00                       . "view rel. data dcl.
