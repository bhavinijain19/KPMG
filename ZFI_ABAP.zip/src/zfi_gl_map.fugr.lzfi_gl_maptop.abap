FUNCTION-POOL ZFI_GL_MAP                 MESSAGE-ID SV.

* INCLUDE LZFI_GL_MAPD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GL_MAPT00                          . "view rel. data dcl.
