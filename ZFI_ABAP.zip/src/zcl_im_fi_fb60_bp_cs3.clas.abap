class ZCL_IM_FI_FB60_BP_CS3 definition
  public
  final
  create public .

public section.

  interfaces IF_EX_FAGL_SET_SEGMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_FI_FB60_BP_CS3 IMPLEMENTATION.


  METHOD if_ex_fagl_set_segment~change_segment_psegment.

    TYPES: BEGIN OF ty_tvarvc1,
             sign TYPE tvarv_sign,
             opti TYPE tvarv_opti,
             low  TYPE tvarv_val,
             high TYPE tvarv_val,
           END OF ty_tvarvc1.

    DATA : it_tcodes  TYPE STANDARD TABLE OF ty_tvarvc1,
           wa_tcodes  TYPE ty_tvarvc1,
           it_tcodes1 TYPE STANDARD TABLE OF ty_tvarvc1,
           wa_tcodes1 TYPE ty_tvarvc1,
           it_park    TYPE STANDARD TABLE OF ty_tvarvc1,   "Added by Raj on 29.03.2024
           wa_park    TYPE ty_tvarvc1,                      "Added by Raj on 29.03.2024
           it_post    TYPE STANDARD TABLE OF ty_tvarvc1,     "Added by Raj on 29.03.2024
           wa_post    TYPE ty_tvarvc1.                        "Added by Raj on 29.03.2024
    DATA : lr_tcode TYPE TABLE OF ty_tvarvc1,     "Added by Rahul Vasita on 09.04.2024 15:07:22
           ls_tcode TYPE ty_tvarvc1.              "Added by Rahul Vasita on 09.04.2024 15:07:26
    DATA : wa_valid TYPE accit,
           lv_lifnr TYPE ekko-lifnr,
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*           lv_panno TYPE j_1imovend-j_1ipanno,
           lv_panno TYPE j_1ipanno,
******************end of ATC changes 13/02/26   UDAYABAP03*************
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*           it_vend  TYPE STANDARD TABLE OF j_1imovend,
*           wa_vend  TYPE j_1imovend,
           it_vend  TYPE STANDARD TABLE OF lfa1,
           wa_vend  TYPE lfa1,
******************End of ATC changes 13/02/26   UDAYABAP03*************
           it_bsip  TYPE STANDARD TABLE OF bsip,
           wa_bsip  TYPE bsip,
           it_bsip1 TYPE STANDARD TABLE OF bsip,
           wa_bsip1 TYPE bsip,
           lv_msg   TYPE c LENGTH 250,
           it_bkpf  TYPE STANDARD TABLE OF bkpf, "Added by Raj on 19.09.2023
           wa_bkpf  TYPE bkpf. "Added by Raj on 19.09.2023

    DATA : lv_bstat  TYPE bkpf-bstat.
    DATA : lv_tcode  TYPE bkpf-tcode.
    DATA : lv_awkey  TYPE bkpf-awkey.
    DATA : lv_belnr  TYPE rbkp-belnr.
    DATA : lv_region TYPE csks-regio.
    DATA : lv_kostl  TYPE ekkn-kostl.
    DATA : lv_werks  TYPE t001w-werks.
    DATA : lv_bupla TYPE bseg-bupla.
    DATA : lv_bupla1 TYPE bseg-bupla.
    DATA : lv_bupla_region TYPE csks-regio.
    DATA : lv_adrnr TYPE adrnr.
    DATA : lv_prctr TYPE bseg-prctr.
    DATA : it_accit TYPE TABLE OF accit,
           wa_accit TYPE accit.
******    Added changes by Carina Jose on 10.04.2020
    DATA : it_accit1 TYPE TABLE OF accit,
           wa_accit1 TYPE accit.
    TYPES : BEGIN OF ty_tcjpos,
              comp_code       TYPE tcj_positions-comp_code,
              cajo_number     TYPE tcj_positions-cajo_number,
              fisc_year       TYPE tcj_positions-fisc_year,
              posting_number  TYPE tcj_positions-posting_number,
              position_number TYPE tcj_positions-position_number,
              transact_number TYPE tcj_positions-transact_number,
              customer        TYPE  tcj_positions-customer,
              posting_date    TYPE tcj_positions-posting_date,
              p_receipts      TYPE tcj_positions-p_receipts,
              document_status TYPE tcj_documents-document_status,
            END OF ty_tcjpos.
    DATA : it_tcjpos TYPE STANDARD TABLE OF ty_tcjpos,
           wa_tcjpos TYPE ty_tcjpos.
    DATA : v_sump  TYPE maxbt.
    DATA : v_sums  TYPE maxbt.
    DATA : v_sum  TYPE maxbt.
    DATA : v_totamount(10).
*    DATA : it_kna1 TYPE STANDARD TABLE OF kna1,
*           wa_kna1 TYPE kna1.
*    data : it_bkpf type STANDARD TABLE OF
    CONSTANTS: c_tvarvc_name TYPE rvari_vnam VALUE 'ZSD_FBCJ_AMOUNT'.

***********Commented and Added by Raj on 01.09.2023************************************
*    CONSTANTS: c_tcodes  TYPE rvari_vnam VALUE 'ZFI_TCODES',
*               c_tcodes1 TYPE rvari_vnam VALUE 'ZMM_TCODES'.
    CONSTANTS: c_tcodes TYPE rvari_vnam VALUE 'ZFIMM_TCODES'.

    CONSTANTS: c_park TYPE rvari_vnam VALUE 'ZTCODES_PARK'.
    CONSTANTS: c_post TYPE rvari_vnam VALUE 'ZTCODES_POST'.

* ***********Commented and Added by Raj on 01.09.2023************************************
******    End of changes by Carina Jose on 10.04.2020
    DATA: v_receipts TYPE tcj_documents-h_receipts.

    CLEAR: it_tcodes[].
    SELECT sign opti low high
        INTO CORRESPONDING FIELDS OF TABLE it_tcodes
        FROM tvarvc
        WHERE  name  = c_tcodes.


******Begin of changes****Added by Raj on 14.02.2024*****************
    TYPES : BEGIN OF ty_bp,
              werks TYPE t001w-werks,
              bukrs TYPE t001-bukrs,
              bupla TYPE bseg-bupla,
              bwkey TYPE t001w-bwkey,
              land1 TYPE t001w-land1,
            END OF ty_bp.

    DATA : it_tab TYPE STANDARD TABLE OF ty_bp,
           wa_tab TYPE ty_bp.
    DATA : lv_bsp TYPE bseg-bupla.
    DATA : lv_plant TYPE t001w-werks.
    DATA : lv_blart TYPE rbkp-blart.
    DATA : lv_bs TYPE char4."Profit center 4 digits local variable
    DATA : lv_msg1 TYPE string.
**End of changes****Added by Raj on 14.02.2024**************

***************Begin of changes Added by Raj on 29.03.2024*************

    REFRESH :it_park,it_post.

    "Added by BP
    SELECT hkont FROM zfi_gl_check INTO TABLE @DATA(lt_gl)
      FOR ALL ENTRIES IN @ct_accit WHERE hkont = @ct_accit-hkont.

    IF sy-subrc = 0.
      SORT lt_gl BY hkont.
    ENDIF.
    "Ended by BP

    SELECT sign opti low high
           INTO CORRESPONDING FIELDS OF TABLE it_park
           FROM tvarvc
           WHERE  name  = c_park.

    SELECT sign opti low high
           INTO CORRESPONDING FIELDS OF TABLE it_post
           FROM tvarvc
           WHERE  name  = c_post.

***************End of changes Added by Raj on 29.03.2024*************

********Commented by Raj on 01.09.2023*************
*    CLEAR: it_tcodes1[].
*    SELECT sign opti low high
*        INTO CORRESPONDING FIELDS OF TABLE it_tcodes1
*        FROM tvarvc
*        WHERE  name  = c_tcodes1.
* **********Commented By Raj on 01.09.2023************

    it_accit = ct_accit.
*    if sy-tcode = 'VF01'.
*      LOOP AT it_accit INTO wa_accit WHERE HKONT = '0060010305'.
*        WA_ACCIT-ZUONR = 'FRIGHT'.
*        MODIFY IT_ACCIT FROM WA_ACCIT TRANSPORTING ZUONR.
*     ENDLOOP.
*   ENDIF.
*
*  ct_accit[] = it_accit[].

******************begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_fullswitch) WHERE name = 'ZFI_MM_SWITCH' AND type = 'P'."Added By Raj Kumar on 28.10.2024
    SELECT name , low FROM tvarvc INTO @DATA(ls_fullswitch) UP TO 1 ROWS WHERE name = 'ZFI_MM_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY. ENDSELECT."Added By Raj Kumar on 28.10.2024
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF ls_fullswitch-low = 'X'.

* ***************Begin of changes Added by Raj on 12.02.2024*********
      REFRESH : it_tab.
      CLEAR : lv_plant.



      LOOP AT it_accit INTO wa_accit.
        IF wa_accit-blart IS NOT INITIAL.
          IF wa_accit-blart = 'RK'.
            lv_blart = wa_accit-blart.
            EXIT.
          ENDIF.
        ENDIF.
        CLEAR wa_accit.
      ENDLOOP.

*data : lv_kzmek type rseg-kzmek.
*select single  kzmek from rseg into lv_kzmek where ebeln = lv_zuonr.


*if lv_kzmek  is INITIAL.

      IF lv_blart <> 'RK'.



*    IF sy-tcode = 'MIR4' OR sy-tcode = 'MIR7'.

        READ TABLE it_park INTO wa_park WITH KEY low = sy-tcode. "Added by Raj on 29.03.2024

        IF sy-subrc = 0.

          IF it_accit IS NOT INITIAL.

            SELECT  a~werks b~bukrs a~j_1bbranch a~bwkey c~land1 INTO TABLE it_tab
               FROM t001k AS b INNER JOIN t001w AS a ON a~bwkey = b~bwkey
                    INNER JOIN t005 AS c ON c~land1 = a~land1
               FOR ALL ENTRIES IN it_accit WHERE a~bwkey = it_accit-bwkey AND a~werks = it_accit-werks.
          ENDIF.
*
**************Need to Get error Accordingly compare whole business place******************
          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-werks IS NOT INITIAL.
              lv_plant = wa_accit-werks.
              EXIT.
            ENDIF.
            CLEAR wa_accit.
          ENDLOOP.
          DELETE it_accit WHERE buzid = 'T'.  "Against this line items business place getting blank at that time for those line items
*******************************        start 25.12.2024
          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-xauto = 'X' AND wa_accit-werks IS INITIAL.
              DELETE TABLE it_accit FROM wa_accit.
            ENDIF.
          ENDLOOP.

*        DELETE it_accit WHERE xauto = 'X'.  "To over come diff issue " for change 25.12.2024
*      DELETE it_accit WHERE xskrl = 'X'.  "add by parth 13.03.2024
*      delete it_accit where GKOAR = 'K'.  "Added by Raj on 13.03.2024
          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-kstat NE 'X'. "Added by BP
              IF wa_accit-bupla IS NOT INITIAL.
                READ TABLE  it_tab INTO wa_tab WITH KEY werks =  lv_plant.
                IF wa_accit-bupla NE wa_tab-bupla.
                  READ TABLE lt_gl INTO DATA(ls_gl) WITH KEY hkont = wa_accit-hkont. "Added by BP
                  IF sy-subrc = 0.
                    MESSAGE e051(zmm)." DISPLAY LIKE 'E'.
*          RETURN .
                  ENDIF.
                ENDIF.
                CLEAR :wa_accit,wa_tab.
              ELSE.
                READ TABLE  it_tab INTO wa_tab WITH KEY werks =  lv_plant.
                IF wa_accit-prctr+4(4) NE wa_tab-werks.
                  MESSAGE e051(zmm)." DISPLAY LIKE 'E'.
*          RETURN .
                ENDIF.
                CLEAR :wa_accit,wa_tab.

              ENDIF.
            ENDIF.

          ENDLOOP.
* refresh it_accit.
        ENDIF.


*
*    IF sy-tcode = 'MIRO' OR sy-tcode = 'MIR4' OR sy-tcode = 'MIR7'." or sy-tcode = 'MIR4' OR sy-tcode = 'MIR7'.



        READ TABLE it_post INTO wa_post WITH KEY low = sy-tcode. "Added by Raj on 29.03.2024

        IF sy-subrc = 0.


          IF it_accit IS NOT INITIAL.

            SELECT  a~werks b~bukrs a~j_1bbranch a~bwkey c~land1 INTO TABLE it_tab
               FROM t001k AS b INNER JOIN t001w AS a ON a~bwkey = b~bwkey
                    INNER JOIN t005 AS c ON c~land1 = a~land1
               FOR ALL ENTRIES IN it_accit WHERE a~bwkey = it_accit-bwkey AND a~werks = it_accit-werks.

          ENDIF.

          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-werks IS NOT INITIAL.
              lv_plant = wa_accit-werks.
              EXIT.
            ENDIF.
            CLEAR wa_accit.
          ENDLOOP.


          DELETE it_accit WHERE buzid = 'T'.  "Against this line items business place getting blank
*******************************        comment by parth 25.12.2024
          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-xauto = 'X' AND wa_accit-werks IS INITIAL.
              DELETE TABLE it_accit FROM wa_accit.
            ENDIF.
          ENDLOOP.
*************************************       end by parth 25.12.2024

*        DELETE it_accit WHERE xauto = 'X'.  "To over come diff issue " comment by  parth25.12.2024
*      DELETE it_accit WHERE xskrl = 'X'.  "add by parth 13.03.2024
*      delete it_accit where GKOAR = 'K'.  "Added by Raj on 13.03.2024
          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-kstat NE 'X'.
              IF wa_accit-bupla IS NOT INITIAL.
                READ TABLE  it_tab INTO wa_tab WITH KEY werks =  lv_plant.
                IF wa_accit-bupla NE wa_tab-bupla.
                  READ TABLE lt_gl INTO ls_gl WITH KEY hkont = wa_accit-hkont. "Added by BP
                  IF sy-subrc = 0.
                    MESSAGE e051(zmm)." DISPLAY LIKE 'E'.
                  ENDIF.
                ENDIF.
*          RETURN .
                CLEAR :wa_accit,wa_tab.
              ELSE.
                READ TABLE  it_tab INTO wa_tab WITH KEY werks =  lv_plant.  "If business place is initial in runtime then that time it will take
                IF wa_accit-prctr+4(4) NE wa_tab-werks.                    "Compare plant and profit center will be check if these two are not same
                  MESSAGE e051(zmm)." DISPLAY LIKE 'E'.                    "System throughs an error message business place is not correct
*          RETURN .
                ENDIF.
                CLEAR :wa_accit,wa_tab.
              ENDIF.
            ENDIF.
          ENDLOOP.

        ENDIF.
*refresh :it_accit.
        CLEAR : lv_plant.
*endif.
******************End of changes added by Raj on 14.02.2024****
      ENDIF.

*************Begin of changes Added by Raj on 16.02.2024***************************  "Uncommented by Raj on 05.03.2024
      "Adding Start by Rahul Vasita on 09.04.2024 15:07:56 APLITSS00054
      SELECT name,
             low
        FROM tvarvc
        INTO TABLE @DATA(lt_tvarvc)
        WHERE name = 'ZFI_BUPLA_CHECK' AND type = 'S'.
      "Adding End by Rahul Vasita on 09.04.2024 15:07:56
      DATA(ls_tvarvc) = VALUE #( lt_tvarvc[ low = sy-tcode ] OPTIONAL ).
*    IF sy-tcode = 'FV60' OR   sy-tcode = 'FB60' OR sy-tcode = 'FV65' OR sy-tcode = 'FB65'. "OR sy-tcode = 'FBV0' OR sy-tcode = 'FBV3' OR sy-tcode = 'FBVB'." "Comment by Rahul Vasita on 09.04.2024 15:11:14
      IF ls_tvarvc IS NOT INITIAL.

        "Comment Start by Rahul Vasita on 09.04.2024 15:11:47
**      LOOP AT it_accit INTO wa_accit.
**        IF wa_accit-prctr IS NOT INITIAL.
**          lv_bsp = wa_accit-prctr+0(4).
**          EXIT.
**        ENDIF.
**        CLEAR wa_accit.
**      ENDLOOP.
        "Comment End by Rahul Vasita on 09.04.2024 15:11:47

        IF it_accit IS NOT INITIAL.

          LOOP AT it_accit INTO wa_accit.
            IF wa_accit-kstat NE 'X'.
              IF wa_accit-prctr IS NOT INITIAL.
                SELECT SINGLE a~werks b~bukrs a~j_1bbranch a~bwkey c~land1 INTO wa_tab
                FROM t001k AS b INNER JOIN t001w AS a ON a~bwkey = b~bwkey
                     INNER JOIN t005 AS c ON c~land1 = a~land1
                WHERE   a~werks = wa_accit-prctr+4(4).
                IF sy-subrc <> 0.
************************************Changes add by UDAYABAP03***************
                  DATA(lv_prct) = wa_accit-prctr.
                  SHIFT lv_prct LEFT DELETING LEADING '0'.
************************************Changes add by UDAYABAP03***************
*                SELECT SINGLE werks , bupla FROM zfi_bupla_con INTO @DATA(ls_bupla) WHERE werks = @wa_accit-prctr+0(4).
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE werks , bupla FROM zfi_bupla_con INTO @DATA(ls_bupla) WHERE werks = @lv_prct+0(4).
                  SELECT werks , bupla FROM zfi_bupla_con INTO @DATA(ls_bupla) UP TO 1 ROWS WHERE werks = @lv_prct+0(4) ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                  IF sy-subrc = 0.
                    IF wa_accit-bupla <> ls_bupla-bupla
                        AND wa_accit-bupla NE 'ISAL'. "ADDED BY BHAUMIK FOR UAT 02.06.26
                      READ TABLE lt_gl INTO ls_gl WITH KEY hkont = wa_accit-hkont. "Added by BP
                      IF sy-subrc = 0.
                        MESSAGE e051(zmm).
                      ENDIF.
                    ENDIF.
                  ELSE.
*                IF wa_accit-bupla <> wa_tab-bupla.
                    MESSAGE e051(zmm).
*                ENDIF.
                  ENDIF."End of LS_BUPLA
                ELSE.
                  IF wa_accit-bupla <> wa_tab-bupla.
                    MESSAGE e051(zmm).
                  ENDIF.
                ENDIF."End of WA_TAB
              ENDIF.
              CLEAR : wa_tab,wa_accit.
              CLEAR : ls_bupla. "Added by Rahul Vasita on 09.04.2024 15:21:35
*         if wa_accit-prctr is not INITIAL.
*          if wa_accit-prctr+0(1) <> lv_bsp+0(1).
*             MESSAGE e051(zmm).
*            endif.
*            ENDIF.
*            clear : wa_accit.
            ENDIF.
          ENDLOOP.

        ENDIF.

      ENDIF."End of Tcode

**    CLEAR : lv_bsp. "Comment by Rahul Vasita on 09.04.2024 15:12:16 not used any place already commented.
************End of changes Added by Raj on 16.02.2024******************************

      IF sy-tcode = 'FBA7'.
        LOOP AT it_accit INTO wa_accit.
          IF wa_accit-bupla IS NOT INITIAL AND wa_accit-prctr IS NOT INITIAL.

            lv_bupla = wa_accit-bupla.
            lv_prctr = wa_accit-prctr.
*        ELSE. Comment by parth 15/04/2019
            IF lv_bupla NE wa_accit-bupla.
              MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
            ELSE.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = lv_prctr.
              SELECT regio FROM cepc INTO lv_region UP TO 1 ROWS WHERE prctr = lv_prctr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT SINGLE regio FROM t001w INTO lv_region WHERE werks = lv_werks.

*              ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*              SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
              SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              ENDIF.
***********************
*            IF wa_accit-bupla(2) NE lv_region."comment by parth 13/04/2019
              IF lv_bupla_region NE lv_region."add by parth 13/04/2019
                MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
              ENDIF.
            ENDIF.
          ENDIF.

        ENDLOOP.
      ENDIF.

      " f-53, F-51
      IF sy-tcode = 'FBZ2'.
        LOOP AT it_accit INTO wa_accit.
          IF wa_accit-bupla IS NOT INITIAL AND wa_accit-prctr IS NOT INITIAL.
            lv_bupla = wa_accit-bupla.
            lv_werks = wa_accit-prctr(4).

*        IF wa_accit-werks IS NOT INITIAL.
*          lv_werks = wa_accit-werks.
*          IF lv_bupla NE wa_accit-bupla.
*            MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
*          ELSE.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = wa_accit-prctr.
            SELECT regio FROM cepc INTO lv_region UP TO 1 ROWS WHERE prctr = wa_accit-prctr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
*          SELECT SINGLE regio FROM t001w INTO lv_region WHERE werks = lv_werks.

*           ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*            SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
            SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
            IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
              SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
            ENDIF.
***********************

*          IF wa_accit-bupla(2) NE lv_region."comment by parth 13/04/2019
            IF lv_bupla_region NE lv_region."add by parth 13/04/2019
              MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
            ENDIF.
*          ENDIF.
*        ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.

      "FBCJ
      IF sy-tcode = 'FBCJ'.
        LOOP AT it_accit INTO wa_accit.
******  Added changes by Carina Jose on 10.04.2020
          MOVE-CORRESPONDING wa_accit TO wa_accit1.
          IF wa_accit1-kunnr IS NOT INITIAL.
            wa_accit1-pswbt = wa_accit1-pswbt * -1 .
            APPEND wa_accit1 TO it_accit1.
          ENDIF.

*        IF it_accit1 IS NOT INITIAL.
*          SELECT kunnr ktokd
*          INTO CORRESPONDING FIELDS OF TABLE it_kna1
*          FROM kna1
*          FOR ALL ENTRIES IN it_accit1
*          WHERE kunnr = it_accit1-kunnr AND
*              ktokd NE 'CPD'.
*        ENDIF.

          IF it_accit1 IS NOT INITIAL .
*        IF it_accit1 IS NOT INITIAL AND it_kna1 IS NOT INITIAL.  " for one time customer

************************Commented by Raj on 01.03.2024********************************************************
*          SELECT comp_code posting_number transact_number posting_date p_receipts customer
*          INTO CORRESPONDING FIELDS OF TABLE it_tcjpos
*          FROM tcj_positions
*          FOR ALL ENTRIES IN it_accit1
*          WHERE comp_code = it_accit1-bukrs AND
*                posting_date = it_accit1-budat AND
*                customer = it_accit1-kunnr.
*
*          SELECT tcjpos~comp_code tcjpos~cajo_number tcjpos~fisc_year tcjpos~posting_number tcjpos~position_number tcjpos~transact_number tcjpos~posting_date tcjpos~p_receipts tcjpos~customer
*          tcjdoc~document_status
*          INTO CORRESPONDING FIELDS OF TABLE it_tcjpos
*          FROM tcj_positions AS tcjpos INNER JOIN tcj_documents AS tcjdoc ON tcjpos~posting_number = tcjdoc~posting_number
*          FOR ALL ENTRIES IN it_accit1
*          WHERE tcjpos~comp_code = it_accit1-bukrs AND
*                tcjpos~transact_number EQ '  6' AND
*                tcjpos~posting_date = it_accit1-budat AND
*                tcjpos~customer = it_accit1-kunnr." AND tcjdoc~document_status IN ( 'S' )."or tcjdoc~document_status = 'S'.
************************Commented by Raj on 01.03.2024********************************************************

******************begin of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT SINGLE low
*            INTO v_totamount
*            FROM tvarvc
*            WHERE name = c_tvarvc_name .
            SELECT low
            INTO v_totamount UP TO 1 ROWS
            FROM tvarvc
            WHERE name = c_tvarvc_name ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
****************************************************Begin of changes Added by Raj on 01.03.2024**********************************
            IF it_accit1 IS NOT INITIAL.
              SELECT comp_code,cajo_number,fisc_year,posting_number,position_number,transact_number,posting_date,p_receipts,customer FROM tcj_positions
                INTO TABLE @DATA(it_pos) FOR ALL ENTRIES IN @it_accit1
                WHERE comp_code = @it_accit1-bukrs
                AND posting_date = @it_accit1-budat AND customer = @it_accit1-kunnr ."and ." AND transact_number = '6'
            ENDIF.

            IF it_pos IS NOT INITIAL.
              SELECT comp_code,cajo_number,fisc_year,posting_number,posting_date,document_status FROM tcj_documents
                INTO TABLE @DATA(it_doc) FOR ALL ENTRIES IN @it_pos
                WHERE comp_code = @it_pos-comp_code AND cajo_number = @it_pos-cajo_number AND fisc_year = @it_pos-fisc_year
                AND posting_number = @it_pos-posting_number ."and position_number = @it_pos-position_number.

            ENDIF.

            LOOP AT it_pos INTO DATA(wa_pos).
              READ TABLE it_doc INTO DATA(wa_doc) WITH KEY comp_code = wa_pos-comp_code cajo_number = wa_pos-cajo_number fisc_year = wa_pos-fisc_year  posting_number = wa_pos-posting_number.
              wa_tcjpos-comp_code     =  wa_pos-comp_code.
              wa_tcjpos-cajo_number  = wa_pos-cajo_number.
              wa_tcjpos-fisc_year    =  wa_pos-cajo_number.
              wa_tcjpos-position_number = wa_pos-position_number.
              wa_tcjpos-transact_number = wa_pos-transact_number.
              wa_tcjpos-customer        =  wa_pos-customer .
              wa_tcjpos-document_status = wa_doc-document_status.
              wa_tcjpos-p_receipts  = wa_pos-p_receipts.
              wa_tcjpos-posting_number = wa_pos-posting_number.
              APPEND wa_tcjpos  TO it_tcjpos.
              CLEAR : wa_pos,wa_tcjpos.
            ENDLOOP.
*
*
*


***********************End of changes Added by Raj on 01.03.2024**************************************************


          ENDIF.

          LOOP AT it_tcjpos INTO wa_tcjpos.
            IF wa_tcjpos-document_status EQ 'P' OR  wa_tcjpos-document_status EQ 'R'.
              v_sump = v_sump + wa_tcjpos-p_receipts.
              CLEAR : wa_tcjpos.
            ENDIF.
            READ TABLE it_accit1 INTO wa_accit1 WITH KEY awref = wa_tcjpos-posting_number.
            IF sy-subrc = 0.
              v_sums = v_sums + wa_tcjpos-p_receipts.
              CLEAR : wa_tcjpos.
            ENDIF.

          ENDLOOP.
          v_sum = v_sums + v_sump.

          IF v_sum > v_totamount.
*          MESSAGE 'Amount should not exceed more than 2,00,000.00' TYPE 'E'.
            MESSAGE e019(zfi) WITH wa_accit1-kunnr.
          ENDIF.

*****************************Logic for Direct posting Added by Raj on 01.03.2024***********************
*        IF it_tcjpos IS INITIAL.
          LOOP AT it_accit1 INTO wa_accit1.
            IF wa_accit1-kunnr IS NOT INITIAL AND wa_accit1-blart = 'CR' AND wa_accit1-koart = 'D'." and wa_accit1-
              IF wa_accit1-pswbt > v_totamount.
                MESSAGE e019(zfi) WITH wa_accit1-kunnr.
              ENDIF.
            ENDIF.
            CLEAR : wa_accit1.
          ENDLOOP.
*        ENDIF.

*****************************End of changes on 01.03.3

******  End of changes by Carina Jose on 10.04.2020
          IF wa_accit-belnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT SINGLE h_receipts FROM tcj_documents INTO v_receipts  WHERE comp_code = wa_accit-bukrs
*                                                                               AND fisc_year = wa_accit-gjahr
*                                                                               AND posting_number = wa_accit-belnr.
            SELECT h_receipts FROM tcj_documents INTO v_receipts UP TO 1 ROWS  WHERE comp_code = wa_accit-bukrs
                                                                               AND fisc_year = wa_accit-gjahr
                                                                               AND posting_number = wa_accit-belnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
          ENDIF.
          IF  v_receipts LE '0.00'.
            IF wa_accit-bupla IS NOT INITIAL AND wa_accit-prctr IS NOT INITIAL.
              lv_bupla = wa_accit-bupla.
              lv_werks = wa_accit-prctr(4).

******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = wa_accit-prctr.
              SELECT regio FROM cepc INTO lv_region UP TO 1 ROWS WHERE prctr = wa_accit-prctr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

***            *   ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*              SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
              SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              ENDIF.
***********************

*          IF lv_region NE lv_bupla(2)."comment by parth 13/04/2019
              IF lv_region NE lv_bupla_region." added by parth 13/04/2019
                MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
              ENDIF.
*        ELSE.
*          SELECT SINGLE regio FROM csks INTO lv_region WHERE kostl = wa_accit-kostl.
*          IF wa_accit-bupla(2) NE lv_region.
*            MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
*          ENDIF.
*          ENDIF.
*        ENDIF.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.




      IF sy-tcode = 'MIR7' OR sy-tcode = 'MIRO'.
        LOOP AT it_accit INTO wa_accit.
          IF wa_accit-bupla IS NOT INITIAL.     " AND wa_accit-secco IS NOT INITIAL.    " wa_accit-werks IS NOT INITIAL. "
            lv_bupla1 = wa_accit-bupla.
            AT FIRST.
*          lv_bupla = wa_accit-bupla.
              lv_bupla = lv_bupla1.
            ENDAT.
*        ELSE. Comment by parth 15/04/2019
            IF wa_accit-bupla IS NOT INITIAL.
              IF lv_bupla(2) NE wa_accit-bupla(2).
                MESSAGE 'Please Enter Correct BuisnessPlace' TYPE 'E'.
              ELSE.
                IF wa_accit-prctr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                  SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = wa_accit-prctr.
                  SELECT regio FROM cepc INTO lv_region UP TO 1 ROWS WHERE prctr = wa_accit-prctr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
*          ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                  SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*                  SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
                  SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                  IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                    SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                    SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                  ENDIF.
***********************

*                IF wa_accit-bupla(2) NE lv_region."comment by parth 13/04/2019
                  IF lv_bupla_region  NE lv_region."added by parth 13/04/2019
                    MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
                    EXIT.
                    LEAVE TO LIST-PROCESSING.
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.

      IF sy-tcode = 'FV60'
        OR sy-tcode = 'FB60'
        OR sy-tcode = 'FB65'
        OR sy-tcode = 'FV65'
        OR sy-tcode = 'FB75'
        OR sy-tcode = 'FV75' .

        LOOP AT it_accit INTO wa_accit.
          IF wa_accit-bupla IS NOT INITIAL AND wa_accit-secco IS NOT INITIAL.
            lv_bupla = wa_accit-bupla.
*          lv_werks = wa_accit-prctr(4).
          ELSE.
            IF wa_accit-prctr IS NOT INITIAL.
*          lv_werks = wa_accit-werks.
              IF lv_bupla NE wa_accit-bupla.
                MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
              ELSE.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = wa_accit-prctr.
                SELECT regio FROM cepc INTO lv_region UP TO 1 ROWS WHERE prctr = wa_accit-prctr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

*               ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*                SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
                SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                  SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                  SELECT region FROM adrc UP TO 1 ROWS INTO lv_bupla_region WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
                ENDIF.
***********************

*              IF wa_accit-bupla(2) NE lv_region."Comment by parth 13/04/2019
                IF lv_bupla_region NE lv_region."added by parth 13/04/2019
                  MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.


      IF sy-tcode = 'FB50' OR sy-tcode = 'FV50'.
        LOOP AT it_accit INTO wa_accit.
          IF wa_accit-bupla IS NOT INITIAL AND wa_accit-kostl IS INITIAL.
            lv_bupla = wa_accit-bupla.
            lv_werks = wa_accit-prctr(4).
*        ELSE. Comment by parth 15/04/2019
            IF lv_bupla NE wa_accit-bupla.
              MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
            ELSE.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE regio FROM csks INTO lv_region WHERE kostl = wa_accit-kostl.
              SELECT regio FROM csks INTO lv_region UP TO 1 ROWS WHERE kostl = wa_accit-kostl ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
*               ********* add for business place region from adrc table
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*              SELECT adrnr FROM j_1bbranch INTO lv_adrnr UP TO 1 ROWS WHERE branch = wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
              SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @wa_accit-bupla ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              IF lv_adrnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*                SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
                SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr ORDER BY PRIMARY KEY.ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
              ENDIF.
***********************

*            IF wa_accit-bupla(2) NE lv_region."comment by parth 13/04/2019
              IF  wa_accit-kostl IS NOT INITIAL. "added by parth 15/04/2019
                IF lv_bupla_region NE lv_region."added by parth 13/04/2019
                  MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
                ENDIF.
              ENDIF.  "added by parth 15/04/2019
            ENDIF.
          ENDIF.

        ENDLOOP.
      ENDIF.

*******************************Added By Raj Begin of changes on 01.09.2023********************************
*   IF sy-tcode IN it_tcodes.
*
*      READ TABLE it_accit INTO wa_valid WITH KEY koart = 'K'.
*      IF sy-subrc = 0.
*
*        IF wa_valid-ebeln IS NOT INITIAL.
*          SELECT SINGLE lifnr FROM ekko INTO lv_lifnr WHERE ebeln = wa_valid-ebeln.
*          IF lv_lifnr IS NOT INITIAL.
*            SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = lv_lifnr.
*          ENDIF.
*        ELSE.
*          SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = wa_valid-lifnr.
*        ENDIF.
*
*        IF lv_panno IS NOT INITIAL.
*          SELECT * FROM j_1imovend INTO TABLE it_vend WHERE j_1ipanno = lv_panno.
*          IF it_vend IS NOT INITIAL.
*
*            SELECT * FROM bsip INTO TABLE it_bsip FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'H'.
*            SELECT * FROM bsip INTO TABLE it_bsip1 FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'S'.
*
*            IF sy-tcode EQ 'FV65' OR sy-tcode EQ 'FB65' OR sy-tcode EQ 'FBVB'.
*
*              LOOP AT it_bsip1 INTO wa_bsip1 WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip INTO wa_bsip WITH KEY lifnr = wa_bsip1-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                  DELETE TABLE it_bsip  FROM wa_bsip.
*                ELSE.
*
*                  CLEAR lv_bstat.
*                  SELECT SINGLE bstat tcode FROM bkpf INTO (lv_bstat, lv_tcode) WHERE bukrs = wa_bsip1-bukrs
*                     AND belnr = wa_bsip1-belnr AND gjahr = wa_bsip1-gjahr.
*
*                  IF lv_bstat EQ 'V' AND sy-tcode EQ 'FB65'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat NE 'V'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ELSE.
*
*              LOOP AT it_bsip INTO wa_bsip WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip1 INTO wa_bsip1 WITH KEY lifnr = wa_bsip-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip FROM wa_bsip.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                ELSE.
*
**                  CLEAR lv_bstat.
**                  SELECT SINGLE bstat tcode FROM bkpf INTO (lv_bstat, lv_tcode) WHERE bukrs = wa_bsip-bukrs
**                     AND belnr = wa_bsip-belnr AND gjahr = wa_bsip-gjahr.
*
**                  IF lv_bstat EQ 'V' AND lv_tcode EQ 'MIR7'.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
**                  ELSEIF lv_bstat EQ 'V' AND sy-tcode EQ 'FB60'.
**                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
**                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
**                    CONDENSE lv_msg.
**                    MESSAGE lv_msg TYPE 'E'.
**                  ELSEIF lv_bstat NE 'V'.
**                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
**                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
**                    CONDENSE lv_msg.
**                    MESSAGE lv_msg TYPE 'E'.
**                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ENDIF.
*
*          ENDIF.
*        ENDIF.
*
*
*      ENDIF.
*
*    ENDIF.

*************************************    added by parth 18.09.2023
*                                                                           ****Begin of changes*"Commented by Raj on 19.02.2024***********
      IF sy-tcode IN it_tcodes.

        READ TABLE it_accit INTO wa_valid WITH KEY koart = 'K'.
        IF sy-subrc = 0.

          IF wa_valid-ebeln IS NOT INITIAL.
            SELECT SINGLE lifnr FROM ekko INTO lv_lifnr WHERE ebeln = wa_valid-ebeln.
            IF lv_lifnr IS NOT INITIAL.
*************************************added change by UDAYABAP02 12-02-26************************************
*              SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = lv_lifnr.
              SELECT SINGLE j_1ipanno FROM lfa1 INTO lv_panno WHERE lifnr = lv_lifnr.
*************************************end change by UDAYABAP02 12-02-26************************************
            ENDIF.
          ELSE.
*************************************added change by UDAYABAP02 12-02-26************************************
*            SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = wa_valid-lifnr.
            SELECT SINGLE j_1ipanno FROM lfa1 INTO lv_panno WHERE lifnr = wa_valid-lifnr.
*************************************end  change by UDAYABAP02 12-02-26************************************
          ENDIF.

          IF lv_panno IS NOT INITIAL.
*            SELECT * FROM j_1imovend INTO TABLE it_vend WHERE j_1ipanno = lv_panno. "Change by bhaumik|12.02.26
            SELECT * FROM lfa1 INTO TABLE @DATA(it_vend_t) WHERE j_1ipanno = @lv_panno. "Change by bhaumik|12.02.26
            IF it_vend_t IS NOT INITIAL.  "Change by bhaumik|12.02.26

              SELECT * FROM bsip INTO TABLE it_bsip FOR ALL ENTRIES IN it_vend_t "Change by bhaumik|12.02.26
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'H'. "Comment 21.12.2023
                WHERE  lifnr = it_vend_t-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'H' AND xblnr = wa_valid-xblnr. "added 21.12.2023
              SELECT * FROM bsip INTO TABLE it_bsip1 FOR ALL ENTRIES IN it_vend_t "Change by bhaumik|12.02.26
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'S'. "comment 21.12.2023
                WHERE  lifnr = it_vend_t-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'S' AND xblnr = wa_valid-xblnr . "added 21.12.2023


            ENDIF.
          ENDIF.
          LOOP AT it_bsip1 INTO wa_bsip1 WHERE xblnr = wa_valid-xblnr.

            READ TABLE it_bsip INTO wa_bsip WITH KEY lifnr = wa_bsip1-lifnr xblnr = wa_valid-xblnr.
            IF sy-subrc = 0.
              DELETE TABLE it_bsip1 FROM wa_bsip1.
              DELETE TABLE it_bsip  FROM wa_bsip.
            ENDIF.
          ENDLOOP.

          LOOP AT it_bsip INTO wa_bsip WHERE xblnr = wa_valid-xblnr.

            READ TABLE it_bsip1 INTO wa_bsip1 WITH KEY lifnr = wa_bsip-lifnr xblnr = wa_valid-xblnr.
            IF sy-subrc = 0.
              DELETE TABLE it_bsip1 FROM wa_bsip1.
              DELETE TABLE it_bsip  FROM wa_bsip.
            ENDIF.
          ENDLOOP.


        ENDIF.
      ENDIF.

***************************    ended by parth 18.09.2023
*************************Begin of changes Added  by Raj on 19.09.2023*********************
      IF it_bsip1 IS NOT INITIAL.
        SELECT * FROM bkpf  INTO TABLE it_bkpf FOR ALL ENTRIES IN it_bsip1
*       WHERE bukrs = it_bsip1-bukrs  AND belnr = it_bsip1-belnr AND gjahr = it_bsip1-gjahr AND xreversal NE '1' AND xreversal NE '2'. "comment by 21.12.2023
         WHERE bukrs IN ('1000','4000') AND  belnr = it_bsip1-belnr AND gjahr = it_bsip1-gjahr AND xreversal NE '1' AND xreversal NE '2'. "added by 21.12.2023
      ENDIF.
      IF it_bsip IS NOT INITIAL.
        SELECT * FROM bkpf  APPENDING TABLE it_bkpf FOR ALL ENTRIES IN it_bsip
*         WHERE bukrs = it_bsip-bukrs AND belnr = it_bsip-belnr AND gjahr = it_bsip-gjahr AND xreversal NE '1' AND xreversal NE '2'."comment by 12.12.2023
           WHERE bukrs IN ('1000','4000') AND belnr = it_bsip-belnr AND gjahr = it_bsip-gjahr AND xreversal NE '1' AND xreversal NE '2'. "added by 12.12.2023
      ENDIF.




      LOOP AT it_accit INTO wa_accit.
        IF wa_accit-belnr IS INITIAL.
*        READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_accit-bukrs  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."commnet by 21.12.2023
          READ TABLE it_bkpf INTO wa_bkpf WITH KEY  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr. "added by 21.12.2023
          IF wa_bkpf IS NOT INITIAL .


            CONCATENATE 'Document No' wa_bkpf-belnr 'in Co Code' wa_bkpf-bukrs 'with this reference in fiscal year'
                                    wa_bkpf-gjahr 'is already posted'  INTO lv_msg SEPARATED BY space.
            CONDENSE lv_msg.
            MESSAGE lv_msg TYPE 'E'.
          ENDIF.
        ELSE.

*        READ TABLE it_bkpf INTO wa_bkpf WITH KEY belnr = wa_accit-belnr bukrs = wa_accit-bukrs  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."comment by 21.12.2023
          READ TABLE it_bkpf INTO wa_bkpf WITH KEY belnr = wa_accit-belnr  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr. "added by 21.12.2023
          IF wa_bkpf IS NOT INITIAL .
            DELETE it_bkpf WHERE belnr = wa_accit-belnr.
            CLEAR wa_bkpf.
          ENDIF.

          IF sy-tcode = 'MIR4'.
*          READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey(10) = wa_accit-awref bukrs = wa_accit-bukrs  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."comment by 21.12.2023
            READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey(10) = wa_accit-awref  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr. "added by 21.12.2023
            IF wa_bkpf IS NOT INITIAL .
*            DELETE it_bkpf WHERE awkey(10) = wa_accit-awref AND bukrs = wa_accit-bukrs AND gjahr = wa_accit-gjahr."comment by 21.12.2023
              DELETE it_bkpf WHERE awkey(10) = wa_accit-awref AND gjahr = wa_accit-gjahr."added by 21.12.2023
              CLEAR wa_bkpf.
            ENDIF.
          ENDIF.




*        READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_accit-bukrs  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."comment by 21.12.2023
          READ TABLE it_bkpf INTO wa_bkpf WITH KEY  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."added by 21.12.2023
          IF wa_bkpf IS NOT INITIAL .
            CONCATENATE 'Document No' wa_bkpf-belnr 'in Co Code' wa_bkpf-bukrs  'with this reference in fiscal year'
                                 wa_bkpf-gjahr 'is already posted'  INTO lv_msg SEPARATED BY space.
            CONDENSE lv_msg.
            MESSAGE lv_msg TYPE 'E'.

          ENDIF.

        ENDIF.
*      ENDIF.
      ENDLOOP.
***********************End of changes Added by Raj on 19.09.2023**************************
* ****End of changes*"Commented by Raj on 19.02.2024***********

********************************Commented By Mayank on 26-08-2023********************************
*
*    IF sy-tcode IN it_tcodes.
*
*      READ TABLE it_accit INTO wa_valid WITH KEY koart = 'K'.
*      IF sy-subrc = 0.
*
*        IF wa_valid-ebeln IS NOT INITIAL.
*          SELECT SINGLE lifnr FROM ekko INTO lv_lifnr WHERE ebeln = wa_valid-ebeln.
*          IF lv_lifnr IS NOT INITIAL.
*            SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = lv_lifnr.
*          ENDIF.
*        ELSE.
*          SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = wa_valid-lifnr.
*        ENDIF.
*
*        IF lv_panno IS NOT INITIAL.
*          SELECT * FROM j_1imovend INTO TABLE it_vend WHERE j_1ipanno = lv_panno.
*          IF it_vend IS NOT INITIAL.
*
*            SELECT * FROM bsip INTO TABLE it_bsip FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'H'.
*            SELECT * FROM bsip INTO TABLE it_bsip1 FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'S'.
*
*            IF sy-tcode EQ 'FV65' OR sy-tcode EQ 'FB65' OR sy-tcode EQ 'FBVB'.
*
*              LOOP AT it_bsip1 INTO wa_bsip1 WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip INTO wa_bsip WITH KEY lifnr = wa_bsip1-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                  DELETE TABLE it_bsip  FROM wa_bsip.
*                ELSE.
*
*                  CLEAR lv_bstat.
*                  SELECT SINGLE bstat tcode FROM bkpf INTO (lv_bstat, lv_tcode) WHERE bukrs = wa_bsip1-bukrs
*                     AND belnr = wa_bsip1-belnr AND gjahr = wa_bsip1-gjahr.
*
*                  IF lv_bstat EQ 'V' AND sy-tcode EQ 'FB65' OR sy-tcode EQ 'FV65'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat NE 'V'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ELSE.
*
*              LOOP AT it_bsip INTO wa_bsip WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip1 INTO wa_bsip1 WITH KEY lifnr = wa_bsip-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip FROM wa_bsip.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                ELSE.
*
*                  CLEAR lv_bstat.
*                  SELECT SINGLE bstat tcode awkey FROM bkpf INTO (lv_bstat, lv_tcode, lv_awkey) WHERE bukrs = wa_bsip-bukrs
*                     AND belnr = wa_bsip-belnr AND gjahr = wa_bsip-gjahr.
*
*                  lv_belnr = lv_awkey+0(10).
*
*                  IF lv_bstat NE 'V' AND lv_belnr NE wa_valid-awref.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
**                  ENDIF.
*
**                  IF lv_bstat EQ 'V' AND lv_tcode EQ 'MIR7'." AND lv_belnr NE wa_valid-awref.
**                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
**                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
**                    CONDENSE lv_msg.
**                    MESSAGE lv_msg TYPE 'E'.
**                  ELSEIF lv_bstat EQ 'V' AND sy-tcode EQ 'FB60'.
**                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
**                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
**                    CONDENSE lv_msg.
**                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat NE 'V'.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ENDIF.
*
*          ENDIF.
*        ENDIF.
*
*
*      ENDIF.
*
*    ELSEIF sy-tcode IN it_tcodes1.
*
*      READ TABLE it_accit INTO wa_valid WITH KEY koart = 'K'.
*      IF sy-subrc = 0.
*
*        IF wa_valid-ebeln IS NOT INITIAL.
*          SELECT SINGLE lifnr FROM ekko INTO lv_lifnr WHERE ebeln = wa_valid-ebeln.
*          IF lv_lifnr IS NOT INITIAL.
*            SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = lv_lifnr.
*          ENDIF.
*        ELSE.
*          SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = wa_valid-lifnr.
*        ENDIF.
*
*        IF lv_panno IS NOT INITIAL.
*          SELECT * FROM j_1imovend INTO TABLE it_vend WHERE j_1ipanno = lv_panno.
*          IF it_vend IS NOT INITIAL.
*
*            SELECT * FROM bsip INTO TABLE it_bsip FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'H'.
*            SELECT * FROM bsip INTO TABLE it_bsip1 FOR ALL ENTRIES IN it_vend
*              WHERE bukrs = wa_valid-bukrs AND lifnr = it_vend-lifnr AND gjahr = wa_valid-gjahr AND shkzg = 'S'.
*
*            IF sy-tcode EQ 'FV65' OR sy-tcode EQ 'FB65' OR sy-tcode EQ 'FBVB'.
*
*              LOOP AT it_bsip1 INTO wa_bsip1 WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip INTO wa_bsip WITH KEY lifnr = wa_bsip1-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                  DELETE TABLE it_bsip  FROM wa_bsip.
*                ELSE.
*
*                  CLEAR lv_bstat.
*                  SELECT SINGLE bstat tcode FROM bkpf INTO (lv_bstat, lv_tcode) WHERE bukrs = wa_bsip1-bukrs
*                     AND belnr = wa_bsip1-belnr AND gjahr = wa_bsip1-gjahr.
*
*                  IF lv_bstat EQ 'V' AND sy-tcode EQ 'FB65'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat NE 'V'.
*                    CONCATENATE 'Document No' wa_bsip1-belnr 'with this reference in fiscal year'
*                                wa_bsip1-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ELSE.
*
*              LOOP AT it_bsip INTO wa_bsip WHERE xblnr = wa_valid-xblnr.
*
*                READ TABLE it_bsip1 INTO wa_bsip1 WITH KEY lifnr = wa_bsip-lifnr xblnr = wa_valid-xblnr.
*                IF sy-subrc = 0.
*                  DELETE TABLE it_bsip FROM wa_bsip.
*                  DELETE TABLE it_bsip1 FROM wa_bsip1.
*                ELSE.
*
*                  CLEAR lv_bstat.
*                  SELECT SINGLE bstat tcode awkey FROM bkpf INTO (lv_bstat, lv_tcode, lv_awkey) WHERE bukrs = wa_bsip-bukrs
*                     AND belnr = wa_bsip-belnr AND gjahr = wa_bsip-gjahr.
*
*                  lv_belnr = lv_awkey+0(10).
*
*                  IF lv_bstat EQ 'V' AND lv_tcode EQ 'MIR7' AND lv_belnr NE wa_valid-awref.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat EQ 'V' AND sy-tcode EQ 'FB60'.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ELSEIF lv_bstat NE 'V'.
*                    CONCATENATE 'Document No' wa_bsip-belnr 'with this reference in fiscal year'
*                                wa_bsip-gjahr 'is already posted' INTO lv_msg SEPARATED BY space.
*                    CONDENSE lv_msg.
*                    MESSAGE lv_msg TYPE 'E'.
*                  ENDIF.
*
*                ENDIF.
*
*              ENDLOOP.
*
*            ENDIF.
*
*          ENDIF.
*        ENDIF.
*
*      ENDIF.
*
*    ENDIF.

****************************************************Till Here by Mayank on 26-08-2023**************************************************

      "f-02

*    LOOP AT it_accit INTO wa_accit.
*      IF wa_accit-bupla IS NOT INITIAL AND wa_accit-prctr IS INITIAL.
*        lv_bupla = wa_accit-bupla.
**        lv_werks = wa_accit-prctr(4).
*      ELSE.
*        IF wa_accit-prctr IS NOT INITIAL.
*          lv_werks = wa_accit-prctr(4).
*          IF lv_bupla NE wa_accit-bupla.
*            MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
*          ELSE.
*            SELECT SINGLE regio FROM t001w INTO lv_region WHERE werks = lv_werks.
*            IF wa_accit-bupla(2) NE lv_region.
*              MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.


      "f-29
*    LOOP AT it_accit INTO wa_accit.
*      IF wa_accit-bupla IS NOT INITIAL AND wa_accit-prctr IS NOT INITIAL.
*        lv_bupla = wa_accit-bupla.
*        lv_werks = wa_accit-prctr(4).
*
**        IF wa_accit-werks IS NOT INITIAL.
**          lv_werks = wa_accit-werks.
*          IF lv_bupla NE wa_accit-bupla.
*            MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
*          ELSE.
*            SELECT SINGLE regio FROM t001w INTO lv_region WHERE werks = lv_werks.
*            IF wa_accit-bupla(2) NE lv_region.
*              MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
*            ENDIF.
*          ENDIF.
**        ENDIF.
*      ENDIF.
*     ENDLOOP.



      "fb65
*    LOOP AT it_accit INTO wa_accit.
*      IF wa_accit-bupla IS NOT INITIAL AND wa_accit-secco IS NOT INITIAL.
*        lv_bupla = wa_accit-bupla.
**          lv_werks = wa_accit-prctr(4).
*      ELSE.
*        IF wa_accit-prctr IS NOT INITIAL.7
*          IF lv_bupla NE wa_accit-bupla.
*            MESSAGE 'Please Enter Correct BusinessPlace' TYPE 'E'.
*          ELSE.
*            SELECT SINGLE regio FROM cepc INTO lv_region WHERE prctr = wa_accit-prctr.
*            IF wa_accit-bupla(2) NE lv_region.
*              MESSAGE 'Business Place does not match with cost center' TYPE 'E'.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.

*    IF sy-tcode IN it_tcodes.
*
*      SORT it_accit BY koart."prerequiste for binary search:Before binary search need to sort the internal table with its key fields of respective table.
*      READ TABLE it_accit INTO wa_valid WITH KEY koart = 'K' BINARY SEARCH.
*      IF sy-subrc = 0.
*
*        IF wa_valid-ebeln IS NOT INITIAL.
*          SELECT SINGLE lifnr FROM ekko INTO lv_lifnr WHERE ebeln = wa_valid-ebeln.
*          IF lv_lifnr IS NOT INITIAL.
*            SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = lv_lifnr.
*          ENDIF.
*        ELSE.
*          SELECT SINGLE j_1ipanno FROM j_1imovend INTO lv_panno WHERE lifnr = wa_valid-lifnr.
*        ENDIF.
*
*        IF lv_panno IS NOT INITIAL.
*          SELECT lifnr FROM j_1imovend INTO TABLE @DATA(it_vend) WHERE j_1ipanno = @lv_panno.
*
*          IF it_vend IS NOT INITIAL.
*
*            SELECT lifnr,xblnr,belnr,gjahr,shkzg FROM bsip INTO TABLE @DATA(it_bsip) FOR ALL ENTRIES IN @it_vend
*              WHERE  lifnr = @it_vend-lifnr AND gjahr = @wa_valid-gjahr AND shkzg = 'H'. "added 21.12.2023
*
*            SELECT lifnr,xblnr,belnr,gjahr,shkzg FROM bsip INTO TABLE @DATA(it_bsip1) FOR ALL ENTRIES IN @it_vend
*              WHERE  lifnr = @it_vend-lifnr AND gjahr = @wa_valid-gjahr AND shkzg = 'S' . "added 21.12.2023
*
*
*          ENDIF.
*        ENDIF.
*        LOOP AT it_bsip1 INTO DATA(wa_bsip1) WHERE xblnr = wa_valid-xblnr.
*
*          SORT it_bsip BY lifnr xblnr belnr gjahr.
*          READ TABLE it_bsip INTO DATA(wa_bsip) WITH KEY lifnr = wa_bsip1-lifnr xblnr = wa_valid-xblnr BINARY SEARCH.
*          IF sy-subrc = 0.
**            DELETE TABLE it_bsip1 FROM wa_bsip1.
**            DELETE TABLE it_bsip  FROM wa_bsip.
*            DELETE it_bsip1 WHERE lifnr = wa_bsip1-lifnr AND xblnr = wa_bsip1-xblnr  AND belnr = wa_bsip1-belnr AND gjahr = wa_bsip1-gjahr AND shkzg = wa_bsip1-shkzg.
*            DELETE it_bsip WHERE lifnr = wa_bsip-lifnr AND xblnr = wa_bsip-xblnr  AND belnr = wa_bsip-belnr AND gjahr = wa_bsip-gjahr AND shkzg = wa_bsip-shkzg.
*          ENDIF.
*        ENDLOOP.
*
*
*
*        LOOP AT it_bsip INTO wa_bsip WHERE xblnr = wa_valid-xblnr.
*          SORT it_bsip1 BY lifnr xblnr.
*          READ TABLE it_bsip1 INTO wa_bsip1 WITH KEY lifnr = wa_bsip-lifnr xblnr = wa_valid-xblnr BINARY SEARCH.
*          IF sy-subrc = 0.
**            DELETE TABLE it_bsip1 FROM wa_bsip1.
**            DELETE TABLE it_bsip  FROM wa_bsip.
*            DELETE it_bsip1 WHERE lifnr = wa_bsip1-lifnr AND xblnr = wa_bsip1-xblnr  AND belnr = wa_bsip1-belnr AND gjahr = wa_bsip1-gjahr AND shkzg = wa_bsip1-shkzg.
*            DELETE it_bsip WHERE lifnr = wa_bsip-lifnr AND xblnr = wa_bsip-xblnr  AND belnr = wa_bsip-belnr AND gjahr = wa_bsip-gjahr AND shkzg = wa_bsip-shkzg.
*          ENDIF.
*        ENDLOOP.
*
*
*      ENDIF.
*    ENDIF.
*
****************************    ended by parth 18.09.2023
**************************Begin of changes Added  by Raj on 19.09.2023*********************
*    IF it_bsip1 IS NOT INITIAL.
*      SELECT bukrs,belnr,gjahr,xblnr,awkey FROM bkpf  INTO TABLE @DATA(it_bkpf) FOR ALL ENTRIES IN @it_bsip1
*       WHERE bukrs IN ('1000','7000') AND  belnr = @it_bsip1-belnr AND gjahr = @it_bsip1-gjahr AND xreversal <> '1' AND xreversal <> '2'.
*    ENDIF.
*    IF it_bsip IS NOT INITIAL.
*      SELECT bukrs,belnr,gjahr,xblnr,awkey FROM bkpf  APPENDING TABLE @it_bkpf FOR ALL ENTRIES IN @it_bsip
*         WHERE bukrs IN ('1000','7000') AND belnr = @it_bsip-belnr AND gjahr = @it_bsip-gjahr AND xreversal <> '1' AND xreversal <> '2'.
*    ENDIF.
*
*
*
*
*    LOOP AT it_accit INTO wa_accit.
*      IF wa_accit-belnr IS INITIAL.
*        SORT it_bkpf BY bukrs belnr gjahr.
*        READ TABLE it_bkpf INTO DATA(wa_bkpf) WITH KEY  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr BINARY SEARCH. "added by 21.12.2023
*        IF wa_bkpf IS NOT INITIAL .
*
*
*          CONCATENATE 'Document No' wa_bkpf-belnr 'in Co Code' wa_bkpf-bukrs 'with this reference in fiscal year'
*                                  wa_bkpf-gjahr 'is already posted'  INTO lv_msg SEPARATED BY space.
*          CONDENSE lv_msg.
*          MESSAGE lv_msg TYPE 'E'.
*        ENDIF.
*      ELSE.
*        SORT it_bkpf BY bukrs belnr gjahr.
*        READ TABLE it_bkpf INTO wa_bkpf WITH KEY belnr = wa_accit-belnr  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr BINARY SEARCH. "added by 21.12.2023
*        IF wa_bkpf IS NOT INITIAL .
*          DELETE it_bkpf WHERE belnr = wa_accit-belnr.
*          CLEAR wa_bkpf.
*        ENDIF.
*
*        IF sy-tcode = 'MIR4'.
*          SORT it_bkpf BY bukrs belnr gjahr.
*          READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey(10) = wa_accit-awref  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr BINARY SEARCH. "added by 21.12.2023
*          IF wa_bkpf IS NOT INITIAL .
*
*            DELETE it_bkpf WHERE awkey(10) = wa_accit-awref AND gjahr = wa_accit-gjahr."added by 21.12.2023
*            CLEAR wa_bkpf.
*          ENDIF.
*        ENDIF.
*
*        SORT it_bkpf BY bukrs belnr gjahr.
*        READ TABLE it_bkpf INTO wa_bkpf WITH KEY  gjahr = wa_accit-gjahr xblnr = wa_accit-xblnr."added by 21.12.2023
*        IF wa_bkpf IS NOT INITIAL .
*          CONCATENATE 'Document No' wa_bkpf-belnr 'in Co Code' wa_bkpf-bukrs  'with this reference in fiscal year'
*                               wa_bkpf-gjahr 'is already posted'  INTO lv_msg SEPARATED BY space.
*          CONDENSE lv_msg.
*          MESSAGE lv_msg TYPE 'E'.
*
*        ENDIF.
*
*      ENDIF.
**      ENDIF.
*    ENDLOOP.
      "Adding Start by Rahul Vasita on 11.04.2024 10:06:34 Payments terms issue in Production Ticket-APLITSS00045
      "Comment Start by Rahul Vasita on 01.05.2024 11:00:57
      CLEAR : lv_msg.
      SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_tcode1) WHERE name = 'ZPAYMENT_TERM_TCODE' AND type = 'S' AND low = @sy-tcode.
      IF ls_tcode1 IS NOT INITIAL.
        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_tcode2) WHERE name = 'ZPAYMENT_TERM_TCODE_EX' AND type = 'S' AND low = @sy-tcode.
        IF ls_tcode2 IS NOT INITIAL.
          SELECT lifnr , ktokk FROM lfa1 INTO TABLE @DATA(lt_lfa1)
            FOR ALL ENTRIES IN @it_accit
            WHERE lifnr = @it_accit-lifnr
              AND ktokk IN ( 'ZEMP' , 'EE' ).
          IF lt_lfa1[] IS INITIAL.
            lv_msg = 'Payment Terms Missing in Vendor Master Record'.
            LOOP AT it_accit ASSIGNING FIELD-SYMBOL(<ls_accit>) WHERE koart = 'K'.
              IF <ls_accit>-zterm IS INITIAL.
                MESSAGE lv_msg TYPE 'E'.
              ENDIF."<ls_accit>-zterm IS INITIAL.
            ENDLOOP.
          ENDIF."IF lt_lfa1[] IS INITIAL.
        ELSE.
          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_tcode3) WHERE name = 'ZPAYMENT_TERM_TCODE_MM' AND type = 'S' AND low = @sy-tcode.
          IF ls_tcode3 IS NOT INITIAL.
            lv_msg = 'Payment Terms Missing in Vendor Master Record'.
            LOOP AT it_accit ASSIGNING <ls_accit> WHERE koart = 'K' AND bschl = '31'.
              IF <ls_accit>-zterm IS INITIAL.
                MESSAGE lv_msg TYPE 'E'.
              ENDIF."<ls_accit>-zterm IS INITIAL.
            ENDLOOP.
          ENDIF."IF ls_tcode3 is INITIAL.
        ENDIF."IF ls_tcode2 IS NOT INITIAL.
*      t_accit = it_Accit.
      ENDIF."IF ls_tcode1 is NOT INITIAL.
      CLEAR : ls_tcode1 , ls_tcode2 , lv_msg.
      ct_accit = it_accit.
      "Comment End by Rahul Vasita on 01.05.2024 11:00:57
      "Adding End by Rahul Vasita on 11.04.2024 10:06:34  Payments terms issue in Production Ticket-APLITSS00045

      "Comment Start by Rahul Vasita on 26.07.2024 10:44:00
**    GST VALIDATION BACKUP CODE PLEASE DO NOT REMOVE.
**    "Comment Start by Rahul Vasita on 22.05.2024 18:38:11
***********    "Adding Start by Rahul Vasita on 13.05.2024 11:26:26 Ticket - APLITSS00034
*********    it_accit = ct_accit.
*********    DATA : lv_vregio TYPE lfa1-regio,
*********           lv_lifnr1 TYPE lfa1-lifnr,
*********           lv_ktokk  TYPE lfa1-ktokk.
*********    CLEAR lv_lifnr1.
*********    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_new) WHERE name = 'ZFI_GSTIN_NEW_TCODE' AND type = 'S' AND low = @sy-tcode.
*********    IF sy-subrc = 0.
*********      lv_lifnr1 = VALUE #( it_accit[ koart = 'K' ]-gst_part OPTIONAL ).
*********    ELSE.
*********      lv_lifnr1 = VALUE #( it_accit[ koart = 'K' ]-lifnr OPTIONAL ).
*********    ENDIF.
*********    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_gstswitch) WHERE name = 'ZFI_GSTIN_EN_SWITCH' AND type = 'P'.
*********    IF ls_gstswitch-low = abap_true.
*********      SELECT SINGLE ktokk FROM lfa1 INTO lv_ktokk WHERE lifnr = lv_lifnr1.
*********      SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_ktokk) WHERE name = 'ZFI_GSTIN_EN_KTOKK' AND type = 'S' AND low = @lv_ktokk.
**********        IF lv_ktokk <> 'ZCEM'. "Comment by Rahul Vasita on 18.07.2024 15:26:02
*********        IF sy-subrc <> 0. "add by Rahul Vasita on 18.07.2024 15:26:02
*********          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_import) WHERE name = 'ZFI_GSTIN_IMPORT' AND type = 'S' AND low = @lv_ktokk.
*********          IF sy-subrc = 0.
*********            SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_endetail) WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = @sy-tcode.
*********            IF ls_endetail IS NOT INITIAL.
*********              LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
*********                SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_imtax) WHERE name = 'ZFI_GSTIN_IMPORT_TX' AND type = 'S' AND low = @wa_accit-mwskz.
*********                IF sy-subrc <> 0.
*********                  MESSAGE e007(zrcm_gst_en).
*********                ENDIF."End of LS_IMTAX
*********                CLEAR wa_accit.
*********              ENDLOOP.
*********            ENDIF."IF ls_endetail IS NOT INITIAL.
*********          ELSE.
*********            CLEAR : ls_endetail.
*********            SELECT SINGLE name  low FROM tvarvc INTO ls_endetail WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = sy-tcode.
*********            IF ls_endetail IS NOT INITIAL.
*********              SELECT SINGLE * FROM zfi_gstin_exl INTO @DATA(ls_splifnr) WHERE lifnr = @lv_lifnr1.
*********              IF sy-subrc <> 0.
*********                LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
*********                  SELECT SINGLE lifnr , ven_class FROM j_1imovend INTO @DATA(ls_j_1imovend) WHERE lifnr = @lv_lifnr1.
*********                  IF ls_j_1imovend-ven_class = '0'.
*********                    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_excep) WHERE name = 'ZFI_GSTIN_P1_V2_EX' AND type = 'S' AND low = @wa_accit-mwskz.
*********                    IF sy-subrc <> 0.
*********                      IF wa_accit-blart = 'RM'.
**********              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_excep) WHERE name = 'ZFI_GSTIN_P1_V2_EX' AND type = 'S' AND low = @wa_accit-mwskz.
**********                IF sy-subrc <> 0.
*********                        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v2) WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = @wa_accit-mwskz.
*********                        IF sy-subrc <> 0.
*********                          "Error Message for Validation No 2
*********                          MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                        ELSE.
*********                          "If Doc. Type is RM Starts
***********              IF wa_accit-blart = 'RM'.
*********                          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v3) WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = @wa_accit-mwskz.
*********                          IF sy-subrc <> 0.
*********                            "Error Message for Validation No 3
*********                            MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                          ELSE.
*********                            "Validation Code 6 Starts
*********                            CLEAR : lv_region , lv_adrnr , lv_bupla_region.
*********                            SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
*********                            SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*********                            IF lv_adrnr IS NOT INITIAL.
*********                              SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
*********                            ENDIF.
*********                            IF lv_region <> lv_bupla_region.
*********                              "IGST Code ZFI_GSTIN_P1_IGST
*********                              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v6) WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = @wa_accit-mwskz.
*********                              IF sy-subrc <> 0.
*********                                "Error Only IGST Allowed
*********                                MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
**********                    ELSE. "Comment by Rahul Vasita on 25.05.2024 15:33:14
*********                              ENDIF."ls_p1v6
*********                            ELSE.
*********                              "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
*********                              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v7) WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = @wa_accit-mwskz.
*********                              IF sy-subrc <> 0.
*********                                "Error Only C/S GST Allowed
*********                                MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
**********                    ELSE. "Comment by Rahul Vasita on 25.05.2024 15:33:23
*********                              ENDIF."ls_p1v7
*********                            ENDIF."IF lv_region <> lv_bupla_region.
*********                            "Validation Code 6 Ends
*********                          ENDIF."ls_p1v3
***********              ENDIF."RM Doc Type Validation
*********                          "If Doc. Type is RM Ends
*********                        ENDIF."sy-subrc <> 0.
*********                        CLEAR : ls_p1v2.
**********                ENDIF."End of LS_EXCEP
*********                      ELSE.
*********                        MESSAGE e004(zrcm_gst_en).
*********                      ENDIF."IF wa_accit-blart = 'RM'.
*********                    ENDIF."ls_excep
*********                  ELSE.""IF ls_j_1imovend-ven_class = '0'.
*********                    CLEAR: ls_splifnr.
*********                    SELECT SINGLE * FROM zfi_gstin_inc INTO ls_splifnr WHERE lifnr = lv_lifnr1.
*********                    IF sy-subrc = 0.
*********                      "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
*********                      IF wa_accit-blart = 'RM'.
*********                        SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
*********                        IF sy-subrc <> 0.
*********                          "Error Message for Validation No 2
*********                          MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                        ELSE.
*********                          "If Doc. Type is RM Starts
*********                          SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
*********                          IF sy-subrc <> 0.
*********                            "Error Message for Validation No 3
*********                            MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                          ELSE.
*********                            "Validation Code 6 Starts
*********                            CLEAR : lv_region , lv_adrnr , lv_bupla_region.
*********                            SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
*********                            SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*********                            IF lv_adrnr IS NOT INITIAL.
*********                              SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
*********                            ENDIF.
*********                            IF lv_region <> lv_bupla_region.
*********                              "IGST Code ZFI_GSTIN_P1_IGST
*********                              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = wa_accit-mwskz.
*********                              IF sy-subrc <> 0.
*********                                "Error Only IGST Allowed
*********                                MESSAGE e003(zrcm_gst_en).
*********                              ENDIF."ls_p1v6
*********                            ELSE.
*********                              "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
*********                              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
*********                              IF sy-subrc <> 0.
*********                                "Error Only C/S GST Allowed
*********                                MESSAGE e002(zrcm_gst_en).
*********                              ENDIF."ls_p1v7
*********                            ENDIF."IF lv_region <> lv_bupla_region.
*********                            "Validation Code 6 Ends
*********                          ENDIF."ls_p1v3
*********                          "If Doc. Type is RM Ends
*********                        ENDIF."sy-subrc <> 0.
*********                        CLEAR : ls_p1v2.
*********                      ELSE.
*********                        MESSAGE e004(zrcm_gst_en).
*********                      ENDIF."IF wa_accit-blart = 'RM'.
*********                      "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
*********                    ELSE.
*********                      IF wa_accit-blart = 'RM'.
*********                        MESSAGE e005(zrcm_gst_en).
*********                      ELSE.
*********                        SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
*********                        IF sy-subrc = 0.
*********                          MESSAGE e006(zrcm_gst_en).
*********                        ELSE.
**********                      GST PHASE 2 STARTS
*********                          "Validation Code 6 Starts
*********                          CLEAR : lv_region , lv_adrnr , lv_bupla_region.
*********                          SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
*********                          SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*********                          IF lv_adrnr IS NOT INITIAL.
*********                            SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
*********                          ENDIF.
*********                          CLEAR: ls_p1v6 , ls_p1v7.
*********                          IF lv_region <> lv_bupla_region.
*********                            "IGST Code ZFI_GSTIN_P1_IGST
*********                            SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P2_IGST' AND type = 'S' AND low = wa_accit-mwskz.
*********                            IF sy-subrc <> 0.
*********                              "Error Only IGST Allowed
*********                              MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                            ENDIF."ls_p1v6
*********                          ELSE.
*********                            "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
*********                            SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P2_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
*********                            IF sy-subrc <> 0.
*********                              "Error Only C/S GST Allowed
*********                              MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                            ENDIF."ls_p1v7
*********                          ENDIF."IF lv_region <> lv_bupla_region.
*********                          "Validation Code 6 Ends
**********                      GST PHASE 2 ENDS
***********                SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = wa_accit-mwskz.
***********                IF sy-subrc = 0.
***********                  MESSAGE e006(zrcm_gst_en).
***********                ELSE.
***********                  SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
***********                  IF sy-subrc = 0.
***********                    MESSAGE e006(zrcm_gst_en).
***********                  ENDIF."END OF C / S GST
***********                ENDIF."END OF IGST
*********                        ENDIF."End of V2 TAX CODE
*********                      ENDIF."wa_accit-blart = 'RM'.
*********                    ENDIF."ENd of Include Vendor
*********                  ENDIF."IF ls_j_1imovend-ven_class = '0'.
*********                  CLEAR : wa_accit , ls_j_1imovend.
*********                ENDLOOP.
*********              ELSE.
*********                LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '.
*********                  IF wa_accit-blart = 'RM'.
*********                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = wa_accit-mwskz.
*********                    IF sy-subrc <> 0.
*********                      "Error Message for Validation No 2
*********                      MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                    ELSE.
*********                      SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
*********                      IF sy-subrc <> 0.
*********                        "Error Message for Validation No 3
*********                        MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                      ELSE.
*********                        "Validation Code 6 Starts
*********                        CLEAR : lv_region , lv_adrnr , lv_bupla_region.
*********                        SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.
*********                        SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = wa_accit-bupla.
*********                        IF lv_adrnr IS NOT INITIAL.
*********                          SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.
*********                        ENDIF.
*********                        IF lv_region <> lv_bupla_region.
*********                          "IGST Code ZFI_GSTIN_P1_IGST
*********                          SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = wa_accit-mwskz.
*********                          IF sy-subrc <> 0.
*********                            "Error Only IGST Allowed
*********                            MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                          ENDIF."ls_p1v6
*********                        ELSE.
*********                          "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
*********                          SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = wa_accit-mwskz.
*********                          IF sy-subrc <> 0.
*********                            "Error Only C/S GST Allowed
*********                            MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
*********                          ENDIF."ls_p1v7
*********                        ENDIF."IF lv_region <> lv_bupla_region.
*********                        "Validation Code 6 Ends
*********                      ENDIF."ls_p1v3
*********                      "If Doc. Type is RM Ends
*********                    ENDIF."sy-subrc <> 0.
*********                    CLEAR : ls_p1v2.
*********                  ELSE.
*********                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = wa_accit-mwskz.
*********                    IF sy-subrc = 0.
*********                      MESSAGE e006(zrcm_gst_en).
*********                    ENDIF."ls_p1v2
*********                  ENDIF."IF wa_accit-blart = 'RM'.
*********                ENDLOOP.
*********              ENDIF."LS_SPLIFNR
*********            ENDIF."IF ls_endetail IS NOT INITIAL.
*********            CLEAR : ls_endetail.
*********          ENDIF."END OF IMPORT ACC. GRP.
*********
*********        ENDIF."IF lv_ktokk <> 'ZCEM'.
*********      ENDIF."IF ls_gstswitch-low = abap_true.
*********      ct_accit = it_accit.
*********      CLEAR ls_gstswitch.
***********    "Adding End by Rahul Vasita on 13.05.2024 11:26:26  Ticket - APLITSS00034
**    "Comment End by Rahul Vasita on 22.05.2024 18:38:11
**    GST VALIDATION BACKUP CODE PLEASE DO NOT REMOVE.
      "Comment End by Rahul Vasita on 26.07.2024 10:44:00



****************************Begin of Changes Added by Raj on 09.10.2024*****************************

      CONSTANTS: c_tcode TYPE rvari_vnam VALUE 'HSN_TCODE'.
      CONSTANTS: c_ccode TYPE rvari_vnam VALUE 'HSN_CO_CODE'.
      CONSTANTS: c_doc TYPE rvari_vnam VALUE 'HSN_DOC_TYPE'.
*    CONSTANTS: C_GL TYPE RVARI_VNAM VALUE 'HSN_GL'.

      DATA : it_htcode TYPE STANDARD TABLE OF ty_tvarvc1,
             wa_htcode TYPE ty_tvarvc1.

      DATA : it_ccode TYPE STANDARD TABLE OF ty_tvarvc1,
             wa_ccode TYPE ty_tvarvc1.

      DATA : it_docs TYPE STANDARD TABLE OF ty_tvarvc1,
             wa_docs TYPE ty_tvarvc1.

*    DATA : IT_GL TYPE TABLE OF ZFI_GL,
*           WA_GL TYPE ZFI_GL.

      REFRESH : it_htcode,it_htcode,it_docs.
      CLEAR : wa_htcode,wa_htcode,wa_docs.


      SELECT sign opti low high
             INTO CORRESPONDING FIELDS OF TABLE it_htcode
             FROM tvarvc
             WHERE  name  = c_tcode.


      SELECT sign opti low high
          INTO CORRESPONDING FIELDS OF TABLE it_ccode
          FROM tvarvc
          WHERE  name  = c_ccode.


      SELECT sign opti low high
       INTO CORRESPONDING FIELDS OF TABLE it_docs
       FROM tvarvc
       WHERE  name  = c_doc.

      READ TABLE it_htcode INTO wa_htcode WITH KEY low = sy-tcode.
      IF sy-subrc = 0.
        LOOP AT it_accit INTO wa_accit.
          READ TABLE it_ccode INTO wa_ccode WITH KEY low = wa_accit-bukrs.
          IF sy-subrc = 0.
            READ TABLE it_docs INTO wa_docs WITH KEY low = wa_accit-blart.
            IF sy-subrc = 0.
              IF wa_accit-koart = 'S' AND wa_accit-xauto IS INITIAL.
*              READ TABLE IT_GL INTO WA_GL WITH KEY hkont = WA_ACCIT-HKONT.
*              IF SY-SUBRC = 0.
                IF wa_accit-hsn_sac IS INITIAL.
                  MESSAGE e055(zmm).
                ENDIF.
*              ENDIF.
*              clear : wa_gl.
              ENDIF.
            ENDIF.
            CLEAR : wa_docs.
          ENDIF.
          CLEAR : wa_accit,wa_ccode.
        ENDLOOP.
        CLEAR : wa_htcode.
      ENDIF.
****************************End of Changes Added by Raj on 09.10.2024******************************

    ENDIF.

  ENDMETHOD.
ENDCLASS.
