*&---------------------------------------------------------------------*
*&  Include           SAPMZFI_BANK_RECO_MANUAL_O01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  SET_SCREEN  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE set_screen OUTPUT.
  IF gv_bukrs IS INITIAL AND
     gv_hbkid IS INITIAL AND
     gv_hktid IS INITIAL AND
     gv_aznum IS INITIAL AND
     gv_azdat IS INITIAL AND
     gv_ssald IS INITIAL AND
     gv_esald IS INITIAL.
    gv_sub_8001 = gc_8001.
    gv_sub_8002 = '8999'.
    gv_flag = 'X'.
  ELSE.
    gv_sub_8001 = gc_8001.
    gv_sub_8002 = gc_8002.
    CLEAR gv_flag.
  ENDIF.
ENDMODULE.                 " SET_SCREEN  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.
  SET PF-STATUS 'STATUS_9000'.
ENDMODULE.                 " STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  SET_SCREEN_ATTR  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE set_screen_attr OUTPUT.
  IF gv_bukrs IS NOT INITIAL AND
     gv_hbkid IS NOT INITIAL AND
     gv_hktid IS NOT INITIAL AND
     gv_aznum IS NOT INITIAL AND
     gv_azdat IS NOT INITIAL AND
     gv_ssald IS NOT INITIAL.
*     gv_esald IS INITIAL.
    LOOP AT SCREEN.
      IF screen-group1 = 'GP1'.
        screen-input = 0.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ENDIF.
  IF gv_azdat IS INITIAL.
    gv_azdat = sy-datum.
  ENDIF.
ENDMODULE.                 " SET_SCREEN_ATTR  OUTPUT

*&SPWIZARD: OUTPUT MODULE FOR TC 'T_TABL_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: UPDATE LINES FOR EQUIVALENT SCROLLBAR
MODULE t_tabl_ctrl_change_tc_attr OUTPUT.
  DESCRIBE TABLE gt_table LINES t_tabl_ctrl-lines.
ENDMODULE.

*&SPWIZARD: OUTPUT MODULE FOR TC 'T_TABL_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: GET LINES OF TABLECONTROL
MODULE t_tabl_ctrl_get_lines OUTPUT.
  g_t_tabl_ctrl_lines = sy-loopc.
*  wa_table-cldat = space.
  LOOP AT SCREEN.
    IF ( screen-name = 'WA_TABLE-BUKRS' AND wa_table-bukrs IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-VGMAN' AND wa_table-vgman IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-HKONT' AND wa_table-hkont IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-BELNR' AND wa_table-belnr IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-BLART' AND wa_table-blart IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-DMBTR' AND wa_table-dmbtr IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-ZUONR' AND wa_table-dmbtr IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-KIDNO' AND wa_table-dmbtr IS NOT INITIAL ) OR
       ( screen-name = 'WA_TABLE-NAME'  AND wa_table-dmbtr IS NOT INITIAL ).
      screen-input = 0.
*    screen-active = 0.
      MODIFY SCREEN.
    ENDIF.
    IF ( screen-name = 'WA_TABLE-CLDAT' AND wa_table-cldat NE 0  ) OR
       ( screen-name = 'WA_TABLE-BLDAT' AND wa_table-bldat NE 0  ) OR
       ( screen-name = 'WA_TABLE-BUDAT' AND wa_table-budat NE 0  ) OR
       ( screen-name = 'WA_TABLE-VALUT' AND wa_table-valut NE 0  )
 .
      screen-input = 0.
*    screen-active = 0.
      MODIFY SCREEN.


    ENDIF.
  ENDLOOP.
*  IF wa_table-cldat eq 0.
*    BREAK sap_abap.
*  ENDIF.
ENDMODULE.
