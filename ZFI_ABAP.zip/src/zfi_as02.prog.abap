*&---------------------------------------------------------------------*
*& Report ZFI_AS02
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zfi_as02.

TYPES: BEGIN OF ty_upload,
         anln1(012),
         anln2(004),
         bukrs(004),
         txt50(050),
         txa50(050),
         sernr(018),
         menge(018),
         meins(003),
         aktiv(010),
         invnr(025),
         anlhtxt(050),
         kostl(010),
         werks(004),
         stort(004),
         gsber(004),
         lstar(006),
         raumn(008),
*         pernr(008),
         kfzkz(015),
         anlue(012),
         lifnr(010),
         typbz(015),
         herst(030),
         glo_in_blk_key(005),
         glo_in_ast_use(010),
         afasl1(004),
         ndjar1(003),
         ndper1(003),
         afabg1(010),
         schrw1              TYPE string,
         schrw_proz1(015),
         afasl2(004),
         ndjar2(003),
         ndper2(003),
         afabg2(010),
         schrw2              TYPE string,
         schrw_proz2(015),

*         anln1                   TYPE anln1,        " Main Asset Number
*         anln2                   TYPE anln2,        " Asset Subnumber
*         bukrs                   TYPE bukrs,        " Company Code
*         txt50                   TYPE char50,       " Asset Description
*         txa50                   TYPE char50,       " Additional Description
*         sernr                   TYPE char18,        " Serial Number
*         menge                   TYPE menge_d,      " Quantity
*         meins                   TYPE meins,        " Unit of Measure
*         aktiv                   TYPE aktiv,        " Activation Date
*         invnr                   TYPE invnr,        " Inventory Number
*         anlhtxt                 TYPE anlhtxt,      " Main Asset Text
*         kostl                   TYPE kostl,        " Cost Center
*         werks                   TYPE werks_d,      " Plant
*         stort                   TYPE lgort_d,        " Asset Location
*         gsber                   TYPE gsber,        " Business Area
*         lstar                   TYPE lstar,        " Activity Type
*         raumn                   TYPE char8,        " Room
*         pernr                   TYPE pernr_d,      " Personnel Number
*         kfzkz                   TYPE char15,        " License Plate
*         lifnr                   TYPE lifnr,        " Vendor
*         typbz                   TYPE typbz,        " Type Designation
*         herst                   TYPE herst,        " Manufacturer
*         glo_in_blk_key          TYPE glo_in_blk_key,
*         glo_in_ast_use          TYPE datum,
*         dep_area                TYPE char2,
*         afasl                   TYPE afasl,        " Depr. Key
*         ndjar                   TYPE ndjar,        " Useful life (years)
*         ndper                   TYPE ndper,        " Useful life (periods)
*         afabg                   TYPE afabg,        " Depr. start date
*         schrw                   TYPE bf_schrw,     " Scrap Value
*         schrw_proz              TYPE schrw_proz,   " Scrap %
       END OF ty_upload.


DATA: lt_upload TYPE STANDARD TABLE OF ty_upload,
      ls_upload TYPE ty_upload,
      lt_raw    TYPE truxs_t_text_data. " Required for TEXT_CONVERT FM

DATA: ls_gen    TYPE bapi1022_feglg001,            ls_genx   TYPE bapi1022_feglg001x,
      ls_poi    TYPE bapi1022_feglg002,            ls_poix   TYPE bapi1022_feglg002x,
      ls_time   TYPE bapi1022_feglg003,            ls_timex  TYPE bapi1022_feglg003x,
      ls_orn    TYPE bapi1022_feglg009,            ls_ornx   TYPE bapi1022_feglg009x,
      ls_glo    TYPE bapi1022_glo_in_gen,          ls_glox   TYPE bapi1022_glo_in_genx,
      lt_dep    TYPE TABLE OF bapi1022_dep_areas,  ls_dep    TYPE bapi1022_dep_areas,
      lt_depx   TYPE TABLE OF bapi1022_dep_areasx, ls_depx   TYPE bapi1022_dep_areasx,
      ls_return TYPE bapiret2.

DATA: gt_raw     TYPE solix_tab,
      gv_bin_len TYPE i.

DATA: lv_xstring    TYPE xstring,
      lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
      lv_docname    TYPE string,
      lt_worksheets TYPE STANDARD TABLE OF string,
      lv_worksheet  TYPE string,
      lv_lines      TYPE i,
      lo_data       TYPE REF TO data.


DATA:   bdcdata LIKE bdcdata    OCCURS 0 WITH HEADER LINE.
DATA:   messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
*DATA:   record TYPE STANDARD TABLE OF ty_record WITH HEADER LINE.
*  DATA  :t_raw TYPE truxs_t_text_data.
DATA: w_param TYPE ctu_params.
DATA: l_mstring(480).
DATA: l_subrc LIKE sy-subrc.

FIELD-SYMBOLS: <lt_data>      TYPE STANDARD TABLE,
               <ls_data>      TYPE any,
               <lv_value_tmp> TYPE any,
               <lv_value>     TYPE any.

DATA: lv_fname   TYPE string.
DATA : lv_area(2) TYPE i.


SELECTION-SCREEN : PUSHBUTTON 1(20) TEXT-004 USER-COMMAND down MODIF ID dn.
PARAMETERS: p_file TYPE rlgrap-filename,
            p_mode TYPE ctu_mode DEFAULT 'N'.

AT SELECTION-SCREEN.
  IF sy-ucomm = 'DOWN'.
    PERFORM download_template.
    RETURN.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'F4_FILENAME'
    IMPORTING
      file_name = p_file.

START-OF-SELECTION.

  lv_fname = p_file.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  CREATE OBJECT lo_excel
    EXPORTING
      document_name = lv_docname
      xdocument     = lv_xstring.

  IF lo_excel IS NOT INITIAL.
    lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
      IMPORTING
        worksheet_names = lt_worksheets ).
  ENDIF.

  DESCRIBE TABLE lt_worksheets LINES lv_lines.

  IF lt_worksheets[] IS NOT INITIAL.
    READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
    lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
    ASSIGN lo_data->* TO <lt_data>.
  ENDIF.

  IF <lt_data> IS ASSIGNED.
    LOOP AT <lt_data> ASSIGNING <ls_data> FROM 2.
      CLEAR: ls_upload.
      DO.
        ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data> TO <lv_value_tmp>.
        IF sy-subrc EQ 0.
          ASSIGN COMPONENT sy-index OF STRUCTURE ls_upload TO <lv_value>.
          IF sy-subrc EQ 0.
            <lv_value> = <lv_value_tmp>.
          ENDIF.
        ELSE.
          EXIT.
        ENDIF.
      ENDDO.
      IF ls_upload IS NOT INITIAL.
        APPEND ls_upload TO lt_upload.
      ENDIF.
    ENDLOOP.
  ENDIF.

  SORT lt_upload BY anln1.

  LOOP AT lt_upload ASSIGNING FIELD-SYMBOL(<ls_upload>).
    <ls_upload>-anln1 = |{ <ls_upload>-anln1 ALPHA = IN }|.
    <ls_upload>-stort = |{ <ls_upload>-stort ALPHA = IN }|.
*    <ls_upload>-pernr = |{ <ls_upload>-pernr ALPHA = IN }|.
  ENDLOOP.

  IF lt_upload IS NOT INITIAL.
    SELECT a~anln1, a~txt50, a~aktiv, a~anlkl,
           b~afasl, b~afabe, b~ndjar, b~ndper, b~afabg,
           z~werks, z~kostl FROM anla AS a
        INNER JOIN anlb AS b ON b~bukrs = a~bukrs
                             AND b~anln1 = a~anln1
        INNER JOIN anlz AS z ON z~bukrs = a~bukrs
                             AND  z~anln1 = a~anln1
      FOR ALL ENTRIES IN @lt_upload
      WHERE a~bukrs = @lt_upload-bukrs
        AND a~anln1 = @lt_upload-anln1
      INTO TABLE @DATA(lt_asset).
    IF lt_asset IS INITIAL .
      MESSAGE 'Assest Master data is not available' TYPE 'E'.
    ENDIF.
  ENDIF.

  LOOP AT lt_upload INTO ls_upload.

*    DATA(ls_upload1) = ls_upload.
*    AT NEW anln1.
*      CLEAR: ls_gen, ls_genx, ls_poi, ls_poix, ls_time, ls_timex.
*
*      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT' EXPORTING input = ls_upload-anln1 IMPORTING output = ls_upload1-anln1.
*
*      " General Data Mapping
*      IF ls_upload1-txt50 IS NOT INITIAL.
*        ls_gen-descript      = ls_upload1-txt50.
*      ENDIF.
*      ls_gen-descript2     = ls_upload1-txa50.
*      ls_gen-serial_no     = ls_upload1-sernr.
*      ls_gen-quantity      = ls_upload1-menge.
*      ls_gen-base_uom      = ls_upload1-meins.
*      ls_gen-invent_no     = ls_upload1-invnr.
*      ls_gen-main_descript = ls_upload1-anlhtxt.
*
*      ls_genx-descript = ls_genx-descript2 = ls_genx-serial_no =
*      ls_genx-quantity = ls_genx-base_uom = ls_genx-invent_no = ls_gen-main_descript =   'X'.
*
*
*      "Position
*      ls_poi-cap_date = ls_upload-aktiv.
*
*      ls_poix = 'X'.
*
*      " Time-Dependent Mapping
*      ls_time-costcenter   = ls_upload1-kostl.
*      ls_time-plant        = ls_upload1-werks.
*      ls_time-location     = ls_upload1-stort.
**      ls_time-bus_area     = ls_upload-gsber.
*      ls_time-acttype      = ls_upload1-lstar.
*      ls_time-room         = ls_upload1-raumn.
*      ls_time-person_no    = ls_upload1-pernr.
*      ls_time-plate_no     = ls_upload1-kfzkz.
*
*      ls_timex-costcenter = ls_timex-plant = ls_timex-location  =
*      ls_timex-acttype    = ls_timex-room  = ls_timex-person_no = ls_timex-license_plate_no   = 'X'. "ls_timex-bus_area
*
*      "Origin
*      ls_orn-vendor_no    = ls_upload1-lifnr.
*      ls_orn-type_name    = ls_upload1-typbz.
*      ls_orn-manufacturer = ls_upload1-herst.
*
*      ls_ornx-vendor_no = ls_ornx-type_name = ls_ornx-manufacturer = 'X'.
*
*      "GLO
*      ls_glo-block_key       = ls_upload1-glo_in_blk_key.
*      ls_glo-put_to_use_date = ls_upload1-glo_in_ast_use.
*
*      ls_glox-block_key = ls_glox-put_to_use_date = 'X'.
*    ENDAT.
*
*    "Depreciation Areas
*    IF ls_upload1-dep_area IS NOT INITIAL.
*      ls_dep-area             = ls_upload1-dep_area.
*      ls_dep-dep_key          = ls_upload1-afasl.
*      ls_dep-ulife_yrs        = ls_upload1-ndjar.
*      ls_dep-ulife_prds       = ls_upload1-ndper.
*      ls_dep-odep_start_date  = ls_upload1-afabg.
*      ls_dep-scrapvalue       = ls_upload1-schrw.
*      ls_dep-scrapvalue_prctg = ls_upload1-schrw_proz.
*
*      APPEND ls_dep TO lt_dep.
*
*      ls_depx-area       = ls_upload-dep_area. "'X'
*      ls_depx-dep_key = ls_depx-ulife_yrs = ls_depx-ulife_prds
*      = ls_depx-odep_start_date =  ls_depx-scrapvalue = ls_depx-scrapvalue_prctg = 'X'.
*      APPEND ls_depx TO lt_depx.
*    ENDIF.
*
*    AT END OF anln1.
*      "---> Call BAPI
*      CALL FUNCTION 'BAPI_FIXEDASSET_CHANGE'
*        EXPORTING
*          companycode         = ls_upload1-bukrs
*          asset               = ls_upload1-anln1
*          subnumber           = ls_upload1-anln2
*          generaldata         = ls_gen
*          generaldatax        = ls_genx
*          postinginformation  = ls_poi
*          postinginformationx = ls_poix
*          timedependentdata   = ls_time
*          timedependentdatax  = ls_timex
*          origin              = ls_orn
*          originx             = ls_ornx
*          glo_in_gen          = ls_glo
*          glo_in_genx         = ls_glox
*        IMPORTING
*          return              = ls_return
*        TABLES
*          depreciationareas   = lt_dep
*          depreciationareasx  = lt_depx.
*
*      IF ls_return-type = 'S' OR ls_return-type = 'W'.
*        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = 'X'.
*        WRITE: / ls_upload-anln1, 'SUCCESS'.
*      ELSE.
*        WRITE: / ls_upload-anln1, 'ERROR:', ls_return-message.
*      ENDIF.
*    ENDAT.

    PERFORM bdc_dynpro      USING 'SAPLAIST' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-BUKRS'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'ANLA-ANLN1'
                                  ls_upload-anln1.

    IF ls_upload-anln2 IS INITIAL.
    ELSE.
      PERFORM bdc_field       USING 'ANLA-ANLN2'
                                    ls_upload-anln2.
    ENDIF.
    PERFORM bdc_field       USING 'ANLA-BUKRS'
                                  ls_upload-bukrs.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB02'.

    READ TABLE lt_asset INTO DATA(ls_asset) WITH KEY anln1 = ls_upload-anln1.

    IF ls_upload-txt50 IS INITIAL.
      PERFORM bdc_field       USING 'ANLA-TXT50'
                                    ls_asset-txt50.
    ELSE.
      PERFORM bdc_field       USING 'ANLA-TXT50'
                                    ls_upload-txt50.
    ENDIF.

    PERFORM bdc_field       USING 'ANLA-TXA50'
                                  ls_upload-txa50.
    PERFORM bdc_field       USING 'ANLH-ANLHTXT'
                                  ls_upload-anlhtxt.
    PERFORM bdc_field       USING 'ANLA-SERNR'
                                  ls_upload-sernr.
    PERFORM bdc_field       USING 'ANLA-INVNR'
                                  ls_upload-invnr.
    PERFORM bdc_field       USING 'ANLA-MENGE'
                                  ls_upload-menge.
    PERFORM bdc_field       USING 'ANLA-MEINS'
                                  ls_upload-meins.
    PERFORM bdc_field       USING 'ANLA-INKEN'
                                  'X'. "ls_upload-inken.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-DEAKT'.

    IF ls_upload-aktiv IS INITIAL.
      PERFORM bdc_field       USING 'ANLA-AKTIV'
                                    ls_asset-aktiv.
    ELSE.
      PERFORM bdc_field       USING 'ANLA-AKTIV'
                                    ls_upload-aktiv.
    ENDIF.

    PERFORM bdc_field       USING 'ANLA-AKTIV'
                                  ls_upload-aktiv.
*    PERFORM bdc_field       USING 'ANLA-DEAKT'
*                                  ls_upload-deakt.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB03'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLZ-SEGMENT'.

    IF ls_upload-kostl IS INITIAL.
      PERFORM bdc_field       USING 'ANLZ-KOSTL'
                               ls_asset-kostl.
    ELSE.
      PERFORM bdc_field       USING 'ANLZ-KOSTL'
                               ls_upload-kostl.
    ENDIF.


    IF ls_asset-anlkl = '220000' OR ls_asset-anlkl = '350000'.
      PERFORM bdc_field       USING 'ANLZ-LSTAR'
                                    ls_upload-lstar.
    ENDIF.

    IF ls_upload-werks IS INITIAL.
      PERFORM bdc_field       USING 'ANLZ-WERKS'
                                    ls_asset-werks.
    ELSE.
      PERFORM bdc_field       USING 'ANLZ-WERKS'
                                    ls_upload-werks.
    ENDIF.

    PERFORM bdc_field       USING 'ANLZ-STORT'
                                  ls_upload-stort.
    PERFORM bdc_field       USING 'ANLZ-RAUMN'
                                  ls_upload-raumn.
    PERFORM bdc_field       USING 'ANLZ-KFZKZ'
                                  ls_upload-kfzkz.
*    PERFORM bdc_field       USING 'ANLZ-PERNR'
*                                  ls_upload-pernr.
*    PERFORM bdc_field       USING 'ANLZ-PRCTR'
*                                  ls_upload-prctr.
*    PERFORM bdc_field       USING 'ANLZ-SEGMENT'
*                                  ls_upload-segment.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB04'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-ANLUE'.
    PERFORM bdc_field       USING 'ANLA-ANLUE'
                                  ls_upload-anlue.
    PERFORM bdc_field       USING 'RA02S-EQANZ'
                                  '1'."ls_upload-eqanz.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB05'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-ANTEI'.
    PERFORM bdc_field       USING 'ANLA-LIFNR'
                                  ls_upload-lifnr.
    PERFORM bdc_field       USING 'ANLA-HERST'
                                  ls_upload-herst.
    PERFORM bdc_field       USING 'ANLA-TYPBZ'
                                  ls_upload-typbz.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB08'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'GLOFAAASSETDATA-GLO_IN_PRIOR_YR'.
    PERFORM bdc_field       USING 'GLOFAAASSETDATA-GLO_IN_BLK_KEY'
                                  ls_upload-glo_in_blk_key.
    PERFORM bdc_field       USING 'GLOFAAASSETDATA-GLO_IN_AST_USE'
                                  ls_upload-glo_in_ast_use.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=SELZ'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-AFASL(01)'.

    CLEAR ls_asset.
    READ TABLE lt_asset INTO ls_asset WITH KEY anln1 = ls_upload-anln1
                                               afabe = '01'.

    IF ls_upload-afasl1 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-AFASL(02)'
                                     ls_asset-afasl.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-AFASL(02)'
                                     ls_upload-afasl1.
    ENDIF.

    PERFORM bdc_dynpro      USING 'SAPLAIST' '0195'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=RW'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-SCHRW_PROZ'.

    IF ls_upload-afasl1 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-AFASL'
                                     ls_asset-afasl.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-AFASL'
                                     ls_upload-afasl1.
    ENDIF.

    IF ls_upload-ndjar1 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-NDJAR'
                              ls_asset-ndjar.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-NDJAR'
                                 ls_upload-ndjar1.
    ENDIF.

    IF ls_upload-ndper1 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-NDPER'
                                 ls_asset-ndper.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-NDPER'
                              ls_upload-ndper1.
    ENDIF.

    IF ls_upload-afabg1 IS INITIAL.
      DATA(lv_final_date) = ls_asset-afabg+6(2) && '.' &&
                            ls_asset-afabg+4(2) && '.' &&
                            ls_asset-afabg(4).
      PERFORM bdc_field       USING 'ANLB-AFABG'
                              lv_final_date.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-AFABG'
                              ls_upload-afabg1.
    ENDIF.

*    PERFORM bdc_field       USING 'ANLB-NDURJ'
*                                  ls_upload-ndurj1.
    PERFORM bdc_field       USING 'ANLB-SCHRW'
                                  ls_upload-schrw1.
    PERFORM bdc_field       USING 'ANLB-SCHRW_PROZ'
                                  ls_upload-schrw_proz1.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=SELZ'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-AFASL(02)'.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '0195'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BUCH'. "'=RW'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-SCHRW_PROZ'.

    CLEAR ls_asset.
    READ TABLE lt_asset INTO ls_asset WITH KEY anln1 = ls_upload-anln1
                                               afabe = '15'.

    IF ls_upload-afasl2 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-AFASL'
                               ls_asset-afasl.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-AFASL'
                              ls_upload-afasl2.
    ENDIF.

    IF ls_upload-ndjar2 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-NDJAR'
                                ls_asset-ndjar.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-NDJAR'
                              ls_upload-ndjar2.
    ENDIF.

    IF ls_upload-ndper2 IS INITIAL.
      PERFORM bdc_field       USING 'ANLB-NDPER'
                               ls_asset-ndper.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-NDPER'
                              ls_upload-ndper2.
    ENDIF.

    IF ls_upload-afabg2 IS INITIAL.
      lv_final_date = ls_asset-afabg+6(2) && '.' &&
                            ls_asset-afabg+4(2) && '.' &&
                            ls_asset-afabg(4).
      PERFORM bdc_field       USING 'ANLB-AFABG'
                               lv_final_date.
    ELSE.
      PERFORM bdc_field       USING 'ANLB-AFABG'
                              ls_upload-afabg2.
    ENDIF.

*    PERFORM bdc_field       USING 'ANLB-NDURJ'
*                                  ls_upload-ndurj2.
    PERFORM bdc_field       USING 'ANLB-SCHRW'
                                  ls_upload-schrw2.
    PERFORM bdc_field       USING 'ANLB-SCHRW_PROZ'
                                  ls_upload-schrw_proz2.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BUCH'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ANLB-AFASL(01)'.

    PERFORM bdc_transaction USING 'AS02'.

  ENDLOOP.

FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.                    "BDC_DYNPRO

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM.

FORM bdc_transaction  USING tcode.
  REFRESH messtab.

  w_param-dismode  = p_mode.  " Display Mode: 'N' (No display), 'E' (Errors only), 'A' (All screens)
  w_param-updmode  = 'S'.  " Update Mode: 'S' (Synchronous), 'A' (Asynchronous), 'L' (Local)
  w_param-defsize  = 'X'.  " Use default window size (Critical for transactions with Table Controls)
  w_param-racommit = 'X'.  " COMMIT WORK does not end the transaction
  w_param-nobinpt  = 'X'.  " SY-BINPT = SPACE in the called transaction

  CALL TRANSACTION tcode USING bdcdata
                     OPTIONS FROM w_param
*                   MODE   ctumode
*                   UPDATE cupdate
                   MESSAGES INTO messtab.
  l_subrc = sy-subrc.

  WRITE: / 'CALL_TRANSACTION',
           tcode,
           'returncode:'(i05),
           l_subrc,
           'RECORD:',
           sy-index.
  LOOP AT messtab.
    SELECT SINGLE * FROM t100 WHERE sprsl = @messtab-msgspra
                              AND   arbgb = @messtab-msgid
                              AND   msgnr = @messtab-msgnr
      INTO @DATA(lv_t100).
    IF sy-subrc = 0.
      l_mstring = lv_t100-text.
      IF l_mstring CS '&1'.
        REPLACE '&1' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&2' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&3' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&4' WITH messtab-msgv4 INTO l_mstring.
      ELSE.
        REPLACE '&' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv4 INTO l_mstring.
      ENDIF.
      CONDENSE l_mstring.
      WRITE: / messtab-msgtyp, l_mstring(250).
    ELSE.
      WRITE: / messtab.
    ENDIF.
  ENDLOOP.
  SKIP.

  REFRESH bdcdata.

ENDFORM.
FORM download_template.

  DATA: lt_header_tab TYPE TABLE OF string,
        lv_header_str TYPE string,
        lv_filename   TYPE string,
        lv_path       TYPE string,
        lv_fullpath   TYPE string.

  CONCATENATE 'Asset Number' 'Subnumber' 'Company Code'  'Description' 'Description1' 'Serial number'
              'Quantity' 'Base Unit' 'Capitalized on' 'Inventory number' 'Asset main Text'
              'Cost center' 'Plant' 'Location' 'Buisness Area' 'Activity Type' 'Building/Room No.'
              'License plate number' 'Asset Super Number' 'Vendor' 'Type Name' 'Manufacturer' 'Block Key'
              'Asset put to use' 'Dep. Key 01' 'Useful life 01' 'Periods 01' 'Ord.dep.Start 01'
              'Scrap value01' 'Scrap percentage01' 'Dep. Key 15' 'Useful life 15' 'Periods 15'
              'Ord.dep.Start 15' 'Scrap value' 'Scrap percentage'

    INTO lv_header_str SEPARATED BY cl_abap_char_utilities=>horizontal_tab.

  APPEND lv_header_str TO lt_header_tab.

  " File save dialog
  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      default_file_name = 'Asset_change.xls'
      file_filter       = 'Excel Files (*.xls)|*.xls'
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fullpath.

  IF lv_fullpath IS NOT INITIAL.
    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        filename              = lv_fullpath
        write_field_separator = ' '
      CHANGING
        data_tab              = lt_header_tab
      EXCEPTIONS
        OTHERS                = 1.

    IF sy-subrc = 0.
      MESSAGE 'Template downloaded successfully.' TYPE 'S'.
    ENDIF.
  ENDIF.
ENDFORM.
