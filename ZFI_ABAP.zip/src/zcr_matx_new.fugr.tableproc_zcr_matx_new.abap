*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCR_MATX_NEW
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCR_MATX_NEW        .

  PERFORM TABLEPROC.

ENDFUNCTION.
