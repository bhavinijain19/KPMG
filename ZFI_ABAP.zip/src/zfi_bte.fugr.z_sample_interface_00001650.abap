FUNCTION Z_SAMPLE_INTERFACE_00001650.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_POSTAB) LIKE  RFPOS STRUCTURE  RFPOS
*"  EXPORTING
*"     VALUE(E_POSTAB) LIKE  RFPOS STRUCTURE  RFPOS
*"--------------------------------------------------------------------

*-------------- Initialize Output by using the following line ----------
* E_POSTAB = I_POSTAB.

*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_POSTAB) LIKE  RFPOS STRUCTURE  RFPOS
*"  EXPORTING
*"     VALUE(E_POSTAB) LIKE  RFPOS STRUCTURE  RFPOS
*"----------------------------------------------------------------------

*-------------- Initialize Output by using the following line ----------

  e_postab = i_postab.
  DATA : lv_prctr TYPE prctr.
  DATA: lv_wsl TYPE faglflexa-wsl.
  DATA: lv_docln(06).
**********Comment by parth 08/06/2019 All profit center come in below query (faglflexa table)
*   where no GL / Material related opposit line items are in document, ZZPRCTR remains initial a
*  nd hence failed in authorisation check for object K_PCAR_REP if authorisation for blank Profir center is not available
*****
*  SELECT SINGLE prctr
*                FROM bseg
*                INTO lv_prctr
*                WHERE bukrs = i_postab-bukrs
*                  AND belnr = i_postab-belnr
*                  AND gjahr = i_postab-gjahr
*                  AND ( koart = 'S' OR koart = 'M')."GL Posting.
**  IF sy-subrc EQ 0. "comment by parth 08/06/2019
*    if lv_prctr is not INITIAL. "add by parth 08/06/2019
*    e_postab-zzprctr = lv_prctr.
*******************    end by parth 08/06/2019
*************************    Add by parth 08/06/2019 for General ledger view Profit center

  lv_docln = i_postab-buzei.

*  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*    EXPORTING
*      input  = lv_docln
*    IMPORTING
*      output = lv_docln.
*
*  SELECT SINGLE prctr
*              FROM faglflexa
*              INTO lv_prctr
*              WHERE ryear = i_postab-gjahr
*                AND docnr = i_postab-belnr
*                AND rldnr = '0L'
*                AND rbukrs = i_postab-bukrs
*                AND docln  = lv_docln.
*  IF sy-subrc EQ 0.
*    e_postab-zzprctr = lv_prctr.
*  ENDIF.
*  CLEAR: lv_prctr.

  IF i_postab-shkzg = 'S'.
    SELECT SINGLE MAX( wsl ) MAX( prctr )
           FROM faglflexa
           INTO (lv_wsl,lv_prctr)
           WHERE rldnr = '0L'
           AND   rbukrs = i_postab-bukrs
           AND   gjahr = i_postab-gjahr
           AND   belnr = i_postab-belnr
           AND   buzei = i_postab-buzei

           AND   wsl = ( SELECT MAX( wsl )
           FROM faglflexa
           WHERE rbukrs = i_postab-bukrs
           AND   gjahr = i_postab-gjahr
           AND   belnr = i_postab-belnr
           AND   buzei = i_postab-buzei )
          GROUP BY buzei.
*    IF SY-SUBRC = 0.
*      SELECT SINGLE PRCTR
*         FROM faglflexa
*         INTO (lv_prctr)
*         WHERE rldnr = '0L'
*         AND   rbukrs = i_postab-bukrs
*         AND   gjahr = i_postab-gjahr
*         AND   belnr = i_postab-belnr
*         AND   buzei = i_postab-buzei
*         AND   wsl = lv_wsl.
*    ENDIF.
    IF sy-subrc EQ 0.
      e_postab-zzprctr = lv_prctr.
    ENDIF.
  ELSE.
    SELECT SINGLE MIN( wsl ) MIN( prctr )
         FROM faglflexa
         INTO (lv_wsl,lv_prctr)
         WHERE rldnr = '0L'
         AND   rbukrs = i_postab-bukrs
         AND   gjahr = i_postab-gjahr
         AND   belnr = i_postab-belnr
         AND   buzei = i_postab-buzei
         AND    wsl = ( SELECT MIN( wsl )
        FROM faglflexa
        WHERE rbukrs = i_postab-bukrs
         AND   gjahr = i_postab-gjahr
         AND   belnr = i_postab-belnr
         AND   buzei = i_postab-buzei )
*
         GROUP BY buzei.

*    IF SY-SUBRC = 0.
*      SELECT SINGLE PRCTR
*         FROM faglflexa
*         INTO (lv_prctr)
*         WHERE rldnr = '0L'
*         AND   rbukrs = i_postab-bukrs
*         AND   gjahr = i_postab-gjahr
*         AND   belnr = i_postab-belnr
*         AND   buzei = i_postab-buzei
*         AND   wsl = lv_wsl.
*    ENDIF.

    IF sy-subrc EQ 0.
      e_postab-zzprctr = lv_prctr.
    ENDIF.
    CLEAR: lv_prctr.
  ENDIF.

*********************** added by parth 11.04.2023
  if e_postab-zzprctr  is INITIAL.
     e_postab-zzprctr =  e_postab-prctr.
  endif.
************************* ended by parth 11.04.2023
*************************  End by parth 08/06/2019 for General ledger view Profit center

  IF i_postab-qsshb NE 0.
*
*  IF e_postab-qbshb EQ 0.
*
    e_postab-qsshb = 0.

    e_postab-qbshb = 0.

    SELECT SINGLE SUM( wt_qsshb ) SUM( wt_qbshb )

    INTO (e_postab-qsshb, e_postab-qbshb)

    FROM with_item

    WHERE bukrs EQ i_postab-bukrs

    AND belnr EQ i_postab-belnr

    AND gjahr EQ i_postab-gjahr

    AND buzei EQ i_postab-buzei

    AND hkont NE ' '.

    IF sy-subrc NE 0.

      e_postab-qsshb = i_postab-qsshb.

      e_postab-qbshb = i_postab-qbshb.

    ENDIF.
  ENDIF.

* ***** Logic for customer filed in FBL3N.
* * Changes by Sayali on 08.07.2017

*  DATA : it_bseg  TYPE TABLE OF bseg,
*         wa_bseg  TYPE bseg,
*         lv_kunnr TYPE kunnr.
*  IF e_postab-customer IS INITIAL  AND e_postab-hkont = '0010029993'.
*
*    SELECT SINGLE kunnr      FROM bseg
*                    INTO lv_kunnr
*                    WHERE bukrs = i_postab-bukrs
*                      AND belnr = i_postab-belnr
*                      AND gjahr = i_postab-gjahr
*                              AND ( koart = 'D').
*    e_postab-customer = lv_kunnr.
*  ENDIF.

ENDFUNCTION.
