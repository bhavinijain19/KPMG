FUNCTION ZFI_CRM_LEDGER_CUST_RCL.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(BUKRS) TYPE  BUKRS
*"     VALUE(KUNNR) TYPE  KUNNR
*"     VALUE(FROM_BUDAT) TYPE  BUDAT
*"     VALUE(TO_BUDAT) TYPE  BUDAT
*"  EXPORTING
*"     VALUE(IT_FINAL) TYPE  ZTT_CUST_LEDGER
*"----------------------------------------------------------------------

  TYPES:BEGIN OF ty_final,
          bukrs      TYPE  bukrs,
          kunnr      TYPE  kunnr,
          name1      TYPE  txt50,
          umskz      TYPE  umskz,
          augbl      TYPE  augbl,
          augdt      TYPE  augdt,
          zuonr      TYPE  dzuonr,
          gjahr      TYPE  gjahr,
          belnr      TYPE  belnr_d,
          buzei      TYPE buzei,
          budat      TYPE  budat,
          bldat      TYPE  bldat,
          xblnr      TYPE  xblnr,
          blart      TYPE  blart,
          ltext      TYPE  ltext,
          bschl      TYPE  bschl,
          shkzg      TYPE  shkzg,
          mwskz      TYPE  mwskz,
          dmbtr      TYPE  dmbtr,
          wrbtr      TYPE  wrbtr,
          saknr      TYPE  saknr,
          txt50      TYPE  txt50,
          hkont      TYPE  hkont,
          debit      TYPE  dmbtr,
          credit     TYPE dmbtr,
          opening	   TYPE	dmbtr,
          closing	   TYPE	dmbtr,
          sgtxt	     TYPE	sgtxt,
          color(4)   TYPE c,
          prctr	     TYPE	prctr,
          werks	     TYPE	werks_d,
          plant	     TYPE	name1,
          ind1       TYPE char1,
          ind2       TYPE char1,
          amount     TYPE dmbtr,
          doctype	   TYPE	char30,
          debitusd   TYPE dmbtr,
          creditusd	 TYPE	dmbtr,
          closingusd TYPE dmbtr,
          waers	     TYPE	waers,
          ref1(40),
          vkorg      TYPE vkorg,
          prkey(100),
          due_dat    TYPE bsak-budat, "Added by Raj on 13.08.2024
        END OF ty_final.

  DATA:wa_final TYPE zst_cust_ledger.
*       it_final TYPE TABLE OF ty_final.

  DATA:v_date1  TYPE sy-datum,
       days     LIKE t5a4a-dlydy,
       v_cldate TYPE p0001-begda.

  DATA:wa_open TYPE bapi3007_3,
       it_open TYPE TABLE OF bapi3007_3.

  CONSTANTS: c_tvarvc    TYPE rvari_vnam VALUE 'Z_CRM_LDGR_CUSTRCL_VKORG', " Added on 12.08.2022
             c_type_user TYPE rsscr_kind VALUE 'S'.

  DATA : dbs TYPE dbcon-con_name.

  SELECT bukrs, kunnr, umskz, augdt, augbl, zuonr, gjahr, belnr, buzei, budat, bldat, waers, xblnr, blart,
           bschl, shkzg, mwskz, dmbtr, wrbtr, saknr, hkont, sgtxt, zbd1t FROM bsid INTO TABLE @DATA(it_bsid)
                                                           WHERE bukrs = @bukrs
                                                             AND kunnr = @kunnr
                                                             AND budat BETWEEN @from_budat AND @to_budat.

  SELECT bukrs, kunnr, umskz, augdt, augbl, zuonr, gjahr, belnr, buzei, budat, bldat, waers, xblnr, blart,
         bschl, shkzg, mwskz, dmbtr, wrbtr, saknr, hkont, sgtxt, zbd1t FROM bsad INTO TABLE @DATA(it_bsad)
                                                         WHERE bukrs = @bukrs
                                                           AND kunnr = @kunnr
                                                           AND budat BETWEEN @from_budat AND @to_budat.

  IF it_bsid IS NOT INITIAL.

    SELECT * FROM bkpf INTO TABLE @DATA(it_bkpf) FOR ALL ENTRIES IN @it_bsid
                                              WHERE bukrs = @it_bsid-bukrs
                                              AND   budat BETWEEN @from_budat AND @to_budat
                                              AND   belnr = @it_bsid-belnr.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*    SELECT bukrs, belnr, gjahr, augbl, zuonr, prctr, hkont FROM bseg INTO TABLE @DATA(it_bseg)
*                                                     FOR ALL ENTRIES IN @it_bkpf
*                                                     WHERE bukrs = @it_bkpf-bukrs
*                                                     AND belnr = @it_bkpf-belnr
*                                                     AND gjahr = @it_bkpf-gjahr
*                                                     AND prctr NE ' '.
 SELECT  COMPANYCODE AS BUKRS , ACCOUNTINGDOCUMENT AS BELNR ,
FISCALYEAR AS GJAHR , CLEARINGACCOUNTINGDOCUMENT AS AUGBL ,
ASSIGNMENTREFERENCE AS ZUONR , PROFITCENTER AS PRCTR , GLACCOUNT AS
HKONT FROM I_OPERATIONALACCTGDOCITEM INTO TABLE  @DATA(IT_BSEG)
FOR  ALL  ENTRIES  IN  @IT_BKPF  WHERE COMPANYCODE = @IT_BKPF-BUKRS AND
ACCOUNTINGDOCUMENT = @IT_BKPF-BELNR AND FISCALYEAR = @IT_BKPF-GJAHR AND
PROFITCENTER NE ' '.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
*                                                     AND bschl EQ '40'.

    SELECT kunnr, vkorg FROM knvv INTO TABLE @DATA(it_knvv)
                FOR ALL ENTRIES IN @it_bsid
                WHERE kunnr = @it_bsid-kunnr.

  ENDIF.

  IF it_bsad IS NOT INITIAL.
    SELECT * FROM bkpf INTO TABLE @DATA(it_bkpf1) FOR ALL ENTRIES IN @it_bsad
                                            WHERE bukrs = @it_bsad-bukrs
                                            AND   budat BETWEEN @from_budat AND @to_budat
                                            AND   belnr = @it_bsad-belnr.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*    SELECT bukrs, belnr, gjahr, augbl, zuonr, prctr, hkont FROM bseg INTO TABLE @DATA(it_bseg1)
*                                                     FOR ALL ENTRIES IN @it_bkpf1
*                                                     WHERE bukrs =  @it_bkpf1-bukrs
*                                                     AND belnr = @it_bkpf1-belnr
*                                                     AND gjahr = @it_bkpf1-gjahr
*                                                     AND prctr NE ' '.
 SELECT  COMPANYCODE AS BUKRS , ACCOUNTINGDOCUMENT AS BELNR ,
FISCALYEAR AS GJAHR , CLEARINGACCOUNTINGDOCUMENT AS AUGBL ,
ASSIGNMENTREFERENCE AS ZUONR , PROFITCENTER AS PRCTR , GLACCOUNT AS
HKONT FROM I_OPERATIONALACCTGDOCITEM INTO TABLE  @DATA(IT_BSEG1)
FOR  ALL  ENTRIES  IN  @IT_BKPF1  WHERE COMPANYCODE = @IT_BKPF1-BUKRS
AND ACCOUNTINGDOCUMENT = @IT_BKPF1-BELNR AND FISCALYEAR =
@IT_BKPF1-GJAHR AND PROFITCENTER NE ' '.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
*                                                     AND bschl EQ '50'.

    SELECT kunnr vkorg FROM knvv APPENDING TABLE it_knvv
                FOR ALL ENTRIES IN it_bsad
                WHERE kunnr = it_bsad-kunnr.
  ENDIF.

  SELECT saknr, txt50 FROM skat INTO TABLE @DATA(it_skat) WHERE spras EQ 'E'.

  SELECT blart, ltext FROM t003t INTO TABLE @DATA(it_t003t) WHERE spras EQ 'E'.

  SELECT werks, name1 FROM t001w INTO TABLE @DATA(it_t001w).

  SORT it_bsid BY kunnr budat.
  SORT it_bsad BY kunnr budat.

  LOOP AT it_bsid INTO DATA(wa_bsid).

*    IF p_open = 'X'. " opening balance
    AT NEW kunnr.

      CALL FUNCTION 'OIL_LAST_DAY_OF_PREVIOUS_MONTH'
        EXPORTING
          i_date_old = from_budat
        IMPORTING
          e_date_new = v_date1.


" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
      CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'"#EC CI_USAGE_OK[2628704]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
        EXPORTING
          companycode = wa_bsid-bukrs
          customer    = wa_bsid-kunnr
          keydate     = v_date1
        TABLES
          keybalance  = it_open.

      READ TABLE it_open INTO wa_open INDEX 1.
      IF sy-subrc EQ 0.

        wa_final-bukrs = wa_bsid-bukrs.
        wa_final-kunnr = wa_bsid-kunnr.
        wa_final-budat = v_date1.

        IF wa_open-lc_bal > 0.
          wa_final-debit = wa_open-lc_bal.
        ELSE.
          wa_final-credit = wa_open-lc_bal  * ( -1 ).
        ENDIF.

        wa_final-ltext = 'Opening Balance'.
        wa_final-color = 'C510'.
        APPEND wa_final TO it_final.
        CLEAR:wa_final,wa_open,v_date1.
      ENDIF.

    ENDAT.
*    ENDIF.

    MOVE-CORRESPONDING wa_bsid TO wa_final.

    READ TABLE it_bseg INTO DATA(wa_bseg) WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.

    IF sy-subrc EQ 0.

      wa_final-prctr = wa_bseg-prctr.
      wa_final-werks = wa_bseg-prctr+0(4).
      CLEAR:wa_bseg.

    ENDIF.

    READ TABLE it_t001w INTO DATA(wa_t001w) WITH KEY werks = wa_final-werks.
    IF sy-subrc EQ 0.

      wa_final-plant = wa_t001w-name1.
      CLEAR:wa_t001w.

    ENDIF.

    READ TABLE it_bkpf INTO DATA(wa_bkpf) WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.
    IF sy-subrc = 0.
      wa_final-ref1 = wa_bkpf-xblnr.
      CLEAR: wa_bkpf.
    ENDIF.

    IF wa_final-blart EQ 'DZ'.

      READ TABLE it_bseg INTO wa_bseg WITH KEY bukrs = wa_bsid-bukrs belnr = wa_bsid-belnr gjahr = wa_bsid-gjahr.

      IF sy-subrc EQ 0.
        wa_final-zuonr = wa_bseg-zuonr.
        wa_final-hkont = wa_bseg-hkont.
*        wa_final-prctr = wa_bseg-prctr.

        READ TABLE it_skat INTO DATA(wa_skat) WITH KEY saknr = wa_bseg-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ELSE.

        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bsid-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.
      ENDIF.

    ENDIF.

    IF wa_bsid-shkzg EQ 'S'.
      wa_final-debit = wa_bsid-dmbtr." * ( -1 ).

      IF wa_bsid-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt Reversal'.
      ELSEIF wa_bsid-blart EQ 'RV'.
        wa_final-ltext = 'Invoice'.
      ELSEIF wa_bsid-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsid-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note Reversal'.
      ELSEIF wa_bsid-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note'.
      ELSEIF wa_bsid-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ELSE.
      wa_final-credit = wa_bsid-dmbtr.

      IF wa_bsid-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt'.
      ELSEIF wa_bsid-blart EQ 'RV'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsid-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsid-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsid-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note Reversal'.
      ELSEIF wa_bsid-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ENDIF.

*    READ TABLE it_t003t INTO wa_t003t WITH KEY blart = wa_bsid-blart.
*    IF sy-subrc EQ 0.
*      wa_final-ltext = wa_t003t-ltext.
*    ENDIF.

    READ TABLE it_knvv INTO DATA(wa_knvv) WITH KEY kunnr = wa_bsid-kunnr.
    IF sy-subrc = 0.
      wa_final-vkorg = wa_knvv-vkorg.
    ENDIF.


*******************************Begin of changes Added by Raj on 13.08.2024*********************
    days = wa_bsid-zbd1t.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = wa_bsid-budat
        days      = days
        months    = 00
        signum    = '+'
        years     = 00
      IMPORTING
        calc_date = v_cldate.

    wa_final-due_dat = v_cldate.

******************************End of changes Added by Raj on 13.08.2024*********************


    APPEND wa_final TO it_final.
    CLEAR:wa_final,wa_bsid,wa_bseg,wa_knvv,v_cldate,days.

  ENDLOOP.

  LOOP AT it_bsad INTO DATA(wa_bsad).
*
*    IF p_open = 'X'.
    AT NEW kunnr.
      READ TABLE it_bsid INTO wa_bsid WITH KEY kunnr = wa_bsad-kunnr.
      IF sy-subrc EQ 0.

      ELSE.
        CALL FUNCTION 'OIL_LAST_DAY_OF_PREVIOUS_MONTH'
          EXPORTING
            i_date_old = from_budat
          IMPORTING
            e_date_new = v_date1.

" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
        CALL FUNCTION 'BAPI_AR_ACC_GETKEYDATEBALANCE'"#EC CI_USAGE_OK[2628704]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
          EXPORTING
            companycode = wa_bsad-bukrs
            customer    = wa_bsad-kunnr
            keydate     = v_date1
          TABLES
            keybalance  = it_open.

        READ TABLE it_open INTO wa_open INDEX 1.
        IF sy-subrc EQ 0.
          wa_final-bukrs = wa_bsad-bukrs.
          wa_final-kunnr = wa_bsad-kunnr.
          wa_final-budat = v_date1.

          IF wa_open-lc_bal > 0.
            wa_final-debit = wa_open-lc_bal.
          ELSE.
            wa_final-credit = wa_open-lc_bal  * ( -1 ).
          ENDIF.
          wa_final-ltext = 'Opening Balance'.
          wa_final-color = 'C510'.
          APPEND wa_final TO it_final.
          CLEAR:wa_final,wa_open,v_date1.
        ENDIF.

      ENDIF.
    ENDAT.
*    ENDIF.

    MOVE-CORRESPONDING wa_bsad TO wa_final.

    READ TABLE it_bseg1 INTO DATA(wa_bseg1) WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
    IF sy-subrc EQ 0.

      wa_final-prctr = wa_bseg1-prctr.
      wa_final-werks = wa_bseg1-prctr+0(4).
      CLEAR:wa_bseg1.

    ENDIF.

    READ TABLE it_t001w INTO wa_t001w WITH KEY werks = wa_final-werks.
    IF sy-subrc EQ 0.

      wa_final-plant = wa_t001w-name1.
      CLEAR:wa_t001w.

    ENDIF.

    READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
    IF sy-subrc = 0.
      wa_final-ref1 = wa_bkpf-xblnr.

      CLEAR: wa_bkpf.
    ENDIF.



    IF wa_final-blart EQ 'DZ'.

      READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY bukrs = wa_bsad-bukrs belnr = wa_bsad-belnr gjahr = wa_bsad-gjahr.
      IF sy-subrc EQ 0.
        wa_final-zuonr = wa_bseg1-zuonr.
        wa_final-hkont = wa_bseg1-hkont.
*        wa_final-prctr = wa_bseg1-prctr.

        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bseg1-hkont.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ELSE.
        READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bsad-saknr.
        IF sy-subrc EQ 0.
          wa_final-txt50 = wa_skat-txt50.
          CLEAR:wa_skat.
        ENDIF.

      ENDIF.

    ENDIF.

    IF wa_bsad-shkzg EQ 'S'.
      wa_final-debit = wa_bsad-dmbtr." * ( -1 ).

      IF wa_bsad-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt Reversal'.
      ELSEIF wa_bsad-blart EQ 'RV'.
        wa_final-ltext = 'Invoice'.
      ELSEIF wa_bsad-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsad-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note Reversal'.
      ELSEIF wa_bsad-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note'.
      ELSEIF wa_bsad-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.

    ELSE.
      wa_final-credit = wa_bsad-dmbtr.

      IF wa_bsad-blart EQ 'DZ'.
        wa_final-ltext = 'Receipt'.
      ELSEIF wa_bsad-blart EQ 'RV'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsad-blart EQ 'AB'.
        wa_final-ltext = 'Accounting Document'.
      ELSEIF wa_bsad-blart EQ 'DG'.
        wa_final-ltext = 'Credit Note'.
      ELSEIF wa_bsad-blart EQ 'DR'.
        wa_final-ltext = 'Debit Note Reversal'.
      ELSEIF wa_bsad-blart EQ 'UE'.
        wa_final-ltext = 'Opening'.
      ENDIF.


    ENDIF.

*      READ TABLE it_t003t INTO wa_t003t WITH KEY blart = wa_bsad-blart.
*      IF sy-subrc EQ 0.
*        wa_final-ltext = wa_t003t-ltext.
*      ENDIF.

    READ TABLE it_knvv INTO wa_knvv WITH KEY kunnr = wa_bsad-kunnr.
    IF sy-subrc = 0.
      wa_final-vkorg = wa_knvv-vkorg.
    ENDIF.


*    *******************************Begin of changes Added by Raj on 13.08.2024*********************
    days = wa_bsad-zbd1t.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = wa_bsad-budat
        days      = days
        months    = 00
        signum    = '+'
        years     = 00
      IMPORTING
        calc_date = v_cldate.

    wa_final-due_dat = v_cldate.

******************************End of changes Added by Raj on 13.08.2024*********************


    APPEND wa_final TO it_final.
    CLEAR:wa_final,wa_bsad,wa_bseg1,wa_knvv,v_cldate,days.


  ENDLOOP.
*****  Added by Carina Jose on 12.08.2022
* SELECT SINGLE low
*     INTO v_prctr
*     FROM tvarvc
*     WHERE name = c_tvarvc .

  SELECT sign,
           opti,
           low,
           high INTO TABLE @DATA(it_tvarvc)
              FROM tvarvc
              WHERE name = @c_tvarvc AND
                    type = @c_type_user.



  DELETE it_final WHERE vkorg NOT IN it_tvarvc.

*****  End of changes on 12.08.2022



  SELECT kunnr, name1, name2, ort01 FROM kna1 INTO TABLE @DATA(it_kna1) FOR ALL ENTRIES IN @it_final WHERE kunnr = @it_final-kunnr.

*  SORT it_final BY kunnr budat.
*  SORT IT_FINAL BY KUNNR BLDAT.

*  DATA:wa_final1 TYPE zss_fi_ledger_customer,
*       it_final1 TYPE TABLE OF  zss_fi_ledger_customer. "ZTT_FI_LEDGER_CUSTOMER.

*  DATA:v_closing1 TYPE bsid-dmbtr.

*  it_final1[] = it_final[].

*  SORT it_final1 BY kunnr budat.
*  SORT IT_FINAL1 BY KUNNR BLDAT.

*  DELETE ADJACENT DUPLICATES FROM it_final1 COMPARING kunnr.

  SORT it_final BY kunnr budat.

**  IF p_chk EQ 'X'.
**
**    LOOP AT it_final INTO wa_final.
**
**      v_debit = wa_final-debit.
**      v_credit = wa_final-credit.
**
**      AT NEW kunnr.
**        v_total = v_total + v_debit - v_credit.
**        wa_final-ind1 = 'X'.
**        MODIFY it_final FROM wa_final TRANSPORTING ind1.
**      ENDAT.
**
**      AT LAST.
**        DELETE it_final WHERE ind1 EQ 'X'.
**      ENDAT.
**
**    ENDLOOP.
**
**    LOOP AT it_final INTO wa_final.
**      v_customer = wa_final-kunnr.
**      v_text     = 'Opening Balance'.
**
**      AT FIRST.
**        CLEAR:wa_final.
**        wa_final-kunnr = v_customer.
**        wa_final-ltext = v_text.
**        IF v_total LT 0.
**          wa_final-credit = v_total.
**        ELSE.
**          wa_final-debit = v_total.
**        ENDIF.
**        wa_final-color = 'C510'.
**        APPEND wa_final TO it_final.
**      ENDAT.
**    ENDLOOP.
**
**    SORT it_final BY kunnr budat.
**
**    LOOP AT it_final INTO wa_final.
**
**      READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
**      IF sy-subrc EQ 0.
**
**        CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name1 SEPARATED BY ' '.
***      wa_final-name1 = wa_kna1-name1.
**        MODIFY it_final FROM wa_final TRANSPORTING name1.
**        CLEAR:wa_kna1.
**      ENDIF.
**
**      IF wa_final-debit IS NOT INITIAL.
**        wa_final-closing = v_closing + wa_final-debit.
**        v_closing = wa_final-closing.
**      ELSE.
**        IF v_closing IS NOT INITIAL.
**          wa_final-closing = v_closing - wa_final-credit.
**          v_closing = wa_final-closing.
**        ELSE.
**          wa_final-closing = v_closing - wa_final-credit * ( -1 ).
**          v_closing = wa_final-closing.
**        ENDIF.
**      ENDIF.
**
**      CONCATENATE wa_final-blart wa_final-kunnr wa_final-belnr wa_final-budat wa_final-bukrs wa_final-buzei INTO wa_final-prkey.
**
**      MODIFY it_final FROM wa_final TRANSPORTING closing prkey.
**
***    AT END OF kunnr.
***      CLEAR:wa_final, v_closing.
***
***    ENDAT.
**
**    ENDLOOP.
**  ELSE.
**
**    SORT it_final BY kunnr budat.
**    LOOP AT it_final INTO wa_final.
**
**      READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
**      IF sy-subrc EQ 0.
**
**        CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name1 SEPARATED BY ' '.
***      wa_final-name1 = wa_kna1-name1.
**        MODIFY it_final FROM wa_final TRANSPORTING name1.
**        CLEAR:wa_kna1.
**      ENDIF.
**
**      IF wa_final-debit IS NOT INITIAL.
**        wa_final-closing = v_closing + wa_final-debit.
**        v_closing = wa_final-closing.
**      ELSE.
**        wa_final-closing = v_closing - wa_final-credit.
**        v_closing = wa_final-closing.
**      ENDIF.
**      wa_final-amount = '0.00'.
**      CONCATENATE wa_final-blart '/' wa_final-belnr INTO wa_final-doctype.
**      SHIFT wa_final-kunnr LEFT DELETING LEADING '0'.
**      wa_final-kunnr = wa_final-kunnr.
**
**      CONCATENATE wa_final-blart wa_final-kunnr wa_final-belnr wa_final-budat wa_final-bukrs wa_final-buzei INTO wa_final-prkey.
**      MODIFY it_final FROM wa_final TRANSPORTING closing amount doctype kunnr prkey .
**
**      AT END OF kunnr.
**        CLEAR:wa_final, v_closing.
**      ENDAT.
**    ENDLOOP.
**  ENDIF.

*  SORT it_final BY kunnr budat.

*  LOOP AT it_final INTO wa_final.
*
*    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
*    IF sy-subrc EQ 0.
*
*      CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name1 SEPARATED BY ' '.
**      wa_final-name1 = wa_kna1-name1.
*      MODIFY it_final FROM wa_final TRANSPORTING name1.
*      CLEAR:wa_kna1.
*    ENDIF.
*
*    IF wa_final-debit IS NOT INITIAL.
*      wa_final-closing = v_closing + wa_final-debit.
*      v_closing = wa_final-closing.
*    ELSE.
*      wa_final-closing = v_closing - wa_final-credit.
*      v_closing = wa_final-closing.
*    ENDIF.
*    MODIFY it_final FROM wa_final TRANSPORTING closing.
*
**    AT END OF kunnr.
**      CLEAR:wa_final, v_closing.
**
**    ENDAT.
*
*  ENDLOOP.

* dbs = 'MSSQL1'.
**  dbs = 'MSSQL2'.
**
**  EXEC SQL.
**    CONNECT TO :DBS
**  ENDEXEC.
**
**  IF bukrs = '1000'.
**
**    LOOP AT it_final INTO wa_final.
**      IF wa_flag = 0.
**        EXEC SQL.
**
**          DELETE FROM S_TransdistLedger_rcl
**
**        ENDEXEC.
**        wa_flag = 1.
**      ENDIF.
**
**      EXEC SQL.
**
**        insert into S_TransdistLedger_rcl
**        ( PrimaryID,DocId,DistributorSynchid,PostingDate,Narration,Amount,crAmount,DrAmount,CompanyCode,ref1,ass,due_dat,SPGLIND )
**
**        values  ( :wa_final-prkey,:wa_final-doctype, :wa_final-kunnr, :wa_final-budat, :wa_final-sgtxt,
**                  :wa_final-amount, :wa_final-credit,:wa_final-debit, :wa_final-bukrs,:wa_final-ref1,:wa_final-zuonr,
**                  :wa_final-due_dat,:wa_final-umskz )
**
**
***      insert into tmp_socd_pend_order  (ordsr_no,order_date,order_no,pcode,bchcd,it_code,unit,itqty,pndqty,itr,amount,itsrno,netamount)
***      values  ( :wa_final-vbeln,:wa_final-erdat,:wa_final-bstkd,:wa_final-kunnr,:wa_final-werks,:wa_final-matnr,:wa_final-vrkme,:wa_final-kbmeng,:wa_final-amount,:wa_final-netwr,:wa_final-posnr,:wa_final-gross )
**
**      ENDEXEC.
***    endif.
**    ENDLOOP.
**
**  ELSEIF s_bukrs-low = '7000'.
**
**    LOOP AT it_final INTO wa_final.
**      IF wa_flag = 0.
**        EXEC SQL.
**
**          DELETE FROM S_TransdistLedger_gem
**
**        ENDEXEC.
**        wa_flag = 1.
**      ENDIF.
**
**      EXEC SQL.
**
**        insert into S_TransdistLedger_gem
**        ( PrimaryID,DocId,DistributorSynchid,PostingDate,Narration,Amount,crAmount,DrAmount,CompanyCode,ref1,ass,due_dat,SPGLIND )
**
**        values  ( :wa_final-prkey, :wa_final-doctype, :wa_final-kunnr, :wa_final-budat, :wa_final-sgtxt,
**                  :wa_final-amount, :wa_final-credit,:wa_final-debit, :wa_final-bukrs,:wa_final-ref1,:wa_final-zuonr,
**                  :wa_final-due_dat, :wa_final-umskz )
**
**
***      insert into tmp_socd_pend_order  (ordsr_no,order_date,order_no,pcode,bchcd,it_code,unit,itqty,pndqty,itr,amount,itsrno,netamount)
***      values  ( :wa_final-vbeln,:wa_final-erdat,:wa_final-bstkd,:wa_final-kunnr,:wa_final-werks,:wa_final-matnr,:wa_final-vrkme,:wa_final-kbmeng,:wa_final-amount,:wa_final-netwr,:wa_final-posnr,:wa_final-gross )
**
**      ENDEXEC.
***    endif.
**    ENDLOOP.
**  ENDIF.
***SORT IT_FINAL BY PRTDTL.
**  WRITE:/  'Update Successfully'.


ENDFUNCTION.
