*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_OD_KDGRPTOP.                  " Global Declarations
  INCLUDE LZFI_OD_KDGRPUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_OD_KDGRPF...                  " Subroutines
* INCLUDE LZFI_OD_KDGRPO...                  " PBO-Modules
* INCLUDE LZFI_OD_KDGRPI...                  " PAI-Modules
* INCLUDE LZFI_OD_KDGRPE...                  " Events
* INCLUDE LZFI_OD_KDGRPP...                  " Local class implement.
* INCLUDE LZFI_OD_KDGRPT99.                  " ABAP Unit tests
  INCLUDE LZFI_OD_KDGRPF00                        . " subprograms
  INCLUDE LZFI_OD_KDGRPI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
