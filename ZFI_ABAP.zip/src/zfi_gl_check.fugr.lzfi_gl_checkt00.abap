*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GL_CHECK....................................*
DATA:  BEGIN OF STATUS_ZFI_GL_CHECK                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GL_CHECK                  .
CONTROLS: TCTRL_ZFI_GL_CHECK
            TYPE TABLEVIEW USING SCREEN '9999'.
*.........table declarations:.................................*
TABLES: *ZFI_GL_CHECK                  .
TABLES: ZFI_GL_CHECK                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
