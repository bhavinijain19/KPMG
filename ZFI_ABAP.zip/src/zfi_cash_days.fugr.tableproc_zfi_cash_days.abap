*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_CASH_DAYS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_CASH_DAYS       .

  PERFORM TABLEPROC.

ENDFUNCTION.
