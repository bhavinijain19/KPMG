"Name: \TY:CL_MRM_TM_SERVICES\ME:READ_RSEG_TM\SE:END\EI
ENHANCEMENT 0 ZFI_CUSTOMS_VAL_NEW.

FIELD-SYMBOLS : <lx_desreg> TYPE mmcr_drseg .
FIELD-SYMBOLS :<lx_ebeln> TYPE ebeln .
DATA : lv_knumv TYPE knumv .
DATA : lv_wkurs TYPE wkurs,
       lv_kwert TYPE kwert.

IF ct_drseg IS NOT INITIAL .
  READ TABLE ct_drseg ASSIGNING <lx_desreg> INDEX 1.
  IF <lx_desreg> IS ASSIGNED .
    SELECT SINGLE wkurs knumv FROM ekko INTO (lv_wkurs , lv_knumv) WHERE ebeln = <lx_desreg>-ebeln.
    IF sy-subrc EQ 0 .
      SELECT SINGLE kwert FROM prcd_elements INTO lv_kwert WHERE knumv = lv_knumv
                                                   AND kschl = 'ZSAV'.

      IF sy-subrc EQ 0.
        <lx_desreg>-customs_val = lv_kwert * lv_wkurs.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.

ENDENHANCEMENT.
