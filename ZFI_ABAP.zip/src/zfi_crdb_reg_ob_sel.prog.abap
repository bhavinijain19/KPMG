*&---------------------------------------------------------------------*
*& Include          ZFI_CRDB_REG_OB_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_belnr FOR bkpf-belnr,
                  s_budat FOR bkpf-budat NO-DISPLAY,
                  s_bukrs FOR bkpf-bukrs OBLIGATORY,
                  s_vkorg FOR knvv-vkorg OBLIGATORY,
                  s_gjahr FOR j_1iexchdr-docyr NO-EXTENSION NO INTERVALS OBLIGATORY,
                  s_kunnr FOR kna1-kunnr,
                  s_lifnr FOR lfa1-lifnr.
  PARAMETERS: p_mins  TYPE i DEFAULT 30.
  PARAMETERS: v_cr RADIOBUTTON GROUP rad1 DEFAULT 'X'.
  PARAMETERS: v_dr RADIOBUTTON GROUP rad1.
  PARAMETERS: p_date AS CHECKBOX.
  PARAMETERS: p_cpi AS CHECKBOX.
SELECTION-SCREEN : END OF BLOCK a1.
