*&---------------------------------------------------------------------*
*& Report ZFI_CRDB_REG_OB
*&---------------------------------------------------------------------*
*       MODULE : Finance                                               *
*----------------------------------------------------------------------*
*       Objective : Credit and Debit note sending to CPI               *
*       Program   : Updates Tables ( X )     Downloads data (  )       *
*                   Outputs List   (   )                               *
*                                                                      *
*                                                                      *
*       Date Created :    13.03.2026                                   *
*       Instructed by:    KPMG - Rajesh Vaghasiya                      *
*       Devloped by:      KPMG - Bhaumik Patel                         *
*                                                                      *
*----------------------------------------------------------------------*
*       External Dependencies                                          *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
* Amendment History                                                    *
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR                  CR/ID            *
*......................................................................*
* <001>   Bhaumik Patel         DEVK904081                             *
* Reason: Credit and Debit note sending to CPI                         *
*......................................................................*
* <002>                                                                *
* Reason:                                                              *
*----------------------------------------------------------------------*
REPORT zfi_crdb_reg_ob.

INCLUDE zfi_crdb_reg_ob_top.
INCLUDE zfi_crdb_reg_ob_sel.
INCLUDE zfi_crdb_reg_ob_main.

*---------------------------------------------------------------------*
* START-OF-SELECTION
*---------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM fetch_data.

  IF it_final IS NOT INITIAL.
    IF p_cpi IS NOT INITIAL.
      PERFORM call_cpi_utility.
    ENDIF.
    PERFORM display.
  ENDIF.
