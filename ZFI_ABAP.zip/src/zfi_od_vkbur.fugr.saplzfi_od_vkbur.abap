*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_OD_VKBURTOP.                  " Global Declarations
  INCLUDE LZFI_OD_VKBURUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_OD_VKBURF...                  " Subroutines
* INCLUDE LZFI_OD_VKBURO...                  " PBO-Modules
* INCLUDE LZFI_OD_VKBURI...                  " PAI-Modules
* INCLUDE LZFI_OD_VKBURE...                  " Events
* INCLUDE LZFI_OD_VKBURP...                  " Local class implement.
* INCLUDE LZFI_OD_VKBURT99.                  " ABAP Unit tests
  INCLUDE LZFI_OD_VKBURF00                        . " subprograms
  INCLUDE LZFI_OD_VKBURI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
