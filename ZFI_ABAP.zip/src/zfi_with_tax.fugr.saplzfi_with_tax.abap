*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_WITH_TAXTOP.                  " Global Declarations
  INCLUDE LZFI_WITH_TAXUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_WITH_TAXF...                  " Subroutines
* INCLUDE LZFI_WITH_TAXO...                  " PBO-Modules
* INCLUDE LZFI_WITH_TAXI...                  " PAI-Modules
* INCLUDE LZFI_WITH_TAXE...                  " Events
* INCLUDE LZFI_WITH_TAXP...                  " Local class implement.
* INCLUDE LZFI_WITH_TAXT99.                  " ABAP Unit tests
