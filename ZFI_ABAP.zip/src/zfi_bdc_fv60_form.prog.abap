*&---------------------------------------------------------------------*
*& Include          ZFI_BDC_FV60_FORM
*&---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* GUI_UPLOAD (Excel → internal table) – mirrors your reference approach
*---------------------------------------------------------------------*
FORM gui_upload .
  DATA: p_fname1 TYPE rlgrap-filename,
        it_type  TYPE truxs_t_text_data.

  CLEAR filename.
  filename  = p_fname.
  p_fname1  = filename.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_fname1
    TABLES
      i_tab_converted_data = itab
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error In Uploading File' TYPE 'E' DISPLAY LIKE 'S'.
    RETURN.
  ENDIF.
ENDFORM. " gui_upload

*---------------------------------------------------------------------*
* BDC helpers (EXACT same signatures/names as you already use)
*---------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. " bdc_dynpro

FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM. " bdc_field

*---------------------------------------------------------------------*
* Helper: 2-digit index text for ACGL subscript: (01), (02), ...
*---------------------------------------------------------------------*

FORM idx2 USING    p_idx TYPE i
          CHANGING p_c2  TYPE char2.

  p_c2 = |{ p_idx WIDTH = 2 ALIGN = RIGHT PAD = '0' }|.

ENDFORM.


FORM bdc_fill_item_grid USING p_item TYPE ty_itab
                              p_idx  TYPE i.

  DATA: lv_i TYPE char2,
        lv_f TYPE bdc_fnam.

  PERFORM idx2 USING p_idx CHANGING lv_i.

  " All on SAPMF05A 1100; do NOT leave this dynpro here
  PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
  lv_f = |ACGL_ITEM-HKONT({ lv_i })|.
  PERFORM bdc_field  USING 'BDC_CURSOR' lv_f.
  PERFORM bdc_field USING lv_f p_item-hkont_01.


  lv_f = |ACGL_ITEM-WRBTR({ lv_i })|.
  DATA(lv_amt) = p_item-wrbtr_01.
  REPLACE ALL OCCURRENCES OF ',' IN lv_amt WITH ''.
  PERFORM bdc_field USING lv_f lv_amt.
  " lv_hdr_amt1 = lv_amt +  lv_hdr_amt1.

  p_item-mwskz_item = |{ p_item-mwskz_item ALPHA = IN }|.
  lv_f = |ACGL_ITEM-MWSKZ({ lv_i })|.
  PERFORM bdc_field USING lv_f p_item-mwskz_item."dj

  lv_f = |ACGL_ITEM-ZUONR({ lv_i })|.
  PERFORM bdc_field USING lv_f p_item-zuonr_01.

  lv_f = |ACGL_ITEM-SGTXT({ lv_i })|.
  PERFORM bdc_field USING lv_f p_item-sgtxt_01.

  lv_f = |ACGL_ITEM-HSN_SAC({ lv_i })|.
  PERFORM bdc_field USING lv_f p_item-hsn_sac_01.

  lv_f = |ACGL_ITEM-GSBER({ lv_i })|.
  PERFORM bdc_field  USING  lv_f p_item-gsber_01.
  lv_f = |ACGL_ITEM-KOSTL({ lv_i })|.
  PERFORM bdc_field  USING  lv_f p_item-kostl_01.



ENDFORM.
FORM bdc_open_item_detail USING p_item TYPE ty_itab
                                p_idx  TYPE i
                                p_hdr  TYPE ty_itab.

  DATA: lv_i   TYPE char2,
        lv_f   TYPE bdc_fnam,
        lv_amt TYPE char20.


  PERFORM idx2 USING p_idx CHANGING lv_i.

  "---- Select row n on 1100 and open detail with =PICK (double-click)

  "PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
  lv_f = |ACGL_ITEM-HKONT({ lv_i })|.
  PERFORM bdc_field  USING 'BDC_CURSOR' lv_f.
***  " PERFORM bdc_field  USING 'BDC_OKCODE' '=PICK'.

  "---- Now we're on 0300 for row n
  PERFORM bdc_dynpro USING 'SAPMF05A' '0300'.
  PERFORM bdc_field  USING 'BDC_CURSOR' 'BSEG-BUPLA'.
  PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.

  lv_amt = p_item-wrbtr_01.
  REPLACE ALL OCCURRENCES OF ',' IN lv_amt WITH ''.

  PERFORM bdc_field  USING 'BSEG-WRBTR' lv_amt.
  "  lv_hdr_amt1 = lv_amt +  lv_hdr_amt1.
  p_item-mwskz_item = |{ p_item-mwskz_item ALPHA = IN }|.
  PERFORM bdc_field  USING 'BSEG-MWSKZ' p_item-mwskz_item. "dj
  PERFORM bdc_field  USING 'BKPF-XMWST' p_hdr-xmwst.
  PERFORM bdc_field  USING 'BSEG-BUPLA' p_hdr-bupla.
  PERFORM bdc_field  USING 'BSEG-ZUONR' p_item-zuonr_01.
  PERFORM bdc_field  USING 'BSEG-SGTXT' p_item-sgtxt_01.
  PERFORM bdc_field  USING 'DKACB-FMORE' 'X'.

  "---- COBL (cost assignment)
  PERFORM bdc_dynpro USING 'SAPLKACB' '0002'.
  PERFORM bdc_field  USING 'BDC_CURSOR' 'COBL-GSBER'.
  PERFORM bdc_field  USING 'BDC_OKCODE' '=ENTE'.
  PERFORM bdc_field  USING 'COBL-GSBER' p_item-gsber_01.
  PERFORM bdc_field  USING 'COBL-KOSTL' p_item-kostl_01.
 "   PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.

  "---- Back to 0300 -> return to 1100
  PERFORM bdc_dynpro USING 'SAPMF05A' '0300'.
  PERFORM bdc_field  USING 'BDC_CURSOR' 'BSEG-WRBTR'.
  PERFORM bdc_field  USING 'BDC_OKCODE' '=RW'.



ENDFORM.
*---------------------------------------------------------------------*
* Execute BDC for one document:
*  - If FM 'BDC_PROCESS' exists in your system, call it
*  - Else fallback to CALL TRANSACTION
*---------------------------------------------------------------------*
FORM run_bdc_transaction .
DATA: w_param TYPE ctu_params.
  DATA: lv_exists TYPE c.
   w_param-dismode  = ctu_mode.
  w_param-updmode  = 'S'.

"  w_param-racommit = 'X'.
"  w_param-defsize  = 'X'.
  "Fallback – standard approach
  CALL TRANSACTION p_tcode USING bdcdata
    OPTIONS FROM w_param
    MESSAGES INTO messtab.

  IF messtab[] IS INITIAL.

  ELSE.
    DATA: lv_text      TYPE string.
    LOOP AT messtab INTO DATA(ls_msg).
      IF ls_msg-msgnr = 001.
        WRITE: / 'Document Parked Successfully' , ls_msg-msgv1 .
      ELSEIF ( ls_msg-msgtyp = 'S' and ls_msg-MSGSPRA = 'E' ) OR ls_msg-msgtyp = 'E'.
        CALL FUNCTION 'FORMAT_MESSAGE'
          EXPORTING
            id        = ls_msg-msgid
            lang      = sy-langu
            no        = ls_msg-msgnr
            v1        = ls_msg-msgv1
            v2        = ls_msg-msgv2
            v3        = ls_msg-msgv3
            v4        = ls_msg-msgv4
          IMPORTING
            msg       = lv_text
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
        WRITE: / lv_text.
      ENDIF.
    ENDLOOP.
  ENDIF.



ENDFORM.
*---------------------------------------------------------------------*
* Convert CHAR amount ('1,000.00' or '1000.00') -> packed (ty_amount)
*---------------------------------------------------------------------*
FORM char_amount_to_p USING    p_char    TYPE char20
                      CHANGING p_amount TYPE ty_amount.

  DATA lv_char TYPE char20.

  lv_char = p_char.
  " remove thousand separators and spaces
  REPLACE ALL OCCURRENCES OF ',' IN lv_char WITH ''.
  CONDENSE lv_char NO-GAPS.

  " let ABAP convert to packed (will raise an exception only if invalid)
  p_amount = lv_char.

ENDFORM.
