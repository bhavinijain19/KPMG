*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_MAILID
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_MAILID          .

  PERFORM TABLEPROC.

ENDFUNCTION.
