*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PIPES_BANKTOP.                " Global Declarations
  INCLUDE LZFI_PIPES_BANKUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PIPES_BANKF...                " Subroutines
* INCLUDE LZFI_PIPES_BANKO...                " PBO-Modules
* INCLUDE LZFI_PIPES_BANKI...                " PAI-Modules
* INCLUDE LZFI_PIPES_BANKE...                " Events
* INCLUDE LZFI_PIPES_BANKP...                " Local class implement.
* INCLUDE LZFI_PIPES_BANKT99.                " ABAP Unit tests
  INCLUDE LZFI_PIPES_BANKF00                      . " subprograms
  INCLUDE LZFI_PIPES_BANKI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
