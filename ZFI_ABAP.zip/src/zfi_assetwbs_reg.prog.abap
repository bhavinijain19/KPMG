*&---------------------------------------------------------------------*
*& Report ZFI_ASSETWBS_REG
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZFI_ASSETWBS_REG.
*&---------------------------------------------------------------------*
*& Report  ZFI_ASSETWBS_REG( WBS Element Asset details with CWIP class)
*&
*&---------------------------------------------------------------------*
*&   Created By    : Carina Jose
*&   Creation Date : 31/05/2022
*&---------------------------------------------------------------------*
TABLES : anla,prps.

*&--------------------------------------------------- DATA DECLARATION ---------------------------------------------------------------&*

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE,
       gt_sort        TYPE slis_t_sortinfo_alv WITH HEADER LINE.

TYPES : BEGIN OF ty_final,
          anln1 TYPE anla-anln1, " Asset Code
          wbs   TYPE string,       " WBS Element
          post1 TYPE prps-post1, " WBS Element Desc.
          anlkl TYPE ankt-anlkl, " Asset Class
          txk50 TYPE ankt-txk50, " Asset Class Desc.
          werks TYPE prps-werks, " Plant
          txt50 TYPE anla-txt50, " Asset Description
        END OF ty_final.
DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.

TYPES :  BEGIN OF ty_anla,
           anln1 TYPE anla-anln1,
           posnr TYPE anla-posnr,
           txt50 TYPE anla-txt50,
         END OF ty_anla.

DATA :  it_anla TYPE STANDARD TABLE OF ty_anla,
        wa_anla TYPE ty_anla.

DATA : v_wbs(05).
DATA : lv_len TYPE i.

*&------------------------------------------------------- SELECTION SCREEN -------------------------------------------------------------------&*
SELECTION-SCREEN BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_posnr FOR anla-posnr,
                 s_anln1 FOR anla-anln1," OBLIGATORY,
                 s_werks FOR prps-werks OBLIGATORY.
SELECTION-SCREEN END OF BLOCK a1.
*&------------------------------------------------------- START-OF-SELECTION -----------------------------------------------------------------&*

START-OF-SELECTION.
*  PERFORM authorization_check.
  PERFORM get_data.
  IF it_final IS INITIAL.
    MESSAGE 'No data for inputted values!!' TYPE 'S' DISPLAY LIKE 'E'.
  ELSE.
    PERFORM fill_fieldcatalog.
    PERFORM display_grid.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
*FORM authorization_check .
*
*ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  IF s_posnr IS NOT INITIAL.
    SELECT anln1 posnr txt50
     INTO CORRESPONDING FIELDS OF TABLE it_anla
     FROM anla
     WHERE anln1 IN s_anln1
     AND   posnr IN s_posnr.
  ELSE.
    SELECT anln1 posnr txt50
     INTO CORRESPONDING FIELDS OF TABLE it_anla
     FROM anla
     WHERE anln1 IN s_anln1
     AND   posnr NE ''.
  ENDIF.

  IF  it_anla IS NOT INITIAL.
    SELECT pspnr,post1,stufe,belkz,werks
      INTO TABLE @DATA(it_prps)
      FROM prps
      FOR ALL ENTRIES IN @it_anla
      WHERE pspnr = @it_anla-posnr
*      AND   stufe = '4'
      AND   belkz EQ 'X'
      AND   werks IN @s_werks.
  ENDIF.

  SELECT wbs,cwip_class
    INTO TABLE @DATA(it_wbs)
    FROM zfi_wbs.

  IF it_wbs IS NOT INITIAL.
*    SELECT spras,anlkl,txk50
*      INTO TABLE @DATA(it_ankt)
*      FROM ankt
*      FOR ALL ENTRIES IN @it_wbs
*      WHERE spras = @sy-langu
*      AND   anlkl = @it_wbs-cwip_class.

    SELECT spras,ktogr,ktgrtx
     INTO TABLE @DATA(it_t095t)
     FROM t095t
     FOR ALL ENTRIES IN @it_wbs
     WHERE spras = @sy-langu
     AND   ktogr = @it_wbs-cwip_class.
  ENDIF.
*&----------------------------------------------------------------- READ TABLES ---------------------------------------------------------&*
  LOOP AT it_anla INTO wa_anla.

    wa_final-anln1 = wa_anla-anln1.
    wa_final-txt50 = wa_anla-txt50.
    READ TABLE it_prps ASSIGNING FIELD-SYMBOL(<fs_prps>) WITH KEY pspnr = wa_anla-posnr.
    IF <fs_prps> IS ASSIGNED.
      wa_final-post1 = <fs_prps>-post1.
      wa_final-werks = <fs_prps>-werks.
      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = <fs_prps>-pspnr
        IMPORTING
          output = wa_final-wbs.

*      lv_len = strlen( wa_final-wbs ) - 8.
*      v_wbs = wa_final-wbs+lv_len(2).
      v_wbs = wa_final-wbs+13(2).
*      lv_len = strlen( wa_final-wbs ) - 5.
*      v_wbs = wa_final-wbs+13(05).
*      v_wbs = wa_final-wbs+lv_len(5).
      READ TABLE it_wbs ASSIGNING FIELD-SYMBOL(<fs_wbs>) WITH KEY wbs = v_wbs.
      IF <fs_wbs> IS ASSIGNED.
        wa_final-anlkl = <fs_wbs>-cwip_class.

*        READ TABLE it_ankt ASSIGNING FIELD-SYMBOL(<fs_ankt>) WITH KEY anlkl = wa_final-anlkl.
*        IF <fs_ankt> IS ASSIGNED.
*          wa_final-txk50 = <fs_ankt>-txk50.
*        ENDIF.
        READ TABLE it_t095t ASSIGNING FIELD-SYMBOL(<fs_t095t>) WITH KEY ktogr = wa_final-anlkl.
        IF <fs_t095t> IS ASSIGNED.
          wa_final-txk50 = <fs_t095t>-ktgrtx.
        ENDIF.

        APPEND wa_final TO it_final.
*        UNASSIGN :<fs_prps>,<fs_wbs>,<fs_ankt>.
        UNASSIGN :<fs_prps>,<fs_wbs>,<fs_t095t>.
        CLEAR : wa_final,wa_anla,v_wbs.
      ENDIF.
    ENDIF.
  ENDLOOP.

  SORT it_final by  werks.

  LOOP AT it_final INTO wa_final.
    AUTHORITY-CHECK OBJECT 'Z_WBS_WRKS'
      ID 'WERKS' FIELD wa_final-werks
      ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
*      MESSAGE e007(zsd) WITH wa_final-werks.
      DELETE it_final WHERE werks = wa_final-werks AND anln1 = wa_final-anln1.
    ENDIF.
    CLEAR :  wa_final.
  ENDLOOP.





ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'WERKS'               'PLANT'                'X' '20' 'IT_FINAL' '' 'C411' .
  PERFORM fieldcat_append  USING  'WBS'               'WBS ELEMENT'                'X' '20' 'IT_FINAL' '' '' .
*  PERFORM fieldcat_append  USING  'POST1'               'WBS ELEMENT DESCRIPTION'                'X'  'IT_FINAL' ''  .
  PERFORM fieldcat_append  USING  'ANLN1'               'WBS ASSET CODE'                'X' '11'  'IT_FINAL' '' '' .
  PERFORM fieldcat_append  USING  'TXT50'               'WBS ASSET DESCRIPTION'                'X' '40'  'IT_FINAL' '' '' .
  PERFORM fieldcat_append  USING  'ANLKL'               'CWIP CLASS'                'X' '11'  'IT_FINAL' '' '' .
  PERFORM fieldcat_append  USING  'TXK50'               'CWIP CLASS DESCRIPTION'                'X' '50'  'IT_FINAL' ''  ''.

ENDFORM.
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_op)
                               VALUE(p_table)
                               VALUE(p_dosum)
                               VALUE(p_emph).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-outputlen   = p_op.
  t_fieldcatalog-tabname     = p_table.
  t_fieldcatalog-do_sum      = p_dosum.
  t_fieldcatalog-emphasize      = p_emph.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
*     it_sort            = gt_sort[]
*     it_events          = t_event[]
      i_save             = 'A'
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
  ENDIF.
ENDFORM.
