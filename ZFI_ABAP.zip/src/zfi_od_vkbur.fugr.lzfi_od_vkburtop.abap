FUNCTION-POOL ZFI_OD_VKBUR               MESSAGE-ID SV.

* INCLUDE LZFI_OD_VKBURD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_OD_VKBURT00                        . "view rel. data dcl.
