FUNCTION ZMM_GATE_ENTRY_UPDATE.
*"----------------------------------------------------------------------
*"*"Update Function Module:
*"
*"*"Local Interface:
*"  TABLES
*"      T_GATE_H_I STRUCTURE  ZGATE_HEADER
*"      T_GATE_H_U STRUCTURE  ZGATE_HEADER
*"      T_GATE_H_D STRUCTURE  ZGATE_HEADER OPTIONAL
*"      T_GATE_I_I STRUCTURE  ZGATE_ITEM
*"      T_GATE_I_U STRUCTURE  ZGATE_ITEM
*"      T_GATE_I_D STRUCTURE  ZGATE_ITEM OPTIONAL
*"----------------------------------------------------------------------
* delete
*  BREAK-POINT.
  IF NOT t_gate_h_d[] IS INITIAL.
    DELETE zgate_header FROM TABLE t_gate_h_d.
    IF sy-subrc NE 0.
      MESSAGE 'Delete Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.

* insert
  IF NOT t_gate_h_i[] IS INITIAL.
    INSERT zgate_header FROM TABLE t_gate_h_i.
    IF sy-subrc NE 0.
      MESSAGE 'Insert Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.

***********************Begin of Changes Added by Raj on 05.11.2024***************************
if sy-subrc = 0.

 DATA: lo_send_request         TYPE REF TO cl_bcs.
    DATA: lo_document             TYPE REF TO cl_document_bcs.
    DATA: l_dockey                TYPE soodk.
    DATA: l_service               TYPE ad_pagserv.
    DATA: l_number                TYPE ad_pagnmbr.
    DATA: li_recipient            TYPE REF TO if_recipient_bcs.
    DATA: l_texttype              TYPE so_obj_tp VALUE  'TXT'.
    DATA: lt_text                 TYPE bcsy_text.
    DATA: l_text                  TYPE LINE OF bcsy_text.
    DATA: l_subject               TYPE so_obj_des.
    DATA: l_len                   TYPE so_obj_len.
    DATA: lt_recipients           TYPE bcsy_re.
    DATA: lo_bcs_exception        TYPE REF TO cx_bcs.
    DATA: l_msg_text              TYPE string.
    DATA: p_addr TYPE ad_pagnmbr.
    DATA : p_subj TYPE so_obj_des.
    DATA : p_body TYPE soli-line.

    TYPES: BEGIN OF ty_text,
         text(10000),
       END OF ty_text.
DATA: text    TYPE STANDARD TABLE OF ty_text,
      lv_text TYPE ty_text.

*    p_addr = wa_adr2-telnr_long.

    p_addr = '9182558898'.
    p_subj = 'GATE ENTRY DETAILS'.
    p_body = lv_text.


  TRY.
*   handle request
        lo_send_request = cl_bcs=>create_persistent( ).
*   set 'send immediately' -> no send queue required
        lo_send_request->set_send_immediately( 'X' ).

*   set subject
        MOVE p_subj TO l_subject.

*   set text
        MOVE p_body TO l_text.
        APPEND l_text TO lt_text.
        l_len = strlen( l_text ).

*   create document
        lo_document = cl_document_bcs=>create_document(
                              i_type = l_texttype
                              i_text = lt_text
                              i_language = sy-langu
                              i_subject = l_subject
                              i_length = l_len
                              ).
*   add document to send request
        CALL METHOD lo_send_request->set_document( lo_document ).

*   document key
        l_dockey-objtp = lo_document->get_doctp( ).
        l_dockey-objyr = lo_document->get_docyr( ).
        l_dockey-objno = lo_document->get_docno( ).

        TRY.
*       create SMS/pager recipient
            l_number = p_addr.
            CALL METHOD cl_cam_address_bcs=>create_sms_address
              EXPORTING
                i_service = l_service
                i_number  = l_number
              RECEIVING
                result    = li_recipient.

*       add recipient to send request
            CALL METHOD lo_send_request->add_recipient
              EXPORTING
                i_recipient = li_recipient.

          CATCH cx_address_bcs cx_send_req_bcs.
            MESSAGE e038(swn) WITH l_number INTO l_msg_text.
*       error message
            WRITE:/ text-t01, l_msg_text.
            EXIT.
        ENDTRY.

*   add recipient with its respective attributes to send request
        CALL METHOD lo_send_request->add_recipient
          EXPORTING
            i_recipient = li_recipient
            i_express   = 'X'.

*   check if document has recipients at all
        lt_recipients = lo_send_request->recipients( ).
        IF lt_recipients IS INITIAL.
          MESSAGE e040(swn) INTO l_msg_text.
*     error message
          WRITE:/ text-t01, l_msg_text.
          EXIT.
        ELSE.
*     send document
          CALL METHOD lo_send_request->send( ).
          COMMIT WORK.
          MESSAGE s058(swn) WITH l_dockey INTO l_msg_text.
*     sms has been sent
          WRITE:/ text-t02, l_msg_text.
        ENDIF.

      CATCH cx_bcs INTO lo_bcs_exception.
*   error messages
        MESSAGE e034(salert) WITH lo_bcs_exception->error_type INTO l_msg_text.
        WRITE:/ text-t01, l_msg_text.
        MESSAGE e041(salert) WITH p_addr INTO l_msg_text.
        WRITE:/ text-t01, l_msg_text.
        EXIT.
    ENDTRY.
*  SUBMIT SWN_TEST_SEND_SMS1.
    CLEAR: p_body,p_subj,p_addr,lv_text.
    REFRESH : lt_text.


endif.
**********************End of Changes Added by Raj on 05.11.2024*****************************



* update
  IF NOT t_gate_h_u[] IS INITIAL.
    UPDATE zgate_header FROM TABLE t_gate_h_u.
    IF sy-subrc NE 0.
      MESSAGE 'Update Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.

  IF NOT t_gate_i_d[] IS INITIAL.
    DELETE zgate_item FROM TABLE t_gate_i_d.
    IF sy-subrc NE 0.
      MESSAGE 'Delete Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.

* insert
  IF NOT t_gate_h_i[] IS INITIAL.
    INSERT zgate_item FROM TABLE t_gate_i_i.
    IF sy-subrc NE 0.
      MESSAGE 'Insert Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.

* update
  IF NOT t_gate_i_u[] IS INITIAL.
    UPDATE zgate_item FROM TABLE t_gate_i_u.
    IF sy-subrc NE 0.
      MESSAGE 'Update Gate Entry status is failed' TYPE 'A'.
    ENDIF.
  ENDIF.


ENDFUNCTION.
