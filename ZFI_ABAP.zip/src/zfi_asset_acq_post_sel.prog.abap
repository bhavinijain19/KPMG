*&---------------------------------------------------------------------*
*& Include          ZFI_ASSET_ACQ_POST_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS:
    r_down RADIOBUTTON GROUP rg1 USER-COMMAND rad,
    r_up   RADIOBUTTON GROUP rg1 DEFAULT 'X'.

  PARAMETERS:
    p_file TYPE rlgrap-filename MODIF ID up.
*    p_mode TYPE c DEFAULT 'N' MODIF ID mod.   "A/E/N
SELECTION-SCREEN END OF BLOCK b1.
