*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZFI_CH_DAY_PAINT
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZFI_CH_DAY_PAINT   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
