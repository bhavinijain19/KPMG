FUNCTION-POOL ZFI_FB60.                     "MESSAGE-ID ..

* INCLUDE LZFI_FB60D...                      " Local class definition
