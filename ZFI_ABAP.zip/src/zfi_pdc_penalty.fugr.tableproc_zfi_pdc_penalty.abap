*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PDC_PENALTY
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PDC_PENALTY     .

  PERFORM TABLEPROC.

ENDFUNCTION.
