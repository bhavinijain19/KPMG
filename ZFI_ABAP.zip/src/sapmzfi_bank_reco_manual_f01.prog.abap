*&---------------------------------------------------------------------*
*&  Include           SAPMZFI_BANK_RECO_MANUAL_F01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  F_CLEAR
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_clear .
  CLEAR: gv_ucomm,sy-ucomm,gv_bukrs ,
                           gv_hbkid ,
                           gv_hktid ,
                           gv_aznum ,
                           gv_azdat ,
                           gv_ssald ,
                           gv_esald ,
                           gv_hkont ,
                           gv_hkont1,
                           gv_hkont2,
                           gv_get.

ENDFORM.                    " F_CLEAR
*&---------------------------------------------------------------------*
*&      Form  F_CONVERSION_ALPHA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_GV_HKONT2  text
*----------------------------------------------------------------------*
FORM f_conversion_alpha  CHANGING e_change.
  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = e_change
    IMPORTING
      output = e_change.

ENDFORM.                    " F_CONVERSION_ALPHA

*----------------------------------------------------------------------*
*   INCLUDE TABLECONTROL_FORMS                                         *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  USER_OK_TC                                               *
*&---------------------------------------------------------------------*
FORM user_ok_tc USING    p_tc_name TYPE dynfnam
                         p_table_name
                         p_mark_name
                CHANGING p_ok      LIKE sy-ucomm.

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA: l_ok     TYPE sy-ucomm,
        l_offset TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

*&SPWIZARD: Table control specific operations                          *
*&SPWIZARD: evaluate TC name and operations                            *
  SEARCH p_ok FOR p_tc_name.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.
  l_offset = strlen( p_tc_name ) + 1.
  l_ok = p_ok+l_offset.
*&SPWIZARD: execute general and TC specific operations                 *
  CASE l_ok.
    WHEN 'INSR'.                      "insert row
      PERFORM fcode_insert_row USING    p_tc_name
                                        p_table_name.
      CLEAR p_ok.

    WHEN 'DELE'.                      "delete row
      PERFORM fcode_delete_row USING    p_tc_name
                                        p_table_name
                                        p_mark_name.
      CLEAR p_ok.

    WHEN 'P--' OR                     "top of list
         'P-'  OR                     "previous page
         'P+'  OR                     "next page
         'P++'.                       "bottom of list
      PERFORM compute_scrolling_in_tc USING p_tc_name
                                            l_ok.
      CLEAR p_ok.
*     WHEN 'L--'.                       "total left
*       PERFORM FCODE_TOTAL_LEFT USING P_TC_NAME.
*
*     WHEN 'L-'.                        "column left
*       PERFORM FCODE_COLUMN_LEFT USING P_TC_NAME.
*
*     WHEN 'R+'.                        "column right
*       PERFORM FCODE_COLUMN_RIGHT USING P_TC_NAME.
*
*     WHEN 'R++'.                       "total right
*       PERFORM FCODE_TOTAL_RIGHT USING P_TC_NAME.
*
    WHEN 'MARK'.                      "mark all filled lines
      PERFORM fcode_tc_mark_lines USING p_tc_name
                                        p_table_name
                                        p_mark_name   .
      CLEAR p_ok.

    WHEN 'DMRK'.                      "demark all filled lines
      PERFORM fcode_tc_demark_lines USING p_tc_name
                                          p_table_name
                                          p_mark_name .
      CLEAR p_ok.

*     WHEN 'SASCEND'   OR
*          'SDESCEND'.                  "sort column
*       PERFORM FCODE_SORT_TC USING P_TC_NAME
*                                   l_ok.
    WHEN 'EXPO'.
      PERFORM fcode_tc_export_lines USING p_tc_name
                                          p_table_name
                                          p_mark_name.

      CLEAR p_ok.


  ENDCASE.

ENDFORM.                              " USER_OK_TC

*&---------------------------------------------------------------------*
*&      Form  FCODE_INSERT_ROW                                         *
*&---------------------------------------------------------------------*
FORM fcode_insert_row
              USING    p_tc_name           TYPE dynfnam
                       p_table_name             .

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_lines_name       LIKE feld-name.
  DATA l_selline          LIKE sy-stepl.
  DATA l_lastline         TYPE i.
  DATA l_line             TYPE i.
  DATA l_table_name       LIKE feld-name.
  FIELD-SYMBOLS <tc>                 TYPE cxtab_control.
  FIELD-SYMBOLS <table>              TYPE STANDARD TABLE.
  FIELD-SYMBOLS <lines>              TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: get looplines of TableControl                              *
  CONCATENATE 'G_' p_tc_name '_LINES' INTO l_lines_name.
  ASSIGN (l_lines_name) TO <lines>.

*&SPWIZARD: get current line                                           *
  GET CURSOR LINE l_selline.
  IF sy-subrc <> 0.                   " append line to table
    l_selline = <tc>-lines + 1.
*&SPWIZARD: set top line                                               *
    IF l_selline > <lines>.
      <tc>-top_line = l_selline - <lines> + 1 .
    ELSE.
      <tc>-top_line = 1.
    ENDIF.
  ELSE.                               " insert line into table
    l_selline = <tc>-top_line + l_selline - 1.
    l_lastline = <tc>-top_line + <lines> - 1.
  ENDIF.
*&SPWIZARD: set new cursor line                                        *
  l_line = l_selline - <tc>-top_line + 1.

*&SPWIZARD: insert initial line                                        *
  INSERT INITIAL LINE INTO <table> INDEX l_selline.
  <tc>-lines = <tc>-lines + 1.
*&SPWIZARD: set cursor                                                 *
  SET CURSOR LINE l_line.

ENDFORM.                              " FCODE_INSERT_ROW

*&---------------------------------------------------------------------*
*&      Form  FCODE_DELETE_ROW                                         *
*&---------------------------------------------------------------------*
FORM fcode_delete_row
              USING    p_tc_name           TYPE dynfnam
                       p_table_name
                       p_mark_name   .

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: delete marked lines                                        *
  DESCRIBE TABLE <table> LINES <tc>-lines.

  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    IF <mark_field> = 'X'.
      DELETE <table> INDEX syst-tabix.
      IF sy-subrc = 0.
        <tc>-lines = <tc>-lines - 1.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                              " FCODE_DELETE_ROW

*&---------------------------------------------------------------------*
*&      Form  COMPUTE_SCROLLING_IN_TC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*      -->P_OK       ok code
*----------------------------------------------------------------------*
FORM compute_scrolling_in_tc USING    p_tc_name
                                      p_ok.
*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_tc_new_top_line     TYPE i.
  DATA l_tc_name             LIKE feld-name.
  DATA l_tc_lines_name       LIKE feld-name.
  DATA l_tc_field_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <lines>      TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.
*&SPWIZARD: get looplines of TableControl                              *
  CONCATENATE 'G_' p_tc_name '_LINES' INTO l_tc_lines_name.
  ASSIGN (l_tc_lines_name) TO <lines>.


*&SPWIZARD: is no line filled?                                         *
  IF <tc>-lines = 0.
*&SPWIZARD: yes, ...                                                   *
    l_tc_new_top_line = 1.
  ELSE.
*&SPWIZARD: no, ...                                                    *
    CALL FUNCTION 'SCROLLING_IN_TABLE'
      EXPORTING
        entry_act      = <tc>-top_line
        entry_from     = 1
        entry_to       = <tc>-lines
        last_page_full = 'X'
        loops          = <lines>
        ok_code        = p_ok
        overlapping    = 'X'
      IMPORTING
        entry_new      = l_tc_new_top_line
      EXCEPTIONS
*       NO_ENTRY_OR_PAGE_ACT  = 01
*       NO_ENTRY_TO    = 02
*       NO_OK_CODE_OR_PAGE_GO = 03
        OTHERS         = 0.
  ENDIF.

*&SPWIZARD: get actual tc and column                                   *
  GET CURSOR FIELD l_tc_field_name
             AREA  l_tc_name.

  IF syst-subrc = 0.
    IF l_tc_name = p_tc_name.
*&SPWIZARD: et actual column                                           *
      SET CURSOR FIELD l_tc_field_name LINE 1.
    ENDIF.
  ENDIF.

*&SPWIZARD: set the new top line                                       *
  <tc>-top_line = l_tc_new_top_line.


ENDFORM.                              " COMPUTE_SCROLLING_IN_TC

*&---------------------------------------------------------------------*
*&      Form  FCODE_TC_MARK_LINES
*&---------------------------------------------------------------------*
*       marks all TableControl lines
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*----------------------------------------------------------------------*
FORM fcode_tc_mark_lines USING p_tc_name
                               p_table_name
                               p_mark_name.
*&SPWIZARD: EGIN OF LOCAL DATA-----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: mark all filled lines                                      *
  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    <mark_field> = 'X'.
  ENDLOOP.
ENDFORM.                                          "fcode_tc_mark_lines

*&---------------------------------------------------------------------*
*&      Form  FCODE_TC_DEMARK_LINES
*&---------------------------------------------------------------------*
*       demarks all TableControl lines
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*----------------------------------------------------------------------*
FORM fcode_tc_demark_lines USING p_tc_name
                                 p_table_name
                                 p_mark_name .
*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: demark all filled lines                                    *
  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    <mark_field> = space.
  ENDLOOP.
ENDFORM.                                          "fcode_tc_mark_lines

FORM fcode_tc_export_lines USING p_tc_name
                                 p_table_name
                                 p_mark_name .

  DATA: cv_filename TYPE string.
  DATA:s1 TYPE string,
       s2 TYPE string.

*  CALL METHOD cl_gui_frontend_services=>file_save_dialog
*    EXPORTING
*      window_title         = 'File'
*      default_extension    = 'XLS'
*      default_file_name    = cv_filename
*      initial_directory    = 'C:\Documents and Settings\root\Desktop'
*      prompt_on_overwrite  = 'X'
*    CHANGING
*      filename             = s1
*      path                 = s2
*      fullpath             = cv_filename
*    EXCEPTIONS
*      cntl_error           = 1
*      error_no_gui         = 2
*      not_supported_by_gui = 3
*      OTHERS               = 4.

  TYPES:BEGIN OF ty_down,
          field1  TYPE string,
          field2  TYPE string,
          field3  TYPE string,
          field4  TYPE string,
          field5  TYPE string,
          field6  TYPE string,
          field7  TYPE string,
          field8  TYPE string,
          field9  TYPE string,
          field10 TYPE string,
          field11 TYPE string,
          field12 TYPE string,
          field13 TYPE c,
        END OF ty_down.

  DATA:wa_down TYPE ty_down,
       it_down TYPE TABLE OF ty_down.

  DATA:v_dmbtr TYPE dmbtr.

  LOOP AT gt_table INTO wa_table.
    AT FIRST.
      wa_down-field1  = 'Company Code'.
      wa_down-field2  = 'Tran Type'.
      wa_down-field3  = 'G/L Account'.
      wa_down-field4  = 'Document Number'.
      wa_down-field5  = 'Type'.
      wa_down-field6  = 'Document Date'.
      wa_down-field7  = 'Posting Date'.
      wa_down-field8  = 'Value Date'.
      wa_down-field9  = 'Amount'.
      wa_down-field10 = 'Clearing Date'.
      wa_down-field11 = 'Assignment Num.'.
      wa_down-field12 = 'Name'.
      wa_down-field13 = 'Minus Indicator'.
      APPEND wa_down TO it_down.
      CLEAR:wa_down.

    ENDAT.

    wa_down-field1  = wa_table-bukrs.
    wa_down-field2  = wa_table-vgman.
    wa_down-field3  = wa_table-hkont.
    wa_down-field4  = wa_table-belnr.
    wa_down-field5  = wa_table-blart.

    CONCATENATE wa_table-bldat+6(2) wa_table-bldat+4(2) wa_table-bldat+0(4) INTO wa_down-field6 SEPARATED BY '.'.
    CONCATENATE wa_table-budat+6(2) wa_table-budat+4(2) wa_table-budat+0(4) INTO wa_down-field7 SEPARATED BY '.'.
    CONCATENATE wa_table-valut+6(2) wa_table-valut+4(2) wa_table-valut+0(4) INTO wa_down-field8 SEPARATED BY '.'.

    IF wa_table-dmbtr GT 0.
      wa_down-field9  = wa_table-dmbtr.
    ELSE.
      v_dmbtr = wa_table-dmbtr * ( -1 ).
      wa_down-field9 = v_dmbtr.
      wa_down-field13 = 'X'.
    ENDIF.

    IF wa_table-cldat IS NOT INITIAL.
      CONCATENATE wa_table-cldat+6(2) wa_table-cldat+4(2) wa_table-cldat+0(4) INTO wa_down-field10 SEPARATED BY '.'.
*      wa_down-field10 = 'Blank'.
    ELSE.
      wa_down-field10 = 'Blank'.
    ENDIF.


    wa_down-field11 = wa_table-zuonr.
    wa_down-field12 = wa_table-name.

*    wa_down-field10 = wa_table-cldat.

    APPEND wa_down TO it_down.
    CLEAR:wa_down,wa_table.

  ENDLOOP.

  LOOP AT it_down INTO wa_down.

    CONDENSE:wa_down-field1,
             wa_down-field2,
             wa_down-field3,
             wa_down-field4,
             wa_down-field5,
             wa_down-field6,
             wa_down-field7,
             wa_down-field8 ,
             wa_down-field9,
             wa_down-field10,
             wa_down-field11,
             wa_down-field12,
             wa_down-field13.

    MODIFY it_down FROM wa_down.


  ENDLOOP.


  DATA:v_file TYPE rlgrap-filename.

*  cv_filename = 'C:\Users\Administrator\Desktop\Payment_Details.xls'.
*  cv_filename = 'C:\Documents and Settings\root\Desktop\Payment_Details.xls'.
*  cv_filename = 'D:\Payment_Details.xls'.
*  cv_filename = '\\192.168.9.14\testing1\ACCOUNT\BHADRESH\Payment_Details.xls'.

  v_file = cv_filename.

*  CALL FUNCTION 'GUI_DOWNLOAD'
*    EXPORTING
*      filename              = cv_filename
*      filetype              = 'ASC'
*      write_field_separator = 'X'
*      show_transfer_status  = 'X'
*    TABLES
*      data_tab              = it_down[].

  DATA : fname      TYPE string,
         fpath      TYPE string,
         fpath_full TYPE string.

*  CALL METHOD cl_gui_frontend_services=>file_save_dialog
*    EXPORTING
*      window_title         = 'Choose a location'
*    CHANGING
*      filename             = fname
*      path                 = fpath
*      fullpath             = fpath_full
*    EXCEPTIONS
*      cntl_error           = 1
*      error_no_gui         = 2
*      not_supported_by_gui = 3
*      OTHERS               = 4.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*  ENDIF.

  DATA:lc_rc TYPE sy-subrc.

  DATA:file_table    TYPE TABLE OF file_table,
       wa_file_table TYPE file_table.

  DATA:v_msg(120) TYPE c.

  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title            = 'Choose a location'
    CHANGING
      file_table              = file_table
      rc                      = lc_rc
    EXCEPTIONS
      file_open_dialog_failed = 1
      cntl_error              = 2
      error_no_gui            = 3
      not_supported_by_gui    = 4
      OTHERS                  = 5.
  v_file                  = fname.

  IF file_table IS NOT INITIAL.

    READ TABLE file_table INTO wa_file_table INDEX 1.
    IF sy-subrc EQ 0.
      v_file = wa_file_table-filename.
    ENDIF.

    CALL FUNCTION 'MS_EXCEL_OLE_STANDARD_DAT'
      EXPORTING
        file_name = v_file
      TABLES
        data_tab  = it_down[].

    CONCATENATE 'File has been Downloaded on your PATH' v_file INTO v_msg SEPARATED BY ' '.

    IF sy-subrc EQ 0.
*    MESSAGE 'File has been Downloaded on your PATH testing1\ACCOUNT\BHADRESH\Payment_Details.xls' TYPE 'S'.
      MESSAGE v_msg TYPE 'S'.
    ENDIF.

  ENDIF.

  REFRESH:file_table.
  CLEAR:v_file,lc_rc,v_msg.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  F_BDC_DATA_FF67
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_bdc_data_ff67 .
  DATA: lv_dmbtr  TYPE dmbtr.
  LOOP AT gt_table INTO wa_table WHERE mark = 'X'.
    wa_item-vgman = wa_table-vgman .
    CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
      EXPORTING
*        date_internal = wa_table-valut
        date_internal = wa_table-cldat
      IMPORTING
        date_external = wa_item-budat.

*      wa_item-budat = wa_table-budat .
    IF wa_item-vgman = 'ZOUT'.
      lv_dmbtr = wa_table-dmbtr.
      wa_item-dmbtr = lv_dmbtr.
    ELSE.
      wa_item-dmbtr = wa_table-dmbtr.
    ENDIF.
    wa_item-waers = 'INR'."waers_l."wa_table-waers.
*      wa_item-bukrs = bukrs_l."" wa_table-bukrs.
    wa_item-hkont = wa_item-hkont.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = wa_table-belnr
      IMPORTING
        output = wa_item-belnr.

*      wa_item-belnr = wa_table-belnr .
*      wa_item-zuonr = wa_table-zuonr.
    APPEND wa_item TO gt_item .
    CLEAR wa_item .
  ENDLOOP.
  wa_header-bukrs = gv_bukrs .
  wa_header-hbkid = gv_hbkid .
  wa_header-hktid = gv_hktid .
  wa_header-waers = 'INR'." wa_final-waers .
  wa_header-aznum = gv_aznum .
  CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
    EXPORTING
      date_internal = gv_azdat
    IMPORTING
      date_external = wa_header-azdat.

*      wa_header-azdat = p_azdat .
  wa_header-ssald = gv_ssald .
  wa_header-close_balance = gv_esald.
  CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
    EXPORTING
      date_internal = sy-datum
    IMPORTING
      date_external = wa_header-budtm.

*    wa_header-budtm = wa_final-budtm .
*    wa_header-bankl = wa_final-bankl .
*    wa_header-bankn = wa_final-bankn .
  PERFORM f_post_data.

ENDFORM.                    " F_BDC_DATA_FF67
*&---------------------------------------------------------------------*
*&      Form  F_POST_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_post_data .
  REFRESH bdcdata[].
  PERFORM bdc_dynpro      USING 'SAPMF40K' '0101'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'FEBMKA-BUDTM'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.

  PERFORM bdc_field       USING 'FEBMKA-BUKRS'
                                wa_header-bukrs.            " '1000'.
  PERFORM bdc_field       USING 'FEBMKA-HBKID'
                                wa_header-hbkid.        " 'SCB1'.
  PERFORM bdc_field       USING 'FEBMKA-HKTID'
                                wa_header-hktid.            " 'S4369'.
  PERFORM bdc_field       USING 'FEBMKA-AZNUM'
                                wa_header-aznum.        " '9'.
  PERFORM bdc_field       USING 'FEBMKA-AZDAT'
                                wa_header-azdat.            " '19.01.2012'.
*      PERFORM bdc_field       USING 'FEBMKA-WAERS'
*                                    wa_header-waers.

  CONDENSE wa_header-ssald.
  PERFORM bdc_field       USING 'FEBMKA-SSALD'
                                wa_header-ssald.            " '                 1'.
  CONDENSE wa_header-close_balance.
  PERFORM bdc_field       USING 'FEBMKA-ESALD'
                                wa_header-close_balance.    " '                 2'.
  PERFORM bdc_field       USING 'FEBMKA-BUDTM'
                                wa_header-budtm.          " '19.01.2012'.

*     perform bdc_field       using 'FEBMKA-JNAME'
*                                  'KPITFI'.

  CLEAR : wa_header.
  LOOP AT gt_item INTO wa_item .

    PERFORM bdc_dynpro      USING 'SAPMF40K' '0220'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'FEBMKA-VGMAN(16)'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.

    count = count + 1 .


    CONCATENATE    'FEBMKA-VGMAN(' count ')' INTO temp  .

    PERFORM bdc_field       USING temp
                                  wa_item-vgman .

    CLEAR temp .


    CONCATENATE    'FEBEP-VALUT(' count ')' INTO temp  .

    PERFORM bdc_field       USING temp
                                  wa_item-budat.


    CLEAR temp .
    CONDENSE wa_item-dmbtr.
    CONCATENATE    'FEBMKA-KWBTR(' count ')' INTO temp  .
    PERFORM bdc_field       USING temp
                                  wa_item-dmbtr.


    CLEAR temp .



    CONCATENATE    'FEBMKK-BELNR(' count ')' INTO temp  .
    PERFORM bdc_field       USING temp
                                  wa_item-belnr .
    CLEAR temp .

*    CONCATENATE    'FEBMKK-CHECT_KF(' count ')' INTO temp  .
*    PERFORM bdc_field       USING temp
*                                  wa_item-xchng.


*    CLEAR temp .
*    CONCATENATE    'FEBMKK-zuonr(' count ')' INTO temp  .
*    PERFORM bdc_field       USING temp
*                                  wa_item-zuonr.
*
*
*    CLEAR temp .
*
*    var_exc = wa_item-kursf_kf.
*    CONCATENATE    'FEBMKK-KURSF_KF(' count ')' INTO temp  .
*
*    PERFORM bdc_field       USING temp
*                                 var_exc.

*    CLEAR var_exc.

*    CONCATENATE    'FEBMKK-KURSF_KF(' count ')' INTO temp  .
*    local = wa_item-KURSF_KF.
*    PERFORM bdc_field       USING temp
*                                  local.

*    CLEAR temp .
*    CONCATENATE    'FEBMKK-PRCTR_KF(' count ')' INTO temp  .
*    PERFORM bdc_field       USING temp
*                                  wa_item-prctr .
*    CLEAR temp .


    count1 = count MOD 16 .

    IF count1 = 0 .

      PERFORM bdc_dynpro      USING 'SAPMF40K' '0220'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                            'FEBMKA-VGMAN(16)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                            '=ZINS'.
      PERFORM bdc_dynpro      USING 'SAPMF40K' '0220'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                            'FEBMKA-VGMAN(16)'.

      PERFORM bdc_field       USING 'BDC_OKCODE'
                            '=P+'.


      PERFORM bdc_dynpro      USING 'SAPMF40K' '0220'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                            'FEBMKA-KWBTR(14)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                            '/00'.
      count = '00' .

    ENDIF .
  ENDLOOP .
  PERFORM bdc_field       USING 'BDC_OKCODE'
                            '=SICH'.

  PERFORM bdc_dynpro      USING 'SAPMF40K' '0101'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'FEBMKA-BUKRS'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BUCH'.
  params-dismode = 'A'.
  params-updmode = 'S'.
  params-defsize = 'X'.
  CALL TRANSACTION 'FF67' USING bdcdata OPTIONS FROM params
                                 MESSAGES INTO gt_msgtype  ." MODE MOd UPDATE upd.

  CLEAR :count,count1,wa_header.
  REFRESH :gt_item[].
ENDFORM.                    " F_POST_DATA
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
*  IF FVAL <> NODATA.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
*  ENDIF.
ENDFORM. "BDC_FIELD
*&---------------------------------------------------------------------*
*&      Form  F_CHANGE_FB02
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_change_fb02 .
*  BREAK-POINT.
  LOOP AT gt_table INTO wa_table WHERE mark = 'X' AND cldat NE 0.
    REFRESH bdcdata[].
    PERFORM bdc_dynpro      USING 'SAPMF05L' '0100'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'RF05L-BELNR'
                                  wa_table-belnr.           " 'S4369'.
    PERFORM bdc_field       USING 'RF05L-BUKRS'
                                  wa_table-bukrs.           " '1000'.
    PERFORM bdc_field       USING 'RF05L-GJAHR'
                                  wa_table-gjahr.        " 'SCB1'.
    PERFORM bdc_dynpro      USING 'SAPMF05L' '0700'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=VK'.
    PERFORM bdc_dynpro      USING 'SAPMF05L' '1710'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ENTR'.
    CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
      EXPORTING
        date_internal = wa_table-cldat
      IMPORTING
        date_external = wa_item-budat.

    PERFORM bdc_field       USING 'BKPF-XBLNR'
                                  wa_item-budat.            " 'S4369'.
    PERFORM bdc_dynpro      USING 'SAPMF05L' '0700'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=AE'.
    params-dismode = 'A'.
    params-updmode = 'S'.
    params-defsize = 'X'.
    CALL TRANSACTION 'FB02' USING bdcdata OPTIONS FROM params
                                   MESSAGES INTO gt_msgtype  ." MODE MOd UPDATE upd.

  ENDLOOP.

ENDFORM.                    " F_CHANGE_FB02
*&---------------------------------------------------------------------*
*&      Form  F_CHECK_AMOUNT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_check_amount .
  DATA: lt_t028h  TYPE STANDARD TABLE OF t028h,
        lw_t028h  TYPE t028h,
        lv_amount TYPE dmbtr.

*  SELECT * FROM t028h
*    INTO TABLE lt_t028h
*      FOR ALL ENTRIES IN gt_table
*          WHERE vgman = gt_table-vgman.
  LOOP AT gt_table INTO wa_table WHERE mark = 'X'.
*    READ TABLE lt_t028h INTO lw_t028h WITH KEY vtypm = '1'
*                                               vgman = wa_final-vgman.
*    IF lw_t028h-vozpm = '-'.
*      lv_amount = lv_amount + ( wa_table-dmbtr * -1 ) .
*    ELSE.
*      lv_amount = lv_amount + wa_table-dmbtr.
*    ENDIF.
    lv_amount = lv_amount + wa_table-dmbtr.

  ENDLOOP.
  lv_amount = gv_ssald + lv_amount.
  IF lv_amount NE gv_esald.
    gv_amt = 'X'.
    MESSAGE s006(zfi) DISPLAY LIKE 'E'.
  ELSE.
    CLEAR gv_amt.
  ENDIF.
ENDFORM.                    " F_CHECK_AMOUNT
