*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GL_CHECKTOP.                  " Global Declarations
  INCLUDE LZFI_GL_CHECKUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GL_CHECKF...                  " Subroutines
* INCLUDE LZFI_GL_CHECKO...                  " PBO-Modules
* INCLUDE LZFI_GL_CHECKI...                  " PAI-Modules
* INCLUDE LZFI_GL_CHECKE...                  " Events
* INCLUDE LZFI_GL_CHECKP...                  " Local class implement.
* INCLUDE LZFI_GL_CHECKT99.                  " ABAP Unit tests
  INCLUDE LZFI_GL_CHECKF00                        . " subprograms
  INCLUDE LZFI_GL_CHECKI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
