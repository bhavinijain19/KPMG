*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PIPES_SOFF
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PIPES_SOFF      .

  PERFORM TABLEPROC.

ENDFUNCTION.
