*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_OD_LEGAL....................................*
DATA:  BEGIN OF STATUS_ZFI_OD_LEGAL                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_OD_LEGAL                  .
CONTROLS: TCTRL_ZFI_OD_LEGAL
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_OD_LEGAL                  .
TABLES: ZFI_OD_LEGAL                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
