FUNCTION z_fi_regio_validate.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_FUNCL) TYPE  FUNCL_020
*"  TABLES
*"      T_XVBKPF STRUCTURE  FVBKPF
*"      T_XVBSEG STRUCTURE  FVBSEG
*"      T_XVBSEC STRUCTURE  FVBSEC
*"      T_YVBKPF STRUCTURE  FVBKPF
*"      T_YVBSEG STRUCTURE  FVBSEG
*"      T_YVBSEC STRUCTURE  FVBSEC
*"----------------------------------------------------------------------
  READ TABLE t_xvbkpf INTO DATA(ls_xvbkpf) INDEX 1.

  SELECT a~branch, a~bukrs, b~region
*    FROM j_1bbranch AS a
    FROM P_BUSINESSPLACE AS a
    INNER JOIN adrc AS b ON a~adrnr = b~addrnumber
    FOR ALL ENTRIES IN @t_xvbseg
    WHERE a~branch = @t_xvbseg-bupla
      AND a~bukrs = @ls_xvbkpf-bukrs
    INTO TABLE @DATA(lt_bupla_region).

  SELECT prctr, regio AS region
    FROM cepc
    INTO TABLE @DATA(lt_prctr_region)
    FOR ALL ENTRIES IN @t_xvbseg
    WHERE prctr = @t_xvbseg-prctr
      AND datbi >= @sy-datum.

  " Check Profit Center Region
  LOOP AT t_xvbseg INTO DATA(ls_xvbseg) WHERE bupla IS NOT INITIAL AND prctr IS NOT INITIAL.
    TRY.
        " Get region from Business Place Hashed Table via table expression
        DATA(lv_bp_region) = lt_bupla_region[
          branch = ls_xvbseg-bupla
          bukrs = ls_xvbkpf-bukrs
        ]-region.

        " Get region from Profit Center Hashed Table via table expression
        DATA(lv_pc_region) = lt_prctr_region[
          prctr = ls_xvbseg-prctr
        ]-region.

        " Compare Regions
        IF lv_bp_region <> lv_pc_region AND lv_bp_region IS NOT INITIAL.
          MESSAGE e003(zfi_msgs) WITH ls_xvbseg-prctr ls_xvbseg-bupla.
        ENDIF.

      CATCH cx_sy_itab_line_not_found.
        CONTINUE.
    ENDTRY.

  ENDLOOP.

ENDFUNCTION.
