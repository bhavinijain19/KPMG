*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PDC_BANK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PDC_BANK        .

  PERFORM TABLEPROC.

ENDFUNCTION.
