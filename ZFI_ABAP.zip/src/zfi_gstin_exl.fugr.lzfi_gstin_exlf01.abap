*----------------------------------------------------------------------*
***INCLUDE LZFI_GSTIN_EXLF01.
*----------------------------------------------------------------------*
FORM create_data.
  zfi_gstin_exl-change_by = sy-uname.
  zfi_gstin_exl-change_date = sy-datum.
  zfi_gstin_exl-change_time = sy-uzeit.
ENDFORM.
