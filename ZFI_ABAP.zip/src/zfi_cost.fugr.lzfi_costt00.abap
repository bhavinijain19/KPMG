*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_COST........................................*
DATA:  BEGIN OF STATUS_ZFI_COST                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_COST                      .
CONTROLS: TCTRL_ZFI_COST
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_COST                      .
TABLES: ZFI_COST                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
