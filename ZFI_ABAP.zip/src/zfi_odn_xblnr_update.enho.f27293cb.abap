"Name: \FU:POST_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZFI_ODN_XBLNR_UPDATE.
DATA: lv_xblnr TYPE xblnr.
DATA: lv_blart TYPE char4.
DATA: lv_year TYPE char2.
DATA: lv_reg TYPE regio.

" 1. Read first header and first line item to get required data
READ TABLE t_bkpf INDEX 1 ASSIGNING FIELD-SYMBOL(<fs_bkpf>).
READ TABLE t_bseg INDEX 1 ASSIGNING FIELD-SYMBOL(<fs_bseg>).

IF <fs_bkpf> IS ASSIGNED AND <fs_bseg> IS ASSIGNED.

  lv_xblnr = <fs_bkpf>-xblnr.

  "Call your existing SD logic handler
  lv_blart = <fs_bkpf>-blart.

*SELECT SINGLE b~region
*  INTO lv_reg
**  FROM j_1bbranch AS a
*  FROM p_businessplace AS a
*  INNER JOIN adrc AS b
*    ON a~adrnr = b~addrnumber
*  WHERE a~bukrs  = <fs_bkpf>-bukrs
*    AND a~branch = <fs_bseg>-bupla.

  DATA: lv_adrnr TYPE p_businessplace-adrnr.

  SELECT SINGLE adrnr
    INTO lv_adrnr
    FROM pbusinessplace
    WHERE bukrs  = <fs_bkpf>-bukrs
      AND branch = <fs_bseg>-bupla.

  IF sy-subrc = 0.

* Then get REGION
    SELECT SINGLE region
      INTO lv_reg
      FROM adrc
      WHERE addrnumber = lv_adrnr.

  ENDIF.

  lv_year = <fs_bkpf>-gjahr+2(2).
  zcl_odn_handler=>generate_xblnr(
    EXPORTING
      iv_fkart = lv_blart        " Document Type (FI mapping for Billing Type)
      iv_werks = <fs_bseg>-gsber
      iv_regio = lv_reg        " Region from header
      iv_year  = lv_year       " Year from Doc Date
    IMPORTING
      ev_subrc = DATA(lv_subrc)
    CHANGING
      cv_xblnr = lv_xblnr ).

  "Update the substitution table (Required for BTE 1120 to work)
  IF lv_xblnr IS NOT INITIAL.
    IF <fs_bseg>-koart = 'K'. "Added by bhaumik
      <fs_bkpf>-xblnr_alt = lv_xblnr.
    ELSE.
      <fs_bkpf>-xblnr = lv_xblnr.
    ENDIF.
  ENDIF.
ENDIF.

ENDENHANCEMENT.
