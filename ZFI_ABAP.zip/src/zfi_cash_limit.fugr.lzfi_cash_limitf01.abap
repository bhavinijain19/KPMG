*----------------------------------------------------------------------*
***INCLUDE LZFI_CASH_LIMITF01.
*----------------------------------------------------------------------*

FORM update.
** -- Data Declarations
*DATA: lv_timestamp TYPE tzonref-tstamps.
*BREAK-POINT.
**-- Time stamp conversion
*CALL FUNCTION 'ABI_TIMESTAMP_CONVERT_INTO'
*EXPORTING
*iv_date = sy-datum
*iv_time = sy-uzeit
*IMPORTING
*ev_timestamp = lv_timestamp
*EXCEPTIONS
*conversion_error = 1
*OTHERS = 2.
FIELD-SYMBOLS: <fs_field> TYPE any .
*BREAK-POINT.
LOOP AT total.
CHECK <action> EQ aendern.
** -- Updated By
ASSIGN COMPONENT 'UPDTD_BY' OF STRUCTURE <vim_total_struc> TO <fs_field>.
IF sy-subrc EQ 0.
<fs_field> = sy-uname.
ENDIF.
** -- Updated On
ASSIGN COMPONENT 'UPDTD_DT' OF STRUCTURE <vim_total_struc> TO <fs_field>.
IF sy-subrc EQ 0.
<fs_field> = sy-datum.
ENDIF.

ASSIGN COMPONENT 'UPDTD_TIME' OF STRUCTURE <vim_total_struc> TO <fs_field>.
IF sy-subrc EQ 0.
<fs_field> = sy-uzeit.
ENDIF.
READ TABLE extract WITH KEY <vim_xtotal_key>.
IF sy-subrc EQ 0.
extract = total.
MODIFY extract INDEX sy-tabix.
ENDIF.
IF total IS NOT INITIAL.
MODIFY total.
ENDIF.
ENDLOOP.
ENDFORM.
