*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_EMAIL.......................................*
DATA:  BEGIN OF STATUS_ZSD_EMAIL                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_EMAIL                     .
CONTROLS: TCTRL_ZSD_EMAIL
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZSD_EMAIL                     .
TABLES: ZSD_EMAIL                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
