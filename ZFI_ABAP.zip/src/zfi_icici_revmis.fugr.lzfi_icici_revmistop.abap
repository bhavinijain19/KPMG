FUNCTION-POOL ZFI_ICICI_REVMIS.             "MESSAGE-ID ..

* INCLUDE LZFI_ICICI_REVMISD...              " Local class definition
