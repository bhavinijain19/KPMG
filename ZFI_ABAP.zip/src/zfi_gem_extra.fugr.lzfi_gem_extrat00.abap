*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GEM_EXTRA...................................*
DATA:  BEGIN OF STATUS_ZFI_GEM_EXTRA                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GEM_EXTRA                 .
CONTROLS: TCTRL_ZFI_GEM_EXTRA
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_GEM_EXTRA                 .
TABLES: ZFI_GEM_EXTRA                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
