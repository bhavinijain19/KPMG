*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_HSBC_COLLECTIONTOP.           " Global Declarations
  INCLUDE LZFI_HSBC_COLLECTIONUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_HSBC_COLLECTIONF...           " Subroutines
* INCLUDE LZFI_HSBC_COLLECTIONO...           " PBO-Modules
* INCLUDE LZFI_HSBC_COLLECTIONI...           " PAI-Modules
* INCLUDE LZFI_HSBC_COLLECTIONE...           " Events
* INCLUDE LZFI_HSBC_COLLECTIONP...           " Local class implement.
* INCLUDE LZFI_HSBC_COLLECTIONT99.           " ABAP Unit tests
