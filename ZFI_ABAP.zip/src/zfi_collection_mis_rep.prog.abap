
*&---------------------------------------------------------------------*
*& Report  ZFI_COLLECTION_MIS_REP
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Module Pool      : ZFI_COLLECTION_MIS_REP                       ---*
*&--Package          : ZFI_ABAP                                     ---*
*&--Description      : Report for Collection MIS Information        ---*
*&--Transaction Code : ZFI_COLL_CRN                                 ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP )                      ---*
*&--Functional Owner : BRIJESH SHAH / MAHESH KOKULU                 ---*
*&--TR No            : DEVK938572                                   ---*
*&--                 : DEVK939184 (Date Validation in RB2           ---*
*&---------------------------------------------------------------------*
REPORT zfi_collection_mis_rep.

INCLUDE zfi_collection_mis_top.
INCLUDE zfi_collection_mis_sel.
INCLUDE zfi_collection_mis_sub.

START-OF-SELECTION.
  IF p_bgchk = 'X' AND sy-batch = 'X'.
    IF p_rd1 = 'X'.
      IF s_budat[] IS NOT INITIAL.
        PERFORM bg_task.
      ELSE.
        MESSAGE 'Please Enter Posting Date Range' TYPE 'S' DISPLAY LIKE 'E'.
        RETURN.
      ENDIF."s_budat[] is NOT INITIAL.
    ELSE.
      PERFORM bg_task.
    ENDIF."P_RD1 = 'X'
  ELSE.
    IF p_rd1 = 'X'.
      IF s_budat[] IS NOT INITIAL.
        PERFORM get_data.
        PERFORM display_data.
      ELSE.
        MESSAGE 'Please Enter Posting Date Range' TYPE 'S' DISPLAY LIKE 'E'.
        RETURN.
      ENDIF." s_budat[] is NOT INITIAL.
    ELSE.
      PERFORM get_data.
      PERFORM display_data.
    ENDIF."IF p_rd1 = 'X'.
  ENDIF."p_bgchk = 'X'.
