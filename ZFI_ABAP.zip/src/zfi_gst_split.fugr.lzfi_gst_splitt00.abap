*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_GST_SPLIT...................................*
DATA:  BEGIN OF STATUS_ZFI_GST_SPLIT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_GST_SPLIT                 .
CONTROLS: TCTRL_ZFI_GST_SPLIT
            TYPE TABLEVIEW USING SCREEN '9999'.
*.........table declarations:.................................*
TABLES: *ZFI_GST_SPLIT                 .
TABLES: ZFI_GST_SPLIT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
