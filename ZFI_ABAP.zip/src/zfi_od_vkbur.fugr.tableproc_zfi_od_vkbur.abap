*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_OD_VKBUR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_OD_VKBUR        .

  PERFORM TABLEPROC.

ENDFUNCTION.
