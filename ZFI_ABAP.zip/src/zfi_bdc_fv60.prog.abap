*&---------------------------------------------------------------------*
*& Report ZFI_BDC_FV60
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zfi_bdc_fv60.

*INCLUDE zfi_bdc_fv60_TOP.
*INCLUDE zfi_bdc_fv60_SCR.
*INCLUDE zfi_bdc_fv60_FORM.
*
**&---------------------------------------------------------------------*
**& Report ZFI_BDC_FV60
**&---------------------------------------------------------------------*
*&

*---------------------------------------------------------------------*
* Types – columns map 1:1 with Excel header row
*---------------------------------------------------------------------*
TYPES: BEGIN OF ty_itab,
         doc_no       TYPE char25,
         bukrs        TYPE char4,   " INVFO-BUKRS (Company Code)
         accnt        TYPE char10,  " INVFO-ACCNT  (Vendor)
         bldat        TYPE char10,  " INVFO-BLDAT  (Doc Date, DD.MM.YYYY)
         budat        TYPE char10,  " INVFO-BUDAT  (Posting Date)
         blart        TYPE char2,   " INVFO-BLART  (e.g. KR)
         xblnr        TYPE char16,  " INVFO-XBLNR  (Reference)
         waers        TYPE char5,   " INVFO-WAERS  (INR, etc.)
         wrbtr_h      TYPE char20,  " INVFO-WRBTR  (Header Amount)
         xmwst        TYPE char1,   " INVFO-XMWST  ('X' to calc tax)
         mwskz        TYPE char2,   " INVFO-MWSKZ  (Tax Code)

         bupla        TYPE char10,  " INVFO-BUPLA  (Business Place)
         secco        TYPE char10,  " INVFO-SECCO  (Section Code)
         sgtxt_h      TYPE char50,  " INVFO-SGTXT  (Header Text)
         gst_part     TYPE char20,  " INVFO-GST_PART
         plc_sup      TYPE char5,   " INVFO-PLC_SUP
         zuonr        TYPE  char18, " DJ NEW
         zname        TYPE char50,  " WA_VEND-ZNAME   (optional subscreen)
         zgst         TYPE char20,  " WA_VEND-ZGST
         zinv         TYPE char20,  " WA_VEND-ZINV
         zdate        TYPE char10,  " WA_VEND-ZDATE

         hkont_01     TYPE char10,  " ACGL_ITEM-HKONT(01)
         wrbtr_01     TYPE char20,  " ACGL_ITEM-WRBTR(01) / BSEG-WRBTR
         zuonr_01     TYPE char18,  " ACGL_ITEM-ZUONR(01) / BSEG-ZUONR
         sgtxt_01     TYPE char50,  " ACGL_ITEM-SGTXT(01) / BSEG-SGTXT
         gsber_01     TYPE char10,  " ACGL_ITEM-GSBER(01) / COBL-GSBER
         kostl_01     TYPE char12,  " ACGL_ITEM-KOSTL(01) / COBL-KOSTL
         aufnr_01     TYPE char12,  " ACGL_ITEM-AUFNR(01)
         hsn_sac_01   TYPE char10,  " ACGL_ITEM-HSN_SAC(01)
         mwskz_item   TYPE char2,

         wt_withcd_01 TYPE char2,   " ACWT_ITEM-WT_WITHCD(01)
         wt_qsshb_01  TYPE char20,  " ACWT_ITEM-WT_QSSHB(01)
       END OF ty_itab.

DATA: it_data TYPE STANDARD TABLE OF ty_itab WITH EMPTY KEY.
DATA: it_data1 TYPE STANDARD TABLE OF ty_itab WITH EMPTY KEY.

DATA: bdcdata LIKE bdcdata    OCCURS 0 WITH HEADER LINE,
      messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

DATA: filename TYPE string.
DATA: p_tcode  TYPE tcode VALUE 'FV60'.
"data: lv_hdr_amt type  wrbtr .
DATA: lv_hdr_amt1 TYPE  wrbtr .
TYPES: ty_amount TYPE p LENGTH 16 DECIMALS 2.

DATA: lv_line      TYPE i,
      lv_screen_ln TYPE i,
      lv_idx_c     TYPE char2,
      lv_field     TYPE string.


*---------------------------------------------------------------------*
* Selection-screen (same pattern as your reference)
*---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS : ctu_mode LIKE ctu_params-dismode DEFAULT 'A',

               p_fname  LIKE ibipparms-path OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.


*---------------------------------------------------------------------*
* F4 help for file (same as reference)
*---------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_fname.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = ' '
    IMPORTING
      file_name     = p_fname.

*---------------------------------------------------------------------*
* START-OF-SELECTION
*---------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM gui_upload.
  it_data1[] = it_data[].
  DELETE ADJACENT DUPLICATES FROM it_data1 COMPARING accnt xblnr.
  PERFORM post_fv60.


  " perform bdc_process1.


*---------------------------------------------------------------------*
* GUI_UPLOAD (Excel → internal table) – mirrors your reference approach
*---------------------------------------------------------------------*
FORM gui_upload .
  DATA: p_fname1 TYPE rlgrap-filename,
        it_type  TYPE truxs_t_text_data.

  CLEAR filename.
  filename  = p_fname.
  p_fname1  = filename.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_fname1
    TABLES
      i_tab_converted_data = it_data
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error In Uploading File' TYPE 'E' DISPLAY LIKE 'S'.
    RETURN.
  ENDIF.
ENDFORM. " gui_upload

FORM post_fv60 .


  DATA: lv_screen_ln TYPE i VALUE 0,
        lv_idx_c     TYPE char2,
        lv_field     TYPE string.

  SORT it_data BY doc_no.

  LOOP AT it_data INTO DATA(wa_head).
    DATA(wa_data) = wa_head.
    AT NEW doc_no.

      CLEAR lv_screen_ln.

      "--------------------------------------------------
      " Initial FV60 screens (UNCHANGED)
      "--------------------------------------------------
      PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
      PERFORM bdc_field       USING 'INVFO-ACCNT'
                              wa_data-accnt.
      PERFORM bdc_field       USING 'INVFO-BLDAT'
                                    wa_data-bldat.
      PERFORM bdc_field  USING 'BDC_OKCODE' '/ECCDE'.

      PERFORM bdc_dynpro USING 'SAPLACHD' '1000'.
      PERFORM bdc_field  USING 'BDC_OKCODE' '=ENTR'.
      PERFORM bdc_field  USING 'BKPF-BUKRS' wa_data-bukrs.

      PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
      PERFORM bdc_field USING 'INVFO-ACCNT'    wa_data-accnt.
      PERFORM bdc_field USING 'INVFO-BLDAT'    wa_data-bldat.
      PERFORM bdc_field USING 'INVFO-BUDAT'    wa_data-budat.
      PERFORM bdc_field USING 'INVFO-BLART'    wa_data-blart.
      PERFORM bdc_field USING 'INVFO-XBLNR'    wa_data-xblnr.
      PERFORM bdc_field USING 'INVFO-WAERS'    wa_data-waers.
      PERFORM bdc_field USING 'INVFO-WRBTR'    wa_data-wrbtr_h.
      PERFORM bdc_field USING 'INVFO-XMWST'    wa_data-xmwst.
      PERFORM bdc_field USING 'INVFO-MWSKZ'    wa_data-mwskz.

      "   PERFORM bdc_field USING 'INVFO-ZUONR'    wa_data-ZUONR." DJ NEW

      PERFORM bdc_field USING 'INVFO-BUPLA'     wa_data-bupla.
      PERFORM bdc_field USING 'INVFO-SECCO'     wa_data-secco.

      PERFORM bdc_field USING 'INVFO-SGTXT'     wa_data-sgtxt_h.
      PERFORM bdc_field USING 'INVFO-GST_PART'  wa_data-gst_part.
      PERFORM bdc_field USING 'INVFO-PLC_SUP'   wa_data-plc_sup.

      PERFORM bdc_field USING 'WA_VEND-ZNAME'   wa_data-zname.
      PERFORM bdc_field USING 'WA_VEND-ZGST'    wa_data-zgst.
      PERFORM bdc_field USING 'WA_VEND-ZINV'    wa_data-zinv.
      PERFORM bdc_field USING 'WA_VEND-ZDATE'   wa_data-zdate.

      PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.


*        IF wa_data-wt_withcd_01 IS NOT INITIAL.
*        PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
*        PERFORM bdc_field USING 'BDC_OKCODE' '=WT'.
*        "
*        PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
*        PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
*
*        PERFORM bdc_field  USING 'BDC_CURSOR' 'ACWT_ITEM-WT_WITHCD(01)'.
*        PERFORM bdc_field USING 'ACWT_ITEM-WT_WITHCD(01)'
*                               wa_data-wt_withcd_01.
*        PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
*      ENDIF.

    ENDAT.

    "--------------------------------------------------
    " Line items (Paging every 10 lines)
    "--------------------------------------------------
    lv_screen_ln = lv_screen_ln + 1.



    IF lv_screen_ln = 5.
      lv_screen_ln = lv_screen_ln - 1.
      lv_idx_c = lv_screen_ln.
*        PERFORM bdc_dynpro      USING 'SAPMF05A'
*                                      '1100'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
*      PERFORM bdc_dynpro      USING 'SAPMF05A'
*                                     '1100'.
*
*       PERFORM bdc_field  USING 'BDC_CURSOR' 'ACGL_ITEM-HKONT(10)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.

    ENDIF.

    lv_idx_c = lv_screen_ln.
    SHIFT lv_idx_c LEFT DELETING LEADING ' '.
    IF lv_screen_ln < 10.
      CONCATENATE '0' lv_idx_c INTO lv_idx_c.
    ENDIF.

    PERFORM bdc_dynpro      USING 'SAPMF05A'
                                     '1100'.

*    PERFORM bdc_field  USING 'BDC_CURSOR' 'ACGL_ITEM-HKONT(' lv_idx_c ')'.
    CONCATENATE 'ACGL_ITEM-HKONT(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field  USING 'BDC_CURSOR' lv_field.
    PERFORM bdc_field USING lv_field wa_data-hkont_01.

    CONCATENATE 'ACGL_ITEM-WRBTR(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-wrbtr_01.

    CONCATENATE 'ACGL_ITEM-ZUONR(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-zuonr_01.

    CONCATENATE 'ACGL_ITEM-SGTXT(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-sgtxt_01.

    CONCATENATE 'ACGL_ITEM-GSBER(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-gsber_01.
    "
    CONCATENATE 'ACGL_ITEM-KOSTL(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-kostl_01.

    CONCATENATE 'ACGL_ITEM-AUFNR(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-aufnr_01.

    CONCATENATE 'ACGL_ITEM-HSN_SAC(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-hsn_sac_01.

    CONCATENATE 'ACGL_ITEM-MWSKZ(' lv_idx_c ')' INTO lv_field.
    PERFORM bdc_field USING lv_field wa_data-mwskz_item.
    PERFORM bdc_field USING 'BDC_OKCODE' '/00'.


    "--------------------------------------------------
    " End of one DOC_NO → POST ONCE
    "--------------------------------------------------
    AT END OF doc_no.


*      PERFORM bdc_dynpro      USING 'SAPMF05A'
*                                     '1100'.
      PERFORM bdc_dynpro      USING 'SAPMF05A' '1100'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                              '=PI'.
      PERFORM bdc_field  USING 'BDC_CURSOR' 'ACGL_ITEM-HKONT(01)'.
      PERFORM bdc_dynpro USING 'SAPMF05A' '0300'.
      PERFORM bdc_field  USING 'BDC_CURSOR' 'BSEG-BUPLA'.

      PERFORM bdc_field  USING 'BSEG-BUPLA' wa_data-bupla.
      PERFORM bdc_field  USING 'BDC_OKCODE' '=RW'.
      "     PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
      "   PERFORM bdc_dynpro USING 'SAPMF05A' '0300'.
*      PERFORM bdc_field  USING 'BDC_CURSOR' 'BSEG-WRBTR'.



*      IF wa_data-wt_withcd_01 IS NOT INITIAL.
*        PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
*      PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
*        PERFORM bdc_field USING 'BDC_OKCODE' '=WT'.
*         PERFORM bdc_field  USING 'BDC_CURSOR' 'ACWT_ITEM-WT_WITHCD(01)'.
*        PERFORM bdc_field USING 'ACWT_ITEM-WT_WITHCD(01)'
*                               wa_data-wt_withcd_01.
*      ENDIF.


      IF wa_data-wt_withcd_01 IS NOT INITIAL.
        PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
        PERFORM bdc_field USING 'BDC_OKCODE' '=WT'.
        "
        PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
        PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.

        PERFORM bdc_field  USING 'BDC_CURSOR' 'ACWT_ITEM-WT_WITHCD(01)'.
        PERFORM bdc_field USING 'ACWT_ITEM-WT_WITHCD(01)'
                               wa_data-wt_withcd_01.
        PERFORM bdc_field  USING 'BDC_OKCODE' '/00'.
      ENDIF.
      PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
      PERFORM bdc_field USING 'BDC_OKCODE' '=MORE'.
      perform bdc_dynpro      using 'SAPMF05A' '1100'.
     perform bdc_field       using 'BDC_OKCODE'
                              '/00'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'INVFO-ZUONR'.
      PERFORM bdc_field       USING 'INVFO-ZUONR'
                                     wa_data-zuonr.

      PERFORM bdc_dynpro USING 'SAPMF05A' '1100'.
      PERFORM bdc_field  USING 'BDC_OKCODE' '=PBBP'.

      PERFORM bdc_transaction USING 'FV60'.

    ENDAT.

  ENDLOOP.

ENDFORM.



FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. " bdc_dynpro

FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM. " bdc_field


DATA: gt_bdcmsg TYPE STANDARD TABLE OF bdcmsgcoll.

FORM bdc_transaction USING p_tcode TYPE tcode.
  DATA: w_param TYPE ctu_params.
  w_param-dismode  = ctu_mode.
  w_param-updmode  = 'S'.
  w_param-nobinpt  = 'X'.
  w_param-racommit = 'X'.
  w_param-defsize  = 'X'.

  CALL TRANSACTION p_tcode
       USING    bdcdata
*       MODE     ctu_mode          " N = Background, A = Foreground
*       UPDATE   'S'
      OPTIONS FROM w_param
       MESSAGES INTO gt_bdcmsg.

  IF gt_bdcmsg[] IS INITIAL.

  ELSE.
    DATA: lv_text      TYPE string.
    LOOP AT gt_bdcmsg INTO DATA(ls_msg).
      IF ls_msg-msgnr = 001.
        WRITE: / 'Document Parked Successfully' , ls_msg-msgv1 .
      ELSEIF ( ls_msg-msgtyp = 'S' AND ls_msg-msgspra = 'E' ) OR ls_msg-msgtyp = 'E'.
        CALL FUNCTION 'FORMAT_MESSAGE'
          EXPORTING
            id        = ls_msg-msgid
            lang      = sy-langu
            no        = ls_msg-msgnr
            v1        = ls_msg-msgv1
            v2        = ls_msg-msgv2
            v3        = ls_msg-msgv3
            v4        = ls_msg-msgv4
          IMPORTING
            msg       = lv_text
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
        WRITE: / lv_text.
      ENDIF.
    ENDLOOP.
  ENDIF.
  REFRESH bdcdata.

ENDFORM.
