FUNCTION-POOL ZFI_CASH_DAYS              MESSAGE-ID SV.

* INCLUDE LZFI_CASH_DAYSD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_CASH_DAYST00                       . "view rel. data dcl.
