class ZCL_PIPES_COLLECTION_MIS definition
  public
  final
  create public .

public section.

  data LT_BSTAB type ZFI_COLL_MIS_BS_TT .
  data LS_BSTAB type ZFI_COLL_MIS_BS_TS .
  data LS_KNVV type ZFI_PIPES_MIS_KNVV_TS .
  data LS_FINAL type ZFI_PIPES_MIS_FINAL_TS .

  methods GET_DATA
    importing
      !KDGRP type ANY TABLE optional
      !VKBUR type ANY TABLE optional
      !KUNNR type ANY TABLE optional
      !SPART type ANY TABLE
      !VTWEG type ANY TABLE
      !VKORG type ANY TABLE
    changing
      !LT_KNVV type ZFI_PIPES_MIS_KNVV_TT .
  methods PROCESS_DATA
    importing
      !START_DATE type DATUM
      !END_DATE type DATUM
      !BLART type ANY TABLE
      !BUKRS type ANY TABLE
      !LT_KNVV type ZFI_PIPES_MIS_KNVV_TT
    changing
      !LT_FINAL type ZFI_PIPES_MIS_FINAL_TT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_PIPES_COLLECTION_MIS IMPLEMENTATION.


  METHOD get_data.
    SELECT a~kunnr
           a~vkorg
           a~vtweg
           a~spart
           a~erdat
           a~kdgrp
           a~vkbur
           b~name1
           c~sales_desc
      FROM knvv AS a
      INNER JOIN kna1 AS b ON a~kunnr = b~kunnr
      INNER JOIN zfi_pipes_soff AS c ON a~vkbur = c~vkbur
      INTO CORRESPONDING FIELDS OF TABLE lt_knvv
      WHERE a~kunnr IN kunnr
        AND a~vkorg IN vkorg
        AND a~vtweg IN vtweg
        AND a~spart IN spart
        AND a~kdgrp IN kdgrp
        AND a~vkbur IN vkbur.

    SELECT a~kunnr,
           b~city1,
           b~country,
           b~region,
           c~bezei AS state
      FROM kna1 AS a
      INNER JOIN adrc AS b ON a~adrnr = b~addrnumber
      INNER JOIN t005u AS c ON b~region = c~bland AND b~country = c~land1
      INTO TABLE @DATA(lt_addr)
      FOR ALL ENTRIES IN @lt_knvv
      WHERE a~kunnr = @lt_knvv-kunnr
        AND c~spras = @sy-langu.

    LOOP AT lt_knvv ASSIGNING FIELD-SYMBOL(<ls>).
      <ls>-city1 = VALUE #( lt_addr[ kunnr = <ls>-kunnr ]-city1 OPTIONAL ).
      <ls>-state = VALUE #( lt_addr[ kunnr = <ls>-kunnr ]-state OPTIONAL ).
    ENDLOOP.

  ENDMETHOD.


  METHOD process_data.
    IF lt_knvv[] IS NOT INITIAL.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
        FROM bsid
        INTO TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz NOT IN ( 'I' , 'Q' )
          AND ( budat >= start_date AND budat <= end_date ) "lv_end
          AND blart IN blart.
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr blart.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
        FROM bsad
        APPENDING TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz NOT IN ( 'I' , 'Q' )
          AND ( budat >= start_date AND budat <= end_date )
          AND blart IN blart. "Comment by Rahul Vasita on 23.03.2024 14:24:48
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr blart.

      DELETE lt_bstab WHERE blart = 'RV' AND shkzg = 'S'.

      IF lt_bstab[] IS NOT INITIAL.
        SELECT bukrs,
               belnr,
               gjahr,
               buzei,
               koart,
               hkont,
               kunnr
          FROM bseg
          INTO TABLE @DATA(lt_bseg)
          FOR ALL ENTRIES IN @lt_bstab
          WHERE bukrs = @lt_bstab-bukrs
            AND belnr = @lt_bstab-belnr
            AND gjahr = @lt_bstab-gjahr
*          AND buzei = @lt_bstab-buzei.
*          AND kunnr = @lt_bstab-kunnr
            AND koart = 'S'.
      ENDIF."IF lt_bstab[] IS NOT INITIAL.

      SORT lt_bseg ASCENDING BY bukrs belnr gjahr hkont.
      IF lt_bseg IS NOT INITIAL.
        SELECT banka,
               hkont
          FROM zfi_pipes_bank
          INTO TABLE @DATA(lt_bank)
          FOR ALL ENTRIES IN @lt_bseg
          WHERE hkont = @lt_bseg-hkont.
      ENDIF."IF lt_bseg is NOT INITIAL.


      DATA(lt_bstab_copy) = lt_bstab[].
      SORT lt_bstab_copy ASCENDING BY bukrs kunnr.
      DELETE ADJACENT DUPLICATES FROM lt_bstab_copy COMPARING bukrs kunnr gjahr belnr.

      LOOP AT lt_bstab_copy INTO DATA(ls_copy).
        LOOP AT lt_bstab INTO ls_bstab WHERE bukrs = ls_copy-bukrs AND kunnr = ls_copy-kunnr
                                         AND gjahr = ls_copy-gjahr AND belnr = ls_copy-belnr.
          CASE ls_bstab-blart.
            WHEN 'DZ' OR 'DA'.
*              IF ls_bstab-dmbtr < 0.
              IF ls_bstab-shkzg = 'S'.
                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
              ENDIF."ls_bstab-dmbtr < 0.
              ls_final-coll_amt = ls_final-coll_amt + ls_bstab-dmbtr.

            WHEN 'RV'.
*              IF ls_bstab-dmbtr < 0.
              IF ls_bstab-shkzg = 'H'.
                ls_final-credit_not_amt = ls_final-credit_not_amt +  ls_bstab-dmbtr .
              ENDIF."ls_bstab-dmbtr < 0.
            WHEN 'DG'.
*              IF ls_bstab-dmbtr < 0.
              IF ls_bstab-shkzg = 'S'.
                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
              ENDIF."ls_bstab-dmbtr < 0.
              ls_final-credit_not_amt = ls_final-credit_not_amt +  ls_bstab-dmbtr .
          ENDCASE.
          CLEAR ls_bstab.

        ENDLOOP.
        IF ls_final IS NOT INITIAL.
          ls_final-belnr = ls_copy-belnr.
          ls_final-budat = ls_copy-budat.
          IF ls_final-coll_amt <> '0' AND ls_final-credit_not_amt = '0' .
            ls_final-hkont = VALUE #( lt_bseg[ bukrs = ls_copy-bukrs
                                               belnr = ls_copy-belnr
                                               gjahr = ls_copy-gjahr ]-hkont OPTIONAL ).
            IF ls_final-hkont IS NOT INITIAL.

              ls_final-banka = VALUE #( lt_bank[ hkont = ls_final-hkont ]-banka OPTIONAL ).
            ENDIF.
          ENDIF.
          ls_knvv = VALUE #( lt_knvv[ kunnr = ls_copy-kunnr ] OPTIONAL ).
          IF ls_knvv IS NOT INITIAL.
            ls_final-kunnr = ls_knvv-kunnr.
            ls_final-vkorg = ls_knvv-vkorg.
            ls_final-name1 = ls_knvv-name1.
            ls_final-sales_desc = ls_knvv-sales_desc.
            ls_final-city1 = ls_knvv-city1.
            ls_final-state = ls_knvv-state.
            IF ls_final-banka IS NOT INITIAL.
              CONCATENATE ls_final-banka ls_knvv-sales_desc INTO ls_final-bank_div SEPARATED BY '-'.
            ELSE.
              ls_final-bank_div  = ls_knvv-sales_desc .
            ENDIF.
            IF ls_final-sales_desc IS NOT INITIAL.
              SELECT SINGLE vkbur INTO ls_final-vkbur FROM zfi_pipes_soff WHERE sales_desc = ls_final-sales_desc.
            ENDIF.
          ENDIF."ls_knvv is NOT INITIAL.

          ls_final-total_amt = ls_final-credit_not_amt + ls_final-coll_amt.
          APPEND ls_final TO lt_final.
          CLEAR : ls_final , ls_knvv.
        ENDIF.
      ENDLOOP.

    ELSE.
      MESSAGE 'No Customer Data Found' TYPE 'E'.
    ENDIF."lt_knvv[] IS NOT INITIAL.
    DELETE lt_final WHERE budat = '00000000'.
  ENDMETHOD.
ENDCLASS.
