FUNCTION-POOL ZFI_ISD_SPLIT              MESSAGE-ID SV.

* INCLUDE LZFI_ISD_SPLITD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_ISD_SPLITT00                       . "view rel. data dcl.
