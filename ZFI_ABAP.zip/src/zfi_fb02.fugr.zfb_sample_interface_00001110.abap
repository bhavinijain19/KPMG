FUNCTION zfb_sample_interface_00001110.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_XBKPF) LIKE  BKPF STRUCTURE  BKPF
*"     VALUE(I_YBKPF) LIKE  BKPF STRUCTURE  BKPF
*"  TABLES
*"      XBSED STRUCTURE  FBSED
*"      YBSED STRUCTURE  FBSED
*"      XBSEG STRUCTURE  FBSEG
*"      YBSEG STRUCTURE  FBSEG
*"----------------------------------------------------------------------

*BREAK-POINT.
  TYPES : BEGIN OF ty_bseg,
            bukrs TYPE bseg-bukrs,
            belnr TYPE bseg-belnr,
            gjahr TYPE bseg-gjahr,
            zlspr TYPE bseg-zlspr,
          END OF ty_bseg.

  DATA:it_bseg TYPE STANDARD TABLE OF ty_bseg,
       wa_bseg TYPE ty_bseg.

  TYPES: BEGIN OF ty_user,
           name TYPE tvarvc-name,
           low  TYPE tvarvc-low,
         END OF ty_user.

  DATA: it_user TYPE STANDARD TABLE OF ty_user,
        wa_user TYPE ty_user.

  TYPES: BEGIN OF ty_tcode,
           name TYPE tvarvc-name,
           low  TYPE tvarvc-low,
         END OF ty_tcode.

  DATA: it_tcode TYPE STANDARD TABLE OF ty_tcode,
        wa_tcode TYPE ty_tcode.

  DATA: i_code TYPE tvarvc-low.

  SELECT name
          low
     FROM tvarvc
     INTO TABLE it_user
     WHERE name = 'ZFI_USER_FB02'
       AND type = 'S'.

  SELECT name
        low
   FROM tvarvc
   INTO TABLE it_tcode
   WHERE name = 'ZFI_PMT_BLK_T'
     AND type = 'S'.



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*   SELECT single
*         low
*    FROM tvarvc
*    INTO i_code
*    WHERE name = 'ZFI_PMT_BLK_I'
*      AND type = 'P'.

  SELECT
   low FROM tvarvc INTO i_code UP TO 1 ROWS WHERE name = 'ZFI_PMT_BLK_I' AND type = 'P'
   ORDER BY PRIMARY KEY .
  ENDSELECT.
* End of Quick Fix



  READ TABLE it_tcode INTO wa_tcode WITH KEY low = sy-tcode.
  IF sy-subrc = 0.


    READ TABLE it_user INTO wa_user WITH KEY low = sy-uname.
    IF sy-subrc <> 0.


* Quick Fix Replace SELECT from table BSEG by API Call
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT bukrs belnr gjahr zlspr FROM bseg
*        INTO TABLE it_bseg
*        FOR ALL ENTRIES IN xbseg
*        WHERE bukrs = xbseg-bukrs
*        AND   belnr = xbseg-belnr
*        AND   gjahr = xbseg-gjahr.
**

      SELECT
            companycode          AS bukrs,
            accountingdocument   AS belnr,
            fiscalyear           AS gjahr,
            paymentblockingreason AS zlspr
          FROM i_operationalacctgdocitem
          INTO TABLE @it_bseg
          FOR ALL ENTRIES IN @xbseg
          WHERE companycode        = @xbseg-bukrs
            AND accountingdocument = @xbseg-belnr
            AND fiscalyear         = @xbseg-gjahr.

* End of Quick Fix



      LOOP AT it_bseg INTO wa_bseg.
        IF wa_bseg-zlspr = i_code.
          READ TABLE xbseg WITH KEY bukrs = wa_bseg-bukrs belnr = wa_bseg-belnr gjahr = wa_bseg-gjahr.
          IF xbseg-zlspr = ' '.
            MESSAGE e032(zfi) WITH sy-uname .
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

  ENDIF.
*endif.

ENDFUNCTION.
