*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_FB02TOP.                      " Global Declarations
  INCLUDE LZFI_FB02UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_FB02F...                      " Subroutines
* INCLUDE LZFI_FB02O...                      " PBO-Modules
* INCLUDE LZFI_FB02I...                      " PAI-Modules
* INCLUDE LZFI_FB02E...                      " Events
* INCLUDE LZFI_FB02P...                      " Local class implement.
* INCLUDE LZFI_FB02T99.                      " ABAP Unit tests
