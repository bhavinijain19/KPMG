*&---------------------------------------------------------------------*
*&  Include  ZCFP1_USER_COMMAND_1000I01
*&---------------------------------------------------------------------*

*&SPWIZARD: INPUT MODULE FOR TC 'TC_REG'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: MODIFY TABLE
MODULE tc_reg_modify INPUT.
*  break sap_abap.
  IF sy-ucomm = c_save.

*    IF wa_part-zbank IS INITIAL.
*      MESSAGE e001(00) WITH text-e08.
*    ENDIF.
*
*    IF wa_part-zlimit IS INITIAL.
*      MESSAGE e001(00) WITH text-e04.
*    ENDIF.
*
*    IF wa_part-zfrom_date IS INITIAL.
*      MESSAGE e001(00) WITH text-e05.
*    ENDIF.
*
*    IF wa_part-zto_date IS INITIAL.
*      MESSAGE e001(00) WITH text-e06.
*    ENDIF.

*    IF wa_part-zfrom_date GE wa_part-zto_date.
*      MESSAGE e001(00) WITH text-e09.
*    ENDIF.

*    IF wa_part-zchange_dt IS NOT INITIAL.
*      IF wa_part-zfrom_date GT wa_part-zchange_dt.
*        MESSAGE e001(00) WITH text-e10.
*      ENDIF.
*    ENDIF.

*    IF wa_part-zagr_ren_dt LE wa_part-zagr_exp_date.
*      MESSAGE e001(00) WITH text-e12.
*    ENDIF.
*
*    IF wa_part-zinterest_rate > 100.
*      MESSAGE e001(00) WITH text-e11.
*    ENDIF.

    IF wa_part-kunnr IS NOT INITIAL.
      IF wa_part-zenhancement  IS NOT INITIAL OR wa_part-zdecrease IS NOT INITIAL.
        IF wa_part-zchange_dt IS INITIAL.
          MESSAGE e001(00) WITH text-e07.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

    IF wa_part-zbank IS INITIAL.
      MESSAGE e001(00) WITH text-e08.
    ENDIF.

    IF wa_part-zlimit IS INITIAL.
      MESSAGE e001(00) WITH text-e04.
    ENDIF.

    IF wa_part-zfrom_date IS INITIAL.
      MESSAGE e001(00) WITH text-e05.
    ENDIF.

    IF wa_part-zto_date IS INITIAL.
      MESSAGE e001(00) WITH text-e06.
    ENDIF.

  IF wa_part-zmail IS NOT INITIAL.
    SPLIT wa_part-zmail AT '@' INTO DATA(w_s1) DATA(w_s2).
    IF wa_part-zmail NP '*@*' OR w_s2 IS INITIAL.
      MESSAGE e001(00) WITH text-e13.
    ENDIF.
  ENDIF.

*  IF wa_part-kunnr IS NOT INITIAL.
    IF wa_part-zenhancement  IS NOT INITIAL OR wa_part-zdecrease IS NOT INITIAL.
      IF wa_part-zchange_dt IS INITIAL.
        MESSAGE e001(00) WITH text-e07.
      ENDIF.
    ENDIF.
*  ENDIF.


  IF wa_part-zfrom_date IS NOT INITIAL AND wa_part-zto_date IS NOT INITIAL.
    IF wa_part-zfrom_date GE wa_part-zto_date.
      MESSAGE e001(00) WITH text-e09.
    ENDIF.
  ENDIF.

  IF wa_part-zchange_dt IS NOT INITIAL.
    IF wa_part-zfrom_date GT wa_part-zchange_dt.
      MESSAGE e001(00) WITH text-e10.
    ENDIF.
  ENDIF.

  IF wa_part-zagr_ren_dt  IS NOT INITIAL AND wa_part-zagr_exp_date IS NOT INITIAL.
    IF wa_part-zagr_ren_dt LE wa_part-zagr_exp_date.
      MESSAGE e001(00) WITH text-e12.
    ENDIF.
  ENDIF.

  IF wa_part-zagr_date  IS NOT INITIAL AND wa_part-zagr_exp_date IS NOT INITIAL.
    IF wa_part-zagr_date > wa_part-zagr_exp_date.
      MESSAGE e001(00) WITH text-e16.
    ENDIF.
  ENDIF.

  IF wa_part-zinterest_rate > 100.
    MESSAGE e001(00) WITH text-e11.
  ENDIF.

  DATA : w_len  TYPE i,
         w_len1 TYPE i.
  IF wa_part-zphone IS NOT INITIAL.
    SHIFT wa_part-zphone LEFT DELETING LEADING '0'.
    CLEAR w_len.
    w_len = strlen( wa_part-zphone ).
    IF w_len LT 10.
      MESSAGE e001(00) WITH text-e14.
    ENDIF.
  ENDIF.

  IF wa_part-zifsc IS NOT INITIAL.
    CLEAR w_len1.
    w_len1 = strlen( wa_part-zifsc ).
    IF w_len1 < 11.
      MESSAGE e001(00) WITH text-e15.
    ENDIF.
  ENDIF.

  MODIFY it_part
    FROM wa_part
    INDEX tc_reg-current_line.
ENDMODULE.

MODULE tc_reg_user_command INPUT.
  ok_code = sy-ucomm.
  PERFORM user_ok_tc USING    'TC_REG'
                              'IT_PART'
                              ' '
                     CHANGING ok_code.
  sy-ucomm = ok_code.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.
  DATA : w_lines TYPE i,
         w_flag  TYPE c,
         w_error TYPE c,
         w_cnt   TYPE i,
         w_srno  TYPE p DECIMALS 3.
  CLEAR : w_lines, w_cnt.
  FIELD-SYMBOLS : <fs_part> TYPE zfi_partner_data.

  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = w_kunnr
    IMPORTING
      output = w_kunnr.

  SELECT SINGLE name1 FROM kna1 INTO w_name WHERE kunnr = w_kunnr.

  CASE sy-ucomm.
    WHEN c_back OR c_cancel OR c_exit.
      SET SCREEN 0.
    WHEN c_fetch.
      DATA : l_new   TYPE c,
             l_end   TYPE c,
             l_total TYPE zfi_partner_data-zlimit.

      SELECT * FROM zfi_partner_data INTO TABLE it_part WHERE bukrs = w_bukrs AND kunnr = w_kunnr.
      IF sy-subrc = 0.
        SORT it_part BY bukrs kunnr zsrno zbank zsrno1 DESCENDING.
        DELETE ADJACENT DUPLICATES FROM it_part COMPARING bukrs kunnr zsrno zbank.
* --------------------------
*        READ TABLE it_part INTO DATA(ls_part) INDEX 1.
        LOOP AT it_part ASSIGNING FIELD-SYMBOL(<ls_part>).
*        IF sy-subrc = 0.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*          SELECT * FROM zfi_partner_data
*             INTO TABLE @DATA(it_temp)
*              WHERE bukrs = @<ls_part>-bukrs
*               AND kunnr = @<ls_part>-kunnr
*               AND zsrno = @<ls_part>-zsrno.

SELECT * FROM ZFI_PARTNER_DATA
 INTO TABLE @DATA(IT_TEMP)
 WHERE BUKRS = @<LS_PART>-BUKRS
 AND KUNNR = @<LS_PART>-KUNNR
 AND ZSRNO = @<LS_PART>-ZSRNO
 ORDER BY PRIMARY KEY .
* End of Quick Fix

          IF sy-subrc = 0.
            LOOP AT it_temp INTO DATA(ls_temp) WHERE bukrs = <ls_part>-bukrs
                                                 AND kunnr = <ls_part>-kunnr
                                                 AND zsrno = <ls_part>-zsrno..
              AT NEW zsrno.
                l_new = 'X'.
              ENDAT.

              AT END OF zsrno.
                l_end = 'X'.
              ENDAT.
              IF l_new = 'X'.
                CLEAR l_total.
                ls_temp-ztotal = ls_temp-zlimit + ls_temp-zenhancement - ls_temp-zdecrease.
                l_total = ls_temp-ztotal.
              ELSE.
                ls_temp-ztotal = l_total + ls_temp-zenhancement - ls_temp-zdecrease.
                l_total = ls_temp-ztotal.
              ENDIF.
              CLEAR: l_end, l_new.
            ENDLOOP.
          ENDIF.


          <ls_part>-ztotal = l_total.

          CLEAR l_total.
        ENDLOOP.

        LOOP AT it_part ASSIGNING <fs_part>.
          CLEAR : <fs_part>-zenhancement, <fs_part>-zdecrease, <fs_part>-zchange_dt.
        ENDLOOP.
* --------------------------

      ENDIF.
    WHEN c_new.
      REFRESH it_part[].
    WHEN c_save.
      CLEAR : w_error, w_flag.

      IF it_part IS INITIAL.
*        MESSAGE e001(00) WITH text-e17.
      ENDIF.

      DELETE it_part WHERE zbank IS INITIAL.
      LOOP AT it_part INTO wa_part.
        IF wa_part-zlimit IS INITIAL.
          MESSAGE w001(00) WITH text-e04 DISPLAY LIKE 'E'.
          w_error = c_x.
        ENDIF.

        IF wa_part-zfrom_date IS INITIAL.
          MESSAGE e001(00) WITH text-e05.
          w_error = c_x.
        ENDIF.

        IF wa_part-zto_date IS INITIAL.
          MESSAGE e001(00) WITH text-e06.
          w_error = c_x.
        ENDIF.

        IF           w_error = c_x.
          LEAVE TO SCREEN 0100.
        ENDIF.
      ENDLOOP.
      CLEAR w_srno.
      DELETE it_part WHERE zbank IS INITIAL.
      READ TABLE it_part INTO DATA(lwa_part) INDEX 1.
      IF lwa_part-kunnr IS INITIAL.   "New records


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT * FROM zfi_partner_data INTO TABLE @DATA(it_old) WHERE bukrs = @w_bukrs AND kunnr = @w_kunnr.

SELECT * FROM ZFI_PARTNER_DATA INTO TABLE @DATA(IT_OLD) WHERE BUKRS = @W_BUKRS AND KUNNR = @W_KUNNR
 ORDER BY PRIMARY KEY .

* End of Quick Fix

        IF sy-subrc = 0.
*          delete ADJACENT DUPLICATES FROM it_old COMPARING bukrs kunnr zsrno.
          DESCRIBE TABLE it_old LINES w_lines.
          READ TABLE it_old INTO DATA(ls_old) INDEX w_lines.
          w_cnt = ls_old-zsrno.
*          w_cnt = w_lines.
*          w_srno = w_cnt + 1.
*          SORT it_old BY zsrno1 DESCENDING.
*          READ TABLE it_old INTO DATA(ls_old) INDEX 1.
*          IF sy-subrc = 0.
*            w_srno = ls_old-zsrno1.
        ENDIF.


        DATA : w_1 TYPE p DECIMALS 1 VALUE '0.1'.

        IF w_srno IS INITIAL.
          w_srno = 1.
        ENDIF.
        LOOP AT it_part ASSIGNING <fs_part>.
          w_cnt = w_cnt + 1.
          w_srno = w_cnt + w_1.
          <fs_part>-bukrs = w_bukrs.
          <fs_part>-kunnr = w_kunnr.
          <fs_part>-zsrno = w_cnt.
          <fs_part>-zsrno1 = w_srno.
          <fs_part>-zlog_user = sy-uname.
          <fs_part>-zlog_date = sy-datum.
          <fs_part>-zlog_time = sy-uzeit.
*          <fs_part>-ztotal = <fs_part>-ztotal + <fs_part>-zenhancement - <fs_part>-zdecrease.
          CLEAR <fs_part>-ztotal.
          IF <fs_part>-zlimit IS INITIAL.
            w_flag = c_x.
            EXIT.
          ENDIF.
        ENDLOOP.
      ELSE.

        LOOP AT it_part ASSIGNING <fs_part> WHERE zlimit IS INITIAL.
          w_flag = c_x.
        ENDLOOP.

        LOOP AT it_part ASSIGNING <fs_part>.
          <fs_part>-zsrno1 = <fs_part>-zsrno1 + w_1.
          <fs_part>-zlog_user = sy-uname.
          <fs_part>-zlog_date = sy-datum.
          <fs_part>-zlog_time = sy-uzeit.
          CLEAR <fs_part>-ztotal.
        ENDLOOP.

      ENDIF.


      MODIFY zfi_partner_data FROM TABLE it_part.
      IF sy-subrc = 0.
        MESSAGE s001(00) WITH text-s01.
      ENDIF.
  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALIDATION  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_validation INPUT.
  SELECT SINGLE bukrs FROM t001 INTO @DATA(l_bukrs) WHERE bukrs = @w_bukrs.
  IF sy-subrc NE 0.
    MESSAGE e001(00) WITH text-e03.
  ENDIF.

  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = w_kunnr
    IMPORTING
      output = w_kunnr.
  .

  SELECT SINGLE kunnr FROM kna1 INTO @DATA(l_kunnr) WHERE kunnr = @w_kunnr.
  IF sy-subrc NE 0.
    MESSAGE e001(00) WITH text-e01.
  ENDIF.


ENDMODULE.
