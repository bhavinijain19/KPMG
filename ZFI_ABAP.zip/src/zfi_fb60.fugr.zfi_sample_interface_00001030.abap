FUNCTION zfi_sample_interface_00001030.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_BKDF) LIKE  BKDF STRUCTURE  BKDF
*"     VALUE(I_UF05A) LIKE  UF05A STRUCTURE  UF05A
*"     VALUE(I_XVBUP) LIKE  OFIWA-XVBUP DEFAULT 'X'
*"     VALUE(I_BKPF) LIKE  BKPF STRUCTURE  BKPF OPTIONAL
*"  TABLES
*"      T_AUSZ1 STRUCTURE  AUSZ1 OPTIONAL
*"      T_AUSZ2 STRUCTURE  AUSZ2 OPTIONAL
*"      T_AUSZ3 STRUCTURE  AUSZ_CLR OPTIONAL
*"      T_BKP1 STRUCTURE  BKP1
*"      T_BKPF STRUCTURE  BKPF
*"      T_BSEC STRUCTURE  BSEC
*"      T_BSED STRUCTURE  BSED
*"      T_BSEG STRUCTURE  BSEG
*"      T_BSET STRUCTURE  BSET
*"      T_BSEU STRUCTURE  BSEU
*"      T_WITH_ITEM STRUCTURE  ACWT_ITEM OPTIONAL
*"----------------------------------------------------------------------

  DATA: it_vend   TYPE STANDARD TABLE OF zfi_vend_details,
        wa_vend   TYPE zfi_vend_details,
        wa_vend1  TYPE zfi_vend_details,
        wa_vend_t TYPE zfi_vend_details.

  DATA: moff    TYPE i,
        mlen    TYPE i,
        s1      TYPE string,
        s2      TYPE string,
        len(10) TYPE n.


  IF sy-tcode = 'FV60'.

    IMPORT it_vend TO wa_vend_t FROM MEMORY ID 'ZFB60'.
    FREE MEMORY ID 'ZFB60'.

    SELECT SINGLE * FROM zfi_vend_details INTO wa_vend WHERE bukrs = t_bkpf-bukrs AND belnr = t_bkpf-belnr AND gjahr = t_bkpf-gjahr.
    IF sy-subrc = 0.

      IF wa_vend1-zgst IS NOT INITIAL  .

        len = strlen( wa_vend1-zgst ).

        FIND REGEX `\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}`
             IN wa_vend1-zgst
             IGNORING CASE
             MATCH OFFSET moff
             MATCH LENGTH mlen
             SUBMATCHES s1 s2.
        IF sy-subrc NE 0.
          MESSAGE e398(00) WITH 'Please Enter Valid GSTN No. Pattern should matched'.
        ENDIF.

        IF mlen <> 15.
          MESSAGE e398(00) WITH 'Please Enter Valid GSTN No length'.
        ENDIF.
        CLEAR: mlen, len.

      ENDIF.

      IF wa_vend1-zname NE wa_vend-zname.
        wa_vend-zname = wa_vend1-zname.
      ENDIF.

      IF wa_vend1-zgst NE wa_vend-zgst.
        wa_vend-zgst  = wa_vend1-zgst.
      ENDIF.

      IF wa_vend1-zinv NE wa_vend-zinv.
        wa_vend-zinv  = wa_vend1-zinv.
      ENDIF.

      IF wa_vend1-zdate NE wa_vend-zdate.
        wa_vend-zdate = wa_vend1-zdate.
      ENDIF.

      IF wa_vend-zname IS INITIAL AND wa_vend-zgst IS INITIAL AND wa_vend-zinv IS INITIAL.
        DELETE zfi_vend_details FROM wa_vend.
        CLEAR: wa_vend.
      ELSE.
        MODIFY zfi_vend_details FROM wa_vend.
        CLEAR: wa_vend.
      ENDIF.


    ENDIF.

  ELSEIF sy-tcode = 'FB60'.

    IMPORT it_vend TO wa_vend_t FROM MEMORY ID 'ZFB60_T'.
    FREE MEMORY ID 'ZFB60'.

    wa_vend = wa_vend_t.

    IF wa_vend-zname IS NOT INITIAL AND wa_vend-zgst IS NOT INITIAL
      AND wa_vend-zinv IS NOT INITIAL AND wa_vend-zdate IS NOT INITIAL.

      IF wa_vend-zgst IS NOT INITIAL  .

        len = strlen( wa_vend-zgst ).

        FIND REGEX `\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}`
             IN wa_vend-zgst
             IGNORING CASE
             MATCH OFFSET moff
             MATCH LENGTH mlen
             SUBMATCHES s1 s2.
        IF sy-subrc NE 0.
          MESSAGE e398(00) WITH 'Please Enter Valid GSTN No. Pattern should matched'.
        ENDIF.

        IF mlen <> 15.
          MESSAGE e398(00) WITH 'Please Enter Valid GSTN No length'.
        ENDIF.
        CLEAR: mlen, len.

      ENDIF.

      wa_vend-bukrs = t_bkpf-bukrs.
      wa_vend-belnr = t_bkpf-belnr.
      wa_vend-gjahr = t_bkpf-gjahr.

      MODIFY zfi_vend_details FROM wa_vend.
      CLEAR: wa_vend.

    ENDIF.

  ENDIF.

********************************  ADDED BY PARTH 18.02.2026

  DATA: lv_fy(4) TYPE c,
      lv_fiscal TYPE gjahr.
DATA: lv_firstd TYPE sy-datum,
      lv_lastd  TYPE sy-datum.

  TYPES: BEGIN OF ty_tvarvc,
             sign   TYPE char01,
             option TYPE char02,
             low    TYPE rvari_val_255,
             high   TYPE rvari_val_255,
           END OF ty_tvarvc,
           tt_tvarvc TYPE TABLE OF ty_tvarvc.
    DATA: rt_tcode  TYPE TABLE OF ty_tvarvc.
DATA:Yt_tvarvc TYPE TABLE OF tvarvc.

     SELECT *
       INTO TABLE Yt_tvarvc
        FROM tvarvc
        WHERE name  = 'ZFI_VALID_TCODE' .
    IF sy-subrc = 0.
          rt_tcode = VALUE #( FOR lw_tvarvc IN Yt_tvarvc
                            WHERE ( name = 'ZFI_VALID_TCODE' )
                            ( sign = lw_tvarvc-sign
                              option = lw_tvarvc-opti
                              low = lw_tvarvc-low
                              high = lw_tvarvc-high ) ).
          ENDIF.

*    IF sy-tcode = 'FV60' OR sy-tcode = 'FB60' OR sy-tcode = 'FV65' OR sy-tcode = 'MIRO' OR sy-tcode = 'MIR7' OR sy-tcode =  'FB65'.
IF sy-tcode IN rt_tcode.
  data:llt_tvar TYPE TABLE OF tvarvc.
  DATA LOW  TYPE STRING.
    SELECT *
      FROM tvarvc
       INTO TABLE llt_tvar   "Table for tvarvc
        WHERE name  = 'ZFI_REFERENCE' .


       READ TABLE llt_tvar INTO data(lw_tvar) INDEX 1.
       if sy-subrc = 0.
         LOW = lw_tvar-low.
        if  t_bkpf-xblnr CA CONV STRING( lw_tvar-low ) .

*      IF invfo-xblnr CA ';:_`~!@#$%^&*()+=|\]}{["?.>,<' or invfo-xblnr CA | ' |.
        MESSAGE | Only - and / are Allowed in a Reference | TYPE 'E' .
      ENDIF.
      ENDIF.

           IF t_bkpf-bldat GT sy-datum.
        MESSAGE 'Please do not enter future date for Document date' TYPE 'E'  DISPLAY LIKE 'E'.
      ENDIF.

"""""""""Added  By Pankaj K on 14.03.2024
DATA: LV_VALUE TYPE TVARVC.
DATA: Lt_VALUE TYPE TABLE OF TVARVC.
      SELECT  * FROM tvarvc INTO TABLE lt_value where NAME = 'Z_DOC DATE_VALIDATE'.
        READ TABLE lt_value INTO data(wa_value) INDEX 1.
        lv_value = wa_value-low.

if  wa_value-low is NOT INITIAL. "added by parth 01.04.2024
IF  t_bkpf-BLDAT IS NOT INITIAL.
*  Get fiscal year
  CALL FUNCTION 'GM_GET_FISCAL_YEAR'
    EXPORTING
      i_date =  t_bkpf-BLDAT
      i_fyv  = 'V3'
    IMPORTING
      e_fy   = lv_fy.

  IF lv_fy IS NOT INITIAL.
    lv_fiscal = lv_fy.

*   Get first and last date for fiscal year
    CALL FUNCTION 'FIRST_AND_LAST_DAY_IN_YEAR_GET'
      EXPORTING
        i_gjahr        = lv_fiscal
        i_periv        = 'V3'
      IMPORTING
        e_first_day    = lv_firstd
        e_last_day     = lv_lastd
      EXCEPTIONS
        input_false    = 1
        t009_notfound  = 2
        t009b_notfound = 3
        OTHERS         = 4.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    DATA(lv_postyear) = lv_fy + 1.
    DATA: lv_post_date TYPE char10,
          lv_postyear1 TYPE char4.

    DATA: lv_limit_date TYPE sy-datum.

    lv_postyear1 = lv_postyear.

           CONCATENATE lv_postyear1 lv_value INTO lv_post_date.
           CONDENSE lv_post_date NO-GAPS.

    lv_limit_date = lv_post_date.

    IF  t_bkpf-budat NOT BETWEEN lv_firstd AND lv_limit_date.
      MESSAGE 'Document date is not in valid period' TYPE 'E'.
    ENDIF.
  ENDIF.
  ENDIF.
      ENDIF.
endif. " 01.04.2024  added by parth .

ENDFUNCTION.
