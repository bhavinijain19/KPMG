*&---------------------------------------------------------------------*
*&  Include           ZFI_CRITICAL_OD_SS
*&---------------------------------------------------------------------*
SELECTION-SCREEN COMMENT /60(70) xstr.
SELECTION-SCREEN BEGIN OF BLOCK blk1 WITH FRAME TITLE text-001.
SELECT-OPTIONS: regio  FOR kna1-regio NO INTERVALS,
                party  FOR bsid-kunnr,
*                s_kdgrp  FOR knvv-kdgrp,
                s_vkbur FOR knvv-vkbur. "OBLIGATORY.
*                code   FOR bsid-bukrs  DEFAULT '1000' NO INTERVALS OBLIGATORY.
PARAMETERS :    fsyr   LIKE bkpf-gjahr OBLIGATORY,
                s_date LIKE bapi3007-key_date   OBLIGATORY,
                code   LIKE bsid-bukrs OBLIGATORY DEFAULT '1000'.
SELECT-OPTIONS: vkorg  FOR knvv-vkorg OBLIGATORY  NO INTERVALS.
SELECT-OPTIONS: akont FOR knb1-akont ."NO-DISPLAY.
select-options : s_bzirk for knvv-bzirk.  " Added by Raj 4806 on 02.03.2023
SELECT-OPTIONS: s_vkgrp FOR knvv-vkgrp.   " Added by Raj 4806 on 02.03.2023
SELECTION-SCREEN END OF BLOCK blk1.

SELECTION-SCREEN BEGIN OF BLOCK blk2 WITH FRAME TITLE text-002.
SELECTION-SCREEN BEGIN OF LINE.
PARAMETERS:   ageslb1(3) TYPE n DEFAULT  15,  "8,
              ageslb2(3) TYPE n DEFAULT  30,  "15,
              ageslb3(3) TYPE n DEFAULT  60,  "30,
              ageslb4(3) TYPE n DEFAULT  90,  "60,
              ageslb5(3) TYPE n DEFAULT  120, "90,
              ageslb6(3) TYPE n DEFAULT 180,
              ageslb7(4) TYPE n DEFAULT 1095,
              ageslb8(4) TYPE n DEFAULT 1120,   "++ changes by hemang on 23/02/2026
              ageslb9(4) TYPE n DEFAULT 1150,   "++ changes by hemang on 23/02/2026
              ageslb10(4) TYPE n DEFAULT 1180.  "++ changes by hemang on 23/02/2026
SELECTION-SCREEN END OF LINE.
SELECTION-SCREEN END OF BLOCK blk2.

SELECTION-SCREEN BEGIN OF BLOCK blk3 WITH FRAME TITLE text-003.
PARAMETERS: p_chk AS CHECKBOX,
            p_chk1 AS CHECKBOX,
            p_chk2 AS CHECKBOX,
            p_sql AS CHECKBOX.
SELECTION-SCREEN END OF BLOCK blk3.


*SELECTION-SCREEN BEGIN OF BLOCK blk4 WITH FRAME TITLE text-004.
*PARAMETERS: p_sql AS CHECKBOX.
*SELECTION-SCREEN END OF BLOCK blk4.

INITIALIZATION.

SELECT   sign
           opti
           low
           high INTO TABLE it_user
                 FROM tvarvc
                 WHERE name = a_name.

AT SELECTION-SCREEN.
  IF ( p_chk = 'X' AND p_chk1 = 'X' AND p_chk2 = 'X' ) OR
     ( p_chk = 'X' AND p_chk1 = 'X' AND p_chk2 = '' ) OR
     ( p_chk = 'X' AND p_chk2 = 'X' AND p_chk1 = '' ) OR
     ( p_chk1 = 'X' AND p_chk2 = 'X' AND p_chk = '' ).

    MESSAGE 'Select only 1 checkbox at a time' TYPE 'E'.

  ENDIF.



  AT SELECTION-SCREEN OUTPUT.

     LOOP AT SCREEN.

       IF screen-name = 'P_SQL'.
      READ TABLE it_user INTO wa_user WITH KEY low = sy-uname.
      IF sy-subrc = 0.
        screen-invisible = 0.
      ELSE.
        screen-invisible = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDIF.

    ENDLoop.
