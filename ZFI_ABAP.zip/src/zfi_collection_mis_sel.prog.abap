*&---------------------------------------------------------------------*
*&  Include           ZFI_COLLECTION_MIS_SEL
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-000.
  SELECT-OPTIONS : s_vkorg FOR knvv-vkorg,
                   s_bukrs FOR bsid-bukrs OBLIGATORY,
                   s_kunnr FOR knvv-kunnr,
                   s_vkbur FOR knvv-vkbur,
*                 s_kdgrp FOR knvv-kdgrp.
                  s_kvgr1 FOR knvv-kvgr1,
                  s_kvgr2 FOR knvv-kvgr2.

*SELECTION-SCREEN BEGIN OF LINE.
  PARAMETERS : p_rd1 RADIOBUTTON GROUP rd2 DEFAULT 'X',
               p_rd2 RADIOBUTTON GROUP rd2.
*SELECTION-SCREEN END OF LINE.
  SELECT-OPTIONS : s_budat FOR bsid-budat MODIF ID rrr.
  PARAMETERS : p_rb4 RADIOBUTTON GROUP rg1,
               p_rb5 RADIOBUTTON GROUP rg1,
               p_rb1 RADIOBUTTON GROUP rg1,
               p_rb3 RADIOBUTTON GROUP rg1,
               p_rb2 RADIOBUTTON GROUP rg1.
  PARAMETERS : p_bgchk AS CHECKBOX.
SELECTION-SCREEN END OF BLOCK b1.




AT SELECTION-SCREEN OUTPUT.
  CLEAR : p_rb1,p_rb2,p_rb3,p_rb4,p_rb5.

  LOOP AT SCREEN.
    IF p_rd1 = 'X'.
      IF screen-name = 'P_RB1' OR screen-name = 'P_RB2' OR screen-name = 'P_RB3'.
        screen-invisible = 1.
        screen-active = 0.
        MODIFY SCREEN.
      ENDIF.
    ELSEIF p_rd2 = 'X'.
      IF screen-name = 'P_RB4' OR screen-name = 'P_RB5' OR screen-group1 = 'RRR'.
        screen-invisible = 1.
        screen-active = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDIF.
  ENDLOOP.

  SELECT name,
         low
    FROM tvarvc
    INTO TABLE @DATA(lt_user)
    WHERE name = 'ZFI_MIS_USER'
  AND type = 'S'.
  DATA(ls_user) = VALUE #( lt_user[ low = sy-uname ] OPTIONAL ).
  IF ls_user IS INITIAL.
    LOOP AT SCREEN.
      IF screen-name = 'P_BGCHK'.
        screen-invisible = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.

AT SELECTION-SCREEN ON s_budat.
  IF p_rd1 = 'X'.
    IF s_budat-low IS INITIAL.
      MESSAGE 'Please Enter Minimum Posting Date Value' TYPE 'S' DISPLAY LIKE 'E'.
*      MESSAGE 'Please Enter Minimum Posting Date Value' TYPE  'E'.
      RETURN.
    ENDIF.
    IF s_budat-high IS INITIAL.
      MESSAGE 'Please Enter Maximum Posting Date Value' TYPE 'S' DISPLAY LIKE 'E'.
*      MESSAGE 'Please Enter Maximum Posting Date Value' TYPE 'E'.
      RETURN.
    ENDIF.
**  ELSE.
**    CLEAR : s_budat[] , s_budat.
  ENDIF."p_rd1 = 'X'


AT SELECTION-SCREEN ON s_vkorg.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT DISTINCT vkorg
*        FROM tvko
*        INTO TABLE @DATA(lt_so)
*  WHERE vkorg IN @s_vkorg.

  SELECT DISTINCT vkorg
   FROM tvko
   INTO TABLE @DATA(lt_so)
   WHERE vkorg IN @s_vkorg
   ORDER BY PRIMARY KEY .
* End of Quick Fix

  LOOP AT lt_so INTO DATA(ls_so).
    AUTHORITY-CHECK OBJECT 'Z_MIS_SO' ID 'VKORG' FIELD ls_so-vkorg
                                       ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'Not Authorized for Sales Org :' && ls_so-vkorg TYPE 'E'." DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.
  ENDLOOP.

*AT SELECTION-SCREEN ON HELP-REQUEST FOR s_kdgrp.
AT SELECTION-SCREEN ON HELP-REQUEST FOR s_kvgr1.
  SELECT kvgr1,
         txt
    FROM zfi_mis_kdgrp
    INTO TABLE @lt_kdgrp.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield  = 'KVGR1'
*     dynprofield = 'S_BZIRK'
      dynpprog  = sy-cprog
      dynpnr    = sy-dynnr
      value_org = 'S'
    TABLES
      value_tab = lt_kdgrp[].


AT SELECTION-SCREEN ON HELP-REQUEST FOR s_kvgr2.
  SELECT kvgr2,
         txt
    FROM zfi_mis_kdgrp
    INTO TABLE @lt_kdgrp.
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield  = 'KVGR2'
*     dynprofield = 'S_BZIRK'
      dynpprog  = sy-cprog
      dynpnr    = sy-dynnr
      value_org = 'S'
    TABLES
      value_tab = lt_kdgrp[].

*  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
*    EXPORTING
*      retfield  = 'KDGRP'
**     dynprofield = 'S_BZIRK'
*      dynpprog  = sy-cprog
*      dynpnr    = sy-dynnr
*      value_org = 'S'
*    TABLES
*      value_tab = lt_kdgrp[].
