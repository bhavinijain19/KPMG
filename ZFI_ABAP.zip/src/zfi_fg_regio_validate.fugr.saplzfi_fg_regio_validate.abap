*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_FG_REGIO_VALIDATETOP.         " Global Declarations
  INCLUDE LZFI_FG_REGIO_VALIDATEUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_FG_REGIO_VALIDATEF...         " Subroutines
* INCLUDE LZFI_FG_REGIO_VALIDATEO...         " PBO-Modules
* INCLUDE LZFI_FG_REGIO_VALIDATEI...         " PAI-Modules
* INCLUDE LZFI_FG_REGIO_VALIDATEE...         " Events
* INCLUDE LZFI_FG_REGIO_VALIDATEP...         " Local class implement.
* INCLUDE LZFI_FG_REGIO_VALIDATET99.         " ABAP Unit tests
