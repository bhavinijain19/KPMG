*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_ODN_NRGRP...................................*
DATA:  BEGIN OF STATUS_ZFI_ODN_NRGRP                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_ODN_NRGRP                 .
CONTROLS: TCTRL_ZFI_ODN_NRGRP
            TYPE TABLEVIEW USING SCREEN '1011'.
*.........table declarations:.................................*
TABLES: *ZFI_ODN_NRGRP                 .
TABLES: ZFI_ODN_NRGRP                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
