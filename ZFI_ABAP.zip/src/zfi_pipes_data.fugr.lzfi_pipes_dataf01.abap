*----------------------------------------------------------------------*
***INCLUDE LZFI_PIPES_DATAF01.
*----------------------------------------------------------------------*
FORM create_data.
  zfi_pipes_data-created_by = sy-uname.
  zfi_pipes_data-created_date = sy-datum.
  zfi_pipes_data-created_time = sy-uzeit.
ENDFORM.
