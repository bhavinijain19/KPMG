FUNCTION-POOL ZFI_PDC_GL                 MESSAGE-ID SV.

* INCLUDE LZFI_PDC_GLD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PDC_GLT00                          . "view rel. data dcl.
