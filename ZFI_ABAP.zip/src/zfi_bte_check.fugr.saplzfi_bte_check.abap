*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_BTE_CHECKTOP.                 " Global Declarations
  INCLUDE LZFI_BTE_CHECKUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_BTE_CHECKF...                 " Subroutines
* INCLUDE LZFI_BTE_CHECKO...                 " PBO-Modules
* INCLUDE LZFI_BTE_CHECKI...                 " PAI-Modules
* INCLUDE LZFI_BTE_CHECKE...                 " Events
* INCLUDE LZFI_BTE_CHECKP...                 " Local class implement.
* INCLUDE LZFI_BTE_CHECKT99.                 " ABAP Unit tests
