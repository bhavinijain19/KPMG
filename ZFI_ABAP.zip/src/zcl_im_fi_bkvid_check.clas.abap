class ZCL_IM_FI_BKVID_CHECK definition
  public
  final
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_FI_BKVID_CHECK IMPLEMENTATION.
ENDCLASS.
