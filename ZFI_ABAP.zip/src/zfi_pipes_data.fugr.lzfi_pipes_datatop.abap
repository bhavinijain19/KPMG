FUNCTION-POOL ZFI_PIPES_DATA             MESSAGE-ID SV.

* INCLUDE LZFI_PIPES_DATAD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PIPES_DATAT00                      . "view rel. data dcl.
