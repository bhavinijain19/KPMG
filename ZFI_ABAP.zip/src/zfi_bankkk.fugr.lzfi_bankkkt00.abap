*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_BANK........................................*
DATA:  BEGIN OF STATUS_ZFI_BANK                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_BANK                      .
CONTROLS: TCTRL_ZFI_BANK
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_BANK                      .
TABLES: ZFI_BANK                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
