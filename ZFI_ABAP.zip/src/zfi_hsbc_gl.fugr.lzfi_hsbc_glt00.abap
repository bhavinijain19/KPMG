*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_HSBC_GL.....................................*
DATA:  BEGIN OF STATUS_ZFI_HSBC_GL                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_HSBC_GL                   .
CONTROLS: TCTRL_ZFI_HSBC_GL
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_HSBC_GL                   .
TABLES: ZFI_HSBC_GL                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
