FUNCTION-POOL ZFI_PDC_PENALTY            MESSAGE-ID SV.

* INCLUDE LZFI_PDC_PENALTYD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PDC_PENALTYT00                     . "view rel. data dcl.
