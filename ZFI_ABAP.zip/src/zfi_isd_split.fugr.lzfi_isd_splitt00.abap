*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_ISD_SPLIT...................................*
DATA:  BEGIN OF STATUS_ZFI_ISD_SPLIT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_ISD_SPLIT                 .
CONTROLS: TCTRL_ZFI_ISD_SPLIT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFI_ISD_SPLIT                 .
TABLES: ZFI_ISD_SPLIT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
