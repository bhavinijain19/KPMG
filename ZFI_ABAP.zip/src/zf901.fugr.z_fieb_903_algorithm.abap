FUNCTION z_fieb_903_algorithm.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_NOTE_TO_PAYEE) TYPE  STRING OPTIONAL
*"     REFERENCE(I_COUNTRY) TYPE  LAND1 OPTIONAL
*"  TABLES
*"      T_AVIP_IN STRUCTURE  AVIP OPTIONAL
*"      T_AVIP_OUT STRUCTURE  AVIP
*"      T_FILTER1 OPTIONAL
*"      T_FILTER2 OPTIONAL
*"--------------------------------------------------------------------

  DATA: BEGIN OF kidno_tab OCCURS 10,
          nummer LIKE febep-kidno,
        END OF kidno_tab,
        s_bsis TYPE STANDARD TABLE OF bsis,
        h_bsis TYPE bsis.

  LOOP AT t_avip_in WHERE sfeld = 'KIDNO'.
    kidno_tab-nummer = t_avip_in-swert.
    APPEND kidno_tab.
  ENDLOOP.
  REFRESH t_avip_out.

  LOOP AT t_avip_in WHERE bukrs IS NOT INITIAL.
    DATA(lv_bukrs) = t_avip_in-bukrs.
    IF lv_bukrs IS NOT INITIAL.
      EXIT.
    ENDIF.
  ENDLOOP.


  LOOP AT kidno_tab.
***Selecting the table based on XREF1

***Selecting the table based on Check
    SELECT * FROM bsis INTO TABLE s_bsis WHERE kidno = kidno_tab-nummer AND bschl = '40' AND hkont LIKE '%%%%%%%%%1'
*End of change
    AND xopvw = 'X'.

    IF sy-subrc = 0.
      LOOP AT s_bsis INTO h_bsis.
        t_avip_out-koart = 'S'.
        t_avip_out-konto = h_bsis-hkont.
        t_avip_out-sfeld = 'BELNR'.
        t_avip_out-swert = h_bsis-belnr.
        t_avip_out-swert+10(4) = h_bsis-gjahr.
        APPEND t_avip_out.
      ENDLOOP.
    ELSE.
      TRANSLATE kidno_tab-nummer TO LOWER CASE.
      SELECT * FROM bsis INTO TABLE s_bsis
        WHERE kidno = kidno_tab-nummer AND bschl = '40' AND hkont LIKE '%%%%%%%%%1'
        AND xopvw = 'X'.
      IF sy-subrc = 0.
        LOOP AT s_bsis INTO h_bsis.
          t_avip_out-koart = 'S'.
          t_avip_out-konto = h_bsis-hkont.
          t_avip_out-sfeld = 'BELNR'.
          t_avip_out-swert = h_bsis-belnr.
          t_avip_out-swert+10(4) = h_bsis-gjahr.
          APPEND t_avip_out.
        ENDLOOP.
      ELSE.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF t_avip_out IS INITIAL.
    t_avip_out-swert = kidno_tab-nummer.
    t_avip_out-sfeld  = 'KIDNO'.
    t_avip_out-koart = 'S'.
    APPEND t_avip_out.
  ENDIF.
  """"added by vd
ENDFUNCTION.
