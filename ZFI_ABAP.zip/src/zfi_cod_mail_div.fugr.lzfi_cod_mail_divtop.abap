FUNCTION-POOL ZFI_COD_MAIL_DIV           MESSAGE-ID SV.

* INCLUDE LZFI_COD_MAIL_DIVD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_COD_MAIL_DIVT00                    . "view rel. data dcl.
