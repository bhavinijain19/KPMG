*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_OD_SMS_GP_CS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_OD_SMS_GP_CS    .

  PERFORM TABLEPROC.

ENDFUNCTION.
