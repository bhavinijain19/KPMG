class ZCL_IM_MRM_PAYMENT_TERMS definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MRM_PAYMENT_TERMS .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MRM_PAYMENT_TERMS IMPLEMENTATION.


  method IF_EX_MRM_PAYMENT_TERMS~PAYMENT_TERMS_SET.

  e_zfbdt = i_rbkpv-zfbdt.
  e_zbd1t = i_rbkpv-zbd1t.
  e_zbd1p = i_rbkpv-zbd1p.
  e_zbd2t = i_rbkpv-zbd2t.
  e_zbd2p = i_rbkpv-zbd2p.
  e_zbd3t = i_rbkpv-zbd3t.
  e_zlspr = i_rbkpv-zlspr.


  DATA: gc_miro  TYPE sy-tcode VALUE 'MIRO',
        gc_mir7  TYPE sy-tcode VALUE 'MIR7',
        gc_mir4  TYPE sy-tcode VALUE 'MIR4',
        gc_vgabe TYPE vgabe VALUE '1'.
  DATA: ls_msg        TYPE bapiret2,
        lv_errflag(1).
  DATA : em_budat TYPE rbkp-budat.
  DATA : e_budat TYPE ekbe-budat.


  DATA: it_zmsg_val TYPE STANDARD TABLE OF zmsg_val,
        wa_zmsg_val LIKE LINE OF it_zmsg_val.
  DATA: lv_msgclass TYPE zmsg_val-msgclass.

  CHECK sy-tcode EQ gc_miro OR sy-tcode EQ gc_mir7 .
*-----------------------------------------------------------------------
*** Setting ZFBDT depending on goods receive
*-----------------------------------------------------------------------

  TYPES: BEGIN OF ty_ekbe,
           ebeln TYPE ebeln,
           ebelp TYPE ebelp,
           budat TYPE budat,
           lfgja TYPE lfgja,
           lfbnr TYPE lfbnr,
           lfpos TYPE lfpos,
         END OF ty_ekbe.
  DATA: gt_ekbe TYPE STANDARD TABLE OF ty_ekbe,
        wa_ekbe TYPE ty_ekbe.
  DATA : e_webud TYPE ekbe-budat. " Added by Carina Jose on 24.03.2021
  DATA : wa_ti_drseg TYPE mmcr_drseg. " Added by Carina Jose on 24.03.2021

  DATA: v_bwtar TYPE ekpo-bwtar.

  TYPES: BEGIN OF ty_ekko,
           ebeln TYPE ekko-ebeln,
           ekorg TYPE ekko-ekorg,
         END OF ty_ekko.
  DATA: it_ekko TYPE STANDARD TABLE OF ty_ekko,
        wa_ekko TYPE ty_ekko.


* select ebeln ekorg from ekko INTO TABLE it_ekko
*   for ALL ENTRIES IN ti_drseg
*   where ebeln = ti_drseg-ebeln.


* READ TABLE it_ekko into wa_ekko INDEX 1.

  READ TABLE ti_drseg INTO wa_ti_drseg INDEX 1.

  IF wa_ti_drseg-lfbnr IS NOT INITIAL.

*  if wa_ekko-ekorg <> '1001'.


*    IF ti_drseg IS NOT INITIAL.
*ALTITBO00257 EKBKE QUERY OPTIMIZATION CHANGES BY RAHUL VASITA ( VC-ERP) ON 29-03-2024.
      SELECT ebeln
             ebelp
             budat
             lfgja
             lfbnr
             lfpos
        FROM ekbe
          INTO TABLE gt_ekbe
            FOR ALL ENTRIES IN ti_drseg
              WHERE ebeln = ti_drseg-ebeln
                AND ebelp = ti_drseg-ebelp
                AND vgabe = gc_vgabe
                AND lfgja = ti_drseg-lfgja
                AND lfbnr = ti_drseg-lfbnr
                AND lfpos = ti_drseg-lfpos.

      IF sy-subrc EQ 0.
        SORT gt_ekbe BY budat DESCENDING.
        READ TABLE gt_ekbe INTO wa_ekbe INDEX 1.
        IF sy-subrc EQ 0.
          e_budat = wa_ekbe-budat.
        ENDIF.
*****    Added by Carina Jose on 24.03.2021
*    READ TABLE ti_drseg  INTO wa_ti_drseg WITH KEY ebeln = wa_ekbe-ebeln
*                                                   ebelp = wa_ekbe-ebelp
*                                                   lfbnr = wa_ekbe-lfbnr
*                                                   lfgja = wa_ekbe-lfgja
*                                                   lfpos = wa_ekbe-lfpos.
*    IF sy-subrc = '0'.
*      e_webud = wa_ti_drseg-webud.
*    ENDIF.
*****    End of changes by Carina Jose on 24.03.2021
      ENDIF.

      em_budat = i_rbkpv-budat.

    ENDIF.

********* select msg typoe from ZMSG_VAL @ 21 oct

    CLEAR lv_msgclass.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE  msgclass FROM zmsg_val INTO lv_msgclass WHERE tcode = 'MIRO' OR tcode = 'MIR7' OR tcode = 'MIR4'.
    SELECT  msgclass FROM zmsg_val INTO lv_msgclass UP TO 1 ROWS WHERE tcode = 'MIRO' OR tcode = 'MIR7' OR tcode = 'MIR4' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

    IF sy-subrc = 0.

      IF lv_msgclass = 'E'.
**********above code @ 21 oct *******************************

        IF e_budat GT em_budat.
          MESSAGE text-001 TYPE 'E'.
*  MESSAGE 'MIRO POSTING DATE SHOULD BE EQUAL TO OR GREATER THAN MIGO POSTING DATE' TYPE 'E'.
        ENDIF.
       endif.

*****    Added by Carina Jose on 24.03.2021
*    IF em_budat NE e_zfbdt.
*        MESSAGE text-002 TYPE 'W' DISPLAY LIKE 'E'.
*      ENDIF.
*****    End of changes by Carina Jose on 24.03.2021

        IF lv_msgclass = 'W'.
**********above code @ 21 oct *******************************

          IF e_budat GT em_budat.
            MESSAGE text-001 TYPE 'I'.
*  MESSAGE 'MIRO POSTING DATE SHOULD BE EQUAL TO OR GREATER THAN MIGO POSTING DATE' TYPE 'E'.
          ENDIF.

        ENDIF.
      ENDIF.
*    ENDIF.
*  ENDIF.
  """""""""

  DATA: gt_errtab TYPE TABLE OF mrm_errprot,
        gs_errtab TYPE mrm_errprot.
  CONSTANTS:     c_errprot(23)   TYPE c VALUE '(SAPLMRMF)TAB_ERRPROT[]'.

  FIELD-SYMBOLS: <fs_errprot> TYPE table.
  ASSIGN (c_errprot) TO <fs_errprot>.

  REFRESH gt_errtab[].
  gt_errtab[] = <fs_errprot>[].

* First clear the message because the user might have corrected
* the situation that causes the error
  LOOP AT gt_errtab INTO gs_errtab
  WHERE msgty = 'E'
  AND msgid = 'ZSD'
  AND msgno = '015'.
    DELETE gt_errtab INDEX sy-tabix.
  ENDLOOP.

  <fs_errprot>[] = gt_errtab[].

* if the condition is not met, trigger the message
*    IF em_budat NE e_zfbdt.
*      gs_errtab-msgty = 'E'.
*      gs_errtab-msgid = 'ZSD'.
*      gs_errtab-msgno = '015'.
*      gs_errtab-source = 'EC'.
*      APPEND gs_errtab TO gt_errtab.
*
*      CALL FUNCTION 'MRM_PROT_FILL'
*        TABLES
*          t_errprot = gt_errtab.
*    ENDIF.
  endmethod.
ENDCLASS.
