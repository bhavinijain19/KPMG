*&---------------------------------------------------------------------*
*& Include          ZFI_BDC_FV60_TOP
*&---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* Types – columns map 1:1 with Excel header row
*---------------------------------------------------------------------*
TYPES: BEGIN OF ty_itab,
         doc_no       TYPE char25,
         bukrs        TYPE char4,   " INVFO-BUKRS (Company Code)
         accnt        TYPE char10,  " INVFO-ACCNT  (Vendor)
         bldat        TYPE char10,  " INVFO-BLDAT  (Doc Date, DD.MM.YYYY)
         budat        TYPE char10,  " INVFO-BUDAT  (Posting Date)
         blart        TYPE char2,   " INVFO-BLART  (e.g. KR)
         xblnr        TYPE char16,  " INVFO-XBLNR  (Reference)
         waers        TYPE char5,   " INVFO-WAERS  (INR, etc.)
         wrbtr_h      TYPE char20,  " INVFO-WRBTR  (Header Amount)
         xmwst        TYPE char1,   " INVFO-XMWST  ('X' to calc tax)
         mwskz        TYPE char2,   " INVFO-MWSKZ  (Tax Code)

         bupla        TYPE char10,  " INVFO-BUPLA  (Business Place)
         secco        TYPE char10,  " INVFO-SECCO  (Section Code)
         sgtxt_h      TYPE char50,  " INVFO-SGTXT  (Header Text)
         gst_part     TYPE char20,  " INVFO-GST_PART
         plc_sup      TYPE char5,   " INVFO-PLC_SUP

         zname        TYPE char50,  " WA_VEND-ZNAME   (optional subscreen)
         zgst         TYPE char20,  " WA_VEND-ZGST
         zinv         TYPE char20,  " WA_VEND-ZINV
         zdate        TYPE char10,  " WA_VEND-ZDATE

         hkont_01     TYPE char10,  " ACGL_ITEM-HKONT(01)
         wrbtr_01     TYPE char20,  " ACGL_ITEM-WRBTR(01) / BSEG-WRBTR
         zuonr_01     TYPE char18,  " ACGL_ITEM-ZUONR(01) / BSEG-ZUONR
         sgtxt_01     TYPE char50,  " ACGL_ITEM-SGTXT(01) / BSEG-SGTXT
         gsber_01     TYPE char10,  " ACGL_ITEM-GSBER(01) / COBL-GSBER
         kostl_01     TYPE char12,  " ACGL_ITEM-KOSTL(01) / COBL-KOSTL
         aufnr_01     TYPE char12,  " ACGL_ITEM-AUFNR(01)
         hsn_sac_01   TYPE char10,  " ACGL_ITEM-HSN_SAC(01)
         mwskz_item   TYPE char2,

         wt_withcd_01 TYPE char2,   " ACWT_ITEM-WT_WITHCD(01)
         wt_qsshb_01  TYPE char20,  " ACWT_ITEM-WT_QSSHB(01)
       END OF ty_itab.

DATA: itab TYPE STANDARD TABLE OF ty_itab WITH EMPTY KEY.

DATA: bdcdata LIKE bdcdata    OCCURS 0 WITH HEADER LINE,
      messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

DATA: filename TYPE string.
DATA: p_tcode  TYPE tcode VALUE 'FV60'.
"data: lv_hdr_amt type  wrbtr .
DATA: lv_hdr_amt1 TYPE  wrbtr .
TYPES: ty_amount TYPE p LENGTH 16 DECIMALS 2.
