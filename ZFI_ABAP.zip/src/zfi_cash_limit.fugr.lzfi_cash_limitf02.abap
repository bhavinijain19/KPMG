*----------------------------------------------------------------------*
***INCLUDE LZFI_CASH_LIMITF02.
*----------------------------------------------------------------------*
FORM create.
** -- Data Declarations
  DATA: lv_timestamp TYPE tzonref-tstamps.
*-- Time stamp conversion
  CALL FUNCTION 'ABI_TIMESTAMP_CONVERT_INTO'
    EXPORTING
      iv_date          = sy-datum
      iv_time          = sy-uzeit
    IMPORTING
      ev_timestamp     = lv_timestamp
    EXCEPTIONS
      conversion_error = 1
      OTHERS           = 2.
** -- Created On & Created By
  zfi_cash_limit-crtd_by = sy-uname.
  zfi_cash_limit-crtd_dt = sy-datum.
  zfi_cash_limit-crtd_time = sy-uzeit.
ENDFORM.
