*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_LOGIC_DAYSTOP.                " Global Declarations
  INCLUDE LZFI_LOGIC_DAYSUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_LOGIC_DAYSF...                " Subroutines
* INCLUDE LZFI_LOGIC_DAYSO...                " PBO-Modules
* INCLUDE LZFI_LOGIC_DAYSI...                " PAI-Modules
* INCLUDE LZFI_LOGIC_DAYSE...                " Events
* INCLUDE LZFI_LOGIC_DAYSP...                " Local class implement.
* INCLUDE LZFI_LOGIC_DAYST99.                " ABAP Unit tests
  INCLUDE LZFI_LOGIC_DAYSF00                      . " subprograms
  INCLUDE LZFI_LOGIC_DAYSI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
