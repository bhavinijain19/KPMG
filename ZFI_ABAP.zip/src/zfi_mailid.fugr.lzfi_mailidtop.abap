FUNCTION-POOL ZFI_MAILID                 MESSAGE-ID SV.

* INCLUDE LZFI_MAILIDD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_MAILIDT00                          . "view rel. data dcl.
