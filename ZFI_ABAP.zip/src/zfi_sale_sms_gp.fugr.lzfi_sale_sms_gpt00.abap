*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_SALE_SMS_GP.................................*
DATA:  BEGIN OF STATUS_ZFI_SALE_SMS_GP               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_SALE_SMS_GP               .
CONTROLS: TCTRL_ZFI_SALE_SMS_GP
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_SALE_SMS_GP               .
TABLES: ZFI_SALE_SMS_GP                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
