process before output.
*&SPWIZARD: PBO FLOW LOGIC FOR TABLECONTROL 'T_TABL_CTRL'
  module t_tabl_ctrl_change_tc_attr.
*&SPWIZARD: MODULE T_TABL_CTRL_CHANGE_COL_ATTR.
  loop at   gt_table
       into wa_table
       with control t_tabl_ctrl
       cursor t_tabl_ctrl-current_line.
    module t_tabl_ctrl_get_lines.
*&SPWIZARD:   MODULE T_TABL_CTRL_CHANGE_FIELD_ATTR
  endloop.

* MODULE STATUS_8002.
*
process after input.
*&SPWIZARD: PAI FLOW LOGIC FOR TABLECONTROL 'T_TABL_CTRL'
  loop at gt_table.
    chain.
*      field wa_table-bukrs.
*      field wa_table-vgman.
      field wa_table-hkont.
      field wa_table-belnr.
*      field wa_table-blart.
      field wa_table-bldat.
      field wa_table-budat.
*      field wa_table-valut.
      field wa_table-dmbtr.
      field wa_table-cldat.
      field wa_table-zuonr.
      field wa_table-name.
      module insert on chain-request.
      module t_tabl_ctrl_modify on chain-request.
    endchain.
    field wa_table-mark
      module t_tabl_ctrl_mark on request.
  endloop.
  module t_tabl_ctrl_user_command.
*&SPWIZARD: MODULE T_TABL_CTRL_CHANGE_TC_ATTR.
*&SPWIZARD: MODULE T_TABL_CTRL_CHANGE_COL_ATTR.

* MODULE USER_COMMAND_8002.
