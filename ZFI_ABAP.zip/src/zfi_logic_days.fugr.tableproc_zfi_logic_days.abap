*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_LOGIC_DAYS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_LOGIC_DAYS      .

  PERFORM TABLEPROC.

ENDFUNCTION.
