*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_COSTTOP.                      " Global Data
  INCLUDE LZFI_COSTUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_COSTF...                      " Subroutines
* INCLUDE LZFI_COSTO...                      " PBO-Modules
* INCLUDE LZFI_COSTI...                      " PAI-Modules
* INCLUDE LZFI_COSTE...                      " Events
* INCLUDE LZFI_COSTP...                      " Local class implement.
* INCLUDE LZFI_COSTT99.                      " ABAP Unit tests
  INCLUDE LZFI_COSTF00                            . " subprograms
  INCLUDE LZFI_COSTI00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
