*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_EXP_EXTRA...................................*
DATA:  BEGIN OF STATUS_ZFI_EXP_EXTRA                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_EXP_EXTRA                 .
CONTROLS: TCTRL_ZFI_EXP_EXTRA
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_EXP_EXTRA                 .
TABLES: ZFI_EXP_EXTRA                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
