*&---------------------------------------------------------------------*
*& Include          ZFI_CRDB_REG_OB_MAIN
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form fetch_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM fetch_data.
  IF p_mins IS NOT INITIAL.
    GET TIME STAMP FIELD lv_tstmp.
    cl_abap_tstmp=>subtractsecs( EXPORTING tstmp = lv_tstmp secs = CONV #( p_mins * 60 ) RECEIVING r_tstmp = lv_tstmp ).
    CONVERT TIME STAMP lv_tstmp TIME ZONE sy-zonlo INTO DATE lv_date TIME lv_time.
  ELSE.
    CLEAR lv_tstmp.
  ENDIF.
  IF p_date <> 'X'.
    IF v_cr = 'X'.
      SELECT belnr budat bukrs gjahr blart bldat xblnr tcode ppnam FROM bkpf
        INTO TABLE it_bkpf WHERE belnr IN s_belnr AND cpudt IN s_budat AND blart IN ('DR','DG')
        AND bukrs IN s_bukrs AND gjahr IN s_gjahr
        AND last_change_datetime >= lv_tstmp.
    ELSEIF v_dr = 'X'.
      SELECT belnr budat bukrs gjahr blart bldat xblnr tcode ppnam FROM bkpf
        INTO TABLE it_bkpf WHERE belnr IN s_belnr AND cpudt IN s_budat AND blart IN ('KR','KG')
        AND bukrs IN s_bukrs AND gjahr IN s_gjahr
        AND last_change_datetime >= lv_tstmp.
    ENDIF.
  ELSE.
    IF v_cr = 'X'.
      SELECT belnr budat bukrs gjahr blart bldat xblnr tcode ppnam FROM bkpf
        INTO TABLE it_bkpf WHERE belnr IN s_belnr AND budat IN s_budat AND blart IN ('DR','DG')
        AND bukrs IN s_bukrs AND gjahr IN s_gjahr.
    ELSEIF v_dr = 'X'.
      SELECT belnr budat bukrs gjahr blart bldat xblnr tcode ppnam FROM bkpf
        INTO TABLE it_bkpf WHERE belnr IN s_belnr AND budat IN s_budat AND blart IN ('KR','KG')
        AND bukrs IN s_bukrs AND gjahr IN s_gjahr.
    ENDIF.
  ENDIF.


  IF NOT it_bkpf IS INITIAL.
    SELECT bukrs kunnr gjahr belnr FROM bsid INTO CORRESPONDING FIELDS OF TABLE it_bsid
      FOR ALL ENTRIES IN it_bkpf WHERE belnr = it_bkpf-belnr AND gjahr = it_bkpf-gjahr.
    SELECT  accountingdocument AS belnr FROM i_operationalacctgdocitem
   INTO TABLE  @it_cuslif  FOR  ALL  ENTRIES  IN  @it_bkpf  WHERE
   accountingdocument = @it_bkpf-belnr AND customer IN @s_kunnr AND
   supplier IN @s_lifnr AND companycode IN @s_bukrs AND fiscalyear IN @s_gjahr.
    SORT it_cuslif BY belnr.
    DELETE ADJACENT DUPLICATES FROM it_cuslif.
  ENDIF.

  IF NOT it_cuslif IS INITIAL.

    SELECT  accountingdocument AS belnr , accountingdocumentitem AS buzei ,
        unadjusteddebitcreditcode AS shkzg , absoluteamountincocodecrcy AS
       dmbtr , balancetransactioncurrency AS pswsl , documentitemtext AS sgtxt
       , glaccount AS hkont , customer AS kunnr , supplier AS lifnr ,
       profitcenter AS prctr , costcenter AS kostl , taxcode AS mwskz ,
       withholdingtaxcode AS qsskz , plant AS werks FROM
       i_operationalacctgdocitem INTO TABLE  @it_bseg  FOR  ALL  ENTRIES  IN
       @it_cuslif  WHERE accountingdocument = @it_cuslif-belnr AND companycode
       IN @s_bukrs AND fiscalyear IN @s_gjahr.
    SORT it_bseg BY belnr buzei.

  ENDIF.

  IF it_bseg IS NOT INITIAL.
    SELECT a~kunnr, a~name1, b~vkorg
      FROM kna1 AS a
      INNER JOIN knvv AS b ON a~kunnr = b~kunnr
      INTO TABLE @it_kna1
      FOR ALL ENTRIES IN @it_bseg
      WHERE a~kunnr = @it_bseg-kunnr
        AND b~vkorg IN @s_vkorg.
  ENDIF.

  DATA: lr_kunnr TYPE RANGE OF kunnr.

  lr_kunnr = VALUE #( FOR wa IN it_kna1 ( sign = 'I' option = 'EQ' low = wa-kunnr ) ).

  " 2. Delete non-matching entries from both tables
  IF lr_kunnr IS NOT INITIAL.
    DELETE it_bseg WHERE kunnr NOT IN lr_kunnr.
  ENDIF.

  SELECT saknr txt50 FROM skat INTO TABLE it_skat FOR ALL ENTRIES IN it_bseg WHERE saknr = it_bseg-hkont AND spras = 'EN' AND ktopl = 'ASTL'.

  LOOP AT it_bseg INTO wa_bseg.
    READ TABLE it_bkpf INTO wa_bkpf WITH KEY belnr = wa_bseg-belnr.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.
    wa_final-belnr = wa_bseg-belnr.
    wa_final-budat = wa_bkpf-budat.
    wa_final-blart = wa_bkpf-blart.
    wa_final-hkont = wa_bseg-hkont.
    wa_final-bldat = wa_bkpf-bldat.
    wa_final-xblnr = wa_bkpf-xblnr.
    wa_final-kunnr = wa_bseg-kunnr.
    wa_final-lifnr = wa_bseg-lifnr.
    wa_final-buzei = wa_bseg-buzei.
    wa_final-werks = wa_bseg-werks.
    CONCATENATE wa_bseg-belnr wa_bseg-buzei wa_bkpf-budat INTO wa_final-primaryid.

    IF NOT wa_bseg-lifnr IS INITIAL.
      SELECT SINGLE name1 FROM lfa1 INTO wa_final-name WHERE lifnr = wa_bseg-lifnr.
    ELSEIF NOT wa_bseg-kunnr IS INITIAL.
      SELECT SINGLE name1 FROM kna1 INTO wa_final-name WHERE kunnr = wa_bseg-kunnr.
    ELSE.
      READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bseg-hkont.
      wa_final-name = wa_skat-txt50.
    ENDIF.
    READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_final-kunnr.
    IF sy-subrc = 0.
      wa_final-name1  =  wa_kna1-name1.
      wa_final-vkorg  =  wa_kna1-vkorg.
    ENDIF.
    CONDENSE wa_final-name.
    IF wa_bseg-shkzg = 'S'.
      wa_final-debit = wa_bseg-dmbtr.
    ELSEIF wa_bseg-shkzg = 'H'.
      wa_final-credit = wa_bseg-dmbtr.
    ENDIF.
    wa_final-pswsl = wa_bseg-pswsl.
    wa_final-sgtxt = wa_bseg-sgtxt.
    CONDENSE wa_final-sgtxt.
    wa_final-bukrs = wa_bkpf-bukrs.
    wa_final-gjahr = wa_bkpf-gjahr.
    wa_final-prctr = wa_bseg-prctr.
    wa_final-kostl = wa_bseg-kostl.
    wa_final-mwskz = wa_bseg-mwskz.
    wa_final-qsskz = wa_bseg-qsskz.
    AT END OF belnr.
      READ TABLE it_bkpf INTO wa_bkpf WITH KEY belnr = wa_bseg-belnr.
      wa_final-tcode = wa_bkpf-tcode.
      wa_final-ppnam = wa_bkpf-ppnam.
    ENDAT.

    IF wa_final-sgtxt IS INITIAL.
      DATA : lines TYPE STANDARD TABLE OF tline.
      DATA : wa_lines TYPE tline.
      DATA : v_belnr(70).
      CONCATENATE wa_bkpf-bukrs wa_bkpf-belnr wa_bkpf-gjahr wa_bseg-buzei INTO v_belnr.
      CONDENSE v_belnr.
      CALL FUNCTION 'READ_TEXT'
        EXPORTING
          client                  = sy-mandt
          id                      = '0001'
          language                = sy-langu
          name                    = v_belnr
          object                  = 'DOC_ITEM'
        TABLES
          lines                   = lines
        EXCEPTIONS
          id                      = 1
          language                = 2
          name                    = 3
          not_found               = 4
          object                  = 5
          reference_check         = 6
          wrong_access_to_archive = 7
          OTHERS                  = 8.
      IF sy-subrc EQ 0.
        LOOP AT lines INTO wa_lines.
          IF NOT wa_lines-tdline IS INITIAL.
            CONCATENATE wa_final-sgtxt '' wa_lines-tdline INTO wa_final-sgtxt SEPARATED BY space.
            CONDENSE wa_final-sgtxt.
            CLEAR wa_lines.
          ENDIF.
        ENDLOOP.
        REFRESH lines.
      ENDIF.
    ENDIF.

    APPEND wa_final TO it_final.
    CLEAR : wa_final,wa_skat,wa_bkpf,wa_bseg,v_belnr,wa_lines.
    REFRESH lines.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form call_cpi_utility
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM call_cpi_utility.

  DATA: lv_full_xml TYPE string,
        lv_endpoint TYPE string,
        ls_log      TYPE char3. " Table structure from Image

  IF it_final[] IS NOT INITIAL.
    IF v_cr IS NOT INITIAL.
      SELECT low FROM tvarvc   UP TO 1 ROWS INTO @DATA(lv_ep_suffix) WHERE
        name = 'ZFI_CR_EP' AND type = 'P'  ORDER BY PRIMARY KEY.
      ENDSELECT.

      IF sy-subrc = 0.
        lv_endpoint = lv_ep_suffix.
        zcl_http_util=>post_to_cpi(
        EXPORTING
          iv_json        = /ui2/cl_json=>serialize( it_final )
          iv_path_suffix = lv_endpoint
        IMPORTING
          ev_status      = DATA(lv_status)
          ev_response    = DATA(lv_resp) ).

        WRITE: / 'API Response processed. Status:', ls_log, lv_resp.
      ENDIF.

    ELSEIF  v_dr IS NOT INITIAL.

      SELECT low FROM tvarvc   UP TO 1 ROWS INTO lv_ep_suffix WHERE
        name = 'ZFI_DR_EP' AND type = 'P'  ORDER BY PRIMARY KEY.
      ENDSELECT.
      IF sy-subrc = 0.

        lv_endpoint = lv_ep_suffix.
        zcl_http_util=>post_to_cpi(
        EXPORTING
          iv_json        = /ui2/cl_json=>serialize( it_final )
          iv_path_suffix = lv_endpoint
        IMPORTING
          ev_status      = lv_status
          ev_response    = lv_resp ).

        WRITE: / 'API Response processed. Status:', ls_log, lv_resp.
      ENDIF.
    ENDIF.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form display
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM display.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-cprog
      i_callback_top_of_page = 'TOP_PAGE'
      is_layout              = VALUE slis_layout_alv( zebra = abap_true colwidth_optimize = abap_true )  " List layout specifications
      it_fieldcat            = VALUE slis_t_fieldcat_alv( tabname = 'IT_FINAL'
                                     ( fieldname = 'BELNR' seltext_l = 'Doc Number' )
                                     ( fieldname = 'BUDAT'     seltext_l = 'Posting Date' )
                                     ( fieldname = 'HKONT'     seltext_l = 'G/L Account' )
                                     ( fieldname = 'NAME'      seltext_l = 'Name' )
                                     ( fieldname = 'DEBIT'     seltext_l = 'Debit Amount' )
                                     ( fieldname = 'CREDIT'    seltext_l = 'Credit Amount' )
                                     ( fieldname = 'PSWSL'     seltext_l = 'General Ledger Currency' )
                                     ( fieldname = 'SGTXT'     seltext_l = 'Text' )
                                     ( fieldname = 'BUKRS'     seltext_l = 'Company Code' )
                                     ( fieldname = 'VKORG'     seltext_l = 'Sales Organization' )
                                     ( fieldname = 'GJAHR'     seltext_l = 'Fiscal Year' )
                                     ( fieldname = 'BLART'     seltext_l = 'Document Type' )
                                     ( fieldname = 'PRCTR'     seltext_l = 'Profit Center' )
                                     ( fieldname = 'KOSTL'     seltext_l = 'Cost Center' )
                                     ( fieldname = 'BLDAT'     seltext_l = 'Document Date' )
                                     ( fieldname = 'XBLNR'     seltext_l = 'Reference' )
                                     ( fieldname = 'TCODE'     seltext_l = 'Transaction Code' )
                                     ( fieldname = 'PPNAM'     seltext_l = 'User Name' )
                                     ( fieldname = 'MWSKZ'     seltext_l = 'Tax Code' )
                                     ( fieldname = 'QSSKZ'     seltext_l = 'Withholding Tax Code' )
                                     ( fieldname = 'KUNNR'     seltext_l = 'Customer' )
                                     ( fieldname = 'NAME1'     seltext_l = 'Customer/Vendor Name' )
                                     ( fieldname = 'LIFNR'     seltext_l = 'Vendor' )
                                     ( fieldname = 'BUZEI'     seltext_l = 'Line Item' )
                                     ( fieldname = 'COLOR'     seltext_l = 'Row Color' )
                                     ( fieldname = 'WERKS'     seltext_l = 'Plant' )
                                     ( fieldname = 'FKART'     seltext_l = 'Billing Type' )
                                     ( fieldname = 'TIME'      seltext_l = 'Time' )
                                     ( fieldname = 'PRIMARYID' seltext_l = 'Primary ID' ) )
    TABLES
      t_outtab               = it_final[]                " Table with data to be displayed
    EXCEPTIONS
      program_error          = 1                " Program errors
      OTHERS                 = 2.
  IF sy-subrc <> 0.

  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      FORM  TOP_PAGE
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).

  wa_header-typ = 'H'.
  wa_header-info = 'Astral Poly Technik Ltd'.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF v_cr = 'X'.
    wa_header-info = 'Credit Note Register'.
  ELSE.
    wa_header-info = 'Debit Note Register'.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_belnr-high IS INITIAL.
    CONCATENATE 'Document No :- ' s_belnr-low  ' TO ' s_belnr-high INTO wa_header-info SEPARATED BY space.
  ELSE.
    LOOP AT s_belnr.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_belnr-low IS INITIAL.
          CONCATENATE wa_header-info ',' s_belnr-low INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Document No :- ' s_belnr-low INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_budat-high IS INITIAL.
    CONCATENATE s_budat-low+6(2) '-' s_budat-low+4(2) '-' s_budat-low+0(4) INTO v_lowdate.
    CONCATENATE s_budat-high+6(2) '-' s_budat-high+4(2) '-' s_budat-high+0(4) INTO v_highdate.
    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
  ELSE.
    CONCATENATE s_budat-low+6(2) '-' s_budat-low+4(2) '-' s_budat-low+0(4) INTO v_lowdate.
    LOOP AT s_budat.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_budat-low IS INITIAL.
          CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Date :- ' v_lowdate INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CLEAR : v_lowdate,v_highdate.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_header.
*      I_LOGO             = 'ASTRALS'.

  CLEAR wa_header.
  REFRESH it_header.
ENDFORM.    " TOP_PAGE
*&---------------------------------------------------------------------*
*&      FORM  INTERACTIVE
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM interactive USING r_ucomm TYPE sy-ucomm
                       selfield TYPE slis_selfield.
  CLEAR wa_final.
  CASE r_ucomm.
    WHEN '&IC1'.
      READ TABLE it_final INDEX selfield-tabindex INTO wa_final.
      SET PARAMETER ID 'BLN' FIELD wa_final-belnr.
      SET PARAMETER ID 'BUK' FIELD wa_final-bukrs.
      SET PARAMETER ID 'GJR' FIELD wa_final-gjahr.
      CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN.
  ENDCASE.

ENDFORM.
