FUNCTION-POOL ZFI_BTE_CHECK.                "MESSAGE-ID ..

* INCLUDE LZFI_BTE_CHECKD...                 " Local class definition
