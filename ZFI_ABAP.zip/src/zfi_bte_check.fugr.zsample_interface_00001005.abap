FUNCTION zsample_interface_00001005.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_BSEG) LIKE  BSEG STRUCTURE  BSEG
*"     VALUE(I_BKPF) LIKE  BKPF STRUCTURE  BKPF
*"     VALUE(I_SKA1) LIKE  SKA1 STRUCTURE  SKA1
*"     VALUE(I_SKB1) LIKE  SKB1 STRUCTURE  SKB1
*"----------------------------------------------------------------------

  DATA: lv_fy(4)  TYPE c,
        lv_fiscal TYPE gjahr.
  DATA: lv_firstd TYPE sy-datum,
        lv_lastd  TYPE sy-datum.

  TYPES: BEGIN OF ty_tvarvc,
           sign   TYPE char01,
           option TYPE char02,
           low    TYPE rvari_val_255,
           high   TYPE rvari_val_255,
         END OF ty_tvarvc,
         tt_tvarvc TYPE TABLE OF ty_tvarvc.
  DATA: rt_tcode  TYPE TABLE OF ty_tvarvc.
  DATA:Yt_tvarvc TYPE TABLE OF tvarvc.
  IF i_BKPF-xblnr IS NOT INITIAL.


    SELECT *
      INTO TABLE Yt_tvarvc
       FROM tvarvc
       WHERE name  = 'ZFI_VALID_TCODE' .
    IF sy-subrc = 0.
      rt_tcode = VALUE #( FOR lw_tvarvc IN Yt_tvarvc
                        WHERE ( name = 'ZFI_VALID_TCODE' )
                        ( sign = lw_tvarvc-sign
                          option = lw_tvarvc-opti
                          low = lw_tvarvc-low
                          high = lw_tvarvc-high ) ).
    ENDIF.

*    IF sy-tcode = 'FV60' OR sy-tcode = 'FB60' OR sy-tcode = 'FV65' OR sy-tcode = 'MIRO' OR sy-tcode = 'MIR7' OR sy-tcode =  'FB65'.
    IF sy-tcode IN rt_tcode.
      DATA:llt_tvar TYPE TABLE OF tvarvc.
      DATA low  TYPE string.
      SELECT *
        FROM tvarvc
         INTO TABLE llt_tvar   "Table for tvarvc
          WHERE name  = 'ZFI_REFERENCE' .


      READ TABLE llt_tvar INTO DATA(lw_tvar) INDEX 1.
      IF sy-subrc = 0.
        low = lw_tvar-low.
        IF  i_BKPF-xblnr CA CONV string( lw_tvar-low ) .
          DATA(lv_xblnr) = '(SAPLFDCB)BKPF-XBLNR'.
          FIELD-SYMBOLS: <xblnr> TYPE any.
          ASSIGN (lv_xblnr) TO <xblnr>.
          IF <xblnr> IS ASSIGNED.
            <xblnr> = ' '.
          ENDIF.
*      IF invfo-xblnr CA ';:_`~!@#$%^&*()+=|\]}{["?.>,<' or invfo-xblnr CA | ' |.
          MESSAGE | Only - and / are Allowed in a Reference | TYPE 'E' DISPLAY LIKE 'E'.
        ENDIF.
      ENDIF.

      IF i_BKPF-bldat GT sy-datum.
        MESSAGE 'Please do not enter future date for Document date' TYPE 'E'  DISPLAY LIKE 'E'.
      ENDIF.
    ENDIF.

  ENDIF.

ENDFUNCTION.
