*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_ISD_SPLIT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_ISD_SPLIT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
