*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_BANKKK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_BANKKK          .

  PERFORM TABLEPROC.

ENDFUNCTION.
