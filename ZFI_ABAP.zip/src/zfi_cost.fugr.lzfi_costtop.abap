FUNCTION-POOL ZFI_COST                   MESSAGE-ID SV.

* INCLUDE LZFI_COSTD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_COSTT00                            . "view rel. data dcl.
