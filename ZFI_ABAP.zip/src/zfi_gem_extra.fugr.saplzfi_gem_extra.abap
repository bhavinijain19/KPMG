*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_GEM_EXTRATOP.                 " Global Data
  INCLUDE LZFI_GEM_EXTRAUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_GEM_EXTRAF...                 " Subroutines
* INCLUDE LZFI_GEM_EXTRAO...                 " PBO-Modules
* INCLUDE LZFI_GEM_EXTRAI...                 " PAI-Modules
* INCLUDE LZFI_GEM_EXTRAE...                 " Events
* INCLUDE LZFI_GEM_EXTRAP...                 " Local class implement.
* INCLUDE LZFI_GEM_EXTRAT99.                 " ABAP Unit tests
  INCLUDE LZFI_GEM_EXTRAF00                       . " subprograms
  INCLUDE LZFI_GEM_EXTRAI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
