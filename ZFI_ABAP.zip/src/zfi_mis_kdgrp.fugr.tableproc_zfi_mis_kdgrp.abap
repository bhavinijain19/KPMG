*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_MIS_KDGRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_MIS_KDGRP       .

  PERFORM TABLEPROC.

ENDFUNCTION.
