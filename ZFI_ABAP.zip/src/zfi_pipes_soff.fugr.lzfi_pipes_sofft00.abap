*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PIPES_SOFF..................................*
DATA:  BEGIN OF STATUS_ZFI_PIPES_SOFF                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PIPES_SOFF                .
CONTROLS: TCTRL_ZFI_PIPES_SOFF
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PIPES_SOFF                .
TABLES: ZFI_PIPES_SOFF                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
