class ZCL_J_1IG_STO_CLOUD definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_BADI_J_1IG_STO_CLOUD .
protected section.
private section.
ENDCLASS.



CLASS ZCL_J_1IG_STO_CLOUD IMPLEMENTATION.


  method IF_BADI_J_1IG_STO_CLOUD~CHANGE_BEFORE_POST.

    DATA(lv_test) = 'X'.
    lv_test = 'P'.
  endmethod.
ENDCLASS.
