*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PIPES_DATATOP.                " Global Data
  INCLUDE LZFI_PIPES_DATAUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PIPES_DATAF...                " Subroutines
* INCLUDE LZFI_PIPES_DATAO...                " PBO-Modules
* INCLUDE LZFI_PIPES_DATAI...                " PAI-Modules
* INCLUDE LZFI_PIPES_DATAE...                " Events
* INCLUDE LZFI_PIPES_DATAP...                " Local class implement.
* INCLUDE LZFI_PIPES_DATAT99.                " ABAP Unit tests
  INCLUDE LZFI_PIPES_DATAF00                      . " subprograms
  INCLUDE LZFI_PIPES_DATAI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzfi_pipes_dataf01.
