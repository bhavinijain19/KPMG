FUNCTION zfi_senh_gst_pan.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_BKDF) LIKE  BKDF STRUCTURE  BKDF
*"     VALUE(I_UF05A) LIKE  UF05A STRUCTURE  UF05A
*"     VALUE(I_XVBUP) LIKE  OFIWA-XVBUP DEFAULT 'X'
*"  TABLES
*"      T_AUSZ1 STRUCTURE  AUSZ1 OPTIONAL
*"      T_AUSZ2 STRUCTURE  AUSZ2 OPTIONAL
*"      T_AUSZ3 STRUCTURE  AUSZ_CLR OPTIONAL
*"      T_BKP1 STRUCTURE  BKP1
*"      T_BKPF STRUCTURE  BKPF
*"      T_BSEC STRUCTURE  BSEC
*"      T_BSED STRUCTURE  BSED
*"      T_BSEG STRUCTURE  BSEG
*"      T_BSET STRUCTURE  BSET
*"      T_BSEU STRUCTURE  BSEU
*"----------------------------------------------------------------------

  " Example logic inside the function module
  DATA: lv_gstin TYPE lfa1-stcd3,
        lv_pan   TYPE lfa1-j_1ipanno,
        lv_msg   TYPE string.

  " Loop through line items to find the vendor (KOART = 'K')
  LOOP AT t_bseg WHERE koart = 'K'.
    " Fetch GSTIN from LFA1
    SELECT SINGLE stcd3, j_1ipanno FROM lfa1 INTO (@lv_gstin,@lv_pan) WHERE lifnr = @t_bseg-lifnr.

    " Fetch PAN (table/field depends on your India GST localization)
*    SELECT SINGLE j_1ipanno FROM j_1id INTO lv_pan WHERE lifnr = t_bseg-lifnr.

    " Prepare and display the pop-up
    CONCATENATE 'GSTIN:' lv_gstin 'PAN:' lv_pan INTO lv_msg SEPARATED BY space.

    CALL FUNCTION 'POPUP_TO_DISPLAY_TEXT'
      EXPORTING
        titel     = 'Vendor Tax Details'
        textline1 = lv_msg.
  ENDLOOP.




ENDFUNCTION.
