FUNCTION-POOL ZFI_TE_BUPLA               MESSAGE-ID SV.

* INCLUDE LZFI_TE_BUPLAD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_TE_BUPLAT00                        . "view rel. data dcl.
