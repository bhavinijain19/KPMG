*&---------------------------------------------------------------------*
*& Include          ZBP_TDS_UPLOADER_SEL
*&---------------------------------------------------------------------*

"" Input Screen
SELECTION-SCREEN: BEGIN OF BLOCK b1 WITH FRAME.
  PARAMETERS: p_file TYPE ibipparms-path." OBLIGATORY.
*              p_mode TYPE char1.
SELECTION-SCREEN: END OF BLOCK b1.

" Add a push button to the selection screen
SELECTION-SCREEN: PUSHBUTTON /1(20) TEXT-001 USER-COMMAND ok.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'OK'.

      DATA : t_data TYPE g_ty_final OCCURS 0 WITH HEADER LINE.

      DATA: BEGIN OF wa_header,
              name TYPE c LENGTH 30,
            END OF wa_header.

      DATA: t_header LIKE TABLE OF wa_header.

      DATA: lv_filename      TYPE string,
            lv_path          TYPE string,
            lv_fullpath      TYPE string,
            lv_result        TYPE i,
            lv_default_fname TYPE string,
            lv_fname         TYPE string.

*set header
      APPEND 'Company Code'     TO t_header.
      APPEND 'Account type'     TO t_header.
      APPEND 'Cust./Vend. Acct' TO t_header.
      APPEND 'Sub to TAN Ex'    TO t_header.
      APPEND 'Section Group'    TO t_header.
      APPEND 'WTax Type'        TO t_header.
      APPEND 'W/Tax Code'       TO t_header.
      APPEND 'Exempt From'      TO t_header.
**      APPEND 'PAN'              TO t_header.
      APPEND 'Exempt To'        TO t_header.
      APPEND 'Exemption Number' TO t_header.
      APPEND 'Exemption Rate'   TO t_header.
      APPEND 'Exempt. Reason'   TO t_header.
      APPEND 'Exem threshold'   TO t_header.
      APPEND 'Currency'         TO t_header.

      CALL METHOD cl_gui_frontend_services=>file_save_dialog
        EXPORTING
          window_title      = 'File Directory'
          default_extension = 'XLS'
          initial_directory = 'D:\'
        CHANGING
          filename          = lv_filename
          path              = lv_path
          fullpath          = lv_fullpath
          user_action       = lv_result.

      lv_fname = lv_fullpath.
*      lv_fname = |TDS uploader Template.XLSX|.

*download file in excel
      CALL FUNCTION 'GUI_DOWNLOAD'
        EXPORTING
          bin_filesize        = ''
          filename            = lv_fname
          filetype            = 'DBF'
        TABLES
          data_tab            = t_data
          fieldnames          = t_header
        EXCEPTIONS
          file_open_error     = 1
          file_write_error    = 2
          invalid_filesize    = 3
          invalid_table_width = 4
          invalid_type        = 5
          no_batch            = 6
          unknown_error       = 7
          OTHERS              = 8.

  ENDCASE.

  "" F4 for Uploader

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.

  CALL FUNCTION 'F4_FILENAME'
    IMPORTING
      file_name = p_file.
