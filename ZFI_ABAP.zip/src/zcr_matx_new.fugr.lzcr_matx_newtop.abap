FUNCTION-POOL ZCR_MATX_NEW               MESSAGE-ID SV.

* INCLUDE LZCR_MATX_NEWD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCR_MATX_NEWT00                        . "view rel. data dcl.
