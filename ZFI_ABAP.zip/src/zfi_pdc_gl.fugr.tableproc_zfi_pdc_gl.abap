*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_PDC_GL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_PDC_GL          .

  PERFORM TABLEPROC.

ENDFUNCTION.
