FUNCTION-POOL ZFI_POST.                     "MESSAGE-ID ..

* INCLUDE LZFI_POSTD...                      " Local class definition
