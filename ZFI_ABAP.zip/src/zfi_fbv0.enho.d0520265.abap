"Name: \PR:SAPLJ_1IG_VENDOR_SUBSCR\FO:HIDE_FIELDS\SE:BEGIN\EI
ENHANCEMENT 0 ZFI_FBV0.

DATA: it_vend1 TYPE STANDARD TABLE OF ZFI_VEND_DETAILS,
      wa_vend1 TYPE ZFI_VEND_DETAILS.

  IF wa_vend-zname IS INITIAL AND wa_vend-zgst IS INITIAL AND wa_vend-zinv IS INITIAL AND
     wa_vend-zdate IS INITIAL.

    SELECT SINGLE * FROM ZFI_VEND_DETAILS INTO wa_vend1 WHERE bukrs = invfo-bukrs AND belnr = invfo-belnr
                                                          AND gjahr = invfo-gjahr.

    wa_vend-zname = wa_vend1-zname.
    wa_vend-zgst  = wa_vend1-zgst.
    wa_vend-zinv  = wa_vend1-zinv.
    wa_vend-zdate = wa_vend1-zdate.

  ENDIF.
ENDENHANCEMENT.
