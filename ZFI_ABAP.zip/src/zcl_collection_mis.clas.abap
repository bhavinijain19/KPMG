class ZCL_COLLECTION_MIS definition
  public
  final
  create public .

public section.

  interfaces ZIF_COLLECTION_MIS .

  data LT_FINAL type ZFI_COLLECTION_MIS_TT .
  data LS_FINAL type ZFI_COLLECTION_MIS_TS .
  data LT_KNVV type ZFI_COLL_MIS_KNVV_TT .
  data LS_KNVV type ZFI_COLL_MIS_KNVV_TS .
  data LT_BSTAB type ZFI_COLL_MIS_BS_TT .
  data LS_BSTAB type ZFI_COLL_MIS_BS_TS .
protected section.
private section.
ENDCLASS.



CLASS ZCL_COLLECTION_MIS IMPLEMENTATION.


  method ZIF_COLLECTION_MIS~DISPLAY_DATA.
  endmethod.


  METHOD zif_collection_mis~filter_data.
    IF lt_knvv[] IS NOT INITIAL.
**      DATA : lv_start  TYPE d,
**             lv_end    TYPE d,
      DATA            ls_detail TYPE zfi_collection_mis_detail_ts.
**      CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
**        EXPORTING
**          iv_date             = sy-datum
**        IMPORTING
**          ev_month_begin_date = lv_start
**          ev_month_end_date   = lv_end.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
             kidno
        FROM bsid
        INTO CORRESPONDING FIELDS OF TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz <> 'I' AND umskz <> 'Q'
          AND ( budat >= start_date AND budat <= end_date ) "lv_end
          AND blart IN blart."( 'DZ' , 'DG' ).
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
             kidno
        FROM bsad
        APPENDING CORRESPONDING FIELDS OF TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz <> 'I' AND umskz <> 'Q'
          AND ( budat >= start_date AND budat <= end_date )
                  AND blart IN blart.
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr.

      LOOP AT lt_bstab INTO ls_bstab.
        ls_knvv = VALUE #( lt_knvv[ kunnr = ls_bstab-kunnr ] OPTIONAL ).
        IF ls_knvv IS NOT INITIAL.
          ls_detail-kunnr = ls_knvv-kunnr.
          ls_detail-vkorg = ls_knvv-vkorg.
          ls_detail-name1 = ls_knvv-name1.
          ls_detail-kvgr1 = ls_knvv-kvgr1.
          ls_detail-kvgr2 = ls_knvv-kvgr2.
          ls_detail-bezei = ls_knvv-bezei.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*          SELECT SINGLE txt
*              FROM zfi_mis_kdgrp
*              INTO ls_detail-division
*              WHERE kdgrp = ls_knvv-kdgrp.

          SELECT kvgr1
           FROM zfi_mis_kdgrp INTO ls_detail-division UP TO 1 ROWS WHERE kvgr1 = ls_knvv-kvgr1
           ORDER BY PRIMARY KEY .
          ENDSELECT.
* End of Quick Fix

          IF sy-subrc <> 0.
            ls_detail-division = 'OTHERS'.
          ENDIF.
        ENDIF."ls_knvv is NOT INITIAL.
        ls_detail-belnr = ls_bstab-belnr.
        ls_detail-kidno = ls_bstab-kidno.
        ls_detail-budat = ls_bstab-budat.
        CASE ls_bstab-blart.
          WHEN 'DZ'.
*            IF ls_bstab-shkzg = 'H'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_detail-dz_amt = ls_detail-dz_amt +  ls_bstab-dmbtr.
***            IF ls_detail-dz_amt < 0.
***              ls_detail-dz_amt = ls_detail-dz_amt * -1.
***            ENDIF."ls_detail-dz_amt < 0.
          WHEN 'DG'.
*            IF ls_bstab-shkzg = 'H'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_detail-dg_amt = ls_detail-dg_amt +  ls_bstab-dmbtr.
***            IF ls_detail-dg_amt < 0.
***              ls_detail-dg_amt = ls_detail-dg_amt * -1.
***            ENDIF."ls_detail-dz_amt < 0.
          WHEN 'DA'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_detail-dz_amt = ls_detail-dz_amt +  ls_bstab-dmbtr.
*            ls_detail-dz_amt = ls_detail-dz_amt * -1. "Comment by Rahul Vasita on 23.01.2024 14:58:08
        ENDCASE.
        ls_detail-total = ls_detail-dz_amt + ls_detail-dg_amt.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ls_detail-kunnr
          IMPORTING
            output = ls_detail-kunnr.

        APPEND ls_detail TO lt_detail.
        CLEAR : ls_detail , ls_knvv , ls_bstab.
      ENDLOOP.

****      LOOP AT lt_knvv INTO ls_knvv.
****        ls_detail-kunnr = ls_knvv-kunnr.
****        ls_detail-vkorg = ls_knvv-vkorg.
****        ls_detail-name1 = ls_knvv-name1.
****        ls_detail-bezei = ls_knvv-bezei.
****        SELECT SINGLE txt
****            FROM zfi_mis_kdgrp
****            INTO ls_detail-division
****            WHERE kdgrp = ls_knvv-kdgrp.
*****        CASE ls_knvv-kdgrp.
*****          WHEN '01' OR '19'.
*****            ls_final-division = 'MNT'.
*****          WHEN '11' OR '21'.
*****            ls_final-division = 'WOOD'.
*****          WHEN '06' OR '20'.
*****            ls_final-division = 'IND'.
*****          WHEN '12' OR '22'.
*****            ls_final-division = 'CC'.
*****          WHEN '10'.
*****            ls_final-division = 'EXPORT'.
*****          WHEN '03'.
*****            ls_final-division = 'OTHERS'.
*****          WHEN OTHERS.
*****        ENDCASE.
****
****        LOOP AT lt_bstab INTO ls_bstab WHERE kunnr = ls_knvv-kunnr.
****          ls_detail-belnr = ls_bstab-belnr.
****          ls_detail-kidno = ls_bstab-kidno.
****          ls_detail-budat = ls_bstab-budat.
****          CASE ls_bstab-blart.
****            WHEN 'DZ'.
****              IF ls_bstab-shkzg = 'H'.
****                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
****              ENDIF.
****              ls_detail-dz_amt = ls_detail-dz_amt +  ls_bstab-dmbtr.
****              IF ls_detail-dz_amt < 0.
****                ls_detail-dz_amt = ls_detail-dz_amt * -1.
****              ENDIF."ls_detail-dz_amt < 0.
****            WHEN 'DG'.
****              IF ls_bstab-shkzg = 'H'.
****                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
****              ENDIF.
****              ls_detail-dg_amt = ls_detail-dg_amt +  ls_bstab-dmbtr.
****              IF ls_detail-dz_amt < 0.
****                ls_detail-dz_amt = ls_detail-dz_amt * -1.
****              ENDIF."ls_detail-dz_amt < 0.
****            WHEN 'DA'.
****              ls_detail-dz_amt = ls_detail-dz_amt +  ls_bstab-dmbtr.
****              ls_detail-dz_amt = ls_detail-dz_amt * -1.
****
****          ENDCASE.
******          IF ls_detail-dz_amt < 0.
******            ls_detail-dz_amt = ls_detail-dz_amt * -1.
******          ENDIF."ls_detail-dz_amt < 0.
******
******          IF ls_detail-dg_amt < 0.
******            ls_detail-dg_amt = ls_detail-dg_amt * -1.
******          ENDIF."ls_detail-dz_amt < 0.
****
****          ls_detail-total = ls_detail-dz_amt + ls_detail-dg_amt.
****          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
****            EXPORTING
****              input  = ls_detail-kunnr
****            IMPORTING
****              output = ls_detail-kunnr.
****
****          APPEND ls_detail TO lt_detail.
****          CLEAR : ls_bstab , ls_detail-belnr,
****                  ls_detail-kidno,
****                  ls_detail-budat,
****                  ls_detail-dz_amt,
****                  ls_detail-dg_amt,
****                  ls_detail-total.
****        ENDLOOP.
****
******        IF ls_detail-dz_amt < 0.
******          ls_detail-dz_amt = ls_detail-dz_amt * -1.
******        ENDIF."ls_detail-dz_amt < 0.
******
******        IF ls_detail-dg_amt < 0.
******          ls_detail-dg_amt = ls_detail-dg_amt * -1.
******        ENDIF."ls_detail-dz_amt < 0.
******
******        ls_detail-total = ls_detail-dz_amt + ls_detail-dg_amt.
******        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
******          EXPORTING
******            input  = ls_detail-kunnr
******          IMPORTING
******            output = ls_detail-kunnr.
******
******        APPEND ls_detail TO lt_detail.
******        CLEAR : ls_detail , ls_bstab.
****        CLEAR : ls_knvv , ls_detail.
****      ENDLOOP.
    ELSE.
      MESSAGE 'No Customer Data Found' TYPE 'E'.
    ENDIF."lt_knvv[] IS NOT INITIAL.

    DELETE lt_detail WHERE budat = '00000000'.
  ENDMETHOD.


  METHOD zif_collection_mis~get_data.
    SELECT a~kunnr
           a~vkorg
           a~vtweg
           a~vkbur
           a~spart
           a~erdat
*           a~kdgrp
           a~kvgr1
           a~kvgr2

           b~name1
           c~bezei
      FROM knvv AS a
      INNER JOIN kna1 AS b ON a~kunnr = b~kunnr
*      INNER JOIN tvkbt AS c ON a~vkbur = c~vkbur
      LEFT OUTER JOIN tvkbt AS c ON a~vkbur = c~vkbur
      INTO TABLE lt_knvv
      WHERE a~kunnr IN kunnr
        AND a~vkorg IN vkorg
        AND a~vtweg IN vtweg
        AND a~spart IN spart
*        AND c~spras = sy-langu
*        AND a~kdgrp IN kdgrp
        AND a~kvgr1 IN kvgr1
        AND a~kvgr2 IN kvgr2
        AND a~vkbur IN vkbur.


  ENDMETHOD.


  METHOD zif_collection_mis~process_data.
    IF lt_knvv[] IS NOT INITIAL.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
        FROM bsid
        INTO TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz <> 'I' AND umskz <> 'Q'
          AND ( budat >= start_date AND budat <= end_date ) "lv_end
          AND blart IN blart."( 'DZ' , 'DG' ).
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr.

      SELECT bukrs
             kunnr
             umsks
             umskz
             augdt
             augbl
             zuonr
             gjahr
             belnr
             buzei
             budat
             waers
             blart
             shkzg
             dmbtr
        FROM bsad
        APPENDING TABLE lt_bstab
        FOR ALL ENTRIES IN lt_knvv
        WHERE bukrs IN bukrs
          AND kunnr = lt_knvv-kunnr
          AND umskz <> 'I' AND umskz <> 'Q'
          AND ( budat >= start_date AND budat <= end_date )
          AND blart IN blart.
      SORT lt_bstab ASCENDING BY bukrs kunnr belnr buzei gjahr.

      LOOP AT lt_bstab INTO ls_bstab.
        ls_knvv = VALUE #( lt_knvv[ kunnr = ls_bstab-kunnr ] OPTIONAL ).
        IF ls_knvv IS NOT INITIAL.
          ls_final-kunnr = ls_knvv-kunnr.
          ls_final-vkorg = ls_knvv-vkorg.
          ls_final-name1 = ls_knvv-name1.
          ls_final-bezei = ls_knvv-bezei.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*          SELECT SINGLE txt
*              FROM zfi_mis_kdgrp
*              INTO ls_final-division
*              WHERE kdgrp = ls_knvv-kdgrp.

          SELECT kvgr1
           FROM zfi_mis_kdgrp INTO ls_final-division UP TO 1 ROWS WHERE kvgr1 = ls_knvv-kvgr1
           ORDER BY PRIMARY KEY .
          ENDSELECT.
* End of Quick Fix

          IF sy-subrc <> 0.
            ls_final-division = 'OTHERS'.
          ENDIF.
        ENDIF."ls_knvv is NOT INITIAL.
        ls_final-budat = ls_bstab-budat.
        CASE ls_bstab-blart.
          WHEN 'DZ'." OR 'DA'.
*            IF ls_bstab-shkzg = 'H'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_final-dz_amt = ls_final-dz_amt +  ls_bstab-dmbtr.
          WHEN 'DG'.
*            IF ls_bstab-shkzg = 'H'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_final-dg_amt = ls_final-dg_amt +  ls_bstab-dmbtr.
          WHEN 'DA'.
            IF ls_bstab-shkzg = 'S'.
              ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
            ENDIF.
            ls_final-dz_amt = ls_final-dz_amt +  ls_bstab-dmbtr.
*            ls_final-dz_amt = ls_final-dz_amt * -1.

        ENDCASE.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = ls_final-kunnr
          IMPORTING
            output = ls_final-kunnr.

        APPEND ls_final TO lt_final.
        CLEAR : ls_final , ls_bstab.
        CLEAR : ls_knvv.
      ENDLOOP.

***      LOOP AT lt_knvv INTO ls_knvv.
***        ls_final-kunnr = ls_knvv-kunnr.
***        ls_final-vkorg = ls_knvv-vkorg.
***        ls_final-name1 = ls_knvv-name1.
***        ls_final-bezei = ls_knvv-bezei.
***        SELECT SINGLE txt
***            FROM zfi_mis_kdgrp
***            INTO ls_final-division
***            WHERE kdgrp = ls_knvv-kdgrp.
****        CASE ls_knvv-kdgrp.
****          WHEN '01' OR '19'.
****            ls_final-division = 'MNT'.
****          WHEN '11' OR '21'.
****            ls_final-division = 'WOOD'.
****          WHEN '06' OR '20'.
****            ls_final-division = 'IND'.
****          WHEN '12' OR '22'.
****            ls_final-division = 'CC'.
****          WHEN '10'.
****            ls_final-division = 'EXPORT'.
****          WHEN '03'.
****            ls_final-division = 'OTHERS'.
****          WHEN OTHERS.
****        ENDCASE.
***        LOOP AT lt_bstab INTO ls_bstab WHERE kunnr = ls_knvv-kunnr.
***          ls_final-budat = ls_bstab-budat.
***          CASE ls_bstab-blart.
***            WHEN 'DZ' OR 'DA'.
***              IF ls_bstab-shkzg = 'H'.
***                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
***              ENDIF.
***              ls_final-dz_amt = ls_final-dz_amt +  ls_bstab-dmbtr.
***            WHEN 'DG'.
***              IF ls_bstab-shkzg = 'H'.
***                ls_bstab-dmbtr = ls_bstab-dmbtr * -1.
***              ENDIF.
***              ls_final-dg_amt = ls_final-dg_amt +  ls_bstab-dmbtr.
***          ENDCASE.
***        ENDLOOP.
***        IF ls_final-dz_amt < 0.
***          ls_final-dz_amt = ls_final-dz_amt * -1.
***        ENDIF."ls_final-dz_amt < 0.
***
***        IF ls_final-dg_amt < 0.
***          ls_final-dg_amt = ls_final-dg_amt * -1.
***        ENDIF."ls_final-dz_amt < 0.
***
***        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
***          EXPORTING
***            input  = ls_final-kunnr
***          IMPORTING
***            output = ls_final-kunnr.
***
***        APPEND ls_final TO lt_final.
***        CLEAR : ls_final , ls_bstab.
***        CLEAR : ls_knvv.
***      ENDLOOP.
    ELSE.
      MESSAGE 'No Customer Data Found' TYPE 'E'.
    ENDIF."lt_knvv[] IS NOT INITIAL.

    DELETE lt_final WHERE budat = '00000000'.
  ENDMETHOD.
ENDCLASS.
