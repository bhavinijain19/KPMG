*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_CH_DAY_PAINT................................*
DATA:  BEGIN OF STATUS_ZFI_CH_DAY_PAINT              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CH_DAY_PAINT              .
CONTROLS: TCTRL_ZFI_CH_DAY_PAINT
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_CH_DAY_PAINT              .
TABLES: ZFI_CH_DAY_PAINT               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
