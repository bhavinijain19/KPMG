*&---------------------------------------------------------------------*
*& Report  ZFI_ASSET_TRANSFER
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zfi_asset_transfer.

****************************************Selection Screen*******************
Types : begin of ty_bkpf,
  bukrs type bkpf-bukrs,
  belnr type bkpf-belnr,
  gjahr type bkpf-gjahr,
  budat type bkpf-budat,
  END OF ty_bkpf.

  data : it_bkpf TYPE STANDARD TABLE OF ty_bkpf.
  data : wa_bkpf type ty_bkpf.



TABLES : bkpf,anlz.
SELECTION-SCREEN BEGIN OF BLOCK a1 WITH FRAME TITLE text-003.

SELECT-OPTIONS : s_bukrs for bkpf-bukrs OBLIGATORY,
                 s_budat FOR bkpf-budat OBLIGATORY,
                 s_werks FOR anlz-werks.

SELECTION-SCREEN END OF BLOCK a1.

START-OF-SELECTION.

select bukrs belnr gjahr budat from bkpf into table it_bkpf where  bukrs in  s_bukrs and  budat in s_budat and tcode = 'ABUMN'.
  if it_bkpf is not INITIAL.
*    select bukrs b
    endif.
