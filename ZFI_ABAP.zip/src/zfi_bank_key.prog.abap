*&----------------------------------------------------------------------------*
*& Report  ZFI_BANK_KEY
*&----------------------------------------------------------------------------*
*& Title: Upload Bank Key.
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Cummins Infosystems Ltd, Pune
*& Functional Consultant : Biswajit Sahoo, KPIT Cummins Infosystems Ltd, Pune
*& Report Creation Date  : 13/10/2014
*& Transaction Code      :
*& Request Number        : DEVK900430
*&----------------------------------------------------------------------------*
 REPORT  zfi_bank_key
       NO STANDARD PAGE HEADING LINE-SIZE 255.

 TABLES: t100.
*include bdcrecx1.

*parameters: dataset(132) lower case.
***    DO NOT CHANGE - the generated data section - DO NOT CHANGE    ***
*
*   If it is nessesary to change the data section use the rules:
*   1.) Each definition of a field exists of two lines
*   2.) The first line shows exactly the comment
*       '* data element: ' followed with the data element
*       which describes the field.
*       If you don't have a data element use the
*       comment without a data element name
*   3.) The second line shows the fieldname of the
*       structure, the fieldname must consist of
*       a fieldname and optional the character '_' and
*       three numbers and the field length in brackets
*   4.) Each field must be type C.
*
*** Generated data section with specific formatting - DO NOT CHANGE  ***
* TYPES: BEGIN OF ty_itab,
** data element: BANKS
*          banks_001(003),       "Bank country key
** data element: BANKK
*          bankl_002(015),       "Bank Keys
** data element: BANKA
*          banka_003(060),       "Name of bank
** data element: REGIO
*          provz_004(003),       "Region (State, Province, County)
** data element: STRAS_GP
*          stras_005(035),       "House number and street
** data element: ORT01_GP
*          ort01_006(035),       "City
** data element: BRNCH
*          brnch_007(040),       "Bank Branch
** data element: SWIFT
*          swift_008(011),       "SWIFT Code for International Payments
** data element: BANKL
*          bnklz_009(015),       "Bank number
*        END OF ty_itab.

 TYPES : BEGIN OF ty_itab,
           banks  TYPE banks,
           bankl  TYPE bankk,
           banka  TYPE banka,
           brnch  TYPE brnch,
           stras  TYPE stras,
           pstlz  TYPE pstlz,
           ort01  TYPE ort01,
           country  TYPE land1,
           regio  TYPE regio,
           swift  TYPE swift,
           banklz TYPE bankl,
           bgrup  TYPE bgrup,
         END OF ty_itab.

*** End generated data section ***
 DATA : t_itab    TYPE STANDARD TABLE OF ty_itab INITIAL SIZE 0,
        t_bdcdata TYPE STANDARD TABLE OF bdcdata INITIAL SIZE 0.
*&---------------------------------------------------------------------*
*& Work Area
*&---------------------------------------------------------------------*

 DATA : w_bdcdata TYPE bdcdata,
        record    TYPE ty_itab,
*        record1   TYPE ty_itab1,
        messtab   LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE,
        file_path TYPE string.

 DATA:
   l_log_handle TYPE balloghndl,
   l_s_log      TYPE bal_s_log,
   l_s_msg      TYPE bal_s_msg,
   l_msgno      TYPE symsgno,
   v_txt(255)   TYPE c.               "To Hold Message Text.

** End generated data section ***
*include bdcrecx1.
 SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
   PARAMETERS : mod LIKE ctu_params-dismode DEFAULT 'A'.
   PARAMETERS : file_url LIKE rlgrap-filename OBLIGATORY. " Output File
 SELECTION-SCREEN END OF BLOCK b1.

 AT SELECTION-SCREEN ON VALUE-REQUEST FOR file_url.

   PERFORM sub_get_file.

 START-OF-SELECTION.

* Load the file into the Internal table
   IF NOT file_url IS INITIAL.
     MOVE  file_url TO file_path.
     PERFORM sub_upload_data.
   ENDIF.



**perform open_dataset using dataset.
**perform open_group.
**
**do.
**
**read dataset dataset into record.
**if sy-subrc <> 0. exit. endif.
   LOOP AT t_itab INTO record.
**   AT FIRST.
***     Open the New BDC Session
**      PERFORM sub_bdc_open_group.
**    ENDAT.
*     AT NEW bankl_002.
     AT NEW bankl.
       CLEAR t_bdcdata[].
*      v_flag = c_x.
     ENDAT.

***     PERFORM bdc_dynpro      USING 'SAPMF02B' '0100'.
***     PERFORM bdc_field       USING 'BDC_CURSOR'
***                                   'BNKA-BANKL'.
***     PERFORM bdc_field       USING 'BDC_OKCODE'
***                                   '/00'.
***     PERFORM bdc_field       USING 'BNKA-BANKS'
***                                   record-banks_001.
***     PERFORM bdc_field       USING 'BNKA-BANKL'
***                                   record-bankl_002.
***     PERFORM bdc_dynpro      USING 'SAPMF02B' '0110'.
***     PERFORM bdc_field       USING 'BDC_CURSOR'
***                                   'BNKA-BNKLZ'.
***     PERFORM bdc_field       USING 'BDC_OKCODE'
***                                   '=UPDA'.
***     PERFORM bdc_field       USING 'BNKA-BANKA'
***                                   record-banka_003.
***     PERFORM bdc_field       USING 'BNKA-PROVZ'
***                                   record-provz_004.
***     PERFORM bdc_field       USING 'BNKA-STRAS'
***                                   record-stras_005.
***     PERFORM bdc_field       USING 'BNKA-ORT01'
***                                   record-ort01_006.
***     PERFORM bdc_field       USING 'BNKA-BRNCH'
***                                   record-brnch_007.
***     PERFORM bdc_field       USING 'BNKA-SWIFT'
***                                   record-swift_008.
***     PERFORM bdc_field       USING 'BNKA-BNKLZ'
***                                   record-bnklz_009.
     PERFORM bdc_dynpro      USING 'SAPMF02B' '0100'.
     PERFORM bdc_field       USING 'BDC_CURSOR'
                                   'BNKA-BANKL'.
     PERFORM bdc_field       USING 'BDC_OKCODE'
                                   '/00'.
     PERFORM bdc_field       USING 'BNKA-BANKS'
                                   record-banks.
     PERFORM bdc_field       USING 'BNKA-BANKL'
                                   record-bankl.
     PERFORM bdc_dynpro      USING 'SAPMF02B' '0110'.
     PERFORM bdc_field       USING 'BDC_CURSOR'
                                   'BNKA-BGRUP'.
     PERFORM bdc_field       USING 'BDC_OKCODE'
                                   '=ADDR'.
     PERFORM bdc_field       USING 'BNKA-SWIFT'
                                   record-swift.
     PERFORM bdc_field       USING 'BNKA-BNKLZ'
                                   record-banklz.
     PERFORM bdc_field       USING 'BNKA-BGRUP'
                                   record-bgrup.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-BANK_NAME'
                                   record-banka.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-BANK_BRANCH'
                                   record-brnch.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-STREET'
                                   record-stras.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-HOUSE_NUMBER'
                                   ''.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-POSTAL_CODE'
                                   record-pstlz.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-CITY'
                                   record-ort01.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-COUNTRY'
                                   record-banks.
     PERFORM bdc_field       USING 'BNKA_ADDR_UI-REGION'
                                   record-regio.
*     PERFORM bdc_dynpro      USING 'SAPLSZA1' '0201'.
*     PERFORM bdc_field       USING 'BDC_OKCODE'
*                                   '/ECANC'.
*     PERFORM bdc_field       USING 'BDC_CURSOR'
*                                   'SZA1_D0100-TITLE_MEDI'.
*     PERFORM bdc_dynpro      USING 'SAPLSPO1' '0200'.
*     PERFORM bdc_field       USING 'BDC_OKCODE'
*                                   '=YES'.
*     PERFORM bdc_dynpro      USING 'SAPMF02B' '0110'.
*     PERFORM bdc_field       USING 'BDC_OKCODE'
*                                   '=UPDA'.
*     PERFORM bdc_field       USING 'BNKA-BNKLZ'
*                                   record-banklz.
*     PERFORM bdc_field       USING 'BDC_CURSOR'
*                                   'BNKA_ADDR_UI-BANK_NAME'.
*     PERFORM bdc_field       USING 'BNKA_ADDR_UI-BANK_NAME'
*                                    record-banka.
*     PERFORM bdc_field       USING 'BNKA_ADDR_UI-BANK_BRANCH'
*                                   record-brnch.
*     PERFORM bdc_field       USING 'BNKA_ADDR_UI-CITY'
*                                   record-ort01.
*     PERFORM bdc_field       USING 'BNKA_ADDR_UI-COUNTRY'
*                                   record-country.
*     PERFORM bdc_field       USING 'BNKA_ADDR_UI-REGION'
*                                   record-regio.
     PERFORM bdc_transaction .
*
*enddo.
*
*perform close_group.
*perform close_dataset using dataset.
**    PERFORM sub_bdc_insert.
**
**    AT LAST.
**      PERFORM sub_bdc_close_group.
**    ENDAT.

*enddo.
   ENDLOOP.

*&---------------------------------------------------------------------*
*&      Form  sub_get_file
*&---------------------------------------------------------------------*
 FORM sub_get_file .

   CALL FUNCTION 'F4_FILENAME'
     EXPORTING
       program_name  = sy-repid
       dynpro_number = sy-dynnr
     IMPORTING
       file_name     = file_url.

 ENDFORM.                    " sub_get_file
*&---------------------------------------------------------------------*
*&      Form  sub_upload_data
*&---------------------------------------------------------------------*
 FORM sub_upload_data .
   DATA: p_file  TYPE rlgrap-filename,
         it_type TYPE truxs_t_text_data.
   p_file = file_path.

   CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
     EXPORTING
*      I_FIELD_SEPERATOR    =
       i_line_header        = 'X'
       i_tab_raw_data       = it_type
       i_filename           = p_file
     TABLES
       i_tab_converted_data = t_itab
     EXCEPTIONS
       conversion_failed    = 1
       OTHERS               = 2.
   IF sy-subrc <> 0.
     MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
             WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
   ENDIF.
*delete t_itab index 1.

**
** DATA: lwa_intern TYPE alsmex_tabline,
**        lit_intern TYPE STANDARD TABLE OF alsmex_tabline INITIAL SIZE 0.
**
**  DATA l_row TYPE kcd_ex_row_n. " Row
**
**  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
**    EXPORTING
**      filename                = v_filename
**      i_begin_col             = p_frmcol        "1
**      i_begin_row             = p_frmlin
**      i_end_col               = p_tocol         "14
**      i_end_row               = p_toline
**    TABLES
**      intern                  = lit_intern
**    EXCEPTIONS
**      inconsistent_parameters = 1
**      upload_ole              = 2
**      OTHERS                  = 3.
**  IF sy-subrc <> 0 .
**    MESSAGE text-003 TYPE 'I'.
**    " Error in uploading the file from presentation server
**    LEAVE LIST-PROCESSING.
**
**  ELSE.
**
***    sort lit_intern by row ascending
***                     col ascending.
**
**    l_row = 1.
**
**    LOOP AT lit_intern INTO lwa_intern.
**
**      IF l_row = lwa_intern-row.
**
**        IF lwa_intern-col = 1.
**          record-BANKS_001  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 2.
**          record-BANKL_002  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 3.
**          record-BANKA_003 = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 4.
**          record-PROVZ_004  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 5.
**          record-STRAS_005  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 6.
**          record-ORT01_006  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 7.
**          record-BRNCH_007  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 8.
**          record-SWIFT_008  = lwa_intern-value.
**
**        ELSEIF lwa_intern-col = 9.
**          record-BNKLZ_009  = lwa_intern-value.
**
**        ENDIF.
**
**        AT END OF row.
**          l_row = l_row + 1.
**          APPEND record TO t_itab.
**          CLEAR record.
**        ENDAT.
**
**      ENDIF.
**
**    ENDLOOP.
**
**  ENDIF.

 ENDFORM.                    " SUB_UPLOAD_DATA


*&---------------------------------------------------------------------*
*&      Form bdc_dynpro
*&---------------------------------------------------------------------*
*&      Initialize the screen
*&---------------------------------------------------------------------*

 FORM bdc_dynpro USING    p_g_program_1
                          p_g_screen.

   CLEAR w_bdcdata.
   w_bdcdata-program  = p_g_program_1.
   w_bdcdata-dynpro   = p_g_screen.
   w_bdcdata-dynbegin = 'X'.
   APPEND w_bdcdata TO t_bdcdata.

 ENDFORM.                    "bdc_dynpro

*&---------------------------------------------------------------------*
*&      Form bdc_field
*&---------------------------------------------------------------------*
*&      Insert Field
*&---------------------------------------------------------------------*

 FORM bdc_field USING f_name f_value.

   CLEAR w_bdcdata.
   w_bdcdata-fnam = f_name.
   w_bdcdata-fval = f_value.
   APPEND w_bdcdata TO t_bdcdata.

 ENDFORM.                    "bdc_field

***&---------------------------------------------------------------------*
***&      Form  BDC_CLOSE_GROUP
***&---------------------------------------------------------------------*
***&      Close the BDC session
***&---------------------------------------------------------------------*
**
**FORM sub_bdc_close_group.
**
**  CALL FUNCTION 'BDC_CLOSE_GROUP'
**    EXCEPTIONS
**      not_open    = 1
**      queue_error = 2
**      OTHERS      = 3.
**
**  IF sy-subrc <> 0.
**    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**  ENDIF.
**
**ENDFORM.                    " SUB_BDC_CLOSE_GROUP
**
***&---------------------------------------------------------------------*
***&      Form  BDC_OPEN_GROUP
***&---------------------------------------------------------------------*
***&      To Open the BDC session
***&---------------------------------------------------------------------*
**
**FORM sub_bdc_open_group.
**
**  CALL FUNCTION 'BDC_OPEN_GROUP'
**    EXPORTING
**      client              = sy-mandt
**      group               = p_sessn
**      keep                = 'X'
**      user                = sy-uname
**    EXCEPTIONS
**      client_invalid      = 1
**      destination_invalid = 2
**      group_invalid       = 3
**      group_is_locked     = 4
**      holddate_invalid    = 5
**      internal_error      = 6
**      queue_error         = 7
**      running             = 8
**      system_lock_error   = 9
**      user_invalid        = 10
**      OTHERS              = 11.
**  IF sy-subrc <> 0.
**    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**  ELSE.
**    MESSAGE i000(zb001).
**  ENDIF.
**
**
**
**
**
**
**ENDFORM.                    "SUB_BDC_OPEN_GROUP
**
***&---------------------------------------------------------------------*
***&      Form  BDC_INSERT
***&---------------------------------------------------------------------*
***&      Insert the BDC session
***&---------------------------------------------------------------------*
**
**FORM sub_bdc_insert .
**
**  CALL FUNCTION 'BDC_INSERT'
**    EXPORTING
**      tcode            = 'FI01'
**    TABLES
**      dynprotab        = t_bdcdata
**    EXCEPTIONS
**      internal_error   = 1
**      not_open         = 2
**      queue_error      = 3
**      tcode_invalid    = 4
**      printing_invalid = 5
**      posting_invalid  = 6
**      OTHERS           = 7.
**  IF sy-subrc <> 0.
**    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**  ENDIF.
**
**  CLEAR t_bdcdata[].
**
**ENDFORM.                    "SUB_BDC_INSERT
*&---------------------------------------------------------------------*
*&      Form  BDC_TRANSACTION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0202   text
*----------------------------------------------------------------------*
 FORM bdc_transaction .
   DATA tcode LIKE tstc-tcode.
   tcode = 'FI01'.
   CALL TRANSACTION tcode    USING t_bdcdata
                    MODE mod
                    MESSAGES INTO  messtab.

   PERFORM msg_generation.

 ENDFORM.                    " BDC_TRANSACTION
*&---------------------------------------------------------------------*
*&      Form  MSG_GENERATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
 FORM msg_generation .
   DATA: l_mstring(480).
   DATA: l_subrc LIKE sy-subrc.
   DATA: l_error TYPE c.

   LOOP AT messtab.

     SELECT SINGLE * FROM t100 WHERE sprsl = messtab-msgspra
                               AND   arbgb = messtab-msgid
                               AND   msgnr = messtab-msgnr.
     IF sy-subrc = 0.
       l_mstring = t100-text.
       IF l_mstring CS '&1'.
         REPLACE '&1' WITH messtab-msgv1 INTO l_mstring.
         REPLACE '&2' WITH messtab-msgv2 INTO l_mstring.
         REPLACE '&3' WITH messtab-msgv3 INTO l_mstring.
         REPLACE '&4' WITH messtab-msgv4 INTO l_mstring.
       ELSE.
         REPLACE '&' WITH messtab-msgv1 INTO l_mstring.
         REPLACE '&' WITH messtab-msgv2 INTO l_mstring.
         REPLACE '&' WITH messtab-msgv3 INTO l_mstring.
         REPLACE '&' WITH messtab-msgv4 INTO l_mstring.
       ENDIF.
       CONDENSE l_mstring.
       WRITE: / messtab-msgtyp, l_mstring(250).
     ELSE.
       WRITE: / messtab.
     ENDIF.
   ENDLOOP.
 ENDFORM.                    " MSG_GENERATION
