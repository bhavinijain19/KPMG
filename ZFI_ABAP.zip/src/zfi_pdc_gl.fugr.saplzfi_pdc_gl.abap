*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PDC_GLTOP.                    " Global Declarations
  INCLUDE LZFI_PDC_GLUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PDC_GLF...                    " Subroutines
* INCLUDE LZFI_PDC_GLO...                    " PBO-Modules
* INCLUDE LZFI_PDC_GLI...                    " PAI-Modules
* INCLUDE LZFI_PDC_GLE...                    " Events
* INCLUDE LZFI_PDC_GLP...                    " Local class implement.
* INCLUDE LZFI_PDC_GLT99.                    " ABAP Unit tests
  INCLUDE LZFI_PDC_GLF00                          . " subprograms
  INCLUDE LZFI_PDC_GLI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
