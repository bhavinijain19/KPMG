PROCESS BEFORE OUTPUT.

  MODULE status_0100.

  MODULE screen_edit_0100.
  MODULE tc_reg_change_tc_attr.

  LOOP AT   it_part
       INTO wa_part
       WITH CONTROL tc_reg
       CURSOR tc_reg-current_line.
    MODULE tc_reg_get_lines.

  ENDLOOP.


*
PROCESS AFTER INPUT.
*&SPWIZARD: PAI FLOW LOGIC FOR TABLECONTROL 'TC_REG'
  CHAIN.
    FIELD : w_bukrs, w_kunnr
     MODULE check_validation.
  ENDCHAIN.

  LOOP AT it_part.
    CHAIN.
      FIELD wa_part-bukrs.
      FIELD wa_part-kunnr.
      FIELD wa_part-zsrno.
      FIELD wa_part-zbank.
      FIELD wa_part-zadr1.
      FIELD wa_part-zadr2.
      FIELD wa_part-zadr3.
      FIELD wa_part-city1.
      FIELD wa_part-zstate.
      FIELD wa_part-zpin.
      FIELD wa_part-zpersion.
      FIELD wa_part-zmail.
      FIELD wa_part-zphone.
      FIELD wa_part-zmicr.
      FIELD wa_part-zifsc.
      FIELD wa_part-zpulling_by.
      FIELD wa_part-zfrom_date.
      FIELD wa_part-zto_date.
      FIELD wa_part-zlimit.
      FIELD wa_part-zenhancement.
      FIELD wa_part-zdecrease.
      FIELD wa_part-zchange_dt.
      field wa_part-ZAGR_STATUS.
      field wa_part-ZAGR_DATE.
      field wa_part-ZAGR_EXP_DATE.
      field wa_part-ZAGR_REN_DT.
      field wa_part-ZINTEREST_RATE.
      field wa_part-ZCREDIT_PERIOD.
      field wa_part-ZACC_STATUS.
      field wa_part-ZFEES.
      MODULE tc_reg_modify ON CHAIN-REQUEST.
    ENDCHAIN.
  ENDLOOP.
*  MODULE TC_REG_USER_COMMAND.

  MODULE user_command_0100.
