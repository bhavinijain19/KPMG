*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_GEM_EXTRA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_GEM_EXTRA       .

  PERFORM TABLEPROC.

ENDFUNCTION.
