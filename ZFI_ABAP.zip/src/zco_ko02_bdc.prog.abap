*&---------------------------------------------------------------------*
*& Report  ZCO_KO02_BDC
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zco_ko02_bdc.

TYPES: BEGIN OF ty_ko02,
         order_number  TYPE string,
         description   TYPE string,
         company_code  TYPE string,
         business_area TYPE string,
         plant         TYPE string,
         object_class  TYPE string,
         profit_centre TYPE string,
         resp_cctr     TYPE string,
         resp_user     TYPE string,
       END OF ty_ko02.

DATA: lt_ko02  TYPE TABLE OF ty_ko02,
      ls_ko022 TYPE ty_ko02.

DATA :it_type TYPE truxs_t_text_data.
DATA : file_name TYPE string.

DATA:wa_bdc TYPE bdcdata,
     it_bdc TYPE TABLE OF bdcdata.

DATA:wa_msg TYPE bdcmsgcoll,
     it_msg TYPE TABLE OF bdcmsgcoll.

TYPES :  BEGIN OF t_message   ,
*           lifnr   TYPE char10  , " Customer Number
           status   TYPE char4   , " Light Indicator
           order_no TYPE char15,
           type     TYPE char4   , " Error Type
           message  TYPE char255 , " Message Description
         END OF t_message    .

TYPES : BEGIN OF ty_error,
          sno          TYPE i,
*          efield(200),
          message(100) TYPE c,
        END OF ty_error.

DATA: wa_error    TYPE ty_error,
      it_error    TYPE STANDARD TABLE OF ty_error,

      it_fieldcat TYPE slis_t_fieldcat_alv WITH HEADER LINE.

DATA: i_message   TYPE STANDARD TABLE OF t_message.

DATA:count  TYPE i.
FIELD-SYMBOLS :
  <x_message> TYPE t_message,
  <x_field>   TYPE slis_fieldcat_alv,
  <x_bdcdata> TYPE bdcdata,
  <x_msg>     TYPE bdcmsgcoll.

CONSTANTS:
  c_x    TYPE char1 VALUE 'X',
  c_e    TYPE char1 VALUE 'E',
  c_i    TYPE char1 VALUE 'I',
  c_s    TYPE char1 VALUE 'S',
  c_l    TYPE char1 VALUE 'L',
  c_a    TYPE char1 VALUE 'A',
  c_n    TYPE char1 VALUE 'N',
  c_xls  TYPE char4 VALUE '.XLS',
" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  c_xd01 TYPE char4 VALUE 'XD01',    "#EC CI_USAGE_OK[2226131]
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  c_en   TYPE char2 VALUE 'EN'.

DATA: gv_sno(02),
      gv_fname(60).
DATA: cursor TYPE i.

*&---------------------------------------------- SELECTION SCREEN -------------------------------------------------------------&*
SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
PARAMETERS:p_file TYPE rlgrap-filename OBLIGATORY,
*           p_file1 TYPE rlgrap-filename OBLIGATORY, " Download FileName
           p_mode LIKE ctu_params-dismode DEFAULT 'A'.         " Mode .
SELECTION-SCREEN:END OF BLOCK a1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'WS_FILENAME_GET'
    EXPORTING
      def_filename     = space
      def_path         = space
      mask             = ',*.*,*.*.'
      mode             = space
      title            = space
    IMPORTING
      filename         = p_file
*     RC               =
    EXCEPTIONS
      inv_winsys       = 1
      no_batch         = 2
      selection_cancel = 3
      selection_error  = 4
      OTHERS           = 5.
  IF sy-subrc <> 0 AND sy-subrc <> 3.
    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
  ENDIF.


START-OF-SELECTION.

  PERFORM upload_data.
  PERFORM authorization_check.
  PERFORM bdc_run.
  PERFORM fieldcat.
  PERFORM alv_display.

*&---------------------------------------------------------------------*
*&      Form  UPLOAD_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload_data .

  file_name  = p_file.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = lt_ko02
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  DATA: lv_order TYPE aufnr.

  LOOP AT lt_ko02 INTO DATA(wa_data).
    CLEAR: lv_order.
    lv_order = wa_data-order_number.
    SELECT SINGLE auart FROM coas INTO @DATA(lv_coas)
         WHERE aufnr = @lv_order.

    AUTHORITY-CHECK OBJECT 'ZAUFK_ART'
        ID 'AUFART' FIELD lv_coas
        ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e025(zfi) WITH lv_order.
    ENDIF.
    CLEAR : wa_data.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_RUN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc_run .

  LOOP AT lt_ko02 INTO ls_ko022.

    PERFORM bdc_dynpro      USING 'SAPMKAUF' '0110'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'COAS-AUFNR'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'COAS-AUFNR'
*                              '1890'.
    ls_ko022-order_number.
    PERFORM bdc_dynpro      USING 'SAPMKAUF' '0600'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'COAS-KTEXT'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=SICH'.
    IF ls_ko022-description = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-KTEXT'
*                                    'VIPUL KULSHRESTHA'.
   ls_ko022-description.
    ENDIF.
*perform bdc_field       using 'COAS-KTEXT'
*                              'VIPUL KULSHRESTHA'.
    IF ls_ko022-company_code = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-BUKRS'
*                                    '1000'.
                              ls_ko022-company_code.
    ENDIF.

    IF ls_ko022-business_area = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-GSBER'
                                    ls_ko022-business_area."'0001'.

    ENDIF.

    IF ls_ko022-plant = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-WERKS'
                                    ls_ko022-plant."'1000'.
    ENDIF.
    IF ls_ko022-object_class = 'X'.
    ELSE.
      PERFORM bdc_field       USING 'COAS-SCOPE'
*                              'OCOST'.
                                   ls_ko022-object_class.
    ENDIF.

    IF ls_ko022-profit_centre = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-PRCTR'
                                ls_ko022-profit_centre."'1000010226'.
    ENDIF.

    IF ls_ko022-profit_centre = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-PRCTR'
                                ls_ko022-profit_centre."'1000010226'.
    ENDIF.

    IF ls_ko022-resp_cctr = 'X'.

    ELSE.
      PERFORM bdc_field       USING 'COAS-KOSTV'
                               ls_ko022-resp_cctr."'1030550098'.
    ENDIF.

    IF ls_ko022-resp_user = 'X'.
    ELSE.
      PERFORM bdc_field       USING 'COAS-VERAA_USER'
                               ls_ko022-resp_user."'APLCO01'.
    ENDIF.

*perform bdc_transaction using 'KO02'.
    CALL TRANSACTION 'KO02' USING it_bdc MODE p_mode UPDATE 'S' MESSAGES INTO it_msg.

    IF  it_msg IS NOT INITIAL.
      PERFORM populate_error.
    ENDIF.
    REFRESH it_bdc.
    CLEAR : ls_ko022.
  ENDLOOP.

ENDFORM.

FORM bdc_dynpro USING program screen.

  wa_bdc-program = program.
  wa_bdc-dynpro = screen.
  wa_bdc-dynbegin = 'X'.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
FORM bdc_field USING field value.

  wa_bdc-fnam = field.
  wa_bdc-fval = value.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  POPULATE_ERROR
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM populate_error .

  DATA : lv_msg TYPE string.
  LOOP AT it_msg INTO wa_msg.
    CALL FUNCTION 'FORMAT_MESSAGE'
      EXPORTING
        id   = wa_msg-msgid
        lang = sy-langu
        no   = wa_msg-msgnr
        v1   = wa_msg-msgv1
        v2   = wa_msg-msgv2
        v3   = wa_msg-msgv3
        v4   = wa_msg-msgv4
      IMPORTING
        msg  = lv_msg.

    IF wa_msg-msgtyp = c_s .
*                              AND wa_msg-msgnr = '271' OR wa_msg-msgnr = '175'.
      UNASSIGN <x_message>.
      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
      IF <x_message> IS ASSIGNED.
*        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message>-status       = icon_led_green        .
        <x_message>-order_no = ls_ko022-order_number.
        <x_message>-type         =  wa_msg-msgtyp       .
        <x_message>-message      = lv_msg                .
      ENDIF.
*      ELSEIF wa_msg-msgtyp = c_i  .
*        UNASSIGN <x_message>.
*        APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
*        IF <x_message> IS ASSIGNED.
*          <x_message>-lifnr        = wa_msg-msgv1         .
*          <x_message>-status       = icon_led_yellow        .
*          <x_message>-type         =  wa_msg-msgtyp       .
*          <x_message>-message      = lv_msg                .
*        ENDIF.

*    ELSEIF wa_msg-msgtyp = c_s  AND wa_msg-msgid = '06'.
*      UNASSIGN <x_message>.
*      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
*      IF <x_message> IS ASSIGNED.
**          <x_message>-lifnr        = wa_msg-msgv1         .
*        <x_message>-status       = icon_led_green        .
*        <x_message>-type         =  wa_msg-msgtyp       .
*        <x_message>-message      = lv_msg                .
*      ENDIF.
    ELSEIF wa_msg-msgtyp = c_e.
      UNASSIGN <x_message>.
      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
      IF <x_message> IS ASSIGNED.

*          <x_message>-lifnr        = wa_msg-msgv1                       .
        <x_message>-status       = icon_led_red          .
        <x_message>-order_no = ls_ko022-order_number.
        <x_message>-type         = wa_msg-msgtyp        .
*        IF wa_msg-msgid = 'AM' AND wa_msg-msgnr = '214'
*          OR wa_msg-msgid = 'AM' AND wa_msg-msgnr = '215'.
*          <x_message>-type = c_e.
*        ENDIF.
        <x_message>-message      = lv_msg                .
      ENDIF.
    ENDIF.

    DELETE it_msg WHERE msgnr = wa_msg-msgnr.
*      IF <x_message>-kunnr IS NOT INITIAL.
*        EXIT.
*      ENDIF.
  ENDLOOP.

  IF sy-subrc = 0 .
    count = count + 1.
    wa_error-sno = count.
*    CONCATENATE wa_msg-msgv1 wa_msg-msgv2 wa_msg-msgv3 wa_msg-msgv4 INTO wa_error-efield.
    wa_error-message = lv_msg.
*    wa_error-matnr = wa_msg-msgv1.
*    wa_error-werks = wa_msg-msgv2.
    APPEND wa_error TO it_error.
    CLEAR:wa_error.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fieldcat .

  PERFORM fieldcat_append  USING  'STATUS'               'STATUS'                'X'  'I_MESSAGE'    '5'.
  PERFORM fieldcat_append  USING  'ORDER_NO'               'ORDER NUMBER'                'X'  'I_MESSAGE'    '15'.
*  Order_no
  PERFORM fieldcat_append  USING  'TYPE'               'TYPE'                'X'  'I_MESSAGE'    '5'.
  PERFORM fieldcat_append  USING  'MESSAGE'               'MESSAGE DESCRIPTION'                'X'  'I_MESSAGE'  '60'  .

ENDFORM.

FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table)
                                 VALUE(p_outlen).
  it_fieldcat-fieldname   = p_fname.
  it_fieldcat-seltext_l   = p_ftext.
  it_fieldcat-fix_column  = p_fixcol.
  it_fieldcat-tabname     = p_table.
  it_fieldcat-outputlen   = p_outlen.
  APPEND it_fieldcat.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  ALV_DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_display .

  DATA : lv_repid TYPE sy-repid.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = lv_repid
      it_fieldcat        = it_fieldcat[]
      i_save             = 'A'
    TABLES
      t_outtab           = i_message
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.
