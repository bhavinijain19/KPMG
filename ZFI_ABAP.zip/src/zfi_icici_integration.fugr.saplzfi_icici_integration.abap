*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_ICICI_INTEGRATIONTOP.         " Global Declarations
  INCLUDE LZFI_ICICI_INTEGRATIONUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_ICICI_INTEGRATIONF...         " Subroutines
* INCLUDE LZFI_ICICI_INTEGRATIONO...         " PBO-Modules
* INCLUDE LZFI_ICICI_INTEGRATIONI...         " PAI-Modules
* INCLUDE LZFI_ICICI_INTEGRATIONE...         " Events
* INCLUDE LZFI_ICICI_INTEGRATIONP...         " Local class implement.
* INCLUDE LZFI_ICICI_INTEGRATIONT99.         " ABAP Unit tests
