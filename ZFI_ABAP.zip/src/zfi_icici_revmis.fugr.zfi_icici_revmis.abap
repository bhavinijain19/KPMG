FUNCTION ZFI_ICICI_REVMIS.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IT_ZREVERSE) TYPE  YSTRUCTURE_TT OPTIONAL
*"  EXPORTING
*"     VALUE(STATUS) TYPE  STRING
*"     VALUE(REJECT_REASON) TYPE  STRING
*"--------------------------------------------------------------------


DATA: ls_data LIKE LINE OF it_zreverse.

DATA: it_rundate TYPE TABLE OF zicici_log,
      wa_rundate TYPE zicici_log.

DATA: lt_bkpf TYPE TABLE OF bkpf,
      lt_bseg TYPE TABLE OF bseg,
      wa_bseg TYPE bseg.

*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
LOOP AT it_zreverse INTO ls_data.

*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
  SELECT * INTO TABLE it_rundate
    FROM zicici_log
    WHERE paydocno = ls_data-unique_ref_no.

*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
  LOOP AT it_rundate INTO wa_rundate.

    IF ls_data-pay_prod_code = 'AUTONEFT'
       OR ls_data-pay_prod_code = 'FUNDS_TRF'
       OR ls_data-pay_prod_code = 'DEMO_FT'.

      UPDATE zicici_log
        SET utr_no         = ls_data-unique_ref_no
            status         = ls_data-status
            payment_method = ls_data-pay_prod_code
        WHERE paydocno = ls_data-unique_ref_no
          AND belnr    = wa_rundate-belnr
          AND gjahr    = wa_rundate-gjahr
          AND bukrs    = wa_rundate-bukrs.

    ELSEIF ls_data-pay_prod_code = 'AUTORTGS'.

      UPDATE zicici_log
        SET utr_no         = ls_data-proce_remark
            status         = ls_data-status
            payment_method = ls_data-pay_prod_code
        WHERE paydocno = ls_data-unique_ref_no
          AND belnr    = wa_rundate-belnr
          AND gjahr    = wa_rundate-gjahr
          AND bukrs    = wa_rundate-bukrs.

    ENDIF.

*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
    IF ls_data-status = 'paid'.

      SELECT * INTO TABLE lt_bkpf
        FROM bkpf
        WHERE bukrs = wa_rundate-bukrs
          AND belnr = wa_rundate-belnr
          AND gjahr = wa_rundate-gjahr.

      SELECT * INTO TABLE lt_bseg
        FROM bseg
        WHERE bukrs = wa_rundate-bukrs
          AND belnr = wa_rundate-belnr
          AND gjahr = wa_rundate-gjahr.

      LOOP AT lt_bseg INTO wa_bseg.

        IF ls_data-pay_prod_code = 'AUTORTGS'.
          wa_bseg-xref3 = ls_data-proce_remark.
        ELSE.
          wa_bseg-xref3 = ls_data-unique_ref_no.
        ENDIF.

        MODIFY lt_bseg FROM wa_bseg.

      ENDLOOP.

      CALL FUNCTION 'CHANGE_DOCUMENT'
        TABLES
          t_bkpf = lt_bkpf
          t_bseg = lt_bseg.

      COMMIT WORK.

    ENDIF.

  ENDLOOP.

ENDLOOP.

*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
status = 'paid'.

ENDFUNCTION.
