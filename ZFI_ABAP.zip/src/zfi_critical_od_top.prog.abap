*&---------------------------------------------------------------------*
*&  Include           ZFI_CRITICAL_OD_TOP
*&---------------------------------------------------------------------*
TABLES: bsid,kna1,knvv,knb1.

CONSTANTS : a_name TYPE rvari_vnam VALUE 'Z_AUTH_USER'.

TYPES: BEGIN OF ty_final,
         division      TYPE char50,
         sales_office  TYPE char50,
         tsm_sales_grp TYPE char50,
         kunnr         TYPE kunnr,
         name          TYPE char50,
         cdam1         LIKE bsid-dmbtr,   " SLOT AMT
         cdam2         LIKE bsid-dmbtr,   " SLOT AMT
         cdam3         LIKE bsid-dmbtr,   " SLOT AMT
         cdam4         LIKE bsid-dmbtr,   " SLOT AMT
         cdam5         LIKE bsid-dmbtr,   " SLOT AMT
         cdam6         LIKE bsid-dmbtr,   " SLOT AMT
         cdam7         LIKE bsid-dmbtr,   " SLOT AMT
         cdam8         LIKE bsid-dmbtr,   " SLOT AMT
         netot         LIKE bsid-dmbtr,
         notdue        LIKE bsid-dmbtr,   " notdue amount
         sec_dep       LIKE bsid-dmbtr,
         due4          LIKE bsid-dmbtr,   " notdue amount
         cos_amt       LIKE bsid-dmbtr,
         cod_amt       LIKE bsid-dmbtr,
         zterm         TYPE knvv-zterm,
         text1         TYPE t052u-text1,
         pay_trm_days  TYPE dztage,
         legalcase     TYPE char50,
         od_os_pr      TYPE bsid-dmbtr,
         cod_cos_pr    TYPE bsid-dmbtr,
         group         TYPE zgroup,
         default       TYPE ad_extens1,
       END OF ty_final.

DATA : BEGIN OF it_head OCCURS 0 ,
         ktext(20)  TYPE c,
         spras      LIKE t151t-spras,

         Kvgr1      TYPE kvgr1,
         Kvgr2      TYPE kvgr2,
         bukrs      LIKE bsid-bukrs,   " COMPANY CODE
*         gsber      LIKE bsid-gsber,   " BUSINESS AREA
         busab      LIKE knb1-busab,   " ACCOUNTING CLEARK
         akont      LIKE knb1-akont,   " RECON A/C
         ktokd      LIKE kna1-ktokd,   " A/C GROUP
         txt30      LIKE t001s-sname,  " ACCOUNTING CLEARK TEXT
         kunnr      LIKE kna1-kunnr,   " PARTY CODE
         name1      LIKE kna1-name1,   " NAME
         cdam1      LIKE bsid-dmbtr,   " SLOT AMT
         cdam2      LIKE bsid-dmbtr,   " SLOT AMT
         cdam3      LIKE bsid-dmbtr,   " SLOT AMT
         cdam4      LIKE bsid-dmbtr,   " SLOT AMT
         cdam5      LIKE bsid-dmbtr,   " SLOT AMT
         cdam6      LIKE bsid-dmbtr,   " SLOT AMT
         cdam7      LIKE bsid-dmbtr,   " SLOT AMT
         cdam8      LIKE bsid-dmbtr,   " SLOT AMT
         cdam09     LIKE bsid-dmbtr,   " SLOT AMT   "Added by Ranjan
         cdam10     LIKE bsid-dmbtr,   " SLOT AMT  "Added by Ranjan
         cdam11     LIKE bsid-dmbtr,   " SLOT AMT   "Added by Ranjan
         crbal      LIKE bsid-dmbtr,   " Credit Balance
         total      LIKE bsid-dmbtr,   " TOTAL AMOUNT
         totcd      LIKE bsid-dmbtr,   " TOTAL CR/DR AMOUNT
         cltot      LIKE bsid-dmbtr,   " CLOSING AMOUNT
         saldv      LIKE knc3-saldv,   " Security Amt
         colamt     LIKE bsid-dmbtr,   "Collection Amt
         netot      LIKE bsid-dmbtr,
         netot_dr   LIKE bsid-dmbtr,
         netot_cr   LIKE bsid-dmbtr,
         regio      TYPE kna1-regio,        "Region
         bezei      LIKE t005u-bezei,       "REGION NAME "ADDED ON 22.05.09
         normal     TYPE dmbtr,
         special    TYPE dmbtr,
         credit     TYPE dmbtr,
         vkbur      LIKE knvv-vkbur,
         vktxt      LIKE tvkbt-bezei,
         klimk      TYPE knkk-klimk,
         skfor      TYPE knkk-skfor,
         knkli      TYPE knkk-knkli,
         pname1     TYPE kna1-name1,
***********   Added changes by Carina Jose on 09/07/2021
         zone       TYPE zsd_zone-name,
         szone      TYPE zsd_zone-sname,
         lcategory1 TYPE zsd_custemp_assg-lcategory,
         lname1     TYPE zsd_custemp_assg-lname,
         lcategory2 TYPE zsd_custemp_assg-lcategory,
         lname2     TYPE zsd_custemp_assg-lname,
         lcategory3 TYPE zsd_custemp_assg-lcategory,
         lname3     TYPE zsd_custemp_assg-lname,
         lcategory4 TYPE zsd_custemp_assg-lcategory,
         lname4     TYPE zsd_custemp_assg-lname,
         lcategory5 TYPE zsd_custemp_assg-lcategory,
         lname5     TYPE zsd_custemp_assg-lname,
         lcategory6 TYPE zsd_custemp_assg-lcategory,
         lname6     TYPE zsd_custemp_assg-lname,
***********   End of changes on 09/07/2021
**********************  20.01.2022

***** Anded by BP
         g1         TYPE zde_geo_code,
         pg1        TYPE zde_geo_code,
         g1_d       TYPE zde_geo_desc,
         g2         TYPE zde_geo_code,
         pg2        TYPE zde_geo_code,
         g2_d       TYPE zde_geo_desc,
         g3         TYPE zde_geo_code,
         pg3        TYPE zde_geo_code,
         g3_d       TYPE zde_geo_desc,
         g4         TYPE zde_geo_code,
         pg4        TYPE zde_geo_code,
         g4_d       TYPE zde_geo_desc,
         g5         TYPE zde_geo_code,
         pg5        TYPE zde_geo_code,
         g5_d       TYPE zde_geo_desc,
         g6         TYPE zde_geo_code,
         pg6        TYPE zde_geo_code,
         g6_d       TYPE zde_geo_desc,
         g7         TYPE zde_geo_code,
         pg7        TYPE zde_geo_code,
         g7_d       TYPE zde_geo_desc,
***** Ended by BP

         vkgrp      LIKE knvv-vkgrp,
         bzirk      LIKE knvv-bzirk,
         bztxt      TYPE t171t-bztxt,
         vkgrp_txt  TYPE tvgrt-bezei,
         zterm      TYPE knvv-zterm,
         extension1 TYPE adrc-extension1,
         extension2 TYPE adrc-extension2,
         remark     TYPE adrct-remark,
         text1      TYPE t052u-text1,
         od_amt     TYPE bsid-dmbtr, "Added by Rahul Vasita on 29.08.2024 18:23:29
********************************
**************
       END OF it_head.

DATA : BEGIN OF it_detail OCCURS 0,
         kunnr(10) TYPE c, " LIKE kna1-kunnr,   " PARTY CODE
         bldat     LIKE bsid-bldat,
*         kdgrp     LIKE knvv-kdgrp ,  " Customer Group
         kvgr1     LIKE knvv-kvgr1,
         kvgr2     LIKE knvv-kvgr2,
         bukrs     LIKE bsis-bukrs,   " COMPANY CODE
         belnr     LIKE bsid-belnr,   " DOC NUMBER
         gjahr     LIKE bsid-gjahr,   " FISCAL YEAR
         budat     LIKE bsid-budat,   " POSTING DATE
         blart     LIKE bsid-blart,
*         bldat     LIKE bsid-bldat,
         dmbtr     LIKE bsid-dmbtr,   " AMOUNT
         dmbtr1    LIKE bsid-dmbtr,   " AMOUNT
         dmbtr2    LIKE bsid-dmbtr,   " AMOUNT
         waers     LIKE bsid-waers,   " CURRENCY
         shkzg     LIKE bsid-shkzg,   " CREDIT/DEBIT INDICATOR
         umskz     LIKE bsid-umskz,   " SPECIAL GL INDICATOR
*         gsber     LIKE bsid-gsber,   " BUSINES AREA
         akont     LIKE knb1-akont,   " RECON A/C
         busab     LIKE knb1-busab,   " ACCOUNTING CLEARK
         ktokd     LIKE kna1-ktokd,   " A/C GROUP

         ktext(20) TYPE c,
         spras     LIKE t151t-spras,
         colamt    LIKE bsid-dmbtr,  "Collection Amt
         tcode     LIKE bkpf-tcode,
         vkbur     LIKE knvv-vkbur,
         vktxt     LIKE tvkbt-bezei,
********************************         ADDED 20.01.2022
         vkgrp     LIKE knvv-vkgrp,
         bzirk     LIKE knvv-bzirk,
         bztxt     TYPE t171t-bztxt,
         vkgrp_txt TYPE tvgrt-bezei,
********************************
         zterm     TYPE knvv-zterm,
         text1     TYPE tvzbt-vtext,
         ind(1),
         zuonr     TYPE dzuonr,
       END OF it_detail.

DATA : BEGIN OF it_head_due OCCURS 0,
         ktext(20)      TYPE c,
         spras          LIKE t151t-spras,
         kdgrp          LIKE knvv-kdgrp ,  " Customer Group
         kvgr1          LIKE knvv-kvgr1 ,  " Customer Group 1
         kvgr2          LIKE knvv-kvgr2 ,  " Customer Group 2
         bukrs          LIKE bsid-bukrs,   " COMPANY CODE
*         gsber          LIKE bsid-gsber,   " BUSINESS AREA
         busab          LIKE knb1-busab,   " ACCOUNTING CLEARK
         akont          LIKE knb1-akont,   " RECON A/C
         ktokd          LIKE kna1-ktokd,   " A/C GROUP
         txt30          LIKE t001s-sname,  " ACCOUNTING CLEARK TEXT
         kunnr          LIKE kna1-kunnr,   " PARTY CODE
         name1          LIKE kna1-name1,   " NAME
         cdam1          LIKE bsid-dmbtr,   " SLOT AMT
         cdam2          LIKE bsid-dmbtr,   " SLOT AMT
         cdam3          LIKE bsid-dmbtr,   " SLOT AMT
         cdam4          LIKE bsid-dmbtr,   " SLOT AMT
         cdam5          LIKE bsid-dmbtr,   " SLOT AMT
         cdam6          LIKE bsid-dmbtr,   " SLOT AMT
         cdam7          LIKE bsid-dmbtr,   " SLOT AMT
         cdam8          LIKE bsid-dmbtr,   " SLOT AMT
         crbal          LIKE bsid-dmbtr,   " Credit Balance
         total          LIKE bsid-dmbtr,   " TOTAL AMOUNT
         notdue         LIKE bsid-dmbtr,   " notdue amount
         totcd          LIKE bsid-dmbtr,   " TOTAL CR/DR AMOUNT
         cltot          LIKE bsid-dmbtr,   " CLOSING AMOUNT
         saldv          LIKE knc3-saldv,   " Security Amt
         colamt         LIKE bsid-dmbtr,   "Collection Amt
         netot          LIKE bsid-dmbtr,
         netot_dr       LIKE bsid-dmbtr,
         netot_cr       LIKE bsid-dmbtr,
         regio          TYPE kna1-regio,        "Region
         bezei          LIKE t005u-bezei,       "REGION NAME "ADDED ON 22.05.09
         normal         TYPE dmbtr,
         special        TYPE dmbtr,
         credit         TYPE dmbtr,
         vkbur          LIKE knvv-vkbur,
         vktxt          LIKE tvkbt-bezei,
         klimk          TYPE knkk-klimk,
         skfor          TYPE knkk-skfor,
         knkli          TYPE knkk-knkli,
         pname1         TYPE kna1-name1,
*         invcurr  type bsid-dmbtr,
         dzcurr         TYPE bsid-dmbtr,
*         invpriv  type bsid-dmbtr,
*         dzpriv  type bsid-dmbtr,
***********   Added changes by Carina Jose on 09/07/2021
         zone           TYPE zsd_zone-name,
         szone          TYPE zsd_zone-sname,
         lcategory1     TYPE zsd_custemp_assg-lcategory,
         lname1         TYPE zsd_custemp_assg-lname,
         lcategory2     TYPE zsd_custemp_assg-lcategory,
         lname2         TYPE zsd_custemp_assg-lname,
         lcategory3     TYPE zsd_custemp_assg-lcategory,
         lname3         TYPE zsd_custemp_assg-lname,
         lcategory4     TYPE zsd_custemp_assg-lcategory,
         lname4         TYPE zsd_custemp_assg-lname,
         lcategory5     TYPE zsd_custemp_assg-lcategory,
         lname5         TYPE zsd_custemp_assg-lname,
         lcategory6     TYPE zsd_custemp_assg-lcategory,
         lname6         TYPE zsd_custemp_assg-lname,
         totalod_amount TYPE dmbtr, "Total overdue
*         collec_amount  TYPE dmbtr,  "Collection amount
*         net_odamount   TYPE dmbtr,    "Net Overdue amount
         zterm          LIKE knvv-zterm,
***********   End of changes on 09/07/2021
         due1           LIKE bsid-dmbtr,   " notdue amount
         due2           LIKE bsid-dmbtr,   " notdue amount
         due3           LIKE bsid-dmbtr,   " notdue amount
         due4           LIKE bsid-dmbtr,   " notdue amount
       END OF it_head_due.

TYPES: BEGIN OF ty_manage,
         division      TYPE char50,
         sales_office  TYPE char50,
         tsm_sales_grp TYPE char50,
         kunnr         TYPE kunnr,
         name          TYPE char50,
         cdam1         TYPE char20,   " SLOT AMT
         cdam2         TYPE char20,   " SLOT AMT
         cdam3         TYPE char20,   " SLOT AMT
         cdam4         TYPE char20,   " SLOT AMT
         cdam5         TYPE char20,   " SLOT AMT
         cdam6         TYPE char20,   " SLOT AMT
         cdam7         TYPE char20,   " SLOT AMT
         cdam8         TYPE char20,   " SLOT AMT
         netot         TYPE char20,
         notdue        TYPE char20,   " notdue amount
         sec_dep       TYPE char20,
         due4          TYPE char20,   " notdue amount
         cos_amt       TYPE char20,
         cod_amt       TYPE char20,
         zterm         TYPE knvv-zterm,
         text1         TYPE t052u-text1,
         pay_trm_days  TYPE dztage,
         legalcase     TYPE char50,
         od_os_pr      TYPE char20,
         cod_cos_pr    TYPE char20,
       END OF ty_manage.

TYPES: BEGIN OF ty_sale_head,
         group        TYPE zgroup,
         sales_office TYPE char50,
         netot        LIKE bsid-dmbtr,
         due4         LIKE bsid-dmbtr,   " notdue amount
         cos_amt      LIKE bsid-dmbtr,
         cod_amt      LIKE bsid-dmbtr,
         legalcase    TYPE bsid-dmbtr,
         od_os_pr     TYPE bsid-dmbtr,
         cod_cos_pr   TYPE bsid-dmbtr,
       END OF ty_sale_head.

DATA: it_manage TYPE TABLE OF ty_manage,
      wa_manage TYPE ty_manage.

DATA: lv_od_os_pr   TYPE i,
      lv_cod_cos_pr TYPE i.

DATA:it_sale_head   TYPE TABLE OF ty_sale_head,
     wa_sale_head   TYPE ty_sale_head,
     wa_sale_head_t TYPE ty_sale_head.

DATA: g_variant  TYPE disvariant,
      gx_variant TYPE disvariant,
      g_save     TYPE c VALUE 'X',
      g_exit     TYPE c.

DATA: lt_mis_kdgrp TYPE TABLE OF zfi_mis_kdgrp,
      ls_mis_kdgrp TYPE zfi_mis_kdgrp.
*      lt_co_mnt    TYPE TABLE OF zfi_co_mnt,
*      ls_co_mnt    TYPE zfi_co_mnt.

DATA: it_fcat TYPE slis_t_fieldcat_alv,
      wa_fcat TYPE slis_fieldcat_alv.

DATA: it_final TYPE TABLE OF ty_final,
      wa_final TYPE ty_final.

DATA : BEGIN OF it_slabs OCCURS 8,
         slab(1) TYPE n,
*         days(3) TYPE n,
         days(4) TYPE n,
       END OF it_slabs.

DATA: lv_tot_netot      TYPE bsid-dmbtr,
      lv_tot_due4       TYPE bsid-dmbtr,
      lv_tot_cos_amt    TYPE bsid-dmbtr,
      lv_tot_cod_amt    TYPE bsid-dmbtr,
      lv_tot_legalcase  TYPE bsid-dmbtr,
      lv_tot_od_os_pr   TYPE bsid-dmbtr,
      lv_tot_cod_cos_pr TYPE bsid-dmbtr.

DATA: lv_cdam1      TYPE char20,
      lv_cdam2      TYPE char20,
      lv_cdam3      TYPE char20,
      lv_cdam4      TYPE char20,
      lv_cdam5      TYPE char20,
      lv_cdam6      TYPE char20,
      lv_cdam7      TYPE char20,
      lv_cdam8      TYPE char20,
      lv_nettot     TYPE char20,
      lv_notdue     TYPE char20,
      lv_due4       TYPE char20,
      lv_sec_dep    TYPE char20,
      lv_cos        TYPE char20,
      lv_cod        TYPE char20,
      lv_paytrmdays TYPE char3,
      lv_odospr     TYPE char20,
      lv_codospr    TYPE char20.

TYPES: BEGIN OF ty_tvarv,
         sign TYPE tvarv_sign,
         opti TYPE tvarv_opti,
         low  TYPE tvarv_val,
         high TYPE tvarv_val,
       END OF ty_tvarv.

DATA: it_user TYPE STANDARD TABLE OF ty_tvarv,
      wa_user TYPE ty_tvarv.
