*&---------------------------------------------------------------------*
*&  Include           SAPMZFI_BANK_RECO_MANUAL_I01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  M_EXIT  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE m_exit INPUT.
  IF sy-ucomm EQ 'EXIT'.
    LEAVE PROGRAM.
  ENDIF.
ENDMODULE.                 " M_EXIT  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.
  gv_ucomm = sy-ucomm.
  CLEAR sy-ucomm.
  CASE gv_ucomm.
    WHEN 'BACK' OR 'CANCEL' OR 'EXIT'.
      IF gv_flag IS INITIAL.
        PERFORM f_clear.
        gv_flag = 'X'.
*        CLEAR: zgate_header,gv_zztrtyp,wa,gv_get.
        REFRESH : gt_final[],gt_table[].
        LEAVE TO SCREEN 9000.
      ELSE.
        PERFORM f_clear.
        CLEAR gv_flag.
        LEAVE PROGRAM.
      ENDIF.
    WHEN 'EXIT'.
      CLEAR: gv_ucomm,sy-ucomm.
      LEAVE PROGRAM.
*      LEAVE TO SCREEN 9000.
    WHEN 'FF67'.
      PERFORM f_check_amount.
      CHECK gv_amt IS INITIAL.
      PERFORM f_bdc_data_ff67.
    WHEN 'FB02'.
      PERFORM f_change_fb02.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*&      Module  M_GET_INV  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE m_get_inv INPUT.
*  IF gv_aznum IS INITIAL.
  SELECT SINGLE
         bukrs
         hbkid
         hkont
    FROM t012k
     INTO wa_t012k
       WHERE bukrs = gv_bukrs
         AND hbkid = gv_hbkid
         AND hktid = gv_hktid.
  IF sy-subrc EQ 0.
    gv_hkont = wa_t012k-hkont.
    gv_hkont1 = wa_t012k-hkont + 1.
    PERFORM f_conversion_alpha CHANGING gv_hkont1.
    gv_hkont2 = wa_t012k-hkont + 2.
    PERFORM f_conversion_alpha CHANGING gv_hkont2.
    SELECT  aznum
            esvoz
            esbtr
         FROM febko
          INTO TABLE gt_febko
            WHERE hkont = gv_hkont.
    IF sy-subrc EQ 0.
      SORT gt_febko BY aznum DESCENDING.
      READ TABLE gt_febko INTO wa_febko INDEX 1.
      CLEAR gv_aznum.
      gv_aznum = wa_febko-aznum + 1.
      gv_ssald = wa_febko-esbtr.
      IF wa_febko-esvoz EQ 'S'.
        gv_ssald = wa_febko-esbtr * -1.
      ENDIF.
    ENDIF.
  ELSE.
    MESSAGE e003(zfi) WITH gv_hbkid gv_hktid.
  ENDIF.
  IF gv_aznum IS INITIAL.
    MESSAGE e001(zfi).
  ENDIF.
*  ENDIF.
ENDMODULE.                 " M_GET_INV  INPUT
*&---------------------------------------------------------------------*
*&      Module  M_CHECK  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE m_check INPUT.
  IF gv_ssald IS INITIAL .
    MESSAGE w004(zfi).
  ENDIF.
ENDMODULE.                 " M_CHECK  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8001 INPUT.
  IF gv_get IS INITIAL.
    r_hkont-sign = 'I'.
    r_hkont-option = 'EQ'.
    r_hkont-low = gv_hkont1.
    APPEND r_hkont.
    r_hkont-low = gv_hkont2.
    APPEND r_hkont.
    SELECT bukrs
           hkont
           zuonr
           gjahr
           belnr
           budat
           bldat
           blart
           dmbtr
           wrbtr
           valut
           kidno              "Added By Raj on 15-May-2023
       FROM bsis
      INTO   TABLE gt_bsis
        WHERE bukrs = gv_bukrs
          AND hkont IN r_hkont
    AND budat <= gv_azdat.
    IF sy-subrc EQ 0.
      LOOP AT gt_bsis INTO wa_bsis.
        wa_final-bukrs = wa_bsis-bukrs.
        wa_final-hkont = wa_bsis-hkont.
        wa_final-gjahr = wa_bsis-gjahr.
        wa_final-belnr = wa_bsis-belnr.
        wa_final-blart = wa_bsis-blart.
        wa_final-bldat = wa_bsis-bldat.
        wa_final-budat = wa_bsis-budat.
        wa_final-valut = wa_bsis-valut.
        wa_final-dmbtr = wa_bsis-dmbtr.
        wa_final-kidno = wa_bsis-kidno.            "Added By Raj on 15-May-2023
        IF wa_bsis-hkont+9(1) EQ 1 .
          wa_final-vgman = 'ZINC'.
        ELSEIF wa_bsis-hkont+9(1) EQ 2.
          wa_final-vgman = 'ZOUT'.
          wa_final-dmbtr = wa_final-dmbtr * -1.
        ENDIF.
        APPEND wa_final TO gt_final.
        CLEAR:wa_final.
      ENDLOOP.

      IF gt_final IS NOT INITIAL.


* Quick Fix Replace SELECT from table BSEG by API Call
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT bukrs belnr gjahr koart zuonr hkont kunnr lifnr FROM bseg INTO TABLE it_bseg
*                                                               FOR ALL ENTRIES IN gt_final
*                                                               WHERE bukrs = gt_final-bukrs
*                                                                 AND belnr = gt_final-belnr
*                                                                 and gjahr = gt_final-gjahr
*                                                                 AND hkont <> gt_final-hkont.


        SELECT
              companycode          AS bukrs,
              accountingdocument   AS belnr,
              fiscalyear           AS gjahr,
              financialaccounttype AS koart,
              assignmentreference  AS zuonr,
              glaccount            AS hkont,
              customer             AS kunnr,
              supplier             AS lifnr
            FROM i_operationalacctgdocitem
            INTO TABLE @it_bseg
            FOR ALL ENTRIES IN @gt_final
            WHERE companycode        = @gt_final-bukrs
              AND accountingdocument = @gt_final-belnr
              AND fiscalyear         = @gt_final-gjahr
             AND glaccount          <> @gt_final-hkont.

* End of Quick Fix



* Quick Fix Replace SELECT from table BSEG by API Call
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT bukrs belnr gjahr koart zuonr hkont kunnr lifnr FROM bseg INTO TABLE it_bseg1
*                                                               FOR ALL ENTRIES IN gt_final
*                                                               WHERE bukrs = gt_final-bukrs
*                                                                 AND belnr = gt_final-belnr
*                                                                 and gjahr = gt_final-gjahr
*                                                                 AND hkont = gt_final-hkont
*                                                                 AND hkont NE ' '.

        SELECT
              companycode          AS bukrs,
              accountingdocument   AS belnr,
              fiscalyear           AS gjahr,
              financialaccounttype AS koart,
              assignmentreference  AS zuonr,
              glaccount            AS hkont,
              customer             AS kunnr,
              supplier             AS lifnr
            FROM i_operationalacctgdocitem
            INTO TABLE @it_bseg1
            FOR ALL ENTRIES IN @gt_final
            WHERE companycode        = @gt_final-bukrs
              AND accountingdocument = @gt_final-belnr
              AND fiscalyear         = @gt_final-gjahr
              AND glaccount          = @gt_final-hkont
              AND glaccount          <> ''.



* End of Quick Fix


      ENDIF.

      IF it_bseg IS NOT INITIAL.

        SELECT kunnr name1 name2 FROM kna1 INTO TABLE it_kna1 FOR ALL ENTRIES IN it_bseg WHERE kunnr = it_bseg-kunnr.

        SELECT lifnr name1 name2 FROM lfa1 INTO TABLE it_lfa1 FOR ALL ENTRIES IN it_bseg WHERE lifnr = it_bseg-lifnr.

        SELECT saknr txt50       FROM skat INTO TABLE it_skat FOR ALL ENTRIES IN it_bseg WHERE saknr = it_bseg-hkont.

      ENDIF.

      LOOP AT gt_final INTO wa_final.

        READ TABLE it_bseg INTO wa_bseg WITH KEY bukrs = wa_final-bukrs
                                                 belnr = wa_final-belnr.
        IF sy-subrc EQ 0.
          wa_final-zuonr = wa_bseg-zuonr.

          IF wa_final-zuonr IS INITIAL.
            READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY bukrs = wa_final-bukrs
                                                       belnr = wa_final-belnr.
            IF sy-subrc EQ 0.
              wa_final-zuonr = wa_bseg-zuonr.
            ENDIF.
          ENDIF.
          IF wa_bseg-koart EQ 'S'.
            READ TABLE it_skat INTO wa_skat WITH KEY saknr = wa_bseg-hkont.
            IF sy-subrc EQ 0.
              wa_final-name = wa_skat-txt50.
              CLEAR:wa_skat.
            ENDIF.
          ELSEIF wa_bseg-koart EQ 'D'.
            READ TABLE it_kna1 INTO wa_kna1 WITH KEY kunnr = wa_bseg-kunnr.
            IF sy-subrc EQ 0.
              CONCATENATE wa_kna1-name1 wa_kna1-name2 INTO wa_final-name.
              CLEAR:wa_kna1.
            ENDIF.
          ELSEIF wa_bseg-koart EQ 'K'.
            READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_bseg-lifnr.
            IF sy-subrc EQ 0.
              CONCATENATE wa_lfa1-name1 wa_lfa1-name2 INTO wa_final-name.
              CLEAR:wa_lfa1.
            ENDIF.
          ENDIF.

          MODIFY gt_final FROM wa_final TRANSPORTING zuonr name.
          CLEAR:wa_final.

        ENDIF.
      ENDLOOP.
      gv_get = 'X'.
      SORT gt_final BY bukrs vgman hkont gjahr belnr.
      LOOP AT gt_final ASSIGNING <fs_final>.
        gv_dmbtr = gv_dmbtr + <fs_final>-dmbtr.
        AT END OF belnr.
          wa_final = <fs_final>.
          wa_final-dmbtr = gv_dmbtr.
          APPEND wa_final TO gt_table.                "Added By Raj on 15-May-2023
          CLEAR :wa_final,gv_dmbtr.
        ENDAT.
      ENDLOOP.

      LOOP AT gt_table INTO wa_table.

        READ TABLE gt_final INTO wa_final WITH KEY bukrs = wa_table-bukrs
                                                   belnr = wa_table-belnr.

        IF sy-subrc EQ 0.
          wa_table-zuonr = wa_final-zuonr.
          wa_table-name  = wa_final-name.
          wa_table-kidno = wa_final-kidno.
          CLEAR:wa_final.
        ENDIF.
        MODIFY gt_table FROM wa_table TRANSPORTING zuonr name kidno.

      ENDLOOP.
*      gt_table[] = gt_final[].
    ELSE.
      MESSAGE e002(zfi).
    ENDIF.
  ENDIF.

ENDMODULE.                 " USER_COMMAND_8001  INPUT

*&SPWIZARD: INPUT MODULE FOR TC 'T_TABL_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: MODIFY TABLE
MODULE t_tabl_ctrl_modify INPUT.
  MODIFY gt_table
    FROM wa_table
    INDEX t_tabl_ctrl-current_line.
ENDMODULE.

*&SPWIZARD: INPUT MODUL FOR TC 'T_TABL_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: MARK TABLE
MODULE t_tabl_ctrl_mark INPUT.
  DATA: g_t_tabl_ctrl_wa2 LIKE LINE OF gt_table.
  IF t_tabl_ctrl-line_sel_mode = 1
  AND wa_table-mark = 'X'.
    LOOP AT gt_table INTO g_t_tabl_ctrl_wa2
      WHERE mark = 'X'.
      g_t_tabl_ctrl_wa2-mark = ''.
      MODIFY gt_table
        FROM g_t_tabl_ctrl_wa2
        TRANSPORTING mark.
    ENDLOOP.
  ENDIF.
  MODIFY gt_table
    FROM wa_table
    INDEX t_tabl_ctrl-current_line
    TRANSPORTING mark.
ENDMODULE.

*&SPWIZARD: INPUT MODULE FOR TC 'T_TABL_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: PROCESS USER COMMAND
MODULE t_tabl_ctrl_user_command INPUT.
  ok_code = sy-ucomm.
  PERFORM user_ok_tc USING    'T_TABL_CTRL'
                              'GT_TABLE'
                              'MARK'
                     CHANGING ok_code.
  sy-ucomm = ok_code.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  INSERT  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE insert INPUT.
  READ TABLE gt_table INDEX t_tabl_ctrl-current_line TRANSPORTING NO FIELDS.
  IF sy-subrc <> 0.
    INSERT INITIAL LINE INTO gt_table INDEX t_tabl_ctrl-current_line.
  ENDIF.
ENDMODULE.                 " INSERT  INPUT
*&---------------------------------------------------------------------*
*&      Module  M_ESALD  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE m_esald INPUT.
  IF gv_esald IS INITIAL.
    MESSAGE w004(zfi).
  ENDIF.
ENDMODULE.                 " M_ESALD  INPUT
