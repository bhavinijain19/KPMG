FUNCTION-POOL ZTMM_SE_WF_AGENT           MESSAGE-ID SV.

* INCLUDE LZTMM_SE_WF_AGENTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTMM_SE_WF_AGENTT00                    . "view rel. data dcl.
