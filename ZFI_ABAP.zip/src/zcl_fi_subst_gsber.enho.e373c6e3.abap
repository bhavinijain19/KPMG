"Name: \FU:FI_SUBST_GSBER\SE:END\EI
ENHANCEMENT 0 ZCL_FI_SUBST_GSBER.
*data:lt_isd_split type TABLE OF zfi_isd_split,
*     ls_isd_split type  zfi_isd_split .
* SELECT  *
*        FROM zfi_isd_split
*        INTO TABLE lt_isd_split .
*   LOOP AT t_accit.
*
* READ TABLE lt_isd_split INTO ls_isd_split WITH KEY bupla = t_accit-bupla.
*
*
*       t_accit-gsber =  ls_isd_split-gsber.
*       t_accit-prctr =  ls_isd_split-prctr.
*        MODIFY t_accit.
*     ENDLOOP.
ENDENHANCEMENT.
