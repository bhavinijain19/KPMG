*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PIPES_SOFFTOP.                " Global Declarations
  INCLUDE LZFI_PIPES_SOFFUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PIPES_SOFFF...                " Subroutines
* INCLUDE LZFI_PIPES_SOFFO...                " PBO-Modules
* INCLUDE LZFI_PIPES_SOFFI...                " PAI-Modules
* INCLUDE LZFI_PIPES_SOFFE...                " Events
* INCLUDE LZFI_PIPES_SOFFP...                " Local class implement.
* INCLUDE LZFI_PIPES_SOFFT99.                " ABAP Unit tests
  INCLUDE LZFI_PIPES_SOFFF00                      . " subprograms
  INCLUDE LZFI_PIPES_SOFFI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
