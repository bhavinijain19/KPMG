*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_OD_KDGRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_OD_KDGRP        .

  PERFORM TABLEPROC.

ENDFUNCTION.
