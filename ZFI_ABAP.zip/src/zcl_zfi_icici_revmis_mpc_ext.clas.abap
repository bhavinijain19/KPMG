class ZCL_ZFI_ICICI_REVMIS_MPC_EXT definition
  public
  inheriting from ZCL_ZFI_ICICI_REVMIS_MPC
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_ICICI_REVMIS_MPC_EXT IMPLEMENTATION.
ENDCLASS.
