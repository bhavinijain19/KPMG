*&---------------------------------------------------------------------*
*& Report  ZFI_ASSET_REGISTER1
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Module Pool      : ZFI_ASSET_REGISTER1_NEW                      ---*
*&--Package          : ZFI_ABAP                                     ---*
*&--Description      : WBS Reg. Optimized Report                    ---*
*&--Transaction Code : ZFI_BMR_CHECKLIST                            ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP )                      ---*
*&--Functional Owner : BRIJESH SHAH / MAHESH KOKULU                 ---*
*&--TR No 1          : DEVK940108                                   ---*
*&--TR No 2          : DEVK942820                                   ---*
*&---------------------------------------------------------------------*
REPORT zfi_asset_register1_new.
TYPE-POOLS:slis.

TABLES: anla,     "Main Asset Table with Description
        mseg.
DATA : lv_blart TYPE bkpf-blart. "Added by Rahul Vasita on 15.04.2024 17:46:27
SELECTION-SCREEN:BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-000.

  SELECT-OPTIONS:s_bukrs FOR anla-bukrs OBLIGATORY NO INTERVALS NO-EXTENSION. " updated by Carina Jose on 30.07.2020.
  SELECT-OPTIONS:s_anln1 FOR anla-anln1 OBLIGATORY," OBLIGATORY,
                 s_budat FOR mseg-budat_mkpf,
                 s_blart FOR lv_blart. "Added by Rahul Vasita on 15.04.2024 17:46:51


SELECTION-SCREEN:END OF BLOCK b1.

INCLUDE zinc_asset_register1_new.
*INCLUDE zinc_asset_register1.
*****" Added for auth. at company level by Carina Jose on 30.07.2020
TYPES: BEGIN OF ty_t001,
         bukrs TYPE bukrs,
       END OF ty_t001.
DATA : gt_t001 TYPE STANDARD TABLE OF ty_t001,
       wa_t001 TYPE ty_t001.


DATA:wa_bset2 TYPE bset,
     it_bset2 TYPE STANDARD TABLE OF  bset. "

*****" Added for auth. at company level by Carina Jose on 30.07.2020
START-OF-SELECTION.

*********Begin of changes Added By Raj on 14.09.2023********
  SELECT   sign
            opti
            low
            high INTO TABLE lt_acc_wbs
                 FROM tvarvc
                 WHERE name = c_var_name.


********End of changes by Raj on 14.09.2023***********

*  PERFORM authorization_check . " Added for Auth. check by Carina Jose on 30.07.2020
  PERFORM get_data.
  PERFORM combine.
  IF it_final1 IS NOT  INITIAL.
    PERFORM fillcat.
    PERFORM display.
  ELSE.
    MESSAGE 'No data found.' TYPE 'S' DISPLAY LIKE 'E'.
  ENDIF.


*&---------------------------------------------------------------------*
*&      Form  GET_DATA

*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

************************************************************************
* Fetching Asset Details                                               *
************************************************************************
*  break sap_abap.

*  SELECT bukrs
*         anln1
*         anln2
*         anlkl
*         anlar
*         zugdt
*         txt50
*         txa50
*         aktiv FROM anla INTO TABLE it_anla WHERE bukrs IN s_bukrs
*                                              AND anln1 IN s_anln1.
*
  "Comment Start by Rahul Vasita on 13.03.2024 11:00:51
**  SELECT * FROM anla INTO TABLE it_anla WHERE bukrs IN s_bukrs
**                                              AND anln1 IN s_anln1.
  "Comment End by Rahul Vasita on 13.03.2024 11:00:51

  "Adding Start by Rahul Vasita on 13.03.2024 11:01:03
  SELECT bukrs
         anln1
         anln2
         txt50
         posnr
    FROM anla
    INTO CORRESPONDING FIELDS OF TABLE it_anla
    WHERE bukrs IN s_bukrs
      AND anln1 IN s_anln1.
  "Adding End by Rahul Vasita on 13.03.2024 11:01:03


  SORT it_anla BY anln1.

  IF it_anla[] IS NOT INITIAL.

    "Comment Start by Rahul Vasita on 13.03.2024 10:43:22
**    SELECT * FROM anlb INTO TABLE it_anlb FOR ALL ENTRIES IN it_anla WHERE bukrs = it_anla-bukrs
**                                                                       AND anln1 = it_anla-anln1.
**
**    SELECT * FROM anlc INTO TABLE it_anlc FOR ALL ENTRIES IN it_anla WHERE bukrs = it_anla-bukrs
**                                                                       AND anln1 = it_anla-anln1.
**
**    SELECT * FROM ankt INTO TABLE it_ankt FOR ALL ENTRIES IN it_anla WHERE anlkl = it_anla-anlkl
**                                                                       AND spras EQ 'EN'.
    "Comment End by Rahul Vasita on 13.03.2024 10:43:22

    "Comment Start by Rahul Vasita on 13.03.2024 10:44:44
***    SELECT * FROM anep INTO TABLE it_anep FOR ALL ENTRIES IN it_anla WHERE anln1 = it_anla-anln1
***                                                                       AND bukrs = it_anla-bukrs
***                                                                       AND bwasl EQ '345'.
***
*******************Begin of changes Added by Raj on 14.09.2023**********************************
***    SELECT * FROM anep INTO TABLE it_wbs FOR ALL ENTRIES IN it_anla WHERE anln1 = it_anla-anln1
***                                                                         AND bukrs = it_anla-bukrs
***                                                                         AND bwasl IN lt_acc_wbs.
***
********************End of changes Added by Raj on 14.09.2023*************************************
    "Comment End by Rahul Vasita on 13.03.2024 10:44:44

    SELECT bukrs
           anln1
           anln2
           gjahr
           lnran
           afabe
           zujhr
           zucod
           bwasl
           anbtr
       FROM anep
       INTO CORRESPONDING FIELDS OF TABLE it_anep
       FOR ALL ENTRIES IN it_anla
       WHERE bukrs = it_anla-bukrs
         AND anln1 = it_anla-anln1
         AND bwasl IN lt_acc_wbs.
    SORT it_anep BY bukrs anln1 gjahr.
**********************Added by Rutvi on 16.09.2024
    SELECT anln1
           anln2
           gjahr
           lnran
           afabe
           belnr
           bwasl FROM anep INTO TABLE it_anep_t WHERE anln1 IN s_anln1
                                                  AND afabe = '01'.
    SORT it_anep_t BY anln1 anln2 gjahr lnran.
************************************************************************
    "Comment Start by Rahul Vasita on 13.03.2024 10:50:53
*    SELECT * FROM anek INTO TABLE it_anek FOR ALL ENTRIES IN it_anla WHERE anln1 = it_anla-anln1
*                                                                         AND bukrs = it_anla-bukrs.
    "Comment End by Rahul Vasita on 13.03.2024 10:50:53
    "Adding Start by Rahul Vasita on 13.03.2024 10:51:02
    SELECT bukrs
           anln1
           anln2
           gjahr
           lnran
           ebeln
           ebelp
           belnr
           buzei
           awtyp
           aworg
      FROM anek
      INTO CORRESPONDING FIELDS OF TABLE it_anek
      FOR ALL ENTRIES IN it_anla
      WHERE bukrs = it_anla-bukrs
        AND anln1 = it_anla-anln1.
    SORT it_anek BY bukrs anln1 gjahr belnr buzei.
    "Adding End by Rahul Vasita on 13.03.2024 10:51:02
  ENDIF.

************************************************************************
* Fetching Purchase Order Details                                      *
************************************************************************

  IF it_anla[] IS NOT INITIAL.
    SORT it_anla ASCENDING BY bukrs anln1.
    "Comment Start by Rahul Vasita on 13.03.2024 10:55:16
*    SELECT * FROM ekkn INTO TABLE it_ekkn FOR ALL ENTRIES IN it_anla WHERE anln1 = it_anla-anln1.
    "Comment End by Rahul Vasita on 13.03.2024 10:55:16

    "Adding Start by Rahul Vasita on 13.03.2024 10:55:23
    SELECT ebeln
           ebelp
           zekkn
           anln1
           ps_psp_pnr
      FROM ekkn
      INTO CORRESPONDING FIELDS OF TABLE it_ekkn
      FOR ALL ENTRIES IN it_anla
      WHERE anln1 = it_anla-anln1.
    SORT it_ekkn BY ebeln ebelp anln1.
    "Adding End by Rahul Vasita on 13.03.2024 10:55:23

    LOOP AT it_anla INTO wa_anla.
      IF wa_anla-posnr IS NOT INITIAL.
        "Comment Start by Rahul Vasita on 13.03.2024 10:58:39
***          SELECT * FROM ekkn  APPENDING CORRESPONDING FIELDS OF TABLE it_ekkn FOR ALL ENTRIES IN it_anla WHERE ps_psp_pnr = wa_anla-posnr.
**        SELECT * FROM ekkn  APPENDING CORRESPONDING FIELDS OF TABLE it_ekkn  WHERE ps_psp_pnr = wa_anla-posnr.
        "Comment End by Rahul Vasita on 13.03.2024 10:58:39
        "Adding Start by Rahul Vasita on 13.03.2024 10:59:03
        SELECT ebeln
               ebelp
               zekkn
               anln1
               ps_psp_pnr
          FROM ekkn
          APPENDING CORRESPONDING FIELDS OF TABLE it_ekkn
          WHERE ps_psp_pnr = wa_anla-posnr.
        "Adding End by Rahul Vasita on 13.03.2024 10:59:03
      ENDIF.
      CLEAR : wa_anla.
    ENDLOOP.


  ENDIF.

  IF it_ekkn IS NOT INITIAL.
    "Comment Start by Rahul Vasita on 13.03.2024 18:40:33
***    SELECT ebeln
***            ebelp
***            txz01
***            matnr
***            bukrs
***            werks
***            meins
***            netpr
***            netwr
***       FROM ekpo
***       INTO CORRESPONDING FIELDS OF TABLE it_ekpo
***       FOR ALL ENTRIES IN it_ekkn
***       WHERE ebeln = it_ekkn-ebeln
***         AND ebelp = it_ekkn-ebelp
***         AND bukrs IN s_bukrs.
    "Comment End by Rahul Vasita on 13.03.2024 18:40:33
    SELECT pspnr
           objnr
           kokrs
           belnr
           buzei
           wrttp
           refbn
           refbk
           refgj
           awtyp
      FROM zfi_covp
      INTO CORRESPONDING FIELDS OF TABLE it_covp
      FOR ALL ENTRIES IN it_ekkn
      WHERE pspnr = it_ekkn-ps_psp_pnr
        AND wrttp = '04'
        AND awtyp = 'BKPF'.


    SORT it_covp ASCENDING BY refbn refbk refgj. "Added by Rahul Vasita on 13.03.2024 17:35:28

    SELECT mandt
           ebeln
           ebelp
           bukrs
           bstyp
           bsart
           lifnr
           wkurs
           bedat
           txz01
           matnr
           werks
           meins
           netpr
           netwr
           spras
           maktx
           name1
           name2
      FROM zfi_po_details
      INTO CORRESPONDING FIELDS OF TABLE lt_po
      FOR ALL ENTRIES IN it_ekkn
      WHERE ebeln = it_ekkn-ebeln
        AND ebelp = it_ekkn-ebelp.
**        AND spras = sy-langu. "Comment by Rahul Vasita on 15.03.2024 10:36:17
    IF lt_po[] IS NOT INITIAL.
      DELETE lt_po WHERE bukrs NOT IN s_bukrs.
    ENDIF.
  ENDIF.

  SORT lt_po ASCENDING BY ebeln ebelp .


  IF lt_po IS NOT INITIAL.
*    SELECT * FROM ekko INTO TABLE it_ekko FOR ALL ENTRIES IN it_ekpo WHERE ebeln = it_ekpo-ebeln. "Comment by Rahul Vasita on 13.03.2024 18:40:50
    SELECT trntyp
           docyr
           docno
           zeile
           exbas
           exbed
           rdoc1
           rdoc2
           ritem1
 FROM j_1iexcdtl INTO CORRESPONDING FIELDS OF TABLE it_excise FOR ALL ENTRIES IN lt_po WHERE rdoc1 = lt_po-ebeln.

    SORT it_excise ASCENDING BY rdoc1 rdoc2 ritem1.
**    SELECT * FROM makt INTO TABLE it_makt FOR ALL ENTRIES IN it_ekpo WHERE matnr = it_ekpo-matnr
**                                                                       AND spras EQ 'EN'.
  ENDIF.
**  SELECT lifnr name1 name2 FROM lfa1 INTO TABLE it_lfa1. "Comment by Rahul Vasita on 13.03.2024 18:40:19
**  SORT it_ekkn BY ebeln ebelp. "Comment by Rahul Vasita on 13.03.2024 18:41:17
**  SORT it_ekpo BY ebeln ebelp. "Comment by Rahul Vasita on 13.03.2024 18:41:32

  IF it_ekkn IS NOT INITIAL.

    SORT it_ekkn ASCENDING BY ebeln ebelp.

    SELECT ebeln
          ebelp
          zekkn
          vgabe
          gjahr
          belnr
          buzei
          budat
          menge
          dmbtr
          waers
          shkzg
          xblnr
          lfgja
          lfbnr
          lfpos
          refwr
          introw
      FROM ekbe INTO CORRESPONDING FIELDS OF TABLE it_ekbe
      FOR ALL ENTRIES IN it_ekkn
      WHERE ebeln = it_ekkn-ebeln
        AND ebelp = it_ekkn-ebelp
        AND vgabe EQ '1'
        AND budat IN s_budat.
*                                                                       AND lfbnr EQ ' '

    SELECT ebeln
           ebelp
           zekkn
           vgabe
           gjahr
           belnr
           buzei
           budat
           menge
           dmbtr
           waers
           shkzg
           xblnr
           lfgja
           lfbnr
           lfpos
           refwr
           introw
 FROM ekbe INTO CORRESPONDING FIELDS OF TABLE it_ekbe1
 FOR ALL ENTRIES IN it_ekkn
 WHERE ebeln = it_ekkn-ebeln
  AND ebelp = it_ekkn-ebelp
  AND vgabe EQ '2'
  AND budat IN s_budat.
*                                                                        AND lfbnr EQ ' '.
*****  Added by Carina Jose on 03.10.2019
    "Comment Start by Rahul Vasita on 13.03.2024 18:43:22
***      SELECT * FROM ekbe INTO TABLE it_ekbe2 FOR ALL ENTRIES IN it_ekkn WHERE ebeln = it_ekkn-ebeln
***                                                                        AND ebelp = it_ekkn-ebelp
***                                                                        AND vgabe EQ '3'
***                                                                        AND budat IN s_budat.
    "Comment End by Rahul Vasita on 13.03.2024 18:43:22
*    SELECT ebeln ebelp vgabe belnr buzei
    SELECT ebeln
           ebelp
           stunr
           zaehk
           vgabe
           gjahr
           belnr
           buzei
     FROM ekbz INTO CORRESPONDING FIELDS OF TABLE it_ekbz1
     FOR ALL ENTRIES IN it_ekkn
     WHERE ebeln = it_ekkn-ebeln
       AND ebelp = it_ekkn-ebelp
*       AND vgabe EQ '2' . "Comment by Rahul Vasita on 18.03.2024 14:12:09
       AND vgabe IN ( '2' , '3' ).
***       AND bewtp IN ( 'M' ) . "Added by Rahul Vasita on 18.03.2024 14:12:10 "Comment by Rahul Vasita on 20.08.2024 16:57:59
*    SELECT ebeln ebelp vgabe belnr dmbtr wrbtr waers belnr budat buzei gjahr lfgja lfbnr lfpos  menge  shkzg
    SELECT ebeln
           ebelp
           zekkn
           vgabe
           gjahr
           belnr
           buzei
           budat
           menge
           dmbtr
           waers
           shkzg
           xblnr
           lfgja
           lfbnr
           lfpos
           refwr
           introw
     FROM ekbe
     INTO CORRESPONDING FIELDS OF TABLE it_ekbe2
     FOR ALL ENTRIES IN it_ekkn
     WHERE ebeln = it_ekkn-ebeln
       AND ebelp = it_ekkn-ebelp AND vgabe EQ '3' .

    SORT : it_ekbe BY ebeln ebelp,
           it_ekbe1 BY ebeln ebelp,
           it_ekbe2 BY ebeln ebelp.

***** End of changes on 03.10.2019
  ENDIF.

  "Comment Start by Rahul Vasita on 13.03.2024 14:33:21
**  SORT it_ekbe BY ebeln ebelp.
**  SORT it_ekbe1 BY ebeln ebelp.
  "Comment End by Rahul Vasita on 13.03.2024 14:33:21

  IF it_ekbe IS NOT INITIAL.
*    SELECT * FROM j_1iexcdtl INTO TABLE it_excise1 FOR ALL ENTRIES IN it_ekbe WHERE rdoc2 = it_ekbe-belnr. "Comment by Rahul Vasita on 13.03.2024 14:35:43
    "Comment Start by Rahul Vasita on 13.03.2024 14:46:18
***    SELECT trntyp
***           docyr
***           docno
***           zeile         "NEVER USED
***           exgrp
***     FROM j_1iexcdtl
***     INTO CORRESPONDING FIELDS OF TABLE it_excise1
***     FOR ALL ENTRIES IN it_ekbe
***     WHERE rdoc2 = it_ekbe-belnr.
***
***    SORT it_excise1 BY docno exgrp.
    "Comment End by Rahul Vasita on 13.03.2024 14:46:18
  ENDIF.

  "Comment Start by Rahul Vasita on 13.03.2024 14:38:08
***  IF it_excise1 IS NOT INITIAL.
***    SELECT * FROM j_1ipart2 INTO TABLE it_part2 FOR ALL ENTRIES IN it_excise1 WHERE exgrp = it_excise1-exgrp
***                                                                                AND docno = it_excise1-docno
***                                                                                AND regtyp EQ 'C'
***                                                                                AND exbed GT 0.

  "Adding Start by Rahul Vasita on 13.03.2024 14:38:22
***    SELECT exgrp
***           regtyp
***           syear
***           serialno          "NEVER USED
***           docno
***           exbed
***      FROM j_1ipart2
***      INTO CORRESPONDING FIELDS OF TABLE it_part2
***      FOR ALL ENTRIES IN it_excise1
***      WHERE exgrp = it_excise1-exgrp
***        AND regtyp = 'C'
***        AND docno = it_excise1-docno
***        AND exbed > 0.
  "Adding End by Rahul Vasita on 13.03.2024 14:38:22
***  ENDIF.
  "Comment End by Rahul Vasita on 13.03.2024 14:38:08
  IF it_ekbe1[] IS NOT INITIAL.
    SELECT gjahr belnr FROM ekbe INTO TABLE it_fi FOR ALL ENTRIES IN it_ekbe1 WHERE ebeln = it_ekbe1-ebeln
                                                                                AND ebelp = it_ekbe1-ebelp.
    SORT it_fi BY gjahr belnr.
  ENDIF.
*************************************************************** Added on 12.09.2019
  IF it_ekkn IS NOT INITIAL.
*    SELECT * FROM ekko INTO TABLE it_ekko1 FOR ALL ENTRIES IN it_ekkn WHERE ebeln = it_ekkn-ebeln "Comment by Rahul Vasita on 13.03.2024 14:52:42
    SELECT ebeln ekorg FROM ekko INTO CORRESPONDING FIELDS OF TABLE it_ekko1
      FOR ALL ENTRIES IN it_ekkn WHERE ebeln = it_ekkn-ebeln "Added by Rahul Vasita on 13.03.2024 14:52:44
      AND  ekorg EQ '1001'.

    SORT it_ekko1 BY ebeln.
  ENDIF.
  IF it_ekko1 IS NOT INITIAL.
    SELECT ebeln ebelp
      FROM ekpo
      INTO CORRESPONDING FIELDS OF TABLE it_ekpo1
      FOR ALL ENTRIES IN it_ekko1
      WHERE ebeln  = it_ekko1-ebeln .

    SORT it_ekpo1 BY ebeln.
  ENDIF.
  IF it_ekpo1 IS NOT INITIAL.
*    SELECT * FROM ekbz INTO TABLE it_ekbz FOR ALL ENTRIES IN it_ekpo1 WHERE ebeln = it_ekpo1-ebeln AND "Comment by Rahul Vasita on 13.03.2024 14:57:27
    SELECT ebeln
           ebelp
           stunr
           zaehk
           vgabe
           gjahr
           belnr
           buzei
      FROM ekbz
      INTO CORRESPONDING FIELDS OF TABLE it_ekbz
      FOR ALL ENTRIES IN it_ekpo1
      WHERE ebeln = it_ekpo1-ebeln AND ebelp = it_ekpo1-ebelp .

    SORT it_ekbz ASCENDING BY ebeln ebelp gjahr belnr buzei. "Added by Rahul Vasita on 13.03.2024 14:58:45
  ENDIF.
  LOOP AT it_ekbz INTO wa_ekbz.
    CONCATENATE wa_ekbz-belnr wa_ekbz-gjahr INTO wa_awkey1-awkey.
    APPEND wa_awkey1 TO it_awkey1.
    CLEAR:wa_awkey1,wa_ekbz.
  ENDLOOP.

  SORT it_awkey1 BY awkey. "Added by Rahul Vasita on 13.03.2024 14:59:28

  IF it_awkey1 IS NOT INITIAL.
    SELECT bukrs
           belnr
           gjahr
           blart
           budat
           xblnr
           awtyp
           awkey
*  FROM bkpf INTO CORRESPONDING FIELDS OF TABLE it_bkpf1
FROM zfi_bkbt_data INTO CORRESPONDING FIELDS OF TABLE it_bkpf1
FOR ALL ENTRIES IN it_awkey1 WHERE bukrs IN s_bukrs AND blart NOT IN s_blart AND awtyp IN ( 'MKPF' , 'RMRP' , 'AUAK' ) AND awkey = it_awkey1-awkey . "
    "Added by Rahul Vasita on 15.04.2024 17:49:16
  ENDIF.


  IF it_bkpf1 IS NOT INITIAL.
    SELECT bukrs
           belnr
           gjahr
           buzei
           mwskz
           hkont
           shkzg
           hwste
           kschl
           FROM bset
           INTO CORRESPONDING FIELDS OF TABLE it_bset1
           FOR ALL ENTRIES IN it_bkpf1
           WHERE belnr = it_bkpf1-belnr
             AND bukrs = it_bkpf1-bukrs
             AND gjahr = it_bkpf1-gjahr ORDER BY PRIMARY KEY.
  ENDIF.

  IF it_covp IS NOT INITIAL.
    SORT it_covp ASCENDING BY refbk refbn refgj. "Added by Rahul Vasita on 13.03.2024 16:39:34
*    SELECT * FROM bset INTO TABLE it_bset2 FOR ALL ENTRIES IN it_covp WHERE  bukrs = it_covp-refbk "ICST/CGST/SGST for Fi Documents "Comment by Rahul Vasita on 13.03.2024 16:38:14
    SELECT bukrs
           belnr
           gjahr
           buzei
           mwskz
           hkont
           txgrp
           shkzg
           hwste
           kschl
       FROM bset
       INTO CORRESPONDING FIELDS OF TABLE it_bset2
       FOR ALL ENTRIES IN it_covp
       WHERE bukrs = it_covp-refbk "ICST/CGST/SGST for Fi Documents
         AND belnr = it_covp-refbn
         AND gjahr = it_covp-refgj ORDER BY PRIMARY KEY.

    SORT it_bset2 ASCENDING BY bukrs belnr gjahr hkont txgrp. "Added by Rahul Vasita on 13.03.2024 16:48:26
  ENDIF.

*****************************************END of changes on 12.09.2019
  LOOP AT it_fi INTO wa_fi.

    CONCATENATE wa_fi-belnr wa_fi-gjahr INTO wa_awkey-awkey.
    APPEND wa_awkey TO it_awkey.
    CLEAR:wa_awkey,wa_fi.

  ENDLOOP.

  SORT it_awkey BY awkey.

  "Comment Start by Rahul Vasita on 13.03.2024 16:16:20
**  LOOP AT it_anek INTO wa_anek.
**
**    READ TABLE it_wbs INTO wa_wbs WITH KEY anln1 = wa_anek-anln1.
**    IF wa_wbs IS NOT INITIAL.
**      wa_awkey-awkey  = wa_anek-belnr.
**      APPEND wa_awkey TO it_awkey.
**    ELSE.
**
**      CONCATENATE wa_anek-belnr wa_anek-gjahr INTO wa_awkey-awkey.
**      APPEND wa_awkey TO it_awkey.
**
**    ENDIF.
**    CLEAR:wa_awkey,wa_anek,wa_wbs.
**
**
**  ENDLOOP.
  "Comment End by Rahul Vasita on 13.03.2024 16:16:20

  "Adding Start by Rahul Vasita on 13.03.2024 16:16:38
  LOOP AT it_anek INTO wa_anek.
    READ TABLE it_anep INTO wa_anep WITH KEY anln1 = wa_anek-anln1.
    IF sy-subrc = 0.
      wa_awkey-awkey  = wa_anek-belnr.
      APPEND wa_awkey TO it_awkey.
    ELSE.
      CONCATENATE wa_anek-belnr wa_anek-gjahr INTO wa_awkey-awkey.
      APPEND wa_awkey TO it_awkey.
    ENDIF.
*    CONCATENATE wa_anek-belnr wa_anek-aworg INTO wa_awkey-awkey. "Comment by Rahul Vasita on 14.03.2024 14:35:36
*    wa_awkey-awtyp = wa_anek-awtyp. "Comment by Rahul Vasita on 14.03.2024 14:35:39

    CLEAR : wa_awkey , wa_anek , wa_anep.
  ENDLOOP.
  "Adding End by Rahul Vasita on 13.03.2024 16:16:38

  SORT it_awkey BY awkey.
  DELETE ADJACENT DUPLICATES FROM it_awkey COMPARING awkey.

  IF it_awkey IS NOT INITIAL.

    "Comment Start by Rahul Vasita on 13.03.2024 16:22:42
*    SELECT * FROM bkpf INTO TABLE it_bkpf FOR ALL ENTRIES IN it_awkey WHERE awkey = it_awkey-awkey
*                                                                        AND bukrs IN s_bukrs.
    "Comment End by Rahul Vasita on 13.03.2024 16:22:42
    "Adding Start by Rahul Vasita on 13.03.2024 16:22:55
    SELECT bukrs
           belnr
           gjahr
           blart
           budat
           xblnr
           awtyp
           awkey
       FROM zfi_bkbt_data
   INTO CORRESPONDING FIELDS OF TABLE it_bkpf
   FOR ALL ENTRIES IN it_awkey
   WHERE bukrs IN s_bukrs
     AND blart NOT IN s_blart "Added by Rahul Vasita on 15.04.2024 17:48:58
*    AND awtyp = it_awkey-awtyp
    AND awkey = it_awkey-awkey .  "

    SORT it_bkpf ASCENDING BY bukrs belnr gjahr awkey.

    DELETE ADJACENT DUPLICATES FROM it_bkpf COMPARING bukrs belnr gjahr awkey. "Added by Rahul Vasita on 20.03.2024 12:40:11
    "Adding End by Rahul Vasita on 13.03.2024 16:22:55
***************Added by Raj on 30.09.2023*******************
    "Comment Start by Rahul Vasita on 13.03.2024 16:26:36
***    IF it_covp IS NOT INITIAL.
***      SELECT * FROM bkpf APPENDING TABLE it_bkpf
***        FOR ALL ENTRIES IN  it_covp
***         WHERE bukrs = it_covp-refbk AND
***        gjahr = it_covp-refgj AND
***        belnr = it_covp-refbn.
***    ENDIF.
    "Comment End by Rahul Vasita on 13.03.2024 16:26:36

    "Adding Start by Rahul Vasita on 13.03.2024 16:27:02
    IF it_covp IS NOT INITIAL.
      SELECT bukrs
             belnr
             gjahr
             blart
             budat
             xblnr
             awtyp
             awkey
         FROM zfi_bkbt_data
         APPENDING CORRESPONDING FIELDS OF TABLE it_bkpf
         FOR ALL ENTRIES IN  it_covp
         WHERE bukrs = it_covp-refbk AND
               belnr = it_covp-refbn AND
               gjahr = it_covp-refgj AND
               blart NOT IN s_blart. "Added by Rahul Vasita on 19.04.2024 14:04:41
      SORT it_bkpf ASCENDING BY bukrs belnr gjahr awkey. "Added by Rahul Vasita on 13.03.2024 18:45:48
      DELETE ADJACENT DUPLICATES FROM it_bkpf COMPARING bukrs belnr gjahr awkey. "Added by Rahul Vasita on 20.03.2024 12:40:11
    ENDIF.
    "Adding End by Rahul Vasita on 13.03.2024 16:27:02
***************Ended by Raj on 30.09.2023*******************

  ENDIF.

  IF it_anek IS NOT INITIAL.
    SORT it_anek BY bukrs anln1 belnr gjahr.
*    SELECT * FROM bkpf APPENDING TABLE it_bkpf FOR ALL ENTRIES IN it_anek WHERE belnr = it_anek-belnr
    SELECT bukrs
           belnr
           gjahr
           blart
           budat
           xblnr
           awtyp
           awkey
   FROM zfi_bkbt_data APPENDING CORRESPONDING FIELDS OF TABLE it_bkpf FOR ALL ENTRIES IN it_anek WHERE bukrs = it_anek-bukrs
                                                                    AND belnr = it_anek-belnr
                                                                    AND gjahr = it_anek-gjahr
                                                                    AND blart NOT IN s_blart. "Added by Rahul Vasita on 15.04.2024 17:50:23
    SORT it_bkpf ASCENDING BY bukrs belnr gjahr awkey. "Added by Rahul Vasita on 13.03.2024 18:46:05
    DELETE ADJACENT DUPLICATES FROM it_bkpf COMPARING bukrs belnr gjahr awkey. "Added by Rahul Vasita on 20.03.2024 12:40:11
  ENDIF.

  IF it_bkpf[] IS NOT INITIAL.
**    SORT it_bkpf ASCENDING BY bukrs belnr gjahr. "Added by Rahul Vasita on 13.03.2024 16:42:08
*    SELECT * FROM bset INTO TABLE it_bset FOR ALL ENTRIES IN it_bkpf WHERE belnr = it_bkpf-belnr
    SELECT bukrs
           belnr
           gjahr
           buzei
           mwskz
           hkont
           txgrp
           shkzg
           hwste
           kschl
   FROM bset
   INTO CORRESPONDING FIELDS OF TABLE it_bset
   FOR ALL ENTRIES IN it_bkpf WHERE belnr = it_bkpf-belnr
    AND bukrs = it_bkpf-bukrs
    AND gjahr = it_bkpf-gjahr ORDER BY PRIMARY KEY.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*    SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*           hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 xref3 FROM bseg INTO CORRESPONDING FIELDS OF TABLE it_bseg
*                                                                 FOR ALL ENTRIES IN it_bkpf
*                                                                 WHERE bukrs = it_bkpf-bukrs
*                                                                 AND belnr = it_bkpf-belnr
*                                                                 AND gjahr = it_bkpf-gjahr
*                                                                 AND koart <> 'A' ORDER BY PRIMARY KEY."Added by Rahul Vasita on 12.04.2024 17:57:50 "Comment by Rahul Vasita on 19.04.2024 11:41:39

    SELECT
        CompanyCode                     AS bukrs,
        AccountingDocument              AS belnr,
        FiscalYear                      AS gjahr,
        AccountingDocumentItem          AS buzei,
        AccountingDocumentItemType      AS buzid,
        ClearingJournalEntry            AS augbl,
        PostingKey                      AS bschl,
        FinancialAccountType            AS koart,
        SpecialGLCode                   AS umskz,
        DebitCreditCode                 AS shkzg,
        TaxCode                         AS mwskz,
        AbsoluteAmountInCoCodeCrcy      AS dmbtr,
        AbsoluteAmountInTransacCrcy     AS wrbtr,
        OriglTxAbsltBaseAmountInCCCrcy  AS txbhw,
        OriginalTaxAbsoluteBaseAmount   AS txbfw,
        TaxAbsltBaseAmountInCoCodeCrcy  AS hwbas,
        TaxAbsltBaseAmountInTransCrcy   AS fwbas,
        TaxType                         AS mwart,
        GLAccount                       AS hkont,
        Supplier                        AS lifnr,
        ProfitCenter                    AS prctr,
        Plant                           AS werks,
        PurchasingDocument              AS ebeln,
        PurchasingDocumentItem          AS ebelp,
        TaxItemGroup                    AS txgrp,
        MasterFixedAsset                AS anln1,
        Reference3IDByBusinessPartner   AS xref3
    FROM i_operationalacctgdocitem
    INTO CORRESPONDING FIELDS OF TABLE @it_bseg
    FOR ALL ENTRIES IN @it_bkpf
    WHERE CompanyCode            = @it_bkpf-bukrs
      AND AccountingDocument     = @it_bkpf-belnr
      AND FiscalYear             = @it_bkpf-gjahr
      AND FinancialAccountType   <> 'A'.
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC

    SORT it_bseg ASCENDING BY bukrs belnr gjahr ebelp ebelp txgrp xref3. "Added by Rahul Vasita on 13.03.2024 16:47:03

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*    SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*       hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 xref3 FROM bseg APPENDING CORRESPONDING FIELDS OF TABLE it_bseg
*                                                             FOR ALL ENTRIES IN it_bkpf
*                                                             WHERE bukrs = it_bkpf-bukrs
*                                                             AND belnr = it_bkpf-belnr
*                                                             AND gjahr = it_bkpf-gjahr
*                                                             AND koart = 'A'
*                                                             AND anln1 <> ' ' ORDER BY PRIMARY KEY."Added by Rahul Vasita on 12.04.2024 17:57:50 "Comment by Rahul Vasita on 19.04.2024 11:41:39

    SELECT
    CompanyCode                     AS bukrs,
    AccountingDocument              AS belnr,
    FiscalYear                      AS gjahr,
    AccountingDocumentItem          AS buzei,
    AccountingDocumentItemType      AS buzid,
    ClearingJournalEntry            AS augbl,
    PostingKey                      AS bschl,
    FinancialAccountType            AS koart,
    SpecialGLCode                   AS umskz,
    DebitCreditCode                 AS shkzg,
    TaxCode                         AS mwskz,
    AbsoluteAmountInCoCodeCrcy      AS dmbtr,
    AbsoluteAmountInTransacCrcy     AS wrbtr,
    OriglTxAbsltBaseAmountInCCCrcy  AS txbhw,
    OriginalTaxAbsoluteBaseAmount   AS txbfw,
    TaxAbsltBaseAmountInCoCodeCrcy  AS hwbas,
    TaxAbsltBaseAmountInTransCrcy   AS fwbas,
    TaxType                         AS mwart,
    GLAccount                       AS hkont,
    Supplier                        AS lifnr,
    ProfitCenter                    AS prctr,
    Plant                           AS werks,
    PurchasingDocument              AS ebeln,
    PurchasingDocumentItem          AS ebelp,
    TaxItemGroup                    AS txgrp,
    MasterFixedAsset                AS anln1,
    Reference3IDByBusinessPartner   AS xref3
      FROM i_operationalacctgdocitem
      APPENDING CORRESPONDING FIELDS OF TABLE @it_bseg
      FOR ALL ENTRIES IN @it_bkpf
      WHERE CompanyCode           = @it_bkpf-bukrs
        AND AccountingDocument    = @it_bkpf-belnr
        AND FiscalYear            = @it_bkpf-gjahr
        AND FinancialAccountType  = 'A'
        AND MasterFixedAsset <> ' '.

" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
    SORT it_bseg ASCENDING BY bukrs belnr gjahr ebelp ebelp txgrp xref3. "Added by Rahul Vasita on 13.03.2024 16:47:03

*                                                                 AND ebeln NE ' '.

* **********************for Fi documents on 05.10.2023

    IF it_covp IS NOT INITIAL.
      " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*      SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*         hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 xref3 projk FROM bseg INTO CORRESPONDING FIELDS OF TABLE it_bsegfi
*                                                               FOR ALL ENTRIES IN it_covp
*                                                               WHERE bukrs = it_covp-refbk AND
*                                                                     gjahr = it_covp-refgj AND
*                                                                       belnr = it_covp-refbn.

*      SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*         hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 xref3 projk FROM bseg INTO CORRESPONDING FIELDS OF TABLE it_bsegfi
*                                                               FOR ALL ENTRIES IN it_covp
*                                                               WHERE bukrs = it_covp-refbk AND
*                                                                     gjahr = it_covp-refgj AND
*                                                                       belnr = it_covp-refbn ORDER BY PRIMARY KEY.

      SELECT  CompanyCode                     AS bukrs,
              AccountingDocument              AS belnr,
              FiscalYear                      AS gjahr,
              AccountingDocumentItem          AS buzei,
              AccountingDocumentItemType      AS buzid,
              ClearingJournalEntry            AS augbl,
              PostingKey                      AS bschl,
              FinancialAccountType            AS koart,
              SpecialGLCode                   AS umskz,
              DebitCreditCode                 AS shkzg,
              TaxCode                         AS mwskz,
              AbsoluteAmountInCoCodeCrcy      AS dmbtr,
              AbsoluteAmountInTransacCrcy     AS wrbtr,
              OriglTxAbsltBaseAmountInCCCrcy  AS txbhw,
              OriginalTaxAbsoluteBaseAmount   AS txbfw,
              TaxAbsltBaseAmountInCoCodeCrcy  AS hwbas,
              TaxAbsltBaseAmountInTransCrcy   AS fwbas,
              TaxType                         AS mwart,
              GLAccount                       AS hkont,
              Supplier                        AS lifnr,
              ProfitCenter                    AS prctr,
              Plant                           AS werks,
              PurchasingDocument              AS ebeln,
              PurchasingDocumentItem          AS ebelp,
              TaxItemGroup                    AS txgrp,
              MasterFixedAsset                AS anln1,
              Reference3IDByBusinessPartner   AS xref3,
              WBSElementInternalID            AS projk
      FROM i_operationalacctgdocitem
      INTO CORRESPONDING FIELDS OF TABLE @it_bsegfi
      FOR ALL ENTRIES IN @it_covp
      WHERE CompanyCode = @it_covp-refbk AND
            FiscalYear = @it_covp-refgj AND
            AccountingDocument = @it_covp-refbn ORDER BY PRIMARY KEY.
      " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC

    ENDIF.
*  *********************For fi Document on 05.10.2023

    IF it_anek IS NOT INITIAL.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*      SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*             hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 FROM bseg INTO TABLE it_bseg1
*                                                                   FOR ALL ENTRIES IN it_anek
*                                                                   WHERE bukrs = it_anek-bukrs
*                                                                   AND belnr = it_anek-belnr
*                                                                   AND gjahr = it_anek-gjahr
*                                                                   AND koart EQ 'A' ORDER BY PRIMARY KEY.

        SELECT
          CompanyCode                     AS bukrs,
          AccountingDocument              AS belnr,
          FiscalYear                      AS gjahr,
          AccountingDocumentItem          AS buzei,
          AccountingDocumentItemType      AS buzid,
          ClearingJournalEntry            AS augbl,
          PostingKey                      AS bschl,
          FinancialAccountType            AS koart,
          SpecialGLCode                   AS umskz,
          DebitCreditCode                 AS shkzg,
          TaxCode                         AS mwskz,
          AbsoluteAmountInCoCodeCrcy      AS dmbtr,
          AbsoluteAmountInTransacCrcy     AS wrbtr,
          OriglTxAbsltBaseAmountInCCCrcy  AS txbhw,
          OriginalTaxAbsoluteBaseAmount   AS txbfw,
          TaxAbsltBaseAmountInCoCodeCrcy  AS hwbas,
          TaxAbsltBaseAmountInTransCrcy   AS fwbas,
          TaxType                         AS mwart,
          GLAccount                       AS hkont,
          Supplier                        AS lifnr,
          ProfitCenter                    AS prctr,
          Plant                           AS werks,
          PurchasingDocument              AS ebeln,
          PurchasingDocumentItem          AS ebelp,
          TaxItemGroup                    AS txgrp,
          MasterFixedAsset                AS anln1
          FROM I_OPERATIONALACCTGDOCITEM
          INTO TABLE @it_bseg1
          FOR ALL ENTRIES IN @it_anek
          WHERE CompanyCode           = @it_anek-bukrs
            AND AccountingDocument    = @it_anek-belnr
            AND FiscalYear            = @it_anek-gjahr
            AND FinancialAccountType  = 'A'.
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC

      SORT it_bseg1 ASCENDING BY bukrs belnr gjahr buzei. "Added by Rahul Vasita on 13.03.2024 16:52:21

****** Added changes for FI document vendor on 06.09.2019
" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*      SELECT bukrs belnr gjahr buzei buzid augbl bschl koart umskz shkzg mwskz dmbtr wrbtr txbhw txbfw
*             hwbas fwbas mwart hkont lifnr prctr werks ebeln ebelp txgrp anln1 FROM bseg INTO TABLE it_bseg2
*                                                                   FOR ALL ENTRIES IN it_anek
*                                                                   WHERE bukrs = it_anek-bukrs
*                                                                   AND belnr = it_anek-belnr
*                                                                   AND gjahr = it_anek-gjahr
*                                                                   AND koart EQ 'K' ORDER BY PRIMARY KEY.

  SELECT
    CompanyCode                     AS bukrs,
    AccountingDocument              AS belnr,
    FiscalYear                      AS gjahr,
    AccountingDocumentItem          AS buzei,
    AccountingDocumentItemType      AS buzid,
    ClearingJournalEntry            AS augbl,
    PostingKey                      AS bschl,
    FinancialAccountType            AS koart,
    SpecialGLCode                   AS umskz,
    DebitCreditCode                 AS shkzg,
    TaxCode                         AS mwskz,
    AbsoluteAmountInCoCodeCrcy      AS dmbtr,
    AbsoluteAmountInTransacCrcy     AS wrbtr,
    OriglTxAbsltBaseAmountInCCCrcy  AS txbhw,
    OriginalTaxAbsoluteBaseAmount   AS txbfw,
    TaxAbsltBaseAmountInCoCodeCrcy  AS hwbas,
    TaxAbsltBaseAmountInTransCrcy   AS fwbas,
    TaxType                         AS mwart,
    GLAccount                       AS hkont,
    Supplier                        AS lifnr,
    ProfitCenter                    AS prctr,
    Plant                           AS werks,
    PurchasingDocument              AS ebeln,
    PurchasingDocumentItem          AS ebelp,
    TaxItemGroup                    AS txgrp,
    MasterFixedAsset                AS anln1
    FROM I_OPERATIONALACCTGDOCITEM
    INTO TABLE @it_bseg2
    FOR ALL ENTRIES IN @it_anek
    WHERE CompanyCode           = @it_anek-bukrs
      AND AccountingDocument    = @it_anek-belnr
      AND FiscalYear            = @it_anek-gjahr
      AND FinancialAccountType  = 'K'.

" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
      SORT it_bseg2 ASCENDING BY bukrs belnr gjahr buzei. "Added by Rahul Vasita on 13.03.2024 16:52:21

      IF it_bseg2[] IS NOT INITIAL.
        SELECT lifnr
               name1
               name2
          FROM lfa1
          INTO CORRESPONDING FIELDS OF TABLE it_lfa1
          FOR ALL ENTRIES IN it_bseg2
          WHERE lifnr = it_bseg2-lifnr.
      ENDIF."it_bseg2[] is NOT INITIAL.


    ENDIF.
****** End of changes on 06.09.2019


*    SELECT * FROM faglflexa INTO TABLE it_fagll FOR ALL ENTRIES IN it_bkpf WHERE ryear = it_bkpf-gjahr
*                                                                           AND belnr = it_bkpf-belnr
*                                                                           AND rldnr EQ '0L'.

*    IF it_ekpo IS NOT INITIAL. "Comment by Rahul Vasita on 14.03.2024 17:07:17
    IF lt_po IS NOT INITIAL.
      "Comment Start by Rahul Vasita on 13.03.2024 17:39:55
**      SELECT belnr gjahr buzei ebeln ebelp matnr bukrs werks menge kschl wrbtr shkzg lifnr bklas bnkan xblnr tbtkz  FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg
**                                                                                     FOR ALL ENTRIES IN it_ekpo
**                                                                                     WHERE ebeln = it_ekpo-ebeln
**                                                                                     AND ebelp = it_ekpo-ebelp.
      "Comment End by Rahul Vasita on 13.03.2024 17:39:55

*      SELECT belnr gjahr buzei ebeln ebelp matnr bukrs werks menge kschl wrbtr shkzg lifnr bklas bnkan xblnr tbtkz  FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg
      SELECT belnr, gjahr, buzei, ebeln, ebelp, matnr, bukrs, werks, menge, kschl, wrbtr, shkzg, lifnr, bklas, bnkan, xblnr, tbtkz  FROM zfi_rseg_pocds INTO CORRESPONDING FIELDS OF TABLE @it_rseg
                                                                             FOR ALL ENTRIES IN @lt_po
                                                                             WHERE ebeln = @lt_po-ebeln
                                                                             AND ebelp = @lt_po-ebelp.
*                                                                                     AND xrueb NE 'X'.
      SORT it_rseg ASCENDING BY belnr gjahr buzei ebeln ebelp.
*************************
      "Comment Start by Rahul Vasita on 13.03.2024 17:41:04
**      SELECT belnr gjahr buzei ebeln ebelp matnr bukrs werks menge kschl xblnr wrbtr shkzg lifnr bklas bnkan FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg1
**                                                                                       FOR ALL ENTRIES IN it_ekpo
**                                                                                      WHERE ebeln = it_ekpo-ebeln
**                                                                                      AND ebelp = it_ekpo-ebelp.
      "Comment End by Rahul Vasita on 13.03.2024 17:41:04

*      SELECT belnr gjahr buzei ebeln ebelp matnr bukrs werks menge kschl xblnr wrbtr shkzg lifnr bklas bnkan FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg1
      SELECT belnr, gjahr, buzei, ebeln, ebelp, matnr, bukrs, werks, menge, kschl, wrbtr, shkzg, lifnr, bklas, bnkan, xblnr FROM zfi_rseg_pocds INTO CORRESPONDING FIELDS OF TABLE @it_rseg1
                                                                               FOR ALL ENTRIES IN @lt_po
                                                                              WHERE ebeln = @lt_po-ebeln
                                                                              AND ebelp = @lt_po-ebelp.
*                                                                                     AND xrueb NE 'X'.
      SORT it_rseg1 ASCENDING BY belnr ebeln ebelp xblnr buzei. "Added by Rahul Vasita on 13.03.2024 18:33:05


*************Added by Raj begin of changes on 18.12.2023***********
      LOOP AT it_rseg INTO wa_rseg.
        CONCATENATE wa_rseg-belnr wa_rseg-gjahr INTO wa_rseg-awkey.
        MODIFY it_rseg FROM wa_rseg TRANSPORTING awkey.
        CLEAR wa_rseg.
      ENDLOOP.

      IF it_rseg IS NOT INITIAL.


        SELECT bukrs
               belnr
               gjahr
               blart
               budat
               xblnr
               awtyp
               awkey
           FROM zfi_bkbt_data
           APPENDING CORRESPONDING FIELDS OF TABLE it_bkpf FOR ALL ENTRIES IN it_rseg WHERE blart NOT IN s_blart AND awkey = it_rseg-awkey. "Added by Rahul Vasita on 19.04.2024 14:05:01

        SORT it_bkpf ASCENDING BY bukrs belnr gjahr awkey. "Added by Rahul Vasita on 13.03.2024 16:56:53

      ENDIF.

************Added by Raj begin of changes on 18.12.2023************



************************************
    ENDIF."End of LT_PO
  ENDIF.

  IF it_rseg IS NOT INITIAL.
    SORT it_rseg ASCENDING BY belnr gjahr buzei ebeln ebelp."Added by Rahul Vasita on 13.03.2024 17:13:31
    SELECT belnr
           gjahr
           bldat
           xblnr
           stblg FROM rbkp INTO CORRESPONDING FIELDS OF TABLE it_rbkp FOR ALL ENTRIES IN it_rseg WHERE belnr = it_rseg-belnr
                                                                           AND gjahr = it_rseg-gjahr.
*                                                                           AND stblg = ''.
    SORT it_rbkp ASCENDING BY belnr gjahr. "Added by Rahul Vasita on 13.03.2024 17:13:28
  ENDIF.

  "Comment Start by Rahul Vasita on 13.03.2024 17:19:41
**  IF it_ekko IS NOT INITIAL.
**    SELECT * FROM eslh INTO TABLE it_eslh FOR ALL ENTRIES IN it_ekko WHERE ebeln = it_ekko-ebeln AND bstyp EQ 'F'.
**  ENDIF.
**
**  IF it_eslh IS NOT INITIAL.
**    SELECT * FROM esll INTO TABLE it_esll FOR ALL ENTRIES IN it_eslh WHERE packno = it_eslh-packno AND package NE 'X' .
**  ENDIF.
  "Comment End by Rahul Vasita on 13.03.2024 17:19:41
  "Adding Start by Rahul Vasita on 13.03.2024 17:19:55
  IF lt_po IS NOT INITIAL.
    SELECT a~packno
           a~ebeln
           a~ebelp
           b~introw
      FROM eslh AS a
*      LEFT OUTER JOIN esll AS b ON a~packno = b~packno
      INNER JOIN esll AS b ON a~packno = b~packno
      INTO TABLE lt_es
      FOR ALL ENTRIES IN lt_po
      WHERE a~ebeln = lt_po-ebeln
        AND a~bstyp = 'F'
        AND b~package <> 'X'.
  ENDIF.

  SORT lt_es ASCENDING BY packno ebeln ebelp introw.
  "Adding End by Rahul Vasita on 13.03.2024 17:19:55

  "Adding Start by Rahul Vasita on 16.08.2024 10:59:40
  IF lt_po[] IS NOT INITIAL.
    SELECT packno,
           ebeln,
           ebelp,
           loekz
      FROM essr
      INTO TABLE @DATA(lt_essr)
      FOR ALL ENTRIES IN @lt_po
      WHERE ebeln = @lt_po-ebeln
        AND loekz = @abap_false.

    SORT lt_essr BY packno.
  ENDIF."IF lt_po[] IS NOT INITIAL.
  IF lt_essr[] IS NOT INITIAL.
    SELECT packno,
           sub_packno
      FROM esll
      INTO TABLE @DATA(lt_esll)
      FOR ALL ENTRIES IN @lt_essr
      WHERE packno = @lt_essr-packno.
    SORT lt_esll BY packno. "Added by Rahul Vasita on 16.08.2024 11:09:20
  ENDIF."IF lt_essr[] IS NOT INITIAL.
  IF lt_esll[] IS NOT INITIAL.
    SELECT packno,
           introw
      FROM esll
      INTO TABLE @DATA(lt_esll_item)
      FOR ALL ENTRIES IN @lt_esll
      WHERE packno = @lt_esll-sub_packno.
  ENDIF.

  lt_wbses = VALUE #( FOR ls_po IN lt_po
                      FOR ls_essr IN lt_essr WHERE ( ebeln = ls_po-ebeln )
                      FOR ls_essl IN lt_esll WHERE ( packno = ls_essr-packno )
                      FOR ls_essl_item IN lt_esll_item WHERE ( packno = ls_essl-sub_packno )
                      ( packno = ls_essl_item-packno
                        introw = ls_essl_item-introw
                        ebeln  = ls_essr-ebeln
                        ebelp  = ls_essr-ebelp
                      ) ).

  SORT lt_wbses BY ebeln ebelp. "Added by Rahul Vasita on 16.08.2024 11:55:42
  "Adding End by Rahul Vasita on 16.08.2024 10:59:40

ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  COMBINE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM combine.

  DATA:v_poquan TYPE menge_d.
  DATA:v_poamt  TYPE dmbtr.
  DATA:v_ebeln TYPE ebeln.
  DATA:v_miquan TYPE menge_d.
  DATA:v_miamt  TYPE dmbtr.
  DATA:v_mblnr TYPE mblnr.
  DATA:v_awkey(20) TYPE c.
  DATA:v_awkey1(20) TYPE c.
  DATA:count TYPE i.
  DATA:count1 TYPE i.
  DATA:srno  TYPE i.
  DATA:cno  TYPE i.

  "Comment Start by Rahul Vasita on 14.03.2024 11:01:37
**  SORT it_ekkn BY ebeln ebelp.
**  SORT it_ekpo BY ebeln ebelp.
**  SORT it_ekbe BY ebeln ebelp.
  "Comment End by Rahul Vasita on 14.03.2024 11:01:37

  " SORTING Adding Start by Rahul Vasita on 14.03.2024 11:24:51
  SORT : it_anep BY anln1,
         lt_po BY ebeln ebelp,
         it_rseg BY ebeln ebelp,
         it_lfa1 BY lifnr,
         it_rbkp BY belnr gjahr,
         it_bkpf BY awkey,"bukrs belnr gjahr
         it_bkpf1 BY awkey,"bukrs belnr gjahr
         it_excise BY trntyp docyr docno zeile rdoc1 rdoc2 ritem1,
         it_ekbe1 BY ebeln ebelp zekkn vgabe gjahr belnr buzei xblnr lfbnr lfpos introw,
         it_rseg1 BY belnr buzei ebeln ebelp xblnr ,        "gjahr
         it_fi BY belnr gjahr,
         it_bseg1 BY  belnr buzei,"bukrs gjahr
         it_bseg2 BY belnr gjahr buzei,"bukrs
         it_bseg BY bukrs belnr gjahr buzei txgrp,
         it_ekbz1 BY ebeln ebelp.
  "SORTING Adding End by Rahul Vasita on 14.03.2024 11:24:51

  SELECT low FROM tvarvc INTO TABLE @DATA(lt_tvarvc) WHERE name = 'ZFI_TAX'.   "Added by Rutvi on 11.09.2024

  LOOP AT it_anla INTO wa_anla.

    wa_final-txt50 = wa_anla-txt50.

*    LOOP AT it_ekkn INTO wa_ekkn WHERE anln1 = wa_anla-anln1. " commented on 10.11.2021

    IF wa_anla-posnr IS NOT INITIAL.
      LOOP AT it_ekkn INTO wa_ekkn WHERE ps_psp_pnr = wa_anla-posnr . " changed on 10.11.2021
        " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*        SELECT SINGLE werks FROM anlz INTO wa_final-werks WHERE bukrs = wa_anla-bukrs AND anln1 = wa_anla-anln1 AND bdatu = '99991231'.

        SELECT werks FROM anlz INTO wa_final-werks UP TO 1 ROWS WHERE bukrs = wa_anla-bukrs AND anln1 = wa_anla-anln1 AND bdatu = '99991231' ORDER BY PRIMARY KEY.ENDSELECT.
        " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
        MOVE-CORRESPONDING wa_anla TO wa_final.
*
        CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
          EXPORTING
            input  = wa_ekkn-ps_psp_pnr
          IMPORTING
            output = wa_final-ps_psp_pnr.

*      wa_final-ps_psp_pnr = wa_ekkn-ps_psp_pnr.
        READ TABLE it_anep INTO wa_anep WITH KEY anln1 = wa_anla-anln1.
        IF sy-subrc EQ 0.
          wa_final-amttrnf = wa_anep-anbtr.
          CLEAR:wa_anep.
        ENDIF.

**        READ TABLE it_ekpo INTO wa_ekpo WITH KEY ebeln = wa_ekkn-ebeln
**                                                 ebelp = wa_ekkn-ebelp.
        READ TABLE lt_po INTO ls_po WITH KEY ebeln = wa_ekkn-ebeln ebelp = wa_ekkn-ebelp BINARY SEARCH.
        IF sy-subrc EQ 0.

          IF ls_po-matnr IS INITIAL.
            wa_final-maktx = ls_po-txz01 .
          ENDIF.


**          READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekpo-ebeln.
**          IF sy-subrc EQ 0.

          wa_final-budat = ls_po-bedat.
          wa_final-lifnr = ls_po-lifnr.
          wa_final-bsart = ls_po-bsart.

          wa_final-wkurs = ls_po-wkurs .

**            READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
**            IF sy-subrc EQ 0.

          CONCATENATE ls_po-name1 ls_po-name2 INTO wa_final-name1.
**              wa_final-name1 = v_vendor.
**              CLEAR:v_vendor.
**              CLEAR:wa_lfa1.
**            ENDIF.
**            CLEAR:wa_ekko.
**          ENDIF."End of EKKO

**          READ TABLE it_makt INTO wa_makt WITH KEY matnr =  wa_ekpo-matnr.
**          IF sy-subrc EQ 0.
          wa_final-maktx =  ls_po-maktx.
**            CLEAR:wa_makt.
**          ENDIF.
          "Comment Start by Rahul Vasita on 12.04.2024 09:45:58
          READ TABLE it_rseg INTO wa_rseg WITH KEY ebeln = ls_po-ebeln
                                                   ebelp = ls_po-ebelp BINARY SEARCH.
          IF sy-subrc EQ 0.
            wa_final-buzei = wa_rseg-buzei.
            CLEAR:wa_rseg.
          ENDIF.
          "Comment End by Rahul Vasita on 12.04.2024 09:45:58
**Excise
*
*        READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = wa_ekpo-ebeln
*                                                    ritem1 = wa_ekpo-ebelp.
*        IF sy-subrc EQ 0.
*          wa_final-amount = wa_excise-exbas.
*          wa_final-bed    = wa_excise-exbed.
*          CLEAR:wa_excise.
*        ENDIF.
*          LOOP AT it_ekbz2 INTO wa_ekbz2 WHERE ebeln = wa_ekpo-ebeln
          LOOP AT it_ekbe2 INTO wa_ekbe2 WHERE ebeln = ls_po-ebeln
                                         AND ebelp = ls_po-ebelp.
**            wa_final-buzei = wa_ekbe2-buzei. "Added by Rahul Vasita on 12.04.2024 10:01:26
*            wa_final-poamt    = ls_po-netwr * wa_final-wkurs  .
            wa_final-matnr    = ls_po-matnr.
**            wa_final-werks    = ls_po-werks. "Comment by Rahul Vasita on 19.04.2024 14:38:36
            wa_final-menge    = ' '.
            wa_final-ebeln = wa_ekbe2-ebeln.
            wa_final-ebelp = wa_ekbe2-ebelp.
            wa_final-ek_curr = wa_ekbe2-waers.

            IF wa_ekbe2-shkzg = 'H'.
              wa_final-finalamt = wa_ekbe2-wrbtr  * ( - 1 ).
              wa_final-poamt    = ( ls_po-netwr * wa_final-wkurs )  * ( - 1 ) .
              wa_final-miquan   = wa_ekbe2-menge .
              wa_final-miamt   =  ( wa_ekbe2-wrbtr * wa_final-wkurs ) * ( - 1 ).
            ELSE.
              wa_final-finalamt = wa_ekbe2-wrbtr .
              wa_final-poamt    = ls_po-netwr * wa_final-wkurs  .
              wa_final-miquan   = wa_ekbe2-menge.
              wa_final-miamt   = wa_ekbe2-wrbtr * wa_final-wkurs .
            ENDIF.
            wa_final-belnr    = wa_ekbe2-belnr.
            wa_final-midate   = wa_ekbe2-budat.

*            wa_final-miquan   = wa_ekbz2-menge.
*            wa_final-miamt   = wa_ekbz2-wrbtr * wa_final-wkurs  .

            READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_ekbe2-belnr
                                                      gjahr = wa_ekbe2-gjahr BINARY SEARCH.
            wa_final-miref     = wa_rbkp-xblnr.
            wa_final-midocdate = wa_rbkp-bldat.

            CONCATENATE wa_ekbe2-belnr wa_ekbe2-gjahr INTO v_awkey.

            READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
            IF sy-subrc EQ 0.
              wa_final-fidoc = wa_bkpf-belnr.
              wa_final-fipdate = wa_bkpf-budat .
            ENDIF.
            CONCATENATE wa_ekbe2-lfgja wa_ekbe2-lfbnr wa_ekbe2-lfpos INTO wa_final-xref3.
            IF wa_final-xref3 EQ '00000000'.
              CLEAR : wa_final-xref3.
            ENDIF.
            wa_final-indic = 'P'.  "Added by Rahul Vasita on 15.04.2024 10:36:28
            APPEND wa_final TO it_final.
            CLEAR : wa_final-finalamt.

          ENDLOOP.
          LOOP AT it_ekbe INTO wa_ekbe WHERE ebeln = ls_po-ebeln
                                         AND ebelp = ls_po-ebelp.
**            wa_final-buzei = wa_ekbe-buzei. "Added by Rahul Vasita on 12.04.2024 10:01:11
*****-----------------------------------------------------------Added on 03.10.2019
            LOOP AT it_ekbz1 INTO wa_ekbz1 WHERE ebeln = wa_ekbe-ebeln
                                            AND ebelp = wa_ekbe-ebelp.
              count1 = count1 + 1.
              wa_ekbz1-count1 = count1.

              MODIFY it_ekbz1 FROM wa_ekbz1.


*            CLEAR : i.
            ENDLOOP.
            CLEAR : count1.
*****-----------------------------------------------------------End of changes on 03.10.2019
*          cno = cno + 1.
*          wa_final-cno = cno.
            wa_final-ek_curr = wa_ekbe-waers.
            wa_final-shkzg = wa_ekbe-shkzg.
            wa_final-1buzei = wa_ekbe-buzei. " added on 02.10.2019
            IF wa_ekbe-shkzg EQ 'S'.
              wa_final-menge =  wa_ekbe-menge.
              wa_final-dmbtr =  wa_ekbe-dmbtr.
            ELSE.
              wa_final-menge =  wa_ekbe-menge ."* ( - 1 ).
              wa_final-dmbtr =  wa_ekbe-menge * ( - 1 ).
            ENDIF.
*Excise
            READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = ls_po-ebeln
                                                        rdoc2 = wa_ekbe-belnr
                                                        ritem1 = ls_po-ebelp
                                                         BINARY SEARCH.
            IF sy-subrc EQ 0.
              wa_final-amount = wa_excise-exbas.
              wa_final-bed    = wa_excise-exbed.
              CLEAR:wa_excise.
            ENDIF.

            READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                       ebelp = ls_po-ebelp
                                                       xblnr = wa_ekbe-xblnr
                                                       lfbnr = wa_ekbe-lfbnr
                                                       lfpos = wa_ekbe-lfpos.
*                                                     buzei = wa_ekbe-buzei.    " comment 21.09.2019
*                                                     buzei = wa_final-cno.    " added 21.09.2019
*                                                     buzei = wa_final-buzei.
            IF sy-subrc EQ 0.
              wa_final-ek_curr = wa_ekbe1-waers.
              wa_final-1buzei = wa_ekbe1-buzei.   " added on 02.10.2019
              wa_final-belnr    = wa_ekbe1-belnr.
*            wa_final-miquan   = wa_ekbe1-menge.
              wa_final-midate   = wa_ekbe1-budat.
              CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
              IF wa_final-xref3 EQ '00000000'.
                CLEAR : wa_final-xref3.
              ENDIF.
              IF wa_final-bsart EQ 'SERV'.

                "Comment Start by Rahul Vasita on 13.03.2024 17:28:01
**                LOOP AT it_eslh INTO wa_eslh WHERE ebeln = wa_ekpo-ebeln
**                                               AND ebelp = wa_ekpo-ebelp.
**
**                  LOOP AT it_esll INTO wa_esll WHERE packno = wa_eslh-packno
**                and introw = wa_ekbe-introw.
                "Comment End by Rahul Vasita on 13.03.2024 17:28:01
**                LOOP AT lt_es INTO ls_es  WHERE ebeln = ls_po-ebeln "Comment by Rahul Vasita on 16.08.2024 11:56:19
                LOOP AT lt_wbses INTO ls_es  WHERE ebeln = ls_po-ebeln "Added by Rahul Vasita on 16.08.2024 11:56:21
                                            AND ebelp = ls_po-ebelp
                                            AND introw = wa_ekbe-introw.

                  READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                             ebelp = ls_po-ebelp
                                                             xblnr = wa_ekbe-xblnr
                                                             introw = ls_es-introw.
                  IF sy-subrc EQ 0.
                    wa_final-ek_curr = wa_ekbe1-waers.
                    wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                    IF wa_ekbe-shkzg EQ 'S'.
                      wa_final-miamt    = wa_ekbe1-dmbtr.
                      wa_final-miquan   = wa_ekbe1-menge.
                      wa_final-finalamt = wa_ekbe1-dmbtr.

                    ELSE.
                      wa_final-miamt    = wa_ekbe1-dmbtr * ( -1 ).
                      wa_final-miquan   = wa_ekbe1-menge .
                      wa_final-finalamt = wa_ekbe1-dmbtr * ( -1 ).
                    ENDIF.
                  ENDIF.
                  READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                      buzei = wa_ekbe1-buzei
                                                      ebeln = ls_po-ebeln
                                                      ebelp = ls_po-ebelp
                                                      xblnr = wa_ekbe-xblnr BINARY SEARCH.
                  IF wa_rseg1-shkzg = 'S'.
                    wa_final-basic = wa_rseg1-wrbtr .
                  ELSE.
                    wa_final-basic = wa_rseg1-wrbtr * ( - 1 ).
                  ENDIF.

*                  IF wa_ekbe-shkzg EQ 'S'.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr.
*                  ELSE.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr * ( -1 ).
*                  ENDIF.
                  CLEAR ls_es.
                ENDLOOP."End of LT_ES
**                  ENDLOOP."it_esll "Comment by Rahul Vasita on 13.03.2024 17:27:17
**                ENDLOOP."it_eslh "Comment by Rahul Vasita on 13.03.2024 17:27:23

              ELSE.
                READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                         buzei = wa_ekbe1-buzei
                                                         ebeln = ls_po-ebeln
                                                         ebelp = ls_po-ebelp
                                                         xblnr = wa_ekbe-xblnr BINARY SEARCH.
                wa_final-miquan   = wa_ekbe1-menge.
                IF wa_ekbe1-shkzg = 'H'.
                  wa_final-miamt    = wa_ekbe1-dmbtr * ( - 1 ).
                ELSE.
                  wa_final-miamt    = wa_ekbe1-dmbtr.
                ENDIF.
                IF wa_ekbe-shkzg EQ 'S'.
                  wa_final-finalamt = wa_ekbe1-refwr.
                ELSE.
                  wa_final-finalamt = wa_ekbe1-refwr * ( -1 ).
                ENDIF.
              ENDIF.

******************* Added

*            READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
*                                                       ebeln = wa_ekpo-ebeln
*                                                       ebelp = wa_ekpo-ebelp
*                                                       xblnr = wa_ekbe-xblnr.
* wa_final-basic = wa_rseg1-wrbtr .

              READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                       gjahr = wa_rseg1-gjahr BINARY SEARCH.
              wa_final-miref     = wa_rbkp-xblnr.
              wa_final-midocdate = wa_rbkp-bldat.

********************* end of changes1
              count = count + 1.
              IF count EQ 1.
                wa_final-ind = 'X'.
              ENDIF.
              srno = srno + 1.
              wa_final-srno = srno.

*---------------------------------Added on 23.09.2019----------------------------------------------------
            ELSE.
              READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                      ebelp = ls_po-ebelp
                                                      xblnr = wa_ekbe-xblnr.
*                                                     buzei = wa_ekbe-buzei.    " comment 21.09.2019
*                                                     buzei = wa_final-cno.    " added 21.09.2019
*                                                     buzei = wa_final-buzei.
              IF sy-subrc EQ 0.
                wa_final-ek_curr = wa_ekbe1-waers.
                wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                wa_final-belnr    = wa_ekbe1-belnr.
*            wa_final-miquan   = wa_ekbe1-menge.
                wa_final-midate   = wa_ekbe1-budat.
                CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
                IF wa_final-xref3 EQ '00000000'.
                  CLEAR : wa_final-xref3.
                ENDIF.
                IF wa_final-bsart EQ 'SERV'.

                  "Comment Start by Rahul Vasita on 13.03.2024 17:29:04
**                  LOOP AT it_eslh INTO wa_eslh WHERE ebeln = wa_ekpo-ebeln
**                                                 AND ebelp = wa_ekpo-ebelp.
**
**                    LOOP AT it_esll INTO wa_esll WHERE packno = wa_eslh-packno
**                                                   AND introw = wa_ekbe-introw.
                  "Comment End by Rahul Vasita on 13.03.2024 17:29:04
**                  LOOP AT lt_es INTO ls_es WHERE ebeln = ls_po-ebeln AND ebelp = ls_po-ebelp AND introw = wa_ekbe-introw. "Comment by Rahul Vasita on 16.08.2024 11:57:05
                  LOOP AT lt_wbses INTO ls_es WHERE ebeln = ls_po-ebeln AND ebelp = ls_po-ebelp AND introw = wa_ekbe-introw. "Added by Rahul Vasita on 16.08.2024 11:57:07


                    READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                               ebelp = ls_po-ebelp
                                                               xblnr = wa_ekbe-xblnr
                                                               introw = ls_es-introw.
                    IF sy-subrc EQ 0.
                      wa_final-ek_curr = wa_ekbe1-waers.
                      wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                      IF wa_ekbe-shkzg EQ 'S'.
                        wa_final-miamt    = wa_ekbe1-dmbtr.
                        wa_final-miquan   = wa_ekbe1-menge.
                        wa_final-finalamt = wa_ekbe1-dmbtr.

                      ELSE.
                        wa_final-miamt    = wa_ekbe1-dmbtr * ( -1 ).
                        wa_final-miquan   = wa_ekbe1-menge .
                        wa_final-finalamt = wa_ekbe1-dmbtr * ( -1 ).
                      ENDIF.
                    ENDIF.
                    READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                        buzei = wa_ekbe1-buzei
                                                        ebeln = ls_po-ebeln
                                                        ebelp = ls_po-ebelp
                                                        xblnr = wa_ekbe-xblnr
                                                         BINARY SEARCH.
                    IF wa_rseg1-shkzg = 'H'.
                      wa_final-basic = wa_rseg1-wrbtr  * ( - 1 ).
                    ELSE.
                      wa_final-basic = wa_rseg1-wrbtr .
                    ENDIF.
*                  IF wa_ekbe-shkzg EQ 'S'.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr.
*                  ELSE.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr * ( -1 ).
*                  ENDIF.
                    CLEAR ls_es.
                  ENDLOOP."ENd of LT_BS
**                    ENDLOOP."ELSS "Comment by Rahul Vasita on 13.03.2024 17:28:48
**                  ENDLOOP."ELSH "Comment by Rahul Vasita on 13.03.2024 17:28:45

                ELSE.
                  READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                           buzei = wa_ekbe1-buzei
                                                           ebeln = ls_po-ebeln
                                                           ebelp = ls_po-ebelp
                                                           xblnr = wa_ekbe-xblnr
                                                            BINARY SEARCH.
                  wa_final-miquan   = wa_ekbe1-menge.

                  IF wa_ekbe1-shkzg = 'H'.
                    wa_final-miamt    = wa_ekbe1-dmbtr * ( - 1 ).
                  ELSE.
                    wa_final-miamt    = wa_ekbe1-dmbtr.
                  ENDIF.
                  IF wa_ekbe-shkzg EQ 'S'.
                    wa_final-finalamt = wa_ekbe1-refwr.
                  ELSE.
                    wa_final-finalamt = wa_ekbe1-refwr * ( -1 ).
                  ENDIF.
                ENDIF.

******************* Added

*            READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
*                                                       ebeln = wa_ekpo-ebeln
*                                                       ebelp = wa_ekpo-ebelp
*                                                       xblnr = wa_ekbe-xblnr.
* wa_final-basic = wa_rseg1-wrbtr .

                READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                         gjahr = wa_rseg1-gjahr BINARY SEARCH.
                wa_final-miref     = wa_rbkp-xblnr.
                wa_final-midocdate = wa_rbkp-bldat.

********************* end of changes1
                count = count + 1.
                IF count EQ 1.
                  wa_final-ind = 'X'.
                ENDIF.
                srno = srno + 1.
                wa_final-srno = srno.
              ENDIF.
*---------------------------------End of changes on 23.09.2019-------------------------------------------
            ENDIF.
***********************************************************************************************Added on 19.09.2019
*          LOOP AT it_rseg INTO wa_rseg.
*            READ TABLE r_rseg WITH KEY belnr = wa_rseg-belnr
*                             gjahr = wa_bseg-gjahr.
*            IF sy-subrc NE 0.
*              r_rseg-belnr = wa_rseg-belnr.
*              r_rseg-gjahr = wa_rseg-gjahr.
*              APPEND r_rseg.
*              CLEAR  r_rseg.
*            ENDIF.
*          ENDLOOP.
*
*          SORT r_rseg BY belnr gjahr.
*          DELETE ADJACENT DUPLICATES FROM r_rseg COMPARING belnr gjahr.
*          SORT r_rseg BY belnr gjahr.
*
*          SORT it_rseg BY belnr buzei.                                              "LINE ADD 03.03.2009
*
*          LOOP AT r_rseg.
*            i = 1.
*            LOOP AT it_rseg INTO wa_rseg WHERE belnr = r_rseg-belnr
*                              AND gjahr = r_rseg-gjahr.
*              wa_rseg-count1 = i.
*              i = i + 1.
*              MODIFY it_rseg FROM wa_rseg.
*            ENDLOOP.
*            CLEAR : i.
*          ENDLOOP.
*******************************************************************************************End of changes


            wa_final-meins    = ls_po-meins.
            wa_final-netpr    = ls_po-netpr.
*          wa_final-poamt    = wa_ekpo-netwr.
            wa_final-poamt    = ls_po-netwr * wa_final-wkurs .
            wa_final-matnr    = ls_po-matnr.
**            wa_final-werks    = ls_po-werks. "Comment by Rahul Vasita on 19.04.2024 14:39:41
            wa_final-migodate = wa_ekbe-budat.
            wa_final-ebeln    = wa_ekbe-ebeln.
            wa_final-ebelp    = wa_ekbe-ebelp.
            wa_final-mblnr    = wa_ekbe-belnr.

            READ TABLE it_fi INTO wa_fi WITH KEY belnr = wa_final-belnr BINARY SEARCH.
            IF sy-subrc EQ 0.
              CONCATENATE wa_fi-belnr wa_fi-gjahr INTO v_awkey.

              READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
              IF sy-subrc EQ 0.
                wa_final-fidoc = wa_bkpf-belnr.
                wa_final-fipdate = wa_bkpf-budat .
              ENDIF.
            ENDIF.

            wa_final-indic = 'P'.  "Added by Rahul Vasita on 15.04.2024 10:36:28
            APPEND wa_final TO it_final.
            CLEAR:wa_final-ind,wa_final-belnr,wa_final-cno.",wa_final. "Comment by Rahul Vasita on 22.04.2024 09:40:54
            CLEAR : wa_final-miamt , wa_final-midate , wa_final-midocdate , wa_final-miquan , wa_final-miref ,wa_final-finalamt,
                    wa_final-fidoc , wa_final-fipdate. "Added by Rahul Vasita on 22.04.2024 14:19:53
            CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1,wa_eslh,wa_esll,wa_rbkp,wa_rseg.
          ENDLOOP.
          CLEAR:count,srno,count1.
********************************************Added by Raj on 29.09.2023*****************************************
**          SELECT pspnr,objnr FROM prps INTO TABLE @DATA(it_prps) FOR ALL ENTRIES IN @it_ekkn WHERE pspnr = @it_ekkn-ps_psp_pnr.
**          SELECT OBJNR,refbn,refbk,refgj FROM covp INTO TABLE @DATA(it_covp) FOR ALL ENTRIES IN  @it_prps WHERE objnr = @it_prps-OBJNR.

*******************************************Added by Raj on 28.09.2023******************************************
*        COUNT = 1.

*        APPEND wa_final TO it_final.
*        CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1.

*If there is no MIgo of any PO.


          IF sy-subrc NE 0.

            LOOP AT it_ekbe1 INTO wa_ekbe1 WHERE ebeln = ls_po-ebeln
                                             AND ebelp = ls_po-ebelp.
**              wa_final-buzei = wa_ekbe1-buzei. "Added by Rahul Vasita on 12.04.2024 09:57:27
              wa_final-shkzg = wa_ekbe1-shkzg.
              wa_final-ek_curr = wa_ekbe1-waers.
              wa_final-belnr = wa_ekbe1-belnr.   " Added on 02.10.2019
              wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
              IF wa_ekbe1-shkzg EQ 'S'.
                wa_final-miamt = wa_ekbe1-dmbtr.
                wa_final-finalamt = wa_ekbe1-refwr.
              ELSE.
                wa_final-miamt = wa_ekbe1-dmbtr     * ( -1 ).
                wa_final-finalamt = wa_ekbe1-refwr  * ( -1 ).
              ENDIF.
              CLEAR : wa_final-menge.
              wa_final-miquan = wa_ekbe1-menge.
              wa_final-midate = wa_ekbe1-budat.
*            wa_final-finalamt = wa_ekbe1-refwr.
              CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
              IF wa_final-xref3 EQ '00000000'.
                CLEAR : wa_final-xref3.
              ENDIF.
*******************************            Added on 23.09.2019
              READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                               buzei = wa_ekbe1-buzei
                                                               ebeln = ls_po-ebeln
                                                               ebelp = ls_po-ebelp
                                                               xblnr = wa_ekbe1-xblnr
                                                                BINARY SEARCH.

              IF wa_rseg1-shkzg = 'H'.
                wa_final-basic = wa_rseg1-wrbtr  * ( - 1 ).
              ELSE.
                wa_final-basic = wa_rseg1-wrbtr .
              ENDIF.
              READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                         gjahr = wa_rseg1-gjahr BINARY SEARCH.
              wa_final-miref     = wa_rbkp-xblnr.
              wa_final-midocdate = wa_rbkp-bldat.

***********************  End of changes on 23.09.2019
              READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = ls_po-ebeln
                                               ritem1 = ls_po-ebelp BINARY SEARCH.
              IF sy-subrc EQ 0.

                wa_final-amount = wa_excise-exbas.
                wa_final-bed    = wa_excise-exbed.
                CLEAR:wa_excise.
              ENDIF.

              wa_final-meins = ls_po-meins.
              wa_final-netpr = ls_po-netpr.
*            wa_final-poamt = wa_ekpo-netwr.

              IF wa_ekbe1-shkzg = 'H'.
                wa_final-poamt    = ( ls_po-netwr * wa_final-wkurs ) * ( - 1 ).
              ELSE.
                wa_final-poamt    = ls_po-netwr * wa_final-wkurs .
              ENDIF.
              wa_final-matnr = ls_po-matnr.
**              wa_final-werks = ls_po-werks.  "Comment by Rahul Vasita on 19.04.2024 14:39:57

*            wa_final-migodate = wa_ekbe1-budat.
              wa_final-ebeln = wa_ekbe1-ebeln.
              wa_final-ebelp = wa_ekbe1-ebelp.
*            wa_final-mblnr = wa_ekbe1-belnr.

              READ TABLE it_fi INTO wa_fi WITH KEY belnr = wa_final-belnr BINARY SEARCH.
              IF sy-subrc EQ 0.

                CONCATENATE wa_fi-belnr wa_fi-gjahr INTO v_awkey.

                READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
                IF sy-subrc EQ 0.
                  wa_final-fidoc = wa_bkpf-belnr.
                  wa_final-fipdate = wa_bkpf-budat .
                ENDIF.

              ENDIF.

              IF wa_ekbe1-shkzg EQ 'S'.
*              wa_final-menge = wa_ekbe1-menge.
                wa_final-dmbtr = wa_ekbe1-dmbtr.
              ELSE.
*              wa_final-menge = wa_ekbe1-menge * ( -1 ).
                wa_final-dmbtr = wa_ekbe1-dmbtr * ( -1 ).
              ENDIF.
              srno = srno + 1.
              wa_final-srno = srno.

              wa_final-indic = 'P'.  "Added by Rahul Vasita on 15.04.2024 10:36:28
              APPEND wa_final TO it_final.
              CLEAR : wa_final-miamt , wa_final-midate , wa_final-midocdate , wa_final-miquan , wa_final-miref ,wa_final-finalamt,
                      wa_final-fidoc , wa_final-fipdate. "Added by Rahul Vasita on 22.04.2024 14:19:53
              CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1,srno.
            ENDLOOP.
          ENDIF.
          CLEAR:ls_po.
        ENDIF.
        CLEAR:wa_final,wa_ekkn,wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1.
      ENDLOOP.

      CLEAR:wa_final,wa_anla.
    ELSE.
      LOOP AT it_ekkn INTO wa_ekkn WHERE anln1 = wa_anla-anln1 . " changed on 10.11.2021
        " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*        SELECT SINGLE werks FROM anlz INTO wa_final-werks WHERE bukrs = wa_anla-bukrs AND anln1 = wa_anla-anln1 AND bdatu = '99991231'.

        SELECT werks FROM anlz INTO wa_final-werks UP TO 1 ROWS WHERE bukrs = wa_anla-bukrs AND anln1 = wa_anla-anln1 AND bdatu = '99991231' ORDER BY PRIMARY KEY.ENDSELECT.
        " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
        MOVE-CORRESPONDING wa_anla TO wa_final.
*
        CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
          EXPORTING
            input  = wa_ekkn-ps_psp_pnr
          IMPORTING
            output = wa_final-ps_psp_pnr.

*      wa_final-ps_psp_pnr = wa_ekkn-ps_psp_pnr.
        READ TABLE it_anep INTO wa_anep WITH KEY anln1 = wa_anla-anln1.
        IF sy-subrc EQ 0.
          wa_final-amttrnf = wa_anep-anbtr.
          CLEAR:wa_anep.
        ENDIF.

        READ TABLE lt_po INTO ls_po WITH KEY ebeln = wa_ekkn-ebeln
                                                 ebelp = wa_ekkn-ebelp BINARY SEARCH.
**        READ TABLE it_ekpo INTO wa_ekpo WITH KEY ebeln = wa_ekkn-ebeln
**                                                 ebelp = wa_ekkn-ebelp.
        IF sy-subrc EQ 0.
          IF ls_po-matnr IS INITIAL.
            wa_final-maktx = ls_po-txz01 .
          ENDIF.


**          READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekpo-ebeln.
**          IF sy-subrc EQ 0.

          wa_final-budat = ls_po-bedat.
          wa_final-lifnr = ls_po-lifnr.
          wa_final-bsart = ls_po-bsart.

          wa_final-wkurs = ls_po-wkurs .

**            READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
**            IF sy-subrc EQ 0.

          CONCATENATE ls_po-name1 ls_po-name2 INTO v_vendor.
          wa_final-name1 = v_vendor.
**              CLEAR:v_vendor.
**              CLEAR:wa_lfa1.
**            ENDIF.
**            CLEAR:wa_ekko.
*          ENDIF."EKKO

**          READ TABLE it_makt INTO wa_makt WITH KEY matnr =  wa_ekpo-matnr.
**          IF sy-subrc EQ 0.
          wa_final-maktx =  ls_po-maktx.
**            CLEAR:wa_makt.
**          ENDIF.

          "Comment Start by Rahul Vasita on 12.04.2024 09:46:30
          READ TABLE it_rseg INTO wa_rseg WITH KEY ebeln = ls_po-ebeln
                                                   ebelp = ls_po-ebelp BINARY SEARCH.
          IF sy-subrc EQ 0.
            wa_final-buzei = wa_rseg-buzei.
            CLEAR:wa_rseg.
          ENDIF.
          "Comment End by Rahul Vasita on 12.04.2024 09:46:30
**Excise
*
*        READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = wa_ekpo-ebeln
*                                                    ritem1 = wa_ekpo-ebelp.
*        IF sy-subrc EQ 0.
*          wa_final-amount = wa_excise-exbas.
*          wa_final-bed    = wa_excise-exbed.
*          CLEAR:wa_excise.
*        ENDIF.
          LOOP AT it_ekbe2 INTO wa_ekbe2 WHERE ebeln = ls_po-ebeln
                                         AND ebelp = ls_po-ebelp.
**            wa_final-buzei  = wa_ekbe2-buzei.  "Added by Rahul Vasita on 12.04.2024 09:47:21
            wa_final-1buzei = wa_ekbe2-buzei.
*            wa_final-poamt    = wa_ekpo-netwr * wa_final-wkurs  .
            wa_final-matnr    = ls_po-matnr.
**            wa_final-werks    = ls_po-werks. "Comment by Rahul Vasita on 19.04.2024 14:40:24
            wa_final-menge    = ' '.
            wa_final-ebeln = wa_ekbe2-ebeln.
            wa_final-ebelp = wa_ekbe2-ebelp.
            wa_final-ek_curr = wa_ekbe2-waers.
*            wa_final-finalamt = wa_ekbe2-wrbtr .
            wa_final-belnr    = wa_ekbe2-belnr.
            wa_final-midate   = wa_ekbe2-budat.

*            wa_final-miquan   = wa_ekbz2-menge.
*            wa_final-miamt   = wa_ekbz2-wrbtr * wa_final-wkurs  .




            IF wa_ekbe2-shkzg = 'H'.
              wa_final-poamt    = ( ls_po-netwr * wa_final-wkurs  ) * ( - 1 ).
              wa_final-miquan   = wa_ekbe2-menge * ( - 1 ).
              wa_final-miamt   = ( wa_ekbe2-wrbtr * wa_final-wkurs  ) * ( - 1 ).
              wa_final-finalamt = wa_ekbe2-wrbtr * ( - 1 ) .
            ELSE.
              wa_final-poamt    = ls_po-netwr * wa_final-wkurs  .
              wa_final-miquan   = wa_ekbe2-menge.
              wa_final-miamt   = wa_ekbe2-wrbtr * wa_final-wkurs  .
              wa_final-finalamt = wa_ekbe2-wrbtr .

            ENDIF.

            READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_ekbe2-belnr
                                                      gjahr = wa_ekbe2-gjahr BINARY SEARCH.
            IF sy-subrc = 0.
              wa_final-miref     = wa_rbkp-xblnr.
              wa_final-midocdate = wa_rbkp-bldat.
            ENDIF.

            CONCATENATE wa_ekbe2-belnr wa_ekbe2-gjahr INTO v_awkey.

            READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
            IF sy-subrc EQ 0.
              wa_final-fidoc = wa_bkpf-belnr.
              wa_final-fipdate = wa_bkpf-budat .
            ENDIF.
            CONCATENATE wa_ekbe2-lfgja wa_ekbe2-lfbnr wa_ekbe2-lfpos INTO wa_final-xref3.
            IF wa_final-xref3 EQ '00000000'.
              CLEAR : wa_final-xref3.
            ENDIF.
            wa_final-indic = 'P'. "Added by Rahul Vasita on 15.04.2024 11:49:58
            APPEND wa_final TO it_final.
            CLEAR : wa_final-finalamt.

          ENDLOOP.
          LOOP AT it_ekbe INTO wa_ekbe WHERE ebeln = ls_po-ebeln
                                         AND ebelp = ls_po-ebelp.
*****-----------------------------------------------------------Added on 03.10.2019
            LOOP AT it_ekbz1 INTO wa_ekbz1 WHERE ebeln = wa_ekbe-ebeln
                                            AND ebelp = wa_ekbe-ebelp.
              count1 = count1 + 1.
              wa_ekbz1-count1 = count1.

              MODIFY it_ekbz1 FROM wa_ekbz1.


*            CLEAR : i.
            ENDLOOP.
            CLEAR : count1.
*****-----------------------------------------------------------End of changes on 03.10.2019
*          cno = cno + 1.
*          wa_final-cno = cno.
**            wa_final-buzei = wa_ekbe-buzei. "Added by Rahul Vasita on 12.04.2024 09:51:55
            wa_final-ek_curr = wa_ekbe-waers.
            wa_final-shkzg = wa_ekbe-shkzg.
            wa_final-1buzei = wa_ekbe-buzei. " added on 02.10.2019
            IF wa_ekbe-shkzg EQ 'S'.
              wa_final-menge =  wa_ekbe-menge.
              wa_final-dmbtr =  wa_ekbe-dmbtr.
            ELSE.
              wa_final-menge =  wa_ekbe-menge.
              wa_final-dmbtr =  wa_ekbe-menge.
            ENDIF.
*Excise
            READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = ls_po-ebeln
                                                        rdoc2 = wa_ekbe-belnr
                                                        ritem1 = ls_po-ebelp BINARY SEARCH.
            IF sy-subrc EQ 0.
              wa_final-amount = wa_excise-exbas.
              wa_final-bed    = wa_excise-exbed.
              CLEAR:wa_excise.
            ENDIF.

            READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                       ebelp = ls_po-ebelp
                                                       xblnr = wa_ekbe-xblnr
                                                       lfbnr = wa_ekbe-lfbnr
                                                       lfpos = wa_ekbe-lfpos.
*                                                     buzei = wa_ekbe-buzei.    " comment 21.09.2019
*                                                     buzei = wa_final-cno.    " added 21.09.2019
*                                                     buzei = wa_final-buzei.
            IF sy-subrc EQ 0.

              LOOP AT it_ekbe1 INTO DATA(wa_ekbe1_t) WHERE ebeln = ls_po-ebeln
                                                      AND  ebelp = ls_po-ebelp
                                                      AND  xblnr = wa_ekbe-xblnr
                                                      AND  lfbnr = wa_ekbe-lfbnr
                                                      AND  lfpos = wa_ekbe-lfpos.

                READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_ekbe1_t-belnr.
                IF sy-subrc = 0.
                  IF wa_rbkp-stblg IS NOT INITIAL.
                    CLEAR: wa_rbkp,wa_ekbe1_t.
                    CONTINUE.
                  ELSE.
                    wa_ekbe1 = wa_ekbe1_t.
                  ENDIF.
                ENDIF.

              ENDLOOP.
              wa_final-ek_curr = wa_ekbe1-waers.
              wa_final-1buzei = wa_ekbe1-buzei.   " added on 02.10.2019
              wa_final-belnr    = wa_ekbe1-belnr.
*            wa_final-miquan   = wa_ekbe1-menge.
              wa_final-midate   = wa_ekbe1-budat.
              CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
              IF wa_final-xref3 EQ '00000000'.
                CLEAR : wa_final-xref3.
              ENDIF.
              IF wa_final-bsart EQ 'SERV'.

*                LOOP AT it_eslh INTO wa_eslh WHERE ebeln = wa_ekpo-ebeln  "Commented by Raj on 04.09.2023
*                                               AND ebelp = wa_ekpo-ebelp.

*                  LOOP AT it_esll INTO wa_esll WHERE packno = wa_eslh-packno.
*                                                 AND introw = wa_ekbe-introw.

                READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                           ebelp = ls_po-ebelp
                                                           xblnr = wa_ekbe-xblnr
*                                                               introw = wa_esll-introw.
                                                            lfbnr = wa_ekbe-lfbnr
                                                            lfpos = wa_ekbe-lfpos
                                                            gjahr = wa_ekbe-gjahr.


                IF sy-subrc EQ 0.
                  wa_final-ek_curr = wa_ekbe1-waers.
                  wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                  IF wa_ekbe-shkzg EQ 'S'.
                    wa_final-miamt    = wa_ekbe1-dmbtr.
                    wa_final-miquan   = wa_ekbe1-menge.
                    wa_final-finalamt = wa_ekbe1-dmbtr.

                  ELSE.
                    wa_final-miamt    = wa_ekbe1-dmbtr * ( -1 ).
                    wa_final-miquan   = wa_ekbe1-menge .
                    wa_final-finalamt = wa_ekbe1-dmbtr * ( -1 ).
                  ENDIF.
                ENDIF.
                READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                    buzei = wa_ekbe1-buzei
                                                    ebeln = ls_po-ebeln
                                                    ebelp = ls_po-ebelp
                                                    xblnr = wa_ekbe-xblnr
                                                     BINARY SEARCH.
                IF wa_rseg1-shkzg = 'H'.

                  wa_final-basic = wa_rseg1-wrbtr * ( - 1 ).

                ELSE.
                  wa_final-basic = wa_rseg1-wrbtr .
                ENDIF.

*                  IF wa_ekbe-shkzg EQ 'S'.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr.
*                  ELSE.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr * ( -1 ).
*                  ENDIF.

*                  ENDLOOP.
*                ENDLOOP.

              ELSE.
                READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                         buzei = wa_ekbe1-buzei
                                                         ebeln = ls_po-ebeln
                                                         ebelp = ls_po-ebelp
                                                         xblnr = wa_ekbe-xblnr
                                                          BINARY SEARCH.
                wa_final-miquan   = wa_ekbe1-menge.

                IF wa_ekbe1-shkzg = 'H'.
                  wa_final-miamt    = wa_ekbe1-dmbtr * ( - 1 ).
                ELSE.
                  wa_final-miamt    = wa_ekbe1-dmbtr.
                ENDIF.

                IF wa_ekbe-shkzg EQ 'S'.
                  wa_final-finalamt = wa_ekbe1-refwr.
                ELSE.
                  wa_final-finalamt = wa_ekbe1-refwr * ( -1 ).
                ENDIF.
              ENDIF.

******************* Added

*            READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
*                                                       ebeln = wa_ekpo-ebeln
*                                                       ebelp = wa_ekpo-ebelp
*                                                       xblnr = wa_ekbe-xblnr.
* wa_final-basic = wa_rseg1-wrbtr .

              READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                       gjahr = wa_rseg1-gjahr BINARY SEARCH.
              wa_final-miref     = wa_rbkp-xblnr.
              wa_final-midocdate = wa_rbkp-bldat.

********************* end of changes1
              count = count + 1.
              IF count EQ 1.
                wa_final-ind = 'X'.
              ENDIF.
              srno = srno + 1.
              wa_final-srno = srno.

*---------------------------------Added on 23.09.2019----------------------------------------------------
            ELSE.
              READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                      ebelp = ls_po-ebelp
                                                      xblnr = wa_ekbe-xblnr.
*                                                     buzei = wa_ekbe-buzei.    " comment 21.09.2019
*                                                     buzei = wa_final-cno.    " added 21.09.2019
*                                                     buzei = wa_final-buzei.
              IF sy-subrc EQ 0.
                wa_final-ek_curr = wa_ekbe1-waers.
                wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                wa_final-belnr    = wa_ekbe1-belnr.
*            wa_final-miquan   = wa_ekbe1-menge.
                wa_final-midate   = wa_ekbe1-budat.
                CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
                IF wa_final-xref3 EQ '00000000'.
                  CLEAR : wa_final-xref3.
                ENDIF.
                IF wa_final-bsart EQ 'SERV'.

                  "Comment Start by Rahul Vasita on 13.03.2024 17:31:54
**                  LOOP AT it_eslh INTO wa_eslh WHERE ebeln = wa_ekpo-ebeln
**                                                 AND ebelp = wa_ekpo-ebelp.
**
**                    LOOP AT it_esll INTO wa_esll WHERE packno = wa_eslh-packno
**                                                   AND introw = wa_ekbe-introw.
                  "Comment End by Rahul Vasita on 13.03.2024 17:31:54
                  LOOP AT lt_es INTO ls_es WHERE ebeln = ls_po-ebeln AND ebelp = ls_po-ebelp AND introw = wa_ekbe-introw.
                    READ TABLE it_ekbe1 INTO wa_ekbe1 WITH KEY ebeln = ls_po-ebeln
                                                               ebelp = ls_po-ebelp
                                                               xblnr = wa_ekbe-xblnr
                                                               lfbnr = wa_ekbe-lfbnr "Added  by Rutvi on 18.09.2024
                                                               introw = ls_es-introw.
                    IF sy-subrc EQ 0.
                      wa_final-ek_curr = wa_ekbe1-waers.
                      wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
                      IF wa_ekbe-shkzg EQ 'S'.
                        wa_final-miamt    = wa_ekbe1-dmbtr.
                        wa_final-miquan   = wa_ekbe1-menge.
                        wa_final-finalamt = wa_ekbe1-dmbtr.

                      ELSE.
                        wa_final-miamt    = wa_ekbe1-dmbtr * ( -1 ).
                        wa_final-miquan   = wa_ekbe1-menge .
                        wa_final-finalamt = wa_ekbe1-dmbtr * ( -1 ).
                      ENDIF.
                    ENDIF.
                    READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                        buzei = wa_ekbe1-buzei
                                                        ebeln = ls_po-ebeln
                                                        ebelp = ls_po-ebelp
                                                        xblnr = wa_ekbe-xblnr
                                                         BINARY SEARCH.
                    IF wa_rseg1-shkzg = 'H'.
                      wa_final-basic = wa_rseg1-wrbtr * ( - 1 ).
                    ELSE.
                      wa_final-basic = wa_rseg1-wrbtr .
                    ENDIF.

*                  IF wa_ekbe-shkzg EQ 'S'.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr.
*                  ELSE.
*                    wa_final-miquan   = wa_esll-menge.
*                    wa_final-finalamt = wa_esll-netwr * ( -1 ).
*                  ENDIF.
                    CLEAR ls_es.
                  ENDLOOP.
*                    ENDLOOP."END OF ESLL "Comment by Rahul Vasita on 13.03.2024 17:31:35
*                  ENDLOOP."END OF ELSH "Comment by Rahul Vasita on 13.03.2024 17:31:38

                ELSE.
                  READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                             buzei = wa_ekbe1-buzei
                                                           ebeln = ls_po-ebeln
                                                           ebelp = ls_po-ebelp
                                                           xblnr = wa_ekbe-xblnr
                                                            BINARY SEARCH.
                  wa_final-miquan   = wa_ekbe1-menge.

                  IF wa_ekbe1-shkzg = 'H'.
                    wa_final-miamt    = wa_ekbe1-dmbtr * ( -1  ).
                  ELSE.
                    wa_final-miamt    = wa_ekbe1-dmbtr.
                  ENDIF.
                  IF wa_ekbe-shkzg EQ 'S'.
                    wa_final-finalamt = wa_ekbe1-refwr.
                  ELSE.
                    wa_final-finalamt = wa_ekbe1-refwr * ( -1 ).
                  ENDIF.
                ENDIF.

******************* Added

*            READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
*                                                       ebeln = wa_ekpo-ebeln
*                                                       ebelp = wa_ekpo-ebelp
*                                                       xblnr = wa_ekbe-xblnr.
* wa_final-basic = wa_rseg1-wrbtr .

                READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                         gjahr = wa_rseg1-gjahr BINARY SEARCH.
                wa_final-miref     = wa_rbkp-xblnr.
                wa_final-midocdate = wa_rbkp-bldat.

********************* end of changes1
                count = count + 1.
                IF count EQ 1.
                  wa_final-ind = 'X'.
                ENDIF.
                srno = srno + 1.
                wa_final-srno = srno.
****************************Added by Rutvi on 18.09.2024
              ELSE.
                wa_final-basic = wa_ekbe-dmbtr.
*********************************************************
              ENDIF.
*---------------------------------End of changes on 23.09.2019-------------------------------------------
            ENDIF.
***********************************************************************************************Added on 19.09.2019
*          LOOP AT it_rseg INTO wa_rseg.
*            READ TABLE r_rseg WITH KEY belnr = wa_rseg-belnr
*                             gjahr = wa_bseg-gjahr.
*            IF sy-subrc NE 0.
*              r_rseg-belnr = wa_rseg-belnr.
*              r_rseg-gjahr = wa_rseg-gjahr.
*              APPEND r_rseg.
*              CLEAR  r_rseg.
*            ENDIF.
*          ENDLOOP.
*
*          SORT r_rseg BY belnr gjahr.
*          DELETE ADJACENT DUPLICATES FROM r_rseg COMPARING belnr gjahr.
*          SORT r_rseg BY belnr gjahr.
*
*          SORT it_rseg BY belnr buzei.                                              "LINE ADD 03.03.2009
*
*          LOOP AT r_rseg.
*            i = 1.
*            LOOP AT it_rseg INTO wa_rseg WHERE belnr = r_rseg-belnr
*                              AND gjahr = r_rseg-gjahr.
*              wa_rseg-count1 = i.
*              i = i + 1.
*              MODIFY it_rseg FROM wa_rseg.
*            ENDLOOP.
*            CLEAR : i.
*          ENDLOOP.
*******************************************************************************************End of changes


            wa_final-meins    = ls_po-meins.
            wa_final-netpr    = ls_po-netpr.
*          wa_final-poamt    = ls_po-netwr.
            wa_final-poamt    = ls_po-netwr * wa_final-wkurs .
            wa_final-matnr    = ls_po-matnr.
**            wa_final-werks    = ls_po-werks.  "Comment by Rahul Vasita on 19.04.2024 14:41:28
            wa_final-migodate = wa_ekbe-budat.
            wa_final-ebeln    = wa_ekbe-ebeln.
            wa_final-ebelp    = wa_ekbe-ebelp.
            wa_final-mblnr    = wa_ekbe-belnr.

            READ TABLE it_fi INTO wa_fi WITH KEY belnr = wa_final-belnr BINARY SEARCH.
            IF sy-subrc EQ 0.
              CONCATENATE wa_fi-belnr wa_fi-gjahr INTO v_awkey.

              READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
              IF sy-subrc EQ 0.
                wa_final-fidoc = wa_bkpf-belnr.
                wa_final-fipdate = wa_bkpf-budat .
              ENDIF.
            ENDIF.

            wa_final-indic = 'P'. "Added by Rahul Vasita on 15.04.2024 11:50:22
            APPEND wa_final TO it_final.
            CLEAR:wa_final-ind,wa_final-belnr,wa_final-cno.",wa_final. "Comment by Rahul Vasita on 22.04.2024 09:41:21
            CLEAR : wa_final-miamt , wa_final-midate , wa_final-midocdate , wa_final-miquan , wa_final-miref ,wa_final-finalamt,
                    wa_final-fidoc , wa_final-fipdate,wa_final-basic. "Added by Rahul Vasita on 22.04.2024 14:19:53
            CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1,wa_eslh,wa_esll,wa_rbkp,wa_rseg.
          ENDLOOP.
          CLEAR:count,srno,count1.
*        COUNT = 1.

*        APPEND wa_final TO it_final.
*        CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1.

*If there is no MIgo of any PO.

          IF sy-subrc NE 0.

            LOOP AT it_ekbe1 INTO wa_ekbe1 WHERE ebeln = ls_po-ebeln
                                             AND ebelp = ls_po-ebelp.
**              wa_final-buzei = wa_ekbe1-buzei. "Added by Rahul Vasita on 12.04.2024 09:56:03
              wa_final-shkzg = wa_ekbe1-shkzg.
              wa_final-ek_curr = wa_ekbe1-waers.
              wa_final-belnr = wa_ekbe1-belnr.   " Added on 02.10.2019
              wa_final-1buzei = wa_ekbe1-buzei.   " Added on 02.10.2019
              IF wa_ekbe1-shkzg EQ 'S'.
                wa_final-miamt = wa_ekbe1-dmbtr.
                wa_final-finalamt = wa_ekbe1-refwr.
              ELSE.
                wa_final-miamt = wa_ekbe1-dmbtr     * ( -1 ).
                wa_final-finalamt = wa_ekbe1-refwr  * ( -1 ).
              ENDIF.
              CLEAR : wa_final-menge.
              wa_final-miquan = wa_ekbe1-menge.
              wa_final-midate = wa_ekbe1-budat.
*            wa_final-finalamt = wa_ekbe1-refwr.
              CONCATENATE wa_ekbe1-lfgja wa_ekbe1-lfbnr wa_ekbe1-lfpos INTO wa_final-xref3.
              IF wa_final-xref3 EQ '00000000'.
                CLEAR : wa_final-xref3.
              ENDIF.
*******************************            Added on 23.09.2019
              READ TABLE it_rseg1 INTO wa_rseg1 WITH KEY belnr = wa_ekbe1-belnr
                                                               buzei = wa_ekbe1-buzei
                                                               ebeln = ls_po-ebeln
                                                               ebelp = ls_po-ebelp
                                                               xblnr = wa_ekbe1-xblnr
                                                                BINARY SEARCH.

              IF wa_rseg1-shkzg = 'H'.
                wa_final-basic = wa_rseg1-wrbtr * ( - 1 ).
              ELSE.
                wa_final-basic = wa_rseg1-wrbtr .
              ENDIF.
              READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg1-belnr
                                                         gjahr = wa_rseg1-gjahr BINARY SEARCH.
              wa_final-miref     = wa_rbkp-xblnr.
              wa_final-midocdate = wa_rbkp-bldat.

***********************  End of changes on 23.09.2019
              READ TABLE it_excise INTO wa_excise WITH KEY rdoc1 = ls_po-ebeln
                                               ritem1 = ls_po-ebelp BINARY SEARCH.
              IF sy-subrc EQ 0.

                wa_final-amount = wa_excise-exbas.
                wa_final-bed    = wa_excise-exbed.
                CLEAR:wa_excise.
              ENDIF.

              wa_final-meins = ls_po-meins.
              wa_final-netpr = ls_po-netpr.
*            wa_final-poamt = wa_ekpo-netwr.
              wa_final-poamt    = ls_po-netwr * wa_final-wkurs .
              wa_final-matnr = ls_po-matnr.
**              wa_final-werks = ls_po-werks.  "Comment by Rahul Vasita on 19.04.2024 14:41:59

*            wa_final-migodate = wa_ekbe1-budat.
              wa_final-ebeln = wa_ekbe1-ebeln.
              wa_final-ebelp = wa_ekbe1-ebelp.
*            wa_final-mblnr = wa_ekbe1-belnr.

              READ TABLE it_fi INTO wa_fi WITH KEY belnr = wa_final-belnr BINARY SEARCH.
              IF sy-subrc EQ 0.

                CONCATENATE wa_fi-belnr wa_fi-gjahr INTO v_awkey.

                READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
                IF sy-subrc EQ 0.
                  wa_final-fidoc = wa_bkpf-belnr.
                  wa_final-fipdate = wa_bkpf-budat .
                ENDIF.

              ENDIF.

              IF wa_ekbe1-shkzg EQ 'S'.
*              wa_final-menge = wa_ekbe1-menge.
                wa_final-dmbtr = wa_ekbe1-dmbtr.
              ELSE.
*              wa_final-menge = wa_ekbe1-menge * ( -1 ).
                wa_final-dmbtr = wa_ekbe1-dmbtr * ( -1 ).
              ENDIF.
              srno = srno + 1.
              wa_final-srno = srno.

              wa_final-indic = 'P'.  "Added by Rahul Vasita on 15.04.2024 10:36:28
              APPEND wa_final TO it_final.
              CLEAR : wa_final-miamt , wa_final-midate , wa_final-midocdate , wa_final-miquan , wa_final-miref ,wa_final-finalamt,
                      wa_final-fidoc , wa_final-fipdate. "Added by Rahul Vasita on 22.04.2024 14:19:53
              CLEAR:wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1,srno.
            ENDLOOP.
          ENDIF.
          CLEAR:ls_po.
        ENDIF."End of LT_PO
        CLEAR:wa_final,wa_ekkn,wa_ekbe,wa_bkpf,wa_fi,wa_excise,wa_ekbe1.
      ENDLOOP.

      CLEAR:wa_final,wa_anla.
    ENDIF.


    DATA:v_amount_h TYPE dmbtr.
    DATA:v_amount_s TYPE dmbtr.

  ENDLOOP.

  IF it_anek[] IS NOT INITIAL.


    LOOP AT it_anek INTO wa_anek .
      READ TABLE it_anla INTO wa_anla WITH KEY anln1 = wa_anek-anln1.
      IF sy-subrc EQ 0.
        wa_final-txt50 = wa_anla-txt50.
        CLEAR:wa_anla.
      ENDIF.

      MOVE-CORRESPONDING wa_anek TO wa_final.
      READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY belnr = wa_anek-belnr
                                                 buzei = wa_anek-buzei BINARY SEARCH.
      IF sy-subrc EQ 0.
        IF wa_final1-werks IS INITIAL. "Added by Rahul Vasita on 18.04.2024 14:18:05
          wa_final1-werks = wa_bseg1-werks. "Added by Rahul Vasita on 18.04.2024 14:18:06
        ENDIF. "Added by Rahul Vasita on 18.04.2024 14:18:08
*************************Added by Rutvi on 11.09.2024
        READ TABLE lt_tvarvc INTO DATA(ls_tvarvc) WITH KEY low = wa_bseg1-mwskz.
        IF sy-subrc = 0.

          IF wa_bseg1-txbhw IS NOT INITIAL.

            IF wa_bseg1-shkzg EQ 'S'.
              wa_final-finalamt = wa_bseg1-txbhw.
            ELSE.
              wa_final-finalamt = wa_bseg1-txbhw * ( -1 ).
            ENDIF.

          ELSE.

            IF wa_bseg1-shkzg EQ 'S'.
              wa_final-finalamt = wa_bseg1-dmbtr.
            ELSE.
              wa_final-finalamt = wa_bseg1-dmbtr * ( -1 ).
            ENDIF.

          ENDIF.

        ELSE.

          IF wa_bseg1-shkzg EQ 'S'.
            wa_final-finalamt = wa_bseg1-dmbtr.
          ELSE.
            wa_final-finalamt = wa_bseg1-dmbtr * ( -1 ).
          ENDIF.

        ENDIF.
**********************************************************************
*****        Added changes by Carina Jose on 03.09.2019
        IF wa_anek-ebeln EQ ' '.
          READ TABLE it_bseg2 INTO wa_bseg2 WITH KEY belnr = wa_anek-belnr BINARY SEARCH.
          READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_bseg2-lifnr BINARY SEARCH.
          IF sy-subrc EQ 0.

            CONCATENATE wa_lfa1-name1 wa_lfa1-name2 INTO v_vendor.
            wa_final-name1 = v_vendor.
            CLEAR:v_vendor.
            CLEAR:wa_lfa1.
          ENDIF.
          wa_final-lifnr = wa_bseg2-lifnr .
*           wa_final-midate = wa_anek-budat .
          wa_final-budat = ' '.

          READ TABLE it_bkpf INTO wa_bkpf WITH KEY bukrs = wa_anek-bukrs
                                                   belnr = wa_anek-belnr
                                                   gjahr = wa_anek-gjahr BINARY SEARCH.
          IF sy-subrc = 0.
            wa_final-fidoc = wa_bkpf-belnr .
            wa_final-belnr = ' '.
            wa_final-midocdate = wa_bkpf-bldat .
            wa_final-miref = wa_bkpf-xblnr .

            wa_final-fipdate = wa_bkpf-budat .
          ENDIF."enD OF IT_BKPF
        ENDIF.
*****        End of changes on 03.09.2019

        wa_final-indic = 'F'.  "Added by Rahul Vasita on 15.04.2024 10:36:28
        " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*        SELECT SINGLE werks FROM anlz INTO wa_final-werks WHERE bukrs = wa_final-bukrs AND anln1 = wa_final-anln1 AND bdatu = '99991231'.
        SELECT werks FROM anlz INTO wa_final-werks UP TO 1 ROWS WHERE bukrs = wa_final-bukrs AND anln1 = wa_final-anln1 AND bdatu = '99991231' ORDER BY PRIMARY KEY.ENDSELECT.
        " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
        APPEND wa_final TO it_final.

        CLEAR:wa_final,wa_anek, wa_bkpf, wa_bseg2.
      ENDIF.
    ENDLOOP.

  ENDIF.

**  SORT it_fi BY belnr gjahr. "Comment by Rahul Vasita on 14.03.2024 11:24:30
**  SORT it_bkpf ASCENDING BY bukrs belnr gjahr awkey. "Comment by Rahul Vasita on 14.03.2024 11:24:32

  CLEAR:wa_final,wa_fi,wa_bkpf.
  DATA:v_vat TYPE dmbtr.

  DATA:v_freight TYPE dmbtr.
  DATA:v_lifnr TYPE lifnr.

  SORT it_final BY ebeln.
  DATA:v_anln1 TYPE anln1.


  LOOP AT it_final INTO wa_final.
    MOVE-CORRESPONDING wa_final TO wa_final1.
    v_anln1 = wa_final-anln1.

********************************************* Addded on 12.09.2019
    LOOP AT it_ekbz INTO wa_ekbz WHERE ebeln = wa_final1-ebeln AND
                                       ebelp = wa_final1-ebelp .


      CONCATENATE wa_ekbz-belnr wa_ekbz-gjahr INTO v_awkey1.
      CONDENSE v_awkey1.

      READ TABLE it_bkpf1 INTO wa_bkpf1 WITH KEY awkey = v_awkey1 .
      IF sy-subrc = 0 .
        LOOP AT it_bset1 INTO wa_bset1 WHERE belnr = wa_bkpf1-belnr AND
                                             bukrs = wa_bkpf1-bukrs AND
                                             gjahr = wa_bkpf1-gjahr AND
                                             buzei = wa_ekbz-buzei
                                                .
          IF wa_bset1-kschl EQ 'JIMD' OR wa_bset1-kschl EQ 'JIMN' .
            IF wa_bset1-shkzg EQ 'S'.
              wa_final1-igst = wa_final1-igst + wa_bset1-hwste.
              wa_final1-igstcr = wa_final1-igstcr + wa_bset1-hwste.
*            ELSE.
*              wa_final1-igst =  ( wa_final1-igst + wa_bset1-hwste ) * -1  .
*              wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset1-hwste ) * -1.
            ELSE.
              wa_final1-igst =  ( wa_final1-igst + wa_bset1-hwste ) * ( -1 ).
              wa_final1-igstcr = ( wa_final1-igstcr + wa_bset1-hwste ) * ( -1 ).
            ENDIF.

          ENDIF.
        ENDLOOP.
      ENDIF.
*   CLEAR : wa_final1-.
    ENDLOOP.
*    IF wa_final1-miamt < 0.
*      wa_final1-miamt = wa_final1-miamt * -1.
*    ENDIF.
*********************************************** End of changes on 12.09.2019
*    READ TABLE it_bseg INTO wa_bseg WITH KEY belnr = wa_final1-fidoc
*                                              ebeln = wa_final1-ebeln
*                                              ebelp = wa_final1-ebelp
*                                              txgrp = wa_final1-srno .
*                                              buzei = wa_ekbz-buzei .
    READ TABLE it_rseg INTO wa_rseg WITH KEY buzei = wa_final1-1buzei
                                             ebeln = wa_final1-ebeln
                                             ebelp = wa_final1-ebelp BINARY SEARCH. " added on 02.10.2019
*                                     buzei = wa_final1-buzei.
*                                     buzei = wa_final1-srno.        " commented on 02.10.2019
*    IF wa_final1-xref3 IS INITIAL.
*        READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
*                                                ebeln = wa_final1-ebeln
*                                                ebelp = wa_final1-ebelp .
*    ENDIF.
    IF wa_final1-indic <> 'F'. "Added by Rahul Vasita on 15.04.2024 10:41:16
      IF wa_final1-bsart EQ 'SERV'.
        CLEAR wa_bseg. "Added by Raj on 23.11.2023
        READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp
**                                                  koart = 'K' "Added by Rahul Vasita on 12.04.2024 18:16:16
*                                                txgrp = wa_final1-txgrp " commented on 02.10.2019
                                                  txgrp = wa_final1-1buzei.  " Added by Raj 23.11.2023
*                                                txgrp = wa_rseg-count1.   " commmented on 02.10.2019
*                                                txgrp = wa_final1-srno .
        IF sy-subrc = '4'.
          CLEAR wa_bseg."Added by Raj on 23.11.2023
          READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp
                                                  txgrp = wa_final1-1buzei
          koart = 'K'. "Added by Rahul Vasita on 12.04.2024 18:16:16
        ENDIF.
      ELSE.
        CLEAR wa_bseg."Added by Raj on 23.11.2023
        READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
**                                                buzei = wa_final1-buzei "Comment by Rahul Vasita on 12.04.2024 15:22:28
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp
                                                  xref3 = wa_final1-xref3.
**                                                  koart = 'K'. "Added by Rahul Vasita on 12.04.2024 18:16:16
      ENDIF.
      IF sy-subrc EQ 0 AND ( wa_bseg-koart <> 'A' ).
        wa_final1-txgrp = wa_bseg-txgrp. "Comment by Rahul Vasita on 11.04.2024 12:44:40
**        wa_final1-mwskz = wa_bseg-mwskz. "Added by Rahul Vasita on 11.04.2024 12:44:42

        LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                       AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                     AND mwskz = wa_final1-mwskz . "Comment by Rahul Vasita on 11.04.2024 16:07:45
                                       AND txgrp = wa_final1-txgrp . "Comment by Rahul Vasita on 22.08.2024 14:08:23


*VAT
          IF wa_bset-kschl EQ 'JVCD' OR wa_bset-kschl EQ 'JVCN' OR wa_bset-kschl EQ 'JVRD' OR wa_bset-kschl EQ 'JVRN' .
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-vat = wa_final1-vat + wa_bset-hwste.
            ELSE.
              wa_final1-vat =  ( wa_final1-vat + wa_bset-hwste ) * -1.
            ENDIF.

*Credit VAT
            IF wa_bset-hkont IS NOT INITIAL.
              wa_final1-crvat = wa_bset-hwste.
            ENDIF.
          ENDIF.

*ADDITIONAL VAT
          IF wa_bset-kschl EQ 'ZVRD' OR wa_bset-kschl EQ 'ZVCD' OR wa_bset-kschl EQ 'ZVRN' OR wa_bset-kschl EQ 'ZVCN'.
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-addvat = wa_final1-addvat + wa_bset-hwste.
            ELSE.
              wa_final1-addvat =  ( wa_final1-addvat + wa_bset-hwste ) * -1 .
            ENDIF.

*Credit VAT
            IF wa_bset-hkont IS NOT INITIAL.
              wa_final1-crvat = wa_final1-crvat + wa_bset-hwste.
            ENDIF.
          ENDIF.


*CST
          IF wa_bset-kschl EQ 'JVCS'.
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-cst =  wa_bset-hwste.
            ELSE .
              wa_final1-cst = wa_bset-hwste * ( -1 ) .
            ENDIF.

          ENDIF.
*GST
          IF wa_bset-kschl EQ 'JICG' OR wa_bset-kschl EQ 'JOCG' .
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
              wa_final1-cgstcr = wa_final1-cgstcr + wa_bset-hwste.
            ELSE.
              wa_final1-cgst =  ( wa_final1-cgst + wa_bset-hwste ) * ( - 1 ).
              wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * ( - 1 ).
            ENDIF.
          ENDIF.
          IF wa_bset-kschl EQ 'ZCRN'.
            IF wa_bset-shkzg = 'H'.
              wa_final1-cgst =  wa_bset-hwste * ( - 1 ).
*            wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * -1.
            ELSE.
              wa_final1-cgst =  wa_bset-hwste .
            ENDIF.

          ENDIF.
          IF wa_bset-kschl EQ 'ZSRN' .
            IF wa_bset-shkzg = 'H'.
              wa_final1-sgst =  wa_bset-hwste  * ( - 1 ).
*            wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * -1.
            ELSE.
              wa_final1-sgst =  wa_bset-hwste  .
            ENDIF.

          ENDIF.

          IF wa_bset-kschl EQ 'ZIRN' .
            IF wa_bset-shkzg = 'H'.
              wa_final1-igst =  wa_bset-hwste  * -1.
              wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) * -1.
            ELSE.
              wa_final1-igst =  wa_bset-hwste  .
              wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) .
            ENDIF.
          ENDIF.


          IF  wa_bset-kschl EQ 'JISG' OR wa_bset-kschl EQ 'JOSG'.
            IF  wa_bset-shkzg EQ 'S'.
              wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
              wa_final1-sgstcr = wa_final1-sgstcr + wa_bset-hwste.
            ELSE.
              wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * ( - 1 ).
              wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * ( - 1 ).

            ENDIF.
          ENDIF.

          IF wa_bset-kschl EQ 'JIIG' OR wa_bset-kschl EQ 'JOIG' .
            IF  wa_bset-shkzg EQ 'S'.
              wa_final1-igst = wa_final1-igst + wa_bset-hwste.
              wa_final1-igstcr = wa_final1-igstcr + wa_bset-hwste.
            ELSE.
              wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
              wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset-hwste ) * -1.
            ENDIF.

          ENDIF.
          IF wa_bset-kschl EQ 'JICN'  .
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
            ELSE.
              wa_final1-cgst = ( wa_final1-cgst + wa_bset-hwste ) * ( -1 ).
            ENDIF.
          ENDIF.

          IF wa_bset-kschl EQ 'JISN' .
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
            ELSE.
              wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * -1.
            ENDIF.

          ENDIF.
          IF wa_bset-kschl EQ 'JIIN'.
            IF wa_bset-shkzg EQ 'S'.
              wa_final1-igst = wa_final1-igst + wa_bset-hwste.
            ELSE.
              wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
            ENDIF.

          ENDIF.

        ENDLOOP.



*SERVICE TAX
        IF wa_final1-bsart EQ 'SERV'.
          CLEAR:wa_bset.
          LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                                         AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                       AND mwskz = wa_final1-mwskz.   "Added by Rahul Vasita on 11.04.2024 12:47:52
                                         AND txgrp = wa_final1-txgrp.  "Comment by Rahul Vasita on 22.08.2024 14:08:41

            IF wa_bset-kschl EQ 'ZSC1' OR wa_bset-kschl EQ 'ZSC2' OR wa_bset-kschl EQ 'ZSC3'
            OR wa_bset-kschl EQ 'ZSN1'  OR wa_bset-kschl EQ 'ZSN4' OR wa_bset-kschl EQ 'ZSN2' OR wa_bset-kschl EQ 'ZSN3' .

              IF wa_bset-shkzg EQ 'S'.
                wa_final1-serv = wa_final1-serv + wa_bset-hwste.
              ELSE.
                wa_final1-serv = ( wa_final1-serv - wa_bset-hwste ) * ( -1 ).
              ENDIF.
*            CLEAR:wa_bset.

              IF wa_bset-hkont IS NOT INITIAL.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                ELSE.
                  wa_final1-crserv = ( wa_final1-crserv + wa_bset-hwste ) * ( - 1 ).
                ENDIF.
*              IF wa_bset-shkzg EQ 'S'.
*                wa_final1-serv = wa_final1-serv + wa_bset-hwste.
*              ELSE.
*                wa_final1-serv = wa_final1-serv - wa_bset-hwste.
*              ENDIF.
              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'ZWC1'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-basic = wa_final1-basic + wa_bset-hwste .
              ELSE.
                wa_final1-basic = ( wa_final1-basic + wa_bset-hwste ) * ( - 1 ).
              ENDIF.
            ENDIF.
          ENDLOOP.
        ENDIF.


        "Adding Start by Rahul Vasita on 08.08.2024 16:05:06 GST Tax Calculation on Fright
        READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
                                                  buzid = 'G'
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp.
        IF sy-subrc = 0.
          LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
                                         AND txgrp = wa_bseg-txgrp . "Comment by Rahul Vasita on 22.08.2024 14:09:05

*VAT
            IF wa_bset-kschl EQ 'JVCD' OR wa_bset-kschl EQ 'JVCN' OR wa_bset-kschl EQ 'JVRD' OR wa_bset-kschl EQ 'JVRN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-vat = wa_final1-vat + wa_bset-hwste.
              ELSE.
                wa_final1-vat =  ( wa_final1-vat + wa_bset-hwste ) * -1.
              ENDIF.
*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_bset-hwste.
              ENDIF.
            ENDIF.
*ADDITIONAL VAT
            IF wa_bset-kschl EQ 'ZVRD' OR wa_bset-kschl EQ 'ZVCD' OR wa_bset-kschl EQ 'ZVRN' OR wa_bset-kschl EQ 'ZVCN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-addvat = wa_final1-addvat + wa_bset-hwste.
              ELSE.
                wa_final1-addvat =  ( wa_final1-addvat + wa_bset-hwste ) * -1 .
              ENDIF.
*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_final1-crvat + wa_bset-hwste.
              ENDIF.
            ENDIF.
*CST
            IF wa_bset-kschl EQ 'JVCS'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cst =  wa_bset-hwste.
              ELSE .
                wa_final1-cst = wa_bset-hwste * ( -1 ) .
              ENDIF.

            ENDIF.
*GST
            IF wa_bset-kschl EQ 'JICG' OR wa_bset-kschl EQ 'JOCG' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
                wa_final1-cgstcr = wa_final1-cgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-cgst =  ( wa_final1-cgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * ( - 1 ).
              ENDIF.
            ENDIF.
            IF wa_bset-kschl EQ 'ZCRN'.
              IF wa_bset-shkzg = 'H'.
                wa_final1-cgst =  wa_bset-hwste * ( - 1 ).
              ELSE.
                wa_final1-cgst =  wa_bset-hwste .
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'ZSRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-sgst =  wa_bset-hwste  * ( - 1 ).
              ELSE.
                wa_final1-sgst =  wa_bset-hwste  .
              ENDIF.

            ENDIF.

            IF wa_bset-kschl EQ 'ZIRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-igst =  wa_bset-hwste  * -1.
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-igst =  wa_bset-hwste  .
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) .
              ENDIF.
            ENDIF.


            IF  wa_bset-kschl EQ 'JISG' OR wa_bset-kschl EQ 'JOSG'.
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
                wa_final1-sgstcr = wa_final1-sgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * ( - 1 ).

              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JIIG' OR wa_bset-kschl EQ 'JOIG' .
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
                wa_final1-igstcr = wa_final1-igstcr + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
                wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JICN'  .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
              ELSE.
                wa_final1-cgst = ( wa_final1-cgst + wa_bset-hwste ) * ( -1 ).
              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JISN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JIIN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.

          ENDLOOP.
        ENDIF."IF sy-subrc = 0.End of BUZID = G
        "Adding End by Rahul Vasita on 08.08.2024 16:05:06 GST Tax Calculation on Fright`

        APPEND wa_final1 TO it_final1.
        CLEAR : wa_final1.
*      CLEAR : wa_final1-dmbtr .

      ENDIF."IF sy-subrc EQ 0 AND ( wa_bseg-koart <> 'A' ).

      "Adding Start by Rahul Vasita on 06.08.2024 18:25:22 Invoice Planning Case KNTTP = 'A'.
      IF wa_final1-bsart = 'SERV'.
        CLEAR wa_bseg."Added by Raj on 23.11.2023
        READ TABLE it_bseg INTO wa_bseg WITH KEY  belnr = wa_final1-fidoc
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp
                                                  txgrp = wa_final1-1buzei
                                                  koart = 'A'. "Added by Rahul Vasita on 12.04.2024 18:16:16
        IF sy-subrc = 0 AND wa_bseg-anln1 <> ' '.
          wa_final1-txgrp = wa_bseg-txgrp.

          LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
                                         AND txgrp = wa_final1-txgrp . "Comment by Rahul Vasita on 22.08.2024 14:09:23


*VAT
            IF wa_bset-kschl EQ 'JVCD' OR wa_bset-kschl EQ 'JVCN' OR wa_bset-kschl EQ 'JVRD' OR wa_bset-kschl EQ 'JVRN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-vat = wa_final1-vat + wa_bset-hwste.
              ELSE.
                wa_final1-vat =  ( wa_final1-vat + wa_bset-hwste ) * -1.
              ENDIF.

*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_bset-hwste.
              ENDIF.
            ENDIF.

*ADDITIONAL VAT
            IF wa_bset-kschl EQ 'ZVRD' OR wa_bset-kschl EQ 'ZVCD' OR wa_bset-kschl EQ 'ZVRN' OR wa_bset-kschl EQ 'ZVCN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-addvat = wa_final1-addvat + wa_bset-hwste.
              ELSE.
                wa_final1-addvat =  ( wa_final1-addvat + wa_bset-hwste ) * -1 .
              ENDIF.

*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_final1-crvat + wa_bset-hwste.
              ENDIF.
            ENDIF.


*CST
            IF wa_bset-kschl EQ 'JVCS'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cst =  wa_bset-hwste.
              ELSE .
                wa_final1-cst = wa_bset-hwste * ( -1 ) .
              ENDIF.

            ENDIF.
*GST
            IF wa_bset-kschl EQ 'JICG' OR wa_bset-kschl EQ 'JOCG' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
                wa_final1-cgstcr = wa_final1-cgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-cgst =  ( wa_final1-cgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * ( - 1 ).
              ENDIF.
            ENDIF.
            IF wa_bset-kschl EQ 'ZCRN'.
              IF wa_bset-shkzg = 'H'.
                wa_final1-cgst =  wa_bset-hwste * ( - 1 ).
*            wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-cgst =  wa_bset-hwste .
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'ZSRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-sgst =  wa_bset-hwste  * ( - 1 ).
*            wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-sgst =  wa_bset-hwste  .
              ENDIF.

            ENDIF.

            IF wa_bset-kschl EQ 'ZIRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-igst =  wa_bset-hwste  * -1.
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-igst =  wa_bset-hwste  .
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) .
              ENDIF.
            ENDIF.


            IF  wa_bset-kschl EQ 'JISG' OR wa_bset-kschl EQ 'JOSG'.
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
                wa_final1-sgstcr = wa_final1-sgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * ( - 1 ).

              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JIIG' OR wa_bset-kschl EQ 'JOIG' .
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
                wa_final1-igstcr = wa_final1-igstcr + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
                wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JICN'  .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
              ELSE.
                wa_final1-cgst = ( wa_final1-cgst + wa_bset-hwste ) * ( -1 ).
              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JISN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JIIN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.

          ENDLOOP.

*SERVICE TAX
          IF wa_final1-bsart EQ 'SERV'.
            CLEAR:wa_bset.
            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
                                           AND txgrp = wa_final1-txgrp. "Comment by Rahul Vasita on 22.08.2024 14:09:34

              IF wa_bset-kschl EQ 'ZSC1' OR wa_bset-kschl EQ 'ZSC2' OR wa_bset-kschl EQ 'ZSC3'
              OR wa_bset-kschl EQ 'ZSN1'  OR wa_bset-kschl EQ 'ZSN4' OR wa_bset-kschl EQ 'ZSN2' OR wa_bset-kschl EQ 'ZSN3' .

                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serv = wa_final1-serv + wa_bset-hwste.
                ELSE.
                  wa_final1-serv = ( wa_final1-serv - wa_bset-hwste ) * ( -1 ).
                ENDIF.

                IF wa_bset-hkont IS NOT INITIAL.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  ELSE.
                    wa_final1-crserv = ( wa_final1-crserv + wa_bset-hwste ) * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.

              IF wa_bset-kschl EQ 'ZWC1'.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-basic = wa_final1-basic + wa_bset-hwste .
                ELSE.
                  wa_final1-basic = ( wa_final1-basic + wa_bset-hwste ) * ( - 1 ).
                ENDIF.
              ENDIF.
            ENDLOOP.
          ENDIF.

          APPEND wa_final1 TO it_final1.
          CLEAR : wa_final1.

        ENDIF."IF sy-subrc = 0 AND wa_bseg-anln1 <> ' '.
      ENDIF."IF wa_final1-bsart = 'SERV'.
      "Adding End by Rahul Vasita on 06.08.2024 18:25:22 Invoice Planning Case KNTTP = 'A'.

    ELSE. "Added by Rahul Vasita on 15.04.2024 10:41:21
      "Adding Start by Rahul Vasita on 20.03.2024 12:32:51 For CAPEX PO Only FI ASSET

      IF wa_final1-ebeln IS NOT INITIAL.

        READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY  belnr = wa_final1-fidoc
                                                  ebeln = wa_final1-ebeln
                                                  ebelp = wa_final1-ebelp
        koart = 'A'. "Added by Rahul Vasita on 12.04.2024 18:16:16 "Comment by Rahul Vasita on 19.04.2024 11:42:08
        IF sy-subrc = 0.
          wa_final1-txgrp = wa_bseg1-txgrp. "Comment by Rahul Vasita on 11.04.2024 12:46:21
**        wa_final1-mwskz = wa_bseg-mwskz. "Added by Rahul Vasita on 11.04.2024 12:46:23
          LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                                 AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                       AND mwskz = wa_final1-mwskz .  "Added by Rahul Vasita on 11.04.2024 12:46:40
                                         AND txgrp = wa_final1-txgrp . "Comment by Rahul Vasita on 22.08.2024 14:10:03


*VAT
            IF wa_bset-kschl EQ 'JVCD' OR wa_bset-kschl EQ 'JVCN' OR wa_bset-kschl EQ 'JVRD' OR wa_bset-kschl EQ 'JVRN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-vat = wa_final1-vat + wa_bset-hwste.
              ELSE.
                wa_final1-vat =  ( wa_final1-vat + wa_bset-hwste ) * -1.
              ENDIF.

*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_bset-hwste.
              ENDIF.
            ENDIF.

*ADDITIONAL VAT
            IF wa_bset-kschl EQ 'ZVRD' OR wa_bset-kschl EQ 'ZVCD' OR wa_bset-kschl EQ 'ZVRN' OR wa_bset-kschl EQ 'ZVCN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-addvat = wa_final1-addvat + wa_bset-hwste.
              ELSE.
                wa_final1-addvat =  ( wa_final1-addvat + wa_bset-hwste ) * -1 .
              ENDIF.

*Credit VAT
              IF wa_bset-hkont IS NOT INITIAL.
                wa_final1-crvat = wa_final1-crvat + wa_bset-hwste.
              ENDIF.
            ENDIF.


*CST
            IF wa_bset-kschl EQ 'JVCS'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cst =  wa_bset-hwste.
              ELSE .
                wa_final1-cst = wa_bset-hwste * ( -1 ) .
              ENDIF.

            ENDIF.
*GST
            IF wa_bset-kschl EQ 'JICG' OR wa_bset-kschl EQ 'JOCG' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
                wa_final1-cgstcr = wa_final1-cgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-cgst =  ( wa_final1-cgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * ( - 1 ).
              ENDIF.
            ENDIF.
            IF wa_bset-kschl EQ 'ZCRN'.
              IF wa_bset-shkzg = 'H'.
                wa_final1-cgst =  wa_bset-hwste * ( - 1 ).
*            wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-cgst =  wa_bset-hwste .
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'ZSRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-sgst =  wa_bset-hwste  * ( - 1 ).
*            wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-sgst =  wa_bset-hwste  .
              ENDIF.

            ENDIF.

            IF wa_bset-kschl EQ 'ZIRN' .
              IF wa_bset-shkzg = 'H'.
                wa_final1-igst =  wa_bset-hwste  * -1.
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ELSE.
                wa_final1-igst =  wa_bset-hwste  .
                wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) .
              ENDIF.
            ENDIF.


            IF  wa_bset-kschl EQ 'JISG' OR wa_bset-kschl EQ 'JOSG'.
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
                wa_final1-sgstcr = wa_final1-sgstcr + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * ( - 1 ).
                wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * ( - 1 ).

              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JIIG' OR wa_bset-kschl EQ 'JOIG' .
              IF  wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
                wa_final1-igstcr = wa_final1-igstcr + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
                wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JICN'  .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
              ELSE.
                wa_final1-cgst = ( wa_final1-cgst + wa_bset-hwste ) * ( -1 ).
              ENDIF.
            ENDIF.

            IF wa_bset-kschl EQ 'JISN' .
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
              ELSE.
                wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.
            IF wa_bset-kschl EQ 'JIIN'.
              IF wa_bset-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + wa_bset-hwste.
              ELSE.
                wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
              ENDIF.

            ENDIF.

          ENDLOOP.

          IF wa_final1-bsart EQ 'SERV'.
            CLEAR:wa_bset.
            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                                 AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                         AND mwskz = wa_final1-mwskz.
                                           AND txgrp = wa_final1-txgrp. "Comment by Rahul Vasita on 22.08.2024 14:12:47

              IF wa_bset-kschl EQ 'ZSC1' OR wa_bset-kschl EQ 'ZSC2' OR wa_bset-kschl EQ 'ZSC3'
              OR wa_bset-kschl EQ 'ZSN1'  OR wa_bset-kschl EQ 'ZSN4' OR wa_bset-kschl EQ 'ZSN2' OR wa_bset-kschl EQ 'ZSN3' .

                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serv = wa_final1-serv + wa_bset-hwste.
                ELSE.
                  wa_final1-serv = ( wa_final1-serv - wa_bset-hwste ) * ( -1 ).
                ENDIF.
*            CLEAR:wa_bset.

                IF wa_bset-hkont IS NOT INITIAL.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  ELSE.
                    wa_final1-crserv = ( wa_final1-crserv + wa_bset-hwste ) * ( - 1 ).
                  ENDIF.
*              IF wa_bset-shkzg EQ 'S'.
*                wa_final1-serv = wa_final1-serv + wa_bset-hwste.
*              ELSE.
*                wa_final1-serv = wa_final1-serv - wa_bset-hwste.
*              ENDIF.
                ENDIF.
              ENDIF.

              IF wa_bset-kschl EQ 'ZWC1'.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-basic = wa_final1-basic + wa_bset-hwste .
                ELSE.
                  wa_final1-basic = ( wa_final1-basic + wa_bset-hwste ) * ( - 1 ).
                ENDIF.
              ENDIF.
            ENDLOOP.
          ENDIF."wa_final1-bsart EQ 'SERV'.
        ENDIF."IT BSEG

      ELSE.

        READ TABLE it_anep_t INTO wa_anep_t WITH KEY anln1 = wa_final-anln1
                                                     anln2 = wa_final-anln2
                                                     afabe = '1'
                                                     lnran = wa_final-lnran.
        IF sy-subrc = 0.

          IF wa_anep_t-bwasl = '105'.

            READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY belnr = wa_final1-fidoc
                                                       shkzg = 'H'
                                                       koart = 'A'.
          ELSE.

            READ TABLE it_bseg1 INTO wa_bseg1 WITH KEY belnr = wa_final1-fidoc
                                                       ebeln = wa_final1-ebeln
                                                       ebelp = wa_final1-ebelp
                                                       shkzg = 'S'
                                                       koart = 'A'.

          ENDIF.

          IF sy-subrc = 0.

*        LOOP AT it_bseg1 INTO wa_bseg1 WHERE belnr = wa_final1-fidoc
*                                         AND ebeln = wa_final1-ebeln
*                                         AND ebelp = wa_final1-ebelp
*                                         AND koart = 'A'. "Added by Rahul Vasita on 12.04.2024 18:16:16 "Comment by Rahul Vasita on 19.04.2024 11:42:08
*          IF sy-subrc = 0.
            wa_final1-txgrp = wa_bseg1-txgrp. "Comment by Rahul Vasita on 11.04.2024 12:46:21
**        wa_final1-mwskz = wa_bseg-mwskz. "Added by Rahul Vasita on 11.04.2024 12:46:23
            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                                 AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                       AND mwskz = wa_final1-mwskz .  "Added by Rahul Vasita on 11.04.2024 12:46:40
                                           AND txgrp = wa_final1-txgrp . "Comment by Rahul Vasita on 22.08.2024 14:10:03


*VAT
              IF wa_bset-kschl EQ 'JVCD' OR wa_bset-kschl EQ 'JVCN' OR wa_bset-kschl EQ 'JVRD' OR wa_bset-kschl EQ 'JVRN' .
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-vat = wa_final1-vat + wa_bset-hwste.
                ELSE.
                  wa_final1-vat =  ( wa_final1-vat + wa_bset-hwste ) * -1.
                ENDIF.

*Credit VAT
                IF wa_bset-hkont IS NOT INITIAL.
                  wa_final1-crvat = wa_bset-hwste.
                ENDIF.
              ENDIF.

*ADDITIONAL VAT
              IF wa_bset-kschl EQ 'ZVRD' OR wa_bset-kschl EQ 'ZVCD' OR wa_bset-kschl EQ 'ZVRN' OR wa_bset-kschl EQ 'ZVCN'.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-addvat = wa_final1-addvat + wa_bset-hwste.
                ELSE.
                  wa_final1-addvat =  ( wa_final1-addvat + wa_bset-hwste ) * -1 .
                ENDIF.

*Credit VAT
                IF wa_bset-hkont IS NOT INITIAL.
                  wa_final1-crvat = wa_final1-crvat + wa_bset-hwste.
                ENDIF.
              ENDIF.


*CST
              IF wa_bset-kschl EQ 'JVCS'.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-cst =  wa_bset-hwste.
                ELSE .
                  wa_final1-cst = wa_bset-hwste * ( -1 ) .
                ENDIF.

              ENDIF.
*GST
              IF wa_bset-kschl EQ 'JICG' OR wa_bset-kschl EQ 'JOCG' .
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
                  wa_final1-cgstcr = wa_final1-cgstcr + wa_bset-hwste.
                ELSE.
                  wa_final1-cgst =  ( wa_final1-cgst + wa_bset-hwste ) * ( - 1 ).
                  wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * ( - 1 ).
                ENDIF.
              ENDIF.
              IF wa_bset-kschl EQ 'ZCRN'.
                IF wa_bset-shkzg = 'H'.
                  wa_final1-cgst =  wa_bset-hwste * ( - 1 ).
*            wa_final1-cgstcr = ( wa_final1-cgstcr + wa_bset-hwste ) * -1.
                ELSE.
                  wa_final1-cgst =  wa_bset-hwste .
                ENDIF.

              ENDIF.
              IF wa_bset-kschl EQ 'ZSRN' .
                IF wa_bset-shkzg = 'H'.
                  wa_final1-sgst =  wa_bset-hwste  * ( - 1 ).
*            wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * -1.
                ELSE.
                  wa_final1-sgst =  wa_bset-hwste  .
                ENDIF.

              ENDIF.

              IF wa_bset-kschl EQ 'ZIRN' .
                IF wa_bset-shkzg = 'H'.
                  wa_final1-igst =  wa_bset-hwste  * -1.
                  wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) * -1.
                ELSE.
                  wa_final1-igst =  wa_bset-hwste  .
                  wa_final1-igstcr = ( wa_final1-igstcr + wa_bset-hwste ) .
                ENDIF.
              ENDIF.


              IF  wa_bset-kschl EQ 'JISG' OR wa_bset-kschl EQ 'JOSG'.
                IF  wa_bset-shkzg EQ 'S'.
                  wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
                  wa_final1-sgstcr = wa_final1-sgstcr + wa_bset-hwste.
                ELSE.
                  wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * ( - 1 ).
                  wa_final1-sgstcr = ( wa_final1-sgstcr + wa_bset-hwste ) * ( - 1 ).

                ENDIF.
              ENDIF.

              IF wa_bset-kschl EQ 'JIIG' OR wa_bset-kschl EQ 'JOIG' .
                IF  wa_bset-shkzg EQ 'S'.
                  wa_final1-igst = wa_final1-igst + wa_bset-hwste.
                  wa_final1-igstcr = wa_final1-igstcr + wa_bset-hwste.
                ELSE.
                  wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
                  wa_final1-igstcr =  ( wa_final1-igstcr + wa_bset-hwste ) * -1.
                ENDIF.

              ENDIF.
              IF wa_bset-kschl EQ 'JICN'  .
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-cgst = wa_final1-cgst + wa_bset-hwste.
                ELSE.
                  wa_final1-cgst = ( wa_final1-cgst + wa_bset-hwste ) * ( -1 ).
                ENDIF.
              ENDIF.

              IF wa_bset-kschl EQ 'JISN' .
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-sgst = wa_final1-sgst + wa_bset-hwste.
                ELSE.
                  wa_final1-sgst = ( wa_final1-sgst + wa_bset-hwste ) * -1.
                ENDIF.

              ENDIF.
              IF wa_bset-kschl EQ 'JIIN'.
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-igst = wa_final1-igst + wa_bset-hwste.
                ELSE.
                  wa_final1-igst = ( wa_final1-igst + wa_bset-hwste ) * -1.
                ENDIF.

              ENDIF.

            ENDLOOP.

            IF wa_final1-bsart EQ 'SERV'.
              CLEAR:wa_bset.
              LOOP AT it_bset INTO wa_bset WHERE belnr = wa_final1-fidoc
**                                                 AND buzei = wa_final1-1buzei "Added by Rahul Vasita on 11.04.2024 17:15:05
**                                         AND mwskz = wa_final1-mwskz.
                                             AND txgrp = wa_final1-txgrp. "Comment by Rahul Vasita on 22.08.2024 14:12:47

                IF wa_bset-kschl EQ 'ZSC1' OR wa_bset-kschl EQ 'ZSC2' OR wa_bset-kschl EQ 'ZSC3'
                OR wa_bset-kschl EQ 'ZSN1'  OR wa_bset-kschl EQ 'ZSN4' OR wa_bset-kschl EQ 'ZSN2' OR wa_bset-kschl EQ 'ZSN3' .

                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-serv = wa_final1-serv + wa_bset-hwste.
                  ELSE.
                    wa_final1-serv = ( wa_final1-serv - wa_bset-hwste ) * ( -1 ).
                  ENDIF.
*            CLEAR:wa_bset.

                  IF wa_bset-hkont IS NOT INITIAL.
                    IF wa_bset-shkzg EQ 'S'.
                      wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                    ELSE.
                      wa_final1-crserv = ( wa_final1-crserv + wa_bset-hwste ) * ( - 1 ).
                    ENDIF.
*              IF wa_bset-shkzg EQ 'S'.
*                wa_final1-serv = wa_final1-serv + wa_bset-hwste.
*              ELSE.
*                wa_final1-serv = wa_final1-serv - wa_bset-hwste.
*              ENDIF.
                  ENDIF.
                ENDIF.

                IF wa_bset-kschl EQ 'ZWC1'.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-basic = wa_final1-basic + wa_bset-hwste .
                  ELSE.
                    wa_final1-basic = ( wa_final1-basic + wa_bset-hwste ) * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDLOOP.
            ENDIF.
          ENDIF.
*        ENDLOOP.
        ENDIF."wa_final1-bsart EQ 'SERV'.
      ENDIF.
    ENDIF."IT BSEG
    APPEND wa_final1 TO it_final1.
    CLEAR : wa_final1.
    "Adding End by Rahul Vasita on 20.03.2024 12:32:51

*    ENDIF. "Added by Rahul Vasita on 15.04.2024 10:41:23
  ENDLOOP.
*    APPEND wa_final1 TO it_final1.
*    REFRESH:it_extra.


  CLEAR:wa_final1,v_awkey.
  LOOP AT it_final1 INTO wa_final1.

* ----------------------------Added on 03.10.2019
    READ TABLE it_ekbz1 INTO wa_ekbz1 WITH KEY  ebeln = wa_final1-ebeln
                                                ebelp = wa_final1-ebelp
                                                count1 = wa_final1-srno.
* ---------------------------- end of changes on 03.10.2019
*FREIGHT
*    IF wa_final1-ind EQ 'X'.         " comment on 20.09.2019
    IF wa_final1-bsart NE 'SERV'.
*       IF wa_final1-ind EQ 'X'.
      LOOP AT it_rseg INTO wa_rseg WHERE ebeln = wa_final1-ebeln
                                     AND ebelp = wa_final1-ebelp
*                                     AND buzei = wa_final1-txgrp " changed on 01.10.2019
                                     AND belnr = wa_ekbz1-belnr
                                     AND matnr = wa_final1-matnr
                                     AND kschl NE ' ' AND bklas NE ' '.

        IF wa_rseg-kschl EQ 'FRC1' OR wa_rseg-kschl EQ 'FRB1' OR wa_rseg-kschl EQ 'FRB2' OR wa_rseg-kschl EQ 'FRC2'
        OR wa_rseg-kschl EQ 'FRC4' OR wa_rseg-kschl EQ 'FRB3' OR wa_rseg-kschl EQ 'FRB4' OR wa_rseg-kschl EQ 'FRC5'
        OR wa_rseg-kschl EQ 'P&F3' OR wa_rseg-kschl EQ 'P&F1' OR wa_rseg-kschl EQ 'P&F2' OR wa_rseg-kschl EQ 'ZTER'
        OR wa_rseg-kschl EQ 'ZSHP' OR wa_rseg-kschl EQ 'JFR1' OR wa_rseg-kschl EQ 'JCFA' OR wa_rseg-kschl EQ 'JFR2'
        OR wa_rseg-kschl EQ 'JOFP' OR wa_rseg-kschl EQ 'JOFV' OR wa_rseg-kschl EQ 'ZFR1' OR wa_rseg-kschl EQ 'ZOFV'. "#EC CI_USAGE_OK[2469385]
*****  Added changes for debit credit freight charges on 31.08.2019
          IF wa_rseg-shkzg EQ 'H'.
            wa_final1-crfreight =  wa_rseg-wrbtr .
          ELSEIF wa_rseg-shkzg EQ 'S'.
            wa_final1-drfreight = wa_rseg-wrbtr .
          ENDIF.
          wa_final1-frdiff = wa_final1-drfreight - wa_final1-crfreight .
**          wa_final1-frdiff = wa_final1-drfreight + wa_final1-crfreight .
          IF wa_final1-shkzg EQ 'S'.   " Added on 20.09.2019
            wa_final1-freight = wa_final1-freight + wa_final1-frdiff .
          ELSE.
            wa_final1-freight =  ( wa_final1-freight + wa_final1-frdiff ) * -1 .
          ENDIF.

*****  End of changes on 31.08.2019
          wa_final1-delcost = wa_final1-delcost + wa_rseg-bnkan .   " Added changes for unplanned delivery cost on 31.08.2018
*****************************
          wa_final1-totfreight = wa_final1-freight + wa_final1-delcost .

*****************************
        ENDIF.

        IF wa_rseg-kschl EQ 'JCDB'  OR wa_rseg-kschl EQ 'JEDB' OR wa_rseg-kschl EQ 'JSED' OR wa_rseg-kschl EQ 'CUAC'
        OR wa_rseg-kschl EQ 'JSWS'  OR wa_rseg-kschl EQ 'ZSFD' OR wa_rseg-kschl EQ 'J1CV' OR wa_rseg-kschl EQ 'JECV'. "#EC CI_USAGE_OK[2469385]
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-customdty = wa_final1-customdty + wa_rseg-wrbtr .
          ELSE .
            wa_final1-customdty = ( wa_final1-customdty + wa_rseg-wrbtr ) * -1 .
          ENDIF.
        ELSEIF wa_rseg-kschl EQ 'JADC' .
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-igst = wa_rseg-wrbtr .
            wa_final1-igstcr = wa_rseg-wrbtr .
          ELSE.
            wa_final1-igst = wa_rseg-wrbtr * ( - 1 ).
            wa_final1-igstcr = wa_rseg-wrbtr * ( - 1 ).
          ENDIF.
        ELSE.
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-igst = wa_final1-igst.
          ELSE.
            wa_final1-igst = wa_final1-igst * ( - 1 ).
          ENDIF.
        ENDIF.

        IF wa_rseg-kschl EQ ' '.
          IF wa_rseg-shkzg EQ 'H'.
            wa_final1-delcost = ( wa_rseg-wrbtr ) * ( - 1 ).
          ELSE.
            wa_final1-delcost = wa_rseg-wrbtr .
          ENDIF.
        ENDIF.

        CONCATENATE wa_rseg-belnr wa_rseg-gjahr INTO v_awkey.
        CONDENSE v_awkey.


*   sort it_bset by belnr .
        READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
        IF sy-subrc EQ 0.
*-----------------------------------------------------------------------------------------------------------------------------------------------------

          IF wa_final1-totfreight EQ '0'.
            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_bkpf-belnr AND
                                            hwbas = wa_rseg-wrbtr .
*KKC
              IF wa_bset-kschl EQ 'JKK1' OR wa_bset-kschl EQ 'JKK2' OR wa_bset-kschl EQ 'JKK4' OR  wa_bset-kschl EQ 'JKK3'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-kkc = wa_bset-hwste.
                ELSE.
                  wa_final1-kkc = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                        wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crkkc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crkkc = wa_bset-hwste * ( - 1 ).
                  ENDIF.

                ENDIF.
              ENDIF.
*SBC
              IF wa_bset-kschl EQ 'JSB1' OR wa_bset-kschl EQ 'JSB2' OR wa_bset-kschl EQ 'JSB4'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-sbc = wa_bset-hwste.
                ELSE.
                  wa_final1-sbc = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsbc =  wa_bset-hwste.
                  ELSE.
                    wa_final1-crsbc =  wa_bset-hwste * ( - 1 ).
                  ENDIF.

                ENDIF.
              ENDIF.

*Freight Service Tax.
              IF wa_bset-kschl EQ 'ZES1' OR wa_bset-kschl EQ 'ZES4' OR wa_bset-kschl EQ 'ZES7'
                 OR wa_bset-kschl EQ 'ZS01' OR wa_bset-kschl EQ 'ZSN1' OR wa_bset-kschl EQ 'ZSC1'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serfreight = wa_bset-hwste.
                ELSE.
                  wa_final1-serfreight = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                        wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsrfreight = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsrfreight = wa_bset-hwste * ( - 1 ).
                  ENDIF.

                ENDIF.
              ENDIF.
              MODIFY it_final1 FROM wa_final1 TRANSPORTING crserv.
              CLEAR : wa_final1-crserv.
            ENDLOOP.
          ELSE.

            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_bkpf-belnr AND
                                                txgrp = wa_rseg-buzei AND
                                               hwbas = wa_final1-totfreight .
*KKC
              IF wa_bset-kschl EQ 'JKK1' OR wa_bset-kschl EQ 'JKK2' OR wa_bset-kschl EQ 'JKK4' OR  wa_bset-kschl EQ 'JKK3'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-kkc = wa_bset-hwste.
                ELSE.
                  wa_final1-kkc = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crkkc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crkkc = wa_bset-hwste * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.
*SBC
              IF wa_bset-kschl EQ 'JSB1' OR wa_bset-kschl EQ 'JSB2' OR wa_bset-kschl EQ 'JSB4'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-sbc = wa_bset-hwste.
                ELSE.
                  wa_final1-sbc = wa_bset-hwste * ( - 1 ) .
                ENDIF.

                IF wa_bset-hkont IS NOT INITIAL.
*                    wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsbc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsbc = wa_bset-hwste * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.

*Freight Service Tax.
              IF wa_bset-kschl EQ 'ZES1' OR wa_bset-kschl EQ 'ZES4' OR wa_bset-kschl EQ 'ZES7'
                 OR wa_bset-kschl EQ 'ZS01' . "#EC CI_USAGE_OK[2469385] "OR wa_bset-kschl EQ 'ZSN1' OR wa_bset-kschl EQ 'ZSC1'
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serfreight = wa_bset-hwste.
                ELSE.
                  wa_final1-serfreight = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.

                    wa_final1-crsrfreight = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsrfreight = wa_bset-hwste * (   - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.
*                MODIFY it_final1 FROM wa_final1 TRANSPORTING crserv.
*                CLEAR : wa_final1-crserv.
            ENDLOOP.
          ENDIF.

          "Adding Start by Rahul Vasita on 28.08.2024 14:51:02 FOR FREIGHT GST
          CLEAR wa_bseg.
          LOOP AT it_bseg INTO wa_bseg WHERE belnr = wa_final1-fidoc AND
                                                    buzid = 'F' AND
                                                    ebeln = wa_final1-ebeln AND
                                                    ebelp = wa_final1-ebelp.

            LOOP AT it_bset INTO wa_bset WHERE bukrs = wa_bseg-bukrs AND
                                               belnr = wa_bseg-belnr AND
                                               gjahr = wa_bseg-gjahr AND
                                               txgrp = wa_bseg-txgrp.
*****************************Added by Rutvi on 27.09.2024
              IF wa_bset-kschl = 'JOCG' OR wa_bset-kschl = 'JICG'
                OR wa_bset-kschl = 'ZCRN' OR wa_bset-kschl = 'JICN'. "#EC CI_USAGE_OK[2469385]
                IF wa_rseg-shkzg EQ 'S'.
                  wa_final1-cgst = wa_final1-cgst + ( wa_bset-hwste ).
                  wa_final1-cgstcr = wa_final1-cgstcr + ( wa_bset-hwste ).
                ELSE.
                  wa_final1-cgst = ( wa_final1-cgst + ( wa_bset-hwste ) * ( - 1 ) ) .
                  wa_final1-cgstcr = ( wa_final1-cgstcr + ( wa_bset-hwste ) * ( - 1 ) ) .
                ENDIF.
              ELSEIF  wa_bset-kschl = 'JOSG' OR wa_bset-kschl = 'JISG'
                OR wa_bset-kschl = 'ZSRN' OR wa_bset-kschl = 'JISN'. "#EC CI_USAGE_OK[2469385]
                IF wa_rseg-shkzg EQ 'S'.
                  wa_final1-sgst = wa_final1-sgst + ( wa_bset-hwste ).
                  wa_final1-sgstcr = wa_final1-sgstcr + ( wa_bset-hwste ).
                ELSE.
                  wa_final1-sgst = ( wa_final1-sgst + ( wa_bset-hwste ) * ( - 1 ) ) .
                  wa_final1-sgstcr = ( wa_final1-sgstcr + ( wa_bset-hwste ) * ( - 1 ) ) .
                ENDIF.
              ELSEIF wa_bset-kschl = 'JOIG' OR wa_bset-kschl = 'JIIG'
                OR wa_bset-kschl = 'ZIRN' OR wa_bset-kschl = 'JIIN'. "#EC CI_USAGE_OK[2469385]
                IF wa_rseg-shkzg EQ 'S'.
                  wa_final1-igst = wa_final1-igst + ( wa_bset-hwste ).
                  wa_final1-igstcr = wa_final1-igstcr + ( wa_bset-hwste ).
                ELSE.
                  wa_final1-igst = ( wa_final1-igst + ( wa_bset-hwste ) * ( - 1 ) ) .
                  wa_final1-igstcr = ( wa_final1-igstcr + ( wa_bset-hwste ) * ( - 1 ) ) .
                ENDIF.
              ENDIF.
*              IF wa_rseg-shkzg EQ 'S'.
*                wa_final1-igst = wa_final1-igst + ( wa_bset-hwste ).
*              ELSE.
*                wa_final1-igst = ( wa_final1-igst + ( wa_bset-hwste ) * ( - 1 ) ) .
*              ENDIF.
****************************************************************************************
              CLEAR: wa_bset.
            ENDLOOP.
            CLEAR: wa_bseg.
          ENDLOOP.
          "Adding End by Rahul Vasita on 28.08.2024 14:51:02 FOR FREIGHT GST

        ENDIF."End of IT_BKPF

*              MODIFY it_final1 FROM wa_final1 TRANSPORTING delcost freight sbc kkc serfreight customdty igst crserv  .
        MODIFY it_final1 FROM wa_final1 TRANSPORTING delcost freight sbc kkc serfreight customdty cgst sgst igst
        cgstcr sgstcr crsrfreight crsbc crkkc igstcr.
        CLEAR : wa_final1-crsrfreight,wa_final1-crsbc, wa_final1-crkkc.
      ENDLOOP.
*      MODIFY it_final1 FROM wa_final1 TRANSPORTING delcost freight sbc kkc serfreight customdty igst crserv.
      CLEAR:wa_rseg,wa_final1.

*********************   24/09/2019---------------------------------------------------------------------------------------------------------------------
    ELSE.
      LOOP AT it_rseg INTO wa_rseg WHERE ebeln = wa_final1-ebeln
                                       AND ebelp = wa_final1-ebelp
*                                       AND buzei = wa_final1-txgrp " commented on 12.11.2019
                                       AND buzei = wa_final1-1buzei " added  on 12.11.2019
                                       AND belnr = wa_final1-belnr.
*                                     AND matnr = wa_final1-matnr.
        " AND SHKZG EQ 'H'.

        IF wa_rseg-kschl EQ 'FRC1' OR wa_rseg-kschl EQ 'FRB1' OR wa_rseg-kschl EQ 'FRB2' OR wa_rseg-kschl EQ 'FRC2'
        OR wa_rseg-kschl EQ 'FRC4' OR wa_rseg-kschl EQ 'FRB3' OR wa_rseg-kschl EQ 'FRB4' OR wa_rseg-kschl EQ 'FRC5'
        OR wa_rseg-kschl EQ 'P&F3' OR wa_rseg-kschl EQ 'P&F1' OR wa_rseg-kschl EQ 'P&F2' OR wa_rseg-kschl EQ 'ZTER'
        OR wa_rseg-kschl EQ 'ZSHP' OR wa_rseg-kschl EQ 'JFR1' OR wa_rseg-kschl EQ 'JCFA' OR wa_rseg-kschl EQ 'JFR2'
        OR wa_rseg-kschl EQ 'JOFP' OR wa_rseg-kschl EQ 'JOFV' OR wa_rseg-kschl EQ 'ZFR1' OR wa_rseg-kschl EQ 'ZOFV' . "#EC CI_USAGE_OK[2469385]
*****  Added changes for debit credit freight charges on 31.08.2019
          IF wa_rseg-shkzg EQ 'H'.
            wa_final1-crfreight =  wa_rseg-wrbtr .
          ELSEIF wa_rseg-shkzg EQ 'S'.
            wa_final1-drfreight = wa_rseg-wrbtr .
          ENDIF.
          wa_final1-frdiff = wa_final1-drfreight - wa_final1-crfreight .
**          wa_final1-frdiff = wa_final1-drfreight + wa_final1-crfreight .
          IF wa_final1-shkzg EQ 'S'.   " Added on 20.09.2019
            wa_final1-freight = wa_final1-freight + wa_final1-frdiff .
          ELSE.
            wa_final1-freight =  ( wa_final1-freight + wa_final1-frdiff ) * -1 .
          ENDIF.

*****  End of changes on 31.08.2019
          "Comment Start by Rahul Vasita on 15.03.2024 16:25:13 UN PLANNED DEL. COST NOT TO CONSIDER FROM RSEG
*          wa_final1-delcost = wa_final1-delcost + wa_rseg-bnkan .   " Added changes for unplanned delivery cost on 31.08.2018
          "Comment End by Rahul Vasita on 15.03.2024 16:25:13
*****************************
          wa_final1-totfreight = wa_final1-freight + wa_final1-delcost .

*****************************
        ENDIF.
        "Comment Start by Rahul Vasita on 15.03.2024 16:25:45
*        IF wa_rseg-kschl EQ  ' '.UN PLANNED DEL. COST NOT TO CONSIDER FROM RSEG
*          wa_final1-delcost = wa_final1-delcost + wa_rseg-bnkan .
*        ENDIF.
        "Comment End by Rahul Vasita on 15.03.2024 16:25:45

        IF wa_rseg-kschl EQ 'JCDB'  OR wa_rseg-kschl EQ 'JEDB' OR wa_rseg-kschl EQ 'JSED' OR wa_rseg-kschl EQ 'CUAC'
        OR wa_rseg-kschl EQ 'JSWS'  OR wa_rseg-kschl EQ 'ZSFD' OR wa_rseg-kschl EQ 'J1CV' OR wa_rseg-kschl EQ 'JECV'.
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-customdty = wa_final1-customdty + wa_rseg-wrbtr .
          ELSE .
            wa_final1-customdty = ( wa_final1-customdty + wa_rseg-wrbtr ) * -1 .
          ENDIF.
        ELSEIF wa_rseg-kschl EQ 'JADC' .
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-igst = wa_rseg-wrbtr .
            wa_final1-igstcr = wa_rseg-wrbtr .

          ELSE.
            wa_final1-igst = wa_rseg-wrbtr * ( - 1  ).
            wa_final1-igstcr = wa_rseg-wrbtr * ( - 1  ).
          ENDIF.




        ELSE.
          IF wa_rseg-shkzg EQ 'S'.
            wa_final1-igst = wa_final1-igst.
          ELSE.
            wa_final1-igst = wa_final1-igst * ( - 1 ).
          ENDIF.

        ENDIF.

        "Comment Start by Rahul Vasita on 15.03.2024 16:26:16
*        IF wa_rseg-kschl EQ ' '.UN PLANNED DEL. COST NOT TO CONSIDER FROM RSEG
*          IF wa_rseg-shkzg EQ 'H'.
*            wa_final1-delcost = wa_rseg-wrbtr * ( - 1 ).
*          ELSE.
*            wa_final1-delcost = wa_rseg-wrbtr .
*          ENDIF.
*        ENDIF.
        "Comment End by Rahul Vasita on 15.03.2024 16:26:16

        CONCATENATE wa_rseg-belnr wa_rseg-gjahr INTO v_awkey.
        CONDENSE v_awkey.


*   sort it_bset by belnr .
        READ TABLE it_bkpf INTO wa_bkpf WITH KEY awkey = v_awkey BINARY SEARCH.
        IF sy-subrc EQ 0.

          IF wa_final1-totfreight EQ '0'.
            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_bkpf-belnr AND
                                            hwbas = wa_rseg-wrbtr .
*                                                txgrp = wa_rseg-count1.
*KKC
              IF wa_bset-kschl EQ 'JKK1' OR wa_bset-kschl EQ 'JKK2' OR wa_bset-kschl EQ 'JKK4' OR  wa_bset-kschl EQ 'JKK3' . "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-kkc = wa_bset-hwste.
                ELSE.
                  wa_final1-kkc = wa_bset-hwste * (  - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.

                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crkkc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crkkc = wa_bset-hwste * ( - 1 ).
                  ENDIF.

                ENDIF.
              ENDIF.
*SBC
              IF wa_bset-kschl EQ 'JSB1' OR wa_bset-kschl EQ 'JSB2' OR wa_bset-kschl EQ 'JSB4'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-sbc = wa_bset-hwste.
                ELSE.
                  wa_final1-sbc = wa_bset-hwste * (  - 1  ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                    wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsbc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsbc = wa_bset-hwste * ( - 1 ) .
                  ENDIF.
                ENDIF.
              ENDIF.

*Freight Service Tax.
              IF wa_bset-kschl EQ 'ZES1' OR wa_bset-kschl EQ 'ZES4' OR wa_bset-kschl EQ 'ZES7'
                 OR wa_bset-kschl EQ 'ZS01' . "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serfreight = wa_bset-hwste.
                ELSE.
                  wa_final1-serfreight = wa_bset-hwste * ( - 1 ) .
                ENDIF.
*                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.

                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsrfreight = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsrfreight = wa_bset-hwste * ( - 1 ).
                  ENDIF.

                ENDIF.
              ENDIF.
            ENDLOOP.
          ELSE.

            LOOP AT it_bset INTO wa_bset WHERE belnr = wa_bkpf-belnr AND
                                               hwbas = wa_final1-totfreight .
*KKC
              IF wa_bset-kschl EQ 'JKK1' OR wa_bset-kschl EQ 'JKK2' OR wa_bset-kschl EQ 'JKK4' OR  wa_bset-kschl EQ 'JKK3'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-kkc = wa_bset-hwste.
                ELSE.
                  wa_final1-kkc = wa_bset-hwste * (  - 1  ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.

                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crkkc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crkkc = wa_bset-hwste *  ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.
*SBC
              IF wa_bset-kschl EQ 'JSB1' OR wa_bset-kschl EQ 'JSB2' OR wa_bset-kschl EQ 'JSB4'. "#EC CI_USAGE_OK[2469385]
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-sbc = wa_bset-hwste.
                ELSE.
                  wa_final1-sbc = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                       wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsbc = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsbc = wa_bset-hwste * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.

*Freight Service Tax.
              IF wa_bset-kschl EQ 'ZES1' OR wa_bset-kschl EQ 'ZES4' OR wa_bset-kschl EQ 'ZES7'
                 OR wa_bset-kschl EQ 'ZS01'  .    " comment  OR wa_bset-kschl EQ 'ZSN1' OR wa_bset-kschl EQ 'ZSC1'
                IF wa_bset-shkzg EQ 'S'.
                  wa_final1-serfreight = wa_bset-hwste.
                ELSE.
                  wa_final1-serfreight = wa_bset-hwste * ( - 1 ).
                ENDIF.
                IF wa_bset-hkont IS NOT INITIAL.
*                        wa_final1-crserv = wa_final1-crserv + wa_bset-hwste.
                  IF wa_bset-shkzg EQ 'S'.
                    wa_final1-crsrfreight = wa_bset-hwste.
                  ELSE.
                    wa_final1-crsrfreight = wa_bset-hwste * ( - 1 ).
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDLOOP.
          ENDIF.

          "Adding Start by Rahul Vasita on 28.08.2024 14:51:02 FOR FREIGHT GST
          CLEAR wa_bseg.
          LOOP AT it_bseg INTO wa_bseg WHERE belnr = wa_final1-fidoc AND
                                                    buzid = 'F' AND
                                                    ebeln = wa_final1-ebeln AND
                                                    ebelp = wa_final1-ebelp.

            LOOP AT it_bset INTO wa_bset WHERE bukrs = wa_bseg-bukrs AND
                                               belnr = wa_bseg-belnr AND
                                               gjahr = wa_bseg-gjahr AND
                                               txgrp = wa_bseg-txgrp.
              IF wa_rseg-shkzg EQ 'S'.
                wa_final1-igst = wa_final1-igst + ( wa_bset-hwste ).
              ELSE.
                wa_final1-igst = ( wa_final1-igst + ( wa_bset-hwste ) * ( - 1 ) ) .
              ENDIF.
              CLEAR: wa_bset.
            ENDLOOP.
            CLEAR: wa_bseg.
          ENDLOOP.
          "Adding End by Rahul Vasita on 28.08.2024 14:51:02 FOR FREIGHT GST

        ENDIF.
        MODIFY it_final1 FROM wa_final1 TRANSPORTING delcost freight sbc kkc serfreight customdty igst crsrfreight crsbc crkkc igstcr.
        CLEAR : wa_final1-crsrfreight,wa_final1-crsbc, wa_final1-crkkc.
*          CLEAR:wa_rseg,wa_final1.
      ENDLOOP.
*      MODIFY it_final1 FROM wa_final1 TRANSPORTING delcost freight sbc kkc serfreight customdty igst crserv .
      CLEAR:wa_rseg,wa_final1.
* ******************  END 24/09/2019 ------------------------------------------------------------------------------------------------------------------------
*    ENDIF.             " commment on 20.09.2019
    ENDIF. "ADD 24.09.2019
  ENDLOOP.









*  LOOP AT it_final1 INTO wa_final1. "Comment by Rahul Vasita on 14.03.2024 15:13:17
  LOOP AT it_final1 ASSIGNING FIELD-SYMBOL(<wa_final1>).
*    READ TABLE it_excise1 INTO wa_excise1 WITH KEY rdoc1 = wa_final1-ebeln
*                                                   ritem1 = wa_final1-ebelp
*                                                   rdoc2 = wa_final1-belnr.
*    IF sy-subrc EQ 0.
*      wa_final1-crexcise = wa_excise1-exbed.
*    ENDIF.


    IF <wa_final1>-bsart EQ 'SERV'.
*      IF wa_final1-serfreight IS NOT INITIAL OR wa_final1-kkc IS NOT INITIAL .
*        wa_final1-crserv = wa_final1-serfreight + wa_final1-kkc .
*      ENDIF.
      "Added on 26.09.2019
      <wa_final1>-crserv = <wa_final1>-crserv + <wa_final1>-crsbc + <wa_final1>-crkkc + <wa_final1>-crsrfreight .
      <wa_final1>-crexcise = <wa_final1>-bed.

***** Added changes by Carina Jose on 31.08.2019
      <wa_final1>-gsttot = <wa_final1>-cgst + <wa_final1>-sgst + <wa_final1>-igst.

      IF <wa_final1>-wkurs = '0'.
*      wa_final1-finalamt =  wa_final1-finalamt - wa_final1-gsttot .
        <wa_final1>-finalamt = <wa_final1>-basic.
      ELSEIF <wa_final1>-ek_curr EQ 'INR' .
        <wa_final1>-finalamt = <wa_final1>-basic.
      ELSE .
        <wa_final1>-finalamt = ( <wa_final1>-basic * <wa_final1>-wkurs  )  .
      ENDIF.

      <wa_final1>-basictax = <wa_final1>-finalamt + <wa_final1>-freight + <wa_final1>-delcost .
***** End of changes by Carina Jose on 31.08.2019

*    wa_final1-crvat   = wa_final1-vat      + wa_final1-addvat.
      <wa_final1>-crtotal = <wa_final1>-crvat    + <wa_final1>-crexcise + <wa_final1>-cgstcr +  <wa_final1>-sgstcr  + <wa_final1>-igstcr + <wa_final1>-crserv.

*      IF wa_final1-crtotal < 0.
*        wa_final1-crtotal  = wa_final1-crtotal * -1.
*      ENDIF.

*          IF wa_final1-crtotal < 0.
*        wa_final1-crtotal  = wa_final1-crtotal * -1.
*      ENDIF.



**      " Added on 14.11.2019
      IF wa_final1-serv < 0.
        <wa_final1>-serv = <wa_final1>-serv * -1.
      ENDIF.

***      " End of changes

      "Comment Start by Rahul Vasita on 17.04.2024 16:30:26
**      <wa_final1>-total   = <wa_final1>-basic + <wa_final1>-bed + <wa_final1>-vat    + <wa_final1>-addvat + <wa_final1>-serv +
**                          <wa_final1>-cst      + <wa_final1>-ro  + <wa_final1>-octroi + <wa_final1>-other  + <wa_final1>-freight
**                          + <wa_final1>-cgst +  <wa_final1>-sgst  + <wa_final1>-igst + <wa_final1>-customdty + <wa_final1>-sbc + <wa_final1>-kkc + <wa_final1>-serfreight + <wa_final1>-delcost.
**      <wa_final1>-netamt = <wa_final1>-total - <wa_final1>-crtotal.
      "Comment End by Rahul Vasita on 17.04.2024 16:30:26

    ELSE.



*      IF wa_final1-serfreight IS NOT INITIAL OR wa_final1-kkc IS NOT INITIAL .
*        wa_final1-crserv = wa_final1-serfreight + wa_final1-kkc .
*      ENDIF.
      <wa_final1>-crserv = <wa_final1>-crserv + <wa_final1>-crsbc + <wa_final1>-crkkc + <wa_final1>-crsrfreight .
      <wa_final1>-crexcise = <wa_final1>-bed.

***** Added changes by Carina Jose on 31.08.2019
*      IF <wa_final1>-finalamt < 0 .
*        <wa_final1>-finalamt = <wa_final1>-finalamt * -1.
*      ENDIF.
      IF <wa_final1>-freight < 0.
        <wa_final1>-freight = <wa_final1>-freight * -1.
      ENDIF.
      IF <wa_final1>-wkurs = '0'.
*      wa_final1-finalamt =  wa_final1-finalamt - wa_final1-gsttot .
        <wa_final1>-finalamt = <wa_final1>-finalamt.
      ELSEIF <wa_final1>-ek_curr EQ 'INR' .
        <wa_final1>-finalamt = <wa_final1>-finalamt.
      ELSE.
        <wa_final1>-finalamt = ( <wa_final1>-finalamt * <wa_final1>-wkurs  )  .
      ENDIF.
      <wa_final1>-gsttot = <wa_final1>-cgst + <wa_final1>-sgst + <wa_final1>-igst.
      <wa_final1>-basictax = <wa_final1>-finalamt + <wa_final1>-freight + <wa_final1>-delcost .
***** End of changes by Carina Jose on 31.08.2019

*    wa_final1-crvat   = wa_final1-vat      + wa_final1-addvat.
      <wa_final1>-crtotal = <wa_final1>-crvat    + <wa_final1>-crexcise + <wa_final1>-cgstcr +  <wa_final1>-sgstcr  + <wa_final1>-igstcr + <wa_final1>-crserv.

*      IF wa_final1-crtotal < 0.                          "changes on 17.01.2024
*        wa_final1-crtotal  = wa_final1-crtotal * -1.
*      ENDIF.

**      " Added on 14.11.2019
      IF <wa_final1>-serv < 0.
        <wa_final1>-serv = <wa_final1>-serv * -1.
      ENDIF.

***      " End of changes

      "Comment Start by Rahul Vasita on 17.04.2024 16:31:13
**      <wa_final1>-total   = <wa_final1>-finalamt + <wa_final1>-bed + <wa_final1>-vat    + <wa_final1>-addvat + <wa_final1>-serv +
**                          <wa_final1>-cst      + <wa_final1>-ro  + <wa_final1>-octroi + <wa_final1>-other  + <wa_final1>-freight
**                          + <wa_final1>-cgst +  <wa_final1>-sgst  + <wa_final1>-igst + <wa_final1>-customdty + <wa_final1>-sbc + <wa_final1>-kkc + <wa_final1>-serfreight.
**
**      <wa_final1>-netamt = <wa_final1>-total - <wa_final1>-crtotal.
      "Comment End by Rahul Vasita on 17.04.2024 16:31:13

    ENDIF.

************************************ Added on 20.09.2019
    IF <wa_final1>-shkzg EQ 'H'.
      IF <wa_final1>-cgst GT 0.
        <wa_final1>-cgst =  <wa_final1>-cgst * -1.
      ENDIF.
      IF <wa_final1>-sgst GT 0.
        <wa_final1>-sgst =  <wa_final1>-sgst * -1 .
      ENDIF.
      IF <wa_final1>-igst GT 0.
        <wa_final1>-igst =  <wa_final1>-igst * -1 .
      ENDIF.
*      <wa_final1>-finalamt = <wa_final1>-finalamt * -1.
      IF wa_final-ebeln IS INITIAL.
        <wa_final1>-total = <wa_final1>-total * -1.

        <wa_final1>-basictax = <wa_final1>-basictax * -1.
        <wa_final1>-netamt = <wa_final1>-netamt * -1.
      ENDIF.
      IF <wa_final1>-amount GT 0.
        <wa_final1>-amount = <wa_final1>-amount * -1.
      ENDIF.
      IF <wa_final1>-bed GT 0.
        <wa_final1>-bed = <wa_final1>-bed * -1.
      ENDIF.
      IF <wa_final1>-cst GT 0.
        <wa_final1>-cst = <wa_final1>-cst * -1.
      ENDIF.
      IF <wa_final1>-vat GT 0.
        <wa_final1>-vat = <wa_final1>-vat * -1.
      ENDIF.
      IF <wa_final1>-addvat GT 0.
        <wa_final1>-addvat = <wa_final1>-addvat * -1.
      ENDIF.
      IF <wa_final1>-crvat GT 0.
        <wa_final1>-crvat = <wa_final1>-crvat * -1.
      ENDIF.
      IF <wa_final1>-crserv GT 0.
        <wa_final1>-crserv = <wa_final1>-crserv * -1.
      ENDIF.
      IF <wa_final1>-crexcise GT 0.
        <wa_final1>-crexcise = <wa_final1>-crexcise * -1.
      ENDIF.
      IF <wa_final1>-crtotal GT 0.
        <wa_final1>-crtotal = <wa_final1>-crtotal * -1.
      ENDIF.
      IF <wa_final1>-serv GT 0.
        <wa_final1>-serv = <wa_final1>-serv * -1.
      ENDIF.
      IF <wa_final1>-sgstcr GT 0.
        <wa_final1>-sgstcr = <wa_final1>-sgstcr * -1.
      ENDIF.
      IF <wa_final1>-cgstcr GT 0.
        <wa_final1>-cgstcr = <wa_final1>-cgstcr * -1.
      ENDIF.
      IF <wa_final1>-igstcr GT 0.
        <wa_final1>-igstcr = <wa_final1>-igstcr * -1.
      ENDIF.
      IF <wa_final1>-freight GT 0.
        <wa_final1>-freight = <wa_final1>-freight * -1.
      ENDIF.

      IF <wa_final1>-miamt < 0.
        <wa_final1>-miamt = <wa_final1>-miamt.
      ELSE.
        <wa_final1>-miamt = <wa_final1>-miamt * -1.
      ENDIF.
      " Added on 14.11.2019
      IF <wa_final1>-finalamt < 0.
        <wa_final1>-finalamt = <wa_final1>-finalamt.
      ELSE.
        <wa_final1>-finalamt = <wa_final1>-finalamt * -1.
      ENDIF.
**************************Added by Rutvi on 18.09.2024
      IF <wa_final1>-basictax < 0.
        <wa_final1>-basictax = <wa_final1>-basictax.
      ELSE.
        <wa_final1>-basictax = <wa_final1>-basictax * -1.
      ENDIF.
*******************************************************
      "Adding Start by Rahul Vasita on 18.04.2024 14:11:52
**      <wa_final1>-total   = <wa_final1>-basic + <wa_final1>-bed + <wa_final1>-vat    + <wa_final1>-addvat + <wa_final1>-serv +
**                          <wa_final1>-cst      + <wa_final1>-ro  + <wa_final1>-octroi + <wa_final1>-other  + <wa_final1>-freight
**                          + <wa_final1>-cgst +  <wa_final1>-sgst  + <wa_final1>-igst + <wa_final1>-customdty + <wa_final1>-sbc + <wa_final1>-kkc + <wa_final1>-serfreight + <wa_final1>-delcost.
**      <wa_final1>-netamt = <wa_final1>-total - <wa_final1>-crtotal.
      "Adding End by Rahul Vasita on 18.04.2024 14:11:52

*      MODIFY it_final1 FROM <wa_final1> TRANSPORTING total crvat crexcise crtotal netamt basictax gsttot finalamt crserv  igst cgst sgst miamt
*  amount bed cst vat addvat sgstcr cgstcr igstcr freight.
    ENDIF.
    <wa_final1>-total   = <wa_final1>-basictax + <wa_final1>-cgst +  <wa_final1>-sgst  + <wa_final1>-igst
                        + <wa_final1>-bed + <wa_final1>-vat    + <wa_final1>-addvat + <wa_final1>-serv
                        + <wa_final1>-cst      + <wa_final1>-ro  + <wa_final1>-octroi + <wa_final1>-other
                        +  <wa_final1>-customdty + <wa_final1>-sbc + <wa_final1>-kkc
                        + <wa_final1>-serfreight.
    <wa_final1>-netamt = <wa_final1>-total - <wa_final1>-crtotal.
************************************+ <wa_final1>-freight + <wa_final1>-delcost

*    MODIFY it_final1 FROM wa_final1 TRANSPORTING total crvat crexcise crtotal netamt basictax gsttot finalamt crserv .
    CLEAR: wa_excise1."wa_final1
  ENDLOOP.


  DATA lv_amount TYPE bseg-dmbtr.

**************Added by Raj on  04.10.2023*************************************
*  LOOP AT it_final1 INTO wa_final1.
*
*    MOVE-CORRESPONDING wa_final1 TO wa_final2.
*
*
*    LOOP AT it_bseg INTO wa_bseg WHERE projk = wa_final2-ps_psp_pnr.
*
*      IF wa_bseg IS NOT INITIAL.
*        CLEAR :wa_final2-fidoc,wa_final2-netamt.
*        wa_final2-fidoc =   wa_bseg-belnr.
*        wa_final2-netamt =  wa_final2-netamt + wa_bseg-dmbtr.
*      ENDIF.
*
*      APPEND  wa_final2 TO it_final2.
*      CLEAR : wa_bseg,wa_final2,lv_amount.
*    ENDLOOP.
*
*  ENDLOOP.
*  it_final1[] = it_final2[].

******************************************
*  LOOP AT it_bseg INTO wa_bseg ."WHERE projk = wa_final2-ps_psp_pnr.
*
*    LOOP AT it_final1 INTO wa_final1.
*
*
*
*    ENDLOOP.
*
*  ENDLOOP.
  CLEAR wa_final1.
  DATA : lv_bukrs   TYPE t001-bukrs,
         lv_lifnr   TYPE lfa1-lifnr,
         lv_name1   TYPE lfa1-name1,
         lv_anln1   TYPE bseg-anln1,
         lv_psp_pnr TYPE string,
         lv_xref    TYPE bseg-xref1,
*         lv_date type bseg-budat,
         lv_werks   TYPE werks,
         lv_fidate  TYPE bkpf-budat,
         lv_bldat   TYPE bkpf-bldat,
         lv_xblnr   TYPE bkpf-xblnr,
         lv_txt50   TYPE anla-txt50,
         lv_igst    TYPE bset-hwste,
         lv_cgst    TYPE bset-hwste,
         lv_sgst    TYPE bset-hwste,

         gv_igst    TYPE bset-hwste,
         gv_cgst    TYPE bset-hwste,
         gv_sgst    TYPE bset-hwste,

         gv_igst1   TYPE bset-hwste,
         gv_cgst1   TYPE bset-hwste,
         gv_sgst1   TYPE bset-hwste.
  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 13.01.2026  FOR ATC
  SORT it_bsegfi.
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC

  LOOP AT it_bsegfi INTO wa_bsegfi.

    LOOP AT it_bset2 INTO wa_bset2 WHERE belnr = wa_bsegfi-belnr
                                   AND hkont = wa_bsegfi-hkont
                                   AND txgrp = wa_bsegfi-txgrp.

      IF wa_bset2-kschl EQ 'JIIG'.
        lv_igst = lv_igst + wa_bset2-hwste.
        gv_igst = lv_igst +   gv_igst.

        IF wa_bset2-shkzg = 'H'.
          gv_igst = gv_igst * -1.
        ENDIF.
      ENDIF.

      IF wa_bset2-kschl EQ 'JICG'.
        lv_cgst = lv_cgst + wa_bset2-hwste.
        gv_cgst = lv_cgst +   gv_cgst.

        IF wa_bset2-shkzg = 'H'.
          gv_cgst = gv_cgst * -1.
        ENDIF.

      ENDIF.

      IF wa_bset2-kschl EQ 'JISG'.
        lv_sgst = lv_sgst + wa_bset2-hwste.
        gv_sgst = lv_sgst +   gv_sgst.

        IF wa_bset2-shkzg = 'H'.
          gv_sgst = gv_sgst * -1.
        ENDIF.

      ENDIF.

      CLEAR : lv_igst,lv_cgst,lv_sgst,wa_bset2.

    ENDLOOP.

    IF wa_bsegfi-projk IS NOT INITIAL.
      IF wa_bsegfi-shkzg = 'H'.
        wa_bsegfi-dmbtr = ( wa_bsegfi-dmbtr * -1 ).
      ENDIF.
      lv_amount  = lv_amount + wa_bsegfi-dmbtr.
    ENDIF.
    IF lv_bukrs  IS  INITIAL.
      lv_bukrs = wa_bsegfi-bukrs.
    ENDIF.

    IF lv_lifnr IS  INITIAL.
      lv_lifnr = wa_bsegfi-lifnr.
      SELECT SINGLE name1 FROM lfa1 INTO lv_name1 WHERE lifnr = lv_lifnr.
    ENDIF.

    IF lv_werks IS  INITIAL.
      lv_werks = wa_bsegfi-prctr+0(4).

    ENDIF.

    IF wa_bsegfi-projk IS NOT INITIAL.
      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = wa_bsegfi-projk
        IMPORTING
          output = lv_psp_pnr.
      " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
*      SELECT SINGLE anln1 txt50 INTO ( lv_anln1 , lv_txt50 ) FROM anla WHERE posnr = wa_bsegfi-projk.

      SELECT anln1 txt50 INTO ( lv_anln1 , lv_txt50 ) UP TO 1 ROWS FROM anla WHERE posnr = wa_bsegfi-projk ORDER BY PRIMARY KEY.ENDSELECT.
      " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 13.01.2026 FOR ATC
    ENDIF.


    IF lv_fidate IS INITIAL.
      SELECT SINGLE bldat budat xblnr FROM bkpf INTO ( lv_fidate , lv_bldat ,lv_xblnr ) WHERE bukrs = wa_bsegfi-bukrs AND belnr = wa_bsegfi-belnr AND gjahr = wa_bsegfi-gjahr.
    ENDIF.
    AT END OF belnr.
      wa_final1-fidoc = wa_bsegfi-belnr.
*      wa_final1-netamt =  lv_amount. "Comment by Rahul Vasita on 15.03.2024 15:28:29
      wa_final1-bukrs = lv_bukrs.
      wa_final1-lifnr = lv_lifnr.
      wa_final1-name1  = lv_name1.
      wa_final1-anln1 = lv_anln1.
      wa_final1-ps_psp_pnr  = lv_psp_pnr.
      wa_final1-txt50  = lv_txt50.
      wa_final1-werks = lv_werks.
      wa_final1-fipdate = lv_fidate.
      wa_final1-igst = gv_igst. "
      wa_final1-cgst = gv_cgst.
      wa_final1-sgst = gv_sgst.
      wa_final1-igstcr = gv_igst. "
      wa_final1-cgstcr = gv_cgst.
      wa_final1-sgstcr = gv_sgst.
      wa_final1-midocdate = lv_bldat.
      wa_final1-miref = lv_xblnr.
      wa_final1-finalamt   =  lv_amount. "Added by Rahul Vasita on 15.03.2024 15:29:30
      wa_final1-basictax = ( wa_final1-finalamt + wa_final1-freight + wa_final1-delcost ). "Added by Rahul Vasita on 15.03.2024 15:28:33
*      wa_final1-miamt  = wa_final1-netamt. "Comment by Rahul Vasita on 15.03.2024 15:53:12
      wa_final1-miamt  = lv_amount."Added by Rahul Vasita on 15.03.2024 15:53:52
*      wa_final1-total = wa_final1-netamt - ( gv_igst + gv_cgst + gv_sgst ). "Comment by Rahul Vasita on 15.03.2024 15:53:36
      wa_final1-total = wa_final1-basictax + gv_igst + gv_cgst + gv_sgst + wa_final-bed + wa_final-vat + wa_final-addvat + wa_final-serv +
                        wa_final-cst + wa_final-ro + wa_final-octroi + wa_final-other + wa_final-serfreight + wa_final-sbc + wa_final-kkc
                        + wa_final-customdty. "Added by Rahul Vasita on 15.03.2024 15:53:55
      wa_final1-crtotal = wa_final1-cgstcr + wa_final1-sgstcr + wa_final1-igstcr + wa_final1-crvat + wa_final1-crexcise + wa_final1-crserv . "Added by Rahul Vasita on 15.03.2024 15:28:39
      wa_final1-netamt = wa_final1-total - wa_final1-crtotal.

      APPEND  wa_final1 TO it_final1.
      CLEAR : wa_final1,lv_amount,wa_bsegfi,lv_amount,lv_bukrs,lv_lifnr,lv_name1,lv_anln1,lv_psp_pnr,lv_txt50,lv_fidate,gv_igst,gv_cgst,gv_sgst,wa_bset2,lv_bldat,lv_xblnr,gv_igst1,gv_cgst1,gv_sgst1.
    ENDAT.

    CLEAR : wa_bsegfi,wa_final1.

  ENDLOOP.

**************Added by Raj on 04.10.2023*************************************.
  "Adding Start by Rahul Vasita on 18.03.2024 13:52:21
  LOOP AT it_final1 ASSIGNING <wa_final1>.

    IF <wa_final1>-freight IS INITIAL.
      LOOP AT it_rseg INTO wa_rseg WHERE ebeln = <wa_final1>-ebeln
                                       AND ebelp = <wa_final1>-ebelp.
        IF wa_rseg-kschl EQ 'FRC1' OR wa_rseg-kschl EQ 'FRB1' OR wa_rseg-kschl EQ 'FRB2' OR wa_rseg-kschl EQ 'FRC2'
        OR wa_rseg-kschl EQ 'FRC4' OR wa_rseg-kschl EQ 'FRB3' OR wa_rseg-kschl EQ 'FRB4' OR wa_rseg-kschl EQ 'FRC5'
        OR wa_rseg-kschl EQ 'P&F3' OR wa_rseg-kschl EQ 'P&F1' OR wa_rseg-kschl EQ 'P&F2' OR wa_rseg-kschl EQ 'ZTER'
        OR wa_rseg-kschl EQ 'ZSHP' OR wa_rseg-kschl EQ 'JFR1' OR wa_rseg-kschl EQ 'JCFA' OR wa_rseg-kschl EQ 'JFR2'
        OR wa_rseg-kschl EQ 'JOFP' OR wa_rseg-kschl EQ 'JOFV' OR wa_rseg-kschl EQ 'ZFR1' OR wa_rseg-kschl EQ 'ZOFV' . "#EC CI_USAGE_OK[2469385]
          IF wa_rseg-shkzg EQ 'H'.
            <wa_final1>-crfreight =  <wa_final1>-drfreight + wa_rseg-wrbtr .
          ELSEIF wa_rseg-shkzg EQ 'S'.
            <wa_final1>-drfreight = <wa_final1>-drfreight + wa_rseg-wrbtr .
          ENDIF.

        ENDIF.
        CLEAR : wa_rseg .
      ENDLOOP.
      <wa_final1>-frdiff = <wa_final1>-drfreight - <wa_final1>-crfreight .

      IF <wa_final1>-shkzg EQ 'S'.   " Added on 20.09.2019
        <wa_final1>-freight = <wa_final1>-freight + <wa_final1>-frdiff .
      ELSE.
        <wa_final1>-freight =  ( <wa_final1>-freight + <wa_final1>-frdiff ) * -1 .
      ENDIF.
      <wa_final1>-basictax = <wa_final1>-basictax +  <wa_final1>-freight.
      <wa_final1>-totfreight = <wa_final1>-freight + <wa_final1>-delcost .
      <wa_final1>-total = <wa_final1>-total + <wa_final1>-freight.
      <wa_final1>-netamt = <wa_final1>-total - <wa_final1>-crtotal.

    ENDIF.
  ENDLOOP.
  "Adding End by Rahul Vasita on 18.03.2024 13:52:21

**  "Adding Start by Rahul Vasita on 17.04.2024 16:31:59 FOR CLUBBING MIGO and Make it to Single MIRO
**  SORT it_final1 BY bukrs anln1 ebeln ebelp mblnr belnr fidoc.
**  DELETE ADJACENT DUPLICATES FROM it_final1 COMPARING bukrs anln1 ebeln ebelp mblnr belnr fidoc.
**  "Adding End by Rahul Vasita on 17.04.2024 16:31:59

  DELETE it_final1 WHERE bukrs IS INITIAL AND anln1 IS INITIAL.

  LOOP AT it_final1 INTO wa_final1.
    AUTHORITY-CHECK OBJECT 'Z_WBSR_WRK'
     ID 'WERKS' FIELD wa_final1-werks
     ID 'ACTVT' FIELD '03'.
    IF sy-subrc NE 0.
*      MESSAGE e018(zfi) WITH wa_final-prctr.
      DELETE it_final1 WHERE werks = wa_final1-werks AND anln1 = wa_final1-anln1 AND ebeln = wa_final1-ebeln AND ebelp = wa_final1-ebelp.
    ENDIF.
    CLEAR: wa_final1.
  ENDLOOP.


ENDFORM.                    " COMBINE
*&---------------------------------------------------------------------*
*&      Form  FILLCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fillcat .

  DEFINE fillcat.

    wa_fcat-col_pos        = &1.
    wa_fcat-tabname        = &2.
    wa_fcat-fieldname      = &3.
    wa_fcat-seltext_l      = &4.
    wa_fcat-no_out         = &5.
    WA_fCAT-do_sum         = &6.
    WA_fCAT-no_zero        = &7.
    wa_fcat-hotspot        = &8.
    wa_fcat-ref_fieldname  = &9.
    IF wa_fcat-fieldname = 'LIFNR'.
wa_fcat-outputlen = 20.
    ENDIF.
    APPEND WA_fCAT TO it_fcat.

  END-OF-DEFINITION.


  fillcat 1 'IT_FINAL1'      'BUKRS'       'Company Code'                  ' '     ' '  ' ' 'X'  'BUKRS'.
  fillcat 1 'IT_FINAL1'      'WERKS'       'Plant'                         ' '     ' '  ' ' ' '  'WERKS'.
  fillcat 1 'IT_FINAL1'      'ANLN1'       'Main Asset Number'             ' '     ' '  ' ' 'X'  'ANLN1' .
  fillcat 1 'IT_FINAL1'      'TXT50'       'Asset Description'             ' '     ' '  ' ' ' '  'TXT50'  .
  fillcat 1 'IT_FINAL1'      'ANLN2'       'Sub Asset Number'              'X'     ' '  ' ' ' '  'ANLN2'.
  fillcat 1 'IT_FINAL1'      'ANLKL'       'Asset Class'                   'X'     ' '  ' ' ' '  'ANLKL'.
  fillcat 1 'IT_FINAL1'      'ANLAR'       'Asset Type'                    'X'     ' '  ' ' ' '  'ANLAR'.
  fillcat 1 'IT_FINAL1'      'ZUGDT'       'Asset Date'                    'X'     ' '  ' ' ' '  'ZUGDT'.
  fillcat 1 'IT_FINAL1'      'EBELN'       'PO No.'                       ' '     ' '  ' ' ' '  'EBELN'.
  fillcat 1 'IT_FINAL1'      'EBELP'       'PO Item No.'                       ' '     ' '  ' ' ' '  'EBELP'.
  fillcat 1 'IT_FINAL1'      'BUDAT'       'PO Date'                       ' '     ' '  ' ' ' '  'BUDAT'.
  fillcat 1 'IT_FINAL1'      'NETPR'       'Rate'                          'X'     ' '  ' ' ' '  'NETPR'.
  fillcat 1 'IT_FINAL1'      'POAMT'       'PO Amt'                        ' '     ' '  ' ' ' '  'POAMT'.
**  fillcat 1 'IT_FINAL1'      'EBELP'       'PO Item Num'                   'X'     ' '  ' ' ' '  'EBELP'. "Comment by Rahul Vasita on 17.04.2024 18:57:34
  fillcat 1 'IT_FINAL1'      'POQUAN'      'PO Qunatity'                   'X'     ' '  ' ' ' '  'POQUAN'.
*  fillcat 1 'IT_FINAL'      'POAMT'       'PO Amount'                     'X'     ' '  ' ' ' '  'POAMT'.
  fillcat 1 'IT_FINAL1'      'SAKTO'       'G/L account'                   'X'     ' '  ' ' ' '  'SAKTO'.
  fillcat 1 'IT_FINAL1'      'MATNR'       'Material Code'                  ' '     ' '  ' ' ' '  'MATNR'.
  fillcat 1 'IT_FINAL1'      'MAKTX'       'Material Desc.'                ' '     ' '  ' ' ' '  'MAKTX'.
  fillcat 1 'IT_FINAL1'      'MEINS'       'UOM'                           ' '     ' '  ' ' ' '  'MEINS'.
  fillcat 1 'IT_FINAL1'      'LIFNR'       'Vendor'                        ' '     ' '  'X' ' '  'LIFNR'.
  fillcat 1 'IT_FINAL1'      'NAME1'       'Vendor Name'                   ' '     ' '  ' ' ' '  'NAME1'.
  fillcat 1 'IT_FINAL1'      'MBLNR'       'MIGO No.'                     ' '     ' '  ' ' ' '  'MBLNR'. "Comment by Rahul Vasita on 17.04.2024 18:57:50
  fillcat 1 'IT_FINAL1'      'MIGODATE'    'MIGO Date'                     ' '     ' '  ' ' ' '  'MIGODATE'. "Comment by Rahul Vasita on 17.04.2024 18:57:53
  fillcat 1 'IT_FINAL1'      'MENGE'       'Qty.(MIGO)'                     ' '     ' '  ' ' ' '  'MENGE'.
  fillcat 1 'IT_FINAL1'      'DMBTR'       'MIGO Amount'                   'X'     ' '  ' ' ' '  'DMBTR'.
  fillcat 1 'IT_FINAL1'      'BELNR'       'MIRO No.'                     ' '     ' '  ' ' ' '  'BELNR'.
  fillcat 1 'IT_FINAL1'      'MIDATE'      'MIRO Date'                     ' '     ' '  ' ' ' '  'MIDATE'.
  fillcat 1 'IT_FINAL1'      'MIDOCDATE'      'Document Date'                     ' '     ' '  ' ' ' '  'MIDOCDATE'.
  fillcat 1 'IT_FINAL1'      'MIREF'      'Reference'                     ' '     ' '  ' ' ' '  'MIREF'.
  fillcat 1 'IT_FINAL1'      'FIDOC'       'FI Document'                   ' '     ' '  ' ' ' '  'FIDOC'.
  fillcat 1 'IT_FINAL1'      'FIPDATE'       'FI Posting Date'                   ' '     ' '  ' ' ' '  'FIPDATE'.

  fillcat 1 'IT_FINAL1'      'MIQUAN'      'Qty.(MIRO)'                     ' '     ' '  ' ' ' '  'MIQUAN' .
  fillcat 1 'IT_FINAL1'      'MIAMT'       'MIRO Amt'                      ' '     ' '  ' ' ' '  'MIAMT'.
  fillcat 1 'IT_FINAL1'      'AMOUNT'      'Ex. Base Amt'                  ' '     ' '  ' ' ' '  'AMOUNT'.

  fillcat 1 'IT_FINAL1'      'FINALAMT'    'Basic Amt.(MIRO)'                     ' '     ' '  ' ' ' '  'FINALAMT'.
  fillcat 1 'IT_FINAL1'      'FREIGHT'     'Freight (MIRO)'                       ' '     ' '  ' ' ' '  'FREIGHT'.
  fillcat 1 'IT_FINAL1'      'DELCOST'     'Unplanned Del. Cost'                       ' '     ' '  ' ' ' '  'DELCOST'.

  fillcat 1 'IT_FINAL1'      'BASICTAX'       'Taxable Basic (MIRO)'                      ' '     ' '  ' ' ' '  'BASICTAX'.
  fillcat 1 'IT_FINAL1'      'CGST'        'CGST'                     ' '     ' '  ' ' ' '  'CGST'.
  fillcat 1 'IT_FINAL1'      'SGST'        'SGST'                     ' '     ' '  ' ' ' '  'SGST'.
  fillcat 1 'IT_FINAL1'      'IGST'        'IGST'                     ' '     ' '  ' ' ' '  'IGST'.

  fillcat 1 'IT_FINAL1'      'GSTTOT'        'GST Total'                     'X'     ' '  ' ' ' '  'GSTTOT'.

  fillcat 1 'IT_FINAL1'      'BED'         'Excise'                        ' '     ' '  ' ' ' '  'BED'.
  fillcat 1 'IT_FINAL1'      'VAT'         'VAT'                           ' '     ' '  ' ' ' '  'VAT'.
  fillcat 1 'IT_FINAL1'      'ADDVAT'      'ADD. VAT'                      ' '     ' '  ' ' ' '  'ADDVAT'.
  fillcat 1 'IT_FINAL1'      'SERV'        'Service Tax'                   ' '     ' '  ' ' ' '  'SERV'.
  fillcat 1 'IT_FINAL1'      'CST'         'CST'                           ' '     ' '  ' ' ' '  'CST'.
  fillcat 1 'IT_FINAL1'      'RO'          'R.O.'                          'X'     ' '  ' ' ' '  'RO'.
  fillcat 1 'IT_FINAL1'      'OCTROI'      'OCTROI'                        'X'     ' '  ' ' ' '  'OCTROI'.
  fillcat 1 'IT_FINAL1'      'OTHER'       'Other'                         'X'     ' '  ' ' ' '  'OTHER'.
  fillcat 1 'IT_FINAL1'      'SERFREIGHT'  'Ser. Freight'                  ' '     ' '  ' ' ' '  'SERFREIGHT'.
  fillcat 1 'IT_FINAL1'      'SBC'         'SBC'                           ' '     ' '  ' ' ' '  'SBC'.
  fillcat 1 'IT_FINAL1'      'KKC'         'KKC'                           ' '     ' '  ' ' ' '  'KKC'.

  fillcat 1 'IT_FINAL1'      'CUSTOMDTY'         'Custom Duty'                           ' '     ' '  ' ' ' '  'CUSTOMDTY'.

  fillcat 1 'IT_FINAL1'      'TOTAL'       'Grand Total'                         ' '     ' '  ' ' ' '  'TOTAL'.



  fillcat 1 'IT_FINAL1'      'CGSTCR'      'CR.CGST'                     ' '     ' '  ' ' ' '  'CGST'.
  fillcat 1 'IT_FINAL1'      'SGSTCR'      'CR.SGST'                     ' '     ' '  ' ' ' '  'SGST'.
  fillcat 1 'IT_FINAL1'      'IGSTCR'      'CR.IGST'                     ' '     ' '  ' ' ' '  'IGST'.
  fillcat 1 'IT_FINAL1'      'CREXCISE'    'CR. Excise'                    ' '     ' '  ' ' ' '  'CREXCISE'.
  fillcat 1 'IT_FINAL1'      'CRVAT'       'CR. VAT'                       ' '     ' '  ' ' ' '  'CRVAT'.
  fillcat 1 'IT_FINAL1'      'CRSERV'      'CR. Service'                   ' '     ' '  ' ' ' '  'CRVAT'.
  fillcat 1 'IT_FINAL1'      'CRTOTAL'     'CR. Total'                     ' '     ' '  ' ' ' '  'CRTOTAL'.


  fillcat 1 'IT_FINAL1'      'NETAMT'      'MIRO Capitalize Amt'                    ' '     ' '  ' ' ' '  'NETAMT'.
  fillcat 1 'IT_FINAL1'      'PS_PSP_PNR'      'WBS Element'                    ' '     ' '  ' ' ' '  'NETAMT'.

******************************************************************************************************************
*  fillcat 1 'IT_FINAL'      'BUKRS'       'Company Code'                  ' '     ' '  ' ' 'X'  'BUKRS'.
*  fillcat 1 'IT_FINAL'      'ANLN1'       'Main Asset Number'             ' '     ' '  ' ' 'X'  'ANLN1' .
*  fillcat 1 'IT_FINAL'      'TXT50'       'Asset Description'             ' '     ' '  ' ' ' '  'TXT50'  .
*  fillcat 1 'IT_FINAL'      'ANLN2'       'Sub Asset Number'              'X'     ' '  ' ' ' '  'ANLN2'.

*  fillcat 1 'IT_FINAL'      'ANLKL'       'Asset Class'                   'X'     ' '  ' ' ' '  'ANLKL'.
*  fillcat 1 'IT_FINAL'      'ANLAR'       'Asset Type'                    'X'     ' '  ' ' ' '  'ANLAR'.
*  fillcat 1 'IT_FINAL'      'ZUGDT'       'Asset Date'                    'X'     ' '  ' ' ' '  'ZUGDT'.
*  fillcat 1 'IT_FINAL'      'EBELN'       'Po Numb'                       ' '     ' '  ' ' ' '  'EBELN'.
*  fillcat 1 'IT_FINAL'      'BUDAT'       'Po date'                       ' '     ' '  ' ' ' '  'BUDAT'.
*  fillcat 1 'IT_FINAL'      'NETPR'       'Rate'                          'X'     ' '  ' ' ' '  'NETPR'.
*  fillcat 1 'IT_FINAL'      'POAMT'       'PO Amt'                        ' '     ' '  ' ' ' '  'POAMT'.
*  fillcat 1 'IT_FINAL'      'EBELP'       'PO Item Num'                   'X'     ' '  ' ' ' '  'EBELP'.
*  fillcat 1 'IT_FINAL'      'POQUAN'      'PO Qunatity'                   'X'     ' '  ' ' ' '  'POQUAN'.
*  fillcat 1 'IT_FINAL'      'POAMT'       'PO Amount'                     'X'     ' '  ' ' ' '  'POAMT'.
*  fillcat 1 'IT_FINAL'      'SAKTO'       'G/L account'                   'X'     ' '  ' ' ' '  'SAKTO'.
*  fillcat 1 'IT_FINAL'      'MBLNR'       'Migo Numb'                     ' '     ' '  ' ' ' '  'MBLNR'.
*  fillcat 1 'IT_FINAL'      'MIGODATE'    'Migo Date'                     ' '     ' '  ' ' ' '  'MIGODATE'.
*  fillcat 1 'IT_FINAL'      'MENGE'       'Migo quan'                     ' '     ' '  ' ' ' '  'MENGE'.
*  fillcat 1 'IT_FINAL'      'WERKS'       'Plant'                         ' '     ' '  ' ' ' '  'WERKS'.
*  fillcat 1 'IT_FINAL'      'MATNR'       'Material Num'                  ' '     ' '  ' ' ' '  'MATNR'.
*  fillcat 1 'IT_FINAL'      'MAKTX'       'Material Desc.'                ' '     ' '  ' ' ' '  'MAKTX'.
*  fillcat 1 'IT_FINAL'      'LIFNR'       'Vendor'                        ' '     ' '  ' ' ' '  'LIFNR'.
*  fillcat 1 'IT_FINAL'      'NAME1'       'Vendor Name'                   ' '     ' '  ' ' ' '  'NAME1'.
*  fillcat 1 'IT_FINAL'      'DMBTR'       'MIGO Amount'                   'X'     ' '  ' ' ' '  'DMBTR'.
*
*  fillcat 1 'IT_FINAL'      'BELNR'       'Miro Numb'                     ' '     ' '  ' ' ' '  'BELNR'.
*  fillcat 1 'IT_FINAL'      'MIDATE'      'Miro Date'                     ' '     ' '  ' ' ' '  'MIDATE'.
*  fillcat 1 'IT_FINAL'      'MIQUAN'      'Miro Quan'                     ' '     ' '  ' ' ' '  'MIQUAN' .
*  fillcat 1 'IT_FINAL'      'MIAMT'       'Miro Amt'                      ' '     ' '  ' ' ' '  'MIAMT'.
*  fillcat 1 'IT_FINAL'      'MEINS'       'UOM'                           ' '     ' '  ' ' ' '  'MEINS'.
*  fillcat 1 'IT_FINAL'      'FIDOC'       'FI Document'                   ' '     ' '  ' ' ' '  'FIDOC'.
*  fillcat 1 'IT_FINAL'      'FINALAMT'    'Final Amt'                     ' '     ' '  ' ' ' '  'FIDOC'.
*  fillcat 1 'IT_FINAL'      'AMOUNT'      'Ex. Base Amt'                  ' '     ' '  ' ' ' '  'AMOUNT'.
*  fillcat 1 'IT_FINAL'      'BED'         'Excise'                        ' '     ' '  ' ' ' '  'BED'.
*  fillcat 1 'IT_FINAL'      'VAT'         'VAT'                           ' '     ' '  ' ' ' '  'VAT'.
*  fillcat 1 'IT_FINAL'      'ADDVAT'      'ADD. VAT'                      ' '     ' '  ' ' ' '  'ADDVAT'.
*  fillcat 1 'IT_FINAL'      'SERV'        'Service Tax'                   ' '     ' '  ' ' ' '  'SERV'.
*  fillcat 1 'IT_FINAL'      'CST'         'CST'                           ' '     ' '  ' ' ' '  'CST'.
*  fillcat 1 'IT_FINAL'      'RO'          'R.O.'                          'X'     ' '  ' ' ' '  'RO'.
*  fillcat 1 'IT_FINAL'      'OCTROI'      'OCTROI'                        'X'     ' '  ' ' ' '  'OCTROI'.
*  fillcat 1 'IT_FINAL'      'OTHER'       'Other'                         'X'     ' '  ' ' ' '  'OTHER'.
*  fillcat 1 'IT_FINAL'      'FREIGHT'     'Freight'                       ' '     ' '  ' ' ' '  'FREIGHT'.
*  fillcat 1 'IT_FINAL'      'SERFREIGHT'  'Ser. Freight'                  ' '     ' '  ' ' ' '  'SERFREIGHT'.
*  fillcat 1 'IT_FINAL'      'SBC'         'SBC'                           ' '     ' '  ' ' ' '  'SBC'.
*  fillcat 1 'IT_FINAL'      'KKC'         'KKC'                           ' '     ' '  ' ' ' '  'KKC'.
*  fillcat 1 'IT_FINAL'      'TOTAL'       'Total'                         ' '     ' '  ' ' ' '  'TOTAL'.
*  fillcat 1 'IT_FINAL'      'CREXCISE'    'CR. Excise'                    ' '     ' '  ' ' ' '  'CREXCISE'.
*  fillcat 1 'IT_FINAL'      'CRVAT'       'CR. VAT'                       ' '     ' '  ' ' ' '  'CRVAT'.
*  fillcat 1 'IT_FINAL'      'CRSERV'      'CR. Service'                   ' '     ' '  ' ' ' '  'CRVAT'.
*  fillcat 1 'IT_FINAL'      'CGSTCR'      'CR.CGST'                     ' '     ' '  ' ' ' '  'CGST'.
*  fillcat 1 'IT_FINAL'      'SGSTCR'      'CR.SGST'                     ' '     ' '  ' ' ' '  'SGST'.
*  fillcat 1 'IT_FINAL'      'IGSTCR'      'CR.IGST'                     ' '     ' '  ' ' ' '  'IGST'.
*  fillcat 1 'IT_FINAL'      'CRTOTAL'     'CR. Total'                     ' '     ' '  ' ' ' '  'CRTOTAL'.
*  fillcat 1 'IT_FINAL'      'CGST'        'CGST'                     ' '     ' '  ' ' ' '  'CGST'.
*  fillcat 1 'IT_FINAL'      'SGST'        'SGST'                     ' '     ' '  ' ' ' '  'SGST'.
*  fillcat 1 'IT_FINAL'      'IGST'        'IGST'                     ' '     ' '  ' ' ' '  'IGST'.
*  fillcat 1 'IT_FINAL'      'NETAMT'      'Net Amount'                    ' '     ' '  ' ' ' '  'NETAMT'.
**  fillcat 1 'IT_FINAL'      'ASSCODE'     'Asset Code after Settlement'   ' '     ' '  ' ' ' '  'ASSCODE'.
**  fillcat 1 'IT_FINAL'      'AMTTRNF'     'Amount Transferred'            ' '     ' '  ' ' ' '  'AMTTRNF'.
**  fillcat 1 'IT_FINAL'      'AKTIV'       'Date of installation'          ' '     ' '  ' ' ' '  'DATEINS'.
*
*
**  fillcat 1 'IT_FINAL'     'erfmg '      'Quantity'                      ' '     ' '  ' ' ' '.

  wa_layout-zebra = 'X'.
  wa_layout-colwidth_optimize = 'X'.


ENDFORM.                    " FILLCAT
*&---------------------------------------------------------------------*
*&      Form  DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display .

  SORT it_final BY anln1.
  SORT it_final1 BY anln1.

*  DELETE it_final WHERE bsart NE 'CAPT' AND bsart NE 'SERV'.

*delete ADJACENT DUPLICATES FROM it_final1 COMPARING

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
      i_callback_user_command = 'USER_COMMAND'
*     I_CALLBACK_TOP_OF_PAGE  = ' '
      is_layout               = wa_layout
      it_fieldcat             = it_fcat
      i_save                  = 'A'
*     IS_VARIANT              =
*     IT_EVENTS               =
    TABLES
      t_outtab                = it_final1.

ENDFORM.                    " DISPLAY

FORM user_command USING ucomm LIKE sy-ucomm
                        selfield TYPE slis_selfield.
  CASE ucomm.
    WHEN '&IC1'.
      CLEAR wa_final1.
      READ TABLE it_final1 INTO wa_final1 INDEX selfield-tabindex.
      SET PARAMETER ID: 'AN1' FIELD wa_final1-anln1,
                        'BUK' FIELD wa_final1-bukrs.
*                        'GJR' field wa_final-gjahr.
      CALL TRANSACTION 'AS03' AND SKIP FIRST SCREEN.
  ENDCASE.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
**** Added changes by Carina Jose on 30.07.2020
*FORM authorization_check .
*  SELECT bukrs FROM t001 INTO TABLE gt_t001 WHERE bukrs IN s_bukrs.
*  LOOP AT gt_t001 INTO wa_t001.
*    AUTHORITY-CHECK OBJECT 'Z_FI_BUKRS'
*    ID 'BUKRS' FIELD wa_t001-bukrs
*    ID 'ACTVT' FIELD '03'.
*    IF sy-subrc <> 0.
*      MESSAGE e014(zsd) WITH wa_t001-bukrs.
*    ENDIF.
*  ENDLOOP.
*ENDFORM.
**** Added changes by Carina Jose on 30.07.2020
*&---------------------------------------------------------------------*
*&      Form  GET_GSTFRIEGHT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_WA_FINAL1  text
*----------------------------------------------------------------------*
FORM get_gstfrieght  CHANGING p_wa_final1 TYPE ty_final.

ENDFORM.
