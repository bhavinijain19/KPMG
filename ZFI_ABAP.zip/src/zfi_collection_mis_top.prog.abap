*&---------------------------------------------------------------------*
*&  Include           ZFI_COLLECTION_MIS_TOP
*&---------------------------------------------------------------------*
TYPE-POOLS : slis , abap .
TABLES : knvv , bsid , bsad.


TYPES : BEGIN OF ty_knvv,
          kunnr TYPE kunnr,
          vkorg TYPE vkorg,
          vtweg TYPE vtweg,
          spart TYPE spart,
          kdgrp TYPE kdgrp,
          name1 TYPE name1_gp,
          bezei TYPE bezei20,
        END OF ty_knvv,
        BEGIN OF ty_kdgrp,
          custgrp(10) TYPE c,
          seq_no      TYPE i,
        END OF ty_kdgrp,
        BEGIN OF ty_pivot,
          vkorg        TYPE vkorg,
          kvgr1        TYPE knvv-kvgr1,
          seq          TYPE i,
          division(10) TYPE c,
          dz_amt       TYPE p LENGTH 16 DECIMALS 2,
          dg_amt       TYPE p LENGTH 16 DECIMALS 2,
          total        TYPE p LENGTH 16 DECIMALS 2,
        END OF ty_pivot.

DATA : lt_knvv     TYPE zfi_coll_mis_knvv_tt, " WITH UNIQUE KEY kunnr vkorg vtweg spart, "ty_knvv
       ls_knvv     TYPE zfi_coll_mis_knvv_ts,
       lt_bstab    TYPE  zfi_coll_mis_bs_tt,
       ls_bstab    TYPE  zfi_coll_mis_bs_ts,
       lt_final    TYPE  zfi_collection_mis_tt,
       ls_final    TYPE  zfi_collection_mis_ts,
       lt_detail   TYPE zfi_collection_mis_detail_tt,
       ls_detail   TYPE zfi_collection_mis_detail_ts,
       lt_pivot_m  TYPE TABLE OF ty_pivot,
       ls_pivot_m  TYPE ty_pivot,
       lt_pivot_d  TYPE TABLE OF ty_pivot,
       ls_pivot_d  TYPE ty_pivot,
       lt_kdgrpseq TYPE TABLE OF ty_kdgrp,
       ls_kdgrpseq TYPE ty_kdgrp.
DATA:ls_fieldcat TYPE slis_fieldcat_alv,
     lt_fieldcat TYPE slis_t_fieldcat_alv.
DATA:ls_layout TYPE slis_layout_alv,
     lt_header TYPE slis_t_listheader,
     ls_header TYPE slis_listheader.
FIELD-SYMBOLS : <ls_pivot> TYPE ty_pivot.
DATA : lo_cwip TYPE REF TO zcl_collection_mis.

"Excel and Mail Data Declarations Starts
DATA : gc_tab        TYPE c VALUE cl_bcs_convert=>gc_tab,
       gc_crlf       TYPE c VALUE cl_bcs_convert=>gc_crlf,
       send_request  TYPE REF TO cl_bcs,
       sender        TYPE REF TO cl_cam_address_bcs,
       document      TYPE REF TO cl_document_bcs,
*       lo_document   TYPE REF TO cl_document_bcs,
       recipient     TYPE REF TO if_recipient_bcs,
       lv_mail       TYPE adr6-smtp_addr,
       bcs_exception TYPE REF TO cx_bcs.
DATA : main_text      TYPE bcsy_text,
       binary_content TYPE solix_tab,
       size           TYPE so_obj_len,
       send_to_all    TYPE os_boolean,
       lv_attachname  TYPE so_obj_des,
       lv_string      TYPE string,
       ld_string      TYPE string,
       lv_dz          TYPE char20,
       lv_dg          TYPE char20,
       lv_total       TYPE char20,
       lv_amt         TYPE char20.
DATA : lv_mailtext TYPE char255.
CONSTANTS: lc_tab  TYPE c VALUE cl_bcs_convert=>gc_tab,
           lc_crlf TYPE c VALUE cl_bcs_convert=>gc_crlf.
DATA : longtext   LIKE  t247-ltx,
       lv_totamt  TYPE p LENGTH 16 DECIMALS 2,
       lv_dztotal TYPE p LENGTH 16 DECIMALS 2,
       lv_dgtotal TYPE p LENGTH 16 DECIMALS 2,
       lv_date1   TYPE char10.
*       lv_date2 TYPE char50. s_kdgrp FOR knvv-kdgrp,
*DATA : .
DATA : lv_start TYPE d,
       lv_end   TYPE d.
RANGES : s_vtweg FOR knvv-vtweg,
         s_spart FOR knvv-spart,
         s_blart FOR bsad-blart.
DATA : lv_flag(1) TYPE c.

DATA: lt_kdgrp TYPE TABLE OF zfi_mis_kdgrp,
      ls_kdgrp TYPE zfi_mis_kdgrp.
