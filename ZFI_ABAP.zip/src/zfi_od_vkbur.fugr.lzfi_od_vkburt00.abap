*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_OD_VKBUR....................................*
DATA:  BEGIN OF STATUS_ZFI_OD_VKBUR                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_OD_VKBUR                  .
CONTROLS: TCTRL_ZFI_OD_VKBUR
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_OD_VKBUR                  .
TABLES: ZFI_OD_VKBUR                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
