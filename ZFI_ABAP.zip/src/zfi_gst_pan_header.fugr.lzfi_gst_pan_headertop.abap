FUNCTION-POOL zfi_gst_pan_header.           "MESSAGE-ID ..

* INCLUDE LZFI_GST_PAN_HEADERD...            " Local class definition

DATA: zgstin  TYPE lfa1-stcd3,     " GST Number
      zpan    TYPE lfa1-j_1ipanno, " PAN Number
      g_lifnr TYPE lfa1-lifnr.   " Global Vendor Number
