class ZCL_ZFI_HSBC_RF_UTR_MPC_EXT definition
  public
  inheriting from ZCL_ZFI_HSBC_RF_UTR_MPC
  create public .

public section.

  methods DEFINE
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZFI_HSBC_RF_UTR_MPC_EXT IMPLEMENTATION.


  METHOD define.
    super->define( ). " Always call super first

    DATA(lo_entity) = model->get_entity_type( 'HSBCUTR' ).
    IF lo_entity IS BOUND.
      " Tells SAP that 'MimeType' property holds the file's media type
      DATA(lo_property) = lo_entity->get_property( 'MimeType' ).
      lo_property->set_as_content_type( ).
    ENDIF.
  ENDMETHOD.
ENDCLASS.
