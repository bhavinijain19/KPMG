*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_EXP_EXTRATOP.                 " Global Data
  INCLUDE LZFI_EXP_EXTRAUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_EXP_EXTRAF...                 " Subroutines
* INCLUDE LZFI_EXP_EXTRAO...                 " PBO-Modules
* INCLUDE LZFI_EXP_EXTRAI...                 " PAI-Modules
* INCLUDE LZFI_EXP_EXTRAE...                 " Events
* INCLUDE LZFI_EXP_EXTRAP...                 " Local class implement.
* INCLUDE LZFI_EXP_EXTRAT99.                 " ABAP Unit tests
  INCLUDE LZFI_EXP_EXTRAF00                       . " subprograms
  INCLUDE LZFI_EXP_EXTRAI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
