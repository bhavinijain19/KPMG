*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCR_MATX_NEWTOP.                  " Global Declarations
  INCLUDE LZCR_MATX_NEWUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCR_MATX_NEWF...                  " Subroutines
* INCLUDE LZCR_MATX_NEWO...                  " PBO-Modules
* INCLUDE LZCR_MATX_NEWI...                  " PAI-Modules
* INCLUDE LZCR_MATX_NEWE...                  " Events
* INCLUDE LZCR_MATX_NEWP...                  " Local class implement.
* INCLUDE LZCR_MATX_NEWT99.                  " ABAP Unit tests
  INCLUDE LZCR_MATX_NEWF00                        . " subprograms
  INCLUDE LZCR_MATX_NEWI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
