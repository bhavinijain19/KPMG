*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_PDC_BANK....................................*
DATA:  BEGIN OF STATUS_ZFI_PDC_BANK                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_PDC_BANK                  .
CONTROLS: TCTRL_ZFI_PDC_BANK
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_PDC_BANK                  .
TABLES: ZFI_PDC_BANK                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
