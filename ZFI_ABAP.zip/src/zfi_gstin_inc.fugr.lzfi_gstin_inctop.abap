FUNCTION-POOL ZFI_GSTIN_INC              MESSAGE-ID SV.

* INCLUDE LZFI_GSTIN_INCD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_GSTIN_INCT00                       . "view rel. data dcl.
