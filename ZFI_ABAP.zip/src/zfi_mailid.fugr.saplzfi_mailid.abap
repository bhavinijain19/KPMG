*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_MAILIDTOP.                    " Global Declarations
  INCLUDE LZFI_MAILIDUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_MAILIDF...                    " Subroutines
* INCLUDE LZFI_MAILIDO...                    " PBO-Modules
* INCLUDE LZFI_MAILIDI...                    " PAI-Modules
* INCLUDE LZFI_MAILIDE...                    " Events
* INCLUDE LZFI_MAILIDP...                    " Local class implement.
* INCLUDE LZFI_MAILIDT99.                    " ABAP Unit tests
  INCLUDE LZFI_MAILIDF00                          . " subprograms
  INCLUDE LZFI_MAILIDI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
