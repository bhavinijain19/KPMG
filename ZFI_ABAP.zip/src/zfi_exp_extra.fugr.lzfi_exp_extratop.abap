FUNCTION-POOL ZFI_EXP_EXTRA              MESSAGE-ID SV.

* INCLUDE LZFI_EXP_EXTRAD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_EXP_EXTRAT00                       . "view rel. data dcl.
