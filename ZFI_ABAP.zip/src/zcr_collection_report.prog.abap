*&---------------------------------------------------------------------*
*& Report ZCR_COLLECTION_REPORT
*&---------------------------------------------------------------------*
*&
*& CREATED BY AARTI KUMARI VSD 27.03.2026 ...
*&
*&---------------------------------------------------------------------*
REPORT zcr_collection_report.

TABLES:zfi_colle_log.

DATA:lo_alv TYPE REF TO cl_salv_table.
DATA:lo_col TYPE REF TO cl_salv_columns_table.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

  PARAMETERS:s_bukrs TYPE zfi_colle_log-bukrs OBLIGATORY.

  SELECT-OPTIONS:s_pos FOR zfi_colle_log-budat OBLIGATORY,
                 s_hkont FOR zfi_colle_log-hkont OBLIGATORY.
  PARAMETERS: rb_h2h RADIOBUTTON GROUP grp1 DEFAULT 'X',
              rb_API RADIOBUTTON GROUP grp1.

SELECTION-SCREEN END OF BLOCK b1.

START-OF-SELECTION.

*  AUTHORITY-CHECK OBJECT 'Z_HKONT'
*  ID 'HKONT' FIELD s_hkont.

  PERFORM auth_check.
  IF rb_h2h = abap_true.
    PERFORM get_DISP_data.
  ELSE.
    PERFORM get_dis_Data_API.
  ENDIF.

*&---------------------------------------------------------------------*
*& Form get_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_DISP_data .

  SELECT bukrs,
  zuonr,
  filename,
  bldat,
  blart,
  budat,
  monat,
  waers,
  hkont,
  dmbtr,
  vdate,
  text,
  kunnr,
  belnr,
  erdat,
  erzet,
  message,
  status,
  van
    FROM zfi_colle_log
    INTO TABLE @DATA(lt_final)
    WHERE bukrs = @s_bukrs
    AND budat IN @s_pos
    AND hkont IN @s_hkont.

  IF lt_final IS NOT INITIAL  .

    cl_salv_table=>factory(
      IMPORTING
        r_salv_table = lo_alv                     " Basis Class Simple ALV Tables
      CHANGING
        t_table      = lt_final ).

    lo_col = lo_alv->get_columns( ).

    lo_col->set_optimize( ).

    lo_alv->display( ).

  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form auth_check
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM auth_check .

  SELECT hkont FROM zfi_colle_log INTO TABLE @DATA(it_COLL) WHERE hkont IN @s_hkont.
  SORT it_COLL DESCENDING.
  DELETE ADJACENT DUPLICATES FROM it_COLL .

  LOOP AT it_COLL ASSIGNING FIELD-SYMBOL(<wa_coll>).

    AUTHORITY-CHECK OBJECT 'Z_HKONT'
    ID 'HKONT' FIELD <wa_coll>-hkont
    ID 'ACTVT' FIELD '03'.

    IF sy-subrc <> 0.

      MESSAGE 'No authorization' TYPE 'E' DISPLAY LIKE 'S'.

    ENDIF.

  ENDLOOP.
  UNASSIGN : <wa_coll>.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_dis_Data_API
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_dis_Data_API .

  SELECT bukrs,
 zuonr,
 filename,
 bldat,
 blart,
 budat,
 monat,
 waers,
 hkont,
 dmbtr,
 vdate,
 text,
 kunnr,
 belnr,
 erdat,
 erzet,
 message,
 status,
 van
   FROM zfi_colle_log_ap
   INTO TABLE @DATA(lt_final)
   WHERE bukrs = @s_bukrs
   AND budat IN @s_pos
   AND hkont IN @s_hkont.

  IF lt_final IS NOT INITIAL  .

    cl_salv_table=>factory(
      IMPORTING
        r_salv_table = lo_alv                     " Basis Class Simple ALV Tables
      CHANGING
        t_table      = lt_final ).

    lo_col = lo_alv->get_columns( ).

    lo_col->set_optimize( ).

    lo_alv->display( ).

  ENDIF.


ENDFORM.
