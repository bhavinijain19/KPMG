*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_PDC_BANKTOP.                  " Global Data
  INCLUDE LZFI_PDC_BANKUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_PDC_BANKF...                  " Subroutines
* INCLUDE LZFI_PDC_BANKO...                  " PBO-Modules
* INCLUDE LZFI_PDC_BANKI...                  " PAI-Modules
* INCLUDE LZFI_PDC_BANKE...                  " Events
* INCLUDE LZFI_PDC_BANKP...                  " Local class implement.
* INCLUDE LZFI_PDC_BANKT99.                  " ABAP Unit tests
  INCLUDE LZFI_PDC_BANKF00                        . " subprograms
  INCLUDE LZFI_PDC_BANKI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
