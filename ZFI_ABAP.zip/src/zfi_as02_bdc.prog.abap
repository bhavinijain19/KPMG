*&---------------------------------------------------------------------*
*& Report  ZFI_AS02_BDC
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zfi_as02_bdc

*REPORT zfi_as01
       NO STANDARD PAGE HEADING LINE-SIZE 255.


TABLES : t100.

TYPES: BEGIN OF  ty_file,
         name(25) TYPE  c,
       END OF   ty_file.

TYPES: BEGIN OF ty_record,

         anlkl(12),
         anln2(12),
         bukrs(04),
         "NASSETS(),
         txt50(50),
         txt501(50),
         sernr(18),
         menge(13),
         meins(03),
*         xhist(01),
         aktiv(10),
         kostl(10),
         werks(04),
         stort(25),
*         ord41(04),
         lifnr(10), "Added by Rutvi on 16.05.2024
         "EQANZ(),
*         gd_liefe(30),
*         herst(30),
*         xgbr_am(01),
*         land1(03),
         typbz(15), "Added by Rutvi on 16.05.2024
*         urjhr(04),
*         urwrt(15),
         glo_in_blk_key(05),
         glo_in_ast_use(10),
*         glo_in_adnlblk(05),
*         glo_in_prior_yr(01),
         afasl01(04),
         ndjar01(03),
         ndper01(03),
         afabg01(10),
         schrw(15),
         schrw_proz(15),
         afasl02(04),
         ndjar02(03),
         ndper02(03),
         afabg02(10),
         schrw_proz1(15),

       END OF ty_record.

DATA : file_name TYPE string.

* *----------------------------------------------------------------------*
*   data definition
*----------------------------------------------------------------------*
*       Batchinputdata of single transaction
DATA:   bdcdata LIKE bdcdata    OCCURS 0 WITH HEADER LINE.
*       messages of call transaction
DATA:   messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA:   record TYPE STANDARD TABLE OF ty_record WITH HEADER LINE.
DATA  :t_raw TYPE truxs_t_text_data.
DATA: w_param TYPE ctu_params.
DATA: l_mstring(480).
DATA: l_subrc LIKE sy-subrc.


SELECTION-SCREEN BEGIN OF BLOCK a WITH FRAME TITLE text-000.
*PARAMETERS ctumode LIKE ctu_params-dismode DEFAULT 'A'.
* "A: show all dynpros "E: show dynpro on error only "N: do not display dynpro
*PARAMETERS : cupdate LIKE ctu_params-updmode DEFAULT 'S'.
*   "S: synchronously  "A: asynchronously  "L: local
PARAMETERS : p_file TYPE rlgrap-filename OBLIGATORY.
*PARAMETERS : p_start TYPE i OBLIGATORY DEFAULT 3,
*             p_end   TYPE i OBLIGATORY DEFAULT 9.

SELECTION-SCREEN END OF BLOCK a.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file .
  PERFORM get_path.
*  w_param-dismode = ctumode.
**  w_param-updmode = cupdate.
*  w_param-defsize = 'X'.

START-OF-SELECTION.
  break sap_abap.
  CLEAR file_name.
  file_name = p_file.
  PERFORM f_get_data.
  SELECT low FROM tvarvc INTO TABLE @DATA(lt_plant) WHERE name = 'ZPLANT'.
*
*include bdcrecx1.
*
*start-of-selection.
*
*perform open_group.
  LOOP AT record.
**************************Added by Rutvi on 20.05.2024
*    IF record-kostl IS INITIAL.
*      messtab-msgtyp = 'E'.
*      l_mstring = 'Cost Center is mandatory'.
*      WRITE: / messtab-msgtyp, l_mstring(250).
*      CLEAR: messtab-msgtyp,l_mstring.
*      CONTINUE.
*    ENDIF.
*    IF record-werks IS NOT INITIAL.
*      READ TABLE lt_plant INTO DATA(wa_plant) WITH KEY low = record-werks.
*      IF sy-subrc = 0.
*        IF record-kostl+0(4) NE record-werks.
*          messtab-msgtyp = 'E'.
*          CONCATENATE 'Cost Center doesnot match with plant' record-werks INTO l_mstring.
*          WRITE: / messtab-msgtyp, l_mstring(250).
*          CLEAR: messtab-msgtyp,l_mstring.
*          CONTINUE.
*        ENDIF.
*      ENDIF.
*    ELSE.
*      messtab-msgtyp = 'E'.
*      l_mstring = 'Plant is mandatory'.
*      WRITE: / messtab-msgtyp, l_mstring(250).
*      CLEAR: messtab-msgtyp,l_mstring.
*      CONTINUE.
*    ENDIF.
********************************************************
    PERFORM bdc_dynpro      USING 'SAPLAIST' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-BUKRS'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'ANLA-ANLN1'
                                  record-anlkl.             "'1200226'.
    if record-anln2 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-ANLN2'
                                  record-anln2. "'0'.
    endif.

    PERFORM bdc_field       USING 'ANLA-BUKRS'
                                  record-bukrs."'1000'.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB02'.
    if record-txt50 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-TXT50'
                                  record-txt50."'DFM-FACTORY BUILDING-PRODUCTION UNIT-B'
    endif.
    "& 'DC'.
    if record-txt501 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-TXA50'
                                 record-txt501." 'DFM-FACTORY BUILDING-PRODUCTION UNIT-B'
    ENDIF.
    " & 'DC'.
    if record-sernr is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-SERNR'
                                  record-sernr.
    endif.           "'12345'.

    if record-menge is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-MENGE'
                                  record-menge."'2'.
    endif.
    if  record-meins is INITIAL.
    ELSE.
    PERFORM bdc_field       USING 'ANLA-MEINS'
                                  record-meins."'AU'.
    endif.

    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-AKTIV'.
    if record-aktiv is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-AKTIV'
                                  record-aktiv."'31.03.2024'.
    endif.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB04'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLZ-STORT'.
    if record-kostl is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLZ-KOSTL'
                                  record-kostl."'1600311001'.
    endif.
    if record-werks is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLZ-WERKS'
                                  record-werks."'1600'.
    endif.
    if record-stort is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLZ-STORT'
                                  record-stort.             "'16001'.
    endif.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB05'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLA-TYPBZ'.
    if record-lifnr is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-LIFNR'
                                  record-lifnr.             "'1000027'.
    endif.

*    PERFORM bdc_field       USING 'GD_LIEFE'
*                                  record-gd_liefe." 'nEHA&/,ENTERPRISE(S)/.-,&()'.
    if  record-typbz is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLA-TYPBZ'
                                   record-typbz."'In'.'MAHESH'.
    endif.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TAB08'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'GLOFAAASSETDATA-GLO_IN_AST_USE'.
    if record-glo_in_blk_key is INITIAL.
    else.
    PERFORM bdc_field       USING 'GLOFAAASSETDATA-GLO_IN_BLK_KEY'
                                  record-glo_in_blk_key."'BL003'.
    endif.
    if record-glo_in_ast_use is INITIAL.
    else.
    PERFORM bdc_field       USING 'GLOFAAASSETDATA-GLO_IN_AST_USE'
                                  record-glo_in_ast_use."''1.4.2023'.
    endif.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=SELZ'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-AFABG(01)'.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '0195'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=RW'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-SCHRW_PROZ'.
    if record-afasl01 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-AFASL'
                                  record-afasl01."'Z010'.
    endif.
    if record-ndjar01 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-NDJAR'
                                  record-ndjar01."' 30'.
    ENDIF.
    if record-ndper01 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-NDPER'
                                  record-ndper01."'  6'.
    endif.
    if record-afabg01 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-AFABG'
                                  record-afabg01."'01.04.2024'.
    endif.

    if record-schrw is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-SCHRW'
                                  record-schrw."''.
    endif.

    if record-schrw_proz is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-SCHRW_PROZ'
                                   record-schrw_proz."''.
    endif.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '1000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=SELZ'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-AFABG(02)'.
    PERFORM bdc_dynpro      USING 'SAPLAIST' '0195'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BUCH'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ANLB-SCHRW_PROZ'.
    if record-afasl02 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-AFASL'
                                  record-afasl02."'Z010'.
    endif.
    if record-ndjar02 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-NDJAR'
                                  record-ndjar02."' 30'.
    endif.

    if record-ndper02 is INITIAL.
     else.
    PERFORM bdc_field       USING 'ANLB-NDPER'
                                  record-ndper02."'  6'.
    endif.

    if record-afabg02 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-AFABG'
                                  record-afabg02."'01.04.2024'.
    endif.
*    PERFORM bdc_field       USING 'ANLB-SCHRW'
*                                  record-schrw."''.
    if record-schrw_proz1 is INITIAL.
    else.
    PERFORM bdc_field       USING 'ANLB-SCHRW_PROZ'
                                  record-schrw_proz1."''.
    endif.

    PERFORM bdc_transaction USING 'AS02'.
  ENDLOOP.
*perform close_group.
*&---------------------------------------------------------------------*
*&      Form  F_GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_get_data .


  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_field_seperator    = 'X'
      i_line_header        = 'X'
      i_tab_raw_data       = t_raw
      i_filename           = p_file
    TABLES
      i_tab_converted_data = record.



ENDFORM.
*----------------------------------------------------------------------*
*        Start new screen                                              *
*----------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.                    "BDC_DYNPRO

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_PATH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_path .
  CALL FUNCTION 'F4_FILENAME'
    IMPORTING
      file_name = p_file.
  .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_TRANSACTION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0365   text
*----------------------------------------------------------------------*
FORM bdc_transaction  USING tcode.
  REFRESH messtab.
  CALL TRANSACTION tcode USING bdcdata
                     OPTIONS FROM w_param
*                   MODE   ctumode
*                   UPDATE cupdate
                   MESSAGES INTO messtab.
  l_subrc = sy-subrc.

  WRITE: / 'CALL_TRANSACTION',
           tcode,
           'returncode:'(I05),
           l_subrc,
           'RECORD:',
           sy-index.
  LOOP AT messtab.
    SELECT SINGLE * FROM t100 WHERE sprsl = messtab-msgspra
                              AND   arbgb = messtab-msgid
                              AND   msgnr = messtab-msgnr.
    IF sy-subrc = 0.
      l_mstring = t100-text.
      IF l_mstring CS '&1'.
        REPLACE '&1' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&2' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&3' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&4' WITH messtab-msgv4 INTO l_mstring.
      ELSE.
        REPLACE '&' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv4 INTO l_mstring.
      ENDIF.
      CONDENSE l_mstring.
      WRITE: / messtab-msgtyp, l_mstring(250).
    ELSE.
      WRITE: / messtab.
    ENDIF.
  ENDLOOP.
  SKIP.

  REFRESH bdcdata.

ENDFORM.
