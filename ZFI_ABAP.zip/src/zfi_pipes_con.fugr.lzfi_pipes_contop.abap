FUNCTION-POOL ZFI_PIPES_CON              MESSAGE-ID SV.

* INCLUDE LZFI_PIPES_COND...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PIPES_CONT00                       . "view rel. data dcl.
