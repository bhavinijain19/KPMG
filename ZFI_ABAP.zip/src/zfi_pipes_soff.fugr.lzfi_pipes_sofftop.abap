FUNCTION-POOL ZFI_PIPES_SOFF             MESSAGE-ID SV.

* INCLUDE LZFI_PIPES_SOFFD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_PIPES_SOFFT00                      . "view rel. data dcl.
