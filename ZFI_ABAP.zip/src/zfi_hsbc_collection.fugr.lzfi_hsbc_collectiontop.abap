FUNCTION-POOL ZFI_HSBC_COLLECTION.          "MESSAGE-ID ..

* INCLUDE LZFI_HSBC_COLLECTIOND...           " Local class definition
