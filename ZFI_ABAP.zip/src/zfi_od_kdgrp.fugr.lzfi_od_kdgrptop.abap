FUNCTION-POOL ZFI_OD_KDGRP               MESSAGE-ID SV.

* INCLUDE LZFI_OD_KDGRPD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_OD_KDGRPT00                        . "view rel. data dcl.
