class ZCL_IM_FIEB_CHANGE_BS_DATA definition
  public
  final
  create public .

public section.

  interfaces IF_EX_FIEB_CHANGE_BS_DATA .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_FIEB_CHANGE_BS_DATA IMPLEMENTATION.


  METHOD if_ex_fieb_change_bs_data~change_data.


* Get source from TVARC table
    SELECT * FROM tvarvc
             INTO TABLE @DATA(lt_source)
             WHERE name = 'ZBANK_REF_CODE'
             AND   low NE ''.

    IF sy-subrc = 0 AND lt_source IS NOT INITIAL.
      READ TABLE lt_source INTO DATA(ls_source) INDEX 1.
    ENDIF.

    IF ls_source-low = 'OLD'.
      SELECT * FROM tvarvc
                   INTO TABLE @DATA(lt_ebs)
                   WHERE name = 'ZFI_EBS_H'
                   AND   low NE ''.
      SELECT * FROM tvarvc
              INTO TABLE @DATA(lt_ebs_s)
              WHERE name = 'ZFI_EBS_S'
              AND   low NE ''.

*      FIELD-SYMBOLS: <lv_vwezw> TYPE char65.

      DATA: lv_str   TYPE string,
            lv_str1  TYPE string,
            lv_flag  TYPE char01,
            lv_zuonr TYPE dzuonr,
            lv_str2  TYPE string,
            lv_str3  TYPE string.

      DATA : gv_tab1 TYPE string,
             gv_tab2 TYPE string.

      CLEAR: lv_str,lv_flag,lv_str1,lv_str2.
      LOOP AT t_febre ASSIGNING FIELD-SYMBOL(<lw_febre>).
        ASSIGN COMPONENT 'VWEZW' OF STRUCTURE <lw_febre> TO FIELD-SYMBOL(<fs>).
        IF <fs>(1) = '&' AND <fs>+1(1) NE 'N'.
          CONCATENATE lv_str2 <fs>  INTO lv_str2 SEPARATED BY space.
        ELSE.
          CONCATENATE lv_str2 <fs>  INTO lv_str2." SEPARATED BY space.
        ENDIF.
      ENDLOOP.

      IF c_febep-epvoz = 'H'.
        REPLACE ALL OCCURRENCES OF '-&' IN lv_str2 WITH ' &'.
        SPLIT lv_str2 AT space INTO TABLE DATA(lt_tab).
        LOOP AT lt_tab INTO DATA(lw_tab).
          IF lw_tab CS '&'.
            REPLACE ALL OCCURRENCES OF '&' IN lw_tab WITH ''.
            CONDENSE lw_tab.
            IF c_febep-kidno IS INITIAL.
              c_febep-kidno = lw_tab.
            ENDIF.
            DATA(strlen2) = strlen( c_febep-kidno ).

            IF  strlen2 = 22.
              EXIT.
            ENDIF.
            CHECK lw_tab CA '0123456789'.
            DATA(str_len1) = strlen( lw_tab ).
            IF str_len1 = 22 AND c_febep-kidno IS NOT INITIAL.
              c_febep-kidno = lw_tab.
            ELSEIF str_len1 = 16 AND c_febep-kidno IS NOT INITIAL.
              c_febep-kidno = lw_tab.
            ELSEIF str_len1 BETWEEN 12 AND 16 AND c_febep-kidno IS NOT INITIAL.. ">= 12 and str_len1 <= 16
              IF strlen2 > 15.
              ELSE.
                c_febep-kidno = lw_tab.
              ENDIF.
            ENDIF.

            CLEAR:str_len1,strlen2.
          ENDIF.
          LOOP AT lt_ebs INTO DATA(lw_ebs).
            IF lw_tab CS lw_ebs-low.
              CONDENSE lw_tab.
              DATA(str_len) = strlen( lw_tab ).
              IF str_len = 22 AND c_febep-kidno IS INITIAL.
*              IF str_len = 25.
*                REPLACE lw_ebs-low in lw_tab WITH ''.
                CONDENSE lw_tab.
                c_febep-kidno = lw_tab.
              ELSEIF c_febep-kidno IS INITIAL AND str_len = 16.
                c_febep-kidno = lw_tab.
*              ELSEIF c_febep-kidno IS INITIAL AND str_len = 12.
*                c_febep-kidno = lw_tab.
              ENDIF.
            ENDIF.
          ENDLOOP.
*          ENDIF.
*          IF lw_tab CS 'HDFCR' OR
*             lw_tab CS 'SCBLR'.
*            CONDENSE lw_tab.
*            DATA(str_len) = strlen( lw_tab ).
*            IF str_len = 22.
*              c_febep-kidno = lw_tab.
*            ELSEIF c_febep-kidno IS INITIAL AND str_len = 16.
*              c_febep-kidno = lw_tab.
*            ENDIF.
*          ENDIF.
        ENDLOOP.
        CLEAR :lw_tab,lt_tab,str_len,str_len1.
      ENDIF.
      IF c_febep-epvoz = 'S' AND lv_flag = '' AND <lw_febre> IS ASSIGNED.
        DATA(lv_len) = strlen( lv_str2 ). "<lw_febre> ).
        lv_len = lv_len - 19.
        IF lv_len = 65.
          CONCATENATE lv_str <lw_febre>+19(lv_len) INTO lv_str.
        ELSEIF lv_len < 65.
          CONCATENATE lv_str <lw_febre>+19(lv_len) INTO lv_str.
          lv_flag = 'X'.
        ENDIF.
      ENDIF.
*    ENDLOOP.

      IF c_febep-epvoz = 'S' AND lv_str2 IS NOT INITIAL.
        SPLIT lv_str2 AT space INTO TABLE DATA(lt_tab1).
        LOOP AT lt_tab1 INTO DATA(lw_tab1).
          LOOP AT lt_ebs_s INTO DATA(lw_ebs_s).
            IF lw_tab1 CS lw_ebs_s-low.
              REPLACE lw_ebs_s-low IN lw_tab1 WITH ''.
              REPLACE ALL OCCURRENCES OF '&' IN lw_tab1 WITH ''.
              CONDENSE lw_tab1.
              IF lw_tab1 IS INITIAL.
                lw_tab1 = 'HSBC0000'.
              ENDIF.
              IF c_febep-zuonr IS INITIAL.
                c_febep-zuonr = lw_tab1.
              ENDIF.
              strlen2 = strlen( c_febep-zuonr ).

              IF  strlen2 = 22.
                EXIT.
              ENDIF.
              str_len1 = strlen( lw_tab1 ).
              IF str_len1 = 22 AND c_febep-zuonr IS NOT INITIAL.
                c_febep-zuonr = lw_tab1.
              ELSEIF str_len1 = 16 AND c_febep-zuonr IS NOT INITIAL.
                c_febep-zuonr = lw_tab1.
              ELSEIF str_len1 = 18 AND c_febep-zuonr IS NOT INITIAL.
                c_febep-zuonr = lw_tab1.
              ENDIF.

              IF strlen2 = 18.
                IF c_febep-zuonr+16(2) = '-0' OR c_febep-zuonr+16(2) = '/0'.
                  c_febep-zuonr+12(6) = ''.
                ENDIF.
                IF c_febep-zuonr+16(1) = '-' OR c_febep-zuonr+16(1) = '/'.
                  c_febep-zuonr+12(6) = ''.
                ENDIF.
              ENDIF.
              CLEAR:str_len1,strlen2.

            ENDIF.

          ENDLOOP.
        ENDLOOP.

        CLEAR:lw_tab1,lt_tab1.
        "Only in case if 'S' ind records for 61 line without Bank Reference
        "From User exit Ref.
        IF c_febep-zuonr IS INITIAL.
          FIND '&' IN lv_str2.
          IF sy-subrc EQ 0.
            SPLIT lv_str2 AT space INTO TABLE lt_tab1.
            LOOP AT lt_tab1 INTO lw_tab1.
              FIND '&' IN lw_tab1.
              IF sy-subrc = 0.
                REPLACE ALL OCCURRENCES OF '&' IN lw_tab1 WITH ''.
                c_febep-zuonr = lw_tab1.
              ENDIF.
            ENDLOOP.
          ENDIF.
        ENDIF.
      ENDIF.

    ELSE.

      DATA : t_raw_data TYPE raw_data.

      CLEAR: lv_str,lv_flag,lv_str1,lv_str2.

      LOOP AT t_febre ASSIGNING <lw_febre>.
        ASSIGN COMPONENT 'VWEZW' OF STRUCTURE <lw_febre> TO <fs>.
        IF <fs> IS ASSIGNED.
          CONCATENATE lv_str2 <fs>  INTO lv_str2.
        ENDIF.
      ENDLOOP.

      DATA: lv_len1 TYPE i.
      DATA: lv_length TYPE i.

      IF lv_str2 IS NOT INITIAL.
        SPLIT lv_str2 AT '&&' INTO DATA(lv_string1) DATA(lv_string2).
        IF lv_string2 IS NOT INITIAL AND strlen( lv_string2 ) GT 2.
          lv_len1 = lv_string2+0(2).
          "Changes added by Ranjan 03.12.2025
          DATA lv_dummy TYPE string. " Used to catch the rest of the string
          DATA ls_string TYPE string.
          SPLIT lv_string2 AT ' ' INTO ls_string lv_dummy.

           lv_length = STRLEN( ls_string ).   "New logic added to calculate lev_len1
           lv_len1 = lv_length - 2.           "Changes added by Ranjan 19.12.2025

          ""End of chnages by Ranjan 03.12.2025
          IF lv_len1 IS NOT INITIAL.
            IF c_febep-epvoz = 'H'.
              c_febep-kidno = lv_string2+2(lv_len1).
            ELSEIF c_febep-epvoz = 'S'.
*              IF lv_len1 = 22.
*                c_febep-zuonr = lv_string2+6(18).
*              ELSEIF lv_len1 = 16.
*                c_febep-zuonr = lv_string2+6(12).
*              ELSE.
*                c_febep-zuonr = lv_string2+2(lv_len1).
*              ENDIF.

              " ----------------------------------------------------------------------"
              "Start of change by Ranjan 03.12.2025
              IF lv_len1 > 18.
                " If the length is > 18, we only want the last 18 characters.
                Data:lv_extract_len type i.
                DATA lv_base_offset TYPE i VALUE 2.
                lv_extract_len = 18.
                DATA lv_offset TYPE i.
                lv_offset = lv_len1 - lv_extract_len + lv_base_offset. " Calculate the starting position for the last 18
                c_febep-zuonr = ls_string+lv_offset(lv_extract_len).
              ELSE. ""If length is <18 we take all the character
                c_febep-zuonr = ls_string+2(lv_len1).
              ENDIF.
              ""End of change by Ranjan 03.12.2025
              " ----------------------------------------------------------------------"

            ENDIF.
          ENDIF.
        ENDIF.

        IF c_febep-chect CA '/'.
          REPLACE '/' WITH space INTO c_febep-chect.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
