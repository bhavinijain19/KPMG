*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_CASH_DAYSTOP.                 " Global Declarations
  INCLUDE LZFI_CASH_DAYSUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_CASH_DAYSF...                 " Subroutines
* INCLUDE LZFI_CASH_DAYSO...                 " PBO-Modules
* INCLUDE LZFI_CASH_DAYSI...                 " PAI-Modules
* INCLUDE LZFI_CASH_DAYSE...                 " Events
* INCLUDE LZFI_CASH_DAYSP...                 " Local class implement.
* INCLUDE LZFI_CASH_DAYST99.                 " ABAP Unit tests
  INCLUDE LZFI_CASH_DAYSF00                       . " subprograms
  INCLUDE LZFI_CASH_DAYSI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
