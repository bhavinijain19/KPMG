*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_BANKKKTOP.                    " Global Declarations
  INCLUDE LZFI_BANKKKUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_BANKKKF...                    " Subroutines
* INCLUDE LZFI_BANKKKO...                    " PBO-Modules
* INCLUDE LZFI_BANKKKI...                    " PAI-Modules
* INCLUDE LZFI_BANKKKE...                    " Events
* INCLUDE LZFI_BANKKKP...                    " Local class implement.
* INCLUDE LZFI_BANKKKT99.                    " ABAP Unit tests
  INCLUDE LZFI_BANKKKF00                          . " subprograms
  INCLUDE LZFI_BANKKKI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
