*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_ABAPTOP.                      " Global Data
  INCLUDE LZFI_ABAPUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_ABAPF...                      " Subroutines
* INCLUDE LZFI_ABAPO...                      " PBO-Modules
* INCLUDE LZFI_ABAPI...                      " PAI-Modules
* INCLUDE LZFI_ABAPE...                      " Events
* INCLUDE LZFI_ABAPP...                      " Local class implement.
* INCLUDE LZFI_ABAPT99.                      " ABAP Unit tests
