*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_GSTIN_EXL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_GSTIN_EXL       .

  PERFORM TABLEPROC.

ENDFUNCTION.
