*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_GL_CHECK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_GL_CHECK        .

  PERFORM TABLEPROC.

ENDFUNCTION.
