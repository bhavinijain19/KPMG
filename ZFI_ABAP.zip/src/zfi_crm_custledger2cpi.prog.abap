*&---------------------------------------------------------------------*
*& Report ZFI_CRM_CUSTLEDGER2CPI
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zfi_crm_custledger2cpi.

TABLES: t001,kna1,bkpf.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_bukrs FOR t001-bukrs DEFAULT '1000' OBLIGATORY,
                  s_kunnr FOR kna1-kunnr,
                  s_budat FOR bkpf-budat.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
  PARAMETERS: p_open AS CHECKBOX DEFAULT 'X'. " Fetch Opening Balance
****              p_cpi  AS CHECKBOX DEFAULT 'X'. " Trigger CPI Sync
SELECTION-SCREEN END OF BLOCK b2.

****TYPES: BEGIN OF ty_ledger_payload,
****         primaryid(100)      TYPE c,
****         docid(30)           TYPE c,
****         distributorsynchid  TYPE kunnr,
****         postingdate         TYPE bkpf-budat,
****         narration           TYPE bseg-sgtxt,
****         amount              TYPE dmbtr,
****         cramount            TYPE dmbtr,
****         dramount            TYPE dmbtr,
****         companycode         TYPE bukrs,
****         refnumber           TYPE xblnr,
****         assnum              TYPE bseg-zuonr,     " zuonr
****         duedate             TYPE datum,
****         spglind             TYPE bsid-umskz,     " umskz
****         transactiontype(40) TYPE c,
****         plant(4)            TYPE c,
****         closing             TYPE dmbtr,
****       END OF ty_ledger_payload.

****DATA: lt_cpi_payload TYPE TABLE OF ty_ledger_payload,

TYPES: BEGIN OF ty_final,
         bukrs     TYPE bukrs,
         kunnr     TYPE kunnr,
         name1     TYPE kna1-name1,
         belnr     TYPE belnr_d,
         budat     TYPE budat,
         xblnr     TYPE xblnr,
         bldat     TYPE bldat,
         blart     TYPE blart,
         ltext     TYPE t003t-ltext,
         umskz     TYPE umskz,
         zuonr     TYPE bsid-zuonr,
         debit     TYPE dmbtr,
         credit    TYPE dmbtr,
         closing   TYPE dmbtr,
         prctr     TYPE prctr,
         werks     TYPE werks_d,
         plant     TYPE name1,
         augbl     TYPE augbl,
         augdt     TYPE augdt,
         sgtxt     TYPE sgtxt,
         saknr     TYPE saknr,
         hkont     TYPE hkont,
         txt50     TYPE txt50,
         gjahr     TYPE gjahr,
         bschl     TYPE bschl,
         shkzg     TYPE shkzg,
         mwskz     TYPE mwskz,
         dmbtr     TYPE dmbtr,
         wrbtr     TYPE wrbtr,
         primaryid TYPE string,
         docid     TYPE string,
         dist_sync TYPE string,
         color(4)  TYPE c,
       END OF ty_final.

DATA: it_final      TYPE TABLE OF ty_final,
      wa_final      TYPE ty_final,
      it_open       TYPE TABLE OF bapi3007_3,
      wa_open       TYPE bapi3007_3,
      it_fcat       TYPE slis_t_fieldcat_alv,
      wa_fcat       TYPE slis_fieldcat_alv,
      wa_layout     TYPE slis_layout_alv,
      lv_start_date TYPE datum,
      lv_key_date   TYPE datum,
      v_customer    TYPE string,
      v_name        TYPE string,
      it_kna1_header TYPE TABLE OF kna1,
      wa_kna1_header TYPE kna1.

" --- 2. Macro for Field Catalog (Sequence 1-29) ---
DEFINE fillcat.
  wa_fcat-col_pos    = &1.
  wa_fcat-tabname    = &2.
  wa_fcat-fieldname  = &3.
  wa_fcat-seltext_m  = &4.
  wa_fcat-no_out     = &5.
  wa_fcat-do_sum     = &6.
  wa_fcat-no_zero    = &7.
  wa_fcat-hotspot    = &8.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.
END-OF-DEFINITION.


INCLUDE zfi_crm_custledger2cpi_f01.

START-OF-SELECTION.

  PERFORM get_data.
  PERFORM send2cpi.
  PERFORM build_fcat.
  PERFORM display.
