FUNCTION zfi_bp_validations.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"----------------------------------------------------------------------
*"*"Local Interface:
*----------------------------------------------------------------------
*----------------------------------------------------------------------
**"Local Interface:
*----------------------------------------------------------------------

  DATA: ls_lfa1_new TYPE lfa1,            " Vendor General Data (BP buffer)
        ls_lfb1_new TYPE lfb1.     " Vendor Company Code Data (BP buffer)

  DATA: lt_but0bk TYPE TABLE OF but0bk.

*  --------------------------------------------------------------------
*    " ---> Read BP buffer data (S/4HANA CVI FMs)
*    "--------------------------------------------------------------------
  CALL FUNCTION 'CVIV_BUPA_LFA1_GET'
    IMPORTING
      e_lfa1 = ls_lfa1_new.

  IF ls_lfa1_new-lifnr IS NOT INITIAL.

**      CALL FUNCTION 'CVIV_BUPA_LFB1_GET'
**        IMPORTING
**          e_lfb1 = ls_lfb1_new.

    SELECT lifnr, bukrs FROM lfb1 INTO TABLE @DATA(lt_lfb1) WHERE lifnr = @ls_lfa1_new-lifnr.
    IF lt_lfb1 IS NOT INITIAL.

      CALL FUNCTION 'BUP_BUPA_BUT0BK_GET'
        TABLES
          t_but0bk = lt_but0bk.

*  --------------------------------------------------------------------
*   ---> bank Control Key validation by company Code (but0bk vs lfb1)
*       - If bukrs 1000 -> bkont must be 10
*       - If bukrs 4000 -> bkont must be 40
*  --------------------------------------------------------------------

      IF lt_but0bk IS NOT INITIAL.
        LOOP AT lt_lfb1 INTO DATA(ls_lfb1).

          IF ls_lfb1-bukrs = '1000'.
            IF NOT line_exists( lt_but0bk[ bkont = '10' ] ).
              CALL FUNCTION 'BUS_MESSAGE_STORE'
                EXPORTING
                  arbgb = 'ZFI_MSGS'
                  msgty = 'E'
                  txtnr = '007'. " Control Key 10 missing for BUKRS 1000
              EXIT.
            ENDIF.

          ELSEIF ls_lfb1-bukrs = '4000'.
            IF NOT line_exists( lt_but0bk[ bkont = '40' ] ).
              CALL FUNCTION 'BUS_MESSAGE_STORE'
                EXPORTING
                  arbgb = 'ZFI_MSGS'
                  msgty = 'E'
                  txtnr = '008'. " Control Key 40 missing for BUKRS 4000
              EXIT.
            ENDIF.
          ENDIF.

        ENDLOOP.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFUNCTION.
