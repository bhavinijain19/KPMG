*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_GST_SPLIT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_GST_SPLIT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
