"Name: \FU:MRM_XACCITCR_EXPORT\SE:END\EI
ENHANCEMENT 0 ZFI_MIRO.

*    CONSTANTS: c_tcode TYPE rvari_vnam VALUE 'Z_FI_TCODES'.
*    CONSTANTS: c_gl TYPE rvari_vnam VALUE 'Z_FI_COST_ELEMENT_GL'.
*
*    TYPES: BEGIN OF ty_tvarvc,
*             sign TYPE tvarv_sign,
*             opti TYPE tvarv_opti,
*             low  TYPE tvarv_val,
*             high TYPE tvarv_val,
*           END OF ty_tvarvc.
*
*    DATA : t_tcode  TYPE STANDARD TABLE OF ty_tvarvc,
*           w_tcode  TYPE ty_tvarvc,
*           t_gl     TYPE STANDARD TABLE OF ty_tvarvc,
*           w_gl     TYPE ty_tvarvc,
*           t_item   TYPE TABLE OF accit WITH HEADER LINE,
*           lv_werks TYPE werks_d,
*           lv_prctr TYPE prctr,
*           lv_kostl TYPE kostl.
*
*    SELECT sign
*           opti
*           low
*           high INTO TABLE t_tcode
*                FROM tvarvc
*                WHERE name = c_tcode.
*
*    IF sy-tcode IN t_tcode.
*
*      SELECT sign opti low high INTO TABLE t_gl
*        FROM tvarvc WHERE name = c_gl.
*
*      t_item[] = t_accit[].
*      DELETE t_item WHERE werks IS INITIAL.
*
*      TRY .
*          lv_werks = t_item[ 1 ]-werks.
*        CATCH cx_sy_itab_line_not_found.
*      ENDTRY.
*
*      TRY .
*          lv_prctr = t_item[ 1 ]-prctr.
*        CATCH cx_sy_itab_line_not_found.
*      ENDTRY.
*
*      LOOP AT t_accit WHERE hkont IN t_gl.
*        IF t_accit-kostl IS INITIAL.
*          SELECT SINGLE kostl FROM tka3c INTO t_accit-kostl WHERE bukrs = t_accit-bukrs AND kstar = t_accit-hkont AND bwkey = lv_werks.
*        ENDIF.
*
*        t_accit-prctr = lv_prctr.
*        MODIFY t_accit.
*
*      ENDLOOP.
*
*    ENDIF.

ENDENHANCEMENT.
