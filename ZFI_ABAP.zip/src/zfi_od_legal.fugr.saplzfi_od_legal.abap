*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_OD_LEGALTOP.                  " Global Data
  INCLUDE LZFI_OD_LEGALUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_OD_LEGALF...                  " Subroutines
* INCLUDE LZFI_OD_LEGALO...                  " PBO-Modules
* INCLUDE LZFI_OD_LEGALI...                  " PAI-Modules
* INCLUDE LZFI_OD_LEGALE...                  " Events
* INCLUDE LZFI_OD_LEGALP...                  " Local class implement.
* INCLUDE LZFI_OD_LEGALT99.                  " ABAP Unit tests
  INCLUDE LZFI_OD_LEGALF00                        . " subprograms
  INCLUDE LZFI_OD_LEGALI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
