FUNCTION z_fieb_901_algorithm.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_NOTE_TO_PAYEE) TYPE  STRING OPTIONAL
*"     REFERENCE(I_COUNTRY) TYPE  LAND1 OPTIONAL
*"  TABLES
*"      T_AVIP_IN STRUCTURE  AVIP OPTIONAL
*"      T_AVIP_OUT STRUCTURE  AVIP
*"      T_FILTER1 OPTIONAL
*"      T_FILTER2 OPTIONAL
*"----------------------------------------------------------------------

**  field-symbols: <avip> type avip.
**  read table t_avip_in assigning <avip> index 1.
**  if sy-subrc <> 0.
**    append initial line to t_avip_in.
**    read table t_avip_in assigning <avip> index 1.
**  endif.
**  <avip>-sgtxt = '021'.
**  CALL FUNCTION 'FIEB_026_ALGORITHM'
**       EXPORTING
**            I_NOTE_TO_PAYEE = i_note_to_payee
**            I_COUNTRY       = i_country
**       TABLES
**            T_AVIP_IN       = t_avip_in
**            T_AVIP_OUT      = t_avip_out
**            T_FILTER1       = t_filter1
**            T_FILTER2       = t_filter2.
*  DATA: BEGIN OF kidno_tab OCCURS 10,
*          nummer LIKE febep-kidno,
*        END OF kidno_tab,
*        s_bsis TYPE STANDARD TABLE OF bsis,
*        h_bsis TYPE bsis.
**        lv_sub TYPE string,
**        lv_sub1 TYPE string.
*
*  LOOP AT t_avip_in WHERE sfeld = 'KIDNO'.
*    kidno_tab-nummer = t_avip_in-swert.
*    APPEND kidno_tab.
*  ENDLOOP.
*  REFRESH t_avip_out.
*
*"""added by vd 08.05.2024~start
* LOOP AT t_avip_in WHERE bukrs IS NOT INITIAL.
*    DATA(lv_bukrs) = t_avip_in-bukrs.
*    IF lv_bukrs IS NOT INITIAL.
*      EXIT.
*    ENDIF.
*  ENDLOOP.
*"""added by vd 08.05.2024~end
**
**  SPLIT i_note_to_payee at  ',' INTO lv_sub lv_sub1.
**
**  lv_sub  = lv_sub+15(10).
*  LOOP AT kidno_tab.
****Selecting the table based on XREF1
**begin of change
**    SELECT * FROM bseg INTO TABLE s_bseg WHERE xref1 = kidno_tab-nummer
****Selecting the table based on Check
*    SELECT * FROM bsis INTO TABLE s_bsis WHERE kidno = kidno_tab-nummer AND BSCHL = '40' AND hkont like '%%%%%%%%%1'
**End of change
*    AND xopvw = 'X'.
**    AND xref1 = lv_sub .
*    IF sy-subrc = 0.
*      LOOP AT s_bsis INTO h_bsis.
*        t_avip_out-koart = 'S'.
*        t_avip_out-konto = h_bsis-hkont.
*        t_avip_out-sfeld = 'BELNR'.
*        t_avip_out-swert = h_bsis-belnr.
*        t_avip_out-swert+10(4) = h_bsis-gjahr.
*        APPEND t_avip_out.
*      ENDLOOP.
*    ELSE.
**      CONTINUE.
*    SELECT bukrs, hkont, kidno
*      FROM bsis
*      INTO TABLE @DATA(lt_bsis)
*      WHERE bukrs = @lv_bukrs
*        AND bschl = '40'
*        AND hkont LIKE '%%%%%%%%%1'
*        AND xopvw = 'X'.
*    IF sy-subrc = 0.
*      LOOP AT lt_bsis INTO DATA(wa_bsis).
*        TRANSLATE wa_bsis-kidno TO UPPER CASE.
*        IF wa_bsis-kidno = kidno_tab-nummer.
*          t_avip_out-koart = 'S'.
*          t_avip_out-konto = wa_bsis-hkont.
*          t_avip_out-sfeld = 'KIDNO'.
*          t_avip_out-swert = wa_bsis-kidno.
**        t_avip_out-swert+10(4) = h_bsis-gjahr.
*          APPEND t_avip_out.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
**Message "pAyment rEference  not found"
*    ENDIF.
*  ENDLOOP.
*
*  IF t_avip_out IS INITIAL.
*    t_avip_out-swert = kidno_tab-nummer.
**    t_avip_out-swert+10(4) = '0000'.
*    t_avip_out-sfeld  = 'KIDNO'.
*    t_avip_out-koart = 'S'.
*    APPEND t_avip_out.
*  ENDIF.


  """"added by vd

*  field-symbols: <avip> type avip.
*  read table t_avip_in assigning <avip> index 1.
*  if sy-subrc <> 0.
*    append initial line to t_avip_in.
*    read table t_avip_in assigning <avip> index 1.
*  endif.
*  <avip>-sgtxt = '021'.
*  CALL FUNCTION 'FIEB_026_ALGORITHM'
*       EXPORTING
*            I_NOTE_TO_PAYEE = i_note_to_payee
*            I_COUNTRY       = i_country
*       TABLES
*            T_AVIP_IN       = t_avip_in
*            T_AVIP_OUT      = t_avip_out
*            T_FILTER1       = t_filter1
*            T_FILTER2       = t_filter2.
  DATA: BEGIN OF kidno_tab OCCURS 10,
          nummer LIKE febep-kidno,
        END OF kidno_tab,
        s_bsis TYPE STANDARD TABLE OF bsis,
        h_bsis TYPE bsis.
*        lv_sub TYPE string,
*        lv_sub1 TYPE string.

  LOOP AT t_avip_in WHERE sfeld = 'KIDNO'.
    kidno_tab-nummer = t_avip_in-swert.
    APPEND kidno_tab.
  ENDLOOP.
  REFRESH t_avip_out.

  """added by vd 08.05.2024~start
  LOOP AT t_avip_in WHERE bukrs IS NOT INITIAL.
    DATA(lv_bukrs) = t_avip_in-bukrs.
    IF lv_bukrs IS NOT INITIAL.
      EXIT.
    ENDIF.
  ENDLOOP.
  """added by vd 08.05.2024~end
*
*  SPLIT i_note_to_payee at  ',' INTO lv_sub lv_sub1.
*
*  lv_sub  = lv_sub+15(10).
  LOOP AT kidno_tab.
***Selecting the table based on XREF1
*begin of change
*    SELECT * FROM bseg INTO TABLE s_bseg WHERE xref1 = kidno_tab-nummer
***Selecting the table based on Check
    SELECT * FROM bsis INTO TABLE s_bsis WHERE kidno = kidno_tab-nummer AND bschl = '40' AND hkont LIKE '%%%%%%%%%1'
*End of change
    AND xopvw = 'X'.
*    AND xref1 = lv_sub .
    IF sy-subrc = 0.
      LOOP AT s_bsis INTO h_bsis.
        t_avip_out-koart = 'S'.
        t_avip_out-konto = h_bsis-hkont.
        t_avip_out-sfeld = 'BELNR'.
        t_avip_out-swert = h_bsis-belnr.
        t_avip_out-swert+10(4) = h_bsis-gjahr.
        APPEND t_avip_out.
      ENDLOOP.
    ELSE.
*      CONTINUE.
      TRANSLATE kidno_tab-nummer TO LOWER CASE.
      SELECT * FROM bsis INTO TABLE s_bsis
        WHERE kidno = kidno_tab-nummer AND bschl = '40' AND hkont LIKE '%%%%%%%%%1'
        AND xopvw = 'X'.
      IF sy-subrc = 0.
        LOOP AT s_bsis INTO h_bsis.
          t_avip_out-koart = 'S'.
          t_avip_out-konto = h_bsis-hkont.
          t_avip_out-sfeld = 'BELNR'.
          t_avip_out-swert = h_bsis-belnr.
          t_avip_out-swert+10(4) = h_bsis-gjahr.
          APPEND t_avip_out.
        ENDLOOP.
      ELSE.
*        SELECT bukrs, hkont, kidno
*          FROM bsis
*          INTO TABLE @DATA(lt_bsis)
*          WHERE bukrs = @lv_bukrs
*            AND bschl = '40'
*            AND hkont LIKE '%%%%%%%%%1'
*            AND xopvw = 'X'.
*        IF sy-subrc = 0.
*          LOOP AT lt_bsis INTO DATA(wa_bsis).
*            TRANSLATE wa_bsis-kidno TO UPPER CASE.
*            IF wa_bsis-kidno = kidno_tab-nummer.
*              t_avip_out-koart = 'S'.
*              t_avip_out-konto = wa_bsis-hkont.
*              t_avip_out-sfeld = 'KIDNO'.
*              t_avip_out-swert = wa_bsis-kidno.
**        t_avip_out-swert+10(4) = h_bsis-gjahr.
*              APPEND t_avip_out.
*            ENDIF.
*          ENDLOOP.
*        ENDIF.
*Message "pAyment rEference  not found"
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF t_avip_out IS INITIAL.
    t_avip_out-swert = kidno_tab-nummer.
*    t_avip_out-swert+10(4) = '0000'.
    t_avip_out-sfeld  = 'KIDNO'.
    t_avip_out-koart = 'S'.
    APPEND t_avip_out.
  ENDIF.
  """"added by vd
ENDFUNCTION.
