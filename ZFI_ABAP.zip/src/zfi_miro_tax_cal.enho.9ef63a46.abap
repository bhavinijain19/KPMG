"Name: \PR:SAPLV61A\FO:FRM_KOND_BASIS_362\SE:END\EI
ENHANCEMENT 0 ZFI_MIRO_TAX_CAL.
IF sy-tcode = 'MIRO' OR sy-tcode = 'MIR7' OR sy-tcode = 'MIR4'.
  IF cl_cos_utilities=>is_s4h_on_premise( ) = abap_true.  "Quantity based Cess for Cloud
    IF xt007a-mwart = 'V'.
      IF NOT zwrbtr IS INITIAL.
        zwrbtr = zwrbtr + i_kzwi6.
        zwrbtr = zwrbtr - i_kzwi4.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
