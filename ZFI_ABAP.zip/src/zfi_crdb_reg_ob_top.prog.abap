*&---------------------------------------------------------------------*
*& Include          ZFI_CRDB_REG_OB_TOP
*&---------------------------------------------------------------------*

TABLES : bkpf,j_1iexchdr,kna1,lfa1,knvv.
TYPE-POOLS : slis.


TYPES : BEGIN OF t_bkpf,
          belnr TYPE bkpf-belnr,
          budat TYPE bkpf-budat,
          bukrs TYPE bkpf-bukrs,
          gjahr TYPE bkpf-gjahr,
          blart TYPE bkpf-blart,
          bldat TYPE bkpf-bldat,
          xblnr TYPE bkpf-xblnr,
          tcode TYPE bkpf-tcode,
          ppnam TYPE bkpf-ppnam,
        END OF t_bkpf.
DATA : wa_bkpf TYPE t_bkpf.
DATA : it_bkpf TYPE STANDARD TABLE OF t_bkpf.

TYPES : BEGIN OF t_bseg,
          belnr TYPE bseg-belnr,
          buzei TYPE bseg-buzei,
          shkzg TYPE bseg-shkzg,
          dmbtr TYPE bseg-dmbtr,
          pswsl TYPE bseg-pswsl,
          sgtxt TYPE bseg-sgtxt,
          hkont TYPE bseg-hkont,
          kunnr TYPE bseg-kunnr,
          lifnr TYPE bseg-lifnr,
          prctr TYPE bseg-prctr,
          kostl TYPE bseg-kostl,
          mwskz TYPE bseg-mwskz,
          qsskz TYPE bseg-qsskz,
          werks TYPE bseg-werks,
        END OF t_bseg.
DATA : wa_bseg  TYPE t_bseg.
DATA : it_bseg  TYPE STANDARD TABLE OF t_bseg.
DATA : wa_bsid TYPE bsid,
       it_bsid TYPE TABLE OF bsid.


TYPES : BEGIN OF t_cuslif,
          belnr TYPE bseg-belnr,
          buzei TYPE bseg-buzei,
        END OF t_cuslif.

DATA : wa_cuslif TYPE t_cuslif.
DATA : it_cuslif TYPE STANDARD TABLE OF t_cuslif.

TYPES : BEGIN OF t_skat,
          saknr TYPE skat-saknr,
          txt50 TYPE skat-txt50,
        END OF t_skat.
DATA : wa_skat TYPE t_skat.
DATA : it_skat TYPE STANDARD TABLE OF t_skat.

TYPES: BEGIN OF ty_kna1_knvv,
         kunnr TYPE kna1-kunnr,
         name1 TYPE kna1-name1,
         vkorg TYPE knvv-vkorg,
       END OF ty_kna1_knvv.

DATA : it_kna1 TYPE TABLE OF ty_kna1_knvv,
       wa_kna1 TYPE ty_kna1_knvv.

TYPES : BEGIN OF t_final,
          belnr         TYPE bseg-belnr,
          budat         TYPE bkpf-budat,
          hkont         TYPE bseg-hkont,
          name(80),
          debit         TYPE bseg-dmbtr,
          credit        TYPE bseg-dmbtr,
          pswsl         TYPE bseg-pswsl,
          sgtxt(200),
          bukrs         TYPE bkpf-bukrs,
          vkorg         TYPE knvv-vkorg,
          gjahr         TYPE bkpf-gjahr,
          blart         TYPE bkpf-blart,
          prctr         TYPE bseg-prctr,
          kostl         TYPE bseg-kostl,
          bldat         TYPE bkpf-bldat,
          xblnr         TYPE bkpf-xblnr,
          tcode         TYPE bkpf-tcode,
          ppnam         TYPE bkpf-ppnam,
          mwskz         TYPE bseg-mwskz,
          qsskz         TYPE bseg-qsskz,
          kunnr         TYPE  bseg-kunnr,
          name1         TYPE  kna1-name1,
          lifnr         TYPE bseg-lifnr,
          buzei         TYPE bseg-buzei,
          color(4),
          werks         TYPE bseg-werks,
          fkart         TYPE fkart,
          time(18),
          primaryid(30),
        END OF t_final.
DATA: wa_final TYPE t_final.
DATA: wa_final1 TYPE t_final.
DATA: it_final TYPE STANDARD TABLE OF t_final.
DATA: it_final1 TYPE STANDARD TABLE OF t_final.

DATA: flag       TYPE i VALUE 1,
      wa_flag(1),
      wa_fcat    TYPE slis_fieldcat_alv,
      it_fcat    TYPE slis_t_fieldcat_alv,
      wa_layout  TYPE slis_layout_alv,
      lv_tstmp   TYPE timestampl,
      lv_date    TYPE sy-datum,
      lv_time    TYPE sy-uzeit.
