*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_CH_DAY_PAINTTOP.              " Global Declarations
  INCLUDE LZFI_CH_DAY_PAINTUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_CH_DAY_PAINTF...              " Subroutines
* INCLUDE LZFI_CH_DAY_PAINTO...              " PBO-Modules
* INCLUDE LZFI_CH_DAY_PAINTI...              " PAI-Modules
* INCLUDE LZFI_CH_DAY_PAINTE...              " Events
* INCLUDE LZFI_CH_DAY_PAINTP...              " Local class implement.
* INCLUDE LZFI_CH_DAY_PAINTT99.              " ABAP Unit tests
  INCLUDE LZFI_CH_DAY_PAINTF00                    . " subprograms
  INCLUDE LZFI_CH_DAY_PAINTI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
