*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_SALE_SMS_GP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_SALE_SMS_GP     .

  PERFORM TABLEPROC.

ENDFUNCTION.
