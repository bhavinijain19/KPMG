*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_TE_BUPLATOP.                  " Global Data
  INCLUDE LZFI_TE_BUPLAUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_TE_BUPLAF...                  " Subroutines
* INCLUDE LZFI_TE_BUPLAO...                  " PBO-Modules
* INCLUDE LZFI_TE_BUPLAI...                  " PAI-Modules
* INCLUDE LZFI_TE_BUPLAE...                  " Events
* INCLUDE LZFI_TE_BUPLAP...                  " Local class implement.
* INCLUDE LZFI_TE_BUPLAT99.                  " ABAP Unit tests
  INCLUDE LZFI_TE_BUPLAF00                        . " subprograms
  INCLUDE LZFI_TE_BUPLAI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
