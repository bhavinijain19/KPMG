FUNCTION-POOL ZFI_BANKKK                 MESSAGE-ID SV.

* INCLUDE LZFI_BANKKKD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_BANKKKT00                          . "view rel. data dcl.
