@AbapCatalog.sqlViewName: 'ZFI_RCM_INVOICE'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'CDS for RCM invoice form'
@Metadata.ignorePropagatedAnnotations: true
define view ZFI_CDS_RCM_INVOICE
  with parameters
    p_belnr : belnr_d, // Document Number
    p_gjahr : gjahr, // Fiscal Year
    p_bukrs : bukrs
  as select distinct from bkpf

    left outer join       acdoca         on  bkpf.belnr   = acdoca.belnr
                                         and bkpf.gjahr   = acdoca.gjahr
                                         and acdoca.koart = 'K'
  //and acdoca.ktosl = 'EGK'
      left outer join       acdoca as tax  on  bkpf.belnr   = tax.belnr
                                         and bkpf.gjahr   = tax.gjahr
                                         and tax.ktosl = 'JIC'

    left outer join       acdoca as tax1 on  bkpf.belnr   = tax1.belnr
                                         and bkpf.gjahr   = tax1.gjahr
                                         and tax1.ktosl = 'JIS'

    left outer join       acdoca as tax2 on  bkpf.belnr   = tax2.belnr
                                         and bkpf.gjahr   = tax2.gjahr
                                         and tax2.ktosl = 'JII'
    left outer join       lfa1           on acdoca.lifnr = lfa1.lifnr
    left outer join       bseg           on  bkpf.belnr = bseg.belnr
                                         and bkpf.gjahr = bseg.gjahr
                                         and bseg.buzid = 'W'
    left outer join       t001w          on  bseg.werks = t001w.werks
                                         
    left outer join       adrc           on t001w.adrnr = adrc.addrnumber
    left outer join       j_1bbranch     on bseg.bupla = j_1bbranch.branch


{
  key bkpf.belnr,
      bkpf.xblnr_alt,
      bkpf.budat,
      bkpf.xblnr,
      bkpf.bldat,
      bkpf.gjahr,
      bkpf.bukrs,
      acdoca.lifnr,
      lfa1.name1,
      lfa1.name2,
      lfa1.name3,
      lfa1.name4,
      t001w.adrnr,
      t001w.name1 as plant_name,
      adrc.floor,
      adrc.building,
      adrc.street,
      adrc.str_suppl1,
      adrc.str_suppl2,
      adrc.str_suppl3,
      t001w.regio,
      j_1bbranch.gstin,
      tax.tsl     as JIC,
      tax1.tsl    as JIS,
      tax2.tsl    as JII

}
where
      bkpf.belnr = $parameters.p_belnr
  and bkpf.gjahr = $parameters.p_gjahr
  and bkpf.bukrs = $parameters.p_bukrs;
