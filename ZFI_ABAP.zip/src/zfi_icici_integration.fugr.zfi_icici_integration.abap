FUNCTION zfi_icici_integration.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IT_ZICECOLLECT) TYPE  ZTT_ICECOLLECT OPTIONAL
*"  EXPORTING
*"     VALUE(STATUS) TYPE  STRING
*"     VALUE(REJECT_REASON) TYPE  STRING
*"     VALUE(STATUS_CODE) TYPE  STRING
*"----------------------------------------------------------------------

  DATA: lt_records            TYPE TABLE OF zicecollect,
        lt_not_posted_records TYPE TABLE OF zicecollect,
        lv_posted_count       TYPE i,
        lv_not_posted_count   TYPE i.
  DATA: lv_segment TYPE string.
  DATA: it_bkpf        LIKE bkpf   OCCURS 0,
        it_bkpf_change LIKE bkpf   OCCURS 0,
        it_bseg        LIKE bseg   OCCURS 0,
        it_bseg_change LIKE bseg   OCCURS 0,
        x_bkpf         TYPE bkpf,
        x_bseg         TYPE bseg,
        it_bkdf        LIKE bkdf   OCCURS 0,
        it_bsec        LIKE bsec   OCCURS 0,
        it_bsed        LIKE bsed   OCCURS 0,
        it_bset        LIKE bset   OCCURS 0.

  DATA:it_zicicimap TYPE TABLE OF zicicimap,
       wa_zicicimap TYPE zicicimap.
  DATA gd_documentheader TYPE bapiache09.
  DATA l_type            TYPE bapiache09-obj_type.
  DATA l_key             TYPE bapiache09-obj_key.
  DATA l_sys             TYPE bapiache09-obj_sys.
  DATA it_accountgl     TYPE STANDARD TABLE OF bapiacgl09 WITH HEADER LINE.

*DATA it_accountpayable LIKE TABLE OF bapiacar09 WITH HEADER LINE.
  DATA it_accountpayable TYPE STANDARD TABLE OF bapiacar09 WITH HEADER LINE.
  DATA it_currencyamount TYPE STANDARD TABLE OF bapiaccr09 WITH HEADER LINE.
  DATA it_return        TYPE STANDARD TABLE OF bapiret2 WITH HEADER LINE.
*DATA it_return1        LIKE TABLE OF bapiret2   WITH HEADER LINE.

  DATA : year        TYPE bkpf-gjahr,
         period      TYPE t009b-poper,
         gv_year(4)  TYPE c,
         zglacc      TYPE string,
         lv_bukrs(4) TYPE c.
  DATA: v_len3 TYPE i.
  DATA: v TYPE i.
  DATA:beneacc_1 TYPE string.
  DATA:buyercode_1 TYPE string .
  DATA:buyer_kna1 TYPE  KUNNR,
       utr_txt     TYPE string.
  DATA:it_kna1           TYPE TABLE OF kna1,
       wa_kna1           TYPE kna1,
       it_knvv           TYPE TABLE OF knvv,
       wa_knvv           TYPE knvv,
       es_return_message TYPE bapiret2.

  DATA:docno TYPE zicecollect-docno.
  CONSTANTS:c_ba(4)     VALUE 'BA',
            c_coc(3)    VALUE 'COC',
            c_cca(3)    VALUE 'CCA',
            c_glacc(10) VALUE 'GLACC',
            c_pc(10)    VALUE 'PC',
            c_bus(10)   VALUE 'BUS',
            c_sgl(3)    VALUE 'SGL',
            c_tc(2)     VALUE 'TC'.
********************************************************************

  DATA:it_bapiparex TYPE STANDARD TABLE OF bapiacextc WITH HEADER LINE,
       wa_bapiparex TYPE bapiacextc.
  DATA: str_len TYPE i,
        dz      TYPE char2.
  DATA: wa_mwskz(02),
        mwskz(02).
  DATA:ba_1     TYPE string,
        CCA_1 TYPE STRING,
       coc_1(4) TYPE c,
       glacc_1  TYPE string,
       pc_1     TYPE prctr,
       bus_1    TYPE string,
       sgl_1    TYPE string,
       tc_1     TYPE string.
  DATA:lv_message TYPE c LENGTH 500,
       rmark      TYPE c LENGTH 300.

  TYPES:BEGIN OF ty_allrec,
          clientname     TYPE string,
          clientaccno    TYPE string,
          utr            TYPE string,
          payprocode     TYPE string,
          buyercode      TYPE string,
          currency       TYPE string,
          amount         TYPE string,
          cdate          TYPE string,
          remittname     TYPE string,
          remittbank     TYPE string,
          remittifsccode TYPE string,
          remittaccno    TYPE string,
          clientcode     TYPE string,
          status         TYPE string,
          poststatus     TYPE string,
          van            TYPE string,
          dtstamp        TYPE string,
          filename       TYPE string,
          docno          TYPE string,
          remark         TYPE string,
          client         TYPE string,
          bankvalue      TYPE string,
          docdate        TYPE string,
          postdate       TYPE string,
          valuedate      TYPE string,
          createddate    TYPE string,
          itemtext       TYPE string,
          entrytime      TYPE string,
          fperiod        TYPE string,
          doctype        TYPE string,
          glacc          TYPE string,
        END OF ty_allrec.

  DATA:it_allrec TYPE TABLE OF ty_allrec,
       wa_allrec TYPE ty_allrec.
  DATA:date_str  TYPE string,
       cdate(20) TYPE c,
       sdate(20) TYPE c,
       lv_date   TYPE d,
       lv_year   TYPE char4,
       lv_month  TYPE char2,
       lv_day    TYPE char2,
       date1(20) TYPE c.

  LOOP AT it_zicecollect INTO DATA(wa_zicecollect).
        SELECT * FROM zicecollect
          INTO  TABLE @data(lt_dup)
          WHERE CLIENTACCNO = @wa_zicecollect-clientaccno
          and UTR = @wa_zicecollect-utr .
          if lt_dup is INITIAL.

    SELECT * FROM zicicimap
    INTO CORRESPONDING FIELDS OF TABLE @it_zicicimap
    WHERE keyref = @wa_zicecollect-clientaccno .
    "WHERE sapvalue  = wa_zicecollect-clientaccno.
"soc 23/2 credit control area
         READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                       sapvalue = c_CCA .


    CCA_1 = wa_zicicimap-bankvalue.
"eoc 23/2 credit control area
    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                       sapvalue = c_ba .


    ba_1 = wa_zicicimap-bankvalue.

    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                       sapvalue = c_coc .



    coc_1 = wa_zicicimap-bankvalue.



    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                       sapvalue = c_glacc .

    glacc_1 = wa_zicicimap-bankvalue.

    CLEAR:v_len3.

    v_len3 = strlen( glacc_1 ).


    v = 0.
    WHILE v < ( 10 - v_len3 ) .
      CONCATENATE '0' glacc_1 INTO  glacc_1.
      v = v + 1 .
    ENDWHILE.

    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                      sapvalue = c_bus .



    bus_1 = wa_zicicimap-bankvalue.

    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                      sapvalue = c_pc .



    pc_1 = wa_zicicimap-bankvalue.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = pc_1
      IMPORTING
        output = pc_1.

    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                     sapvalue = c_sgl .



    sgl_1 = wa_zicicimap-bankvalue.

    READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                    sapvalue = c_tc .



    tc_1 = wa_zicicimap-bankvalue.

*  SELECT bankvalue FROM zicicimap INTO ( zglacc )
*  WHERE sapvalue = wa_zicecollect-custcode.
*  ENDSELECT.

    "pt comm 20/02/2026

*    CLEAR:v_len3.
*    buyercode_1 = wa_zicecollect-buyercode.
*    v_len3 = strlen( buyercode_1 ).
*    buyercode_1 = wa_zicecollect-buyercode.

*    v = 0.
*    WHILE v < ( 10 - v_len3 ) .
*      CONCATENATE '0' buyercode_1 INTO  buyercode_1.
*      v = v + 1 .
*    ENDWHILE.

    buyercode_1 = wa_zicecollect-van .
    v_len3 = strlen( buyercode_1 ).
    DATA(v_length) = v_len3 - 6.
    buyercode_1 = buyercode_1+6(v_length).
    buyer_kna1 = |{ buyercode_1 ALPHA = IN }|.
    wa_zicecollect-buyercode = buyer_kna1.

    SELECT * FROM kna1 INTO TABLE it_kna1
                WHERE kunnr = buyer_kna1.

    IF sy-subrc = 0.

      lv_bukrs = coc_1.

      CALL FUNCTION 'FI_PERIOD_DETERMINE'
        EXPORTING
          i_budat = sy-datum
          i_bukrs = lv_bukrs "'C_COC' "'7000'
        IMPORTING
          e_gjahr = year
          e_poper = period.

      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      SELECT SINGLE mwskz FROM t007s
         INTO ( wa_mwskz )
          WHERE spras = 'EN'
          AND kalsm = 'TAXINN'
          AND mwskz = mwskz.

      cdate = wa_zicecollect-cdate.

      REPLACE ALL OCCURRENCES OF '-' IN cdate WITH ' '.

      lv_date = cdate.
      lv_year = lv_date+0(4).
      lv_month = lv_date+4(2).
      lv_day = lv_date+6(2).

*    lv_year = lv_date+4(4).
*    lv_month = lv_date+2(2).
*    lv_day = lv_date(2).

      CONCATENATE lv_year lv_month lv_day INTO sdate.
      cdate = sdate.



      gd_documentheader-username   =  sy-uname.
      gd_documentheader-header_txt = 'Customer collection-ICICI'.
      gd_documentheader-comp_code  = coc_1."'7000'.
      gd_documentheader-fisc_year  =  year.
      gd_documentheader-doc_date   =  cdate."sy-datum . "cdate
      gd_documentheader-pstng_date =  sy-datum .
      gd_documentheader-fis_period =  period.
      gd_documentheader-doc_type   = 'DZ'.

      CLEAR : utr_txt.
      CONCATENATE wa_zicecollect-payprocode wa_zicecollect-utr(5) INTO utr_txt.

      it_accountpayable-itemno_acc     = '0000000002'.
      it_accountpayable-customer       =  buyer_kna1."buyercode_1 .
      it_accountpayable-comp_code      =  coc_1."'7000'.
      it_accountpayable-businessplace  =  ba_1."'KAGP'.
      it_accountpayable-sectioncode    = ba_1."'KAGP'.
      it_accountpayable-profit_ctr     =  pc_1."'7303A00101'.
      it_accountpayable-item_text     =   utr_txt.
      it_accountpayable-paymt_ref      =   wa_zicecollect-utr.
      it_accountpayable-tax_code       =  tc_1."'8I' .
      it_accountpayable-sp_gl_ind      =  sgl_1."'A' .
      it_accountpayable-bline_date     =  sy-datum.
      it_accountpayable-dsct_days1     =  '0'.
      it_accountpayable-c_ctr_area     =  CCA_1.


      APPEND it_accountpayable.


      CLEAR : it_accountgl, utr_txt.

      CONCATENATE wa_zicecollect-payprocode wa_zicecollect-utr(5) INTO utr_txt.

      it_accountgl-itemno_acc     = '0000000001'.
      it_accountgl-gl_account     = glacc_1."'0036012001'.
      it_accountgl-item_text      = utr_txt.
      it_accountgl-customer       = buyer_kna1." buyercode_1.
      it_accountgl-de_cre_ind     = 'H'.
      it_accountgl-comp_code      = coc_1."'7000'.
      it_accountgl-doc_type       = 'DZ'.
      it_accountgl-fis_period     = period .
      it_accountgl-fisc_year      = year.
      it_accountgl-pstng_date     = sy-datum .
      it_accountgl-value_date     = sy-datum .
      it_accountgl-comp_code      = coc_1."'7000'.
      it_accountgl-businessplace  = ba_1."'KAGP'.
      it_accountgl-sectioncode    = ba_1."'KAGP'.
      it_accountgl-profit_ctr     = pc_1."'7303A00101'.
      it_accountgl-bus_area     = bus_1."'7303A00101'.
      it_accountgl-paymt_ref      = wa_zicecollect-utr.

      APPEND it_accountgl.


      it_bapiparex-field1 =  '002405031232'."v_item.
      it_bapiparex-field2 = '1006578'."wa_main-hkont.
      it_bapiparex-field3 = '19'." wa_main-newko.
      APPEND it_bapiparex.

      CLEAR it_currencyamount.
      it_currencyamount-itemno_acc   = '0000000002'.
      it_currencyamount-curr_type    = '00'.
      it_currencyamount-currency     = 'INR'.
      it_currencyamount-amt_doccur   = wa_zicecollect-amount * - 1.

      APPEND it_currencyamount.

      it_currencyamount-itemno_acc   = '0000000001'.
      it_currencyamount-curr_type    = '00'.
      it_currencyamount-currency     = 'INR'.
      it_currencyamount-amt_doccur   = wa_zicecollect-amount .


      APPEND it_currencyamount.
****************************************************************************************************
*     Populate the Extension table           *
      wa_bapiparex-field1 = 'BSCHL'.
      wa_bapiparex-field2 = '02'.      " Item number
      wa_bapiparex-field3 = '19'.      " Posting Key
      APPEND wa_bapiparex TO it_bapiparex.
************************************************************************************************
"pt 8/4/2026 comm DEVK906743
*      CALL FUNCTION 'BAPI_ACC_DOCUMENT_CHECK'
*        EXPORTING
*          documentheader    = gd_documentheader
*        TABLES
*          accountgl         = it_accountgl
*          accountreceivable = it_accountpayable
*          currencyamount    = it_currencyamount
*          return            = it_return.
*
*      CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
*        EXPORTING
*          documentheader    = gd_documentheader
*        IMPORTING
*          obj_type          = l_type
*          obj_key           = l_key
*          obj_sys           = l_sys
*        TABLES
*          accountgl         = it_accountgl
*          accountreceivable = it_accountpayable
*          currencyamount    = it_currencyamount
*          return            = it_return
*          extension1        = it_bapiparex.

"pt 8/4/2026 comm DEVK906743
*      IF l_key IS INITIAL OR l_key EQ '$'.
*        wa_zicecollect-status     = 'E'.
*        wa_zicecollect-poststatus = 'E'.
*
*
*        READ TABLE it_return INTO DATA(wa_return).
*        lv_message = wa_return-message.
*        wa_zicecollect-remark = lv_message.
*
*        MODIFY zicecollect FROM wa_zicecollect.
*        status = 'Error'.
*        reject_reason = 'Any technical error'.
*        status_code = 'NA'.
*
*      ELSE.
*        IF l_key IS NOT INITIAL.
*          wa_zicecollect-status     = 'C'.
*          wa_zicecollect-poststatus = 'C'.
*
*          CONCATENATE l_key(10) '_' coc_1 INTO  rmark.
*          wa_zicecollect-remark =  rmark.
*
*          MODIFY zicecollect FROM wa_zicecollect.
*          status = 'Success'.
*          reject_reason = 'ok'.
*          status_code = '200'.
*        ENDIF.
*      ENDIF.

          wa_zicecollect-status     = 'C'.
          wa_zicecollect-poststatus = 'C'.

          CONCATENATE l_key(10) '_' coc_1 INTO  rmark.
          wa_zicecollect-remark =  rmark.

          MODIFY zicecollect FROM wa_zicecollect.
          status = 'Success'.
          reject_reason = 'ok'.
          status_code = '200'.
*        ENDIF.




*      IF sy-subrc IS INITIAL.
*        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*          EXPORTING
*            wait = 'X'.
*
*        IF sy-subrc IS INITIAL.
*          wa_zicecollect-docno      = l_key(10).
*
*
*          MODIFY zicecollect FROM wa_zicecollect.
*
*        ENDIF.
*
*      ENDIF.
"pt 8/4/2026 comm DEVK906743



      date1 = sy-datum.

      CONCATENATE  date1+6(2)  date1+4(2)  date1+0(4)
          INTO date1 SEPARATED BY '-'.


      MOVE-CORRESPONDING  wa_zicecollect TO wa_allrec.
      wa_allrec-clientname      =  wa_zicecollect-clientname.
      wa_allrec-clientaccno     =  wa_zicecollect-clientaccno.
      wa_allrec-utr             =  wa_zicecollect-utr.
      wa_allrec-payprocode      =  wa_zicecollect-payprocode.
*      DATA(lv_new_data) = wa_zicecollect-van+6(7). "ananya
          wa_allrec-buyercode       =  wa_ZICECOLLECT-buyercode.
*      wa_allrec-buyercode       =  lv_new_data.
      wa_allrec-currency        =  wa_zicecollect-currency.
      wa_allrec-amount          =  wa_zicecollect-amount.
      wa_allrec-cdate           =  wa_zicecollect-cdate.
      wa_allrec-remittname      =  wa_zicecollect-remittname.
      wa_allrec-remittbank      =  wa_zicecollect-remittbank.
      wa_allrec-remittifsccode  =  wa_zicecollect-remittifsccode.
      wa_allrec-remittaccno     =  wa_zicecollect-remittaccno.
      wa_allrec-clientcode      =  wa_zicecollect-clientcode.
      wa_allrec-van             =  wa_zicecollect-van.
      wa_allrec-dtstamp         =  wa_zicecollect-dtstamp.
      wa_allrec-status          =  wa_zicecollect-status.
      wa_allrec-poststatus      =  wa_zicecollect-poststatus.
      wa_allrec-filename        =  wa_zicecollect-filename .
      wa_allrec-docno           =  wa_zicecollect-docno.
      wa_allrec-remark          =  wa_zicecollect-remark.
      wa_allrec-docdate         = wa_zicecollect-cdate. "SY-DATUM.
      wa_allrec-postdate        = wa_zicecollect-cdate.
      wa_allrec-valuedate       = wa_zicecollect-cdate.
      wa_allrec-createddate     = date1.
      wa_allrec-client          = syst-mandt.
      wa_allrec-bankvalue       = coc_1.
      wa_allrec-itemtext        = utr_txt.
      wa_allrec-entrytime        = sy-uzeit.
      wa_allrec-fperiod          = period.
      wa_allrec-doctype         = 'DZ'.
      wa_allrec-glacc           =  glacc_1.





      APPEND wa_allrec TO it_allrec.

      MODIFY zicecollect FROM wa_zicecollect.

    ELSE .
      status = 'Error'.
      reject_reason = 'Any technical error'.
      status_code = 'NA'.
    ENDIF.

    CLEAR   : it_currencyamount, it_accountgl,it_accountpayable.
    REFRESH : it_currencyamount, it_accountgl,it_accountpayable.
    else.
         status = 'Error'.
      reject_reason = 'Data Already Exists'.
      status_code = 'NA'.
 ENDIF.
  ENDLOOP.




DATA: ls_body        TYPE soli,
      lt_body        TYPE soli_tab,

      lx_send_req    TYPE REF TO cl_bcs,
      lx_document    TYPE REF TO cl_document_bcs,
      lx_recipient   TYPE REF TO if_recipient_bcs,
      lx_bcs_exc     TYPE REF TO cx_send_req_bcs,
      lx_address_exc TYPE REF TO cx_address_bcs,
      lx_doc_exc     TYPE REF TO cx_document_bcs,
      html_string    TYPE string,
      bname          TYPE usr01-bname,
      name           TYPE name_text,
      lv_dat         TYPE c LENGTH 10,
*      lv_string       TYPE char40,
      lv_string1     TYPE char200,
      lwa_objcont    TYPE solisti1,
      li_objcont     TYPE STANDARD TABLE OF solisti1.
*
*data : total_docs_REJC   TYPE c LENGTH 10,
*      total_amount  TYPE c LENGTH 10,
*      lv_send_filename_REJ TYPE string,
*      amount_reject type c length 40.
*
*DATA : BODY_TEXT TYPE SO_TEXT255.
*
* DATA  TEXT  TYPE BCSY_TEXT.

DATA: lt_mailrecipients TYPE STANDARD TABLE OF somlrec90 WITH HEADER LINE,
      lt_mailtxt        TYPE STANDARD TABLE OF soli,
      l_mailtxt         TYPE  soli,
      lt_attachment     TYPE STANDARD TABLE OF solisti1  WITH HEADER LINE,
      lt_mailsubject    TYPE sodocchgi1,
      lt_packing_list   TYPE STANDARD TABLE OF sopcklsti1 WITH HEADER LINE,
      gv_cnt            TYPE i.
*        it_ziciciALV_APPR  type table of ziciciALV_APPR,
*        wa_ziciciALV_APPR  type ziciciALV_APPR,
*       it_ziciciALV_APPR  type table of ziciciMUL_APPR ,
*        wa_ziciciALV_APPR  type ziciciMUL_APPR.
**
DATA:"it_zicecollect TYPE TABLE OF zicecollect,
  " wa_zicecollect TYPE zicecollect,
  lv_approver_mailid_rej TYPE string,
  amut                   TYPE c LENGTH 13,
  sts                    TYPE c,
  doc                    TYPE c LENGTH 10,
*     RMARK TYPE C LENGTH 300 ,
*     FNAME TYPE C LENGTH 30 ,
  l_size                 TYPE i,
  rec                    TYPE string,
  lv_header              TYPE string,
  lv_data                TYPE string,
  lv_xstring             TYPE string.


DATA: gs_maildata LIKE sodocchgi1.
DATA: gt_mailpack LIKE sopcklsti1 OCCURS 0 WITH HEADER LINE.
DATA: gt_mailhead LIKE solisti1 OCCURS 0 WITH HEADER LINE.
DATA: gt_mailbin LIKE solisti1 OCCURS 0 WITH HEADER LINE.
DATA: gt_mailtxt LIKE solisti1 OCCURS 0 WITH HEADER LINE.
DATA: gt_mailrec LIKE somlrec90 OCCURS 0 WITH HEADER LINE.
DATA: gt_solisti1 LIKE solisti1 OCCURS 0 WITH HEADER LINE.
DATA: v_lines TYPE i.
DATA : body_text TYPE so_text255.
DATA: lv_sender  TYPE so_rec_ext VALUE 'sap.astral@astralltd.com'.

* DATA  TEXT  TYPE BCSY_TEXT.
DATA  text  TYPE string.

CLEAR gs_maildata.
gs_maildata-obj_name    = 'DP_ERROR_LOG_FILE.CSV'.
gs_maildata-obj_descr   = 'DP_ERROR_LOG_FILE.CSV'.



CONCATENATE body_text 'Dear Team,' INTO body_text SEPARATED BY space.
APPEND body_text TO gt_mailtxt.
CLEAR : body_text.

*CONCATENATE  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
*           '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' into body_text SEPARATED BY space.
*
*APPEND body_text TO GT_MAILTXT.
*CLEAR : BODY_TEXT.


CONCATENATE body_text 'Please find the attached collection transactions status in SAP.' INTO body_text.
APPEND body_text TO gt_mailtxt.
CLEAR : body_text.

*CONCATENATE  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
*           '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' into body_text SEPARATED BY space.
*
*APPEND body_text TO GT_MAILTXT.
*CLEAR : BODY_TEXT.

CONCATENATE body_text 'Thanks & Regards,'  INTO body_text SEPARATED BY space.


APPEND body_text TO gt_mailtxt.
CLEAR : body_text.

CONCATENATE body_text 'SAP(auto generated email).' INTO body_text SEPARATED BY space.
APPEND body_text TO gt_mailtxt.

CLEAR v_lines.
DESCRIBE TABLE gt_mailtxt LINES v_lines.
READ TABLE gt_mailtxt INDEX v_lines.
gs_maildata-doc_size = ( v_lines - 1 ) * 255 + strlen( gt_mailtxt ).

CLEAR gt_mailpack-transf_bin.
gt_mailpack-head_start = 1.
gt_mailpack-head_num = 0.
gt_mailpack-body_start = 1.
gt_mailpack-body_num = v_lines.
gt_mailpack-doc_type = 'RAW'.
APPEND gt_mailpack.

gt_mailhead = 'DP_ERROR_LOG_FILE.CSV'.
APPEND gt_mailhead.

CONCATENATE   'Client'
              'Comapny Code'
              'Assigment number'
              'File name'
              'Document Date'
              'Document type'
              'Posting Date'
              'Fiscal Period'
              'Currency KeY'
              'GLAccount'
              'Amount'
              'Value Date'
              'Item Text'
              'Customer Number'
              'Document number'
              'Created Date'
              'Entry time'
              'Error Message'
              'STATUS'


         INTO lv_header SEPARATED BY ','.

CONCATENATE lv_header cl_abap_char_utilities=>cr_lf INTO lv_data.
APPEND lv_data TO gt_mailbin.




* APPEND GT_MAILBIN.

LOOP AT it_allrec INTO wa_allrec.

  CONCATENATE wa_allrec-client
              wa_allrec-bankvalue
              wa_allrec-utr
              wa_allrec-filename
              wa_allrec-docdate
              wa_allrec-doctype
              wa_allrec-postdate
              wa_allrec-fperiod
              wa_allrec-currency
              wa_allrec-glacc
              wa_allrec-amount
              wa_allrec-valuedate
              wa_allrec-itemtext
              wa_allrec-buyercode
              wa_allrec-docno
              wa_allrec-createddate
              wa_allrec-entrytime
              wa_allrec-remark
              wa_allrec-status


*
*               INTO REC SEPARATED BY ','.
*  APPEND REC TO GT_MAILBIN.
  INTO lv_data SEPARATED BY ','.

  CONCATENATE lv_data cl_abap_char_utilities=>cr_lf INTO lv_data.

  APPEND lv_data TO gt_mailbin.
  CLEAR lv_data.



* APPEND GT_MAILBIN.
ENDLOOP.




CLEAR v_lines.
DESCRIBE TABLE gt_mailbin LINES v_lines.


gt_mailpack-transf_bin = 'X'.
gt_mailpack-head_start = 1.
gt_mailpack-head_num = 1.
gt_mailpack-body_start = 1.
gt_mailpack-body_num = v_lines.
gt_mailpack-doc_type = 'CSV'.
gt_mailpack-obj_name = 'DP_ERROR_LOG_FILE.CSV'.
gt_mailpack-obj_descr = 'DP_ERROR_LOG_FILE.CSV'.
gt_mailpack-doc_size = v_lines * 255.
APPEND gt_mailpack.

READ TABLE it_zicicimap INTO wa_zicicimap WITH KEY keyref  = wa_zicecollect-clientaccno
                                                   sapvalue = c_glacc .

lv_approver_mailid_rej = wa_zicicimap-remarks.

*          l_sender     = 'sap.astral@astralltd.com'.

lt_mailrecipients-rec_type  = 'U'.
lt_mailrecipients-com_type  = 'INT'.
lt_mailrecipients-receiver  = lv_approver_mailid_rej.

APPEND lt_mailrecipients .
*  CLEAR lt_mailrecipients .

* CALL FUNCTION 'SO_NEW_DOCUMENT_ATT_SEND_API1'
* EXPORTING
* DOCUMENT_DATA = GS_MAILDATA
* PUT_IN_OUTBOX = ' '
* sender_address             = lv_sender
* sender_address_type        = 'INT'
* COMMIT_WORK = 'X'
* TABLES
* PACKING_LIST = GT_MAILPACK
* OBJECT_HEADER = GT_MAILHEAD
* CONTENTS_BIN = GT_MAILBIN
* CONTENTS_TXT = GT_MAILTXT
* RECEIVERS = lt_mailrecipients
* EXCEPTIONS
* TOO_MANY_RECEIVERS = 1
* DOCUMENT_NOT_SENT = 2
* OPERATION_NO_AUTHORIZATION = 4
* OTHERS = 99.

CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
  EXPORTING
    document_data              = gs_maildata
    put_in_outbox              = 'X'
    sender_address             = lv_sender
    sender_address_type        = 'INT'
    commit_work                = 'X'
* IMPORTING
*   SENT_TO_ALL                =
*   NEW_OBJECT_ID              =
*   SENDER_ID                  =
  TABLES
    packing_list               = gt_mailpack
    object_header              = gt_mailhead
    contents_bin               = gt_mailbin
    contents_txt               = gt_mailtxt
    receivers                  = lt_mailrecipients
  EXCEPTIONS
    too_many_receivers         = 1
    document_not_sent          = 2
    document_type_not_exist    = 3
    operation_no_authorization = 4
    parameter_error            = 5
    x_error                    = 6
    enqueue_error              = 7
    OTHERS                     = 8.
IF sy-subrc <> 0.
* Implement suitable error handling here
ENDIF.


ENDFUNCTION.
