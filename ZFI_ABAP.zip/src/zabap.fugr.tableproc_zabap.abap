*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZABAP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZABAP               .

  PERFORM TABLEPROC.

ENDFUNCTION.
