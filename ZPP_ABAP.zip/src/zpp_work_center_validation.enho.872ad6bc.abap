"Name: \PR:SAPLCR0D\EX:SCMPPDS_WORKCENTER_UPDATE\EI
ENHANCEMENT 0 ZPP_WORK_CENTER_VALIDATION.

IF crhd IS NOT INITIAL.
  IF crhd-verwe = '0001' OR crhd-verwe = '0008'.
    IF crhd-werks IS NOT INITIAL AND crhd-arbpl
      IS NOT INITIAL AND crhd-verwe IS NOT INITIAL.

      SELECT * FROM zpp_work_center
        WHERE werks = @crhd-werks
         AND arbpl = @crhd-arbpl
        AND verwe = @crhd-verwe
         INTO TABLE @DATA(lt_val).

      IF lt_val IS INITIAL.
        MESSAGE 'Entry does not exist in ZPP_WORK_CENTER table' TYPE 'A' DISPLAY LIKE 'I'.
      ELSE.
        READ TABLE lt_val ASSIGNING FIELD-SYMBOL(<fs_val>) WITH KEY werks = crhd-werks arbpl = crhd-arbpl verwe = crhd-verwe.
        IF sy-subrc = 0.
          IF <fs_val>-anln1 IS INITIAL.
            MESSAGE 'Asset Code is not maintained.' TYPE 'A' DISPLAY LIKE 'I'.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.

ENDENHANCEMENT.
