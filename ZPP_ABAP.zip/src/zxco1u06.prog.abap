*&---------------------------------------------------------------------*
*& Include          ZXCO1U06
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*       MODULE :      pp                                                 *
*----------------------------------------------------------------------*
*       Objective : Batch charge                            *
*       Program   : Updates Tables (   )     Downloads data (  )       *
*                   Outputs List   (   )                               *
*                                                                      *
*                                                                      *
*       Date Created :     31/12/2025                                            *
*       Instructed by:    Dipesh                                              *
*       Devloped by:     Pruthva Trivedi                                              *
*                                                                      *
*----------------------------------------------------------------------*
*       External Dependencies                                          *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
* Amendment History                                                    *
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR           CR/ID                   *
*......................................................................*
* <001>   create UDAYABAP01 pruthva DEVK900191 3-893,  3-928                                                             *
* Reason:  co01 batch populate in components                                                          *
*......................................................................*
* <002>                                                                *
* Reason:                                                              *
*----------------------------------------------------------------------*

DATA : wa_keko TYPE keko.
DATA : lv_perio TYPE string,
       lv_poper TYPE poper,
       lv_gjahr TYPE gjahr.
*CHECK sy-tcode EQ 'CO01' OR sy-tcode = 'CO40'.

CALL FUNCTION 'DETERMINE_PERIOD'
  EXPORTING
    date                = sy-datum
*   PERIOD_IN           = '000'
    version             = 'V3'
  IMPORTING
    period              = lv_perio
    year                = lv_gjahr
  EXCEPTIONS
    period_in_not_valid = 1
    period_not_assigned = 2
    version_undefined   = 3
    OTHERS              = 4.
IF sy-subrc <> 0.
* Implement suitable error handling here
ENDIF.

IF header_imp-matnr NE 'TRIAL'.
  SELECT SINGLE * FROM keko INTO wa_keko
    WHERE matnr = header_imp-matnr
      AND werks = header_imp-werks
      AND feh_sta = 'FR'.

  IF sy-subrc NE 0.
    MESSAGE e001(zpp) WITH header_imp-matnr header_imp-werks.
  ENDIF.
ENDIF.
CONSTANTS:lc_var TYPE c LENGTH 22 VALUE '(SAPLCOKO1)AFPOD-CHARG'.
CONSTANTS:lc_var1 TYPE c LENGTH 22 VALUE '(SAPLCOKO)AFPOD-CHARG'.

FIELD-SYMBOLS:<fs_batch> TYPE charg_d.

IF ( sy-tcode EQ 'CO01' OR sy-tcode EQ 'COR1'
   OR sy-tcode EQ 'CO40'  OR sy-tcode EQ 'COR7_PC' )
*  AND ( sy-ucomm EQ 'YES' or sy-ucomm EQ 'BU' ).
  AND ( sy-ucomm EQ 'BU' ).
  "soc  UDAYABAP01 uat Additions pt 05022026 .
  "comm  UDAYABAP01 uat Additions pt 27022026 .
*IF AUFK-ZORDER_FLOW IS INITIAL.
*    MESSAGE e003(zpp).
*  ENDIF.
  "comm  UDAYABAP01 uat Additions pt 27022026 .
  "eoc  UDAYABAP01 uat Additions pt 05022026 .
  "soc UDAYABAP01 uat Additions pt 26022026
  SELECT SINGLE xchpf FROM marc
    WHERE matnr = @header_imp-matnr
    AND werks = @header_imp-werks
    INTO @DATA(lv_xchpf) .
  "eoc UDAYABAP01 uat Additions pt 26022026
  IF lv_xchpf IS NOT INITIAL.
    SELECT SINGLE * FROM zwm_config

        INTO @DATA(ls_config)

        WHERE werks = @header_imp-werks

          AND auart = @header_imp-auart.

    IF sy-subrc IS INITIAL.

      ASSIGN (lc_var) TO <fs_batch>.
      IF <fs_batch> IS INITIAL.
        ASSIGN (lc_var1) TO <fs_batch>.
        IF <fs_batch> IS INITIAL.
          MESSAGE e002(zpp).
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.

"Added by BP for COR2
DATA:lv_totqty TYPE gamng.

SELECT SINGLE * FROM afko INTO @DATA(is_header_old) WHERE aufnr = @header_imp-aufnr.

IF header_imp-gamng NE is_header_old-gamng AND sy-tcode EQ 'COR2'.
  SELECT SINGLE * FROM tvarvc INTO @DATA(ls_tvarvc) WHERE name EQ 'ZCO11N_MATERIALNO' AND low EQ @header_imp-matnr.
  IF sy-subrc IS NOT INITIAL.
    SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @header_imp-matnr.
    SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
    IF sy-subrc IS INITIAL.
      SELECT SINGLE * FROM zwm_config
        INTO @DATA(ls_config_new)
        WHERE werks = @header_imp-werks
          AND auart = @header_imp-auart.
      IF sy-subrc IS INITIAL.
        SELECT SUM( su_qty )
          FROM zwm_su
          INTO ( lv_totqty )
          WHERE aufnr EQ header_imp-aufnr AND
                del_flg EQ abap_false.
        IF sy-subrc IS INITIAL.
          SELECT SINGLE objnr FROM aufk
           INTO @DATA(lv_objnr)
            WHERE aufnr EQ @header_imp-aufnr.

          SELECT SINGLE * FROM jest
           INTO @DATA(lv_jest)
            WHERE objnr EQ @lv_objnr
              AND stat = 'I0002'.
          IF lv_jest IS NOT INITIAL.
            IF lv_totqty IS INITIAL.
              MESSAGE 'Please mark the order for deletion' TYPE 'E'.
            ELSE.
              IF header_imp-gamng NE lv_totqty.
                MESSAGE 'No changes are allowed as SU is already generated for this order' TYPE 'E'.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
