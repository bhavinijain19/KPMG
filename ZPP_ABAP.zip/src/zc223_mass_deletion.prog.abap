REPORT zc223_mass_deletion.

TABLES: mkal.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS: p_file TYPE localfile OBLIGATORY.
  SELECTION-SCREEN SKIP.
  PARAMETERS: p_test  TYPE abap_bool DEFAULT abap_true AS CHECKBOX.

SELECTION-SCREEN END OF BLOCK b1.


TYPES: BEGIN OF ty_mkal_key,
         matnr TYPE mkal-matnr,
         werks TYPE mkal-werks,
         verid TYPE mkal-verid,
         MKSP  TYPE MKAL-MKSP,
       END OF ty_mkal_key.

Data: gt_excel type table of ty_mkal_key.

TYPES: BEGIN OF ty_result,
         light   TYPE char1,
         matnr   TYPE mkal-matnr,
         werks   TYPE mkal-werks,
         verid TYPE mkal-verid,
         old_sp  TYPE mkal-mksp,
         new_sp  TYPE mkal-mksp,
         status  TYPE char20,
       END OF ty_result.

DATA: gt_update  TYPE STANDARD TABLE OF mkal,
      gt_results TYPE STANDARD TABLE OF ty_result,
      gs_result  TYPE ty_result.


AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'F4_FILENAME'
    IMPORTING
      file_name = p_file.


START-OF-SELECTION.

DATA: lt_raw TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_tab_raw_data       = lt_raw
      i_filename           = p_file
    TABLES
      i_tab_converted_data = gt_excel
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0 OR gt_excel IS INITIAL.
    MESSAGE 'Error reading file or file is empty.' TYPE 'E'.
  ELSE.

    Delete gt_excel  index 1.

    ENDIF.


LOOP AT gt_excel INTO DATA(ls_input).



  SELECT SINGLE * FROM mkal INTO @DATA(ls_mkal)
      WHERE matnr = @ls_input-matnr
        AND werks = @ls_input-werks
        AND verid = @ls_input-verid.


    IF sy-subrc <> 0.
      CLEAR gs_result.
      MOVE-CORRESPONDING ls_input TO gs_result.
      gs_result-matnr = ls_input-matnr.
      gs_result-werks = ls_input-werks.
      gs_result-verid = ls_input-verid.
      gs_result-status  = 'NOT_FOUND'.
      gs_result-light   = '1'.
      APPEND gs_result TO gt_results.
      CONTINUE.
    ENDIF.





*    DATA(lv_blocked) = abap_false.
*    DATA(lv_reason)  = VALUE string( ).
*
*    "1) Check production orders referencing this version (AFPO-VERID)  [blocking]
*    SELECT SINGLE verid FROM afpo
*      WHERE verid = @ls_mkal-verid
*        AND matnr = @ls_mkal-matnr
*        AND pwerk = @ls_mkal-werks
*      INTO @DATA(lv_verid_exist_po).
*
*    IF sy-subrc = 0.
*      lv_blocked = abap_true.
*      lv_reason  = |In use by production orders |.
*    ENDIF.
*
*    "2) Check planned orders referencing this version (PLAF-VERID)    [blocking]
*    IF lv_blocked = abap_false.
*      SELECT SINGLE verid FROM plaf
*        WHERE verid = @ls_mkal-verid
*          AND matnr = @ls_mkal-matnr
*          AND plwrk = @ls_mkal-werks
*        INTO @DATA(lv_verid_exist_plaf).
*      IF sy-subrc = 0.
*        lv_blocked = abap_true.
*        lv_reason  = |In use by planned orders |.
*      ENDIF.
*    ENDIF.
*
*    CLEAR gs_result.
*    MOVE-CORRESPONDING ls_mkal TO gs_result.
*
*    IF lv_blocked = abap_true AND p_force IS INITIAL.
*      gs_result-status  = 'SKIPPED'.
*      gs_result-message = lv_reason.
*      gs_result-light = '2'.
*      APPEND gs_result TO gt_results.
*      CONTINUE.
*    ENDIF.
*
*    IF p_test = abap_true.
*      gs_result-status  = 'WOULD_DEL'.
*      gs_result-message = COND string( WHEN lv_blocked = abap_true
*                                       THEN |Force delete requested: { lv_reason }|
*                                       ELSE |OK to delete| ).
*      gs_result-light = '2'.
*      APPEND gs_result TO gt_results.
*    ELSE.
*      APPEND ls_mkal TO gt_delete.
*    ENDIF.



     gs_result-matnr = ls_mkal-matnr.
     gs_result-werks = ls_mkal-werks.
     gs_result-verid = ls_mkal-verid.
     gs_result-old_sp = ls_mkal-mksp.
     gs_result-new_sp = ls_input-mksp.
     IF ls_input-mksp <= 2.
     ls_mkal-mksp     = ls_input-mksp.
     ELSE.
      gs_result-status  = 'INVALID DATA'.
      gs_result-light   = '1'.
      APPEND gs_result TO gt_results.
      CONTINUE.
      ENDIF.
    IF p_test = abap_true.
      gs_result-status  = 'SIMULATED'.
      gs_result-light   = '2'.
    ELSE.
      APPEND ls_mkal TO gt_update.
      gs_result-status  = 'UPDATED'.
      gs_result-light   = '3'.
    ENDIF.

    APPEND gs_result TO gt_results.


  ENDLOOP.

  IF p_test = abap_false AND gt_update IS NOT INITIAL.

    DATA: lt_mkal_i    TYPE STANDARD TABLE OF mkal,
          lt_mkal_u    TYPE STANDARD TABLE OF mkal,
          lt_mkal_d    TYPE STANDARD TABLE OF mkal,
          lt_mkal_aend TYPE STANDARD TABLE OF mkal_aend.

    lt_mkal_u = gt_update.

* If p_chk is NOT INITIAL.

    CALL FUNCTION 'CM_FV_PROD_VERS_DB_UPDATE'
      TABLES
        it_mkal_i    = lt_mkal_i
        it_mkal_u    = lt_mkal_u
        it_mkal_d    = lt_mkal_d
        it_mkal_aend = lt_mkal_aend.


    IF sy-subrc = 0.
      COMMIT WORK.
    ELSE.
      ROLLBACK WORK.
      MESSAGE 'Database update failed' TYPE 'E'.
    ENDIF.
  ENDIF.

*    IF sy-subrc = 0.
*      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*        EXPORTING
*          wait = 'X'.
*
*      LOOP AT gt_update INTO ls_mkal.
*        CLEAR gs_result.
*        MOVE-CORRESPONDING ls_mkal TO gs_result.
*        gs_result-status  = 'DELETED'.
*        gs_result-light   = '3'.
*        APPEND gs_result TO gt_results.
*      ENDLOOP.
*    ELSE.
*      ROLLBACK WORK.
*      MESSAGE 'Database update failed' TYPE 'E'.
*    ENDIF.
*  ENDIF.

END-OF-SELECTION.


DATA: lt_fieldcat TYPE slis_t_fieldcat_alv,
        ls_layout   TYPE slis_layout_alv.

  ls_layout-zebra             = 'X'.
  ls_layout-colwidth_optimize = 'X'.
  ls_layout-lights_fieldname  = 'LIGHT'.

  PERFORM build_fcat USING:
    'MATNR'  'Material',
    'WERKS'  'Plant',
    'VERID'  'Version',
    'OLD_SP' 'Old MKSP',
    'NEW_SP' 'New MKSP',
    'STATUS' 'Status'.
*    'MESSAGE' 'Message'.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      is_layout   = ls_layout
      it_fieldcat = lt_fieldcat
    TABLES
      t_outtab    = gt_results.

FORM build_fcat USING f_name f_text.
  DATA: ls_fc TYPE slis_fieldcat_alv.
  ls_fc-fieldname = f_name.
  ls_fc-seltext_l = f_text.
  APPEND ls_fc TO lt_fieldcat.
ENDFORM.


*
*  DATA: lt_fieldcat TYPE slis_t_fieldcat_alv,
*        ls_fieldcat TYPE slis_fieldcat_alv,
*        ls_layout   TYPE slis_layout_alv.
*
*  ls_layout-zebra             = 'X'.
*  ls_layout-colwidth_optimize = 'X'.
*  ls_layout-lights_fieldname  = 'LIGHT'. " Tells ALV which field has the color code
*
*  " 2. Manually build Field Catalog (Since we aren't using a Dictionary Structure)
*  CLEAR ls_fieldcat.
*  ls_fieldcat-fieldname = 'MATNR'.
*  ls_fieldcat-seltext_l = 'Material'.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
*  CLEAR ls_fieldcat.
*  ls_fieldcat-fieldname = 'WERKS'.
*  ls_fieldcat-seltext_l = 'Plant'.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
*    CLEAR ls_fieldcat.
*
*  ls_fieldcat-fieldname = 'VERID'.
*  ls_fieldcat-seltext_l = 'Version'.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
*  CLEAR ls_fieldcat.
*  ls_fieldcat-fieldname = 'STATUS'.
*  ls_fieldcat-seltext_l = 'Status'.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
*  CLEAR ls_fieldcat.
*  ls_fieldcat-fieldname = 'MESSAGE'.
*  ls_fieldcat-seltext_l = 'Message'.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
*  " 3. Call the Function Module
*  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
*    EXPORTING
*      is_layout     = ls_layout
*      it_fieldcat   = lt_fieldcat
*    TABLES
*      t_outtab      = gt_results
*    EXCEPTIONS
*      program_error = 1
*      OTHERS        = 2.
