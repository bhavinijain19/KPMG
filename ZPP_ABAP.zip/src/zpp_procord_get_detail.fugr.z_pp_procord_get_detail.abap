FUNCTION z_pp_procord_get_detail.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(NUMBER) LIKE  BAPI_ORDER_KEY-ORDER_NUMBER
*"     VALUE(COLLECTIVE_ORDER)
*"  LIKE  BAPI_ORDER_FUNC_CNTRL-COLLECTIVE_ORDER OPTIONAL
*"     VALUE(ORDER_OBJECTS) LIKE  BAPI_PI_ORDER_OBJECTS
*"  STRUCTURE  BAPI_PI_ORDER_OBJECTS
*"  EXPORTING
*"     VALUE(RETURN) LIKE  BAPIRET2 STRUCTURE  BAPIRET2
*"  TABLES
*"      HEADER STRUCTURE  BAPI_ORDER_HEADER1 OPTIONAL
*"      POSITION STRUCTURE  BAPI_ORDER_ITEM OPTIONAL
*"      SEQUENCE STRUCTURE  BAPI_ORDER_SEQUENCE OPTIONAL
*"      PHASE STRUCTURE  BAPI_ORDER_PHASE OPTIONAL
*"      TRIGGER_POINT STRUCTURE  BAPI_ORDER_TRIGGER_POINT OPTIONAL
*"      COMPONENT STRUCTURE  BAPI_ORDER_COMPONENT OPTIONAL
*"      PROD_REL_TOOL STRUCTURE  BAPI_ORDER_PROD_REL_TOOLS OPTIONAL
*"      ORDERSEASONDATA STRUCTURE  BAPI_RFM_S_SEASON OPTIONAL
*"--------------------------------------------------------------------
* start FLE MATNR BAPI Changes
  DATA: lt_fnames1 TYPE cl_matnr_chk_mapper=>tt_matnr_bapi_fname,
        lt_fnames2 TYPE cl_matnr_chk_mapper=>tt_matnr_bapi_fname,
        lt_fnames3 TYPE cl_matnr_chk_mapper=>tt_matnr_bapi_fname,
        lt_fnames4 TYPE cl_matnr_chk_mapper=>tt_matnr_bapi_fname,
        lt_fnames5 TYPE cl_matnr_chk_mapper=>tt_matnr_bapi_fname.

  FIELD-SYMBOLS: <lfs_prod_rel_tool> TYPE bapi_order_prod_rel_tools.

* components
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  lt_fnames1 = VALUE #( ( int = 'MATERIAL' ext = 'MATERIAL_EXTERNAL' vers = 'MATERIAL_VERSION' guid = 'MATERIAL_GUID' long = 'MATERIAL_LONG' ) ).
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = ' '
                                                        it_fnames          = lt_fnames1
                                             CHANGING   ct_matnr           = component[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).      "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* header
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  lt_fnames2 = VALUE #( ( int = 'MATERIAL' ext = 'MATERIAL_EXTERNAL' vers = 'MATERIAL_VERSION' guid = 'MATERIAL_GUID' long = 'MATERIAL_LONG' ) ).
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = ' '
                                                        it_fnames          = lt_fnames2
                                             CHANGING   ct_matnr           = header[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).  "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* items
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  lt_fnames3 = VALUE #( ( int = 'MATERIAL' ext = 'MATERIAL_EXTERNAL' vers = 'MATERIAL_VERSION' guid = 'MATERIAL_GUID' long = 'MATERIAL_LONG' ) ).
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = ' '
                                                        it_fnames          = lt_fnames3
                                             CHANGING   ct_matnr           = position[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).    "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* PRTs
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  lt_fnames4 = VALUE #( ( int = 'MATERIAL' ext = 'MATERIAL_EXTERNAL' vers = 'MATERIAL_VERSION' guid = 'MATERIAL_GUID' long = 'MATERIAL_LONG' ) ).
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = ' '
                                                        it_fnames          = lt_fnames4
                                             CHANGING   ct_matnr           = prod_rel_tool[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).    "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* again PRTs (material as PRT)
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  lt_fnames5 = VALUE #( ( int = 'PRT_NUMBER' long = 'PRT_NUMBER_LONG' ) ).
  CALL METHOD cl_matnr_chk_mapper=>bapi_tables_conv_tab
    EXPORTING
      iv_int_to_external = ' '
      it_fnames          = lt_fnames5
    CHANGING
      ct_matnr           = prod_rel_tool[].     "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* End FLE MATNR BAPI Changes
  "----------------------------------------------------------------------"
  "- Added for Retail & Fashion Management S/4HANA 2021 FPS0
  "----------------------------------------------------------------------"
  IF cl_ops_switch_check=>sfsw_segmentation_04( ) EQ abap_on.
*Segmentation Switch only to execute if switch is on
    IF cl_sgt_chk_mapper=>check_segmentation_value_exist(
      it_component = component[]
      it_position  = position[] ) EQ abap_true.
*Check Segmentation Fields contains Value to retrict conversion without values
      DATA ls_return TYPE bapiret2.
      cl_sgt_chk_mapper=>sfle_sgt_conversion_table_comp(
        EXPORTING
          iv_int_to_external = abap_false
          it_component       = component[]
        CHANGING
          cs_return          = ls_return  ).
      cl_sgt_chk_mapper=>sfle_sgt_conversion_table_pos(
        EXPORTING
          iv_int_to_external = abap_false
          it_position        = position[]
        CHANGING
          cs_return          = ls_return  ).
      IF ls_return IS NOT INITIAL.
        RETURN.
      ENDIF.
*Set Segmentation Flag to avoid redundant execution of segmentation switch
      DATA(lv_segmentation_flag) = abap_true.
    ENDIF.
  ENDIF.
  "---------------------------------------------------------------------"
*ENHANCEMENT-POINT bapi_procord_get_detail_g8 SPOTS es_sapl0001_bapi STATIC.

*ENHANCEMENT-POINT bapi_procord_get_detail_g6 SPOTS es_sapl0001_bapi.

* =====   Data definitions   ===========================================

* Local tables   -------------------------------------------------------
  DATA:

    lt_ioheader TYPE STANDARD TABLE OF ioheader,
    lt_ioitem   TYPE STANDARD TABLE OF ioitem,
    lt_iosequen TYPE STANDARD TABLE OF iosequen,
    lt_iooper   TYPE STANDARD TABLE OF iooper,
    lt_iosoper  TYPE STANDARD TABLE OF iosoper,
    lt_ioopmst  TYPE STANDARD TABLE OF ioopmst,
    lt_ioopcomp TYPE STANDARD TABLE OF ioopcomp,
    lt_ioopprt  TYPE STANDARD TABLE OF ioopprt.

* Local structures   ---------------------------------------------------
  DATA:

    ls_ioheader      TYPE ioheader,
    ls_ioitem        TYPE ioitem,
    ls_iosequen      TYPE iosequen,
    ls_iooper        TYPE iooper,
    ls_iosoper       TYPE iosoper,
    ls_ioopmst       TYPE ioopmst,
    ls_ioopcomp      TYPE ioopcomp,
    ls_ioopprt       TYPE ioopprt,
    ls_header        TYPE bapi_order_header1,
    ls_position      TYPE bapi_order_item,
    ls_sequence      TYPE bapi_order_sequence,
    ls_phase         TYPE bapi_order_phase,
    ls_trigger_point TYPE bapi_order_trigger_point,
    ls_component     TYPE bapi_order_component,
    ls_prod_rel_tool TYPE bapi_order_prod_rel_tools.


* =====   Call API 'COXT_BAPI_GET_LIST'   ==============================

  CALL FUNCTION 'COXT_BAPI_GET_DETAIL'
    EXPORTING
      i_order_number     = number
      i_order_type       = auftragstyp-bord
      i_collective_order = collective_order
      is_order_objects   = order_objects
    IMPORTING
      es_return          = return
    TABLES
      et_headers         = lt_ioheader
      et_positions       = lt_ioitem
      et_sequences       = lt_iosequen
      et_operations      = lt_iooper
      et_trigger_points  = lt_ioopmst
      et_components      = lt_ioopcomp
      et_prod_rel_tools  = lt_ioopprt
      et_suboperations   = lt_iosoper.


* =====   Call function modules for mapping   ==========================

  LOOP AT lt_ioheader INTO ls_ioheader.
    CALL FUNCTION 'MAP2E_IOHEADER_TO_BAPI_ORDER_H'
      EXPORTING
        ioheader           = ls_ioheader
      CHANGING
        bapi_order_header1 = ls_header.
    APPEND ls_header TO header.
  ENDLOOP.
  LOOP AT lt_ioitem INTO ls_ioitem.
    CALL FUNCTION 'MAP2E_IOITEM_TO_BAPI_ORDER_ITE'
      EXPORTING
        ioitem          = ls_ioitem
      CHANGING
        bapi_order_item = ls_position.
    APPEND ls_position TO position.
  ENDLOOP.
  LOOP AT lt_iosequen INTO ls_iosequen.
    CALL FUNCTION 'MAP2E_IOSEQUEN_TO_BAPI_ORDER_S'
      EXPORTING
        iosequen            = ls_iosequen
      CHANGING
        bapi_order_sequence = ls_sequence.
    APPEND ls_sequence TO sequence.
  ENDLOOP.
  LOOP AT lt_iooper INTO ls_iooper.
    CALL FUNCTION 'MAP2E_IOOPER_TO_BAPI_ORDER_PHA'
      EXPORTING
        iooper           = ls_iooper
      CHANGING
        bapi_order_phase = ls_phase.
    APPEND ls_phase TO phase.
  ENDLOOP.
  LOOP AT lt_iosoper INTO ls_iosoper.
    MOVE-CORRESPONDING ls_iosoper TO ls_iooper.             "#EC ENHOK
    CALL FUNCTION 'MAP2E_IOOPER_TO_BAPI_ORDER_PHA'
      EXPORTING
        iooper           = ls_iooper
      CHANGING
        bapi_order_phase = ls_phase.
    APPEND ls_phase TO phase.
  ENDLOOP.
  SORT phase BY operation_number superior_operation secondary_resource.
  LOOP AT lt_ioopmst INTO ls_ioopmst.
    CALL FUNCTION 'MAP2E_IOOPMST_TO_BAPI_ORDER_TR'
      EXPORTING
        ioopmst                  = ls_ioopmst
      CHANGING
        bapi_order_trigger_point = ls_trigger_point.
    APPEND ls_trigger_point TO trigger_point.
  ENDLOOP.
  LOOP AT lt_ioopcomp INTO ls_ioopcomp.
    CALL FUNCTION 'MAP2E_IOOPCOMP_TO_BAPI_ORDER_C'
      EXPORTING
        ioopcomp             = ls_ioopcomp
      CHANGING
        bapi_order_component = ls_component.
    APPEND ls_component TO component.
  ENDLOOP.
  LOOP AT lt_ioopprt INTO ls_ioopprt.
    CALL FUNCTION 'MAP2E_IOOPPRT_TO_BAPI_ORDER_PR'
      EXPORTING
        ioopprt                   = ls_ioopprt
      CHANGING
        bapi_order_prod_rel_tools = ls_prod_rel_tool.
    APPEND ls_prod_rel_tool TO prod_rel_tool.
  ENDLOOP.

* Begin FLE MATNR BAPI Changes
* components
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = 'X'
                                                        it_fnames          = lt_fnames1
                                             CHANGING   ct_matnr           = component[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).  "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* header
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = 'X'
                                                        it_fnames          = lt_fnames2
                                             CHANGING   ct_matnr           = header[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).    "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* items
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING iv_int_to_external = 'X'
                                                       it_fnames          = lt_fnames3
                                             CHANGING  ct_matnr           = position[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).  "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* PRTs
******************begin of ATC changes 13/02/26   UDAYABAP03*************
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external = 'X'
                                                        it_fnames          = lt_fnames4
                                             CHANGING   ct_matnr           = prod_rel_tool[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).  "#EC CI_FLDEXT_OK[2215424]
******************end of ATC changes 13/02/26   UDAYABAP03*************
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* again PRTs (material as PRT)
  cl_matnr_chk_mapper=>bapi_tables_conv_tab( EXPORTING  iv_int_to_external       = 'X'
                                                        it_fnames                = lt_fnames5
                                             CHANGING   ct_matnr                 = prod_rel_tool[]
                                             EXCEPTIONS excp_matnr_ne            = 1
                                                        excp_matnr_invalid_input = 2
                                                        OTHERS                   = 3 ).    "#EC CI_FLDEXT_OK[2215424]
  IF sy-subrc NE 0.
*   nothing to do...
  ENDIF.
* End FLE MATNR BAPI Changes
*------------------------------------------------------------------------*
* SOA: JT_20251107: Added to get PRT details for Process Orders
*------------------------------------------------------------------------*
  IF prod_rel_tool[] IS INITIAL AND order_objects-prod_rel_tools IS NOT INITIAL.
    SELECT a~aufnr,
           a~plnnr,
           a~plnal,
           f~objid,
           c~equnr,
           d~eqktx
      INTO TABLE @DATA(lt_prt_details)
      FROM afko AS a
      INNER JOIN plfh AS f
        ON a~plnnr = f~plnnr AND a~plnal = f~plnal
      INNER JOIN crve_a AS c
        ON f~objid = c~objid
      INNER JOIN eqkt AS d
        ON c~equnr = d~equnr
      WHERE a~aufnr = @number.
    IF sy-subrc = 0.
      prod_rel_tool[] = VALUE #(
      FOR ls_prt_details IN lt_prt_details
      ( prt_number = ls_prt_details-equnr
        description = ls_prt_details-eqktx )
      ).
    ENDIF.
  ENDIF.
*------------------------------------------------------------------------*
* EOA: JT_20251107: Added to get PRT details for Process Orders
*------------------------------------------------------------------------*

  "------------------------------------------------------------------------"
  "- Added for Retail & Fashion Management S/4HANA 2021 FPS0
  "------------------------------------------------------------------------"
  IF lv_segmentation_flag = abap_true.
    cl_sgt_chk_mapper=>sfle_sgt_conversion_table_comp(
      EXPORTING
        iv_int_to_external = abap_true
        it_component       = component[]
      CHANGING
        cs_return          = ls_return  ).
    cl_sgt_chk_mapper=>sfle_sgt_conversion_table_pos(
      EXPORTING
        iv_int_to_external = abap_true
        it_position        = position[]
      CHANGING
        cs_return          = ls_return  ).
*Segmentation Flag Clearing after use
    lv_segmentation_flag = abap_false.
  ENDIF.
  "-----------------------------------------------------------------------"
* Added for Retail & Fashion Management
  IF cl_switch_check_fashion=>sfsw_fashion_04( ) EQ abap_on AND lt_ioitem IS NOT INITIAL..
    IF 1 = 2.  MESSAGE s100(fsh_season_msg).  ENDIF.
*     When item details available, the fashion details
*     are collected and appended to the ORDERSEASONDATA
    orderseasondata[] = CORRESPONDING #( lt_ioitem ).
  ENDIF.

*ENHANCEMENT-POINT bapi_procord_get_detail_g7 SPOTS es_sapl0001_bapi.
ENDFUNCTION.
