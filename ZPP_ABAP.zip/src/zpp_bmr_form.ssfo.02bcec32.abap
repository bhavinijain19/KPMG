DATA: lv_pdate TYPE aufk-erdat,
      lv_aufnr TYPE aufk-aufnr.

CLEAR: lv_date,lv_aufnr.

CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
  EXPORTING
    input  = aufnr_imp
  IMPORTING
    output = lv_aufnr.


SELECT SINGLE erdat FROM aufk INTO lv_pdate
  WHERE aufnr = lv_aufnr .

IF lv_pdate IS NOT INITIAL.
  lv_date = |{ lv_pdate+6(2) }.{ lv_pdate+4(2) }.{ lv_pdate+0(4) }|.
  CONDENSE: lv_date.
ELSE.
  CLEAR: lv_date.
ENDIF.





















