*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_SEL
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.
PARAMETERS: p_file  TYPE localfile MODIF ID gg1,
            p_sfmat TYPE zpp_bmr_list-sf_matnr MODIF ID gg2,
            p_stlal TYPE zpp_bmr_list-stlal MODIF ID gg2.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-001.
PARAMETERS : p_rb1 RADIOBUTTON GROUP rg1 DEFAULT 'X',
             p_rb2 RADIOBUTTON GROUP rg1,
             p_rb3 RADIOBUTTON GROUP rg1,
             p_rb4 RADIOBUTTON GROUP rg1.
SELECTION-SCREEN END OF BLOCK b2.


AT SELECTION-SCREEN OUTPUT.
  IF p_rb1 = abap_true OR p_rb3 = abap_true.
    LOOP AT SCREEN.
      IF screen-group1 = 'GG2'.
        screen-invisible = 1.
        screen-active = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ELSEIF p_rb2 = abap_true OR p_rb4 = abap_true.
    LOOP AT SCREEN.
      IF screen-group1 = 'GG1'.
        screen-invisible = 1.
        screen-active = 0.
        MODIFY SCREEN.
      ELSEIF screen-group1 = 'GG2'.
        screen-invisible = 0.
        screen-active = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
**  ELSEIF p_rb3 = abap_true.
**    LOOP AT SCREEN.
**      IF screen-group1 = 'GG2'.
**        screen-invisible = 0.
**        screen-active = 1.
**        MODIFY SCREEN.
**      ELSEIF screen-group1 = 'GG1'.
**        screen-invisible = 0.
**        screen-active = 1.
**        MODIFY SCREEN.
**      ENDIF.
**    ENDLOOP.
**  ELSEIF p_rb4 = abap_true.
**    LOOP AT SCREEN.
**      IF screen-group1 = 'GG1'.
**        screen-invisible = 1.
**        screen-active = 1.
**        MODIFY SCREEN.
**      ENDIF.
**    ENDLOOP.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  " Display File Open Dialog control/screen
  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title = 'SELECT CHEQUE EXCEL FILE'
*     default_filename = '*.xlsx'
*     multiselection   = ' '
    CHANGING
      file_table   = lt_it_tab
      rc           = lv_subrc.
  IF lt_it_tab[] IS NOT INITIAL.
    DATA(ls_tab) = VALUE #( lt_it_tab[ 1 ] OPTIONAL ).
    p_file = ls_tab-filename.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_sfmat.
  DATA: gt_return  TYPE TABLE OF ddshretval,
        gwa_return TYPE ddshretval.

  SELECT DISTINCT sf_matnr
    FROM zpp_bmr_list
    INTO TABLE @DATA(lt_aufnr).

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'WERKS'
      value_org       = 'S'
    TABLES
      value_tab       = lt_aufnr
      return_tab      = gt_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.

  READ TABLE gt_return INTO gwa_return INDEX 1.
  IF sy-subrc = 0.
    p_sfmat = gwa_return-fieldval.
  ENDIF.
