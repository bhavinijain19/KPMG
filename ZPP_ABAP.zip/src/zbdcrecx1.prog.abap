*&---------------------------------------------------------------------*
*&  Include           ZBDCRECX1
*&---------------------------------------------------------------------*


*  for programs doing a data transfer by CALL TRANSACTIONS


SELECTION-SCREEN BEGIN OF LINE .
  SELECTION-SCREEN COMMENT 1(20) TEXT-S05 FOR FIELD CTUMODE.
*  selection-screen position 25.
  PARAMETERS CTUMODE LIKE CTU_PARAMS-DISMODE DEFAULT 'N'.
                                      "A: show all dynpros
                                      "E: show dynpro on error only
                                      "N: do not display dynpro
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.

  SELECTION-SCREEN COMMENT 1(20) TEXT-S06 FOR FIELD CUPDATE.
*  selection-screen position 25.
  PARAMETERS CUPDATE LIKE CTU_PARAMS-UPDMODE DEFAULT 'A'.
                                      "S: synchronously
                                      "A: asynchronously
                                      "L: local
SELECTION-SCREEN END OF LINE.




*----------------------------------------------------------------------*
*   data definition
*----------------------------------------------------------------------*
*       Batchinputdata of single transaction
DATA:   BDCDATA LIKE BDCDATA    OCCURS 0 WITH HEADER LINE.
*       messages of call transaction
DATA:   MESSTAB LIKE BDCMSGCOLL OCCURS 0 WITH HEADER LINE.
*       message texts
TABLES: T100.


*----------------------------------------------------------------------*
*        Start new transaction according to parameters                 *
*----------------------------------------------------------------------*
FORM BDC_TRANSACTION USING TCODE.
  DATA: L_MSTRING(480).
  DATA: L_SUBRC LIKE SY-SUBRC.
  data: w_param TYPE ctu_params.
w_param-DISMODE = ctumode.
w_param-UPDMODE = cupdate.
w_param-DEFSIZE = 'X'.
* call transaction using
    REFRESH MESSTAB.
    CALL TRANSACTION TCODE USING BDCDATA
                     OPTIONS FROM w_param
*                     MODE   CTUMODE
*                     UPDATE CUPDATE
                     MESSAGES INTO MESSTAB.
    L_SUBRC = SY-SUBRC.

      WRITE: / 'CALL_TRANSACTION',
               TCODE,
               'returncode:'(I05),
               L_SUBRC,
               'RECORD:',
               SY-INDEX.
      LOOP AT MESSTAB.
        SELECT SINGLE * FROM T100 WHERE SPRSL = MESSTAB-MSGSPRA
                                  AND   ARBGB = MESSTAB-MSGID
                                  AND   MSGNR = MESSTAB-MSGNR.
        IF SY-SUBRC = 0.
          L_MSTRING = T100-TEXT.
          IF L_MSTRING CS '&1'.
            REPLACE '&1' WITH MESSTAB-MSGV1 INTO L_MSTRING.
            REPLACE '&2' WITH MESSTAB-MSGV2 INTO L_MSTRING.
            REPLACE '&3' WITH MESSTAB-MSGV3 INTO L_MSTRING.
            REPLACE '&4' WITH MESSTAB-MSGV4 INTO L_MSTRING.
          ELSE.
            REPLACE '&' WITH MESSTAB-MSGV1 INTO L_MSTRING.
            REPLACE '&' WITH MESSTAB-MSGV2 INTO L_MSTRING.
            REPLACE '&' WITH MESSTAB-MSGV3 INTO L_MSTRING.
            REPLACE '&' WITH MESSTAB-MSGV4 INTO L_MSTRING.
          ENDIF.
          CONDENSE L_MSTRING.
          WRITE: / MESSTAB-MSGTYP, L_MSTRING(250).
        ELSE.
          WRITE: / MESSTAB.
        ENDIF.
      ENDLOOP.
      SKIP.

  REFRESH BDCDATA.
ENDFORM.

*----------------------------------------------------------------------*
*        Start new screen                                              *
*----------------------------------------------------------------------*
FORM BDC_DYNPRO USING PROGRAM DYNPRO.
  CLEAR BDCDATA.
  BDCDATA-PROGRAM  = PROGRAM.
  BDCDATA-DYNPRO   = DYNPRO.
  BDCDATA-DYNBEGIN = 'X'.
  APPEND BDCDATA.
ENDFORM.

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM BDC_FIELD USING FNAM FVAL.

    CLEAR BDCDATA.
    BDCDATA-FNAM = FNAM.
    BDCDATA-FVAL = FVAL.
    APPEND BDCDATA.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_FILE
*&---------------------------------------------------------------------*
*       F4 to select files
*----------------------------------------------------------------------*

FORM UPLOAD_FILE using lp_file type  IBIPPARMS-PATH.

CALL FUNCTION 'F4_FILENAME'
EXPORTING
   PROGRAM_NAME        = SYST-CPROG
   DYNPRO_NUMBER       = SYST-DYNNR
   FIELD_NAME          = 'P_FILR'
IMPORTING
   FILE_NAME           = lp_file
          .
ENDFORM.                    " UPLOAD_FILE
