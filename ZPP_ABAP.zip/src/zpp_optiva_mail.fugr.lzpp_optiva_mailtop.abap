FUNCTION-POOL ZPP_OPTIVA_MAIL            MESSAGE-ID SV.

* INCLUDE LZPP_OPTIVA_MAILD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_OPTIVA_MAILT00                     . "view rel. data dcl.
