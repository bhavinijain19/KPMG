PROCESS BEFORE OUTPUT.
  MODULE status_9000.
*&SPWIZARD: PBO FLOW LOGIC FOR TABLECONTROL 'LT_TAB_CTRL'
  MODULE lt_tab_ctrl_change_tc_attr.
*&SPWIZARD: MODULE LT_TAB_CTRL_CHANGE_COL_ATTR.
  LOOP AT   lt_tbctrl
       INTO ls_tbctrl
       WITH CONTROL lt_tab_ctrl
       CURSOR lt_tab_ctrl-current_line.
    MODULE lt_tab_ctrl_get_lines.
    MODULE modify_table.
*&SPWIZARD:   MODULE LT_TAB_CTRL_CHANGE_FIELD_ATTR
  ENDLOOP.
*  CALL SUBSCREEN ss1 : INCLUDING sy-repid lv_dynnr.
*
PROCESS AFTER INPUT.
  CHAIN.
    FIELD p_aufnr MODULE check_order.
  ENDCHAIN.
  MODULE user_command_9000.
*&SPWIZARD: PAI FLOW LOGIC FOR TABLECONTROL 'LT_TAB_CTRL'
  LOOP AT lt_tbctrl.
    CHAIN.
      FIELD ls_tbctrl-sr_no.
      FIELD ls_tbctrl-werks.
      FIELD ls_tbctrl-sf_matnr.
      FIELD ls_tbctrl-stlal.
      FIELD ls_tbctrl-process_txt.
      FIELD ls_tbctrl-matnr.
      FIELD ls_tbctrl-contribution.
      FIELD ls_tbctrl-std_qty.
      FIELD ls_tbctrl-act_qty.
      FIELD ls_tbctrl-std_tmp.
      FIELD ls_tbctrl-act_tmp.
      FIELD ls_tbctrl-std_time.
      FIELD ls_tbctrl-act_time_hr_f.
      FIELD ls_tbctrl-act_time_hr_t.
      FIELD ls_tbctrl-remarks.
      MODULE lt_tab_ctrl_modify ON CHAIN-REQUEST.
      MODULE check_actual_qty ON CHAIN-INPUT.
    ENDCHAIN.
    FIELD ls_tbctrl-sel
      MODULE lt_tab_ctrl_mark ON REQUEST.
  ENDLOOP.
  MODULE lt_tab_ctrl_user_command.
*&SPWIZARD: MODULE LT_TAB_CTRL_CHANGE_TC_ATTR.
*&SPWIZARD: MODULE LT_TAB_CTRL_CHANGE_COL_ATTR.
*  CALL SUBSCREEN ss1.

PROCESS ON HELP-REQUEST.
  FIELD p_aufnr MODULE get_orderhelp.
