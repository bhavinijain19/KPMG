*&---------------------------------------------------------------------*
*& Report  ZPP_OPTIVA_QP_UPLOAD
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT ZPP_OPTIVA_QP_UPLOAD.

INCLUDE ZPP_OPTIVA_QP_TOP.
INCLUDE ZPP_OPTIVA_QP_SEL.
INCLUDE ZPP_OPTIVA_QP_SUB.


START-OF-SELECTION.

PERFORM read_data.
