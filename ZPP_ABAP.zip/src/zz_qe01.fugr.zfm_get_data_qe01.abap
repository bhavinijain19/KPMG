FUNCTION zfm_get_data_qe01.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  EXPORTING
*"     REFERENCE(CS_QALS) TYPE  QALS
*"----------------------------------------------------------------------
*  cs_qals-zz1_zcontrol_ind_ilh = qals-zz1_zcontrol_ind_ilh.
*  cs_qals-zz1_zloc_ilh         = qals-zz1_zloc_ilh .
*  cs_qals-zz1_zsample_qty_ilh  = qals-zz1_zsample_qty_ilh .





ENDFUNCTION.
