*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_BMR_LIST
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_BMR_LIST        .

  PERFORM TABLEPROC.

ENDFUNCTION.
