*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPRT_CC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPRT_CC             .

  PERFORM TABLEPROC.

ENDFUNCTION.
