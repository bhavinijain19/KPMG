*&----------------------------------------------------------------------------*
*& Report  ZPP_BOM_MASTER
*&----------------------------------------------------------------------------*
*& Title: BOM Master Upload
*&----------------------------------------------------------------------------*
*& Report Author         :
*& Functional Consultant :
*& Report Creation Date  : 11/12/2025
*& Transaction Code      :
*& Request Number        :  DEVK900398
*&----------------------------------------------------------------------------*

REPORT zpp_bom_master.

INCLUDE zpp_bom_upld_top.
INCLUDE zpp_bom_upld_rtn.

DATA : filename TYPE string.

INITIALIZATION.

  SELECTION-SCREEN BEGIN OF BLOCK blk1 WITH FRAME TITLE TEXT-t01.
    PARAMETERS p_fname LIKE ibipparms-path OBLIGATORY.
    PARAMETERS   p_mode    TYPE ctu_params-dismode DEFAULT 'A'.
  SELECTION-SCREEN END OF BLOCK blk1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_fname.
  PERFORM filename_request USING p_fname.

AT SELECTION-SCREEN.
  IF p_fname IS INITIAL.
    MESSAGE : 'ENTER THE FILE NAME' TYPE 'E'.
  ENDIF.
  filename = p_fname.

START-OF-SELECTION.


  PERFORM data_load USING filename.

**  SORT zbom BY docu_no.
  SORT zbom BY material_no.

  PERFORM bdc_execution USING p_mode.


  LOOP AT messtab.

    SELECT SINGLE * FROM t100 WHERE sprsl = messtab-msgspra
                              AND   arbgb = messtab-msgid
                              AND   msgnr = messtab-msgnr.
    IF sy-subrc = 0.
      l_mstring = t100-text.
      IF l_mstring CS '&1'.
        REPLACE '&1' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&2' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&3' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&4' WITH messtab-msgv4 INTO l_mstring.
      ELSE.
        REPLACE '&' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv4 INTO l_mstring.
      ENDIF.
      CONDENSE l_mstring.
      WRITE: / messtab-msgtyp, l_mstring(250).
    ELSE.
      WRITE: / messtab.
    ENDIF.
  ENDLOOP.
