*&---------------------------------------------------------------------*
*& Include          ZPP_IP_UPLOAD_FORM
*&---------------------------------------------------------------------*
FORM download_template.
  DATA: lv_filename  TYPE string,
        lt_file_data TYPE TABLE OF string,
        lv_header    TYPE string,
        lv_fname     TYPE string,
        lv_path      TYPE string,
        lv_fpath     TYPE string,
        lv_action    TYPE i.

  " Add your specific field list here
  DATA(lv_tab) = cl_abap_char_utilities=>horizontal_tab.

  lv_header = |Material{ lv_tab }Activity{ lv_tab }Control Key{ lv_tab }| &&
              |Plant{ lv_tab }Operation Short Text{ lv_tab }Valid From DD.MM.YYYY{ lv_tab }Task List Usage{ lv_tab }| &&
              |Task List Status{ lv_tab }Task List UoM{ lv_tab }Inspection Characteristic Number{ lv_tab }MIC{ lv_tab }| &&
              |MIC Description{ lv_tab }Inspection Method{ lv_tab }Inspection Method Plan{ lv_tab }Sampling Procedure{ lv_tab }| &&
              |Decimal Place{ lv_tab }Characteristics UoM{ lv_tab }Target Value{ lv_tab }Lower Tolerance Limit{ lv_tab }| &&
              |Upper Tolerance Limit{ lv_tab }Selected Set Code{ lv_tab }Formula|.

  lv_filename = |IP_Template_{ sy-datum }_{ sy-uzeit }|.

  APPEND lv_header TO lt_file_data.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'Save Template As'
      default_extension = 'XLS'
      default_file_name = lv_filename  " Sets 'BP_Template' as the default
      initial_directory = 'C:\'
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fpath
      user_action       = lv_action.

  CHECK lv_action = cl_gui_frontend_services=>action_ok.

  " Download Header only (empty data table)
  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename              = lv_fpath
      filetype              = 'DAT'
      write_field_separator = 'X' " Ensures Excel columns align
    TABLES
      data_tab              = lt_file_data.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form VALUE_REQUEST
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM value_request.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name = sy-cprog
    IMPORTING
      file_name    = p_flname.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form VALIDATIONS
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM validations.

  IF p_flname IS INITIAL.
    MESSAGE 'FILE NAME' TYPE 'S'.
    LEAVE LIST-PROCESSING.
  ENDIF.

  IF p_flname CP '*.xlsx'. " Check if pattern matches .xlsx
    " Proceed with upload
  ELSE.
    MESSAGE 'Error: Only .xlsx file format is allowed.' TYPE 'E'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form UPLOAD_EXCEL
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM upload_excel.
  DATA: lv_fname   TYPE string.

  lv_fname = p_flname.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  PERFORM convert_data.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form convert_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM convert_data .
  DATA: lv_xstring    TYPE xstring,
        lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
        lv_docname    TYPE string,
        lt_worksheets TYPE STANDARD TABLE OF string,
        lv_worksheet  TYPE string,
        lv_lines      TYPE i,
        lo_data       TYPE REF TO data.

  FIELD-SYMBOLS: <lt_data_bin>  TYPE STANDARD TABLE,
                 <ls_data_bin>  TYPE any,
                 <lv_value_bin> TYPE any,
                 <lv_value>     TYPE any.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  CREATE OBJECT lo_excel
    EXPORTING
      document_name = lv_docname
      xdocument     = lv_xstring.

  IF lo_excel IS NOT INITIAL.
    lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
      IMPORTING
        worksheet_names = lt_worksheets ).
  ENDIF.

  DESCRIBE TABLE lt_worksheets LINES lv_lines.

  IF lt_worksheets[] IS NOT INITIAL.
    READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
    lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
    ASSIGN lo_data->* TO <lt_data_bin>.
  ENDIF.

  IF <lt_data_bin> IS ASSIGNED.
    LOOP AT <lt_data_bin> ASSIGNING <ls_data_bin> FROM 2.
      CLEAR: wa_file.
      DO.
        ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data_bin> TO <lv_value_bin>.
        IF sy-subrc EQ 0.
          ASSIGN COMPONENT sy-index OF STRUCTURE wa_file TO <lv_value>.
          IF sy-subrc EQ 0.
            <lv_value> = <lv_value_bin>.
          ENDIF.
        ELSE.
          EXIT.
        ENDIF.
      ENDDO.
      IF wa_file IS NOT INITIAL.
        APPEND wa_file TO it_file.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form create_qp
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM create_ip.

  DATA: lv_msg          TYPE string, lv_msgty TYPE bapi_mtype,
        lv_group        TYPE plnnr,
        lv_counter      TYPE plnal,
        lv_last_counter TYPE plnal,
        lv_validfrom    TYPE datum,
        lv_uom          TYPE meinh.

  SORT it_file BY material plant activity.

  LOOP AT it_file ASSIGNING FIELD-SYMBOL(<ls_row>).
    APPEND INITIAL LINE TO t_log ASSIGNING FIELD-SYMBOL(<ls_log_row>).
    MOVE-CORRESPONDING <ls_row> TO <ls_log_row>.

    lv_validfrom = <ls_row>-valid_from+6(4) && <ls_row>-valid_from+3(2) && <ls_row>-valid_from+0(2).

    " AT NEW plant triggers if Material OR Plant changes
    AT NEW material.
      REFRESH: lt_task, lt_alloc, lt_operation, lt_char, lt_return.
      CLEAR: lv_group, lv_counter.

      SELECT SINGLE meinh FROM marm INTO lv_uom WHERE matnr = <ls_row>-material.

      SELECT plnnr, plnal FROM mapl UP TO 1 ROWS
        INTO (@lv_group, @lv_last_counter)
        WHERE matnr = @<ls_row>-material
          AND werks = @<ls_row>-plant
          AND plnty = 'Q'
          AND loekz = @space
        ORDER BY plnnr ASCENDING, plnal DESCENDING.
      ENDSELECT.

      lv_counter = COND #( WHEN sy-subrc = 0
                           THEN |{ lv_last_counter + 1 WIDTH = 2 ALIGN = RIGHT PAD = '0' }|
                           ELSE '01' ).

      APPEND VALUE #( task_list_group  = lv_group
                      group_counter    = lv_counter
                      plant            = <ls_row>-plant
                      valid_from       = lv_validfrom
                      valid_to_date = '99991231'
                      task_list_usage  = <ls_row>-task_list_usage
                      task_list_status = <ls_row>-task_list_status
                      task_measure_unit = lv_uom
                      lot_size_from = 1
                      lot_size_to = '99999999.00'
                      description      = <ls_row>-description ) TO lt_task.

      " Map Allocation
      APPEND VALUE #( material        = <ls_row>-material
                      plant           = <ls_row>-plant
                      task_list_group = lv_group
                      group_counter   = lv_counter
                      valid_from      = lv_validfrom
                      valid_to_date = '99991231' ) TO lt_alloc.
    ENDAT.

    AT NEW activity.
      APPEND VALUE #( task_list_group = lv_group
                      group_counter   = lv_counter
                      activity        = <ls_row>-activity
                      control_key     = <ls_row>-control_key
                      plant           = <ls_row>-plant
                      description     = <ls_row>-description
                      valid_from      = lv_validfrom
                      valid_to_date = '99991231'
                      operation_measure_unit = lv_uom
                      denominator = 1 nominator = 1 base_quantity = 1 ) TO lt_operation.
    ENDAT.

    " 6. Map Characteristics
    DATA(ls_char) = VALUE bapi1191_cha_c(
      task_list_group = lv_group
      group_counter   = lv_counter
      activity        = <ls_row>-activity "
      inspchar        = <ls_row>-inspchar "
      valid_from      = lv_validfrom  "
      valid_to_date   = '99991231' "
      mstr_char       = <ls_row>-mstr_char "
      pmstr_char      = <ls_row>-plant "
      char_descr      = <ls_row>-char_descr "
      method          = <ls_row>-method "
      pmethod         = <ls_row>-pmethod "
      smpl_procedure  = <ls_row>-smpl_procedure "
      smpl_unit               = COND #( WHEN <ls_row>-smpl_procedure IS NOT INITIAL THEN lv_uom ELSE space )
      smpl_quant              = COND #( WHEN <ls_row>-smpl_procedure IS NOT INITIAL THEN 1 ELSE space )
      sampling_procedure_ind  = COND #( WHEN <ls_row>-smpl_procedure IS NOT INITIAL AND <ls_row>-mstr_char NE 'WPL2' THEN 'X' ELSE space )
      cha_master_import_modus = COND #( WHEN <ls_row>-mstr_char EQ 'WPL2' THEN 'C' ELSE 'N' )
      formula_field_1 = <ls_row>-formula
      formula_check_by_sap  = COND #( WHEN <ls_row>-mstr_char EQ 'WPL2' THEN 'X' ELSE space )
      ).

    SELECT SINGLE msehi FROM t006a INTO @DATA(lv_msehi) WHERE spras = 'E' AND mseh6 = @<ls_row>-meas_unit.

    IF <ls_row>-target_val IS NOT INITIAL OR <ls_row>-up_tol_lmt IS NOT INITIAL OR <ls_row>-lw_tol_lmt IS NOT INITIAL.
      ls_char = VALUE #( BASE ls_char
        cha_master_import_modus = COND #( WHEN <ls_row>-mstr_char EQ 'WPL2' THEN 'C' ELSE 'N' )
        meas_value_confirm_ind = COND #( WHEN <ls_row>-meas_unit IS NOT INITIAL AND <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        up_tol_lmt_ind = COND #( WHEN <ls_row>-up_tol_lmt IS NOT INITIAL AND <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        lw_tol_lmt_ind = COND #( WHEN <ls_row>-lw_tol_lmt IS NOT INITIAL AND <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        target_val_check_ind = COND #( WHEN <ls_row>-target_val IS NOT INITIAL AND <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        long_term_insp_ind = COND #( WHEN <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        confirmation_category	= COND #( WHEN <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )
        quantitative_ind = COND #( WHEN <ls_row>-mstr_char NE 'WPL2' THEN abap_true ELSE abap_false )

        dec_places      = <ls_row>-dec_places
        meas_unit       = <ls_row>-meas_unit
        target_val      = <ls_row>-target_val
        up_tol_lmt      = <ls_row>-up_tol_lmt
        lw_tol_lmt      = <ls_row>-lw_tol_lmt
      ).
    ENDIF.
    IF ls_char-quantitative_ind IS INITIAL.
      SELECT SINGLE auswmenge1 FROM qpmz INTO @DATA(lv_selset) WHERE zaehler = @<ls_row>-plant AND mkmnr = @ls_char-mstr_char.
      IF sy-subrc = 0.
        ls_char-sel_set1 = lv_selset." <ls_row>-sel_set1.
        ls_char-psel_set1 = <ls_row>-plant.
        ls_char-attribute_required_ind = abap_true.
      ENDIF.
    ENDIF.
    APPEND ls_char TO lt_char.

    " 7. Call BAPI at end of Material/Plant group
    AT END OF material.
      CALL FUNCTION 'BAPI_INSPECTIONPLAN_CREATE'
        IMPORTING
          group                  = lv_group
          groupcounter           = lv_counter
        TABLES
          task                   = lt_task
          materialtaskallocation = lt_alloc
          operation              = lt_operation
          inspcharacteristic     = lt_char
          return                 = lt_return.

      IF NOT line_exists( lt_return[ type = 'E' ] ).
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = 'X'.
        lv_msgty = 'S'.
        lv_msg   = |Success: Plan { lv_group }/{ lv_counter } created|.
      ELSE.
        CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
        lv_msgty = 'E'.
        LOOP AT lt_return INTO DATA(ls_m) WHERE type = 'E'.
          lv_msg = |{ lv_msg } { ls_m-message }|.
        ENDLOOP.
      ENDIF.

      MODIFY t_log FROM VALUE #( msgty = lv_msgty message = lv_msg )
        TRANSPORTING msgty message
        WHERE material = <ls_row>-material.
    ENDAT.
    CLEAR: lv_validfrom, ls_char, lv_uom.
    REFRESH: lt_task[], lt_alloc[], lt_operation[], lt_char[], lt_return.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form download_log_to_excel
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM download_log_to_excel.
  DATA: lv_filename TYPE string,
        lv_path     TYPE string,
        lv_fullpath TYPE string.

  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING
      default_extension = 'XLSX'
      default_file_name = |Inspection_Plan_Log_{ sy-datum }_{ sy-uzeit }.xls|
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fullpath ).

  IF lv_fullpath IS NOT INITIAL.
    CALL FUNCTION 'GUI_DOWNLOAD'
      EXPORTING
        filename              = lv_fullpath
        filetype              = 'ASC'
        write_field_separator = 'X' " Makes it readable by Excel
        confirm_overwrite     = 'X'
      TABLES
        data_tab              = t_log
      EXCEPTIONS
        file_write_error      = 1
        OTHERS                = 2.

    IF sy-subrc = 0.
      MESSAGE 'Log downloaded successfully.' TYPE 'S'.
    ENDIF.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form display_log
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM display_log .
  " Inline Field Catalog Definition (Avoids long manually-built tables)
  DATA(lt_fcat) = VALUE slis_t_fieldcat_alv(
    ( fieldname = 'MATERIAL'     seltext_m = 'Material' )
    ( fieldname = 'MSGTY'        seltext_m = 'Message Type' )
    ( fieldname = 'MESSAGE'      seltext_m = 'Log Details' outputlen = 255 )
  ).

  DATA(ls_layout) = VALUE slis_layout_alv(
    colwidth_optimize = 'X'
    zebra             = 'X'
  ).

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
      i_callback_user_command = 'USER_COMMAND'
      i_callback_top_of_page  = 'TOP_OF_PAGE'
      is_layout               = ls_layout
      it_fieldcat             = lt_fcat
    TABLES
      t_outtab                = t_log
    EXCEPTIONS
      program_error           = 1
      OTHERS                  = 2.
ENDFORM.
