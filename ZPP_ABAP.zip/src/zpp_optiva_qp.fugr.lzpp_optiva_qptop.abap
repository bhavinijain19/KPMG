FUNCTION-POOL ZPP_OPTIVA_QP              MESSAGE-ID SV.

* INCLUDE LZPP_OPTIVA_QPD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_OPTIVA_QPT00                       . "view rel. data dcl.
