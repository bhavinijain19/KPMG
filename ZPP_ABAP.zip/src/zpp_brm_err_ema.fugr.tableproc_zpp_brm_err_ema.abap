*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_BRM_ERR_EMA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_BRM_ERR_EMA     .

  PERFORM TABLEPROC.

ENDFUNCTION.
