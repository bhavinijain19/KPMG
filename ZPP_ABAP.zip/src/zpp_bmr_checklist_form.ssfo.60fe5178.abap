
lv_index = ls_checklist-sr_no.
CONDENSE lv_index.





















