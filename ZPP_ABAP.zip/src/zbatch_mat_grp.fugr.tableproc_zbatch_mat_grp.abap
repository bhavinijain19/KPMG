*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBATCH_MAT_GRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBATCH_MAT_GRP      .

  PERFORM TABLEPROC.

ENDFUNCTION.
