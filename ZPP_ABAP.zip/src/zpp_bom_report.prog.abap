*&---------------------------------------------------------------------*
*& Report  ZPP_BOM_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zpp_bom_report.

INCLUDE zmm_bom_report_top.
INCLUDE zmm_bom_report_sel.


PARAMETERS: variant LIKE disvariant-variant.
*--- OBJECT AND VARIABLE LIST FOR ALV GRID DISPLAY-------*
DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       fs_layout1     TYPE slis_layout_alv,
       g_save         TYPE c VALUE 'X',
       g_variant      TYPE disvariant,
       g_variant1     TYPE disvariant,
       gx_variant     TYPE disvariant,
       gx_variant1    TYPE disvariant,
       g_exit         TYPE c,
       t_event        TYPE slis_t_event WITH HEADER LINE.
*PARAMETERS: variant LIKE disvariant-variant.
"Adding Start by Rahul Vasita on 23.11.2023 15:50:17
DATA : lt_sort TYPE slis_t_sortinfo_alv,
       ls_sort TYPE slis_sortinfo_alv..
"Adding End by Rahul Vasita on 23.11.2023 15:50:17

INITIALIZATION.
  gx_variant-report = sy-repid.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR variant.
*********************
*  **-- Display all existing variants
  g_variant-report = sy-repid.
* Utilizing the name of the report, this function module will search for a list of
* variants and will fetch the selected one into the parameter field for variants
  CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
    EXPORTING
      is_variant = g_variant
      i_save     = g_save
    IMPORTING
      e_exit     = g_exit
      es_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.



  IF sy-subrc = 2.
    MESSAGE ID sy-msgid TYPE 'S'      NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
    IF g_exit = space.
      variant = gx_variant-variant.
    ENDIF.
  ENDIF.
  "Added by Raj

START-OF-SELECTION.
  PERFORM aurho_object.
  PERFORM get_data.

  PERFORM alv_fcat.
  PERFORM check_variant.
  PERFORM display_data.

FORM get_data .

  c_date = p_aedat.
  sy-uname = ' '.
  IF c_date IS NOT INITIAL.

    CALL FUNCTION 'CHANGEDOCUMENT_READ_HEADERS'
      EXPORTING
*       ARCHIVE_HANDLE             = 0
        date_of_change             = c_date
        objectclass                = 'STUE'
      TABLES
        i_cdhdr                    = it_cdhdr
      EXCEPTIONS
        no_position_found          = 1
        wrong_access_to_archive    = 2
        time_zone_conversion_error = 3
        OTHERS                     = 4.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    DELETE it_cdhdr WHERE udate NE c_date.
    it_cdhdr1[] = it_cdhdr.
    it_cdhdr2  = it_cdhdr.

*    SELECT objectclas  objectid changenr  username  udate tcode  FROM cdhdr INTO TABLE it_cdhdrr WHERE objectclas = 'STUE' AND udate = c_date.
*    SELECT objectclas objectid changenr tabname tabkey FROM cdpos INTO TABLE it_cdpos1 FOR ALL ENTRIES IN it_cdhdrr WHERE tabname = 'MAST' AND changenr = it_cdhdrr-changenr.
    LOOP AT it_cdhdr INTO wa_cdhdr.

      CALL FUNCTION 'CHANGEDOCUMENT_READ_POSITIONS'
        EXPORTING
          archive_handle          = '0'
          changenumber            = wa_cdhdr-changenr
          tablename               = 'MAST'
        TABLES
*         EDITPOS                 =
          editpos_with_header     = it_cdpos
        EXCEPTIONS
          no_position_found       = 1
          wrong_access_to_archive = 2
          OTHERS                  = 3.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.



      LOOP AT it_cdpos INTO wa_cdpos.
*      IF  wa_cdpos-chngind = 'I'.
        wa_final_cdpos-objectid = wa_cdpos-tabkey+3(18).
        APPEND wa_final_cdpos TO it_final_cdpos.
        CLEAR: wa_final_cdpos,wa_cdpos.
*      ENDIF.
      ENDLOOP.
      CLEAR: wa_cdhdr.
    ENDLOOP.

*    else.
*       MESSAGE 'Date is not available' type 'I'.
  ENDIF.
*  ENDLOOP.

*  IF it_final_cdpos IS NOT INITIAL.
*    SELECT matnr
*          werks
*          stlnr
*          stlal
*          losvn
*          losbs
*          andat
*          aedat
*      FROM mast INTO TABLE lt_mast FOR ALL ENTRIES IN it_final_cdpos
*   WHERE matnr = it_final_cdpos-objectid AND werks IN s_werks AND stlal IN s_stlal.
*  ENDIF.

  IF c_date IS INITIAL AND s_matnr IS NOT INITIAL.

     SELECT matnr
         werks
         stlnr
         stlal
         losvn
         losbs
         andat
         aedat
     FROM mast INTO TABLE lt_mast
    WHERE matnr IN s_matnr AND werks IN s_werks AND stlal IN s_stlal.


***************Added by Raj on 09.07.2024******************
if lt_mast is not INITIAL."Added by Raj on 09.07.2024
   select MATNR,STLNR,FEVOR from ZSDFEVOR into table @data(it_afko) FOR ALL ENTRIES IN @lt_mast WHERE MATNR = @lt_mast-matnr and stlnr = @lt_mast-stlnr.
endif.



    IF lt_mast IS NOT INITIAL .
*      SORT lt_mast.

      SELECT stlty
             stlal
             stlnr
             bmeng
             bmein
             lkenz
             andat  "Added by Raj on 24.11.2023
             stlst
             datuv
             guidx FROM stko INTO CORRESPONDING FIELDS OF TABLE lt_stko FOR ALL ENTRIES IN lt_mast
      WHERE stlnr = lt_mast-stlnr AND stlst = s_stlst.
    ENDIF.
    IF lt_stko IS NOT INITIAL.
*      SORT lt_stko. "Commented by Raj on 25.11.2023

      SELECT stlty
             stlal
             stlnr
             stlkn
             stasz FROM stas INTO TABLE lt_stas FOR ALL ENTRIES IN lt_stko
      WHERE stlal = lt_stko-stlal AND stlnr = lt_stko-stlnr.



    ENDIF.

    IF lt_stas IS NOT INITIAL .
*      SORT lt_stas.

      SELECT stlty
             stlnr
             stlkn
             aedat
             andat
             idnrk
             sanka
             menge
             meins
             matkl
             lgort
             guidx FROM stpo INTO CORRESPONDING FIELDS OF TABLE lt_stpo FOR ALL ENTRIES IN lt_stas
      WHERE stlnr = lt_stas-stlnr AND stlkn = lt_stas-stlkn AND stlty = lt_stas-stlty.
    ENDIF.



************************Added by raj on 30.06.2023**************
    IF lt_stpo IS NOT INITIAL.
      SELECT matnr mtart matkl FROM mara INTO TABLE it_mara FOR ALL ENTRIES IN lt_stpo WHERE matnr = lt_stpo-idnrk.


    ENDIF.


    IF lt_stpo IS NOT INITIAL.
*      SORT lt_stpo.

      SELECT matnr
             spras
             maktx FROM makt INTO TABLE lt_makt FOR ALL ENTRIES IN lt_stpo
      WHERE matnr = lt_stpo-idnrk AND spras = 'E'.

    ENDIF.

    "Begin of changes by 4806

    IF lt_mast IS NOT INITIAL.
*      SORT lt_mast.

      SELECT matnr mtart matkl
             FROM mara INTO TABLE lt_mara FOR ALL ENTRIES IN lt_mast
      WHERE matnr = lt_mast-matnr.
      "End of changes by 4806

      SELECT matnr maktx
         FROM makt INTO TABLE it_maktd FOR ALL ENTRIES IN lt_mara
      WHERE matnr = lt_mara-matnr.


    ENDIF.
*******
    DATA : v_key TYPE string.
*  ********Added by Raj on 27.11.2023******
    LOOP AT lt_mast INTO ls_mast.
      CONCATENATE ls_mast-stlnr ls_mast-stlal INTO v_key.
      ls_mast-key = v_key.
      MODIFY lt_mast FROM ls_mast TRANSPORTING key.
      CLEAR :ls_mast,v_key.
    ENDLOOP.

    LOOP AT lt_stko INTO ls_stko.
      CONCATENATE ls_stko-stlnr ls_stko-stlal INTO v_key.
      ls_stko-key = v_key.
      MODIFY lt_stko FROM ls_stko TRANSPORTING key.
      CLEAR :ls_stko,v_key.
    ENDLOOP.

********Added by Raj on 27.11.2023******


    DATA : lv_stlkn1 TYPE c LENGTH 2.

    LOOP AT lt_mast INTO ls_mast.

      LOOP AT lt_stas INTO ls_stas WHERE stlal = ls_mast-stlal AND stlnr = ls_mast-stlnr.


*            lv_stlkn1 = ls_stas-stlkn+6(2).
        ls_final-stlal = ls_stas-stlal.
        READ TABLE lt_stpo INTO ls_stpo WITH KEY stlkn = ls_stas-stlkn stlnr = ls_stas-stlnr.
        ls_final-idnrk = ls_stpo-idnrk.
        ls_final-sanka = ls_stpo-sanka.
        ls_final-menge = ls_stpo-menge.

         CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
          EXPORTING
            input          = ls_stpo-meins
            language       = 'E'
          IMPORTING
            output         = ls_final-meins
          EXCEPTIONS
            unit_not_found = 1
            OTHERS         = 2.
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ENDIF.

*        ls_final-meins = ls_stpo-meins.
        ls_final-matkl = ls_stpo-matkl.

        lv_stlkn1 = ls_stpo-stlkn+6(2).

*    ls_final-stlkn  = lv_stlkn.

        READ TABLE it_mara INTO wa_mara WITH KEY matnr = ls_stpo-idnrk.
        IF sy-subrc = 0.
          ls_final-mtart1 = wa_mara-mtart.
          ls_final-matkl2 = wa_mara-matkl.
        ENDIF.



*        READ TABLE lt_mast INTO ls_mast WITH KEY stlnr = ls_stpo-stlnr."  stlal = lv_stlkn.
*
*        IF sy-subrc = 0.
          ls_final-matnr = ls_mast-matnr.
          ls_final-werks = ls_mast-werks.
          ls_final-losvn = ls_mast-losvn.
          ls_final-losbs = ls_mast-losbs.
          ls_final-andat = ls_mast-andat.
          ls_final-aedat = ls_mast-aedat.
*          ls_final-aedat = ls_mast-aedat.
*        ENDIF.


        READ TABLE lt_stas INTO ls_stas WITH  KEY stlkn =  lv_stlkn1 stlnr = ls_stpo-stlnr stlal = ls_mast-stlal.." Added by Raj for setting logic of BOM status on 25.11.2023


        READ TABLE lt_stko INTO ls_stko WITH  KEY  stlnr = ls_stpo-stlnr stlst = s_stlst stlal = ls_mast-stlal."stlal = ls_stas-stlal." andat = ls_mast-andat. " stlty = ls_stpo-stlty.

*      ls_final-stlal = ls_stko-stlal.
        ls_final-bmeng = ls_stko-bmeng.
        ls_final-bmein = ls_stko-bmein.
        ls_final-bmein2 = ls_stko-bmein.
        ls_final-lkenz = ls_stko-lkenz.
        ls_final-stlst = ls_stko-stlst.
        ls_final-bmein1 = ls_stko-bmein.
        ls_final-datuv = ls_stko-datuv.

*    READ TABLE lt_stko INTO ls_stko WITH  KEY   key = ls_mast-key.
*      ls_final-stlal = ls_stko-stlal."Added by Raj on 28.11.2023

*    LOOP at lt_stpo into ls_stpo.

*    READ TABLE lt_stpo INTO ls_stpo WITH KEY stlnr = ls_mast-stlnr." stlkn = ls_stas-stlkn.

        ls_final-idnrk = ls_stpo-idnrk.
        ls_final-sanka = ls_stpo-sanka.
        ls_final-menge = ls_stpo-menge.
        ls_final-matkl = ls_stpo-matkl.
          ls_final-lgort = ls_stpo-lgort."Added by Raj on 01.07.2024

*Commented by Raj on 28.11.2023
*            READ TABLE lt_stas INTO ls_stas WITH  KEY stlkn =  lv_stlkn1 stlnr = ls_stpo-stlnr." stlty = ls_stpo-stlty."Modified by raj stlal on 29.04.2023
*            IF sy-subrc = 0.
*              ls_final-stlal = ls_stas-stlal.
*            ENDIF.

*Commented by Raj on 28.11.2023
        READ TABLE lt_makt INTO ls_makt WITH KEY matnr = ls_stpo-idnrk.

        ls_final-maktx = ls_makt-maktx.


*    endloop.

        " Begin of changes 4806
        READ TABLE lt_mara INTO ls_mara WITH KEY matnr = ls_mast-matnr.

        ls_final-mtart = ls_mara-mtart.

*      ls_final-matkl2 = ls_mara-mtart.
        ls_final-matkl1 = ls_mara-matkl.
*       ls_final-matkl2 = ls_mara-matkl.
        " End of changes 4806

        READ TABLE it_maktd INTO wa_maktd WITH KEY matnr = ls_mast-matnr.
        ls_final-maktxd = wa_maktd-maktx.

        "Adding Start by Rahul Vasita on 23.11.2023 12:12:48
*        SELECT SINGLE matnr,
*                      bwkey,
*                      bwtar,
*                      vprsv,
*                      verpr,
*                      stprs
*          FROM mbew
*          INTO @DATA(ls_mbew)
*          WHERE matnr = @ls_final-idnrk
*        AND bwkey = @ls_final-werks.
*        IF sy-subrc = 0.
*          IF ls_mbew-vprsv = 'S'.
*            ls_final-price = ls_mbew-stprs.
*          ELSE.
*            ls_final-price = ls_mbew-verpr.
*          ENDIF."ls_mbew-vprsv = 'S'.
*          ls_final-tot_price = ls_final-price * ls_final-menge.
*        ENDIF."End of ls_mbew
*        CLEAR : ls_mbew.
*        "Adding End by Rahul Vasita on 23.11.2023 12:12:48


       READ TABLE it_afko into data(wa_afko) with key MATNR = ls_mast-matnr stlnr = ls_mast-stlnr.
       if sy-subrc = 0.
         ls_final-fevor = wa_afko-fevor.
       endif.

        APPEND ls_final TO lt_final.
        CLEAR: ls_final,wa_mara,wa_maktd, lv_stlkn1,ls_stpo,ls_stas,ls_makt,wa_maktd,ls_stko,wa_afko.


      ENDLOOP.

      CLEAR :ls_mast.
    ENDLOOP.

    IF lt_final IS NOT INITIAL.
      DELETE lt_final WHERE stlst NE s_stlst."Added by Raj on 24.11.2023
      DELETE lt_final WHERE idnrk = ' '.
      delete lt_final where datuv GT sy-datum.
    ENDIF.
*  ENDLOOP.
  ENDIF.
*endif.


**************************************************************Changeing data display
  IF it_final_cdpos IS NOT INITIAL.
*    SELECT matnr
*          werks
*          stlnr
*          stlal
*          losvn
*          losbs
*          andat
*          aedat
*      FROM mast INTO TABLE lt_mast1 FOR ALL ENTRIES IN it_final_cdpos
*   WHERE matnr = it_final_cdpos-objectid AND werks IN s_werks AND stlal IN s_stlal.
    DATA lv_matnr1 TYPE c LENGTH 18.
    LOOP AT it_final_cdpos INTO wa_final_cdpos.

      lv_matnr1 = wa_final_cdpos-objectid.
      SELECT matnr
          werks
          stlnr
          stlal
          losvn
          losbs
          andat
          aedat
      FROM mast INTO TABLE lt_mast1
      WHERE matnr = lv_matnr1 AND werks IN s_werks AND stlal IN s_stlal.

   IF lt_mast1 IS NOT INITIAL."Added by Raj on 09.07.2024
      SELECT MATNR,STLNR,fevor FROM ZSDFEVOR INTO TABLE @DATA(it_afko1) FOR ALL ENTRIES IN @lt_mast1 WHERE MATNR = @lt_mast1-matnr AND stlnr = @lt_mast1-stlnr.
    ENDIF.


      IF lt_mast1 IS NOT INITIAL .
        SORT lt_mast1.

        SELECT stlty
               stlal
               stlnr
               bmeng
               bmein
               lkenz
               andat
               stlst FROM stko INTO TABLE lt_stko1 FOR ALL ENTRIES IN lt_mast1
        WHERE stlnr = lt_mast1-stlnr AND stlal = lt_mast1-stlal  AND andat = lt_mast1-andat. "S_STLST Added by Raj on 11.10.2023
      ENDIF.
      IF lt_stko1 IS NOT INITIAL.
        SORT lt_stko1.

        SELECT stlty
               stlal
               stlnr
               stlkn
               stasz FROM stas INTO TABLE lt_stas1 FOR ALL ENTRIES IN lt_mast1
        WHERE stlal = lt_mast1-stlal AND stlnr = lt_mast1-stlnr.

      ENDIF.

      IF lt_stas1 IS NOT INITIAL .
        SORT lt_stas.

        SELECT stlty
               stlnr
               stlkn
               aedat
               idnrk
               sanka
               menge
               meins
               matkl
               lgort FROM stpo INTO CORRESPONDING FIELDS OF TABLE lt_stpo1 FOR ALL ENTRIES IN lt_stas1
        WHERE stlnr = lt_stas1-stlnr AND stlkn = lt_stas1-stlkn AND stlty = lt_stas1-stlty.
      ENDIF.

      SELECT matnr mtart matkl FROM mara INTO TABLE it_mara FOR ALL ENTRIES IN lt_stpo1 WHERE matnr = lt_stpo1-idnrk.





      IF lt_stpo1 IS NOT INITIAL.
        SORT lt_stpo1.

        SELECT matnr
               spras
               maktx FROM makt INTO TABLE lt_makt1 FOR ALL ENTRIES IN lt_stpo1
        WHERE matnr = lt_stpo1-idnrk AND spras = 'E'.

      ENDIF.

      "Begin of changes by 4806

      IF lt_mast1 IS NOT INITIAL.
        SORT lt_mast1.

        SELECT matnr mtart matkl
               FROM mara INTO TABLE lt_mara1 FOR ALL ENTRIES IN lt_mast1
        WHERE matnr = lt_mast1-matnr.
        "End of changes by 4806

        SELECT matnr maktx
            FROM makt INTO TABLE it_maktd1 FOR ALL ENTRIES IN lt_mara1
        WHERE matnr = lt_mara1-matnr.

      ENDIF.




      DATA : lv_stlkn TYPE c LENGTH 2.

      LOOP AT lt_stpo1 INTO ls_stpo1.
        ls_final1-idnrk = ls_stpo1-idnrk.
        ls_final1-sanka = ls_stpo1-sanka.
        ls_final1-menge = ls_stpo1-menge.
        ls_final1-meins = ls_stpo1-meins.
        ls_final1-matkl = ls_stpo1-matkl.

        lv_stlkn = ls_stpo1-stlkn+6(2).

      ls_final1-lgort = ls_stpo1-lgort. "Added by Raj on 01.07.2024

*      ls_final1-stlkn  = lv_stlkn.

        READ TABLE it_mara INTO wa_mara WITH KEY matnr = ls_stpo1-idnrk.
        ls_final1-mtart1 = wa_mara-mtart.
        ls_final1-matkl2 = wa_mara-matkl.







        READ TABLE lt_mast1 INTO ls_mast1 WITH KEY stlnr = ls_stpo1-stlnr ." stlal = lv_stlkn.
        IF sy-subrc = 0.


          READ TABLE it_cdhdr2 INTO wa_cdhdr2 INDEX 1 ."stlnr = ls_stpo-stlnr.

          ls_final1-matnr = ls_mast1-matnr.
          ls_final1-werks = ls_mast1-werks.
          ls_final1-losvn = ls_mast1-losvn.
          ls_final1-losbs = ls_mast1-losbs.
          ls_final1-andat = ls_mast1-andat.
          ls_final1-aedat = wa_cdhdr2-udate.
        ENDIF.
        READ TABLE lt_stas1 INTO ls_stas1 WITH  KEY stlkn =  lv_stlkn.
        ls_final1-stlal = ls_stas1-stlal.

        READ TABLE lt_stko1 INTO ls_stko1 WITH  KEY stlnr = ls_stpo1-stlnr stlal = ls_stas1-stlal ."andat = ls_mast1-andat."stlal = lv_stlkn.
        IF sy-subrc = 0.
*        ls_final1-stlal = ls_stko1-stlal.
          ls_final1-bmeng = ls_stko1-bmeng.
          ls_final1-bmein = ls_stko1-bmein.
          ls_final1-bmein2 = ls_stko1-bmein.
          ls_final1-lkenz = ls_stko1-lkenz.
          ls_final1-stlst = ls_stko1-stlst.
          ls_final1-bmein1 = ls_stko1-bmein.

*    LOOP at lt_stpo into ls_stpo.

*    READ TABLE lt_stpo INTO ls_stpo WITH KEY stlnr = ls_mast-stlnr." stlkn = ls_stas-stlkn.

          ls_final1-idnrk = ls_stpo1-idnrk.
          ls_final1-sanka = ls_stpo1-sanka.
          ls_final1-menge = ls_stpo1-menge.
          ls_final1-matkl = ls_stpo1-matkl.
        ENDIF.


        READ TABLE lt_makt INTO ls_makt WITH KEY matnr = ls_stpo-idnrk.

        ls_final1-maktx = ls_makt1-maktx.


*    endloop.

        " Begin of changes 4806
        READ TABLE lt_mara1 INTO ls_mara1 WITH KEY matnr = ls_mast1-matnr.

        ls_final1-mtart = ls_mara1-mtart.
*        ls_final1-mtart1 = ls_mara1-mtart.
        ls_final1-matkl1 = ls_mara1-matkl.
*         ls_final1-matkl2 = ls_mara1-matkl.
        " End of changes 4806


        READ TABLE it_maktd1 INTO wa_maktd1 WITH KEY matnr = ls_mast1-matnr.
        ls_final1-maktxd = wa_maktd1-maktx.


           READ TABLE it_afko1 into data(wa_afko1) with key MATNR = ls_mast1-matnr stlnr = ls_mast1-stlnr.
       if sy-subrc = 0.
         ls_final1-fevor = wa_afko1-fevor.
       endif.



        APPEND ls_final1 TO lt_final1.

        IF lt_final1 IS NOT INITIAL.
          DELETE lt_final1 WHERE stlal NE s_stlal-low.
          DELETE lt_final1 WHERE werks = ' '.

        ENDIF.
        CLEAR: ls_final1,wa_mara,wa_maktd1, lv_stlkn1,ls_stpo1,ls_mast1,ls_stas1,ls_makt1,ls_mast1.


      ENDLOOP.
    ENDLOOP.
    IF lt_final1 IS NOT INITIAL.
      DELETE lt_final1 WHERE stlst NE s_stlst."Added by Raj on 24.11.2023
    ENDIF.

  ENDIF.
*    *************************************************************Changeing data display
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  ALV_FCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_fcat .
*  IF s_matnr IS NOT INITIAL AND s_werks IS NOT INITIAL.
  wa_fieldcat-fieldname = 'WERKS'.
  wa_fieldcat-seltext_l = 'PLANT'.
  wa_fieldcat-seltext_m = 'PLANT'.
  wa_fieldcat-col_pos = '1'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'STLAL'.
  wa_fieldcat-seltext_l = 'Alternative BOM'.
  wa_fieldcat-seltext_m = 'Alternative BOM'.
  wa_fieldcat-col_pos = '2'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BMENG'.
  wa_fieldcat-seltext_l = 'Base Quantity'.
  wa_fieldcat-seltext_m = 'Base Quantity'.
  wa_fieldcat-do_sum       = 'X'.
  wa_fieldcat-col_pos = '3'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BMEIN'.
  wa_fieldcat-seltext_l = 'Base Unit'.
  wa_fieldcat-seltext_m = 'Base Unit'.
  wa_fieldcat-col_pos = '4'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LKENZ'.
  wa_fieldcat-seltext_l = 'Deletion Indicator'.
  wa_fieldcat-seltext_m = 'Deletion Indicator'.
  wa_fieldcat-col_pos = '4'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'STLST'.
  wa_fieldcat-seltext_l = 'BOM Status'.
  wa_fieldcat-seltext_m = 'BOM Status'.
  wa_fieldcat-col_pos = '5'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'IDNRK'.
  wa_fieldcat-seltext_l = 'BOM Component'.
  wa_fieldcat-seltext_m = 'BOM Component'.
  wa_fieldcat-col_pos = '6'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MAKTX'.
  wa_fieldcat-seltext_l = 'Material Description'.
  wa_fieldcat-seltext_m = 'Material Description'.
  wa_fieldcat-outputlen = '40'.
  wa_fieldcat-col_pos = '7'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LOSVN'.
  wa_fieldcat-seltext_l = 'From Lot Size'.
  wa_fieldcat-seltext_m = 'From Lot Size'.
  wa_fieldcat-col_pos = '8'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BMEIN1'.
  wa_fieldcat-seltext_l = 'Base U'.
  wa_fieldcat-seltext_m = 'Base U'.
  wa_fieldcat-col_pos = '9'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'LOSBS'.
  wa_fieldcat-seltext_l = 'TO Lot Size'.
  wa_fieldcat-seltext_m = 'TO Lot Size'.
  wa_fieldcat-col_pos = '9'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'BMEIN2'.
  wa_fieldcat-seltext_l = 'Base U'.
  wa_fieldcat-seltext_m = 'Base Unit'.
  wa_fieldcat-col_pos = '11'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'SANKA'.
  wa_fieldcat-seltext_l = 'Indicator for relevancy to costing'.
  wa_fieldcat-seltext_m = 'Indtr for rlcy to costlg'.
  wa_fieldcat-col_pos = '12'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATNR'.
  wa_fieldcat-seltext_l = 'Material No'.
  wa_fieldcat-seltext_m = 'Material No'.
  wa_fieldcat-col_pos = '13'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MENGE'.
  wa_fieldcat-seltext_l = 'Component Quantity'.
  wa_fieldcat-seltext_m = 'Component Quantity'.
  wa_fieldcat-do_sum    = 'X'.
*  wa_fieldcat-cfieldname    = 'MEINS'. "Comment by Rahul Vasita on 23.11.2023 15:00:52.
  wa_fieldcat-col_pos   = '14'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MEINS'.
  wa_fieldcat-seltext_l = 'Unit of Measure'.
  wa_fieldcat-seltext_m = 'Unit of Measure'.
*  wa_fieldcat-do_sum    = 'X'.
  wa_fieldcat-col_pos   = '15'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATKL'.
  wa_fieldcat-seltext_l = 'Material Group'.
  wa_fieldcat-seltext_m = 'Material Group'.
  wa_fieldcat-col_pos = '16'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MTART'.
  wa_fieldcat-seltext_l = 'Material Type'.
  wa_fieldcat-seltext_m = 'Material Type'.
  wa_fieldcat-col_pos = '17'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'ANDAT'.
  wa_fieldcat-seltext_l = 'Created On'.
  wa_fieldcat-seltext_m = 'Created On'.
  wa_fieldcat-col_pos = '18'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'AEDAT'.
  wa_fieldcat-seltext_l = 'Changed On'.
  wa_fieldcat-seltext_m = 'Changed On'.
  wa_fieldcat-col_pos = '19'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

*  ENDIF.

*  IF c_date IS NOT INITIAL AND s_werks IS NOT INITIAL.
*
*    wa_fieldcat1-fieldname = 'WERKS'.
*    wa_fieldcat1-seltext_l = 'PLANT'.
*    wa_fieldcat1-seltext_m = 'PLANT'.
*    wa_fieldcat1-col_pos = '1'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'STLAL'.
*    wa_fieldcat1-seltext_l = 'Alternative BOM'.
*    wa_fieldcat1-seltext_m = 'Alternative BOM'.
*    wa_fieldcat1-col_pos = '2'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'BMENG'.
*    wa_fieldcat1-seltext_l = 'Base Quantity'.
*    wa_fieldcat1-seltext_m = 'Base Quantity'.
*    wa_fieldcat1-do_sum       = 'X'.
*    wa_fieldcat1-col_pos = '3'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'BMEIN'.
*    wa_fieldcat1-seltext_l = 'Base Unit'.
*    wa_fieldcat1-seltext_m = 'Base Unit'.
*    wa_fieldcat1-col_pos = '4'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'LKENZ'.
*    wa_fieldcat1-seltext_l = 'Deletion Indicator'.
*    wa_fieldcat1-seltext_m = 'Deletion Indicator'.
*    wa_fieldcat1-col_pos = '4'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'STLST'.
*    wa_fieldcat1-seltext_l = 'BOM Status'.
*    wa_fieldcat1-seltext_m = 'BOM Status'.
*    wa_fieldcat1-col_pos = '5'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'IDNRK'.
*    wa_fieldcat1-seltext_l = 'BOM Component'.
*    wa_fieldcat1-seltext_m = 'BOM Component'.
*    wa_fieldcat1-col_pos = '6'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'MAKTX'.
*    wa_fieldcat1-seltext_l = 'Material Description'.
*    wa_fieldcat1-seltext_m = 'Material Description'.
*    wa_fieldcat1-col_pos = '7'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'LOSVN'.
*    wa_fieldcat1-seltext_l = 'From Lot Size'.
*    wa_fieldcat1-seltext_m = 'From Lot Size'.
*    wa_fieldcat1-col_pos = '8'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'BMEIN1'.
*    wa_fieldcat1-seltext_l = 'Base U'.
*    wa_fieldcat1-seltext_m = 'Base U'.
*    wa_fieldcat1-col_pos = '9'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'LOSBS'.
*    wa_fieldcat1-seltext_l = 'TO Lot Size'.
*    wa_fieldcat1-seltext_m = 'TO Lot Size'.
*    wa_fieldcat1-col_pos = '9'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'BMEIN2'.
*    wa_fieldcat1-seltext_l = 'Base U'.
*    wa_fieldcat1-seltext_m = 'Base Unit'.
*    wa_fieldcat1-col_pos = '11'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'SANKA'.
*    wa_fieldcat1-seltext_l = 'Indicator for relevancy to costing'.
*    wa_fieldcat1-seltext_m = 'Indtr for rlcy to costlg'.
*    wa_fieldcat1-col_pos = '12'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'MATNR'.
*    wa_fieldcat1-seltext_l = 'Material No'.
*    wa_fieldcat1-seltext_m = 'Material No'.
*    wa_fieldcat1-col_pos = '13'.
*    APPEND wa_fieldcat TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'MENGE'.
*    wa_fieldcat1-seltext_l = 'Component Quantity'.
*    wa_fieldcat1-seltext_m = 'Component Quantity'.
*    wa_fieldcat1-do_sum    = 'X'.
*    wa_fieldcat1-cfieldname    = 'MEINS'.
*    wa_fieldcat1-col_pos   = '14'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'MEINS'.
*    wa_fieldcat1-seltext_l = 'Unit of Measure'.
*    wa_fieldcat1-seltext_m = 'Unit of Measure'.
*  wa_fieldcat-do_sum    = 'X'.
*    wa_fieldcat1-col_pos   = '15'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
  wa_fieldcat-fieldname = 'MATKL1'.
  wa_fieldcat-seltext_l = 'Finished Material Group'.
  wa_fieldcat-seltext_m = 'Finished Material Group'.
  wa_fieldcat-col_pos = '20'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

  wa_fieldcat-fieldname = 'MATKL2'.
  wa_fieldcat-seltext_l = 'Component Material Group'.
  wa_fieldcat-seltext_m = 'Component Material Group'.
  wa_fieldcat-col_pos = '21'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.




  wa_fieldcat-fieldname = 'MTART1'.
  wa_fieldcat-seltext_l = 'Component Material Type'.
  wa_fieldcat-seltext_m = 'Component Material Type'.
  wa_fieldcat-col_pos = '22'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.


*  **********************Added by Raj on 11.10.2023*****************
  wa_fieldcat-fieldname = 'MAKTXD'.
  wa_fieldcat-seltext_l = 'Material Desc.(M-Code)'.
  wa_fieldcat-seltext_m = 'Material Description'.
  wa_fieldcat-outputlen = '40'.
  wa_fieldcat-col_pos = '23'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.


*********************Added by Raj on 11.10.2023*****************
  "Adding Start by Rahul Vasita on 23.11.2023 15:51:29
  REFRESH : lt_sort[].
  ls_sort-spos      = 1.
  ls_sort-fieldname = 'MATNR'.
  ls_sort-up        = 'X'.
  ls_sort-subtot    = 'X'.
  APPEND ls_sort TO lt_sort.
  "Adding End by Rahul Vasita on 23.11.2023 15:51:29
*
*    wa_fieldcat1-fieldname = 'ANDAT'.
*    wa_fieldcat1-seltext_l = 'Created On'.
*    wa_fieldcat1-seltext_m = 'Created On'.
*    wa_fieldcat1-col_pos = '18'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'AEDAT'.
*    wa_fieldcat1-seltext_l = 'Changed On'.
*    wa_fieldcat1-seltext_m = 'Changed On'.
*    wa_fieldcat1-col_pos = '19'.
*    APPEND wa_fieldcat1 TO gt_fieldcat1.
*    CLEAR wa_fieldcat1.
*
*  ENDIF.


*  if c_date is not INITIAL and s_werks is not INITIAL.
*    wa_fieldcat1-fieldname = 'MATNR'.
*  wa_fieldcat1-seltext_l = 'Material'.
*  wa_fieldcat1-seltext_m = 'Material'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*      wa_fieldcat1-fieldname = 'WERKS'.
*  wa_fieldcat1-seltext_l = 'PLANT'.
*  wa_fieldcat1-seltext_m = 'PLANT'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*     wa_fieldcat1-fieldname = 'STLNR'.
*  wa_fieldcat1-seltext_l = 'BILL OF MATERIAL'.
*  wa_fieldcat1-seltext_m = 'BILL OF MATERIAL'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*      wa_fieldcat1-fieldname = 'STLAL'.
*  wa_fieldcat1-seltext_l = 'ALTERNATIVE BOM'.
*  wa_fieldcat1-seltext_m = 'ALTERNATIVE BOM'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*
*
*
*       wa_fieldcat1-fieldname = 'LOSVN'.
*  wa_fieldcat1-seltext_l = 'FROM LOT SIZE'.
*  wa_fieldcat1-seltext_m = 'FROM LOT SIZE'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*       wa_fieldcat1-fieldname = 'LOSBS'.
*  wa_fieldcat1-seltext_l = 'TO LOT SIZE'.
*  wa_fieldcat1-seltext_m = 'USER'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*       wa_fieldcat1-fieldname = 'ANDAT'.
*  wa_fieldcat1-seltext_l = 'CREATED ON'.
*  wa_fieldcat1-seltext_m = 'CREATED ON'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*    wa_fieldcat1-fieldname = 'AEDAT'.
*  wa_fieldcat1-seltext_l = 'CHANGED ON'.
*  wa_fieldcat1-seltext_m = 'CHANGED ON'.
*  wa_fieldcat1-col_pos = '1'.
*  APPEND wa_fieldcat1 TO gt_fieldcat1.
*  CLEAR wa_fieldcat1.
*
*endif.


  wa_fieldcat-fieldname = 'LGORT'.
  wa_fieldcat-seltext_l = 'Storage Location'.
  wa_fieldcat-seltext_m = 'Storage Location'.
  wa_fieldcat-outputlen = '40'.
  wa_fieldcat-col_pos = '24'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

    wa_fieldcat-fieldname = 'FEVOR'.
  wa_fieldcat-seltext_l = 'Production Supervisor'.
  wa_fieldcat-seltext_m = 'Production Supervisor'.
  wa_fieldcat-outputlen = '40'.
  wa_fieldcat-col_pos = '24'.
  APPEND wa_fieldcat TO gt_fieldcat.
  CLEAR wa_fieldcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .
  IF lt_final IS NOT INITIAL.
*       IF s_matnr IS NOT INITIAL.
*      DELETE lt_final WHERE matnr NE s_matnr-low and stlal ne s_stlal-low.
*    ENDIF.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program = sy-repid
        is_layout          = fs_layout
        it_fieldcat        = gt_fieldcat
        it_sort            = lt_sort "Added by Rahul Vasita on 23.11.2023 15:54:19
        is_variant         = g_variant
        i_save             = 'X'
      TABLES
        t_outtab           = lt_final
      EXCEPTIONS
        program_error      = 1
        OTHERS             = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.


  IF c_date IS NOT INITIAL AND s_werks IS NOT INITIAL.

    IF s_matnr IS NOT INITIAL.
      DELETE lt_final1 WHERE matnr NE s_matnr-low AND stlal NE s_stlal-low.
    ENDIF.
*    ELSEIF s_matnr IS INITIAL.
*      DELETE lt_final1 WHERE stlal NE s_stlal-low.
*    ENDIF.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program = sy-repid
        is_layout          = fs_layout1
        it_fieldcat        = gt_fieldcat
        it_sort            = lt_sort "Added by Rahul Vasita on 23.11.2023 15:54:19
        is_variant         = g_variant1
        i_save             = 'X'
      TABLES
        t_outtab           = lt_final1
      EXCEPTIONS
        program_error      = 1
        OTHERS             = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

  ENDIF.



ENDFORM.

*INCLUDE zmm_bom_report_sub.
*&---------------------------------------------------------------------*
*&      Form  AURHO_OBJECT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM aurho_object .

  SELECT werks FROM t001w INTO TABLE gt_t001w WHERE werks IN s_werks.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'ZWERKS_BOM'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_variant .
  g_variant-variant = variant.
  g_variant-report  = sy-repid.
  CALL FUNCTION 'LVC_VARIANT_EXISTENCE_CHECK' "Check for display variant
    EXPORTING
      i_save        = space            "Variants Can be Saved
    CHANGING
      cs_variant    = g_variant        "Variant information
    EXCEPTIONS
      wrong_input   = 1                "Inconsistent input parameters
      not_found     = 2                "Variant not found
      program_error = 3                "Program Errors
    .                                       "  LVC_VARIANT_EXISTENCE_CHECK
  IF sy-subrc = 2.
    MESSAGE 'Display Variant Not Found, Displaying Default Variant'
                                                              TYPE 'S'.
  ENDIF.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.




*  g_variant1-variant = variant.
*  g_variant1-report  = sy-repid.
*  CALL FUNCTION 'LVC_VARIANT_EXISTENCE_CHECK' "Check for display variant
*    EXPORTING
*      i_save        = space            "Variants Can be Saved
*    CHANGING
*      cs_variant    = g_variant1        "Variant information
*    EXCEPTIONS
*      wrong_input   = 1                "Inconsistent input parameters
*      not_found     = 2                "Variant not found
*      program_error = 3                "Program Errors
*    .                                       "  LVC_VARIANT_EXISTENCE_CHECK
*  IF sy-subrc = 2.
*    MESSAGE 'Display Variant Not Found, Displaying Default Variant'
*                                                              TYPE 'S'.
*  ENDIF.
*  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
*    EXPORTING
*      i_save     = g_save
*    CHANGING
*      cs_variant = gx_variant1
*    EXCEPTIONS
*      not_found  = 2.
*  IF sy-subrc = 0.
*    variant = gx_variant1-variant.
*  ENDIF.



ENDFORM.
