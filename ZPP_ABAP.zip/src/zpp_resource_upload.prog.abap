*&---------------------------------------------------------------------*
*& Report ZPP_RESOURCE_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZPP_RESOURCE_UPLOAD.

INCLUDE zpp_resource_upload_top.
INCLUDE zpp_resource_upload_sel.
INCLUDE zpp_resource_upload_f01.

*-------------------------------------------------------------*
* Initialization
*-------------------------------------------------------------*
INITIALIZATION.
  PERFORM init_screen.

*-------------------------------------------------------------*
* F4 Help for file
*-------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_outfil.
  PERFORM f4_file.

*-------------------------------------------------------------*
* Selection screen commands
*-------------------------------------------------------------*
AT SELECTION-SCREEN.
  PERFORM handle_screen_command.

*-------------------------------------------------------------*
* Main processing
*-------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM upload_file.

  IF it_upload[] IS INITIAL.
    MESSAGE 'No data found in upload file' TYPE 'I'.
    EXIT.
  ENDIF.

  PERFORM process_create_crc1.

END-OF-SELECTION.
  PERFORM display_log.
