*&---------------------------------------------------------------------*
*& Report  ZPP_BMR_CHECKLIST
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Module Pool      : ZPP_BMR_CHECKLIST                            ---*
*&--Package          : ZPP_ABAP                                     ---*
*&--Description      : Module Pool for BMR CheckList                ---*
*&--Transaction Code : ZPP_BMR_CHECKLIST                            ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP )                      ---*
*&--Functional Owner : RISHIKESH PATIL ( VC-ERP )                   ---*
*&--TR No            : DEVK935848                                   ---*
*&---------------------------------------------------------------------*
REPORT zpp_bmr_checklist.

INCLUDE zpp_bmr_checklist_top.
INCLUDE zpp_bmr_checklist_sel.
INCLUDE zpp_bmr_checklist_sub.

START-OF-SELECTION.
  IF p_rb1 = abap_true OR p_rb3 = abap_true.
    PERFORM get_data.
    PERFORM display_data.
  ELSEIF  p_rb2 = abap_true.
    PERFORM get_material.
    PERFORM display_data.
  ELSE.
    PERFORM get_material.
    IF  lt_final[] IS NOT INITIAL.
      DELETE zpp_bmr_list FROM TABLE lt_final.
      MESSAGE 'Material-' && p_sfmat && 'Deleted.' TYPE 'I'.
    ENDIF.
  ENDIF.
