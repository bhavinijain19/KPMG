*&---------------------------------------------------------------------*
*& Report  ZPP_INDP_PANNING_REQ
*&----------------------------------------------------------------------------*
*& Title: Independent Planning Requirement
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Technologies Ltd, Pune
*& Functional Consultant : Sanjay Sahoo, KPIT Technologies Ltd, Pune
*& Report Creation Date  : 04/11/2014
*& Transaction Code      :
*& Request Number        :  DEVK900605
*&----------------------------------------------------------------------------*

REPORT  zpp_conv_md61.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
* TABLES:pbim,pbhi,mdtb.
TABLES:pbim,pbhi,mdtb. "#EC CI_USAGE_OK[2268085]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

DATA:req_item   LIKE  bapisitemr OCCURS 0 WITH HEADER LINE,
     req_param  LIKE  cm60r      OCCURS 0 WITH HEADER LINE,
     do_comt    LIKE  bapisparam-do_commit   VALUE 'X',
     up_mode    LIKE  bapisparam-update_mode VALUE 'X',
     param      TYPE  cm60r,
     mat        LIKE  bapisitemr-material,
     plt        LIKE  bapisitemr-plant,
     reqtype    LIKE  bapisitemr-requ_type,
     vers       LIKE  bapisitemr-version,
     reqplannum LIKE  bapisitemr-req_number,
     vers_act   LIKE  bapisitemr-vers_activ,
     mrp_area   LIKE  bapisitemr-mrp_area.


DATA: req_out      LIKE bapisitmeo OCCURS 0 WITH HEADER LINE,
      req_item_out LIKE bapisitemr OCCURS 0 WITH HEADER LINE.



DATA: BEGIN OF return OCCURS 0.
        INCLUDE STRUCTURE bapiret1.
DATA: END OF return.

DATA: BEGIN OF greq_shd OCCURS 0.
        INCLUDE STRUCTURE bapisshdin.
DATA: END OF greq_shd.

DATA: BEGIN OF greq_chr OCCURS 0.
        INCLUDE STRUCTURE bapischarr.
DATA: END OF greq_chr.

DATA : BEGIN OF t_data OCCURS 0,
         matnr TYPE am60x-matnr,
         werks TYPE am60x-werks,
         versb TYPE rm60x-versb,
       END OF t_data.

DATA: BEGIN OF t_data1 OCCURS 0,
        entlu TYPE rm60e-entlu,
        edatu TYPE rm60e-edatu,
        plmng TYPE rm60e-plnmg,
      END OF t_data1.

DATA: BEGIN OF i_bdzei OCCURS 0,
        bdzei TYPE pbim-bdzei,
      END OF i_bdzei.

DATA: bdzei1 TYPE pbhi-bdzei,
      v_date TYPE datum.
DATA : BEGIN OF t_week OCCURS 0,
         matnr       TYPE am60x-matnr,
         werks       TYPE am60x-werks,
*         versb TYPE rm60x-versb,
*         meins TYPE pbpt-meins,
*         date1 TYPE rm60x-datve,
*         date2 TYPE rm60x-datbe,
*         ENTLU type RM60X-ENTLU,
         plmng1(15)  TYPE c, "rm60x-pln01,
         plmng2(15)  TYPE c, " TYPE rm60x-pln01,
         plmng3(15)  TYPE c, " TYPE rm60x-pln01,
         plmng4(15)  TYPE c, " TYPE rm60x-pln01,
         plmng5(15)  TYPE c, " TYPE rm60x-pln01,
         plmng6(15)  TYPE c, "TYPE rm60x-pln01,
         plmng7(15)  TYPE c, " TYPE rm60x-pln01,
         plmng8(15)  TYPE c, " TYPE rm60x-pln01,
         plmng9(15)  TYPE c, " TYPE rm60x-pln01,
         plmng10(15) TYPE c, " TYPE rm60x-pln01,
         plmng11(15) TYPE c, " TYPE rm60x-pln01,
         plmng12(15) TYPE c, " TYPE rm60x-pln01,
*         plmng13(15) TYPE c," TYPE rm60x-pln01,
*         plmng14(15) TYPE c," TYPE rm60x-pln01,
*         plmng15(15) TYPE c," TYPE rm60x-pln01,
*         plmng16(15) TYPE c," TYPE rm60x-pln01,
*         plmng17(15) TYPE c, "TYPE rm60x-pln01,
*         plmng18(15) TYPE c, "TYPE rm60x-pln01,
*         plmng19(15) TYPE c, "TYPE rm60x-pln01,
*         plmng20(15) TYPE c, "TYPE rm60x-pln01,
*         plmng21(15) TYPE c," TYPE rm60x-pln01,
*         plmng22(15) TYPE c," TYPE rm60x-pln01,
*         plmng23(15) TYPE c," TYPE rm60x-pln01,
*         plmng24(15) TYPE c," TYPE rm60x-pln01,
*         plmng25(15) TYPE c," TYPE rm60x-pln01,
*         plmng26(15) TYPE c," TYPE rm60x-pln01,
*         plmng27(15) TYPE c," TYPE rm60x-pln01,
*         plmng28(15) TYPE c," TYPE rm60x-pln01,
*         plmng29(15) TYPE c," TYPE rm60x-pln01,
*         plmng30(15) TYPE c," TYPE rm60x-pln01,
       END OF t_week.

DATA: BEGIN OF t_success OCCURS 0.
        INCLUDE STRUCTURE t_week.
DATA: END OF t_success.

DATA: BEGIN OF t_errors OCCURS 0.
        INCLUDE STRUCTURE t_week.
DATA: END OF t_errors.

DATA: p_act TYPE c.

DATA: var(2) TYPE c.
DATA:v_var TYPE mhdhb.
FIELD-SYMBOLS: <fs> TYPE any.
DATA : w_count TYPE c LENGTH 2,
       w_recno TYPE c LENGTH 2,
       w_srnum TYPE c LENGTH 2,
       w_item  TYPE c LENGTH 3.

w_count = '1'.
w_srnum = '1'.
w_recno = '1'.
w_item  = '1'.
DATA :  plmng(15) TYPE c,
        bdzei     TYPE pbim-bdzei,
        plnmg     TYPE pbed-plnmg,
        index(4)  TYPE c.

index = 1.

PARAMETERS: filename LIKE rlgrap-filename.
PARAMETERS: p_versb  TYPE rm60x-versb.
*PARAMETERS: p_versb  TYPE mdtb-versb.
CONSTANTS : c_a(1) TYPE c VALUE '2',
            c_b(1) TYPE c VALUE '3',
            c_c(1) TYPE c VALUE '1'.



AT SELECTION-SCREEN ON VALUE-REQUEST FOR filename.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
    IMPORTING
      file_name     = filename.


START-OF-SELECTION.
  PERFORM week_get_data.
  CLEAR t_week.
  LOOP AT t_week FROM w_item.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = t_week-matnr
      IMPORTING
        output = t_week-matnr.

    req_item-material   = t_week-matnr.
    req_item-plant      = t_week-werks.
    req_item-requ_type  = 'LSF'.
    req_item-version    = p_versb.
    req_item-req_number = ''.
    IF p_versb EQ '00'.
      p_act = 'X'.
      req_item-vers_activ = p_act.
    ELSE.
      p_act = ' '.
      req_item-vers_activ = p_act.
    ENDIF.
    APPEND req_item.
    PERFORM f_greq_shd.
*    IF t_week-plmng29 IS INITIAL.
*      IF t_week-plmng28 IS INITIAL.
*        PERFORM greq_shd.
*      ELSE.
*        PERFORM greq_shd1.
*      ENDIF.
*    ELSE.
*      PERFORM greq_shd2.
*    ENDIF.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = t_week-matnr
      IMPORTING
        output = t_week-matnr.

    SELECT SINGLE bdzei FROM pbim INTO bdzei
                           WHERE matnr = t_week-matnr
                             AND bedae = 'LSF'
                             AND versb = p_versb.

    IF sy-subrc <> 0.
      param-status  = 'X'.
      param-trtyp   = 'X'.
      param-delkz   = space.
      param-syncron = 'X'.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
      CALL FUNCTION 'BAPI_REQUIREMENTS_CREATE'"#EC CI_USAGE_OK[2438131]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
        EXPORTING
          requirements_item        = req_item
          requirement_param        = param
*         do_commit                = 'X'
*         update_mode              = 'X'
        IMPORTING
          material                 = mat
          plant                    = plt
          requirementstype         = reqtype
          version                  = vers
          reqmtsplannumber         = reqplannum
          mrp_area                 = mrp_area
        TABLES
          requirements_schedule_in = greq_shd
          return                   = return.

      .

      IF return IS NOT INITIAL.
        MOVE t_week TO t_errors.
        APPEND t_errors.
        FORMAT COLOR COL_NEGATIVE INTENSIFIED OFF.
        WRITE:/01 sy-vline,
               02 index,
               06 sy-vline,
               07 return-message_v1,
               27 sy-vline,
               28 'Not Created',
               69 sy-vline.
        WRITE:/ sy-uline(69).
      ELSE.
        FORMAT COLOR COL_HEADING INTENSIFIED OFF.
        WRITE:/01 sy-vline,
               02 index,
               06 sy-vline,
               07 req_item-material,
               27 sy-vline,
               28 'Created',
               69 sy-vline.
        WRITE:/ sy-uline(69).
      ENDIF.
      CLEAR req_item_out.
      CLEAR greq_shd.
      REFRESH greq_shd.
    ELSE.
      param-status  = 'X'.
      param-trtyp   = 'X'.
      param-delkz   = space.
      param-syncron = 'X'.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
      CALL FUNCTION 'BAPI_REQUIREMENTS_CHANGE'"#EC CI_USAGE_OK[2438131]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
        EXPORTING
          material                 = req_item-material
          plant                    = req_item-plant
          requirementstype         = req_item-requ_type
          version                  = req_item-version
          reqmtsplannumber         = req_item-req_number
          vers_activ               = p_act
          requirement_param        = param
*         mrp_area                 = req_item-mrp_area
*         do_commit                = 'X'
*         update_mode              = 'X'
*         delete_old               = ''"'X'
*         no_withdr                = ' '
        IMPORTING
          requirement_item_out     = req_item_out
        TABLES
          requirements_schedule_in = greq_shd
          return                   = return.

      IF return IS NOT INITIAL.
        MOVE t_week TO t_errors.
        APPEND t_errors.
        FORMAT COLOR COL_NEGATIVE INTENSIFIED OFF.
        WRITE:/01 sy-vline,
               02 index,
               06 sy-vline,
               07 return-message_v1,
               27 sy-vline,
               28 'Not Created',
               69 sy-vline.
        WRITE:/ sy-uline(69).
      ELSE.
        FORMAT COLOR COL_HEADING INTENSIFIED OFF.
        WRITE:/01 sy-vline,
               02 index,
               06 sy-vline,
               07 req_item-material,
               27 sy-vline,
               28 'Created',
               69 sy-vline.
        WRITE:/ sy-uline(69).
      ENDIF.
      CLEAR req_item_out.
      CLEAR greq_shd.
      REFRESH greq_shd.
    ENDIF.
    w_item = w_item + 1.
    index = index + 1.
  ENDLOOP.

  PERFORM errors_download.
*&---------------------------------------------------------------------*
*&      Form  week_get_data
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM week_get_data.
  DATA: p_file TYPE rlgrap-filename.
  DATA: filename1 TYPE string,
        it_type   TYPE truxs_t_text_data.
  MOVE: filename TO filename1.
  p_file = filename1.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*       i_tab_converted_data = t_week
      i_tab_converted_data = t_week "#EC CI_FLDEXT_OK[2215424]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

*  CALL FUNCTION 'GUI_UPLOAD'
*    EXPORTING
*      filename            = filename1
*      filetype            = 'DAT'
*      has_field_separator = 'X'
*    TABLES
*      data_tab            = t_week.
*
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*             WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*  ENDIF.
ENDFORM.                    "week_get_data
*&---------------------------------------------------------------------*
*&      Form  greq_shd
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM greq_shd .

  DO 12 TIMES.
    var = sy-index.
    CONCATENATE 't_week-plmng' var INTO plmng.
    ASSIGN (plmng) TO <fs>.
    READ TABLE t_week INDEX w_srnum.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <fs>
      IMPORTING
        output = <fs>.


    IF <fs> = 'W'.
      <fs> = c_a.
    ELSEIF <fs> = 'M'.
      <fs> = c_b.
    ELSEIF <fs> = 'D'.
      <fs> = c_c.
    ENDIF.
    greq_shd-date_type = '2'."<fs>.
    READ TABLE t_week INDEX w_recno.
    v_date = sy-datum.
    greq_shd-req_date = v_date."<fs>.
    READ TABLE t_week INDEX w_item.
    greq_shd-req_qty = <fs>.
*    greq_shd-unit = 'EA'.
    APPEND greq_shd.
    DELETE greq_shd WHERE req_qty IS INITIAL.
  ENDDO.
ENDFORM.                    " greq_shd
*&---------------------------------------------------------------------*
*&      Form  greq_shd1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM greq_shd1 .
  DO 28 TIMES.
    var = sy-index.
    CONCATENATE 't_week-plmng' var INTO plmng.
    ASSIGN (plmng) TO <fs>.
    READ TABLE t_week INDEX w_srnum.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <fs>
      IMPORTING
        output = <fs>.
    IF <fs> = 'W'.
      <fs> = c_a.
    ELSEIF <fs> = 'M'.
      <fs> = c_b.
    ELSEIF <fs> = 'D'.
      <fs> = c_c.
    ENDIF.
    greq_shd-date_type = '2'."<fs>.
    READ TABLE t_week INDEX w_recno.
    v_date = sy-datum.
    greq_shd-req_date = v_date."<fs>.
    READ TABLE t_week INDEX w_item.
    greq_shd-req_qty = <fs>.
*    greq_shd-date_type = <fs>.
*
*    READ TABLE t_week INDEX w_recno.
*
*    greq_shd-req_date = <fs>.
*
*    READ TABLE t_week INDEX w_item.
*
*    greq_shd-req_qty = <fs>.
*
*    greq_shd-unit = 'EA'.
    APPEND greq_shd.
  ENDDO.
ENDFORM.                    " greq_shd1
*&---------------------------------------------------------------------*
*&      Form  greq_shd2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM greq_shd2 .
  DO 29 TIMES.
    var = sy-index.
    CONCATENATE 't_week-plmng' var INTO plmng.
    ASSIGN (plmng) TO <fs>.
    READ TABLE t_week INDEX w_srnum.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <fs>
      IMPORTING
        output = <fs>.
    IF <fs> = 'W'.
      <fs> = c_a.
    ELSEIF <fs> = 'M'.
      <fs> = c_b.
    ELSEIF <fs> = 'D'.
      <fs> = c_c.
    ENDIF.
    greq_shd-date_type = '2'."<fs>.
    READ TABLE t_week INDEX w_recno.
    v_date = sy-datum.
    greq_shd-req_date = v_date."<fs>.
    READ TABLE t_week INDEX w_item.
    greq_shd-req_qty = <fs>.
    APPEND greq_shd.
  ENDDO.
ENDFORM.                    " greq_shd2


TOP-OF-PAGE.
  FORMAT COLOR COL_HEADING INTENSIFIED ON.
  WRITE:/01 sy-vline,
         02 'SNo.',
         06 sy-vline,
         07 'Material' ,
         27 sy-vline,
         28 'Status',
         69 sy-vline.
  WRITE:/ sy-uline(69).
*&---------------------------------------------------------------------*
*&      Form  errors_download
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM errors_download .
  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename              = 'C:\Users\Public\Downloads\bapipir.xls'
      filetype              = 'ASC'
      write_field_separator = 'X'
    TABLES
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*       data_tab              = t_errors.
      data_tab              = t_errors. "#EC CI_FLDEXT_OK[2215424]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
  IF t_errors IS NOT INITIAL.
    MESSAGE 'ERROR FILE IS DOWNLOADED AT C:\Users\Public\Downloads WITH NAME BAPIPIR.XLS' TYPE 'I'.
  ENDIF.
ENDFORM.                    " errors_download
*&---------------------------------------------------------------------*
*&      Form  F_GREQ_SHD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_greq_shd .
  DO 12 TIMES.
    var = sy-index.
    CONCATENATE 't_week-plmng' var INTO plmng.
    ASSIGN (plmng) TO <fs>.
    READ TABLE t_week INDEX w_srnum.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <fs>
      IMPORTING
        output = <fs>.

*    IF <fs> = 'W'.
*      <fs> = c_a.
*    ELSEIF <fs> = 'M'.
*      <fs> = c_b.
*    ELSEIF <fs> = 'D'.
*      <fs> = c_c.
*    ENDIF.
    IF var EQ 1.
      v_date = sy-datum.
      CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
        EXPORTING
          iv_date             = v_date
        IMPORTING
          ev_month_begin_date = v_date
*         EV_MONTH_END_DATE   =
        .
    ELSE.
      v_date = sy-datum.
      v_var = var - 1.
      CALL FUNCTION 'HR_JP_MONTH_BEGIN_END_DATE'
        EXPORTING
          iv_date             = v_date
        IMPORTING
          ev_month_begin_date = v_date
*         EV_MONTH_END_DATE   =
        .
      CALL FUNCTION 'ADD_TIME_TO_DATE'
        EXPORTING
          i_idate = v_date
          i_time  = v_var
          i_iprkz = '2'
*         I_RDMHD =
        IMPORTING
          o_idate = v_date
*     EXCEPTIONS
*         INVALID_PERIOD              = 1
*         INVALID_ROUND_UP_RULE       = 2
*         INTERNAL_ERROR              = 3
*         OTHERS  = 4
        .
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    ENDIF.


    greq_shd-date_type = '3'."<fs>.
    READ TABLE t_week INDEX w_recno.
*    v_date = sy-datum.
    greq_shd-req_date = v_date."<fs>.
    READ TABLE t_week INDEX w_item.
    greq_shd-req_qty = <fs>.
*    greq_shd-unit = 'EA'.
    APPEND greq_shd.
    DELETE greq_shd WHERE req_qty IS INITIAL.
    CLEAR : v_date.
  ENDDO.
ENDFORM.                    " F_GREQ_SHD
