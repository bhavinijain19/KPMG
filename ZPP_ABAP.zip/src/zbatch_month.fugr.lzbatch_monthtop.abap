FUNCTION-POOL ZBATCH_MONTH               MESSAGE-ID SV.

* INCLUDE LZBATCH_MONTHD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBATCH_MONTHT00                        . "view rel. data dcl.
