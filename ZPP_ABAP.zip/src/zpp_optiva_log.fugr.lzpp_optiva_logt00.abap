*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_OPTIVA_LOG..................................*
DATA:  BEGIN OF STATUS_ZPP_OPTIVA_LOG                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_OPTIVA_LOG                .
CONTROLS: TCTRL_ZPP_OPTIVA_LOG
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZPP_OPTIVA_LOG                .
TABLES: ZPP_OPTIVA_LOG                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
