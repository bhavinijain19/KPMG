*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_MACHINE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_MACHINE         .

  PERFORM TABLEPROC.

ENDFUNCTION.
