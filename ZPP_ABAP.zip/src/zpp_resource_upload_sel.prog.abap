*&---------------------------------------------------------------------*
*& Include          ZPP_RESOURCE_UPLOAD_SEL
*&---------------------------------------------------------------------*


SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS: p_create RADIOBUTTON GROUP rb DEFAULT 'X' USER-COMMAND disp,
            p_change RADIOBUTTON GROUP rb .
PARAMETERS: p_outfil TYPE rlgrap-filename.
PARAMETERS: p_mode   TYPE c DEFAULT 'A'.   "A=Foreground, N=Background
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN PUSHBUTTON /1(30) pb_tmpl USER-COMMAND tmpl.

*TEXT-001 = 'Resource Upload (CRC1 / CRC2)'.
