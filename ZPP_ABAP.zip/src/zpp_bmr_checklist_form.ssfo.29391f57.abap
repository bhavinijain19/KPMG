
CLEAR: lv_q1.
IF ls_checklist-std_qty IS NOT INITIAL.
*  BREAK-POINT.
  lv_q1 = ls_checklist-std_qty.
  CONDENSE lv_q1.
ENDIF.



















