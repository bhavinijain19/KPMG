FUNCTION zwm_fm_su_gen_new.
**"----------------------------------------------------------------------
**"*"Local Interface:
**"  IMPORTING
**"     VALUE(EVENT) TYPE  SWETYPECOU-EVENT OPTIONAL
**"     VALUE(RECTYPE) TYPE  SWETYPECOU-RECTYPE OPTIONAL
**"     VALUE(OBJTYPE) TYPE  SWETYPECOU-OBJTYPE OPTIONAL
**"     VALUE(OBJKEY) TYPE  SWEINSTCOU-OBJKEY OPTIONAL
**"     VALUE(EXCEPTIONS_ALLOWED) TYPE  SWEFLAGS-EXC_OK DEFAULT 'X'
**"  EXPORTING
**"     VALUE(REC_ID) TYPE  SWELOG-RECID
**"  TABLES
**"      EVENT_CONTAINER STRUCTURE  SWCONT OPTIONAL
**"      STATUS STRUCTURE  BSVOBJSTA
**"      EVENTS STRUCTURE  BSVEVENT
**"  EXCEPTIONS
**"      INVALID_TYPE
**"      UPDATE_FAILED
**"      TEMP_ERROR
**"----------------------------------------------------------------------
*
*
**--> Local data declaration
*  DATA:lv_aufpl    TYPE co_aufpl,
*       lv_tanum    TYPE ltak-tanum,
*       lv_aufnr    TYPE ltak-benum,
*       lv_suqty    TYPE lvs_lhmng1,
*       lv_suunit   TYPE lvs_letyp1,
*       lv_nos_su   TYPE n LENGTH 3,
*       lv_last_su  TYPE lvs_lhmng1,
*       ls_zwm_su   TYPE zwm_su,
*       lt_ltap_c   TYPE STANDARD TABLE OF ltap_creat,
*       lt_ltap_can TYPE STANDARD TABLE OF ltap_cancl,
*       ls_ltap_c   TYPE ltap_creat,
*       ls_ltap_can TYPE ltap_cancl,
*       lt_zwm_su   TYPE STANDARD TABLE OF zwm_su,
*       lv_cnt      TYPE i.
*
*  lv_aufpl = objkey+0(10).
*
*  FIELD-SYMBOLS: <ls_caufvd> TYPE caufvd, " Ensure the type matches the source structure
*                 <fs_afpod>  TYPE afpod.
*
*  DATA: lv_prog_caufvd TYPE string,
*        lv_prog_afpod  TYPE string.
*
*  " Construct the dynamic access string: '(PROGRAM_NAME)VARIABLE_NAME'
*  lv_prog_caufvd = '(SAPLCOZV)CAUFVD'.
*  lv_prog_afpod = '(SAPLCOZV)AFPOD'.
*  ASSIGN (lv_prog_caufvd) TO <ls_caufvd>.
*  IF <ls_caufvd> IS ASSIGNED.
*    DATA(ls_caufvd) = <ls_caufvd>.
*
*    ASSIGN (lv_prog_afpod) TO <fs_afpod>.
*    IF <fs_afpod> IS ASSIGNED.
*      DATA(ls_afpod) = <fs_afpod>.
*
**  SELECT aufnr ,
**   gamng , gmein , plnbez , aufpl FROM afko INTO @DATA(ls_caufvd) UP TO 1 ROWS WHERE aufpl EQ @lv_aufpl
**   ORDER BY PRIMARY KEY .
**  ENDSELECT.
*** End of Quick Fix
**
**  IF sy-subrc IS NOT INITIAL.
**    EXIT.
**  ENDIF.
*
**  IF status[] IS NOT INITIAL.
**    READ TABLE status ASSIGNING FIELD-SYMBOL(<fs_status>)
**    WITH KEY obtyp = 'ORB'.
**    lv_aufnr = <fs_status>-objnr+2(12).
**  ENDIF.
**
**  IF sy-subrc IS NOT INITIAL.
**    EXIT.
**  ENDIF.
*
*      SELECT SINGLE * FROM tvarvc INTO @DATA(ls_tvarvc)
*        WHERE name EQ 'ZCO11N_MATERIALNO' AND low EQ @ls_caufvd-plnbez.
*      IF sy-subrc IS INITIAL.
*        EXIT.
*      ENDIF.
*
*      SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @ls_caufvd-plnbez.
*      SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
*      IF sy-subrc IS NOT INITIAL.
*        EXIT.
*      ENDIF.
*
*      SELECT * FROM zwm_su INTO TABLE @DATA(it_zwm_su) WHERE aufnr EQ @ls_caufvd-aufnr.
*      IF it_zwm_su IS NOT INITIAL.
*        EXIT.
*      ENDIF.
*
**  SELECT SINGLE aufnr,
**                auart,
**                werks
**           FROM aufk
**           INTO @DATA(ls_aufk)
**           WHERE aufnr EQ @ls_caufvd-aufnr.
**  IF sy-subrc IS INITIAL.
*      SELECT SINGLE * FROM zwm_config INTO @DATA(ls_zwm_config)
*        WHERE werks EQ @ls_caufvd-werks
*          AND auart  EQ @ls_caufvd-auart.
*      IF sy-subrc IS NOT INITIAL.
*        EXIT.
*      ENDIF.
**  ENDIF.
*
**  SELECT SINGLE ernam FROM aufk INTO @DATA(lv_ernam) WHERE aufnr EQ @ls_caufvd-aufnr.
*      DATA(lv_ernam) = ls_caufvd-ernam.
*
** Quick Fix Replace this statement by a SELECT statement with ORDER BY
** Transport DEVK900442 ECC to S4 Hana Migration
** Replaced Code:
**  SELECT SINGLE aufnr,
**                posnr,
**                pwerk,
**                lgort,
**                charg
**           FROM afpo
**           INTO @DATA(ls_afpo)
**           WHERE aufnr EQ @ls_caufvd-aufnr.
*
*      SELECT aufnr ,
*       posnr , pwerk , lgort , charg FROM afpo INTO @DATA(ls_afpo) UP TO 1 ROWS WHERE aufnr EQ @ls_caufvd-aufnr
*       ORDER BY PRIMARY KEY .
*      ENDSELECT.
** End of Quick Fix
*      ls_afpo-posnr = ls_caufvd-posnr.
*      ls_afpo-pwerk = ls_afpod-pwerk.
*      ls_afpo-lgort = ls_afpod-lgort.
**      ls_afpo-charg = ls_afpod-charg.
*
*
*      SELECT SINGLE matnr, lgnum, lhmg1, lhmg2, lhmg3, lhme1, lhme2,
*                    lhme3, lety1, lety2, lety3
*               FROM mlgn
*               INTO @DATA(ls_mlgn)
*               WHERE matnr EQ @ls_caufvd-plnbez
*                 AND lgnum EQ @ls_zwm_config-lgnum.
*
*      SELECT SINGLE * FROM t333 INTO @DATA(ls_t333)
*         WHERE lgnum EQ @ls_zwm_config-lgnum
*           AND bwlvs EQ @ls_zwm_config-bwlvs.
*
*
** Quick Fix Replace this statement by a SELECT statement with ORDER BY
** Transport DEVK900442 ECC to S4 Hana Migration
** Replaced Code:
**  SELECT SINGLE * FROM t302
**    INTO @DATA(ls_t302)
**     WHERE lgnum EQ @ls_zwm_config-lgnum
**       AND lgtyp EQ @ls_t333-vltyp.
*
*      SELECT * FROM t302
*       INTO @DATA(ls_t302) UP TO 1 ROWS WHERE lgnum EQ @ls_zwm_config-lgnum AND lgtyp EQ @ls_t333-vltyp
*       ORDER BY PRIMARY KEY .
*      ENDSELECT.
** End of Quick Fix
*
*
*      lv_aufnr = ls_caufvd-aufnr.
*      IF ls_mlgn-lhme1 = ls_caufvd-gmein.
*        lv_suqty  = ls_mlgn-lhmg1.
*        lv_suunit = ls_mlgn-lety1.
*      ELSEIF ls_mlgn-lhme2 = ls_caufvd-gmein.
*        lv_suqty  = ls_mlgn-lhmg2.
*        lv_suunit = ls_mlgn-lety2.
*      ELSEIF ls_mlgn-lhme3 = ls_caufvd-gmein.
*        lv_suqty  = ls_mlgn-lhmg3.
*        lv_suunit = ls_mlgn-lety3.
*      ENDIF.
*
*      IF lv_suqty IS NOT INITIAL.
*        lv_last_su = ls_caufvd-gamng MOD lv_suqty.
*        lv_nos_su  = ( ls_caufvd-gamng - lv_last_su ) / lv_suqty.
*      ENDIF.
*
*      DO lv_nos_su TIMES.
*        ls_ltap_c-matnr = ls_caufvd-plnbez.
*        ls_ltap_c-charg = ls_afpo-charg.
*        ls_ltap_c-werks = ls_afpo-pwerk.
*        ls_ltap_c-lgort = ls_zwm_config-lgort.
*        ls_ltap_c-anfme = lv_suqty.
*        ls_ltap_c-altme = ls_caufvd-gmein.
*        ls_ltap_c-vltyp = ls_t333-vltyp. " Source storage type
*        ls_ltap_c-vlber = ls_t302-lgber. " Source Storage Section
*        ls_ltap_c-vlpla = lv_aufnr.
*        ls_ltap_c-nltyp = ls_t333-nltyp. " Destination Storage Type
*        ls_ltap_c-nlber = '001'.         " Destination Storage Section
*        ls_ltap_c-letyp = lv_suunit.
*        APPEND ls_ltap_c TO lt_ltap_c.
*        CLEAR:ls_ltap_c.
*      ENDDO.
*
*      IF lv_last_su IS NOT INITIAL.
*        ls_ltap_c-matnr = ls_caufvd-plnbez.
*        ls_ltap_c-charg = ls_afpo-charg.
*        ls_ltap_c-werks = ls_afpo-pwerk.
*        ls_ltap_c-lgort = ls_zwm_config-lgort.
*        ls_ltap_c-anfme = lv_last_su.
*        ls_ltap_c-altme = ls_caufvd-gmein.
*        ls_ltap_c-vltyp = ls_t333-vltyp. " Source storage type
*        ls_ltap_c-vlber = ls_t302-lgber. " Source Storage Section
*        ls_ltap_c-vlpla = lv_aufnr.
*        ls_ltap_c-nltyp = ls_t333-nltyp. " Destination Storage Type
*        ls_ltap_c-nlber = '001'.         " Destination Storage Section
*        ls_ltap_c-letyp = lv_suunit.
*        APPEND ls_ltap_c TO lt_ltap_c.
*        CLEAR:ls_ltap_c.
*      ENDIF.
*
*
*      IF lt_ltap_c IS INITIAL.
*        EXIT.
*      ENDIF.
*
*      DATA:lv_user TYPE sy-uname.
*      lv_user = lv_ernam.
*
*      CALL FUNCTION 'L_TO_CREATE_MULTIPLE'
*        EXPORTING
*          i_lgnum                = ls_zwm_config-lgnum
*          i_bwlvs                = ls_t333-bwlvs
*          i_betyp                = ls_t333-betyp
*          i_benum                = lv_aufnr
*          i_commit_work          = abap_true
*          i_bname                = lv_user
*          i_kompl                = abap_true
*        IMPORTING
*          e_tanum                = lv_tanum
*        TABLES
*          t_ltap_creat           = lt_ltap_c
*        EXCEPTIONS
*          no_to_created          = 1
*          bwlvs_wrong            = 2
*          betyp_wrong            = 3
*          benum_missing          = 4
*          betyp_missing          = 5
*          foreign_lock           = 6
*          vltyp_wrong            = 7
*          vlpla_wrong            = 8
*          vltyp_missing          = 9
*          nltyp_wrong            = 10
*          nlpla_wrong            = 11
*          nltyp_missing          = 12
*          rltyp_wrong            = 13
*          rlpla_wrong            = 14
*          rltyp_missing          = 15
*          squit_forbidden        = 16
*          manual_to_forbidden    = 17
*          letyp_wrong            = 18
*          vlpla_missing          = 19
*          nlpla_missing          = 20
*          sobkz_wrong            = 21
*          sobkz_missing          = 22
*          sonum_missing          = 23
*          bestq_wrong            = 24
*          lgber_wrong            = 25
*          xfeld_wrong            = 26
*          date_wrong             = 27
*          drukz_wrong            = 28
*          ldest_wrong            = 29
*          update_without_commit  = 30
*          no_authority           = 31
*          material_not_found     = 32
*          lenum_wrong            = 33
*          matnr_missing          = 34
*          werks_missing          = 35
*          anfme_missing          = 36
*          altme_missing          = 37
*          lgort_wrong_or_missing = 38
*          OTHERS                 = 39.
*      IF sy-subrc EQ 0.
*
** Quick Fix Replace this statement by a SELECT statement with ORDER BY
** Transport DEVK900442 ECC to S4 Hana Migration
** Replaced Code:
**    SELECT SINGLE lgnum,
**                  tanum,
**                  bdatu,
**                  bzeit,
**                  bname
**             FROM ltak
**             INTO @DATA(ls_ltak)
**             WHERE tanum EQ @lv_tanum.
*
*        SELECT lgnum ,
*         tanum , bdatu , bzeit , bname FROM ltak INTO @DATA(ls_ltak) UP TO 1 ROWS WHERE tanum EQ @lv_tanum
*         ORDER BY PRIMARY KEY .
*        ENDSELECT.
** End of Quick Fix
*
*        IF sy-subrc IS INITIAL.
*          SELECT lgnum,
*                 tanum,
*                 tapos,
*                 matnr,
*                 werks,
*                 charg,
*                 meins,
*                 vsolm,
*                 nlenr
*            FROM ltap
*            INTO TABLE @DATA(lt_ltap)
*            WHERE tanum EQ @lv_tanum.
*        ENDIF.
*      ENDIF.
*
*      LOOP AT lt_ltap INTO DATA(ls_ltap).
*        ls_zwm_su-aufnr   = ls_caufvd-aufnr.
*        ls_zwm_su-lenum   = ls_ltap-nlenr.
*        ls_zwm_su-tanum   = ls_ltap-tanum.
*        ls_zwm_su-lgnum   = ls_ltap-lgnum.
**    ls_zwm_su-auart   = ls_aufk-auart.
*        ls_zwm_su-matnr   = ls_ltap-matnr.
*        ls_zwm_su-werks   = ls_ltap-werks.
*        ls_zwm_su-charg   = ls_ltap-charg.
*        ls_zwm_su-su_qty  = ls_ltap-vsolm.
*        ls_zwm_su-meins   = ls_ltap-meins.
*        ls_zwm_su-su_unit = lv_suunit.
*        ls_zwm_su-bdatu   = ls_ltak-bdatu.
*        ls_zwm_su-bzeit   = ls_ltak-bzeit.
*        ls_zwm_su-bname   = lv_ernam.
*        lv_cnt            = lv_cnt + 1.
*        ls_zwm_su-su_cnt  = lv_cnt.
*        APPEND ls_zwm_su TO lt_zwm_su.
*        CLEAR:ls_zwm_su.
*      ENDLOOP.
*
*      IF lt_zwm_su IS NOT INITIAL.
*        MODIFY zwm_su FROM TABLE lt_zwm_su.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
ENDFUNCTION.
