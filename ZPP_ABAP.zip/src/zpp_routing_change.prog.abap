*&----------------------------------------------------------------------------*
*& Report  ZPP_ROUTING_CHANGE
*&----------------------------------------------------------------------------*
*& Title: Routing Master Change
*&----------------------------------------------------------------------------*
*& Report Author         :
*& Functional Consultant :
*& Report Creation Date  : 23/12/2025
*& Transaction Code      :
*& Request Number        :
*&----------------------------------------------------------------------------*

REPORT zpp_routing_change NO STANDARD PAGE HEADING LINE-SIZE 255.
* include bdcrecx1.

TYPES : BEGIN OF st_upload,
          matnr     TYPE  rc27m-matnr,
          werks     TYPE  rc27m-werks,
          plnnr     TYPE rc271-plnnr,
          sttag(10),
          revlv(02),
          plnme(03),        "unit
          vornr     TYPE  rcm01-vornr,
          arbpl     TYPE  plpod-arbpl,
          steus     TYPE  plpod-steus,
          ltxa1     TYPE  plpod-ltxa1,
          bmsch(16),  "TYPE plpod-bmsch,
          meinh(03),        "Baseunit
          umren(4),    "TYPE  plpod-umren,
          vgw01(09),  " TYPE plpod-vgw01,
          vge01(03),  " Unit
          vgw02(09),  "TYPE plpod-vgw02,
          vge02(03),  " Unit
          vgw03(09),  "TYPE plpod-vgw03,
          vge03(03),  " Unit
          vgw04(09),  "TYPE plpod-vgw04,
          vge04(03),  " Unit
          vgw05(09),  "TYPE plpod-vgw04,
          vge05(03),  " Unit
          vgw06(09),  "TYPE plpod-vgw04,
          vge06(03),  " Unit
          equnr(18),  "Equipment No
          ewvgw(13),  "Usage Value
          eweinh(3),  "Unit
          steuf(4),   "Country Key
          ktext(40),  "Text  "Added by Raj on 18.10.2024
*              num(003) TYPE n,
***              posnr1       TYPE stpo-posnr,
***              posnr2       TYPE stpo-posnr,
***              posnr3       TYPE stpo-posnr,
***              posnr4       TYPE stpo-posnr,
***              posnr5       TYPE stpo-posnr,
***              posnr6       TYPE stpo-posnr,
***              posnr7       TYPE stpo-posnr,
***              posnr8       TYPE stpo-posnr,
***              posnr9       TYPE stpo-posnr,
***              posnr10      TYPE stpo-posnr,
***              posnr11      TYPE stpo-posnr,
***              posnr12      TYPE stpo-posnr,
***              posnr13      TYPE stpo-posnr,
***              posnr14      TYPE stpo-posnr,
***              posnr15      TYPE stpo-posnr,
***              posnr16      TYPE stpo-posnr,
***              posnr17      TYPE stpo-posnr,
***              posnr18      TYPE stpo-posnr,
***              posnr19      TYPE stpo-posnr,
***              posnr20      TYPE stpo-posnr,
***              verwmerkm1   TYPE plmkb-verwmerkm,
***              stichprver1  TYPE plmkb-stichprver,
***              verwmerkm2   TYPE plmkb-verwmerkm,
***              stichprver2  TYPE plmkb-stichprver,
***              verwmerkm3   TYPE plmkb-verwmerkm,
***              stichprver3  TYPE plmkb-stichprver,
***              verwmerkm4   TYPE plmkb-verwmerkm,
***              stichprver4  TYPE plmkb-stichprver,
***              verwmerkm5   TYPE plmkb-verwmerkm,
***              stichprver5  TYPE plmkb-stichprver,
***              verwmerkm6   TYPE plmkb-verwmerkm,
***              stichprver6  TYPE plmkb-stichprver,
***              verwmerkm7   TYPE plmkb-verwmerkm,
***              stichprver7  TYPE plmkb-stichprver,
***              verwmerkm8   TYPE plmkb-verwmerkm,
***              stichprver8  TYPE plmkb-stichprver,
***              verwmerkm9   TYPE plmkb-verwmerkm,
***              stichprver9  TYPE plmkb-stichprver,
***              verwmerkm10  TYPE plmkb-verwmerkm,
***              stichprver10 TYPE plmkb-stichprver,
***              verwmerkm11  TYPE plmkb-verwmerkm,
***              stichprver11 TYPE plmkb-stichprver,
***              verwmerkm12  TYPE plmkb-verwmerkm,
***              stichprver12 TYPE plmkb-stichprver,
***              verwmerkm13  TYPE plmkb-verwmerkm,
***              stichprver13 TYPE plmkb-stichprver,
***              verwmerkm14  TYPE plmkb-verwmerkm,
***              stichprver14 TYPE plmkb-stichprver,
***              verwmerkm15  TYPE plmkb-verwmerkm,
***              stichprver15 TYPE plmkb-stichprver,
***              verwmerkm16  TYPE plmkb-verwmerkm,
***              stichprver16 TYPE plmkb-stichprver,
***              verwmerkm17  TYPE plmkb-verwmerkm,
***              stichprver17 TYPE plmkb-stichprver,
***              verwmerkm18  TYPE plmkb-verwmerkm,
***              stichprver18 TYPE plmkb-stichprver,
***              verwmerkm19  TYPE plmkb-verwmerkm,
***              stichprver19 TYPE plmkb-stichprver,
***              verwmerkm20  TYPE plmkb-verwmerkm,
***              stichprver20 TYPE plmkb-stichprver,
        END OF st_upload.

TYPES : BEGIN OF st_header,
          matnr     TYPE  rc27m-matnr,
          werks     TYPE  rc27m-werks,
          sttag(10),
          revlv(02),
          plnme(03),
          plnal(02),  "Group Counter
          num(003)  TYPE n,
        END OF st_header.


TYPES : BEGIN OF st_item,
          matnr     TYPE  rc27m-matnr,
          vornr     TYPE  rcm01-vornr,
          arbpl     TYPE  plpod-arbpl,
          steus     TYPE  plpod-steus,
          ltxa1     TYPE  plpod-ltxa1,
          bmsch(16),  "TYPE plpod-bmsch,
          meinh(03),        "Baseunit
          umren(4),	"TYPE	plpod-umren,
          vgw01(09),  " TYPE plpod-vgw01,
          vge01(03),  " Unit
          vgw02(09),  "TYPE plpod-vgw02,
          vge02(03),  " Unit
          vgw03(09),  "TYPE plpod-vgw03,
          vge03(03),  " Unit
          vgw04(09),  "TYPE plpod-vgw04,
          vge04(03),  " Unit
          vgw05(09),  "TYPE plpod-vgw04,
          vge05(03),  " Unit
          vgw06(09),  "TYPE plpod-vgw04,
          vge06(03),  " Unit
          equnr(18),  "Equipment No
          ewvgw(13),  "Usage Value
          eweinh(3),  "Unit
          steuf(4),   "Country Key
          ktext(40),  "Text  "Added by Raj on 18.10.2024
          plnnr     TYPE rc271-plnnr,
          num(003)  TYPE n,
        END OF st_item.

TYPES : BEGIN OF st_comp,
          matnr TYPE  rc27m-matnr,
          vornr TYPE  rcm01-vornr,
          posnr TYPE  stpo-posnr,
        END OF st_comp.

TYPES : BEGIN OF st_mic,
          matnr     TYPE  rc27m-matnr,
          vornr     TYPE  rcm01-vornr,
          verwmerkm TYPE plmkb-verwmerkm,
        END OF st_mic.

TYPES : BEGIN OF st_sam,
          matnr      TYPE  rc27m-matnr,
          vornr      TYPE  rcm01-vornr,
          stichprver TYPE plmkb-stichprver,
        END OF st_sam.


*To hold the Error Log.
TYPES : BEGIN OF st_errlog,
          matnr      TYPE  rc27m-matnr,
          ertxt(255) TYPE c,          "Error Text
        END OF st_errlog.

*To hold the Posted Data.
TYPES : BEGIN OF st_scclog,
          matnr      TYPE	rc27m-matnr,
          sctxt(255) TYPE c,         "Succcessfuly Text
        END OF st_scclog.


DATA : it_upload TYPE TABLE OF st_upload WITH HEADER LINE,
       wa_upload TYPE st_upload.

DATA : it_header TYPE TABLE OF st_header WITH HEADER LINE,
       wa_header TYPE st_header.

DATA : it_item1 TYPE TABLE OF st_item WITH HEADER LINE,
       it_item  TYPE TABLE OF st_item WITH HEADER LINE,
       wa_item  TYPE st_item.

DATA : it_comp TYPE TABLE OF st_comp WITH HEADER LINE,
       wa_comp TYPE st_comp.

DATA : it_mic TYPE TABLE OF st_mic WITH HEADER LINE,
       wa_mic TYPE st_mic.

DATA : it_sam TYPE TABLE OF st_sam WITH HEADER LINE,
       wa_sam TYPE st_sam.


DATA : it_scclog TYPE TABLE OF st_scclog WITH HEADER LINE, "Success Log
       it_errlog TYPE TABLE OF st_errlog WITH HEADER LINE. "Error Log

DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.
DATA : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

DATA: t_mapl TYPE STANDARD TABLE OF mapl,
      w_mapl TYPE mapl.
DATA: v_line  TYPE i,
      v_index TYPE sy-index,
      v_indx  TYPE char10.

CONSTANTS: gc_msgtyp(001) VALUE 'S', "Message Type Success
           gc_msgid(020)  VALUE 'F2',  "Message ID
           gc_msgnr(003)  VALUE '174'. "Message Number

*Selection Screen
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS : mod LIKE ctu_params-dismode DEFAULT 'A'.
  PARAMETERS : upd LIKE ctu_params-updmode DEFAULT 'S'.
  PARAMETERS : p_outfil LIKE rlgrap-filename OBLIGATORY. " Output File
SELECTION-SCREEN END OF BLOCK b1.
SKIP.


* Providing output file name from user after pressing F4
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_outfil.
  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    CHANGING
      file_name     = p_outfil
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
  ENDIF.


START-OF-SELECTION.
*******************

  PERFORM upload_file.

  IF NOT ( it_upload[] IS INITIAL ).
    PERFORM create_head_item_table.
    PERFORM new_bdc_change.
*    PERFORM execute_bdc.
*    PERFORM fr_write_message.
  ELSE.
    WRITE : 'No record found in upload file'.
  ENDIF.

END-OF-SELECTION.

TOP-OF-PAGE.
  PERFORM fr_top_of_page.

*&---------------------------------------------------------------------*
*&      Form  execute_bdc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM execute_bdc .
  DATA : wa_knb1 TYPE knb1.
  DATA: count(2) TYPE n." VALUE '01'.
  DATA: count1(2) TYPE n ." VALUE '01'.
  DATA: count2(2) TYPE n ." VALUE '01'
  DATA: v_tabix TYPE sy-tabix.
  DATA: field_bdc(20).
  DATA: lv_date(10).
  DATA: nextpos TYPE string.
  DATA: counter(2) TYPE n VALUE '01'.

  LOOP AT it_header INTO wa_header.
    PERFORM bdc_dynpro      USING 'SAPLCPDI'     '1010'.
    PERFORM bdc_field       USING 'BDC_CURSOR'   'RC271-PLNNR'.
    PERFORM bdc_field       USING 'BDC_OKCODE'   '/00'.
    PERFORM bdc_field       USING 'RC27M-MATNR'  wa_header-matnr.  "'80000001'.
    PERFORM bdc_field       USING 'RC27M-WERKS'  wa_header-werks. "'1110'.
    PERFORM bdc_field       USING 'RC271-REVLV'  wa_header-revlv. "'1110'.
    PERFORM bdc_field       USING 'RC271-PLNNR'  ''.
*    CALL FUNCTION 'CONVERSION_EXIT_PDATE_OUTPUT'
*      EXPORTING
*        input         = sy-datum
*     IMPORTING
*       OUTPUT        = lv_date.
    PERFORM bdc_field       USING 'RC271-STTAG'  wa_header-sttag.         "'20.06.2007'.
    PERFORM f_get_mapl.
    DESCRIBE TABLE t_mapl LINES v_line.
    IF v_line GT 1.
      DO v_line TIMES.
        v_index = sy-tabix.
        READ TABLE it_item INTO wa_item INDEX v_index.
        IF sy-subrc EQ 0.

        ENDIF.
      ENDDO.

    ENDIF.
    IF wa_header-plnal IS NOT INITIAL.
      PERFORM bdc_dynpro      USING 'SAPLCPDI'     '1200'.
      PERFORM bdc_field       USING 'BDC_CURSOR'   'RC27X-ENTRY_ACT'.
      PERFORM bdc_field       USING 'BDC_OKCODE'   '=ANLG'.
    ENDIF.


    PERFORM bdc_dynpro      USING 'SAPLCPDA'       '1200'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '=VOUE'.
    PERFORM bdc_field       USING 'PLKOD-VERWE'    '1'.
    PERFORM bdc_field       USING 'PLKOD-STATU'    '4'.
    PERFORM bdc_field       USING 'PLKOD-LOSVN'    '1'.
    PERFORM bdc_field       USING 'PLKOD-LOSBS'    '1000000'.
    PERFORM bdc_field       USING 'PLKOD-PLNME'     wa_header-plnme.                 "EA.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'PLKOD-SLWBEZ'.
    PERFORM bdc_field       USING 'PLKOD-SLWBEZ'   ''.          "'120'
    PERFORM bdc_field       USING 'PLKOD-PPKZTLZU' ''.          "'0'

    LOOP AT it_item INTO wa_item WHERE matnr = wa_header-matnr
                                   AND num   = wa_header-num.
      count = count + 1.
      PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
      IF wa_item-equnr IS NOT INITIAL.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'PLPOD-VORNR(01)'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=FHUE'.

        CONCATENATE 'RC27X-FLG_SEL(' count ')' INTO field_bdc.
        PERFORM bdc_field       USING field_bdc   'X'.
        CLEAR field_bdc.
      ELSE.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.

      ENDIF.
      IF count GT 1." AND wa_item-equnr IS NOT INITIAL.
        count = count - 1.
        CONCATENATE 'RC27X-FLG_SEL(' count ')' INTO field_bdc.
        PERFORM bdc_field       USING field_bdc   ''.
        CLEAR field_bdc.
        count = count + 1.
      ENDIF.
*** added on 17.05.2013
      CONCATENATE 'PLPOD-VORNR(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING  field_bdc      wa_item-vornr.
      CLEAR field_bdc.
*** ended on 17.05.2013
      CONCATENATE 'PLPOD-ARBPL(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING  field_bdc      wa_item-arbpl.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-STEUS(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING  field_bdc      wa_item-steus.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-LTXA1(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-ltxa1.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-BMSCH(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-bmsch.
      CLEAR field_bdc.


      CONCATENATE 'PLPOD-VGW01(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw01.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE01(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge01.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGW02(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw02.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE02(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge02.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGW03(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw03.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE03(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge03.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGW04(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw04.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE04(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge04.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGW05(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw05.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE05(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge05.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGW06(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vgw06.
      CLEAR field_bdc.
      CONCATENATE 'PLPOD-VGE06(' count ')' INTO field_bdc.
      PERFORM bdc_field       USING field_bdc       wa_item-vge06.
      CLEAR field_bdc.
*      PERFORM bdc_dynpro      USING 'SAPLCPDI'      '1400'.
*
*      PERFORM bdc_field       USING 'BDC_CURSOR'    'PLPOD-VORNR(01)'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'    '=FHUE'.
      IF wa_item-equnr IS NOT INITIAL.

        PERFORM bdc_dynpro      USING 'SAPLCFDI' '0200'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/EFIE'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLFHD-PSNFH'.
        PERFORM bdc_dynpro      USING 'SAPLCFDI' '0230'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLFHD-STEUF'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=BACK'.
**      PERFORM bdc_field       USING 'PLFHD-PSNFH'
**                                    WA_ITEM-psnfh_032.
        PERFORM bdc_field       USING 'PLFHD-EQUNR'
                                      wa_item-equnr.
        PERFORM bdc_field       USING 'PLFHD-EWVGW'
                                      wa_item-ewvgw.
        PERFORM bdc_field       USING 'PLFHD-EWEINH'
                                      wa_item-eweinh.
        PERFORM bdc_field       USING 'PLFHD-STEUF'
                                      wa_item-steuf.
*        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
        PERFORM bdc_dynpro      USING 'SAPLCFDI' '0100'.
        PERFORM bdc_field       USING 'BDC_OKCODE'        '=BACK'.
      ELSE.
        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
*      PERFORM bdc_field       USING 'BDC_CURSOR'
*                                    'PLPOD-VORNR(01)'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.

      ENDIF.

      IF count = 15 AND v_tabix IS INITIAL .
        v_tabix = 1 .
        count = 1.
        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
*        CONCATENATE 'PLPOD-STEUS(' count ')' INTO nextpos.
*        PERFORM bdc_field       USING 'BDC_CURSOR'  nextpos. "'PLPOD-STEUS(17)'.   "nextpos.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                   '=P+'.
      ELSEIF count = 14.
        count = 1.
        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
*        CONCATENATE 'PLPOD-STEUS(' count ')' INTO nextpos.
*        PERFORM bdc_field       USING 'BDC_CURSOR'  nextpos. "'PLPOD-STEUS(17)'.   "nextpos.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                   '=P+'.

      ENDIF.

    ENDLOOP.

*    PERFORM bdc_dynpro      USING 'SAPLCFDI' '0100'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'        '=BACK'.
    PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
    PERFORM bdc_field       USING 'BDC_CURSOR'  'RC27X-ENTRY_ACT'.
    PERFORM bdc_field       USING 'BDC_OKCODE'  '=BU'.
    PERFORM bdc_field       USING 'RC27X-ENTRY_ACT' '1'.
*    PERFORM bdc_dynpro      USING 'SAPLCMDI'    '1000'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'  'RCM01-MATNR'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'  '=BU'.
    count = 0.
    CLEAR: count.
    PERFORM call_tran.
*    PERFORM fr_message.

    REFRESH : messtab, bdcdata.
    CLEAR: it_upload, wa_upload.
  ENDLOOP.
ENDFORM. " execute_bdc

*&---------------------------------------------------------------------*
*&      Form  bdc_dynpro
*&---------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. " bdc_dynpro
*&--------------------------------------------------------------------*
*&      Form  bdc_field
*&---------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM. " bdc_field

*&---------------------------------------------------------------------*
*&      Form  call_tran
*&---------------------------------------------------------------------*
FORM call_tran .

  DATA : lv_params TYPE ctu_params.

  lv_params-dismode = mod.
  lv_params-updmode = upd.
**  lv_params-nobinpt = 'X'. comm
*  LV_PARAMS-RACOMMIT = 'X'.

  lv_params-defsize = 'X'.

*  CALL TRANSACTION 'CA02'
*         USING bdcdata
*         MODE mod
*         UPDATE upd
*         MESSAGES INTO messtab ."OPTIONS FROM lv_params.

  CALL TRANSACTION 'CA02'
        USING bdcdata
*         MODE mod
*         UPDATE upd
        MESSAGES INTO messtab OPTIONS FROM lv_params.


ENDFORM. " call_tran
*&---------------------------------------------------------------------*
*&      Form  fr_message
*&---------------------------------------------------------------------*
*FORM fr_message.
*
*  DATA :  l_txt(255) TYPE c,                "To Hold Message Text
*          lw_scclog TYPE st_scclog,         "work area for success log
*          lw_errlog TYPE st_errlog.         "Work Area for Error Log
*  LOOP AT messtab.
*    CALL FUNCTION 'MESSAGE_TEXT_BUILD'
*      EXPORTING
*        msgid               = messtab-msgid
*        msgnr               = messtab-msgnr
*        msgv1               = messtab-msgv1
*        msgv2               = messtab-msgv2
*        msgv3               = messtab-msgv3
*        msgv4               = messtab-msgv4
*      IMPORTING
*        message_text_output = l_txt.
*
**Success Log
*    IF messtab-msgid  = gc_msgid  AND
*       messtab-msgnr  = gc_msgnr  AND
*       messtab-msgtyp = gc_msgtyp.
*      lw_scclog-kunnr = wa_upload-kunnr.
*      lw_scclog-sctxt = l_txt.
*      APPEND lw_scclog TO it_scclog.
*      CLEAR lw_scclog.
**Error Log
*    ELSEIF messtab-msgtyp = 'E' OR messtab-msgtyp = 'I'.
*      lw_errlog-kunnr = wa_upload-kunnr.
*      lw_errlog-ertxt = l_txt.
*      APPEND lw_errlog TO it_errlog.
*      CLEAR lw_errlog.
*    ENDIF.
*  ENDLOOP.
*  CLEAR: wa_upload.
*ENDFORM.                    " fr_message
**&---------------------------------------------------------------------*
**&      Form  fr_write_message
**&---------------------------------------------------------------------*
*FORM fr_write_message .
*  DATA: v_col TYPE i.
*
*  IF NOT it_scclog[] IS INITIAL.
*    WRITE:/2 'Successful Record' COLOR COL_HEADING INTENSIFIED.
*    WRITE:/2 'Customer Upload'   COLOR COL_HEADING INTENSIFIED,
*          25 'Text'              COLOR COL_HEADING INTENSIFIED.
*
*    LOOP AT it_scclog.
*      v_col = sy-index MOD 2.
*      IF v_col EQ 0.
*        WRITE:/2 it_scclog-kunnr HOTSPOT COLOR 2,
*              25 it_scclog-sctxt COLOR 2.
*      ELSE.
*        WRITE:/2 it_scclog-kunnr HOTSPOT COLOR 4,
*              25 it_scclog-sctxt COLOR 4.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*
*  IF NOT it_errlog[] IS INITIAL.
*    SKIP 2.
*    WRITE:/2 'Unsuccessful Record' COLOR COL_HEADING INTENSIFIED.
*    WRITE:/2 'Customer Upload'     COLOR COL_HEADING INTENSIFIED,
*          25 'Text'                COLOR COL_HEADING INTENSIFIED.
*
*    LOOP AT it_errlog.
*      v_col = sy-index MOD 2.
*      IF v_col EQ 0.
*        WRITE:/2  it_errlog-kunnr COLOR 2,
*               25 it_errlog-ertxt COLOR 2.
*      ELSE.
*        WRITE:/2  it_errlog-kunnr COLOR 4,
*               25 it_errlog-ertxt COLOR 4.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*ENDFORM.                    " fr_write_message
*&---------------------------------------------------------------------*
*&      Form  fr_top_of_page
*&---------------------------------------------------------------------*
FORM fr_top_of_page .

  WRITE:/45 'ROUTING DATA UPLOAD'.
  WRITE:/41 'Routing Data Upload Complete'.
  ULINE.
  WRITE:/1  sy-vline,
         2 'Username:',
        12  sy-uname,
        70 'Program Name :',
        85  sy-repid,
       120  sy-vline.
  ULINE.
  WRITE:/1   sy-vline,
         2  'Date    :',
         12  sy-datum,
         70  'Client       :',
         85  sy-mandt,
         120 sy-vline.
  ULINE.
ENDFORM. " fr_top_of_page
*&---------------------------------------------------------------------*
*&      Form  upload_file
*&---------------------------------------------------------------------*
FORM upload_file .

  DATA:it_type TYPE truxs_t_text_data.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_outfil
    TABLES
      i_tab_converted_data = it_upload
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error In Uploading File' TYPE 'E' DISPLAY LIKE 'S'.
    RETURN.
  ENDIF.

****  CALL FUNCTION 'GUI_UPLOAD'
****    EXPORTING
****      filename                = str_file
****      filetype                = 'ASC'
****      has_field_separator     = 'X'
****    TABLES
****      data_tab                = it_upload
****    EXCEPTIONS
****      file_open_error         = 1
****      file_read_error         = 2
****      no_batch                = 3
****      gui_refuse_filetransfer = 4
****      invalid_type            = 5
****      no_authority            = 6
****      unknown_error           = 7
****      bad_data_format         = 8
****      header_not_allowed      = 9
****      separator_not_allowed   = 10
****      header_too_long         = 11
****      unknown_dp_error        = 12
****      access_denied           = 13
****      dp_out_of_memory        = 14
****      disk_full               = 15
****      dp_timeout              = 16
****      OTHERS                  = 17.
****  IF sy-subrc <> 0.
****    MESSAGE e000(zpp) WITH 'Error In Uploading File'.
****    RETURN.
****  ENDIF.
ENDFORM. " upload_file
*&---------------------------------------------------------------------*
*&      Form  create_head_item_table
*&---------------------------------------------------------------------*
FORM create_head_item_table .
  REFRESH : it_header[], it_item[].
*  SORT it_upload BY matnr. " arbpl.
  DATA : lv_werks TYPE marc-werks.
  DATA : lv_date(10),
         lv_revlv(02),
         lv_plnme(03),
         lv_num(03) TYPE n.
  DATA: t_upload TYPE TABLE OF st_upload WITH HEADER LINE,
        w_upload TYPE st_upload.


  t_upload[] = it_upload[].
  SORT t_upload BY matnr werks.
  DELETE ADJACENT DUPLICATES FROM t_upload COMPARING matnr werks.

  SELECT * FROM mapl INTO TABLE t_mapl
    FOR ALL ENTRIES IN t_upload
       WHERE matnr = t_upload-matnr
         AND werks = t_upload-werks AND plnty = 'N'.

*  lv_num =  1.
*Header Table
  LOOP AT it_upload INTO wa_upload.
    lv_werks = wa_upload-werks.
    lv_date  = wa_upload-sttag.
    lv_revlv = wa_upload-revlv.
    lv_plnme = wa_upload-plnme.
*    lv_num = lv_num + 1.
    AT NEW matnr.
      READ TABLE t_mapl INTO w_mapl WITH KEY matnr = wa_upload-matnr
                                             werks = lv_werks.
      IF sy-subrc EQ 0.
        wa_header-plnal = w_mapl-plnal.
      ENDIF.
      wa_header-matnr = wa_upload-matnr.
      wa_header-werks = lv_werks.
      wa_header-sttag = lv_date.
      wa_header-revlv = lv_revlv.
      wa_header-plnme = lv_plnme.
      wa_header-num   = lv_num.
      APPEND  wa_header TO it_header.
      CLEAR wa_header.
    ENDAT.
  ENDLOOP.

  CLEAR lv_num.
*item Table
  LOOP AT it_upload INTO wa_upload.
    lv_num = lv_num + 1.
    wa_item-matnr =	wa_upload-matnr.
    wa_item-vornr = wa_upload-vornr.
    wa_item-arbpl = wa_upload-arbpl.
    wa_item-steus =	wa_upload-steus.
    wa_item-ltxa1 =	wa_upload-ltxa1.
    wa_item-bmsch =	wa_upload-bmsch.
    wa_item-meinh =	wa_upload-meinh.
    wa_item-umren =	wa_upload-umren.
    wa_item-vgw01 =	wa_upload-vgw01.
    wa_item-vge01 =	wa_upload-vge01.
    wa_item-vgw02 =	wa_upload-vgw02.
    wa_item-vge02 =	wa_upload-vge02.
    wa_item-vgw03 =	wa_upload-vgw03.
    wa_item-vge03 =	wa_upload-vge03.
    wa_item-vgw04 =	wa_upload-vgw04.
    wa_item-vge04 = wa_upload-vge04.
    wa_item-vgw05 = wa_upload-vgw05.
    wa_item-vge05 = wa_upload-vge05.
    wa_item-vgw06 = wa_upload-vgw06.
    wa_item-vge06 = wa_upload-vge06.
    wa_item-equnr = wa_upload-equnr.
    wa_item-ewvgw  = wa_upload-ewvgw .
    wa_item-eweinh = wa_upload-eweinh.
    wa_item-steuf  = wa_upload-steuf .
    wa_item-plnnr = wa_upload-plnnr.
    wa_item-ktext  = wa_upload-ktext ."Added by Raj on 21.10.2024
    wa_item-num  = lv_num.
    APPEND  wa_item  TO it_item1.
    CLEAR wa_item.

  ENDLOOP.
*Comp table
***  LOOP AT it_upload INTO wa_upload.
****1
******    IF  NOT wa_upload-posnr1 IS INITIAL.
******      wa_comp-matnr =	wa_upload-matnr.
******      wa_comp-vornr =   wa_upload-vornr.
******      wa_comp-posnr =   wa_upload-posnr1.
******      APPEND  wa_comp  TO it_comp.
******    ENDIF.
***    IF  NOT wa_upload-verwmerkm1 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm1.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver1 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver1.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****2
***    IF  NOT wa_upload-posnr2 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr2.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm2 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm2.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver2 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver2.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****3
***    IF  NOT wa_upload-posnr3 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr3.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm3 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm3.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver3 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver3.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****4
***    IF  NOT wa_upload-posnr4 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr4.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm4 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm4.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver4 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver4.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****5
***    IF  NOT wa_upload-posnr5 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr5.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm5 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm5.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver5 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver5.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****6
***    IF  NOT wa_upload-posnr6 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr6.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm6 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm6.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver6 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver6.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****7
***    IF  NOT wa_upload-posnr7 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr7.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm7 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm7.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver7 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver7.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****8
***    IF  NOT wa_upload-posnr8 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr8.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm8 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm8.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver8 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver8.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****9
***    IF  NOT wa_upload-posnr9 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr9.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm9 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm9.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver9 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver9.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
****10
***    IF  NOT wa_upload-posnr10 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr10.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm10 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm10.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver10 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver10.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****11
***    IF  NOT wa_upload-posnr11 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr11.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm11 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm11.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver11 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver11.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****12
***    IF  NOT wa_upload-posnr12 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr12.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm12 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm12.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver12 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver2.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****13
***    IF  NOT wa_upload-posnr13 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr13.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm13 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm13.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver14 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver14.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****14
***    IF  NOT wa_upload-posnr14 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr14.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm14 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm14.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver15 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver15.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****15
***    IF  NOT wa_upload-posnr15 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr15.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm15 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm15.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver15 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver15.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****16
***    IF  NOT wa_upload-posnr16 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr16.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm16 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm16.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver16 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver16.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****17
***    IF  NOT wa_upload-posnr17 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr17.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm17 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm17.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver17 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver17.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****18
***    IF  NOT wa_upload-posnr18 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr18.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm18 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm18.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver18 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver18.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
****19
***    IF  NOT wa_upload-posnr19 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr19.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm19 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm19.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver19 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver19.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.
***
***
****20
***    IF  NOT wa_upload-posnr20 IS INITIAL.
***      wa_comp-matnr =  wa_upload-matnr.
***      wa_comp-vornr =   wa_upload-vornr.
***      wa_comp-posnr =   wa_upload-posnr20.
***      APPEND  wa_comp  TO it_comp.
***    ENDIF.
***    IF  NOT wa_upload-verwmerkm20 IS INITIAL.
***      wa_mic-matnr =  wa_upload-matnr.
***      wa_mic-vornr =   wa_upload-vornr.
***      wa_mic-verwmerkm = wa_upload-verwmerkm20.
***      APPEND  wa_mic  TO it_mic.
***    ENDIF.
***    IF  NOT wa_upload-stichprver20 IS INITIAL.
***      wa_sam-matnr =  wa_upload-matnr.
***      wa_sam-vornr =   wa_upload-vornr.
***      wa_sam-stichprver = wa_upload-stichprver20.
***      APPEND  wa_sam  TO it_sam.
***    ENDIF.

***  ENDLOOP.
ENDFORM. " create_head_item_table

*Text elements
*----------------------------------------------------------
* E00 Error opening dataset, return code:
* I01 Session name
* I02 Open session
* I03 Insert transaction
* I04 Close Session
* I05 Return code =
* I06 Error session created
* S01 Session name
* S02 User
* S03 Keep session
* S04 Lock date
* S05 Processing Mode
* S06 Update Mode
* S07 Generate session
* S08 Call transaction
* S09 Error sessn
* S10 Nodata indicator
* S11 Short log


*Selection texts
*----------------------------------------------------------
* IN_PUT D       .
* MOD D       .
* P_OUTFIL D       .
* UPD D       .
*&---------------------------------------------------------------------*
*&      Form  F_GET_MAPL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_WA_HEADER_PLNAL  text
*----------------------------------------------------------------------*
FORM f_get_mapl .
  REFRESH : t_mapl.
  SELECT * FROM mapl INTO TABLE t_mapl
       WHERE matnr = wa_header-matnr
         AND werks = wa_header-werks AND plnty = 'N' AND loekz NE 'X' .

ENDFORM.                    " F_GET_MAPL
*&---------------------------------------------------------------------*
*&      Form  NEW_BDC_CHANGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM new_bdc_change .
  DATA : wa_knb1 TYPE knb1.
  DATA: count(2) TYPE n." VALUE '01'.
  DATA: count1(2) TYPE n ." VALUE '01'.
  DATA: count2(2) TYPE n ." VALUE '01'
  DATA: v_tabix TYPE sy-tabix.
  DATA: field_bdc(20).
  DATA: lv_date(10).
  DATA: nextpos TYPE string.
  DATA: counter(2) TYPE n VALUE '01'.

  LOOP AT it_header INTO wa_header.
    REFRESH: bdcdata[].
    REFRESH it_item[].
    it_item[] = it_item1[].
    DELETE it_item WHERE matnr NE wa_header-matnr.

    PERFORM bdc_dynpro      USING 'SAPLCPDI' '1010'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC271-PLNNR'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'RC27M-MATNR'
                                  wa_header-matnr.
    PERFORM bdc_field       USING 'RC27M-WERKS'
                                  wa_header-werks.
    PERFORM bdc_field       USING 'RC271-PLNNR'
                                  ''."wa_header-plnnr.
    PERFORM bdc_field       USING 'RC271-REVLV'  wa_header-revlv. "'1110'.

    PERFORM bdc_field       USING 'RC271-STTAG'
                                  wa_header-sttag.
*  PERFORM bdc_field       USING 'RC271-PLNAL'
*                                record-plnal.

    PERFORM f_get_mapl.
    DESCRIBE TABLE t_mapl LINES v_line.
    IF v_line GT 1.
      DO v_line TIMES.
        v_index = sy-index.
        count1 = count1 + 1.
        READ TABLE it_item INTO wa_item INDEX v_index.

        select single OBJID from crhd into @data(lv_arbid) where arbpl = @wa_item-arbpl.

        SELECT *  FROM plpo INTO TABLE @DATA(lt_plpo) WHERE arbid  = @lv_arbid.

        DELETE lt_plpo WHERE plnnr NE wa_item-plnnr.

*        READ TABLE t_mapl into data(w_mapl) with key arbpl = wa_item-arbpl.


        READ TABLE lt_plpo INTO DATA(wa_plpo) INDEX 1.


        DATA(lv_count) = wa_plpo-zaehl.

        DATA : lv_plnal TYPE char20.


        SHIFT lv_count LEFT DELETING LEADING '0'.


        IF sy-subrc EQ 0.
          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.


*          CONCATENATE 'PLKOD-PLNAL(' lv_count ')' INTO lv_plnal.


*          PERFORM bdc_field       USING 'BDC_CURSOR'
**                                        'PLKOD-PLNAL( 'wa_plpo-ZAEHL' )'.
*                                          lv_plnal.
*          PERFORM bdc_field       USING 'BDC_OKCODE'
*                                        '=VOUE'.



          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'PLKOD-PLNAL(01)'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=VOUE'.



*          PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
*                                        '1'.
          count = count1 - 1.
          v_indx = v_index.
          CONDENSE v_indx.
          IF count GE 1.
            DO count TIMES.
              count2 = count2 + 1.
              CONCATENATE 'RC27X-FLG_SEL(' count2 ')' INTO field_bdc.
              PERFORM bdc_field       USING field_bdc   ' '.
              CLEAR: field_bdc.
            ENDDO.
            CLEAR:count2.
          ENDIF.

*          CONCATENATE 'RC27X-FLG_SEL(' count1 ')' INTO field_bdc.

          CONCATENATE 'RC27X-FLG_SEL(' lv_count ')' INTO field_bdc.

          PERFORM bdc_field       USING field_bdc   'X'.
          CLEAR: field_bdc.
          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'PLPOD-BMSCH(01)'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'PLPOD-BMSCH(01)'
                                        wa_item-bmsch.

*          CONCATENATE 'PLPOD-VGW01(01)' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vgw01.
*      CLEAR field_bdc.
*      CONCATENATE 'PLPOD-VGE01(' count ')' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vge01.
*      CLEAR field_bdc.
*      CONCATENATE 'PLPOD-VGW02(' count ')' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vgw02.
*      CLEAR field_bdc.
*      CONCATENATE 'PLPOD-VGE02(' count ')' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vge02.
*      CLEAR field_bdc.
*      CONCATENATE 'PLPOD-VGW03(' count ')' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vgw03.
*      CLEAR field_bdc.
*      CONCATENATE 'PLPOD-VGE03(' count ')' INTO field_bdc.
*      PERFORM bdc_field       USING field_bdc       wa_item-vge03.
*      CLEAR field_bdc.


          PERFORM bdc_field       USING 'PLPOD-VGW01(01)'
                                       wa_item-vgw01.

          PERFORM bdc_field       USING 'PLPOD-VGE01(01)'
                                      wa_item-vge01.

          PERFORM bdc_field       USING 'PLPOD-VGW02(01)'
                                      wa_item-vgw02.

          PERFORM bdc_field       USING 'PLPOD-VGE02(01)'
                                      wa_item-vge02.

          PERFORM bdc_field       USING 'PLPOD-VGW03(01)'
                                      wa_item-vgw03.

          PERFORM bdc_field       USING 'PLPOD-VGE03(01)'
                                      wa_item-vge03.


          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'PLPOD-BMSCH(01)'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BACK'.
          PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.


*           PERFORM bdc_field       USING 'PLKOD-KTEXT(01)'  "
          PERFORM bdc_field       USING 'PLKOD-KTEXT'  "
                                      wa_item-ktext.


          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BACK'.
          IF count1 = 15 AND v_tabix IS INITIAL .
            v_tabix = 1 .
            count1 = 1.
            PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
*        CONCATENATE 'PLPOD-STEUS(' count ')' INTO nextpos.
*        PERFORM bdc_field       USING 'BDC_CURSOR'  nextpos. "'PLPOD-STEUS(17)'.   "nextpos.
            PERFORM bdc_field       USING 'BDC_OKCODE'
                                       '=P+'.
          ELSEIF count1 = 14.
            count1 = 1.
            PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
*        CONCATENATE 'PLPOD-STEUS(' count ')' INTO nextpos.
*        PERFORM bdc_field       USING 'BDC_CURSOR'  nextpos. "'PLPOD-STEUS(17)'.   "nextpos.
            PERFORM bdc_field       USING 'BDC_OKCODE'
                                       '=P+'.
          ENDIF.
          IF count GE 1.
            DO count TIMES.
              count2 = count2 + 1.
              CONCATENATE 'RC27X-FLG_SEL(' count2 ')' INTO field_bdc.
              PERFORM bdc_field       USING field_bdc   ' '.
              CLEAR: field_bdc.
            ENDDO.
            CLEAR:count2.
          ENDIF.

        ENDIF.
      ENDDO.


      CLEAR : lv_count,lv_arbid.
      REFRESH : lt_plpo.



    ELSEIF v_line EQ 1.
      READ TABLE it_item INTO wa_item INDEX 1."v_index.
      PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLPOD-BMSCH(01)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'PLPOD-BMSCH(01)'
                                    wa_item-bmsch.

      PERFORM bdc_field       USING 'PLPOD-VGW01(01)'
                                   wa_item-vgw01.

      PERFORM bdc_field       USING 'PLPOD-VGE01(01)'
                                  wa_item-vge01.

      PERFORM bdc_field       USING 'PLPOD-VGW02(01)'
                                  wa_item-vgw02.

      PERFORM bdc_field       USING 'PLPOD-VGE02(01)'
                                  wa_item-vge02.

      PERFORM bdc_field       USING 'PLPOD-VGW03(01)'
                                  wa_item-vgw03.

      PERFORM bdc_field       USING 'PLPOD-VGE03(01)'
                                  wa_item-vge03.


      PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLPOD-BMSCH(01)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=BACK'.
      PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.


      PERFORM bdc_field       USING 'PLKOD-KTEXT'  "
                            wa_item-ktext.


      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=BACK'.



    ENDIF.
    PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC27X-ENTRY_ACT'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
    PERFORM call_tran.
    CLEAR :count,count1,v_line,count2.
  ENDLOOP.

ENDFORM.                    " NEW_BDC_CHANGE
