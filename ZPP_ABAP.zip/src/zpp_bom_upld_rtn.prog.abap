*&---------------------------------------------------------------------*
*&  Include           ZPP_BOM_UPLD_RTN
*&---------------------------------------------------------------------*

FORM bdc_execution USING p_mode.
  DATA : flag(1) TYPE c.
  DATA : temp_comp LIKE rc29p-idnrk.
  DATA : temp_date LIKE rc29n-datuv.
  DATA : temp_mat_no LIKE rc29n-matnr.

**  SORT zbom BY docu_no.
  SORT zbom BY material_no.

  LOOP AT zbom.
    IF zbom-material_no = ''.
      CONTINUE.
    ENDIF.

    temp_mat_no = zbom-material_no.
    PERFORM comp CHANGING temp_mat_no.
    zbom-material_no = temp_mat_no.

    temp_comp = zbom-component.
    PERFORM comp CHANGING temp_comp.
    zbom-component = temp_comp.


    MODIFY zbom.

**    ON CHANGE OF zbom-docu_no.
    ON CHANGE OF zbom-material_no.
      flag = 0.

**************************HEADER DATA**********************************

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0100'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29N-STLAN'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RC29N-MATNR'
                                    zbom-material_no.
      PERFORM bdc_field       USING 'RC29N-WERKS'
                                    zbom-plant.
      PERFORM bdc_field       USING 'RC29N-STLAN'
                                    zbom-bom_usage.

*        perform bdc_field       using 'RC29N-STLAL'
*                                      ''.
      PERFORM bdc_field       USING 'RC29N-AENNR'
                                    zbom-change_no.
      PERFORM bdc_field       USING 'RC29N-DATUV'
                                    zbom-valid_from.

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0110'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RC29K-BMENG'
                                    zbom-base_qty.
      PERFORM bdc_field       USING 'RC29K-STLST'
                                    zbom-status.

*        perform bdc_field       using 'BDC_CURSOR'
*                                      'RC29K-EXSTL'.
*

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0111'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29K-LABOR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.


**************************ITEM DATA**********************************


      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29P-POSTP(02)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.

      IF flag = 0.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
      ELSE.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=FCNP'.
        flag = 1.
      ENDIF.

    ENDON.


******************SECTION INDICATOR*************************************

    PERFORM bdc_field       USING 'RC29P-POSNR(02)'
                                  zbom-item_number.
    PERFORM bdc_field       USING 'RC29P-IDNRK(02)'
                                  zbom-component.
    PERFORM bdc_field       USING 'RC29P-MENGE(02)'
                                  zbom-qty.
    PERFORM bdc_field       USING 'RC29P-MEINS(02)'
                                  zbom-uom.
    PERFORM bdc_field       USING 'RC29P-POSTP(02)'
                                  zbom-item_cat.
    PERFORM bdc_field       USING 'RC29P-SORTF(02)'
                                  zbom-sort_string.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29K-STKTX'.

    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0130'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-KZKUP'.
    PERFORM bdc_field       USING 'RC29P-POSNR'
                                    zbom-item_number.
    PERFORM bdc_field       USING 'RC29P-IDNRK'
                                  zbom-component.
    PERFORM bdc_field       USING 'RC29P-MENGE'
                                  zbom-qty.
    PERFORM bdc_field       USING 'RC29P-MEINS'
                                  zbom-uom.
    PERFORM bdc_field       USING 'RC29P-AUSCH'
                                  zbom-scrap.

*    if zbom-qty < 0.
*      perform bdc_field     using 'RC29P-KZKUP'
*                                  'X'.
*    else.

    PERFORM bdc_field     USING 'RC29P-KZKUP'
                                zbom-co_product.
*    endif.

    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0131'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-POTX1'.
    PERFORM bdc_field       USING 'RC29P-LGORT'
                                  zbom-storage_loc.
    IF zbom-rel_cost IS INITIAL.
      CLEAR zbom-rel_cost.
    ENDIF.
    PERFORM bdc_field       USING 'RC29P-SANKA'
                                  zbom-rel_cost.


    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.

    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-AUSKZ(02)'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=FCNP'.
    PERFORM bdc_field       USING 'RC29P-AUSKZ(02)'
                                  'X'.
    AT END OF material_no.
      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=FCBU'.
      CALL TRANSACTION 'CS01' USING bdcdata MODE p_mode
                                  MESSAGES INTO messtab.

      REFRESH bdcdata.
    ENDAT.
  ENDLOOP.
ENDFORM. "BDC_EXECUTION




*&---------------------------------------------------------------------*
*&      Form  BDC_DYNPRO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PROGRAM    text
*      -->DYNPRO     text
*----------------------------------------------------------------------*

FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO



*&---------------------------------------------------------------------*
*&      Form  BDC_FIELD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->FNAM       text
*      -->FVAL       text
*----------------------------------------------------------------------*

FORM bdc_field USING fnam fval.
*  IF fval <> ''.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
*  ENDIF.
ENDFORM. "BDC_FIELD



*&---------------------------------------------------------------------*
*&      Form  comp
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->TEMP_COMP  text
*----------------------------------------------------------------------*

FORM comp CHANGING temp_comp.
  CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
    EXPORTING
      input        = temp_comp
    IMPORTING
      output       = temp_comp
    EXCEPTIONS
      length_error = 1
      OTHERS       = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
ENDFORM. "comp


*&---------------------------------------------------------------------*
*&      Form  date_format
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->TEMP_DATE  text
*----------------------------------------------------------------------*

FORM date_format CHANGING temp_date.

*  CALL FUNCTION 'CONVERSION_EXIT_PDATE_OUTPUT'
*    EXPORTING
*      INPUT  = temp_date
*    IMPORTING
**      OUTPUT = temp_date.
*

ENDFORM. "date_format


*&---------------------------------------------------------------------*
*&      Form  DATA_LOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->FILENAME   text
*----------------------------------------------------------------------*

FORM data_load USING filename.
  DATA: p_file    TYPE rlgrap-filename,
        it_type   TYPE truxs_t_text_data,
        file_path TYPE string.
  file_path = filename.
  p_file = file_path.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = zbom
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
*
*  CALL FUNCTION 'GUI_UPLOAD'
*    EXPORTING
*      filename                = filename
*      filetype                = 'ASC'
*      has_field_separator     = 'X'
*      read_by_line            = 'X'
*    TABLES
*      data_tab                = zbom
*    EXCEPTIONS
*      file_open_error         = 1
*      file_read_error         = 2
*      no_batch                = 3
*      gui_refuse_filetransfer = 4
*      invalid_type            = 5
*      no_authority            = 6
*      unknown_error           = 7
*      bad_data_format         = 8
*      header_not_allowed      = 9
*      separator_not_allowed   = 10
*      header_too_long         = 11
*      unknown_dp_error        = 12
*      access_denied           = 13
*      dp_out_of_memory        = 14
*      disk_full               = 15
*      dp_timeout              = 16
*      OTHERS                  = 17.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*  ENDIF.
*

ENDFORM. "DATA_LOAD

*&---------------------------------------------------------------------*
*&      Form  FILENAME_REQUEST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_FNAME    text
*----------------------------------------------------------------------*
FORM filename_request USING p_fname.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = ' '
    IMPORTING
      file_name     = p_fname.
ENDFORM. "FILENAME_REQUEST
