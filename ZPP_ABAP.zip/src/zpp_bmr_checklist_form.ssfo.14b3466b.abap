
DATA: ls_qals TYPE qals,
      ls_mapl TYPE mapl,
      lv_flag TYPE i.

****SELECT SINGLE prueflos
****              werk
****              plnty
****              plnnr
****              plnal
****              zaehl
****              matnr
****              aufnr
****  FROM qals
****  INTO CORRESPONDING FIELDS OF ls_qals
****  WHERE werk = wa_temp-werks
****    AND aufnr = aufnr_imp.

SELECT matnr,
       werks,
       plnty,
       plnnr,
       plnal,
       zkriz,
       zaehl
  FROM mapl
  INTO TABLE @DATA(lt_mapl)
  WHERE matnr = @wa_temp-matnr
    AND werks = @wa_temp-werks
    AND plnty = 'Q'.

SORT lt_mapl ASCENDING BY matnr plnal DESCENDING.
DELETE ADJACENT DUPLICATES FROM lt_mapl COMPARING matnr.


IF lt_mapl[] IS NOT INITIAL.
  SELECT plnty            ,
         plnnr            ,
         plnkn            ,
         kzeinstell       ,
         merknr           ,
         zaehl            ,
         kurztext         ,
         masseinhsw       ,
         toleranzob       ,
         toleranzun       ,
         katalgart1       ,
         auswmenge1       ,
         auswmgwrk1
    FROM plmk
    INTO TABLE @DATA(lt_plmk)
    FOR ALL ENTRIES IN @lt_mapl
    WHERE plnty = @lt_mapl-plnty
      AND plnnr = @lt_mapl-plnnr
      AND plnkn = @lt_mapl-zaehl.

ENDIF."IF lt_mapl[] IS NOT INITIAL.


*****IF ls_qals IS NOT INITIAL.
*********  SELECT plnty,
*********         plnnr,
*********         plnkn,
*********         kzeinstell,
*********         merknr,
*********         zaehl,
*********         verwmerkm,
*********         kurztext,
*********         toleranzob,
*********         toleranzun
*********    FROM plmk
*********    INTO TABLE @DATA(lt_plmk)
*********    WHERE plnty = @ls_qals-plnty
*********      AND plnnr = @ls_qals-plnnr
*********      AND zaehl = @ls_qals-zaehl.
*****  SELECT prueflos     ,
*****         vorglfnr     ,
*****         merknr       ,
*****         qmtb_werks   ,
*****         pmethode     ,
*****         kurztext     ,
*****         katalgart1   ,
*****         auswmenge1   ,
*****         auswmgwrk1   ,
*****         masseinhsw   ,
*****         sollwert     ,
*****         toleranzob   ,
*****         toleranzun
*****    FROM qamv
*****    INTO TABLE @DATA(lt_qamv)
*****    WHERE prueflos = @ls_qals-prueflos
*****      AND vorglfnr = @ls_qals-zaehl.
*****ENDIF.

lv_flag = 0.
DATA: lv_lower TYPE string,
      lv_lp    TYPE p LENGTH 16 DECIMALS 3,
      lv_up    TYPE p LENGTH 16 DECIMALS 3,
      lv_upper TYPE string,
      lv_uom   TYPE string.

LOOP AT lt_plmk INTO DATA(ls_qamv).
  lv_flag = lv_flag + 1.
  ls_qmpk-sr_no = lv_flag.

  CLEAR: lv_lower , lv_upper.
  MOVE : ls_qamv-toleranzun TO lv_lp,
         ls_qamv-toleranzob TO lv_up.

  lv_lower = lv_lp.
  lv_upper = lv_up.

  MOVE-CORRESPONDING: ls_qamv TO ls_qmpk.
  ls_qmpk-total_s = ls_qamv-toleranzun + ls_qamv-toleranzob.
  CLEAR: lv_uom.

  CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
    EXPORTING
      input          = ls_qamv-masseinhsw
      language       = sy-langu
    IMPORTING
      short_text     = lv_uom
    EXCEPTIONS
      unit_not_found = 1
      OTHERS         = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
  IF ls_qamv-auswmenge1 IS NOT INITIAL AND
     ls_qamv-auswmgwrk1 IS NOT INITIAL.
    SELECT SINGLE ktx01
            FROM qpam
            INTO ls_qmpk-total_c
            WHERE werks = wa_temp-werks
              AND katalogart = ls_qamv-katalgart1.

  ELSE.
    CONCATENATE lv_lower '-' lv_upper
                lv_uom INTO ls_qmpk-total_c
                SEPARATED BY space.
  ENDIF.
***  ls_qmpk-total_c = ls_qmpk-total_s.



  CONDENSE: ls_qmpk-total_c.
  APPEND ls_qmpk TO lt_qmpk.
  CLEAR: ls_qmpk , ls_qamv.
ENDLOOP.

DO 3 TIMES.
  APPEND INITIAL LINE TO lt_qmpk.
ENDDO.

******IF lt_plmk[] IS NOT INITIAL.
******  SELECT a~zaehler,
******         a~mkmnr,
******         a~version,
******         a~toleranzob,
******         a~toleranzun,
******         b~kurztext
******    FROM qpmk AS a
******    INNER JOIN qpmt AS b ON
******            a~zaehler = b~zaehler AND
******            a~mkmnr   = b~mkmnr   AND
******            a~version = b~version
******    INTO TABLE @DATA(lt_qpdata)
******    FOR ALL ENTRIES IN @lt_plmk
******    WHERE a~zaehler = @wa_temp-werks
******      AND a~mkmnr   = @lt_plmk-verwmerkm.
******ENDIF.
