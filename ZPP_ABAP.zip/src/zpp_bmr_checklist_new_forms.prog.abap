*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_NEW_FORMS
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SAVE_PDF
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM save_pdf .
  IF lt_tbctrl[] IS NOT INITIAL.
    PERFORM build_checklist.
    PERFORM print.
  ELSE.
    MESSAGE 'Please Enter Correct Order Number to Print BMR Form' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_ORDERDATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_orderdata .
  IF p_aufnr IS NOT INITIAL.
    "Comment Start by Rahul Vasita on 07.06.2024 12:00:24
*    IF a = 'X'.
**      PERFORM down_attac. "Comment by Rahul Vasita on 06.06.2024 10:59:06
*    ENDIF.
    "Comment End by Rahul Vasita on 07.06.2024 12:00:24
    IF lv_flag = abap_false.
      REFRESH: lt_tbctrl[].
      PERFORM fetch_order_details CHANGING lt_tbctrl[].
    ENDIF.
    IF lt_tbctrl[] IS INITIAL.
      MESSAGE 'BMR Checklist Data Not Found' TYPE 'S' DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.
  ELSE.
    MESSAGE 'Please Enter Production Order Number' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FETCH_ORDER_DETAILS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_LT_LISTTAB[]  text
*----------------------------------------------------------------------*
FORM fetch_order_details  CHANGING p_lt_tbctrl LIKE lt_tbctrl.
  DATA: lv_base  TYPE stko-bmeng, "Added by Rahul Vasita on 18.06.2024 15:11:43
        lv_stlnr TYPE afko-stlnr, "Added by Rahul Vasita on 18.06.2024 15:11:43
        lv_batch TYPE afpo-psmng. "Added by Rahul Vasita on 18.06.2024 15:11:40
  REFRESH : it_afko[], it_rseb[] , it_makt[] , it_rseb1[] , it_rseb2[] , lt_listtab[].
  CLEAR : counter , counter1 , lv_stlnr.
  CLEAR: lv_base , lv_batch. "Added by Rahul Vasita on 18.06.2024 15:11:54

  SELECT aufnr rsnum FROM afko INTO TABLE it_afko WHERE aufnr = p_aufnr.

  IF it_afko IS NOT INITIAL.
    SELECT rsnum  matnr bdmng meins FROM resb INTO CORRESPONDING FIELDS OF TABLE it_rseb FOR ALL ENTRIES IN it_afko WHERE rsnum = it_afko-rsnum.
  ENDIF.

  SORT it_rseb BY rsnum matnr. "Added by Rahul Vasita on 21.06.2024 16:41:24

  IF p_aufnr IS NOT INITIAL.
    SELECT SINGLE charg FROM afpo INTO v_charg WHERE aufnr = p_aufnr.
    SELECT SINGLE gamng stlal gmein FROM afko INTO ( v_gamng ,v_stlal ,v_gmein )  WHERE aufnr = p_aufnr.
    SELECT SINGLE  charg FROM afpo INTO v_chargd WHERE aufnr = p_aufnr.
  ENDIF.

  SELECT SINGLE plnbez stlnr FROM afko INTO ( v_matnr , lv_stlnr ) WHERE aufnr = p_aufnr.
  wa_temp-matnr =   v_matnr.
*  SELECT SINGLE werks FROM afru INTO v_werks WHERE aufnr = p_aufnr. "Comment by Rahul Vasita on 17.06.2024 11:25:24

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE dwerk FROM afpo INTO v_werks WHERE aufnr = p_aufnr.

SELECT DWERK FROM AFPO INTO V_WERKS UP TO 1 ROWS WHERE AUFNR = P_AUFNR
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

  wa_temp-werks =  v_werks.

  SELECT SINGLE maktx FROM makt INTO v_maktx WHERE matnr = wa_temp-matnr.

  IF it_rseb IS NOT INITIAL.
    SELECT  matnr maktx FROM makt INTO CORRESPONDING FIELDS OF TABLE it_makt FOR ALL ENTRIES IN it_rseb WHERE matnr = it_rseb-matnr.
  ENDIF.

*  SELECT SINGLE psmng FROM afko INTO lv_batch WHERE aufnr = p_aufnr. "Comment by Rahul Vasita on 20.06.2024 11:02:45
  SELECT SINGLE gamng FROM afko INTO lv_batch WHERE aufnr = p_aufnr.


  SELECT SINGLE bmeng FROM stko INTO lv_base WHERE stlty = 'M' AND stlnr = lv_stlnr AND stlal = v_stlal.


  SORT it_rseb1 BY srno matnr bdmng. "Added by Rahul Vasita on 10.06.2024 12:32:56
  DELETE ADJACENT DUPLICATES FROM it_rseb1 COMPARING matnr bdmng. "Added by Rahul Vasita on 10.06.2024 12:32:57

  IF it_rseb IS NOT INITIAL.
    LOOP AT it_rseb INTO wa_rseb.
      counter = counter + 1.
      wa_rseb1-srno  =  counter.
      wa_rseb1-matnr  =  wa_rseb-matnr.
      wa_rseb1-bdmng =  wa_rseb-bdmng .
      wa_rseb1-meins  =  wa_rseb-meins.
      APPEND wa_rseb1 TO it_rseb1.
      CLEAR wa_rseb.
    ENDLOOP.
  ENDIF.

  IF it_makt IS NOT INITIAL.
    LOOP AT it_makt INTO wa_makt.
      counter1 =  counter1 + 1.
      wa_rseb2-srno  =  counter1.
      wa_rseb2-matnr  =   wa_makt-matnr.
      wa_rseb2-maktx =   wa_makt-maktx.
      APPEND wa_rseb2 TO it_rseb2.
      CLEAR wa_makt.
    ENDLOOP.
  ENDIF.


  IF wa_temp IS NOT INITIAL AND v_stlal IS NOT INITIAL.
    """added by akshay dt.15.07.2025
    IF wa_temp-werks+0(1) = '7'.
      SELECT SINGLE MAX( version ) AS lv_version FROM zpp_bmr_list
            INTO @DATA(lv_version)
            WHERE werks = @wa_temp-werks
              AND sf_matnr = @wa_temp-matnr.
      IF sy-subrc = 0.
        SELECT *
        FROM zpp_bmr_list
        INTO TABLE lt_listtab
        WHERE werks = wa_temp-werks
          AND sf_matnr = wa_temp-matnr AND version = lv_version.

      ENDIF.
      IF sy-subrc = 0.
        lv_flag = abap_true.
      ENDIF.

    ELSE. """end of changes by akshay dt.15.07.2025
      SELECT *
        FROM zpp_bmr_list
        INTO TABLE lt_listtab
        WHERE werks = wa_temp-werks
          AND sf_matnr = wa_temp-matnr.
*        AND stlal = v_stlal. """COMMENTED BY AKSHAY DT.06.05.2025
      IF sy-subrc = 0.
        lv_flag = abap_true.
      ENDIF.

    ENDIF. ""added by akshay dt.15.07.2025
    DATA: lv_flag TYPE i.
    lv_flag = 0.
    LOOP AT lt_listtab ASSIGNING FIELD-SYMBOL(<ls_listtab>).
      lv_flag = lv_flag + 1.
      ls_tbctrl-sr_no = lv_flag.
      IF <ls_listtab>-matnr IS NOT INITIAL.
        wa_rseb1-bdmng = VALUE #( it_rseb1[ matnr = <ls_listtab>-matnr ]-bdmng OPTIONAL ).
      ENDIF."      IF <ls_listtab>-matnr is NOT INITIAL.
      MOVE-CORRESPONDING <ls_listtab> TO ls_tbctrl.
      ls_tbctrl-stlal = v_stlal.  """ADDED BY AKSHAY DT.06.05.2025
      """added by akshay dt.15.09.2025
*      IF  wa_temp-werks+0(1) = '7'.
      CLEAR:lv_sum.
      LOOP AT it_rseb1 INTO wa_rseb_n.
        lv_sum = lv_sum + wa_rseb_n-bdmng.
      ENDLOOP.
      ls_tbctrl-std_qty =  (  lv_sum  * <ls_listtab>-contribution ) / 100.
*      ELSE.
*        ls_tbctrl-std_qty =  (  wa_rseb1-bdmng  * <ls_listtab>-contribution ) / 100. ""commented by akshay dt.15.09.2025
*      ENDIF.
      """end of by akshay dt.15.09.2025
*      ls_tbctrl-std_qty =  (  wa_rseb1-bdmng  * <ls_listtab>-contribution ) / 100.

      APPEND ls_tbctrl TO p_lt_tbctrl.
      CLEAR: ls_tbctrl , wa_rseb1.
    ENDLOOP.
  ENDIF."IF wa_temp IS NOT INITIAL AND v_stlal IS NOT INITIAL.

  DO 3 TIMES.
    APPEND INITIAL LINE TO it_rseb1.
  ENDDO.
ENDFORM.

*----------------------------------------------------------------------*
*   INCLUDE TABLECONTROL_FORMS                                         *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  USER_OK_TC                                               *
*&---------------------------------------------------------------------*
FORM user_ok_tc USING    p_tc_name TYPE dynfnam
                         p_table_name
                         p_mark_name
                CHANGING p_ok      LIKE sy-ucomm.

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA: l_ok     TYPE sy-ucomm,
        l_offset TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

*&SPWIZARD: Table control specific operations                          *
*&SPWIZARD: evaluate TC name and operations                            *
  SEARCH p_ok FOR p_tc_name.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.
  l_offset = strlen( p_tc_name ) + 1.
  l_ok = p_ok+l_offset.
*&SPWIZARD: execute general and TC specific operations                 *
  CASE l_ok.
    WHEN 'INSR'.                      "insert row
      PERFORM fcode_insert_row USING    p_tc_name
                                        p_table_name.
      CLEAR p_ok.

    WHEN 'DELE'.                      "delete row
      PERFORM fcode_delete_row USING    p_tc_name
                                        p_table_name
                                        p_mark_name.
      CLEAR p_ok.

    WHEN 'P--' OR                     "top of list
         'P-'  OR                     "previous page
         'P+'  OR                     "next page
         'P++'.                       "bottom of list
      PERFORM compute_scrolling_in_tc USING p_tc_name
                                            l_ok.
      CLEAR p_ok.
*     WHEN 'L--'.                       "total left
*       PERFORM FCODE_TOTAL_LEFT USING P_TC_NAME.
*
*     WHEN 'L-'.                        "column left
*       PERFORM FCODE_COLUMN_LEFT USING P_TC_NAME.
*
*     WHEN 'R+'.                        "column right
*       PERFORM FCODE_COLUMN_RIGHT USING P_TC_NAME.
*
*     WHEN 'R++'.                       "total right
*       PERFORM FCODE_TOTAL_RIGHT USING P_TC_NAME.
*
    WHEN 'MARK'.                      "mark all filled lines
      PERFORM fcode_tc_mark_lines USING p_tc_name
                                        p_table_name
                                        p_mark_name   .
      CLEAR p_ok.

    WHEN 'DMRK'.                      "demark all filled lines
      PERFORM fcode_tc_demark_lines USING p_tc_name
                                          p_table_name
                                          p_mark_name .
      CLEAR p_ok.

*     WHEN 'SASCEND'   OR
*          'SDESCEND'.                  "sort column
*       PERFORM FCODE_SORT_TC USING P_TC_NAME
*                                   l_ok.

  ENDCASE.

ENDFORM.                              " USER_OK_TC

*&---------------------------------------------------------------------*
*&      Form  FCODE_INSERT_ROW                                         *
*&---------------------------------------------------------------------*
FORM fcode_insert_row
              USING    p_tc_name           TYPE dynfnam
                       p_table_name             .

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_lines_name       LIKE feld-name.
  DATA l_selline          LIKE sy-stepl.
  DATA l_lastline         TYPE i.
  DATA l_line             TYPE i.
  DATA l_table_name       LIKE feld-name.
  FIELD-SYMBOLS <tc>                 TYPE cxtab_control.
  FIELD-SYMBOLS <table>              TYPE STANDARD TABLE.
  FIELD-SYMBOLS <lines>              TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: get looplines of TableControl                              *
  CONCATENATE 'G_' p_tc_name '_LINES' INTO l_lines_name.
  ASSIGN (l_lines_name) TO <lines>.

*&SPWIZARD: get current line                                           *
  GET CURSOR LINE l_selline.
  IF sy-subrc <> 0.                   " append line to table
    l_selline = <tc>-lines + 1.
*&SPWIZARD: set top line                                               *
    IF l_selline > <lines>.
      <tc>-top_line = l_selline - <lines> + 1 .
    ELSE.
      <tc>-top_line = 1.
    ENDIF.
  ELSE.                               " insert line into table
    l_selline = <tc>-top_line + l_selline - 1.
    l_lastline = <tc>-top_line + <lines> - 1.
  ENDIF.
*&SPWIZARD: set new cursor line                                        *
  l_line = l_selline - <tc>-top_line + 1.

*&SPWIZARD: insert initial line                                        *
  INSERT INITIAL LINE INTO <table> INDEX l_selline.
  <tc>-lines = <tc>-lines + 1.
*&SPWIZARD: set cursor                                                 *
  SET CURSOR 1 l_line.

ENDFORM.                              " FCODE_INSERT_ROW

*&---------------------------------------------------------------------*
*&      Form  FCODE_DELETE_ROW                                         *
*&---------------------------------------------------------------------*
FORM fcode_delete_row
              USING    p_tc_name           TYPE dynfnam
                       p_table_name
                       p_mark_name   .

*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: delete marked lines                                        *
  DESCRIBE TABLE <table> LINES <tc>-lines.

  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    IF <mark_field> = 'X'.
      DELETE <table> INDEX syst-tabix.
      IF sy-subrc = 0.
        <tc>-lines = <tc>-lines - 1.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                              " FCODE_DELETE_ROW

*&---------------------------------------------------------------------*
*&      Form  COMPUTE_SCROLLING_IN_TC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*      -->P_OK       ok code
*----------------------------------------------------------------------*
FORM compute_scrolling_in_tc USING    p_tc_name
                                      p_ok.
*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_tc_new_top_line     TYPE i.
  DATA l_tc_name             LIKE feld-name.
  DATA l_tc_lines_name       LIKE feld-name.
  DATA l_tc_field_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <lines>      TYPE i.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.
*&SPWIZARD: get looplines of TableControl                              *
  CONCATENATE 'G_' p_tc_name '_LINES' INTO l_tc_lines_name.
  ASSIGN (l_tc_lines_name) TO <lines>.


*&SPWIZARD: is no line filled?                                         *
  IF <tc>-lines = 0.
*&SPWIZARD: yes, ...                                                   *
    l_tc_new_top_line = 1.
  ELSE.
*&SPWIZARD: no, ...                                                    *
    CALL FUNCTION 'SCROLLING_IN_TABLE'
      EXPORTING
        entry_act      = <tc>-top_line
        entry_from     = 1
        entry_to       = <tc>-lines
        last_page_full = 'X'
        loops          = <lines>
        ok_code        = p_ok
        overlapping    = 'X'
      IMPORTING
        entry_new      = l_tc_new_top_line
      EXCEPTIONS
*       NO_ENTRY_OR_PAGE_ACT  = 01
*       NO_ENTRY_TO    = 02
*       NO_OK_CODE_OR_PAGE_GO = 03
        OTHERS         = 0.
  ENDIF.

*&SPWIZARD: get actual tc and column                                   *
  GET CURSOR FIELD l_tc_field_name
             AREA  l_tc_name.

  IF syst-subrc = 0.
    IF l_tc_name = p_tc_name.
*&SPWIZARD: et actual column                                           *
      SET CURSOR FIELD l_tc_field_name LINE 1.
    ENDIF.
  ENDIF.

*&SPWIZARD: set the new top line                                       *
  <tc>-top_line = l_tc_new_top_line.


ENDFORM.                              " COMPUTE_SCROLLING_IN_TC

*&---------------------------------------------------------------------*
*&      Form  FCODE_TC_MARK_LINES
*&---------------------------------------------------------------------*
*       marks all TableControl lines
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*----------------------------------------------------------------------*
FORM fcode_tc_mark_lines USING p_tc_name
                               p_table_name
                               p_mark_name.
*&SPWIZARD: EGIN OF LOCAL DATA-----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: mark all filled lines                                      *
  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    <mark_field> = 'X'.
  ENDLOOP.
ENDFORM.                                          "fcode_tc_mark_lines

*&---------------------------------------------------------------------*
*&      Form  FCODE_TC_DEMARK_LINES
*&---------------------------------------------------------------------*
*       demarks all TableControl lines
*----------------------------------------------------------------------*
*      -->P_TC_NAME  name of tablecontrol
*----------------------------------------------------------------------*
FORM fcode_tc_demark_lines USING p_tc_name
                                 p_table_name
                                 p_mark_name .
*&SPWIZARD: BEGIN OF LOCAL DATA----------------------------------------*
  DATA l_table_name       LIKE feld-name.

  FIELD-SYMBOLS <tc>         TYPE cxtab_control.
  FIELD-SYMBOLS <table>      TYPE STANDARD TABLE.
  FIELD-SYMBOLS <wa>.
  FIELD-SYMBOLS <mark_field>.
*&SPWIZARD: END OF LOCAL DATA------------------------------------------*

  ASSIGN (p_tc_name) TO <tc>.

*&SPWIZARD: get the table, which belongs to the tc                     *
  CONCATENATE p_table_name '[]' INTO l_table_name. "table body
  ASSIGN (l_table_name) TO <table>.                "not headerline

*&SPWIZARD: demark all filled lines                                    *
  LOOP AT <table> ASSIGNING <wa>.

*&SPWIZARD: access to the component 'FLAG' of the table header         *
    ASSIGN COMPONENT p_mark_name OF STRUCTURE <wa> TO <mark_field>.

    <mark_field> = space.
  ENDLOOP.
ENDFORM.                                          "fcode_tc_mark_lines
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  control_parameters-no_dialog = abap_true.
  control_parameters-getotf = abap_true.
  output-tddest = 'ZLP02'.
  "Adding End by Rahul Vasita on 03.05.2024 14:10:09

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
*     formname = 'ZPP_BMR_FORM_123' "Comment by Rahul Vasita on 02.05.2024 18:59:00
      formname = 'ZPP_BMR_FORM' "Added by Rahul Vasita on 02.05.2024 18:59:05
    IMPORTING
      fm_name  = v_fm_name.
  IF sy-subrc <> 0.
  ENDIF.

  CALL FUNCTION v_fm_name
    EXPORTING
      control_parameters = control_parameters
      output_options     = output
      aufnr_imp          = p_aufnr
      it_item            = it_rseb1
      it_itema           = it_rseb2
      wa_temp            = wa_temp
      v_gamng            = v_gamng
      v_stlal            = v_stlal
      v_gmein            = v_gmein
      v_chargd           = v_chargd
      v_maktx            = v_maktx
    IMPORTING
      job_output_info    = ls_otfdata.
*        v_con     = v_con. "Comment by Rahul Vasita on 02.05.2024 19:00:01
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

  lt_otf = ls_otfdata-otfdata[]. "Added by Rahul Vasita on 03.05.2024 14:18:16

  CALL FUNCTION 'CONVERT_OTF'
    EXPORTING
      format                = 'PDF'
      max_linewidth         = 132
    IMPORTING
      bin_filesize          = gv_bin_filesize
      bin_file              = lv_xstring1
    TABLES
      otf                   = lt_otf
      lines                 = lt_pdf_tab
    EXCEPTIONS
      err_max_linewidth     = 1
      err_format            = 2
      err_conv_not_possible = 3
      OTHERS                = 4.

  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

  ENDIF.

  IF lt_checklist[] IS NOT INITIAL.


    CLEAR : v_fm_name , gv_bin_filesize , ls_otfdata.
    REFRESH : lt_pdf_tab[] , lt_otf[].
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
*       formname = 'ZPP_BMR_FORM_123' "Comment by Rahul Vasita on 02.05.2024 18:59:00
        formname = 'ZPP_BMR_CHECKLIST_FORM' "Added by Rahul Vasita on 02.05.2024 18:59:05
**formname = 'ZPP_BMR_CHECKLIST_FORM1' "Added by Rahul Vasita on 02.05.2024 18:59:05
      IMPORTING
        fm_name  = v_fm_name.
    IF sy-subrc <> 0.
    ENDIF.

    CALL FUNCTION v_fm_name "'/1BCDWB/SF00000573'
      EXPORTING
        control_parameters = control_parameters
        output_options     = output
        wa_temp            = wa_temp
        aufnr_imp          = p_aufnr
        v_chargd           = v_chargd
        v_maktx            = v_maktx
        v_stlal            = v_stlal
      IMPORTING
        job_output_info    = ls_otfdata
      TABLES
        lt_checklist       = lt_checklist[]
      EXCEPTIONS
        formatting_error   = 1
        internal_error     = 2
        send_error         = 3
        user_canceled      = 4
        OTHERS             = 5.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.


    lt_otf = ls_otfdata-otfdata[]. "Added by Rahul Vasita on 03.05.2024 14:18:16

    CALL FUNCTION 'CONVERT_OTF'
      EXPORTING
        format                = 'PDF'
        max_linewidth         = 132
      IMPORTING
        bin_filesize          = gv_bin_filesize
        bin_file              = lv_xstring2
      TABLES
        otf                   = lt_otf
        lines                 = lt_pdf_tab
      EXCEPTIONS
        err_max_linewidth     = 1
        err_format            = 2
        err_conv_not_possible = 3
        OTHERS                = 4.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

    ENDIF.
    REFRESH : lt_otf[] , lt_pdf_tab[].
  ENDIF."IF lt_checklist[] IS NOT INITIAL.
  TRY.
      CREATE OBJECT pdf_merger.
    CATCH cx_rspo_pdf_merge INTO ex.
      lv_ex_txt = ex->get_text( ).
*      write: / lv_ex_txt color col_negative.
      rc = 1.
      RETURN.

  ENDTRY.
  IF rc = 0.


    pdf_merger->check_document( EXPORTING document = lv_xstring1 IMPORTING error_text = error_text rc = rc ).
    IF rc = 0.
      pdf_merger->add_document( lv_xstring1 ).
    ENDIF.
    CLEAR : rc.

    pdf_merger->check_document( EXPORTING document = lv_xstring2 IMPORTING error_text = error_text rc = rc ).
    IF rc = 0.
      pdf_merger->add_document( lv_xstring2 ).
    ENDIF.
    CLEAR : rc.

    pdf_merger->merge_documents( IMPORTING merged_document = merged_document rc = rc ).

    IF rc <> 0.
      pdf_merger->get_err_doc_index( IMPORTING index = docindex ).
      pdf_merger->get_document( EXPORTING index = docindex IMPORTING document = errordoc ).
      pdf_merger->get_last_error_text( CHANGING error_text = error_text ).
    ELSE.
      PERFORM save_pdf_desktop USING merged_document. "Added by Rahul Vasita on 03.05.2024 14:44:00
    ENDIF.
  ENDIF."IF rc = 0.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SAVE_PDF_DESKTOP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_MERGED_DOCUMENT  text
*----------------------------------------------------------------------*
FORM save_pdf_desktop  USING    merged_document TYPE xstring.
  DATA: bin_tab TYPE STANDARD TABLE OF tabl1024.
  DATA: lo_gui TYPE REF TO cl_gui_frontend_services.
  DATA: path     TYPE string, fullpath TYPE string.
  DATA: length TYPE i.
  DATA: filter TYPE string, uact TYPE i, name TYPE string.

  CREATE OBJECT lo_gui.
  CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
    EXPORTING
      buffer        = merged_document
    IMPORTING
      output_length = length
    TABLES
      binary_tab    = bin_tab.

  CALL METHOD lo_gui->file_save_dialog
    EXPORTING
      default_extension = 'pdf'
      default_file_name = 'BMR_' && p_aufnr && '.pdf'
      file_filter       = filter
    CHANGING
      filename          = name
      path              = path
      fullpath          = fullpath
      user_action       = uact.
  IF uact = lo_gui->action_cancel.
    EXIT.
  ENDIF.

  lo_gui->gui_download( EXPORTING
                          filename = fullpath
                          filetype = 'BIN'
                          bin_filesize = length
                        CHANGING
                          data_tab = bin_tab ).
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_CHECKLIST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_checklist .
  DATA : lt_trans TYPE TABLE OF zpp_bmr_list_t,
         ls_trans TYPE zpp_bmr_list_t.
  REFRESH: lt_trans[] , lt_checklist[].
  LOOP AT lt_tbctrl INTO ls_tbctrl.
    MOVE-CORRESPONDING : ls_tbctrl TO ls_checklist,
                         ls_tbctrl TO ls_trans.

    APPEND :ls_checklist TO lt_checklist,
            ls_trans TO lt_trans.
    CLEAR: ls_checklist , ls_tbctrl , ls_trans.
  ENDLOOP.
  MODIFY zpp_bmr_list_t FROM TABLE lt_trans[].
  IF sy-subrc = 0.
    COMMIT WORK.
    MESSAGE 'DATA ADDED TO TRANSACTIONAL TABLE' TYPE 'S'.
  ELSE.
    ROLLBACK WORK.
    MESSAGE 'ERROR WHILE UPDATING TRANSACTIONAL DATA' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SAVE_PDF_P
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM save_pdf_p .
  IF lt_tbctrl[] IS NOT INITIAL.
    PERFORM build_checklist_n.
    PERFORM print_n.
  ELSE.
    MESSAGE 'Please Enter Correct Order Number to Print BMR Form' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_CHECKLIST_N
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_checklist_n .
  DATA : lt_trans TYPE TABLE OF zpp_bmr_list_t,
         ls_trans TYPE zpp_bmr_list_t.
  REFRESH: lt_trans[] , lt_checklist[].
  LOOP AT lt_tbctrl INTO ls_tbctrl.
    MOVE-CORRESPONDING : ls_tbctrl TO ls_checklist,
                         ls_tbctrl TO ls_trans.

    APPEND :ls_checklist TO lt_checklist,
            ls_trans TO lt_trans.
    CLEAR: ls_checklist , ls_tbctrl , ls_trans.
  ENDLOOP.
  MODIFY zpp_bmr_list_t FROM TABLE lt_trans[].
  IF sy-subrc = 0.
    COMMIT WORK.
    MESSAGE 'DATA ADDED TO TRANSACTIONAL TABLE' TYPE 'S'.
  ELSE.
    ROLLBACK WORK.
    MESSAGE 'ERROR WHILE UPDATING TRANSACTIONAL DATA' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_N
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print_n .
  control_parameters-no_dialog = abap_true.
  control_parameters-getotf = abap_true.
  output-tddest = 'ZLP02'.
  "Adding End by Rahul Vasita on 03.05.2024 14:10:09

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
*     formname = 'ZPP_BMR_FORM_123' "Comment by Rahul Vasita on 02.05.2024 18:59:00
      formname = 'ZPP_BMR_FORM_P' "Added by Rahul Vasita on 02.05.2024 18:59:05
    IMPORTING
      fm_name  = v_fm_name.
  IF sy-subrc <> 0.
  ENDIF.

  CALL FUNCTION v_fm_name
    EXPORTING
      control_parameters = control_parameters
      output_options     = output
      aufnr_imp          = p_aufnr
      it_item            = it_rseb1
      it_itema           = it_rseb2
      wa_temp            = wa_temp
      v_gamng            = v_gamng
      v_stlal            = v_stlal
      v_gmein            = v_gmein
      v_chargd           = v_chargd
      v_maktx            = v_maktx
    IMPORTING
      job_output_info    = ls_otfdata.
*        v_con     = v_con. "Comment by Rahul Vasita on 02.05.2024 19:00:01
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

  DO 2 TIMES.
    APPEND LINES OF ls_otfdata-otfdata[] TO  lt_otf.
*  lt_otf = ls_otfdata-otfdata[]. "Added by Rahul Vasita on 03.05.2024 14:18:16
  ENDDO.

  CALL FUNCTION 'CONVERT_OTF'
    EXPORTING
      format                = 'PDF'
      max_linewidth         = 132
    IMPORTING
      bin_filesize          = gv_bin_filesize
      bin_file              = lv_xstring1
    TABLES
      otf                   = lt_otf
      lines                 = lt_pdf_tab
    EXCEPTIONS
      err_max_linewidth     = 1
      err_format            = 2
      err_conv_not_possible = 3
      OTHERS                = 4.

  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

  ENDIF.

  IF lt_checklist[] IS NOT INITIAL.


    CLEAR : v_fm_name , gv_bin_filesize , ls_otfdata.
    REFRESH : lt_pdf_tab[] , lt_otf[].
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
*       formname = 'ZPP_BMR_FORM_123' "Comment by Rahul Vasita on 02.05.2024 18:59:00
        formname = 'ZPP_BMR_CHECKLIST_FORM_P' "Added by Rahul Vasita on 02.05.2024 18:59:05
**formname = 'ZPP_BMR_CHECKLIST_FORM1' "Added by Rahul Vasita on 02.05.2024 18:59:05
      IMPORTING
        fm_name  = v_fm_name.
    IF sy-subrc <> 0.
    ENDIF.

    CALL FUNCTION v_fm_name "'/1BCDWB/SF00000573'
      EXPORTING
        control_parameters = control_parameters
        output_options     = output
        wa_temp            = wa_temp
        aufnr_imp          = p_aufnr
        v_chargd           = v_chargd
        v_maktx            = v_maktx
        v_stlal            = v_stlal
        v_gamng            = v_gamng
        v_gmein            = v_gmein
      IMPORTING
        job_output_info    = ls_otfdata
      TABLES
        lt_checklist       = lt_checklist[]
      EXCEPTIONS
        formatting_error   = 1
        internal_error     = 2
        send_error         = 3
        user_canceled      = 4
        OTHERS             = 5.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.


    lt_otf = ls_otfdata-otfdata[]. "Added by Rahul Vasita on 03.05.2024 14:18:16

    CALL FUNCTION 'CONVERT_OTF'
      EXPORTING
        format                = 'PDF'
        max_linewidth         = 132
      IMPORTING
        bin_filesize          = gv_bin_filesize
        bin_file              = lv_xstring2
      TABLES
        otf                   = lt_otf
        lines                 = lt_pdf_tab
      EXCEPTIONS
        err_max_linewidth     = 1
        err_format            = 2
        err_conv_not_possible = 3
        OTHERS                = 4.

    IF sy-subrc <> 0.

      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

    ENDIF.
    REFRESH : lt_otf[] , lt_pdf_tab[].
  ENDIF."IF lt_checklist[] IS NOT INITIAL.
  TRY.
      CREATE OBJECT pdf_merger.
    CATCH cx_rspo_pdf_merge INTO ex.
      lv_ex_txt = ex->get_text( ).
*      write: / lv_ex_txt color col_negative.
      rc = 1.
      RETURN.

  ENDTRY.
  IF rc = 0.


    pdf_merger->check_document( EXPORTING document = lv_xstring1 IMPORTING error_text = error_text rc = rc ).
    IF rc = 0.
      pdf_merger->add_document( lv_xstring1 ).
    ENDIF.
    CLEAR : rc.

    pdf_merger->check_document( EXPORTING document = lv_xstring2 IMPORTING error_text = error_text rc = rc ).
    IF rc = 0.
      pdf_merger->add_document( lv_xstring2 ).
    ENDIF.
    CLEAR : rc.

    pdf_merger->merge_documents( IMPORTING merged_document = merged_document rc = rc ).

    IF rc <> 0.
      pdf_merger->get_err_doc_index( IMPORTING index = docindex ).
      pdf_merger->get_document( EXPORTING index = docindex IMPORTING document = errordoc ).
      pdf_merger->get_last_error_text( CHANGING error_text = error_text ).
    ELSE.
      PERFORM save_pdf_desktop USING merged_document. "Added by Rahul Vasita on 03.05.2024 14:44:00
    ENDIF.
  ENDIF."IF rc = 0.
ENDFORM.
