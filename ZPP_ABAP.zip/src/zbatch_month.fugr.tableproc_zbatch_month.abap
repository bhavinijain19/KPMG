*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBATCH_MONTH
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBATCH_MONTH        .

  PERFORM TABLEPROC.

ENDFUNCTION.
