*&---------------------------------------------------------------------*
*&  Include           ZMM_BOM_REPORT_SEL
*&---------------------------------------------------------------------*


SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_matnr FOR mast-matnr.
SELECT-OPTIONS : s_werks FOR mast-werks OBLIGATORY.
SELECT-OPTIONS : s_stlal FOR stko-stlal OBLIGATORY.
PARAMETERS  : s_stlst type stko-stlst OBLIGATORY ."Added by Raj on 11.10.2023
PARAMETERS  : p_aedat type mast-aedat.
SELECTION-SCREEN : END OF BLOCK b1.
