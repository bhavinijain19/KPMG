*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_CONT_VALUES.................................*
DATA:  BEGIN OF STATUS_ZPP_CONT_VALUES               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_CONT_VALUES               .
CONTROLS: TCTRL_ZPP_CONT_VALUES
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZPP_CONT_VALUES               .
TABLES: ZPP_CONT_VALUES                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
