
*&---------------------------------------------------------------------*
*&  Include          ZPP_RESOURCE_UPLOAD_TOP
*&---------------------------------------------------------------------*

*=====================================================================*
* Types
*=====================================================================*

* Upload structure: order aligned to "Workcenter Upload" sheet columns.
* Mapping is by column position (TEXT_CONVERT_XLS_TO_SAP with header line).
* Keep lengths simple (char) to avoid short dumps on text cells.
TYPES: BEGIN OF st_upload,
  "Header / Defaults"
  werks     TYPE c LENGTH 4,     "Plant
  arbpl     TYPE c LENGTH 18,    "Resource (allow longer names safely)
  verwe     TYPE c LENGTH 4,     "Resource category
  stext     TYPE c LENGTH 40,    "Description
  veran     TYPE c LENGTH 3,     "Person responsible
  planv     TYPE c LENGTH 3,     "Usage
  vgwts     TYPE c LENGTH 10,    "Std value key
  rgekz     TYPE c LENGTH 1,     "Backflush (X/blank)
  steus     TYPE c LENGTH 4,     "Control key

  "Capacity 1 (position 01) - as per sheet"
  kapart1   TYPE c LENGTH 3,
  ktext1    TYPE c LENGTH 40,
  planr1    TYPE c LENGTH 3,
  mosid1    TYPE c LENGTH 3,     "Grouping for shift
  kalid1    TYPE c LENGTH 3,     "Factory calendar
  versa1    TYPE c LENGTH 3,     "Active version
  meins1    TYPE c LENGTH 6,     "Unit
  ngrad1    TYPE c LENGTH 5,     "Utilization %
  aznor1    TYPE c LENGTH 5,     "No. indiv. cap.
  kapter1   TYPE c LENGTH 1,     "Finite scheduling (X/blank)
  datuv1    TYPE c LENGTH 10,    "Valid from (dd.mm.yyyy)
  datub1    TYPE c LENGTH 10,    "Valid to   (dd.mm.yyyy)
  sprog1    TYPE c LENGTH 3,     "Shift Sequence
  anztg1    TYPE c LENGTH 3,     "Length of cycle
  anzsh1    TYPE c LENGTH 3,     "Number of shifts
  fabtg1    TYPE c LENGTH 3,     "Work days
  fork1a_1  TYPE c LENGTH 20,    "Setup formula key (line 1)
  fork1b_1  TYPE c LENGTH 20,    "Processing formula key (line 1)
  fork2_1   TYPE c LENGTH 20,    "Teardown formula key (line 1)

  "Capacity 2 (position 02) - as per sheet"
  kapart2   TYPE c LENGTH 3,
  ktext2    TYPE c LENGTH 40,
  planr2    TYPE c LENGTH 3,
  kalid2    TYPE c LENGTH 3,
  versa2    TYPE c LENGTH 3,
  meins2    TYPE c LENGTH 6,
  begzt2    TYPE c LENGTH 8,     "hh:mm:ss
  endzt2    TYPE c LENGTH 8,
  pause2    TYPE c LENGTH 8,
  ngrad2    TYPE c LENGTH 5,
  aznor2    TYPE c LENGTH 5,
  kapter2   TYPE c LENGTH 1,
  fork1a_2  TYPE c LENGTH 20,
  fork1b_2  TYPE c LENGTH 20,
  fork2_2   TYPE c LENGTH 20,

  "Scheduling capacity block (present in sheet; optional in BDC)"
  sched_kapart TYPE c LENGTH 3,
  fort1        TYPE c LENGTH 10,
  fort2        TYPE c LENGTH 10,
  fort3        TYPE c LENGTH 10,

  "Costing"
  kostl     TYPE c LENGTH 20,

  "Formulas – 6 pairs (LARXX/FORXX)"
  lar1      TYPE c LENGTH 10,  lar2 TYPE c LENGTH 10,
  lar3      TYPE c LENGTH 10,  lar4 TYPE c LENGTH 10,
  lar5      TYPE c LENGTH 10,  lar6 TYPE c LENGTH 10,
  for1      TYPE c LENGTH 10,  for2 TYPE c LENGTH 10,
  for3      TYPE c LENGTH 10,  for4 TYPE c LENGTH 10,
  for5      TYPE c LENGTH 10,  for6 TYPE c LENGTH 10,
END OF st_upload.

* Log line
TYPES: BEGIN OF st_log,
  werks    TYPE c LENGTH 4,
  arbpl    TYPE c LENGTH 18,
  status   TYPE c LENGTH 10,
  message  TYPE string,
END OF st_log.

*=====================================================================*
* Data
*=====================================================================*
DATA: it_upload TYPE STANDARD TABLE OF st_upload,
      wa_upload TYPE st_upload.

DATA: it_log TYPE STANDARD TABLE OF st_log,
      wa_log TYPE st_log.

DATA: bdcdata TYPE STANDARD TABLE OF bdcdata,
      messtab TYPE STANDARD TABLE OF bdcmsgcoll.

* Button text holder (selection screen pushbutton)
*DATA: pb_ctmpl TYPE c LENGTH 30.

*=====================================================================*
* Constants
*=====================================================================*
CONSTANTS: c_create TYPE c VALUE 'X'.
