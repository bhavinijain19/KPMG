*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_REASON
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_REASON          .

  PERFORM TABLEPROC.

ENDFUNCTION.
