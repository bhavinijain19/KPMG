*&---------------------------------------------------------------------*
*& Report ZPP_DEPENDENCY_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZPP_DEPENDENCY_UPLOAD.


INCLUDE zpp_dependency_upload_top.
INCLUDE zpp_dependency_upload_sel.
INCLUDE zpp_dependency_upload_f01.

"---------------- Selection-Screen Events ----------------"
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  PERFORM f4_file.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'TMPL'.  " Download template based on selected radio
      PERFORM download_template_xls.
  ENDCASE.

"---------------- Main Flow ----------------"
START-OF-SELECTION.
  PERFORM determine_scenario.
  IF gv_scen IS INITIAL.
    MESSAGE 'Please select a scenario (Create/Editor/Status)' TYPE 'E'.
  ENDIF.

  IF p_file IS INITIAL.
    MESSAGE 'Please select an input file to upload.' TYPE 'E'.
  ENDIF.

  PERFORM precheck_file_exist USING p_file.
  PERFORM upload_file.
  PERFORM validate_rows.
  PERFORM process_records.
  PERFORM build_fieldcatalog.
  PERFORM show_alv.
