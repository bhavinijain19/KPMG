*&---------------------------------------------------------------------*
*& Include          ZXCO1U12
*&---------------------------------------------------------------------*
*E_COCI_AUFK-dumm
*MOVE     wa_afru-zzlot1  TO es_afrud-zzlot1 .
*VALUE(E_COCI_AUFK) LIKE  COCI_AUFK STRUCTURE  COCI_AUFK

E_COCI_AUFK-zorder_flow = AUFK-zorder_flow .
