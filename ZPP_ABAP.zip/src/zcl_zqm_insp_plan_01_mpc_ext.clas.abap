CLASS zcl_zqm_insp_plan_01_mpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_zqm_insp_plan_01_mpc
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_s_deep_plan.
        INCLUDE TYPE zcl_zqm_insp_plan_01_mpc=>ts_header.
    TYPES: fsspecification_customattrib TYPE zcl_zqm_insp_plan_01_mpc=>ts_customattrib,
        fsspecificationst            TYPE STANDARD TABLE OF zcl_zqm_insp_plan_01_mpc=>ts_specificationst WITH DEFAULT KEY,
        fsspecificationtp            TYPE STANDARD TABLE OF zcl_zqm_insp_plan_01_mpc=>ts_specificationtp WITH DEFAULT KEY,
        messages                     TYPE STANDARD TABLE OF zcl_zqm_insp_plan_01_mpc=>ts_messages WITH DEFAULT KEY,
      END OF ty_s_deep_plan .

    METHODS define
        REDEFINITION .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZQM_INSP_PLAN_01_MPC_EXT IMPLEMENTATION.


  method DEFINE.
    super->define( ). " Keeps existing SEGW definitions

  " Link your Header entity to your Deep ABAP structure
  DATA(lo_entity) = model->get_entity_type( 'Header' ).
  lo_entity->bind_structure( 'ZCL_ZQM_INSP_PLAN_01_MPC_EXT=>TY_S_DEEP_PLAN' ).
  endmethod.
ENDCLASS.
