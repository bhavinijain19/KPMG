
*&---------------------------------------------------------------------*
*& Include          ZPP_DEPENDENCY_UPLOAD_F01
*&---------------------------------------------------------------------*

*-----------------------*
* Scenario determination
*-----------------------*
FORM determine_scenario.
  IF p_cre  = 'X'. gv_scen = 'CREATE'. ENDIF.
  IF p_edit = 'X'. gv_scen = 'EDITOR'. ENDIF.
  IF p_stat = 'X'. gv_scen = 'STATUS'. ENDIF.
ENDFORM.

*-----------------------*
* File F4 help
*-----------------------*
FORM f4_file.
  CALL FUNCTION 'F4_FILENAME'
    IMPORTING file_name = p_file.
ENDFORM.

*---------------------------------------------------------------------*
* Template Download (unchanged)
*---------------------------------------------------------------------*
FORM download_template_xls.
  " NO CHANGE HERE (works fine)
  DATA: lv_fname TYPE string, lv_path TYPE string, lv_full TYPE string.

  TYPES: BEGIN OF ty_template,
           col1 TYPE string,
           col2 TYPE string,
           col3 TYPE string,
         END OF ty_template.

  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  IF p_cre = 'X'.
    ls_template-col1 = 'Dependency Name'.
    ls_template-col2 = 'Dependency Description'.
    ls_template-col3 = 'Dependency Type'.
  ELSEIF p_edit = 'X'.
    ls_template-col1 = 'Sr No'.
    ls_template-col2 = 'Dependency Name'.
    ls_template-col3 = 'Source'.
  ELSEIF p_stat = 'X'.
    ls_template-col1 = 'Dependency Name'.
    ls_template-col2 = 'Status'.
    CLEAR ls_template-col3.
  ELSE.
    MESSAGE 'Please select a scenario before downloading template.' TYPE 'E'.
    RETURN.
  ENDIF.

  APPEND ls_template TO lt_template.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      default_extension = 'xls'
      default_file_name = COND string(
                             WHEN p_cre  = 'X' THEN 'Dependency_Create_Template.xls'
                             WHEN p_edit = 'X' THEN 'Dependency_Editor_Template.xls'
                             WHEN p_stat = 'X' THEN 'Dependency_Status_Template.xls' )
    CHANGING
      filename          = lv_fname
      path              = lv_path
      fullpath          = lv_full.

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      filename              = lv_full
      filetype              = 'ASC'
      write_field_separator = 'X'
    CHANGING
      data_tab              = lt_template.

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.
ENDFORM.

*---------------------------------------------------------------------*
* Check file exists
*---------------------------------------------------------------------*
FORM precheck_file_exist USING pv_file TYPE localfile.
  DATA lv_exists TYPE abap_bool.

  CALL METHOD cl_gui_frontend_services=>file_exist
    EXPORTING file   = CONV #( pv_file )
    RECEIVING result = lv_exists.

  IF lv_exists IS INITIAL.
    MESSAGE 'Selected file does not exist on frontend.' TYPE 'E'.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
* Upload File
*---------------------------------------------------------------------*
FORM upload_file.

  DATA: lt_excel TYPE STANDARD TABLE OF alsmex_tabline.

  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
    EXPORTING
      filename    = p_file
      i_begin_col = 1
      i_begin_row = 1
      i_end_col   = 50
      i_end_row   = 9999
    TABLES
      intern      = lt_excel
    EXCEPTIONS
      OTHERS      = 3.

  IF sy-subrc <> 0 OR lt_excel IS INITIAL.
    MESSAGE 'File upload failed. Ensure the file is a valid Excel (.xls).' TYPE 'E'.
  ENDIF.

  CASE gv_scen.
    WHEN 'CREATE'.
      PERFORM fill_create_table USING lt_excel[].
    WHEN 'EDITOR'.
      PERFORM fill_editor_table USING lt_excel[].
    WHEN 'STATUS'.
      PERFORM fill_status_table USING lt_excel[].
  ENDCASE.

ENDFORM.

*---------------------------------------------------------------------*
* Fill CREATE table
*---------------------------------------------------------------------*
FORM fill_create_table USING pt_excel TYPE STANDARD TABLE.

  DATA: ls_excel TYPE alsmex_tabline,
        ls_row   TYPE ty_cre,
        lv_row   TYPE i.

  CLEAR gt_cre_up.

  LOOP AT pt_excel INTO ls_excel.
    IF ls_excel-row = 1. CONTINUE. ENDIF.

    IF lv_row = 0 OR lv_row <> ls_excel-row.
      IF lv_row <> 0.
        APPEND ls_row TO gt_cre_up.
      ENDIF.
      CLEAR ls_row.
      lv_row = ls_excel-row.
    ENDIF.

    CASE ls_excel-col.
      WHEN 1. ls_row-dep_name = ls_excel-value.
      WHEN 2. ls_row-dep_desc = ls_excel-value.
      WHEN 3. ls_row-dep_type = ls_excel-value.
    ENDCASE.
  ENDLOOP.

  IF lv_row > 1.
    APPEND ls_row TO gt_cre_up.
  ENDIF.

ENDFORM.

*---------------------------------------------------------------------*
* Fill EDITOR table
*---------------------------------------------------------------------*
FORM fill_editor_table USING pt_excel TYPE STANDARD TABLE.

  DATA: ls_excel TYPE alsmex_tabline,
        ls_row   TYPE ty_edit,
        lv_row   TYPE i.

  CLEAR gt_edit_up.

  LOOP AT pt_excel INTO ls_excel.
    IF ls_excel-row = 1. CONTINUE. ENDIF.

    IF lv_row = 0 OR lv_row <> ls_excel-row.
      IF lv_row <> 0.
        APPEND ls_row TO gt_edit_up.
      ENDIF.
      CLEAR ls_row.
      lv_row = ls_excel-row.
    ENDIF.

    CASE ls_excel-col.
      WHEN 1. ls_row-srno     = CONV i( ls_excel-value ).
      WHEN 2. ls_row-dep_name = ls_excel-value.
      WHEN 3. ls_row-source   = ls_excel-value.
    ENDCASE.
  ENDLOOP.

  IF lv_row > 1.
    APPEND ls_row TO gt_edit_up.
  ENDIF.

ENDFORM.

*---------------------------------------------------------------------*
* Fill STATUS table
*---------------------------------------------------------------------*
FORM fill_status_table USING pt_excel TYPE STANDARD TABLE.

  DATA: ls_excel TYPE alsmex_tabline,
        ls_row   TYPE ty_stat,
        lv_row   TYPE i.

  CLEAR gt_stat_up.

  LOOP AT pt_excel INTO ls_excel.
    IF ls_excel-row = 1. CONTINUE. ENDIF.

    IF lv_row = 0 OR lv_row <> ls_excel-row.
      IF lv_row <> 0.
        APPEND ls_row TO gt_stat_up.
      ENDIF.
      CLEAR ls_row.
      lv_row = ls_excel-row.
    ENDIF.

    CASE ls_excel-col.
      WHEN 1. ls_row-dep_name = ls_excel-value.
      WHEN 2. ls_row-status   = ls_excel-value.
    ENDCASE.
  ENDLOOP.

  IF lv_row > 1.
    APPEND ls_row TO gt_stat_up.
  ENDIF.

ENDFORM.

*---------------------------------------------------------------------*
* VALIDATION
*---------------------------------------------------------------------*
FORM validate_rows.
  DATA lv_row TYPE i.

  CASE gv_scen.

    WHEN 'CREATE'.
      LOOP AT gt_cre_up ASSIGNING FIELD-SYMBOL(<c>).
        lv_row = sy-tabix + 1.
        IF <c>-dep_name IS INITIAL OR <c>-dep_type IS INITIAL.
          APPEND VALUE ty_msg(
              row_no   = lv_row
              scen     = gv_scen
              dep_name = <c>-dep_name
              input1   = <c>-dep_type
              mtype    = 'E'
              mtext    = 'Missing required fields (Name/Type).'
          ) TO gt_msgs.
          DELETE gt_cre_up INDEX sy-tabix.
        ENDIF.
      ENDLOOP.

    WHEN 'EDITOR'.
      LOOP AT gt_edit_up ASSIGNING FIELD-SYMBOL(<e>).
        lv_row = sy-tabix + 1.
        IF <e>-dep_name IS INITIAL OR <e>-source IS INITIAL OR <e>-srno <= 0.
          APPEND VALUE ty_msg(
              row_no   = lv_row
              scen     = gv_scen
              dep_name = <e>-dep_name
              input1   = <e>-source
              mtype    = 'E'
              mtext    = 'Invalid row.'
          ) TO gt_msgs.
          DELETE gt_edit_up INDEX sy-tabix.
        ENDIF.
      ENDLOOP.

    WHEN 'STATUS'.
      LOOP AT gt_stat_up ASSIGNING FIELD-SYMBOL(<s>).
        lv_row = sy-tabix + 1.
        IF <s>-dep_name IS INITIAL.
          APPEND VALUE ty_msg(
              row_no   = lv_row
              scen     = gv_scen
              dep_name = <s>-dep_name
              input1   = <s>-status
              mtype    = 'E'
              mtext    = 'Dependency Name is required.'
          ) TO gt_msgs.
          DELETE gt_stat_up INDEX sy-tabix.
*        ELSE.
*          <s>-status = '3'.
        ENDIF.
      ENDLOOP.

  ENDCASE.
ENDFORM.

*---------------------------------------------------------------------*
* PROCESS – ADD ROW NUMBER + DIRECT MESSAGE APPEND
*---------------------------------------------------------------------*
FORM process_records.

  CASE gv_scen.

    WHEN 'CREATE'.
      LOOP AT gt_cre_up ASSIGNING FIELD-SYMBOL(<c>).
        gv_row = sy-tabix + 1.   " <-- ADDED
        PERFORM call_bapi_create USING <c>-dep_name <c>-dep_desc <c>-dep_type.
      ENDLOOP.

    WHEN 'EDITOR'.
      LOOP AT gt_edit_up ASSIGNING FIELD-SYMBOL(<e>).
        gv_row = sy-tabix + 1.   " <-- ADDED
        PERFORM call_bapi_editor USING <e>-dep_name <e>-source <e>-srno.
      ENDLOOP.

    WHEN 'STATUS'.
      LOOP AT gt_stat_up ASSIGNING FIELD-SYMBOL(<s>).
        gv_row = sy-tabix + 1.   " <-- ADDED
        PERFORM call_bapi_status USING <s>-dep_name <s>-status.
      ENDLOOP.

  ENDCASE.

ENDFORM.

*---------------------------------------------------------------------*
* BAPI: CREATE  (ALV message logic added ONLY)
*---------------------------------------------------------------------*
FORM call_bapi_create USING pv_name TYPE string pv_desc TYPE string pv_type TYPE string.

  " --- existing variables (UNCHANGED) ---
  DATA: ls_dep_data LIKE depdat,
        lv_dependency TYPE dep_ident-dep_extern,
        lt_desc TYPE STANDARD TABLE OF depdescr,
        ls_desc TYPE depdescr,
        lt_sourc TYPE STANDARD TABLE OF depsource.

  lv_dependency = pv_name.
  ls_dep_data-dep_type = pv_type.
  ls_dep_data-status   = '3'.

  CLEAR ls_desc.
  ls_desc-language = 'EN'.
  ls_desc-descript = pv_desc.
  APPEND ls_desc TO lt_desc.

  CALL FUNCTION 'CAMA_DEPENDENCY_MAINTAIN'
    EXPORTING
      dependency      = lv_dependency
      dependency_data = ls_dep_data
      commit_and_wait = 'X'
    TABLES
      description     = lt_desc
      source          = lt_sourc
    EXCEPTIONS
      warning         = 1
      error           = 2
      OTHERS          = 3.

  " -----------------------------------------------------------------
  " ADDED: Direct ALV logging (super simple, no RETURN, no collect)
  " -----------------------------------------------------------------
  DATA: ls_msg TYPE ty_msg,
        lv_text TYPE string.

  IF sy-subrc = 0.
    ls_msg-mtype = 'S'.
    lv_text      = 'Dependency created successfully'.
  ELSE.
    ls_msg-mtype = 'E'.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_text.
  ENDIF.

  ls_msg-row_no   = gv_row.
  ls_msg-scen     = 'CREATE'.
  ls_msg-dep_name = pv_name.
  ls_msg-input1   = pv_type.
  ls_msg-mtext    = lv_text.

  APPEND ls_msg TO gt_msgs.

ENDFORM.

*---------------------------------------------------------------------*
* BAPI: EDITOR (ALV message logic added)
*---------------------------------------------------------------------*


*---------------------------------------------------------------------*
* BAPI: EDITOR (Group multiple source lines per dependency)
*---------------------------------------------------------------------*
FORM call_bapi_editor USING pv_name   TYPE string
                             pv_source TYPE string
                             pv_srno   TYPE i.

  " -------------------------------------------------------------------
  " NEW: Skip if this dependency already processed in this run
  " -------------------------------------------------------------------
  IF line_exists( gt_edit_done[ table_line = pv_name ] ).
    RETURN.   " already processed; do nothing
  ENDIF.
  APPEND pv_name TO gt_edit_done.

  " -------------------------------------------------------------------
  " Build complete SOURCE table for this dependency (all rows in gt_edit_up)
  " -------------------------------------------------------------------
  DATA: lt_sourc TYPE STANDARD TABLE OF depsource,
        ls_sourc TYPE depsource,
        lv_sources_str TYPE string.

  LOOP AT gt_edit_up ASSIGNING FIELD-SYMBOL(<e>) WHERE dep_name = pv_name.
    CLEAR ls_sourc.
    ls_sourc-line = <e>-source.
    APPEND ls_sourc TO lt_sourc.

    " Build a readable string for ALV (e.g., '234,501')
    IF lv_sources_str IS INITIAL.
      lv_sources_str = <e>-source.
    ELSE.
      CONCATENATE lv_sources_str <e>-source INTO lv_sources_str SEPARATED BY ','.
    ENDIF.
  ENDLOOP.

  " Optional dedup (if input may have duplicate sources)
  SORT lt_sourc BY line.
  DELETE ADJACENT DUPLICATES FROM lt_sourc COMPARING line.

  " -------------------------------------------------------------------
  " Existing logic (unchanged): prepare dep data and description
  " -------------------------------------------------------------------
  DATA: ls_dep_data    LIKE depdat,
        lv_dependency  TYPE dep_ident-dep_extern,
        lt_desc        TYPE STANDARD TABLE OF depdescr,
        ls_desc        TYPE depdescr.

  lv_dependency       = pv_name.
  ls_dep_data-status  = '3'.     " your current logic

  " fetch description (unchanged)
  IF lv_dependency IS NOT INITIAL.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*    SELECT SINGLE knnum
*      INTO @DATA(lv_knum)
*      FROM cukb
*      WHERE knnam = @lv_dependency.
 SELECT KNNUM FROM CUKB   UP TO 1 ROWS INTO @DATA(LV_KNUM) WHERE KNNAM =
 @LV_DEPENDENCY  ORDER BY PRIMARY KEY.   ENDSELECT.
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC

    IF sy-subrc IS INITIAL AND lv_knum IS NOT INITIAL.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*      SELECT SINGLE knktx
*        INTO @DATA(lv_descr)
*        FROM cukbt
*        WHERE knnum = @lv_knum.
 SELECT KNKTX FROM CUKBT   UP TO 1 ROWS INTO @DATA(LV_DESCR) WHERE
KNNUM = @LV_KNUM  ORDER BY PRIMARY KEY.   ENDSELECT.
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
    ENDIF.
  ENDIF.

  CLEAR ls_desc.
  ls_desc-language = 'EN'.
  ls_desc-descript = lv_descr.
  APPEND ls_desc TO lt_desc.

  " -------------------------------------------------------------------
  " BAPI call (unchanged) – now with ALL source lines for this dependency
  " -------------------------------------------------------------------
  CALL FUNCTION 'CAMA_DEPENDENCY_MAINTAIN'
    EXPORTING
      dependency      = lv_dependency
      dependency_data = ls_dep_data
      commit_and_wait = 'X'
    TABLES
      description     = lt_desc
      source          = lt_sourc
    EXCEPTIONS
      warning         = 1
      error           = 2
      OTHERS          = 3.

  " -------------------------------------------------------------------
  " Direct ALV logging (simple, one line per dependency processed)
  " -------------------------------------------------------------------
  DATA: ls_msg TYPE ty_msg,
        lv_text TYPE string.

  IF sy-subrc = 0.
    ls_msg-mtype = 'S'.
    lv_text      = 'Editor updated successfully'.
  ELSE.
    ls_msg-mtype = 'E'.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_text.
    IF lv_text IS INITIAL.
      lv_text = 'Error during Editor update'.
    ENDIF.
  ENDIF.

  ls_msg-row_no   = gv_row.       " row index from process_records (first occurrence)
  ls_msg-scen     = 'EDITOR'.
  ls_msg-dep_name = pv_name.
  ls_msg-input1   = lv_sources_str.   " show all sources (e.g., '234,501')
  ls_msg-mtext    = lv_text.

  APPEND ls_msg TO gt_msgs.

ENDFORM.

*FORM call_bapi_editor USING pv_name TYPE string pv_source TYPE string pv_srno TYPE i.
*
*  " existing unchanged logic...
*  DATA: ls_dep_data LIKE depdat,
*        lv_dependency TYPE dep_ident-dep_extern,
*        lt_desc TYPE STANDARD TABLE OF depdescr,
*        ls_desc TYPE depdescr,
*        lt_sourc TYPE STANDARD TABLE OF depsource,
*        ls_sourc TYPE depsource.
*
*  lv_dependency = pv_name.
*  ls_dep_data-status = '3'.
*
*  "get desc (unchanged)
*  IF lv_dependency IS NOT INITIAL.
*    SELECT SINGLE knnum INTO @DATA(lv_knum)
*      FROM cukb WHERE knnam = @lv_dependency.
*    IF sy-subrc IS INITIAL AND lv_knum IS NOT INITIAL.
*      SELECT SINGLE knktx INTO @DATA(lv_descr)
*        FROM cukbt WHERE knnum = @lv_knum.
*    ENDIF.
*  ENDIF.
*
*  CLEAR ls_desc.
*  ls_desc-language = 'EN'.
*  ls_desc-descript = lv_descr.
*  APPEND ls_desc TO lt_desc.
*
*  ls_sourc-line = pv_source.
*  APPEND ls_sourc TO lt_sourc.
*
*  CALL FUNCTION 'CAMA_DEPENDENCY_MAINTAIN'
*    EXPORTING
*      dependency      = lv_dependency
*      dependency_data = ls_dep_data
*      commit_and_wait = 'X'
*    TABLES
*      description     = lt_desc
*      source          = lt_sourc
*    EXCEPTIONS
*      warning         = 1
*      error           = 2
*      OTHERS          = 3.
*
*  " -----------------------------------------------------------------
*  " ADDED: Direct ALV logging here also
*  " -----------------------------------------------------------------
*  DATA: ls_msg TYPE ty_msg,
*        lv_text TYPE string.
*
*  IF sy-subrc = 0.
*    ls_msg-mtype = 'S'.
*    lv_text      = 'Record updated successfully'.
*  ELSE.
*    ls_msg-mtype = 'E'.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_text.
*  ENDIF.
*
*  ls_msg-row_no   = gv_row.
*  ls_msg-scen     = 'EDITOR'.
*  ls_msg-dep_name = pv_name.
*  ls_msg-input1   = pv_source.
*  ls_msg-mtext    = lv_text.
*
*  APPEND ls_msg TO gt_msgs.
*
*ENDFORM.

*---------------------------------------------------------------------*
* BAPI: STATUS (ALV message logic added)
*---------------------------------------------------------------------*
FORM call_bapi_status USING pv_name TYPE string pv_status TYPE string.

  " EXISTING logic unchanged...
  DATA: ls_dep_data LIKE depdat,
        lv_dependency TYPE dep_ident-dep_extern,
        lt_desc TYPE STANDARD TABLE OF depdescr,
        ls_desc TYPE depdescr,
        lt_sourc TYPE STANDARD TABLE OF depsource.

  lv_dependency = pv_name.
  ls_dep_data-status = '1'.

  "desc lookup
  IF lv_dependency IS NOT INITIAL.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*    SELECT SINGLE knnum INTO @DATA(lv_knum)
*      FROM cukb WHERE knnam = @lv_dependency.
 SELECT KNNUM FROM CUKB   UP TO 1 ROWS INTO @DATA(LV_KNUM) WHERE KNNAM =
 @LV_DEPENDENCY  ORDER BY PRIMARY KEY.   ENDSELECT.
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
    IF sy-subrc IS INITIAL AND lv_knum IS NOT INITIAL.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*      SELECT SINGLE knktx INTO @DATA(lv_descr)
*        FROM cukbt WHERE knnum = @lv_knum.
 SELECT KNKTX FROM CUKBT   UP TO 1 ROWS INTO @DATA(LV_DESCR) WHERE
KNNUM = @LV_KNUM  ORDER BY PRIMARY KEY.   ENDSELECT.
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
    ENDIF.
  ENDIF.

  CLEAR ls_desc.
  ls_desc-language = 'EN'.
  ls_desc-descript = lv_descr.
  APPEND ls_desc TO lt_desc.

  CALL FUNCTION 'CAMA_DEPENDENCY_MAINTAIN'
    EXPORTING
      dependency      = lv_dependency
      dependency_data = ls_dep_data
      commit_and_wait = 'X'
    TABLES
      description     = lt_desc
      source          = lt_sourc
    EXCEPTIONS
      warning         = 1
      error           = 2
      OTHERS          = 3.

  " -----------------------------------------------------------------
  " ADDED: Direct ALV logging
  " -----------------------------------------------------------------
  DATA: ls_msg TYPE ty_msg,
        lv_text TYPE string.

  IF sy-subrc = 0.
    ls_msg-mtype = 'S'.
    lv_text      = 'Status changed successfully'.
  ELSE.
    ls_msg-mtype = 'E'.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_text.
  ENDIF.

  ls_msg-row_no   = gv_row.
  ls_msg-scen     = 'STATUS'.
  ls_msg-dep_name = pv_name.
  ls_msg-input1   = pv_status.
  ls_msg-mtext    = lv_text.

  APPEND ls_msg TO gt_msgs.

ENDFORM.

*---------------------------------------------------------------------*
* ALV (unchanged)
*---------------------------------------------------------------------*
FORM build_fieldcatalog.
  CLEAR gt_fcat.
  gs_layo-zebra = 'X'.
  gs_layo-colwidth_optimize = 'X'.

  PERFORM add_fcat USING 'ROW_NO'  'Row'        'I'  7.
  PERFORM add_fcat USING 'SCEN'    'Scenario'   'C' 10.
  PERFORM add_fcat USING 'DEP_NAME' 'Dependency' 'C' 40.
  PERFORM add_fcat USING 'INPUT1'  'Input'      'C' 30.
  PERFORM add_fcat USING 'MTYPE'   'Type'       'C' 2.
  PERFORM add_fcat USING 'MTEXT'   'Message'    'C' 120.
ENDFORM.

FORM add_fcat USING p_field p_text p_type p_len.
  DATA ls_fcat TYPE slis_fieldcat_alv.
  ls_fcat-fieldname = p_field.
  ls_fcat-seltext_m = p_text.
  ls_fcat-datatype  = p_type.
  ls_fcat-outputlen = p_len.
  APPEND ls_fcat TO gt_fcat.
ENDFORM.

FORM show_alv.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      is_layout          = gs_layo
      it_fieldcat        = gt_fcat
    TABLES
      t_outtab           = gt_msgs.
ENDFORM.
