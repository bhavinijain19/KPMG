*&---------------------------------------------------------------------*
*& Include          ZPP_MASTER_RECIPE_UPLOAD_TOP
*&---------------------------------------------------------------------*

*---------------------------------------------------------------------*
* TYPES – Excel Structure (As per latest template)
*---------------------------------------------------------------------*
  TYPES: BEGIN OF ty_excel,
**           entry_act          TYPE i,
**           plnnr              TYPE plnnr,       "Group Number
**           plnal              TYPE plnal,       "Counter
**           sttag              TYPE char10,      "Valid from date
**           werks              TYPE werks_d,     "Plan
**           ktext              TYPE plantext,    "Short text
**           plnme              TYPE meins,       "Task list UOM
**           losvn              TYPE char17,      "From Lot Size
**           losbs              TYPE char17,      "To Lot Size
**           vornr              TYPE vornr,       "Operation
**           phflg              TYPE char1,       "Phase
**           pvznr              TYPE pvznr,       "Superior operation
**           phseq              TYPE char2,       "Destination
**           arbpl              TYPE arbpl,       "Work Center
**           steus              TYPE steus,       "Control Key
**           ltxa1              TYPE ltxa1,       "Operation short text
**           bmsch              TYPE char17,      "Base Qty
**           meinh              TYPE meinh,       "UOM
**           vgw01              TYPE vgwrt,       "Setup labor
**           vgw02              TYPE vgwrt,       "Setup Machine
**           vgw03              TYPE vgwrt,       "Setup Power
**           vgw04              TYPE vgwrt,       "Machine
**           vgw05              TYPE vgwrt,       "Labor
**           vgw06              TYPE vgwrt,       "Power
**           matnr              TYPE matnr,       "Material code
**           verid              TYPE verid,       "Production version
**           text1              TYPE vers_text,   "Production version Text
**           stlan              TYPE stlan,       "BOM usage
**           stlal              TYPE stlal,       "Alt BOM
**           mdv01              TYPE char8,       "Production Line

* data element: plnnr
           plnnr_001(008),
* data element: CP_S_PLNAL
           plnal_002(002),
* data element: CP_STTAG
           sttag_003(010),
* data element: ENTRY_ACT
           entry_act_004(010),
* data element: ENTRY_ACT
           entry_act_005(010),
* data element: VORNR
           vornr_006(004),
* data element: STEUS
           steus_007(004),
*** data element: CK_SELKZ
**           ckselkz_008(001),
* data element: LTXA1
           ltxa1_009(040),
* data element: BMSCH
           bmsch_010(017),
* data element: VORME
           meinh_011(003),
* data element: VGWRT
           vgw01_012(011),
*** data element: VGWRTEH
**           vge01_013(003),
*** data element: LSTAR
**           lar01_014(006),
* data element: VGWRT
           vgw02_015(011),
*** data element: VGWRTEH
**           vge02_016(003),
*** data element: LSTAR
**           lar02_017(006),
* data element: VGWRT
           vgw03_018(011),
*** data element: VGWRTEH
**           vge03_019(003),
*** data element: LSTAR
**           lar03_020(006),
* data element: VGWRT
           vgw04_021(011),
*** data element: VGWRTEH
**           vge04_022(003),
*** data element: LSTAR
**           lar04_023(006),
* data element: VGWRT
           vgw05_024(011),
*** data element: VGWRTEH
**           vge05_025(003),
*** data element: LSTAR
**           lar05_026(006),
* data element: VGWRT
           vgw06_027(011),
*** data element: VGWRTEH
**           vge06_028(003),
*** data element: LSTAR
**           lar06_029(006),
*** data element: VORNR
**           vornr_030(004),
*** data element: STEUS
**           steus_031(004),
*** data element: CK_SELKZ
**           ckselkz_032(001),
*** data element: LTXA1
**           ltxa1_033(040),
*** data element: BMSCH
**           bmsch_034(017),
*** data element: VORME
**           meinh_035(003),
*** data element: VGWRT
**           vgw01_036(011),
*** data element: VGWRTEH
**           vge01_037(003),
*** data element: LSTAR
**           lar01_038(006),
*** data element: VGWRT
**           vgw02_039(011),
*** data element: VGWRTEH
**           vge02_040(003),
*** data element: LSTAR
**           lar02_041(006),
*** data element: VGWRT
**           vgw03_042(011),
*** data element: VGWRTEH
**           vge03_043(003),
*** data element: LSTAR
**           lar03_044(006),
*** data element: VGWRT
**           vgw04_045(011),
*** data element: VGWRTEH
**           vge04_046(003),
*** data element: LSTAR
**           lar04_047(006),
*** data element: VGWRT
**           vgw05_048(011),
*** data element: VGWRTEH
**           vge05_049(003),
*** data element: LSTAR
**           lar05_050(006),
*** data element: VGWRT
**           vgw06_051(011),
*** data element: VGWRTEH
**           vge06_052(003),
*** data element: LSTAR
**           lar06_053(006),
         END OF ty_excel.

  DATA: gt_excel TYPE STANDARD TABLE OF ty_excel,
        gs_excel TYPE ty_excel.

  DATA: gt_bdcdata TYPE STANDARD TABLE OF bdcdata,
        gs_bdcdata TYPE bdcdata,
        gt_msg     TYPE STANDARD TABLE OF bdcmsgcoll.
