*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_CONT_VALUES
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_CONT_VALUES     .

  PERFORM TABLEPROC.

ENDFUNCTION.
