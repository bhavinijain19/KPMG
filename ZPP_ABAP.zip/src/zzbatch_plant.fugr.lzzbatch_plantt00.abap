*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZZBATCH_PLANT...................................*
DATA:  BEGIN OF STATUS_ZZBATCH_PLANT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZZBATCH_PLANT                 .
CONTROLS: TCTRL_ZZBATCH_PLANT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZZBATCH_PLANT                 .
TABLES: ZZBATCH_PLANT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
