*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBATCH_MAT_GRPTOP.                " Global Declarations
  INCLUDE LZBATCH_MAT_GRPUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBATCH_MAT_GRPF...                " Subroutines
* INCLUDE LZBATCH_MAT_GRPO...                " PBO-Modules
* INCLUDE LZBATCH_MAT_GRPI...                " PAI-Modules
* INCLUDE LZBATCH_MAT_GRPE...                " Events
* INCLUDE LZBATCH_MAT_GRPP...                " Local class implement.
* INCLUDE LZBATCH_MAT_GRPT99.                " ABAP Unit tests
  INCLUDE LZBATCH_MAT_GRPF00                      . " subprograms
  INCLUDE LZBATCH_MAT_GRPI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
