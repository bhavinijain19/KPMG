"Name: \FU:CO_FW_SEND_MHD_POPUP\SE:END\EI
ENHANCEMENT 0 ZENH_MANUF_DATE_CO11N.
*
   IF sy-tcode EQ 'CO11N' OR sy-tcode EQ 'COR6N'.
  SELECT SINGLE manf_date
    FROM zwm_su
    INTO imseg_chg-mhdat
    WHERE aufnr EQ imseg_chg-aufnr.
 ENDIF.
ENDENHANCEMENT.
