*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_OPTIVA_MAIL.................................*
DATA:  BEGIN OF STATUS_ZPP_OPTIVA_MAIL               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_OPTIVA_MAIL               .
CONTROLS: TCTRL_ZPP_OPTIVA_MAIL
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZPP_OPTIVA_MAIL               .
TABLES: ZPP_OPTIVA_MAIL                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
