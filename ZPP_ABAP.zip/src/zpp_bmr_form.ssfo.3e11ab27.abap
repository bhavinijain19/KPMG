DATA : lv_bdmng TYPE string,
       lv1      TYPE string,
       lv2      TYPE string.

CLEAR: lv_bdmng, gv_bdmng, lv1, lv2.

lv_bdmng = wa_item-bdmng.
*BREAK-POINT.
IF lv_bdmng = 0.
  IF wa_item-matnr IS INITIAL.
    CLEAR: gv_bdmng.
  ELSE.
    SPLIT lv_bdmng AT '.' INTO lv1 lv2.
    CONCATENATE lv1 '.' lv2 INTO gv_bdmng.
  ENDIF.
ELSE.
  SPLIT lv_bdmng AT '.' INTO lv1 lv2.
  CONCATENATE lv1 '.' lv2 INTO gv_bdmng.
ENDIF.


















