*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCERT_MATTOP.                     " Global Declarations
  INCLUDE LZCERT_MATUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCERT_MATF...                     " Subroutines
* INCLUDE LZCERT_MATO...                     " PBO-Modules
* INCLUDE LZCERT_MATI...                     " PAI-Modules
* INCLUDE LZCERT_MATE...                     " Events
* INCLUDE LZCERT_MATP...                     " Local class implement.
* INCLUDE LZCERT_MATT99.                     " ABAP Unit tests
  INCLUDE LZCERT_MATF00                           . " subprograms
  INCLUDE LZCERT_MATI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
