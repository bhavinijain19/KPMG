*&---------------------------------------------------------------------*
*& Include          ZPP_WORKCENTER_UPLOAD_F01
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&  Include          ZPP_WORKCENTER_UPLOAD_F01
*&---------------------------------------------------------------------*

*---------------------------------------------------------------------*
* Initialize screen elements
*---------------------------------------------------------------------*
FORM init_screen.
  pb_tmpl = 'Download Template'.
ENDFORM.

*---------------------------------------------------------------------*
* File browse (frontend)
*---------------------------------------------------------------------*
FORM f4_file.
  DATA: lt_filetab TYPE filetable, lv_rc TYPE i.
  cl_gui_frontend_services=>file_open_dialog(
    EXPORTING default_extension = 'xls'
    CHANGING  file_table        = lt_filetab
              rc                = lv_rc
  ).
  IF lv_rc > 0.
    READ TABLE lt_filetab INDEX 1 INTO DATA(ls_file).
    p_outfil = ls_file-filename.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
* Handle selection screen commands (template download)
*---------------------------------------------------------------------*
FORM handle_screen_command.
  CASE sy-ucomm.
    WHEN 'DISP'.
*      IF p_create = 'X'.
*        pb_tmpl = 'Download Create Template'.
*      ELSEIF p_change = 'X'.
*        pb_tmpl = 'Download Change Template'.
*      ENDIF.
    WHEN 'TMPL'.
      PERFORM download_template_xls.
  ENDCASE.
ENDFORM.

*---------------------------------------------------------------------*
* Template Download (same format as CRC1 uploader)
* - Row 1: technical headers (match st_upload order)
* - Row 2: business-friendly labels
*---------------------------------------------------------------------*
FORM download_template_xls.
  DATA: lv_fname TYPE string, lv_path TYPE string, lv_full TYPE string.

  TYPES: BEGIN OF ty_template, col TYPE string, END OF ty_template.
  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  CLEAR lt_template.

*  IF p_create = 'X'.
    "---------------------- Row 1: technical headers ----------------------"
    CONCATENATE
      'WERKS' 'ARBPL' 'VERWE' 'STEXT' 'VERAN' 'PLANV' 'VGWTS' 'RGEKZ' 'STEUS'
      'KAPART1' 'KTEXT1' 'PLANR1' 'MOSID1' 'KALID1' 'VERSA1' 'MEINS1'
      'NGRAD1' 'AZNOR1' 'KAPTER1' 'DATUV1' 'DATUB1' 'SPROG1' 'ANZTG1' 'ANZSH1' 'FABTG1'
      'FORK1A_1' 'FORK1B_1' 'FORK2_1'
      'KAPART2' 'KTEXT2' 'PLANR2' 'KALID2' 'VERSA2' 'MEINS2'
      'BEGZT2' 'ENDZT2' 'PAUSE2' 'NGRAD2' 'AZNOR2' 'KAPTER2'
      'FORK1A_2' 'FORK1B_2' 'FORK2_2'
      'SCHED_KAPART' 'FORT1' 'FORT2' 'FORT3'
      'KOSTL'
      'LAR1' 'LAR2' 'LAR3' 'LAR4' 'LAR5' 'LAR6'

      'FOR1' 'FOR2' 'FOR3' 'FOR4'
'FOR5'
 'FOR6'

      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    APPEND ls_template TO lt_template.

    "---------------------- Row 2: friendly labels ----------------------"
    CONCATENATE
      'Plant' 'Workcenter' 'Workcenter Category' 'Description' 'Person responsible' 'Usage'
      'Standard value key' 'Backflush' 'Control key'
      'Capacity category' 'Capacity short Text' 'Capacity Responsible' 'Grouping for shift'
      'Factory calendar ID' 'Active Version' 'Base Unit of Measurement for Capacity'
      'Capacity utilization' 'No. of indiv. cap.' 'Relevant for finite scheduling'
      'Valid from' 'Valid to' 'Shift Sequence' 'Length of cycle' 'Number of shifts' 'Work days'
      'Setup formula' 'Processing formula' 'Teardown formula'
      'Capacity category' 'Capacity short Text' 'Capacity Responsible' 'Factory calendar ID'
      'Active Version' 'Base Unit of Measurement for Capacity'
      'Start time' 'Finish' 'Length Breaks' 'Capacity utilization' 'No. of indiv. cap.'
      'Relevant for finite scheduling'
      'Setup formula' 'Processing formula' 'Teardown formula'
      'Capacity Category (Scheduling)' 'Duration of set up' 'Processing Duration' 'Duration of teardown'
      'Cost Center'
      'Labor setup' 'Machine setup' 'Power setup' 'Machine' 'Labor' 'Power'
      'Formula' 'Formula' 'Formula' 'Formula' 'Formula' 'Formula'
      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    APPEND ls_template TO lt_template.
*  ELSE.
*    "Change stub (kept for parity)
*    CONCATENATE 'WERKS' 'ARBPL' 'FIELD_TO_CHANGE' 'NEW_VALUE'
*      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
*    APPEND ls_template TO lt_template.
*  ENDIF.

  "Save dialog & download"
  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING default_extension = 'xls'
              default_file_name = COND string(
                 WHEN p_create = 'X' THEN 'Workcenter_Create_Template.xls'
*                 WHEN p_change = 'X' THEN 'Workcenter_Change_Template.xls'
  )
    CHANGING  filename = lv_fname path = lv_path fullpath = lv_full
  ).

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  cl_gui_frontend_services=>gui_download(
    EXPORTING filename = lv_full filetype = 'ASC' write_field_separator = abap_true
    CHANGING  data_tab = lt_template
  ).

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.
ENDFORM.

*---------------------------------------------------------------------*
* Upload Excel file (.XLS via TEXT_CONVERT_XLS_TO_SAP)
* - Skips row 1 via i_line_header = 'X'
* - Safely skips row 2 (friendly labels) if it matches expected labels
*---------------------------------------------------------------------*
FORM upload_file.
  DATA it_type TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_outfil
    TABLES
      i_tab_converted_data = it_upload
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error in uploading file' TYPE 'E'.
  ENDIF.

  IF lines( it_upload ) > 0.
    READ TABLE it_upload INDEX 1 INTO wa_upload.
*    IF wa_upload-werks = 'Plant'
*     AND wa_upload-arbpl = 'Workcenter'
*     AND wa_upload-verwe = 'Workcenter Category'.
      DELETE it_upload INDEX 1.  "Data now starts from Excel row 3
*    ENDIF.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
* Process Create Workcenter (ZCR01 / CR01)
*---------------------------------------------------------------------*
FORM process_create_zcr01.
  LOOP AT it_upload INTO wa_upload.
    REFRESH: bdcdata, messtab.
    CLEAR:   wa_log.

    PERFORM build_bdc_zcr01 USING wa_upload.



    CALL TRANSACTION 'CR01'                   "Default ZCR01; can set CR01
      USING bdcdata
      MODE   p_mode
      UPDATE 'S'
      MESSAGES INTO messtab.

    PERFORM handle_messages USING wa_upload.
  ENDLOOP.
ENDFORM.

*---------------------------------------------------------------------*
* Build BDCDATA for ZCR01 – mirrors SHDB WORKCENTER_1 sequence
*---------------------------------------------------------------------*
FORM build_bdc_zcr01 USING ps TYPE st_upload.

  "---- Initial (SAPLCRA0 0101) ----"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '0101'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=NEXT'.
  PERFORM bdc_field  USING 'RC68A-WERKS'    ps-werks.
  PERFORM bdc_field  USING 'RC68A-ARBPL'    ps-arbpl.
  PERFORM bdc_field  USING 'RC68A-VERWE'    ps-verwe.

  "---- Basic / Default values on 4000 ----"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '/00'.
  IF ps-stext  IS NOT INITIAL. PERFORM bdc_field USING 'P1000-STEXT'  ps-stext.  ENDIF.
  IF ps-veran  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-VERAN'  ps-veran.  ENDIF.
  IF ps-planv  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-PLANV'  ps-planv.  ENDIF.
  IF ps-vgwts  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-VGWTS'  ps-vgwts.  ENDIF.

  "Backflush on next pass (as per SHDB =VORA hop)"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=VORA'.
  IF ps-rgekz = 'X'.           PERFORM bdc_field USING 'P3000-RGEKZ'  'X'.       ENDIF.

  "Control Key on 3003"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '/00'.
  IF ps-steus  IS NOT INITIAL. PERFORM bdc_field USING 'P3003-STEUS'  ps-steus.  ENDIF.

  "KAUE hop (per SHDB)"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=KAUE'.

  "================ Capacity 1 (pos 01) ================"
  IF ps-kapart1 IS NOT INITIAL.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'       '/00'.
    PERFORM bdc_field  USING 'RC68A-KAPART(01)' ps-kapart1.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'.
    IF ps-ktext1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKT-KTEXT' ps-ktext1. ENDIF.
    IF ps-planr1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-PLANR' ps-planr1. ENDIF.
    IF ps-mosid1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MOSID' ps-mosid1. ENDIF.

    "Standard cap times / utilization / heads (0133) + availability (0132)"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0133'.
    PERFORM bdc_field  USING 'RC68K-BEGZT'     '00:00:00'.
    PERFORM bdc_field  USING 'RC68K-ENDZT'     '00:00:00'.
    IF ps-ngrad1 IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-NGRAD'  ps-ngrad1. ENDIF.
    PERFORM bdc_field  USING 'RC68K-PAUSE'     '00:00:00'.
    IF ps-aznor1 IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-AZNOR'  ps-aznor1. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0132'.
    IF ps-kalid1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-KALID' ps-kalid1. ENDIF.
    IF ps-versa1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-VERSA' ps-versa1. ENDIF.
    IF ps-meins1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MEINS' ps-meins1. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0135'.
    IF ps-kapter1 = 'X'.        PERFORM bdc_field USING 'KAKO-KAPTER' 'X'. ENDIF.
    PERFORM bdc_field  USING 'RC68K-KAPLPL'     'X'.

    "Validity line insert + specific dates/shifts (0116)"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'.
    PERFORM bdc_field  USING 'BDC_OKCODE'         '=INSI'.
    PERFORM bdc_field  USING 'RC68K-VERSN'        '1'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-BEGZT' '00:00:00'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-ENDZT' '00:00:00'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-PAUSE' '00:00:00'.
    IF ps-ngrad1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA_DEFAULT-NGRAD' ps-ngrad1. ENDIF.
    IF ps-aznor1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA_DEFAULT-ANZHL' ps-aznor1. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'.
    PERFORM bdc_field  USING 'BDC_OKCODE'         '/00'.
    PERFORM bdc_field  USING 'RC68K-VERSN'        '1'.
    IF ps-datuv1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-DATUV(01)' ps-datuv1. ENDIF.
    IF ps-datub1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-DATUB(01)' ps-datub1. ENDIF.
    IF ps-sprog1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-SPROG(01)' ps-sprog1. ENDIF.
    IF ps-anztg1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-ANZTG(01)' ps-anztg1. ENDIF.
    IF ps-anzsh1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-ANZSH(01)' ps-anzsh1. ENDIF.
    IF ps-fabtg1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-FABTG(01)' ps-fabtg1. ENDIF.

    "Back to resource and place formula keys for line 1"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'         '/00'.
    IF ps-fork1a_1 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK1(01)' ps-fork1a_1. ENDIF.
    IF ps-fork1b_1 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK2(01)' ps-fork1b_1. ENDIF.
    IF ps-fork2_1  IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK3(01)' ps-fork2_1.  ENDIF.
  ENDIF.

  "================ Capacity 2 (pos 02) ================"
  IF ps-kapart2 IS NOT INITIAL.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'         '/00'.
    PERFORM bdc_field  USING 'RC68A-KAPART(02)'   ps-kapart2.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'.
    IF ps-ktext2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKT-KTEXT' ps-ktext2. ENDIF.
    IF ps-planr2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-PLANR' ps-planr2. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0133'.
    IF ps-begzt2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-BEGZT' ps-begzt2. ENDIF.
    IF ps-endzt2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-ENDZT' ps-endzt2. ENDIF.
    IF ps-ngrad2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-NGRAD'  ps-ngrad2. ENDIF.
    IF ps-pause2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-PAUSE' ps-pause2. ENDIF.
    IF ps-aznor2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-AZNOR'  ps-aznor2. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0132'.
    IF ps-kalid2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-KALID' ps-kalid2. ENDIF.
    IF ps-versa2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-VERSA' ps-versa2. ENDIF.
    IF ps-meins2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MEINS' ps-meins2. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0135'.
    IF ps-kapter2 = 'X'.        PERFORM bdc_field USING 'KAKO-KAPTER' 'X'. ENDIF.
    PERFORM bdc_field  USING 'RC68K-KAPLPL'       'X'.

    "Back and set formula keys (line 2) on main"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'         '/00'.
    IF ps-fork1a_2 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK1(02)' ps-fork1a_2. ENDIF.
    IF ps-fork1b_2 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK2(02)' ps-fork1b_2. ENDIF.
    IF ps-fork2_2  IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORK3(02)' ps-fork2_2.  ENDIF.
  ENDIF.

  "================ Scheduling formulas (optional) ================"
  IF ps-sched_kapart IS NOT INITIAL OR ps-fort1 IS NOT INITIAL
   OR ps-fort2 IS NOT INITIAL OR ps-fort3 IS NOT INITIAL.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'   '/00'.
    PERFORM bdc_field  USING 'RC68A-KAPART' ps-sched_kapart.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'   '/00'.
    IF ps-fort1 IS NOT INITIAL. PERFORM bdc_field USING 'P3005-FORT1' ps-fort1. ENDIF.
    IF ps-fort2 IS NOT INITIAL. PERFORM bdc_field USING 'P3005-FORT2' ps-fort2. ENDIF.
    IF ps-fort3 IS NOT INITIAL. PERFORM bdc_field USING 'P3005-FORT3' ps-fort3. ENDIF.
  ENDIF.

  "================ Costing + LAR/FOR pairs ================"
  IF ps-kostl IS NOT INITIAL OR
     ps-lar1  IS NOT INITIAL OR ps-for1 IS NOT INITIAL OR
     ps-lar2  IS NOT INITIAL OR ps-for2 IS NOT INITIAL OR
     ps-lar3  IS NOT INITIAL OR ps-for3 IS NOT INITIAL OR
     ps-lar4  IS NOT INITIAL OR ps-for4 IS NOT INITIAL OR
     ps-lar5  IS NOT INITIAL OR ps-for5 IS NOT INITIAL OR
     ps-lar6  IS NOT INITIAL OR ps-for6 IS NOT INITIAL.

    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'   '/00'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '1004'.
    PERFORM bdc_field  USING 'P1001-BEGDA' sy-datum.
    PERFORM bdc_field  USING 'P1001-ENDDA' '99991231'.
    IF ps-kostl IS NOT INITIAL. PERFORM bdc_field USING 'CRKEYK-KOSTL' ps-kostl. ENDIF.

    "Map 6 pairs"
    IF ps-lar1 IS NOT INITIAL OR ps-for1 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(01)' ps-lar1.
      PERFORM bdc_field USING 'RC68A-FORXX(01)' ps-for1.
    ENDIF.
    IF ps-lar2 IS NOT INITIAL OR ps-for2 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(02)' ps-lar2.
      PERFORM bdc_field USING 'RC68A-FORXX(02)' ps-for2.
    ENDIF.
    IF ps-lar3 IS NOT INITIAL OR ps-for3 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(03)' ps-lar3.
      PERFORM bdc_field USING 'RC68A-FORXX(03)' ps-for3.
    ENDIF.
    IF ps-lar4 IS NOT INITIAL OR ps-for4 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(04)' ps-lar4.
      PERFORM bdc_field USING 'RC68A-FORXX(04)' ps-for4.
    ENDIF.
    IF ps-lar5 IS NOT INITIAL OR ps-for5 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(05)' ps-lar5.
      PERFORM bdc_field USING 'RC68A-FORXX(05)' ps-for5.
    ENDIF.
    IF ps-lar6 IS NOT INITIAL OR ps-for6 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(06)' ps-lar6.
      PERFORM bdc_field USING 'RC68A-FORXX(06)' ps-for6.
    ENDIF.
  ENDIF.

  "================ Save ================"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE' '=UPD'.

ENDFORM.

*---------------------------------------------------------------------*
* BDC helpers
*---------------------------------------------------------------------*
FORM bdc_dynpro USING pv_prog pv_dynnr.
  DATA ls TYPE bdcdata.
  CLEAR ls.
  ls-program  = pv_prog.
  ls-dynpro   = pv_dynnr.
  ls-dynbegin = 'X'.
  APPEND ls TO bdcdata.
ENDFORM.

FORM bdc_field USING pv_fnam pv_fval.
  DATA ls TYPE bdcdata.
  CLEAR ls.
  ls-fnam = pv_fnam.
  ls-fval = pv_fval.
  APPEND ls TO bdcdata.
ENDFORM.

*---------------------------------------------------------------------*
* Collect messages into simple log
*---------------------------------------------------------------------*
FORM handle_messages USING ps TYPE st_upload.
  DATA lv_text TYPE string.
  LOOP AT messtab INTO DATA(lsm).
    DATA(lv_line) = ||.
    CALL FUNCTION 'MESSAGE_TEXT_BUILD'
      EXPORTING msgid = lsm-msgid msgnr = lsm-msgnr
                msgv1 = lsm-msgv1 msgv2 = lsm-msgv2
                msgv3 = lsm-msgv3 msgv4 = lsm-msgv4
      IMPORTING message_text_output = lv_line.
    IF lv_text IS INITIAL.
      lv_text = lv_line.
    ELSE.
      CONCATENATE lv_text lv_line INTO lv_text SEPARATED BY ' | '.
    ENDIF.
  ENDLOOP.

  wa_log-werks   = ps-werks.
  wa_log-arbpl   = ps-arbpl.
  wa_log-status  = COND #( WHEN line_exists( messtab[ msgtyp = 'E' ] ) THEN 'Error'
                           WHEN line_exists( messtab[ msgtyp = 'W' ] ) THEN 'Warn'
                           ELSE 'Success' ).
  wa_log-message = COND string( WHEN lv_text IS INITIAL THEN 'No messages' ELSE lv_text ).
  APPEND wa_log TO it_log.
ENDFORM.

*---------------------------------------------------------------------*
* Display log (simple list)
*---------------------------------------------------------------------*
FORM display_log.
  FORMAT COLOR COL_HEADING INTENSIFIED ON.
  WRITE: / 'WERKS', 12 'ARBPL', 35 'STATUS', 46 'MESSAGE'.
  ULINE.
  FORMAT RESET.
  LOOP AT it_log INTO wa_log.
    WRITE: / wa_log-werks, 12 wa_log-arbpl, 35 wa_log-status, 46 wa_log-message.
  ENDLOOP.
ENDFORM.
