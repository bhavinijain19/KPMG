*&---------------------------------------------------------------------*
*& Report  ZPP_INSP_TREND_ANALYSIS_REP
*&
*&---------------------------------------------------------------------*
*&  Created By    : Carina Jose
*&  Creation Date : 25/04/2022
*&---------------------------------------------------------------------*
REPORT zpp_insp_trend_analysis_rep.
TABLES : qals.

*&----------------------------------------------------- DATA DECLARATION ----------------------------------------------------------&*
*DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
*       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
*       fs_layout      TYPE slis_layout_alv,
*       g_save         TYPE c VALUE 'X',
*       g_variant      TYPE disvariant,
*       gx_variant     TYPE disvariant,
*       g_exit         TYPE c,
*       t_event        TYPE slis_t_event WITH HEADER LINE,
*       t_sort         TYPE slis_t_sortinfo_alv WITH HEADER LINE.

FIELD-SYMBOLS : <dyn_table> TYPE STANDARD TABLE,  "for dynamic table
                <dyn_wa>,
                <fs1>.

* Create the dynamic internal table
DATA : new_table TYPE REF TO data,
       new_line  TYPE REF TO data.


DATA: fieldname(20)  TYPE c,
      fieldvalue(60) TYPE c.


DATA: it_fldcat  TYPE lvc_t_fcat,
      wa_fldcat  TYPE lvc_s_fcat,
      gs_layout1 TYPE lvc_s_layo.                "slis_layout_alv,

TYPES: BEGIN OF ty_t001w,
         werks TYPE t001w-werks,
         name1 TYPE t001w-name1,
       END OF ty_t001w.
DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w,
       wa_t001w TYPE ty_t001w.


TYPES : BEGIN OF ty_qals,
          prueflos  TYPE qals-prueflos,
          werk      TYPE qals-werk,
          art       TYPE qals-art,
          enstehdat TYPE qals-enstehdat,
          ersteller TYPE qals-ersteller,
          aenderer  TYPE qals-aenderer,
          matnr     TYPE qals-matnr,
          losmenge  TYPE qals-losmenge,
          ktextmat  TYPE qals-ktextmat,
          mblnr     TYPE qals-mblnr,
          charg     TYPE qals-charg,
          sellifnr  TYPE qals-sellifnr, "Added by UDAYABAP03 on 16.04.2026
        END OF ty_qals.
DATA : it_qals TYPE STANDARD TABLE OF ty_qals,
       wa_qals TYPE ty_qals.

TYPES : BEGIN OF ty_qamv,
          prueflos   TYPE qamv-prueflos,
          merknr     TYPE qamv-merknr,
          verwmerkm  TYPE qamv-verwmerkm,
          pmethode   TYPE qamv-pmethode,
          kurztext   TYPE qamv-kurztext,
          katalgart1 TYPE qamv-katalgart1,
          auswmenge1 TYPE qamv-auswmenge1,
          auswmgwrk1 TYPE qamv-auswmgwrk1,
        END OF ty_qamv.
DATA : it_qamv  TYPE STANDARD TABLE OF ty_qamv,
       wa_qamv  TYPE ty_qamv,
       it_qamv1 TYPE STANDARD TABLE OF ty_qamv,
       wa_qamv1 TYPE ty_qamv.

TYPES : BEGIN OF ty_qamr,
          prueflos       TYPE qamv-prueflos,
          merknr         TYPE qamv-merknr,
          original_input TYPE qamr-original_input,
          pruefbemkt     TYPE qamr-pruefbemkt, "Added by UDAYABAP03 on 16.04.2026
        END OF ty_qamr.
DATA : it_qamr TYPE STANDARD TABLE OF ty_qamr,
       wa_qamr TYPE ty_qamr.

TYPES: BEGIN OF ty_qpac,
         werks      TYPE qpac-werks,
         auswahlmge TYPE qpac-auswahlmge,
         codegruppe TYPE qpac-codegruppe,
         code       TYPE qpac-code,
         katalogart TYPE qpac-katalogart,
       END OF ty_qpac.
DATA: it_qpac TYPE STANDARD TABLE OF ty_qpac,
      wa_qpac TYPE ty_qpac.

TYPES: BEGIN OF ty_qpct,
         codegruppe TYPE qpct-codegruppe,
         code       TYPE qpct-code,
         kurztext   TYPE qpct-kurztext,
       END OF ty_qpct.

DATA: it_qpct TYPE STANDARD TABLE OF ty_qpct,
      wa_qpct TYPE ty_qpct.


TYPES : BEGIN OF ty_final,
          prueflos       TYPE qals-prueflos,
          werk           TYPE qals-werk,
          matnr          TYPE qals-matnr,
          art            TYPE qals-art,
          losmenge       TYPE qals-losmenge,
          enstehdat      TYPE qals-enstehdat,
          ersteller      TYPE qals-ersteller,
          verwmerkm      TYPE qamv-verwmerkm,
          pmethode       TYPE qamv-pmethode,
          kurztext       TYPE qamv-kurztext,
          original_input TYPE qamr-original_input,
        END OF ty_final.
DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.

DATA : v_cnt TYPE i.
DATA : v_cnt1(05).

*&----------------------------------------------------- SELECTION SCREEN ----------------------------------------------------------&*
SELECTION-SCREEN BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  PARAMETERS : p_werks TYPE qals-werk OBLIGATORY.
  SELECT-OPTIONS : s_matnr FOR qals-matnr.
  SELECT-OPTIONS : s_date FOR qals-enstehdat OBLIGATORY.
SELECTION-SCREEN END OF BLOCK a1.
*&----------------------------------------------------- START OF SELECTION ----------------------------------------------------------&*
START-OF-SELECTION.
  PERFORM authorization_check.
  PERFORM get_data.
  IF it_qals IS INITIAL.
    MESSAGE 'No data for inputted values.' TYPE 'S' DISPLAY LIKE 'E'.
  ELSE.
    PERFORM build_dynamic_table.
    PERFORM build_data.
    PERFORM alv_display.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT werks name1 FROM t001w INTO TABLE gt_t001w WHERE werks = p_werks.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'Z_INSP_WRK'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
    CLEAR : wa_t001w.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .




  SELECT prueflos werk art enstehdat ersteller aenderer matnr losmenge ktextmat mblnr charg
    sellifnr "Added by UDAYABAP03 on 16.04.2026
    INTO CORRESPONDING FIELDS OF TABLE it_qals
    FROM qals
    WHERE werk = p_werks
    AND   enstehdat IN s_date
    AND   matnr IN s_matnr.

  IF it_qals IS NOT INITIAL.
    SELECT prueflos merknr pmethode verwmerkm kurztext katalgart1 auswmenge1 auswmgwrk1
      INTO CORRESPONDING FIELDS OF TABLE it_qamv
      FROM qamv
      FOR ALL ENTRIES IN it_qals
      WHERE prueflos = it_qals-prueflos.

    "Added by UDAYABAP03 on 16.04.2026
    SELECT lifnr, name1 FROM lfa1
      FOR ALL ENTRIES IN @it_qals
      WHERE lifnr = @it_qals-sellifnr
      INTO TABLE @DATA(lt_lifnr).
    "Added by UDAYABAP03 on 16.04.2026
  ENDIF.

  IF it_qamv IS NOT INITIAL.
    SELECT prueflos merknr original_input
      pruefbemkt "Added by UDAYABAP03 on 16.04.2026
      INTO CORRESPONDING FIELDS OF TABLE it_qamr
      FROM qamr
      FOR ALL ENTRIES IN it_qamv
      WHERE prueflos = it_qamv-prueflos
      AND   merknr = it_qamv-merknr.

    SELECT werks auswahlmge codegruppe code katalogart
      FROM qpac
      INTO TABLE it_qpac
      FOR ALL ENTRIES IN it_qamv
      WHERE werks = it_qamv-auswmgwrk1
      AND  katalogart = it_qamv-katalgart1
      AND   auswahlmge = it_qamv-auswmenge1.
  ENDIF.

  IF it_qpac IS NOT INITIAL.
    SELECT codegruppe code kurztext
    FROM qpct
    INTO TABLE it_qpct
    FOR ALL ENTRIES IN it_qpac
    WHERE codegruppe = it_qpac-codegruppe
    AND   code = it_qpac-code
    AND   sprache = sy-langu.
  ENDIF.






* LOOP AT it_qals .
*
* ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_DYNAMIC_TABLE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_dynamic_table .
  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'PRUEFLOS'.
  wa_fldcat-coltext   = 'Inspection No.'.
  wa_fldcat-datatype  = 'CHAR'.
  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.


  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'WERK'.
  wa_fldcat-coltext   = 'Plant'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '10'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.


  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'MATNR'.
  wa_fldcat-coltext   = 'Material'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '10'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'KTEXTMAT'.
  wa_fldcat-coltext   = 'Material Description'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '10'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'MBLNR'.
  wa_fldcat-coltext   = 'Material Document'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '10'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.


  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'INSPTYPE'.
  wa_fldcat-coltext   = 'Inspection Type'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'LOSMENGE'.
  wa_fldcat-coltext   = 'Inspection Lot Qty'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'CHARG'.
  wa_fldcat-coltext   = 'Batch No.'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'ENSTEHDAT'.
  wa_fldcat-coltext   = 'Creation Date'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'AENDERER'.
  wa_fldcat-coltext   = 'Changed By'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'ERSTELLER'.
  wa_fldcat-coltext   = 'Created By'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.


*  CLEAR wa_fldcat.
*  wa_fldcat-fieldname = 'VERWMERKM'.
*  wa_fldcat-coltext   = 'Master Inspection Characteristics'.
*  wa_fldcat-datatype  = 'CHAR'.
**  wa_fldcat-outputlen  = '20'.
*  wa_fldcat-emphasize  = 'C5'.
*  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'PMETHODE'.
  wa_fldcat-coltext   = 'Inspection Method'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'KURZTEXT'.
  wa_fldcat-coltext   = 'Inspection Characteristic Desc.'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

"Added by UDAYABAP03 on 16.04.2026
  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'SELLIFNR'.
  wa_fldcat-coltext   = 'Vendor No.'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'NAME1'.
  wa_fldcat-coltext   = 'Vendor Name'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

  CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'PRUEFBEMKT'.
  wa_fldcat-coltext   = 'Inspection Remarks'.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

   CLEAR wa_fldcat.
  wa_fldcat-fieldname = 'VCODE'.
  wa_fldcat-coltext   = 'UD Code '.
  wa_fldcat-datatype  = 'CHAR'.
*  wa_fldcat-outputlen  = '20'.
  wa_fldcat-emphasize  = 'C5'.
  APPEND wa_fldcat TO it_fldcat.

*  CLEAR wa_fldcat.
*  wa_fldcat-fieldname = 'VCODE'.
*  wa_fldcat-coltext   = 'UD Code '.
*  wa_fldcat-datatype  = 'CHAR'.
**  wa_fldcat-outputlen  = '20'.
*  wa_fldcat-emphasize  = 'C5'.
*  APPEND wa_fldcat TO it_fldcat.
*

"Added by UDAYABAP03 on 16.04.2026



  v_cnt = 1.
  it_qamv1 = it_qamv[].
  SORT it_qamv1 BY verwmerkm.
  DELETE ADJACENT DUPLICATES FROM it_qamv1 COMPARING verwmerkm.
  LOOP AT it_qamv1 INTO wa_qamv1.
    v_cnt1 = v_cnt.
    CONDENSE v_cnt1.
    CLEAR wa_fldcat.
*    CONCATENATE v_cnt1 '_VERWMERKM' INTO wa_fldcat-fieldname.
*    wa_fldcat-fieldname = 'VERWMERKM'.
    REPLACE ALL OCCURRENCES OF ')' IN wa_qamv1-verwmerkm WITH ' ' .
    REPLACE ALL OCCURRENCES OF '(' IN wa_qamv1-verwmerkm WITH ' ' .
    REPLACE ALL OCCURRENCES OF '"' IN wa_qamv1-verwmerkm WITH ' ' .
    CONDENSE wa_qamv1-verwmerkm NO-GAPS.
    wa_fldcat-fieldname = wa_qamv1-verwmerkm.
    wa_fldcat-coltext   = wa_qamv1-verwmerkm.
*    wa_fldcat-outputlen  = ''.
    wa_fldcat-datatype  = 'CHAR'.
    APPEND wa_fldcat TO it_fldcat.
    CLEAR : wa_qamv1.
    v_cnt = v_cnt + 1.
  ENDLOOP.

  CALL METHOD cl_alv_table_create=>create_dynamic_table
    EXPORTING
*     I_STYLE_TABLE             =
      it_fieldcatalog           = it_fldcat
*     I_LENGTH_IN_BYTE          =
    IMPORTING
      ep_table                  = new_table
*     E_STYLE_FNAME             =
    EXCEPTIONS
      generate_subpool_dir_full = 1
      OTHERS                    = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  ASSIGN new_table->* TO <dyn_table>.

* Create dynamic work area and assign to FS
  CREATE DATA new_line LIKE LINE OF <dyn_table>.
  ASSIGN new_line->* TO <dyn_wa>.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_data .
  LOOP AT it_qamv INTO wa_qamv.
    CLEAR : <dyn_wa>.

    READ TABLE it_qals INTO wa_qals WITH KEY prueflos = wa_qamv-prueflos.
    IF sy-subrc = 0.
      CLEAR : fieldname, fieldvalue.
      fieldname = 'WERK'.
      fieldvalue = wa_qals-werk.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'MATNR'.
      fieldvalue = wa_qals-matnr.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'KTEXTMAT'.
      fieldvalue = wa_qals-ktextmat.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'MBLNR'.
      fieldvalue = wa_qals-mblnr.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.


      CLEAR : fieldname, fieldvalue.
      fieldname = 'INSPTYPE'.
      fieldvalue = wa_qals-art.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'LOSMENGE'.
      fieldvalue = wa_qals-losmenge.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'ENSTEHDAT'.
      fieldvalue = wa_qals-enstehdat.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'AENDERER'.
      fieldvalue = wa_qals-aenderer.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'ERSTELLER'.
      fieldvalue = wa_qals-ersteller.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.

      CLEAR : fieldname, fieldvalue.
      fieldname = 'CHARG'.
      fieldvalue = wa_qals-charg.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.
    ENDIF.

    CLEAR : fieldname, fieldvalue.
    fieldname  = 'PRUEFLOS'.
    fieldvalue = wa_qamv-prueflos.
    CONDENSE fieldvalue.
    ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
    <fs1> = fieldvalue.


*    CLEAR : fieldname, fieldvalue.
*    fieldname  = 'VERWMERKM'.
*    fieldvalue = wa_qamv-verwmerkm.
*    CONDENSE fieldvalue.
*    ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
*    <fs1> = fieldvalue.

    CLEAR : fieldname, fieldvalue.
    fieldname  = 'PMETHODE'.
    fieldvalue = wa_qamv-pmethode.
    CONDENSE fieldvalue.
    ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
    <fs1> = fieldvalue.

    CLEAR : fieldname, fieldvalue.
    fieldname  = 'KURZTEXT'.
    fieldvalue = wa_qamv-kurztext.
    CONDENSE fieldvalue.
    ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
    <fs1> = fieldvalue.

    READ TABLE it_qamr INTO wa_qamr WITH KEY  prueflos = wa_qamv-prueflos
                                               merknr = wa_qamv-merknr.
    CLEAR : fieldname, fieldvalue.
*    CONCATENATE gs_ekpo-ebelp '_MATNR' INTO fieldname.
    CONDENSE wa_qamv-verwmerkm NO-GAPS.
    fieldname = wa_qamv-verwmerkm.
    fieldvalue = wa_qamr-original_input.
    CONDENSE fieldvalue.
    ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
    <fs1> = fieldvalue.
*******************************    for code group
    READ TABLE it_qpac INTO wa_qpac WITH KEY werks = wa_qamv-auswmgwrk1
                                             katalogart = wa_qamv-katalgart1
                                             auswahlmge = wa_qamv-auswmenge1.
    IF sy-subrc = 0.
      READ TABLE it_qpct INTO wa_qpct WITH KEY codegruppe = wa_qpac-codegruppe
                                               code       = wa_qpac-code.
      CLEAR : fieldvalue.
      fieldvalue = wa_qpct-kurztext.
      CONDENSE fieldvalue.
      ASSIGN COMPONENT fieldname OF STRUCTURE <dyn_wa> TO <fs1>.
      <fs1> = fieldvalue.
    ENDIF.
    APPEND <dyn_wa> TO <dyn_table>.
    CLEAR : wa_qamv, wa_qamr,wa_qpac,wa_qpct.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  ALV_DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_display .
  gs_layout1-col_opt   = 'X'.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
    EXPORTING
      i_callback_program = sy-repid
      is_layout_lvc      = gs_layout1
      it_fieldcat_lvc    = it_fldcat[]
*     I_GRID_SETTINGS    = gs_grid
*     IT_EVENTS          = lt_evts[]
*     IT_EVENTS          = I_EVENTS
      i_default          = 'X'
      i_save             = 'A'
*     IS_VARIANT         = GS_VARIANT1
* IMPORTING
*     E_EXIT_CAUSED_BY_CALLER  =
*     ES_EXIT_CAUSED_BY_USER   =
    TABLES
      t_outtab           = <dyn_table>
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.

  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.
