*&---------------------------------------------------------------------*
*& Include          ZPP_DEPENDENCY_UPLOAD_SEL
*&---------------------------------------------------------------------*


*--- Selection-screen texts
*SELECTION-SCREEN COMMENT /1(50) text-001. " e.g. 'Dependency Upload Utility'

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS: p_cre  RADIOBUTTON GROUP grp1 USER-COMMAND rchg,
            p_edit RADIOBUTTON GROUP grp1,
            p_stat RADIOBUTTON GROUP grp1.
SELECTION-SCREEN PUSHBUTTON /1(25) text-002 USER-COMMAND tmpl. " 'Download Template'
PARAMETERS: p_file TYPE localfile.
SELECTION-SCREEN END OF BLOCK b1.
