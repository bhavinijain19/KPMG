*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBATCH_MONTH....................................*
DATA:  BEGIN OF STATUS_ZBATCH_MONTH                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBATCH_MONTH                  .
CONTROLS: TCTRL_ZBATCH_MONTH
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBATCH_MONTH                  .
TABLES: ZBATCH_MONTH                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
