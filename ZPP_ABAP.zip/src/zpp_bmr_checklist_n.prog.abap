*&---------------------------------------------------------------------*
*& Report  ZPP_BMR_CHECKLIST
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Module Pool      : ZPP_BMR_CHECKLIST_N                          ---*
*&--Package          : ZPP_ABAP                                     ---*
*&--Description      : Module Pool for BMR CheckList                ---*
*&--Transaction Code : ZPP_BMR_CHECKLIST _n                         ---*
*&--Technical Owner  : AKSHAY SOMVANSHI ( Squirrel )                ---*
*&--Functional Owner : VAIBHAV JADHAV                               ---*
*&--TR No            : DEVK951382                                   ---*
*&---------------------------------------------------------------------*
REPORT zpp_bmr_checklist_n.

INCLUDE zpp_bmr_checklist_n_top.
INCLUDE zpp_bmr_checklist_n_sel.
INCLUDE zpp_bmr_checklist_n_sub.

START-OF-SELECTION.
  PERFORM read_data.
