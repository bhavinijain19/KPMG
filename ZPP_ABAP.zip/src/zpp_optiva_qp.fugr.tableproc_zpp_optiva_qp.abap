*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_OPTIVA_QP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_OPTIVA_QP       .

  PERFORM TABLEPROC.

ENDFUNCTION.
