*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_CUST_FIELDS.................................*
DATA:  BEGIN OF STATUS_ZPP_CUST_FIELDS               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_CUST_FIELDS               .
CONTROLS: TCTRL_ZPP_CUST_FIELDS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZPP_CUST_FIELDS               .
TABLES: ZPP_CUST_FIELDS                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
