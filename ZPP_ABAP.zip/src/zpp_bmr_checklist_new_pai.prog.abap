*&---------------------------------------------------------------------*
*& Include          ZPP_BMR_CHECKLIST_NEW_PAI
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_NEW_PAI
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.
  CASE ok_code1.
    WHEN 'BACK' OR 'CANCEL' OR 'EXIT'.
      LEAVE TO SCREEN 0.
    WHEN '&SUBMIT'.
      PERFORM save_pdf.
      REFRESH: lt_tbctrl[] , lt_checklist[].
      CLEAR : lv_flag , counter , counter1.
      """"added by akshay dt.02.06.2025
          WHEN '&SUBMIT_P'.
      PERFORM save_pdf_p.
      REFRESH: lt_tbctrl[] , lt_checklist[].
      CLEAR : lv_flag , counter , counter1.
      """"eoc dt.02.06.2025
    WHEN '&CLEAR_N'.
      CLEAR : lv_flag , p_aufnr , counter , counter1.
      REFRESH: lt_tbctrl[] , lt_checklist[] ,lt_listtab[].
      REFRESH : it_afko[], it_rseb[] , it_makt[] , it_rseb1[] , it_rseb2[] , lt_listtab[].
    WHEN 'ENTER'.
      PERFORM get_orderdata.
    WHEN OTHERS.
  ENDCASE.
ENDMODULE.

*&SPWIZARD: INPUT MODULE FOR TC 'LT_TAB_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: MODIFY TABLE
MODULE lt_tab_ctrl_modify INPUT.
  MODIFY lt_tbctrl
    FROM ls_tbctrl
    INDEX lt_tab_ctrl-current_line.
ENDMODULE.

*&SPWIZARD: INPUT MODUL FOR TC 'LT_TAB_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: MARK TABLE
MODULE lt_tab_ctrl_mark INPUT.
  DATA: g_lt_tab_ctrl_wa2 LIKE LINE OF lt_tbctrl.
  IF lt_tab_ctrl-line_sel_mode = 1
  AND ls_tbctrl-sel = 'X'.
    LOOP AT lt_tbctrl INTO g_lt_tab_ctrl_wa2
      WHERE sel = 'X'.
      g_lt_tab_ctrl_wa2-sel = ''.
      MODIFY lt_tbctrl
        FROM g_lt_tab_ctrl_wa2
        TRANSPORTING sel.
    ENDLOOP.
  ENDIF.
  MODIFY lt_tbctrl
    FROM ls_tbctrl
    INDEX lt_tab_ctrl-current_line
    TRANSPORTING sel.
ENDMODULE.

*&SPWIZARD: INPUT MODULE FOR TC 'LT_TAB_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: PROCESS USER COMMAND
MODULE lt_tab_ctrl_user_command INPUT.
  ok_code1 = sy-ucomm.
  PERFORM user_ok_tc USING    'LT_TAB_CTRL'
                              'LT_TBCTRL'
                              'SEL'
                     CHANGING ok_code1.
  sy-ucomm = ok_code1.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_ACTUAL_QTY  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_actual_qty INPUT.
  IF ls_tbctrl-act_qty CA sy-abcde.
    MESSAGE 'Alpha-Numeric Input Not ALlowed' TYPE 'I' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

**  IF ls_tbctrl-act_tmp CA sy-abcde.
**    MESSAGE 'Alpha-Numeric Input Not ALlowed' TYPE 'I' DISPLAY LIKE 'E'.
**    RETURN.
**  ENDIF.

  IF ls_tbctrl-act_time_hr_f CA sy-abcde.
    MESSAGE 'Alpha-Numeric Input Not ALlowed' TYPE 'I' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  IF ls_tbctrl-act_time_hr_t CA sy-abcde.
    MESSAGE 'Alpha-Numeric Input Not ALlowed' TYPE 'I' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_ORDER  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_order INPUT.
  DATA: lv_werks TYPE werks_d.
  CLEAR: lv_werks.
  SELECT SINGLE werks FROM aufk INTO lv_werks WHERE aufnr = p_aufnr.
  IF lv_werks IS NOT INITIAL.
    AUTHORITY-CHECK OBJECT 'ZBMR_WERKS' ID 'WERKS' FIELD lv_werks
                                        ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not Authorized for Order:-' && p_aufnr && ' and Plant Code:-' && lv_werks TYPE 'E'.
    ELSE.
      IF p_aufnr IS NOT INITIAL.
        SELECT SINGLE * FROM afko INTO @DATA(ls_afko) WHERE aufnr = @p_aufnr.
        IF sy-subrc <> 0.
          MESSAGE 'Please Enter Correct Order Number' TYPE 'E'.
        ENDIF.
      ENDIF."IF p_aufnr IS NOT INITIAL.
    ENDIF."Auth Object.
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_ORDERHELP  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_orderhelp INPUT.
  DATA: gt_return  TYPE TABLE OF ddshretval,
        gwa_return TYPE ddshretval.
  SELECT DISTINCT aufnr
          FROM afko
          INTO TABLE @DATA(lt_afko).

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'WERKS'
      value_org       = 'S'
    TABLES
      value_tab       = lt_afko
      return_tab      = gt_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.

  READ TABLE gt_return INTO gwa_return INDEX 1.
  IF gwa_return IS NOT INITIAL.
    p_aufnr = gwa_return-fieldval.
  ENDIF."IF gwa_return IS NOT INITIAL.
ENDMODULE.
