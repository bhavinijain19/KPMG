class ZCL_ZPP_JOB_CARD_MPC_EXT definition
  public
  inheriting from ZCL_ZPP_JOB_CARD_MPC
  create public .

public section.

  types:
    BEGIN OF ty_deep_entity,
             filename   TYPE zpp_bmr_list_st-filename,
             toitems TYPE STANDARD TABLE OF ts_jobcarditems WITH DEFAULT KEY,
           END OF ty_deep_entity .

  methods DEFINE
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZPP_JOB_CARD_MPC_EXT IMPLEMENTATION.


  METHOD define.
    super->define( ).
    DATA(lo_entity_type) = model->get_entity_type( iv_entity_name = 'JobCardHeader' ). " Your wrapper entity name
    lo_entity_type->bind_structure( iv_structure_name = 'ZCL_ZPP_JOB_CARD_MPC_EXT=>TY_DEEP_ENTITY' ). " Your deep structure name
  ENDMETHOD.
ENDCLASS.
