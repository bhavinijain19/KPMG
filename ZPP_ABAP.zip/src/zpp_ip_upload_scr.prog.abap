*&---------------------------------------------------------------------*
*& Include          ZPP_IP_UPLOAD_SCR
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&                           SELECTION SCREEN
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-101.
  PARAMETERS:p_flname TYPE localfile .                        "FILE PATH
SELECTION-SCREEN END OF BLOCK b1.
SELECTION-SCREEN: BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-102.
  SELECTION-SCREEN PUSHBUTTON /2(25) btn_tpl USER-COMMAND dtl.
SELECTION-SCREEN: END OF BLOCK b2.
