*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_OPTIVA_LOGTOP.                " Global Declarations
  INCLUDE LZPP_OPTIVA_LOGUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_OPTIVA_LOGF...                " Subroutines
* INCLUDE LZPP_OPTIVA_LOGO...                " PBO-Modules
* INCLUDE LZPP_OPTIVA_LOGI...                " PAI-Modules
* INCLUDE LZPP_OPTIVA_LOGE...                " Events
* INCLUDE LZPP_OPTIVA_LOGP...                " Local class implement.
* INCLUDE LZPP_OPTIVA_LOGT99.                " ABAP Unit tests
  INCLUDE LZPP_OPTIVA_LOGF00                      . " subprograms
  INCLUDE LZPP_OPTIVA_LOGI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
