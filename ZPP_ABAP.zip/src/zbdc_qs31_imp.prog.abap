*&---------------------------------------------------------------------*
*&  Include           ZBDC_QS31_IMP
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  F4_FILENAME
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_filename .
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
    IMPORTING
      file_name     = p_file.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload_file .
  REFRESH : it_final[],it_error[].
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = t_raw
      i_filename           = p_file
    TABLES
      i_tab_converted_data = it_final
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  CLEAR p_file.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FCAT_LOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fcat_log .
  REFRESH : it_fcat[].
  wa_fcat-fieldname = 'MESG_TYPE'.
  wa_fcat-seltext_m = 'Message Type'.
  wa_fcat-tabname   =  'IT_ERROR'.
  APPEND wa_fcat TO it_fcat.

  wa_fcat-fieldname = 'MESSAGE'.
  wa_fcat-seltext_m = 'Message'.
  wa_fcat-tabname   =  'IT_ERROR'.
  APPEND wa_fcat TO it_fcat.

  wa_layout-zebra = 'X'.
  wa_layout-colwidth_optimize = 'X'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_MSG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_msg .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      is_layout          = wa_layout
      it_fieldcat        = it_fcat
    TABLES
      t_outtab           = it_error.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CALL_BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM call_bdc .
  LOOP AT it_final INTO wa_final.

    PERFORM bdc_dynpro      USING 'SAPMQSCA' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RMQSC-REF_WERKS'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ST'.
    PERFORM bdc_field       USING 'QMTB-WERKS'
                                  wa_final-plant.
    PERFORM bdc_field       USING 'QMTB-PMTNR'
                                  wa_final-insp_method.
    PERFORM bdc_field       USING 'QMTB-GUELTIGAB'
                                  wa_final-valid_from.
    PERFORM bdc_dynpro      USING 'SAPMQSCA' '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'QMTB-SORTFELD'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'QMTB-LOEKZ'
                                  wa_final-status.
    PERFORM bdc_field       USING 'VSKT-KURZTEXT'
                                  wa_final-short_dis.
    PERFORM bdc_field       USING 'QMTB-SORTFELD'
                                  wa_final-serch_field.
    PERFORM bdc_dynpro      USING 'SAPMQSCA' '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'QMTB-LOEKZ'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
**perform bdc_field       using 'QMTB-LOEKZ'
**                              record-LOEKZ_007.
**perform bdc_field       using 'VSKT-KURZTEXT'
**                              record-KURZTEXT_008.
**perform bdc_field       using 'QMTB-SORTFELD'
**                              record-SORTFELD_009.
    REFRESH : it_messtab[].
    gs_ctu_params-dismode = p_mode.
    gs_ctu_params-updmode = 'A'.
    gs_ctu_params-defsize = 'X'.
    gs_ctu_params-nobinpt = 'X'.
    CALL TRANSACTION 'QS31' USING it_bdcdata OPTIONS FROM gs_ctu_params
                           MESSAGES INTO it_messtab.


    LOOP AT it_messtab INTO wa_messtab.

      CALL FUNCTION 'FORMAT_MESSAGE'
        EXPORTING
          id   = sy-msgid
          lang = '-D'
          no   = wa_messtab-msgnr
          v1   = wa_messtab-msgv1
          v2   = wa_messtab-msgv2
          v3   = wa_messtab-msgv3
          v4   = wa_messtab-msgv4
        IMPORTING
          msg  = v_msg.

      IF sy-subrc EQ 0.
        wa_error-message = v_msg.
        wa_error-mesg_type = wa_messtab-msgtyp.
        APPEND wa_error TO it_error.
        CLEAR: wa_error, wa_messtab.
      ENDIF.
      CLEAR :wa_final.
    ENDLOOP.
**  REFRESH : it_messtab[],it_error[].
**  gs_ctu_params-dismode = p_mode.
**  gs_ctu_params-updmode = 'A'.
**  gs_ctu_params-defsize = 'X'.
**  gs_ctu_params-nobinpt = 'X'.
**  CALL TRANSACTION 'QS31' USING it_bdcdata OPTIONS FROM gs_ctu_params
**                         MESSAGES INTO it_messtab.
**
**
**  LOOP AT it_messtab INTO wa_messtab.
**
**    CALL FUNCTION 'FORMAT_MESSAGE'
**      EXPORTING
**        id   = sy-msgid
**        lang = '-D'
**        no   = wa_messtab-msgnr
**        v1   = wa_messtab-msgv1
**        v2   = wa_messtab-msgv2
**        v3   = wa_messtab-msgv3
**        v4   = wa_messtab-msgv4
**      IMPORTING
**        msg  = v_msg.
**
**    IF sy-subrc EQ 0.
**      wa_error-message = v_msg.
**      wa_error-mesg_type = wa_messtab-msgtyp.
**      APPEND wa_error TO it_error.
**      CLEAR: wa_error, wa_messtab.
**    ENDIF.
    REFRESH it_bdcdata[].
  ENDLOOP.

  REFRESH it_messtab[].

ENDFORM.

FORM bdc_dynpro  USING   program TYPE any dynpro TYPE any.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = c_x.
  APPEND wa_bdcdata TO it_bdcdata.
  CLEAR wa_bdcdata.
ENDFORM.                    " BDC_DYNPRO
*&---------------------------------------------------------------------*
*&      Form  BDC_FIELD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0380   text
*      -->P_WA_EDUCATION_ZCERTIFICATES4  text
*----------------------------------------------------------------------*
FORM bdc_field  USING  fnam TYPE any fval TYPE any.
  wa_bdcdata-fnam = fnam .
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata .
  CLEAR wa_bdcdata.
ENDFORM.
