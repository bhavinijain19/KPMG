*----------------------------------------------------------------------*
***INCLUDE ZXCOFI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0900  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0900 INPUT.
  wa_afru = afru.
  DATA: lv_fieldname TYPE string.

" --- Validation for ZZRRES1 through ZZRRES6 ---
DO 6 TIMES.
  lv_fieldname = 'AFRU-ZZRRES' && sy-index.
  ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<fs_value>).

  IF <fs_value> IS NOT INITIAL.
    " Check Prefix: Must start with 'ZR'
    IF <fs_value>(2) NE 'ZR'.
       MESSAGE e004(zpp) WITH 'Field must start with ZR'.
    ENDIF.

    " Check Database
    SELECT SINGLE zzreas FROM zpp_reason INTO @DATA(lv_temp)
      WHERE zzreas = @<fs_value>.
    IF sy-subrc NE 0.
      MESSAGE e004(zpp). " Database error
    ENDIF.
  ENDIF.
ENDDO.

" --- Validation for ZZMACH1 through ZZMACH6 ---
DO 6 TIMES.
  lv_fieldname = 'AFRU-ZZMACH' && sy-index.
  ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<fs_mach>).

  IF <fs_mach> IS NOT INITIAL.
    " Check Prefix: Must start with 'ZM'
    IF <fs_mach>(2) NE 'ZM'.
       MESSAGE e005(zpp) WITH 'Field must start with ZM'.
    ENDIF.

    " Check Database
    SELECT SINGLE zzreas FROM zpp_reason INTO @lv_temp
      WHERE zzreas = @<fs_mach>.
    IF sy-subrc NE 0.
      MESSAGE e005(zpp).
    ENDIF.
  ENDIF.
ENDDO.

DO 6 TIMES.
  lv_fieldname = 'AFRU-ZZRES' && sy-index.
  ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<fs_mach1>).

  IF <fs_mach1> IS NOT INITIAL.
    " Check Prefix: Must start with 'ZM'
    IF <fs_mach1>(2) NE 'ZS'.
       MESSAGE e005(zpp) WITH 'Field must start with ZS'.
    ENDIF.

    " Check Database
    SELECT SINGLE zzreas FROM zpp_reason INTO @lv_temp
      WHERE zzreas = @<fs_mach1>.
    IF sy-subrc NE 0.
      MESSAGE e005(zpp).
    ENDIF.
  ENDIF.
ENDDO.
*
*
*
*" -------- ZZRRES* --------
*IF afru-zzrres1 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help3_1)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres1.
*  IF sy-subrc NE 0.
*      MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*
*  ENDIF.
*ENDIF.
*
*IF afru-zzrres2 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help3_2)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres2.
*  IF sy-subrc NE 0.
*     MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*
*  ENDIF.
*ENDIF.
*
*IF afru-zzrres3 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help3_3)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres3.
*  IF sy-subrc NE 0.
*    MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzrres4 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help3_4)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres4.
*  IF sy-subrc NE 0.
*     MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzrres5 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help5)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres5.
*  IF sy-subrc NE 0.
*     MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzrres6 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_help6)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzrres6.
*  IF sy-subrc NE 0.
*     MESSAGE e004(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*" -------- ZZMACH* --------
*IF afru-zzmach1 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm1)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach1.
*  IF sy-subrc NE 0.
*     MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzmach2 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm2)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach2.
*  IF sy-subrc NE 0.
*     MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzmach3 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm3)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach3.
*  IF sy-subrc NE 0.
*      MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzmach4 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm4)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach4.
*  IF sy-subrc NE 0.
*      MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzmach5 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm5)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach5.
*  IF sy-subrc NE 0.
*      MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*
*IF afru-zzmach6 IS NOT INITIAL.
*  SELECT SINGLE *
*    INTO @DATA(t_helpm6)
*    FROM zpp_reason
*    WHERE zzreas = @afru-zzmach6.
*  IF sy-subrc NE 0.
*     MESSAGE e005(zpp) DISPLAY LIKE 'S'.
*  ENDIF.
*ENDIF.
*ENDMODULE.                 " USER_COMMAND_0900  INPUT
ENDMODULE.                 " USER_COMMAND_0900  INPUT
