FUNCTION-POOL ZBATCH_MATGRP              MESSAGE-ID SV.

* INCLUDE LZBATCH_MATGRPD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBATCH_MATGRPT00                       . "view rel. data dcl.
