*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_TOP
*&---------------------------------------------------------------------*

TYPE-POOLS : slis , abap.

DATA : ok_code01 TYPE sy-ucomm,
       ok_code02 TYPE sy-ucomm.
DATA : lv_subrc  LIKE sy-subrc,
       lt_it_tab TYPE filetable.
DATA : lv_screen  TYPE sy-dynnr,
       lv_aufnr   TYPE aufnr,
       lv_flag    TYPE c,
       lv_cflag   TYPE c,
       gt_content TYPE STANDARD TABLE OF tdline,
       gs_content TYPE tdline.

TYPES : BEGIN OF ty_column,
          column_name(30)   TYPE c,
          column_value(255) TYPE c,
        END OF ty_column.

TYPES : BEGIN OF ty_checklist,
          sel(1)       TYPE c,
          aufnr        TYPE aufnr,
          process_txt  TYPE char255,
          matnr        TYPE matnr,
          contribution TYPE p LENGTH 5 DECIMALS 2,
          std_tmp      TYPE p LENGTH 5,
          act_tmp      TYPE p LENGTH 5,
        END OF ty_checklist,
        BEGIN OF ty_log,
          sr_no        TYPE i,
          werks        TYPE werks_d,
          sf_matnr     TYPE zpp_bmr_list-sf_matnr,
          stlal        TYPE zpp_bmr_list-stlal,
          process_txt  TYPE zpp_bmr_list-process_txt,
          matnr        TYPE zpp_bmr_list-matnr,
          contribution TYPE zpp_bmr_list-contribution,
          std_tmp      TYPE zpp_bmr_list-std_tmp,
          std_time     TYPE zpp_bmr_list-std_time,
          msg1(255)    TYPE c,
          msg2(255)    TYPE c,
          flag(1)      TYPE c,
          version      TYPE i, """added by akshay dt.15.07.2025
        END OF ty_log,
        BEGIN OF ty_final,
          sr_no        TYPE i,
          werks        TYPE werks_d,
          sf_matnr     TYPE zpp_bmr_list-sf_matnr,
          stlal        TYPE zpp_bmr_list-stlal,
          process_txt  TYPE zpp_bmr_list-process_txt,
          matnr        TYPE zpp_bmr_list-matnr,
          contribution TYPE zpp_bmr_list-contribution,
          std_tmp      TYPE zpp_bmr_list-std_tmp,
          std_time     TYPE zpp_bmr_list-std_time,
          version      TYPE i, """added by akshay dt.15.07.2025
        END OF ty_final,

        BEGIN OF ty_bom,
          sf_matnr TYPE zpp_bmr_list-sf_matnr,
          stlal    TYPE zpp_bmr_list-stlal,
          matnr    TYPE zpp_bmr_list-matnr,
        END OF ty_bom.

DATA : lt_exfinal TYPE TABLE OF ty_final,
       ls_exfinal TYPE ty_final,
       lt_bom     TYPE TABLE OF ty_bom,
       ls_bom     TYPE ty_bom,
       lt_log     TYPE TABLE OF ty_log,
       ls_log     TYPE ty_log.
TYPES : ty_bom1 TYPE STANDARD TABLE OF ty_bom WITH EMPTY KEY.

DATA: lt_final TYPE TABLE OF zpp_bmr_list,
      ls_final TYPE zpp_bmr_list.
DATA : lt_fieldcat TYPE slis_t_fieldcat_alv,
       ls_fieldcat TYPE slis_fieldcat_alv,
       lt_header   TYPE slis_t_listheader,
       ls_header   TYPE slis_listheader,
       lt_sort     TYPE slis_t_sortinfo_alv,
       ls_sort     TYPE slis_sortinfo_alv,
       ls_layout   TYPE slis_layout_alv,
       ls_variant  TYPE disvariant.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CHECKLIST_TC' ITSELF
CONTROLS: lt_checklist_tc TYPE TABLEVIEW USING SCREEN 9001.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CHECKLIST_TC'
DATA:     g_lt_checklist_tc_lines  LIKE sy-loopc.

DATA:     ok_code LIKE sy-ucomm.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCD' ITSELF
CONTROLS: lt_ch_tcd TYPE TABLEVIEW USING SCREEN 9003.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCD'
DATA:     g_lt_ch_tcd_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCC' ITSELF
CONTROLS: lt_ch_tcc TYPE TABLEVIEW USING SCREEN 9004.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCC'
DATA:     g_lt_ch_tcc_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TC' ITSELF
CONTROLS: lt_ch_tc TYPE TABLEVIEW USING SCREEN 9001.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TC'
DATA:     g_lt_ch_tc_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCD1' ITSELF
CONTROLS: lt_ch_tcd1 TYPE TABLEVIEW USING SCREEN 9003.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCD1'
DATA:     g_lt_ch_tcd1_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCC1' ITSELF
CONTROLS: lt_ch_tcc1 TYPE TABLEVIEW USING SCREEN 9004.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCC1'
DATA:     g_lt_ch_tcc1_lines  LIKE sy-loopc.
DATA : ftp_handle       TYPE i,
       ftp_rfc_dest_aux LIKE rfcdes-rfcdest VALUE 'SAPFTPA',
       ftp_command(120) TYPE c,
       ftp_result       TYPE sdoki_ftp_result_t,
       pwd(30)          TYPE c,
       key              TYPE i VALUE 26101957,
       slen             TYPE i.
CONSTANTS   : c_tvarvc_matcre  TYPE rvari_vnam VALUE 'ZMM_OPTIVA_PATH'.
CONSTANTS : c_tvarvc_user TYPE rvari_vnam VALUE 'BARCODE_USER'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_pwd TYPE rvari_vnam VALUE 'BARCODE_PWD'.   "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_host TYPE rvari_vnam VALUE 'BARCODE_HOST'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_dest TYPE rvari_vnam VALUE 'BARCODE_DEST'. "Using it from ZMM_MAT_DATA report

CONSTANTS:
c_tvarvc_name TYPE rvari_vnam VALUE 'OPTIVA_BOM'.
CONSTANTS:
c_tvarvc_name1 TYPE rvari_vnam VALUE 'OPTIVA_BOM_DELE'.

CONSTANTS:
c_tvarvc_name2 TYPE rvari_vnam VALUE 'OPTIVA_BOM_MAIL'.


CONSTANTS:
pc_tvarvc_name TYPE rvari_vnam VALUE 'POPTIVA_BOM'.  "Added by Raj on 17.01.2025
CONSTANTS:
pc_tvarvc_name1 TYPE rvari_vnam VALUE 'POPTIVA_BOM_DELE'."Added by Raj on 17.01.2025

CONSTANTS:
pc_tvarvc_name2 TYPE rvari_vnam VALUE 'POPTIVA_BOM_MAIL'."Added by Raj on 17.01.2025




DATA: bcode_user TYPE char200.
DATA: bcode_pwd TYPE char200.
DATA: bcode_host TYPE char200.
DATA: bcode_dest TYPE char200.

DATA: matcre_path(500).

DATA: l_user(30) TYPE c, "VALUE 'APTLSFTP', "user name of ftp server
      l_pwd(30)  TYPE c, "VALUE 'Astral123', "password of ftp server
      l_host(64) TYPE c, "VALUE '192.168.54.74', "ip address of FTP server
      l_dest     LIKE rfcdes-rfcdest.
DATA: w_hdl  TYPE i,
      c_key  TYPE i VALUE 26101957,
      l_slen TYPE i.

DATA: BEGIN OF itab_tmp OCCURS 1,
        line(600)             ,
      END OF itab_tmp       .


"""""XML Read"""""

DATA: gcl_xml       TYPE REF TO cl_xml_document.

TYPES : BEGIN OF ty_files,
          appsrv_fname TYPE localfile, " rlgrap-filename,
        END   OF ty_files.

DATA: t_file_list TYPE TABLE OF epsfili WITH HEADER LINE,
      t_files     TYPE TABLE OF ty_files WITH HEADER LINE.

DATA: wrk_file1    LIKE epsf-epsdirnam,
      wrk_file2    LIKE epsf-epsdirnam,
      wrk_email    LIKE epsf-epsdirnam,
      lv_filename1 TYPE rcgfiletr-ftappl,
      lv_string    TYPE text4096.

DATA: gv_subrc      TYPE sy-subrc.

DATA: gv_xml_string TYPE string.
DATA:  wrk_bom_email TYPE adr6-smtp_addr.
*data:  wrk_bom_email type adr6-SMTP_ADDR.
TYPES: BEGIN OF ty_final_n,
         value TYPE string,
       END OF ty_final_n.
DATA: lt_final_n TYPE TABLE OF ty_final_n,
      ls_final_n TYPE ty_final_n.

TYPES: BEGIN OF ty_xml,

         raw(2000) TYPE c,

       END OF ty_xml.

*      Declaring the XML internal table

DATA:  g_t_xml_tab TYPE TABLE OF ty_xml INITIAL SIZE 0.
DATA:  wa_xml_tab TYPE ty_xml.
DATA:  g_xmldata TYPE xstring.
DATA:  g_t_xml_info TYPE TABLE OF smum_xmltb INITIAL SIZE 0.
DATA: gwa_xml_data  TYPE smum_xmltb.
DATA:  g_t_return TYPE STANDARD TABLE OF bapiret2.



DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.

DATA:    p_mode    TYPE ctu_params-dismode VALUE 'N'.
DATA  : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

"""""""Mail Sending

DATA : lo_mime_helper TYPE REF TO cl_gbt_multirelated_service,
       lo_bcs         TYPE REF TO cl_bcs,
       lo_doc_bcs     TYPE REF TO cl_document_bcs,
       lo_recipient   TYPE REF TO if_recipient_bcs,
       lt_soli        TYPE TABLE OF soli,
       ls_soli        TYPE soli,
       lv_status      TYPE bcs_rqst.

TYPES : BEGIN OF t_message ,
*           lifnr   TYPE char10  , " Customer Number
          status  TYPE char4   , " Light Indicator
          vendor  TYPE char15,
          type    TYPE char4   , " Error Type
          message TYPE char255 , " Message Description
        END OF t_message    .

DATA: i_message   TYPE STANDARD TABLE OF t_message.
DATA: i_message1  TYPE STANDARD TABLE OF t_message.

DATA:count  TYPE i.
FIELD-SYMBOLS :
  <x_message>  TYPE t_message,
  <x_message1> TYPE t_message.
DATA: mt_columns TYPE TABLE OF ty_column.
DATA: gv_plant TYPE werks_d.
