*----------------------------------------------------------------------*
***INCLUDE ZXCOFI02.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse INPUT.
  CLEAR : p_value,p_field.
  GET CURSOR FIELD p_value.
  IF p_value CS 'ZZRES'.
    p_field = 'ZS*'.
  ELSEIF p_value CS 'ZZRRES'.
    p_field = 'ZR*'.
  ELSEIF p_value CS 'ZZMACH'.
    p_field = 'ZM*'.
  ENDIF.
  PERFORM f_help USING p_field CHANGING p_value.
ENDMODULE.                 " HELP_REUSE  INPUT
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE2  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse2 INPUT.
  p_value = 'AFRU-ZZRRES2'.
  PERFORM f_help USING 'ZR*' CHANGING p_value.
ENDMODULE.                 " HELP_REUSE2  INPUT
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE3  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse3 INPUT.
  p_value = 'AFRU-ZZRRES3'.
  PERFORM f_help USING 'ZR*' CHANGING p_value.
ENDMODULE.                 " HELP_REUSE2  INPUT
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE4  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse4 INPUT.
  p_value = 'AFRU-ZZRRES4'.
  PERFORM f_help USING 'ZR*' CHANGING p_value.
ENDMODULE.                 " HELP_REUSE2  INPUT
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE5  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse5 INPUT.
  p_value = 'AFRU-ZZRRES5'.
  PERFORM f_help USING 'ZR*' CHANGING p_value.
ENDMODULE.                 " HELP_REUSE2  INPUT
*&---------------------------------------------------------------------*
*&      Module  HELP_REUSE6  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE help_reuse6 INPUT.
  p_value = 'AFRU-ZZRRES6'.
  PERFORM f_help USING 'ZR*' CHANGING p_value.
ENDMODULE.                 " HELP_REUSE2  INPUT
