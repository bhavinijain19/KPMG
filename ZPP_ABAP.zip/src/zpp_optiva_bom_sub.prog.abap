*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_BOM_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  READ_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM read_data .

*****Transfer files from FTP to AL11
  DATA: lv_cmd    TYPE  char18  , "      sxpgcolist-name VALUE 'ZOPTIVB',
        lv_status TYPE extcmdexex-status,
        lv_code   TYPE extcmdexex-exitcode.

  IF v_rcl = 'X'.  "Added  by Raj on 17.01.2025
    lv_cmd = 'ZOPTIVB'.
  ELSEIF v_p = 'X'.
    lv_cmd = 'ZPOPTIVB'.
  ENDIF.



  DATA: t_result         TYPE STANDARD TABLE OF btcxpm.
*  IF c_excel IS INITIAL. """added by akshay dt.24.03.2025
    CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
      EXPORTING
        commandname                   = lv_cmd
*       ADDITIONAL_PARAMETERS         = lv_parm
*       OPERATINGSYSTEM               = SY-OPSYS
*       TARGETSYSTEM                  = SY-HOST
*       DESTINATION                   =
*       STDOUT                        = 'X'
*       STDERR                        = 'X'
*       TERMINATIONWAIT               = 'X'
*       TRACE                         =
*       DIALOG                        =
      IMPORTING
        status                        = lv_status
        exitcode                      = lv_code
      TABLES
        exec_protocol                 = t_result
      EXCEPTIONS
        no_permission                 = 1
        command_not_found             = 2
        parameters_too_long           = 3
        security_risk                 = 4
        wrong_check_call_interface    = 5
        program_start_error           = 6
        program_termination_error     = 7
        x_error                       = 8
        parameter_expected            = 9
        too_many_parameters           = 10
        illegal_command               = 11
        wrong_asynchronous_parameters = 12
        cant_enq_tbtco_entry          = 13
        jobcount_generation_error     = 14
        OTHERS                        = 15.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
       WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

*  ENDIF ."""added by akshay dt.24.03.2025
*****Transfer of file end

  """""""Read file from AL11"""""
*  CREATE OBJECT gcl_xml.

* begin  of code added on 18.05.2020


  IF v_rcl = 'X'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*            INTO wrk_file1
*            FROM tvarvc
*            WHERE name = c_tvarvc_name .

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = C_TVARVC_NAME
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    SELECT SINGLE low
        INTO wrk_file2
        FROM tvarvc
        WHERE name = c_tvarvc_name1 .



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_email
*        FROM tvarvc
*        WHERE name = c_tvarvc_name2 .

SELECT LOW
 INTO WRK_EMAIL FROM TVARVC UP TO 1 ROWS WHERE NAME = C_TVARVC_NAME2
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    wrk_bom_email = wrk_email.

  ELSEIF v_p = 'X'.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_file1
*        FROM tvarvc
*        WHERE name = pc_tvarvc_name .

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = PC_TVARVC_NAME
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    SELECT SINGLE low
        INTO wrk_file2
        FROM tvarvc
        WHERE name = pc_tvarvc_name1 .



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_email
*        FROM tvarvc
*        WHERE name = pc_tvarvc_name2 .

SELECT LOW
 INTO WRK_EMAIL FROM TVARVC UP TO 1 ROWS WHERE NAME = PC_TVARVC_NAME2
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    wrk_bom_email = wrk_email.
  ENDIF.


*  wrk_file1 = '  \\SAPDEV\sapmnt\trans\OPTIVA\IMPORT'.

  CALL FUNCTION 'EPS_GET_DIRECTORY_LISTING '
    EXPORTING
*     dir_name     = '/usr/sap/trans/' "p_dirnam "'/usr/sap/trans/RTGS'
*     dir_name     = '\\SAPDEV\sapmnt\trans\hsbcpmt\inward' "Added on 09.04.2020 by JKT
*     dir_name     = '\\SAPDEV\sapmnt\trans\OPTIVA\IMPORT' "Added on 09.04.2020 by JKT
      dir_name     = wrk_file1
      file_mask    = '*.*'
    TABLES
      dir_list     = t_file_list
    EXCEPTIONS
      access_error = 1
      OTHERS       = 2.
  IF sy-subrc IS INITIAL.
    LOOP AT t_file_list .
      t_files-appsrv_fname = t_file_list-name.
      APPEND t_files.
      CLEAR  t_files.
    ENDLOOP.
  ENDIF.

  DELETE t_files WHERE appsrv_fname+0(1) <> 'M' AND appsrv_fname+0(2) <> 'SF'.

  LOOP AT t_files.

    CONCATENATE wrk_file1 '/' t_files-appsrv_fname INTO lv_filename1.
    CONDENSE: lv_filename1.
    OPEN DATASET  lv_filename1 FOR INPUT IN TEXT MODE ENCODING DEFAULT.

    "Adding Start by Rahul Vasita on 15.03.2024 17:18:29
    SELECT SINGLE file_name user_name  u_date  u_time
      FROM zpp_optiva_log
      INTO CORRESPONDING FIELDS OF ls_log
      WHERE file_name = t_files-appsrv_fname.
    IF sy-subrc <> 0.
      ls_log-file_name = t_files-appsrv_fname.
      ls_log-u_date = sy-datum.
      ls_log-user_name = sy-uname.
      ls_log-u_time = sy-uzeit.
      ls_log-mandt = sy-mandt.
      "Adding End by Rahul Vasita on 15.03.2024 17:18:29

      CLEAR: gv_xml_string,wa_xml_tab,g_xmldata.
      REFRESH: g_t_xml_tab,g_t_xml_info,g_t_return.



      DO.
        READ DATASET  lv_filename1 INTO wa_xml_tab .
        IF sy-subrc NE 0.
          EXIT.
        ELSE.
          CONDENSE wa_xml_tab.
          APPEND  wa_xml_tab TO  g_t_xml_tab.
        ENDIF.
      ENDDO.

      IF g_t_xml_tab IS NOT INITIAL.
        CONCATENATE LINES OF g_t_xml_tab INTO gv_xml_string SEPARATED BY space.
      ENDIF.

      PERFORM data_upload.

    ENDIF."End of LS_LOG "Added by Rahul Vasita on 15.03.2024 17:18:13
    IF c_excel IS INITIAL.  """added by akshay dt.24.03.2025
      PERFORM delete_file .
    ENDIF. """EOC by akshay dt.24.03.2025
    CLEAR : ls_log. "Added by Rahul Vasita on 15.03.2024 17:22:51


  ENDLOOP.

  """""""End of code""""""""



*  SELECT SINGLE low
*        INTO matcre_path
*        FROM tvarvc
*        WHERE name = c_tvarvc_matcre.
*
*  SELECT SINGLE low
*          INTO bcode_user
*          FROM tvarvc
*          WHERE name = c_tvarvc_user .
*
*  SELECT SINGLE low
*          INTO bcode_pwd
*          FROM tvarvc
*          WHERE name = c_tvarvc_pwd .
*
*  SELECT SINGLE low
*          INTO bcode_host
*          FROM tvarvc
*          WHERE name = c_tvarvc_host .
*
*  SELECT SINGLE low
*          INTO bcode_dest
*          FROM tvarvc
*          WHERE name = c_tvarvc_dest .
*
*  l_user = bcode_user.
*  l_pwd = bcode_pwd.
*  l_host = bcode_host.
*  l_dest = bcode_dest.
*
**HTTP_SCRAMBLE: used to scramble the password provided in a format recognized by SAP.
*  SET EXTENDED CHECK OFF.
*  l_slen = strlen( l_pwd ).
*  CALL FUNCTION 'HTTP_SCRAMBLE'
*    EXPORTING
*      source      = l_pwd
*      sourcelen   = l_slen
*      key         = c_key
*    IMPORTING
*      destination = l_pwd.
*
** To Connect to the Server using FTP
*  CALL FUNCTION 'FTP_CONNECT'
*    EXPORTING
*      user            = l_user
*      password        = l_pwd
*      host            = l_host
*      rfc_destination = l_dest
*    IMPORTING
*      handle          = w_hdl
*    EXCEPTIONS
*      OTHERS          = 1.
*
*  CONCATENATE 'CD' '/OPTIVA/DEV/IMPORT' INTO ftp_command SEPARATED BY space.
*
*  CALL FUNCTION 'FTP_COMMAND'
*    EXPORTING
*      handle        = ftp_handle
*      command       = ftp_command
*    TABLES
*      data          = ftp_result
*    EXCEPTIONS
*      tcpip_error   = 1
*      command_error = 2
*      data_error    = 3.
*
*  CALL FUNCTION 'FTP_SERVER_TO_R3'
*    EXPORTING
*      handle         = ftp_handle
*      fname          = 'merchant-20150917-161638.xls' "result-line+56(44)
*      character_mode = 'X'
*    TABLES
*      text           = itab_tmp
*    EXCEPTIONS
*      tcpip_error    = 1
*      command_error  = 2
*      data_error     = 3
*      OTHERS         = 4.
*
**FTP_DISCONNECT: This is used to disconnect the connection between SAP and other system.
** To disconnect the FTP
*  CALL FUNCTION 'FTP_DISCONNECT'
*    EXPORTING
*      handle = w_hdl.
**RFC_CONNECTION_CLOSE:This is used to disconnect the RFC connection between SAP and other system.
*  CALL FUNCTION 'RFC_CONNECTION_CLOSE'
*    EXPORTING
*      destination = l_dest
*    EXCEPTIONS
*      OTHERS      = 1.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_upload .

  CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
    EXPORTING
      text   = gv_xml_string
    IMPORTING
      buffer = g_xmldata
    EXCEPTIONS
      failed = 1
      OTHERS = 2.

  IF sy-subrc NE 0.
    MESSAGE 'Error in the XML file' TYPE 'E'.
  ENDIF.

  CALL FUNCTION 'SMUM_XML_PARSE'
    EXPORTING
      xml_input = g_xmldata
    TABLES
      xml_table = g_t_xml_info
      return    = g_t_return
    EXCEPTIONS
      OTHERS    = 0.

*”If XML parsing is not successful, return table will contain error messages
  READ TABLE g_t_return INTO DATA(wa_return) WITH KEY type = 'E'.

  IF sy-subrc EQ 0.
    MESSAGE 'Error converting the input XML file' TYPE 'E'.

  ELSE.
    REFRESH g_t_return.
    PERFORM data_operation.
  ENDIF.



ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_OPERATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_operation .

  DATA: flag TYPE flag.
  CLEAR :flag,gwa_xml_data.
  DATA:fsformulaingr TYPE string.
  DATA: matno(255).
  CLEAR fsformulaingr.
  CLEAR:ls_final1.REFRESH: lt_final1.
*  sort g_t_xml_info by cname.

  LOOP AT g_t_xml_info INTO gwa_xml_data .
    IF gwa_xml_data-cname = 'FSFORMULAINGR'.
      flag = 'X'.
      fsformulaingr = 'FSFORMULAINGR'.
    ENDIF.

    IF gwa_xml_data-cname = 'FORMULA_CODE'.
      IF ls_final1-item_code_matno IS INITIAL.
        ls_final1-item_code_matno = gwa_xml_data-cvalue.

      ENDIF.
    ELSEIF gwa_xml_data-cname = 'YIELD'.
      ls_final1-yeild_baseqty = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'C_EFFECTIVE_FROM'.
      CONCATENATE gwa_xml_data-cvalue+8(2) gwa_xml_data-cvalue+5(2) gwa_xml_data-cvalue+0(4) INTO ls_final1-c_effictive_from SEPARATED BY '.'.
*    ELSEIF gwa_xml_data-cname = 'ATTRIB_VAL'.
    ELSEIF gwa_xml_data-cname = 'PLANT_CODE'.
      IF ls_final1-attrib_val_plant IS INITIAL.
        ls_final1-attrib_val_plant = gwa_xml_data-cvalue.
      ENDIF.
      """"Line items
    ELSEIF gwa_xml_data-cname = 'ITEM_CODE'.
      ls_final1-item_code_bom_bomcomp = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'QUANTITY'.
      ls_final1-quantity = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'UOM_CODE'.
      ls_final1-uom_code_comp_unit_of_measure = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE1'.
      ls_final1-attribute1_bom_usage = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE2'.
      ls_final1-attribute2_alt_bom = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE3'.
      ls_final1-attribute3_change_no = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE4'.
      ls_final1-attribute4_bom_status = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE5'.
      ls_final1-attribute5_item_cat = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE6'.
      ls_final1-attribute6_sort_string = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE7'.
      ls_final1-attribute7_item_no = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE8'.
      ls_final1-attribute8_comp_scrap = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE9'.
      ls_final1-attribute9_sel_indctr = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE10'.
      ls_final1-attribute10_co_product = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE11'.
      ls_final1-attribute11_sel_indctr = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE12'.
      ls_final1-attribute12_indct_costing = gwa_xml_data-cvalue.
    ENDIF.
    IF ls_final1-attribute12_indct_costing = '1'.
      ls_final1-attribute12_indct_costing = 'X'.
    ENDIF.

    IF ls_final1-item_code_matno IS NOT INITIAL AND ls_final1-attrib_val_plant IS NOT INITIAL.
      CONCATENATE ls_final1-item_code_matno ls_final1-attrib_val_plant INTO ls_final1-item_code_matnoplant.
    ENDIF.

    IF flag = 'X' AND fsformulaingr = 'FSFORMULAINGR'.
      APPEND ls_final1 TO lt_final1.
      CLEAR:  ls_final1-item_code_bom_bomcomp,ls_final1-quantity,ls_final1-uom_code_comp_unit_of_measure,
              ls_final1-attribute1_bom_usage,ls_final1-attribute2_alt_bom,ls_final1-attribute3_change_no,
              ls_final1-attribute4_bom_status,ls_final1-attribute5_item_cat,ls_final1-attribute6_sort_string,
              ls_final1-attribute7_item_no,ls_final1-attribute8_comp_scrap,ls_final1-attribute9_sel_indctr,
              ls_final1-attribute10_co_product ,ls_final1-attribute11_sel_indctr, ls_final1-attribute12_indct_costing,matno.
      CLEAR: flag,fsformulaingr.
    ENDIF.
  ENDLOOP.

  IF ls_final1 IS NOT INITIAL.
    APPEND ls_final1 TO lt_final1.
    CLEAR: ls_final1.
    DELETE lt_final1 INDEX 1.
  ENDIF.

*  WRITE: 'Test'.
  IF c_excel IS NOT INITIAL.
    IF lt_final1[] IS NOT INITIAL .
      PERFORM download_excel_file.
    ENDIF.
    """EOC DT.19.03.2025
  ELSE."""ADDED BY AKSHAY DT.19.03.2025
    PERFORM bdc_upload.

  ENDIF. """ADDED BY AKSHAY DT.19.03.2025

**  PERFORM bdc_upload.  """commented by akshay dt.19.03.2025

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FINAL1  text
*----------------------------------------------------------------------*
FORM bdc_upload.

  SORT lt_final1 BY item_code_matno.
  DATA : flag(1) TYPE c.
  DATA : temp_comp LIKE rc29p-idnrk.
  DATA : temp_date LIKE rc29n-datuv.
  DATA : temp_mat_no LIKE rc29n-matnr.

  CLEAR: ls_final1. REFRESH: messtab.

  LOOP AT lt_final1 INTO ls_final1.


    IF ls_final1-item_code_matno = '' OR ls_final1-attrib_val_plant = ''.
      ""Send mail operation
      PERFORM send_mail.
      CONTINUE.
    ENDIF.

    temp_mat_no = ls_final1-item_code_matno.
    PERFORM comp CHANGING temp_mat_no.
    ls_final1-item_code_matno = temp_mat_no.

    temp_comp = ls_final1-item_code_bom_bomcomp.
    PERFORM comp CHANGING temp_comp.
    ls_final1-item_code_bom_bomcomp = temp_comp.

    MODIFY lt_final1 FROM ls_final1.

    ON CHANGE OF ls_final1-item_code_matnoplant.
*    ON CHANGE OF ls_final1-item_code_matno.
      flag = 0.

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0100'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29N-STLAN'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RC29N-MATNR'
                                    ls_final1-item_code_matno.
      PERFORM bdc_field       USING 'RC29N-WERKS'
                                    ls_final1-attrib_val_plant.
      PERFORM bdc_field       USING 'RC29N-STLAN'
                                    ls_final1-attribute1_bom_usage.

*        perform bdc_field       using 'RC29N-STLAL'
*                                      ''.
*      PERFORM bdc_field       USING 'RC29N-AENNR'
**                                    zbom-change_no.
*                                     ls_final1-attribute3_change_no.
      PERFORM bdc_field       USING 'RC29N-DATUV'
*                                    zbom-valid_from.
                                     ls_final1-c_effictive_from.

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0110'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RC29K-BMENG'
*                                    zbom-base_qty.
                                     ls_final1-yeild_baseqty. " CHANGE 21.12.2022
      PERFORM bdc_field       USING 'RC29K-STLST'
*                                    zbom-status.
                                     ls_final1-attribute4_bom_status.

*        perform bdc_field       using 'BDC_CURSOR'
*                                      'RC29K-EXSTL'.
*

      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0111'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29K-LABOR'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.


**************************ITEM DATA**********************************


      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC29P-POSTP(02)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.

      IF flag = 0.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
      ELSE.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=FCNP'.
        flag = 1.
      ENDIF.

    ENDON.

******************SECTION INDICATOR*************************************

    PERFORM bdc_field       USING 'RC29P-POSNR(02)'
*                                  zbom-item_number.
                                   ls_final1-attribute7_item_no.
    PERFORM bdc_field       USING 'RC29P-IDNRK(02)'
*                                  zbom-component.
                                   ls_final1-item_code_bom_bomcomp.
    PERFORM bdc_field       USING 'RC29P-MENGE(02)'
*                                  zbom-qty.
                                    ls_final1-quantity.
    PERFORM bdc_field       USING 'RC29P-MEINS(02)'
*                                  zbom-uom.
                                    ls_final1-uom_code_comp_unit_of_measure.
    PERFORM bdc_field       USING 'RC29P-POSTP(02)'
*                                  zbom-item_cat.
                                   ls_final1-attribute5_item_cat.
    PERFORM bdc_field       USING 'RC29P-SORTF(02)'
*                                  zbom-sort_string.
                                   ls_final1-attribute6_sort_string.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29K-STKTX'.

    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0130'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-KZKUP'.
    PERFORM bdc_field       USING 'RC29P-POSNR'
*                                    zbom-item_number.
                                   ls_final1-attribute7_item_no.
    PERFORM bdc_field       USING 'RC29P-IDNRK'
*                                  zbom-component.
                                   ls_final1-item_code_bom_bomcomp.
    PERFORM bdc_field       USING 'RC29P-MENGE'
*                                  zbom-qty.
                                   ls_final1-quantity.
    PERFORM bdc_field       USING 'RC29P-MEINS'
*                                  zbom-uom.
                                   ls_final1-uom_code_comp_unit_of_measure.
    PERFORM bdc_field       USING 'RC29P-AUSCH'
*                                  zbom-scrap.
                                   ls_final1-attribute8_comp_scrap.

*    if zbom-qty < 0.
*      perform bdc_field     using 'RC29P-KZKUP'
*                                  'X'.
*    else.

    PERFORM bdc_field     USING 'RC29P-KZKUP'
*                                zbom-co_product.
                                 ls_final1-attribute10_co_product.
*    endif.

    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0131'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-POTX1'.
    PERFORM bdc_field       USING 'RC29P-LGORT'
                                  ls_final1-attribute11_sel_indctr.
*                                  zbom-storage_loc.  "Doubt on Storage Location
    IF ls_final1-attribute12_indct_costing IS INITIAL.
      CLEAR ls_final1-attribute12_indct_costing.
    ENDIF.
    PERFORM bdc_field       USING 'RC29P-SANKA'
*                                  zbom-rel_cost.
                                  ls_final1-attribute12_indct_costing.


    PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.

    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC29P-AUSKZ(02)'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=FCNP'.
    PERFORM bdc_field       USING 'RC29P-AUSKZ(02)'
                                  'X'.
    AT END OF item_code_matno.
      PERFORM bdc_dynpro      USING 'SAPLCSDI' '0140'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=FCBU'.
      CALL TRANSACTION 'CS01' USING bdcdata MODE p_mode UPDATE 'S'
                                  MESSAGES INTO messtab[].

      IF messtab[] IS NOT INITIAL.
        PERFORM process_message.
      ENDIF.

      REFRESH bdcdata.
    ENDAT.

  ENDLOOP.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  COMP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_TEMP_MAT_NO  text
*----------------------------------------------------------------------*
FORM comp  CHANGING temp_comp.

  CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
    EXPORTING
      input        = temp_comp
    IMPORTING
      output       = temp_comp
    EXCEPTIONS
      length_error = 1
      OTHERS       = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.

FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO

FORM bdc_field USING fnam fval.
*  IF fval <> ''.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
*  ENDIF.
ENDFORM. "BDC_FIELD
*&---------------------------------------------------------------------*
*&      Form  SEND_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_mail .
  CLEAR: ls_soli.
  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  IF ls_final1-item_code_matno = ''.
    ls_soli-line = '<P>Material Number is missing.-</P>'.
    APPEND ls_soli TO lt_soli.
  ENDIF.

  IF ls_final1-attrib_val_plant = ''.
    ls_soli-line = '<P>Plant is missing.-</P>'.
    APPEND ls_soli TO lt_soli.
  ENDIF.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Error in inspection file'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Missing fields in inspection file'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).

  lo_bcs->set_document( i_document = lo_doc_bcs ).

* Set the email address
  lo_recipient = cl_cam_address_bcs=>create_internet_address(
                    i_address_string =  wrk_bom_email ).

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DELETE_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM delete_file.
  DATA:  lv_tpath  LIKE sapb-sappfad.

*CONCATENATE wrk_file1 t_files-appsrv_fname INTO lv_tpath.
*lv_tpath = '\\SAPDEV\sapmnt\trans\archfile'.
  CONCATENATE wrk_file2 t_files-appsrv_fname INTO lv_tpath.
*lv_filename1
*--DELETE FILE ON THE APPLICATION SERVER AFTER DOWNLOAD
  CALL FUNCTION 'ARCHIVFILE_SERVER_TO_SERVER'
    EXPORTING
      sourcepath       = lv_filename1+0(70)
      targetpath       = lv_tpath
    EXCEPTIONS
      error_file       = 1
      no_authorization = 2
      OTHERS           = 3.
  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*      WRITE :  50  'NO' COLOR 7.
  ELSE.
*      WRITE :  50  'YES' COLOR 5.
  ENDIF.

  INSERT zpp_optiva_log FROM ls_log. "Added by Rahul Vasita on 15.03.2024 17:29:44

  DELETE DATASET lv_filename1.
*   ENDIF.
*   REFRESH: gt_main,it_error.
*   CLEAR: lv_count.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PROCESS_MESSAGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_message .

  DATA : lv_msg TYPE string,
         wa_msg TYPE bdcmsgcoll.
  REFRESH: i_message, i_message1.
  CLEAR: wa_msg.
  LOOP AT messtab INTO wa_msg.

    CALL FUNCTION 'FORMAT_MESSAGE'
      EXPORTING
        id   = wa_msg-msgid
        lang = sy-langu
        no   = wa_msg-msgnr
        v1   = wa_msg-msgv1
        v2   = wa_msg-msgv2
        v3   = wa_msg-msgv3
        v4   = wa_msg-msgv4
      IMPORTING
        msg  = lv_msg.

    IF wa_msg-msgtyp = 'E'.

      UNASSIGN <x_message>.
      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
      IF <x_message> IS ASSIGNED.
*        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message>-status       = icon_led_green        .
*        <x_message>-vendor = ls_xk02-vendor.
        <x_message>-type         =  wa_msg-msgtyp       .
        <x_message>-message      = lv_msg                .
      ENDIF.

    ELSEIF wa_msg-msgtyp = 'S'.

      UNASSIGN <x_message1>.
      APPEND INITIAL LINE TO i_message1 ASSIGNING <x_message1>.
      IF <x_message1> IS ASSIGNED.
*        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message1>-status       = icon_led_green        .
*        <x_message>-vendor = ls_xk02-vendor.
        <x_message1>-type         =  wa_msg-msgtyp       .
        <x_message1>-message      = lv_msg                .
      ENDIF.
*      CONTINUE.
    ENDIF.

    DELETE messtab WHERE msgnr = wa_msg-msgnr.
  ENDLOOP.

  IF i_message IS NOT INITIAL.
    PERFORM send_error_mail.
  ENDIF.

  IF i_message1 IS NOT INITIAL.
    PERFORM send_success_mail.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_ERROR_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_error_mail .

  CLEAR: ls_soli.
  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>Below are the errors found while uploading BOM in SAP</P>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  LOOP AT i_message INTO DATA(ls_imessage).
    CONCATENATE '<P>' ls_imessage-message '</P>' INTO ls_soli-line.
    APPEND ls_soli TO lt_soli.
  ENDLOOP.

*ls_soli-line = '<P>Material Number is missing.-</P>'.
*APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Error while uploading BOM in SAP'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Error while uploading BOM in SAP'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).

  lo_bcs->set_document( i_document = lo_doc_bcs ).

* Set the email address
  lo_recipient = cl_cam_address_bcs=>create_internet_address(
                    i_address_string =  wrk_bom_email ).

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_SUCCESS_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_success_mail .

  CLEAR: ls_soli.
  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>Below are the success message found while uploading BOM in SAP</P>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  LOOP AT i_message INTO DATA(ls_imessage).
    CONCATENATE '<P>' ls_imessage-message '</P>' INTO ls_soli-line.
    APPEND ls_soli TO lt_soli.
  ENDLOOP.

*ls_soli-line = '<P>Material Number is missing.-</P>'.
*APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

*  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
*  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Success while uploading BOM in SAP'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Success while uploading BOM in SAP'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).

  lo_bcs->set_document( i_document = lo_doc_bcs ).

* Set the email address
  lo_recipient = cl_cam_address_bcs=>create_internet_address(
                    i_address_string =  wrk_bom_email ).

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_EXCEL_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_excel_file .
  DATA: d_count TYPE i.
  DATA: d_filename      TYPE string,
        d_path          TYPE string,
        d_fullpath      TYPE string,
        d_result        TYPE i,
        d_default_fname TYPE string,
        d_fname         LIKE rlgrap-filename.
  DATA : BEGIN OF it_header OCCURS 0,
           line(50) TYPE c,
         END OF it_header.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'File Directory'
      default_extension = 'XLS'
      initial_directory = 'D:\'
    CHANGING
      filename          = d_filename
      path              = d_path
      fullpath          = d_fullpath
      user_action       = d_result.

  CHECK sy-subrc = 0.

  it_header-line = 'item_code_matno'.
  APPEND it_header.
  it_header-line = 'yeild_baseqty'.
  APPEND it_header.
  it_header-line = 'c_effictive_from'.
  APPEND it_header.
  it_header-line = 'attrib_val_plant'.
  APPEND it_header.
  it_header-line = 'item_code_matnoplant'.
  APPEND it_header.
  it_header-line = 'item_code_bom_bomcomp'.
  APPEND it_header.
  it_header-line = 'quantity'.
  APPEND it_header.
  it_header-line = 'uom_code_comp_unit_of_measure'.
  APPEND it_header.
  it_header-line = 'attribute1_bom_usage'.
  APPEND it_header.
  it_header-line = 'attribute2_alt_bom'.
  APPEND it_header.
  it_header-line = 'attribute3_change_no'.
  APPEND it_header.
  it_header-line = 'attribute4_bom_status'.
  APPEND it_header.
  it_header-line = 'attribute5_item_cat'.
  APPEND it_header.
  it_header-line = 'attribute6_sort_string'.
  APPEND it_header.
  it_header-line = 'attribute7_item_no'.
  APPEND it_header.
  it_header-line = 'attribute8_comp_scrap'.
  APPEND it_header.
  it_header-line = 'attribute9_sel_indctr'.
  APPEND it_header.
  it_header-line = 'attribute10_co_product'.
  APPEND it_header.
  it_header-line = 'attribute11_sel_indctr'.
  APPEND it_header.
  it_header-line = 'attribute12_indct_costing'.
  APPEND it_header.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename              = d_filename
      filetype              = 'ASC'
      write_field_separator = 'X'
    TABLES
      data_tab              = lt_final1
      fieldnames            = it_header.
  IF sy-subrc = 0.
    MESSAGE i006(aq) WITH 'File was downloaded'.
  ENDIF.
ENDFORM.
