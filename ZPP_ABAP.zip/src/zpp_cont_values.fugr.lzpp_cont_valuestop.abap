FUNCTION-POOL ZPP_CONT_VALUES            MESSAGE-ID SV.

* INCLUDE LZPP_CONT_VALUESD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_CONT_VALUEST00                     . "view rel. data dcl.
