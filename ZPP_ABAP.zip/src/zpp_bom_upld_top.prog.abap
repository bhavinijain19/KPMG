*&---------------------------------------------------------------------*
*&  Include           ZPP_BOM_UPLD_TOP
*&---------------------------------------------------------------------*
TABLES t100.
DATA : BEGIN OF zbom OCCURS 0,
**    Docu_No(10)    type n,            "Legacy Document Number
         material_no    LIKE rc29n-matnr,  "Material Number
         plant          LIKE rc29n-werks,  "Plant
         bom_usage      LIKE rc29n-stlan,  "BOM Usage
         alt_bom        LIKE rc29n-stlal,  "Alternative BOM
         change_no      TYPE rc29n-aennr,  "Change No
         valid_from(10) TYPE c,
         base_qty(17)   TYPE c,            "Base quantity
         status         LIKE rc29k-stlst,  "BOM status
         component      LIKE rc29p-idnrk,  "BOM component
         qty(17)        TYPE c,            "Base quantity
         uom            LIKE rc29p-meins,  "Component unit of measure
         item_cat       LIKE rc29p-postp,  "Item category (bill of material)
         sort_string    TYPE rc29p-sortf,  "Sort String
         item_number    LIKE rc29p-posnr,  "Item Number
         scrap(7)       TYPE c,            "Component scrap in percent
         storage_loc    LIKE rc29p-lgort,  "Issue loc for production order
         rel_cost       LIKE rc29p-sanka,  "Indicator for Relevancy to Costing
         section_ind    LIKE rc29p-auskz,  "Selection indicator
         co_product     LIKE rc29p-kzkup,
       END OF zbom.

DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.
DATA  : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA: l_mstring(480).
DATA: l_subrc LIKE sy-subrc.
