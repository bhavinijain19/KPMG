*&----------------------------------------------------------------------------*
*& Report  ZPP_WORK_CENTER
*&----------------------------------------------------------------------------*
*& Title: Work Center Master Upload
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Cummins Infosystems Ltd, Pune
*& Functional Consultant : Sanjay Sahoo, KPIT Cummins Infosystems Ltd, Pune
*& Report Creation Date  : 13/10/2014
*& Transaction Code      :
*& Request Number        : DEVK900434
*&----------------------------------------------------------------------------*

REPORT zpp_work_center.

TYPES  : BEGIN OF ty_itab,
           werks(04),           " Plant
           arbpl(10),           " Work Center
           verwe(04),           " Work Center Cat.
           stext(40),           " Text
           veran(03),           " Person Responsible
           planv(03),           " Usage
           vgwts(04),           " Standard Value Key
           steus(04),           " Control Key

           kapart1(03),         " Capacity Category 1
           fork1_1(06),         " Setup Formula
           fork2_1(06),         " Processing Formula
           fork3_1(06),         " Teardown Formula
           kapart2(03),         " Capacity Category 2
           fork1_2(06),         " Setup Formula
           fork2_2(06),         " Processing Formula
           fork3_2(06),         " Teardown Formula

           ktext1(30),          " Text 1
           planr1(03),          " Capcity Planner Grp.
           kalid1(02),          " Calender ID
           meins1(03),          " Base UOM
           begzt1(08),          " Start Time
           endzt1(08),          " End Time
           pause1(08),          " Length of breaks
           ngrad1(03),          " Capacity Utilization
           aznor1(03),          " No.Of Ind. Capacity
           kapeh1(03),          " Capacity UOM

           ktext2(30),          " Text 2
           planr2(03),          " Capcity Planner Grp.
           kalid2(02),          " Calender ID
           meins2(03),          " Base UOM
           begzt2(08),          " Start Time
           endzt2(08),          " End Time
           pause2(08),          " Length of breaks
           ngrad2(03),          " Capacity Utilization
           aznor2(03),          " No.Of Ind. Capacity
           kapeh2(03),          " Capacity UOM

           kapart(03),          " Capacity Category
           fort1(06),           " Setup Formula
           fort2(06),           " Processing Formula
           fort3(06),           " Teardown Formula

           begda(10),           " Start Date
           endda(10),           " End Date
           kostl(10),           " Cost Center
           larxx1(04),          " Activity Type
           larxx2(04),          " Activity Type
           larxx3(04),          " Activity Type
           forxx1(06),          " Formula Key
           forxx2(06),          " Formula Key
           forxx3(06),          " Formula Key
         END OF ty_itab.

DATA: itab TYPE STANDARD TABLE OF ty_itab WITH HEADER LINE.
DATA : bdcdata  LIKE bdcdata    OCCURS 0 WITH HEADER LINE.
DATA : messtab  LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA : filename TYPE string.
*------------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS : ctu_mode LIKE ctu_params-dismode DEFAULT 'A'.
PARAMETERS : p_fname  LIKE ibipparms-path OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.
*------------------------------------------------------------------------*
"Upload File Name

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_fname.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = ' '
    IMPORTING
      file_name     = p_fname.
*------------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM gui_upload.
  PERFORM bdc_process.
*&---------------------------------------------------------------------*
*&      Form  GUI_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM gui_upload .
  DATA: p_fname1 TYPE rlgrap-filename.
  CLEAR filename.
  filename = p_fname.
  p_fname1 = filename.
  DATA:it_type TYPE truxs_t_text_data.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_fname1
    TABLES
      i_tab_converted_data = itab
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error In Uploading File' TYPE 'E' DISPLAY LIKE 'S'.
    RETURN.
  ENDIF.
****
****  CLEAR filename.
****  filename = p_fname.
****
****  CALL FUNCTION 'GUI_UPLOAD'
****    EXPORTING
****      filename                = filename
****      filetype                = 'ASC'
****      has_field_separator     = 'X'
****      read_by_line            = 'X'
****    TABLES
****      data_tab                = itab
****    EXCEPTIONS
****      file_open_error         = 1
****      file_read_error         = 2
****      no_batch                = 3
****      gui_refuse_filetransfer = 4
****      invalid_type            = 5
****      no_authority            = 6
****      unknown_error           = 7
****      bad_data_format         = 8
****      header_not_allowed      = 9
****      separator_not_allowed   = 10
****      header_too_long         = 11
****      unknown_dp_error        = 12
****      access_denied           = 13
****      dp_out_of_memory        = 14
****      disk_full               = 15
****      dp_timeout              = 16
****      OTHERS                  = 17.
****  IF sy-subrc <> 0.
****    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
****            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
****  ENDIF.
ENDFORM.                    " GUI_UPLOAD
*&---------------------------------------------------------------------*
*&      Form  BDC_PROCESS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc_process .
  LOOP AT itab.
    PERFORM bdc_dynpro      USING 'SAPLCRA0' '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC68A-VERWE'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=NEXT'.
    PERFORM bdc_field       USING 'RC68A-WERKS'
                                  itab-werks.               "'2000'.
    PERFORM bdc_field       USING 'RC68A-ARBPL'
                                  itab-arbpl.               "'MK1234'.
    PERFORM bdc_field       USING 'RC68A-VERWE'
                                  itab-verwe.               "'0001'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'P1000-STEXT'
                                  itab-stext.               "'Schaumanlage'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'P3000-VGWTS'.
    PERFORM bdc_field       USING 'P3000-VERAN'
                                  itab-veran.               "'100'.
    PERFORM bdc_field       USING 'P3000-PLANV'
                                  itab-planv.               "'009'.
    PERFORM bdc_field       USING 'P3000-VGWTS'
                                  itab-vgwts.               "'SAP1'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=VORA'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC68A-VGEXX(03)'.
    PERFORM bdc_field       USING 'P3003-STEUS'
                                  itab-steus.               "'PP01'.
    PERFORM bdc_field       USING 'RC68A-VGEXX(01)'
                                  'MIN'.
    PERFORM bdc_field       USING 'RC68A-VGEXX(02)'
                                  'MIN'.
    PERFORM bdc_field       USING 'RC68A-VGEXX(03)'
                                  'MIN'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=KAUE'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'P3006-FORK3(02)'.
    PERFORM bdc_field       USING 'RC68A-KAPART(01)'
                                  itab-kapart1.             "'001'.
    PERFORM bdc_field       USING 'P3006-FORK1(01)'
                                  itab-fork1_1.             "'SAP005'.
    PERFORM bdc_field       USING 'P3006-FORK1(02)'
                                  itab-fork1_2.             "'SAP005'.
    IF itab-kapart2 IS NOT INITIAL.
      PERFORM bdc_field       USING 'RC68A-KAPART(02)'
                                    itab-kapart2.             "'002'.
      PERFORM bdc_field       USING 'P3006-FORK2(01)'
                                    itab-fork2_1.             "'SAP006'.
      PERFORM bdc_field       USING 'P3006-FORK2(02)'
                                    itab-fork2_2.             "'SAP006'.
    ENDIF.


    PERFORM bdc_field       USING 'P3006-FORK3(01)'
                                  itab-fork3_1.             "'SAP007'.
    PERFORM bdc_field       USING 'P3006-FORK3(02)'
                                  itab-fork3_2.             "'SAP007'.

    PERFORM bdc_dynpro      USING 'SAPLCRK0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'KAKT-KTEXT'
                                  itab-ktext1.        "'Test_001'.
    PERFORM bdc_field       USING 'KAKO-PLANR'
                                  itab-planr1.              "'c01'.
    PERFORM bdc_field       USING 'RC68K-BEGZT'
                                  itab-begzt1.        "'07:00:00'.
    PERFORM bdc_field       USING 'RC68K-ENDZT'
                                  itab-endzt1.        "'07:00:00'.
    PERFORM bdc_field       USING 'KAKO-NGRAD'
                                  itab-ngrad1.              "'100'.
    PERFORM bdc_field       USING 'RC68K-PAUSE'
                                  itab-pause1.        "'01:00:00'.
    PERFORM bdc_field       USING 'KAKO-AZNOR'
                                  itab-aznor1.              "'1'.
    PERFORM bdc_field       USING 'KAKO-KAPEH'
                                  itab-kapeh1.        "'MIN'.
    PERFORM bdc_field       USING 'KAKO-KALID'
                                  itab-kalid1.        "'IN'.
    PERFORM bdc_field       USING 'KAKO-MEINS'
                                  itab-meins1.        "'MIN'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC68K-KAPLPL'.
    PERFORM bdc_field       USING 'KAKO-KAPTER'
                                  'X'.
    PERFORM bdc_field       USING 'KAKO-KAPAVO'
                                  'X'.
    PERFORM bdc_field       USING 'RC68K-KAPLPL'
                                  ''.
    IF itab-kapart2 IS NOT INITIAL.

      PERFORM bdc_dynpro      USING 'SAPLCRK0' '0101'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'KAKT-KTEXT'
                                    itab-ktext2.         "'Test_002'.
      PERFORM bdc_field       USING 'KAKO-PLANR'
                                    itab-planr2.              "'C01'.
      PERFORM bdc_field       USING 'RC68K-BEGZT'
                                    itab-begzt2.         "'07:00:00'.
      PERFORM bdc_field       USING 'RC68K-ENDZT'
                                    itab-endzt2.         "'07:00:00'.
      PERFORM bdc_field       USING 'KAKO-NGRAD'
                                    itab-ngrad2.              "'100'.
      PERFORM bdc_field       USING 'RC68K-PAUSE'
                                    itab-pause2.         "'01:00:00'.
      PERFORM bdc_field       USING 'KAKO-AZNOR'
                                    itab-aznor2.              "'1'.
      PERFORM bdc_field       USING 'KAKO-KAPEH'
                                    itab-kapeh2.         "'MIN'.
      PERFORM bdc_field       USING 'KAKO-KALID'
                                    itab-kalid2.          "'IN'.
      PERFORM bdc_field       USING 'KAKO-MEINS'
                                    itab-meins2.          "'MIN'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'KAKO-KAPAVO'.
      PERFORM bdc_field       USING 'KAKO-KAPTER'
                                    'X'.
      PERFORM bdc_field       USING 'KAKO-KAPAVO'
                                    'X'.
      PERFORM bdc_field       USING 'RC68K-KAPLPL'
                                    ''.
    ENDIF.
    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=TERM'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'P3006-FORK1(01)'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=VK11'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'P3005-FORT3'.
    PERFORM bdc_field       USING 'RC68A-KAPART'
                                  itab-kapart.              "'001'.
    PERFORM bdc_field       USING 'P3005-FORT1'
                                  itab-fort1.               "'SAP001'.
    PERFORM bdc_field       USING 'P3005-FORT2'
                                  itab-fort2.               "'SAP002'.
    PERFORM bdc_field       USING 'P3005-FORT3'
                                  itab-fort3.               "'SAP003'.

**    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
**    PERFORM bdc_field       USING 'BDC_OKCODE'
**                                  '=VK11'.
**    PERFORM bdc_field       USING 'BDC_CURSOR'
**                                  'RC68A-KAPART'.

    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC68A-FLG_REF(03)'.
    PERFORM bdc_field       USING 'P1001-BEGDA'
                                  itab-begda.           "'01.01.2013'.
    PERFORM bdc_field       USING 'P1001-ENDDA'
                                  itab-endda.           "'31129999'.
    PERFORM bdc_field       USING 'CRKEYK-KOSTL'
                                  itab-kostl.               "'20405'.
    PERFORM bdc_field       USING 'RC68A-LARXX(01)'
                                  itab-larxx1.              "'2020'.
    PERFORM bdc_field       USING 'RC68A-LARXX(02)'
                                  itab-larxx2.              "'2020'.
    PERFORM bdc_field       USING 'RC68A-LARXX(03)'
                                  itab-larxx3.              "'2020'.
    PERFORM bdc_field       USING 'RC68A-FORXX(01)'
                                  itab-forxx1.              "'SAP001'.
    PERFORM bdc_field       USING 'RC68A-FORXX(02)'
                                  itab-forxx2.              "'SAP002'.
    PERFORM bdc_field       USING 'RC68A-FORXX(03)'
                                  itab-forxx3.              "'SAP003'.
**    PERFORM bdc_field       USING 'RC68A-FLG_REF(01)'
**                                  'X'.
**    PERFORM bdc_field       USING 'RC68A-FLG_REF(02)'
**                                  'X'.
**    PERFORM bdc_field       USING 'RC68A-FLG_REF(03)'
**                                  'X'.
*    IF NOT itab-larxx1 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-LEINH(01)'
*                                    'hr'.
*    ENDIF.
*
*    IF NOT itab-larxx2 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-LEINH(02)'
*                                    'hr'.
*    ENDIF.
*
*    IF NOT itab-larxx3 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-LEINH(03)'
*                                    'hr'.
*    ENDIF.

*    IF NOT itab-larxx1 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-FLG_REF(01)'
*                                    'X'.
*    ENDIF.
*
*    IF NOT itab-larxx2 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-FLG_REF(02)'
*                                    'X'.
*    ENDIF.
*
*    IF NOT itab-larxx3 IS INITIAL.
*      PERFORM bdc_field       USING 'RC68A-FLG_REF(03)'
*                                    'X'.
*    ENDIF.



    PERFORM bdc_dynpro      USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=UPD'.
**    PERFORM bdc_field       USING 'BDC_CURSOR'
**                                  'RC68A-LARXX(02)'.
    CALL TRANSACTION 'CR01'  USING bdcdata
                             MODE  ctu_mode
                             UPDATE 'S'
                             MESSAGES INTO messtab.
    REFRESH bdcdata.
  ENDLOOP.
ENDFORM.                    " BDC_PROCESS
*&---------------------------------------------------------------------*
*&      Form  BDC_DYNPRO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PROGRAM    text
*      -->DYNPRO     text
*----------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO
*----------------------------------------------------------------------
*        Insert field
*----------------------------------------------------------------------
FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM. "BDC_FIELD*&---------------------------------------------------------------------*
