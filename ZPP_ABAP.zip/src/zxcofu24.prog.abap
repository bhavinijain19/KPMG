*&---------------------------------------------------------------------*
*& Include          ZXCOFU24
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZXCOFU24
*&---------------------------------------------------------------------*
MOVE     wa_afru-zzlot1  TO es_afrud-zzlot1 .
MOVE     wa_afru-zzlot2  TO es_afrud-zzlot2 .
MOVE     wa_afru-zzshift TO es_afrud-zzshift.
*MOVE     wa_afru-zzreason TO es_afrud-zzreason.
MOVE     wa_afru-zzres1  TO es_afrud-zzres1 .
MOVE     wa_afru-zzres2  TO es_afrud-zzres2 .
MOVE     wa_afru-zzres3  TO es_afrud-zzres3 .
MOVE     wa_afru-zzres4  TO es_afrud-zzres4 .
MOVE     wa_afru-zzres5  TO es_afrud-zzres5 .
MOVE     wa_afru-zzres6  TO es_afrud-zzres6 .
MOVE     wa_afru-zzquan1 TO es_afrud-zzquan1.
MOVE     wa_afru-zzquan2 TO es_afrud-zzquan2.
MOVE     wa_afru-zzquan3 TO es_afrud-zzquan3.
MOVE     wa_afru-zzquan4 TO es_afrud-zzquan4.
MOVE     wa_afru-zzquan5 TO es_afrud-zzquan5.
MOVE     wa_afru-zzquan6 TO es_afrud-zzquan6.

MOVE     wa_afru-zzrres1  TO es_afrud-zzrres1 .
MOVE     wa_afru-zzrres2  TO es_afrud-zzrres2 .
MOVE     wa_afru-zzrres3  TO es_afrud-zzrres3 .
MOVE     wa_afru-zzrres4  TO es_afrud-zzrres4 .
MOVE     wa_afru-zzrres5  TO es_afrud-zzrres5 .
MOVE     wa_afru-zzrres6  TO es_afrud-zzrres6 .
MOVE     wa_afru-zzrquan1 TO es_afrud-zzrquan1.
MOVE     wa_afru-zzrquan2 TO es_afrud-zzrquan2.
MOVE     wa_afru-zzrquan3 TO es_afrud-zzrquan3.
MOVE     wa_afru-zzrquan4 TO es_afrud-zzrquan4.
MOVE     wa_afru-zzrquan5 TO es_afrud-zzrquan5.
MOVE     wa_afru-zzrquan6 TO es_afrud-zzrquan6.


MOVE wa_afru-zzmach1  TO es_afrud-zzmach1.
MOVE wa_afru-zzmach2  TO es_afrud-zzmach2.
MOVE wa_afru-zzmach3  TO es_afrud-zzmach3.
MOVE wa_afru-zzmach4  TO es_afrud-zzmach4.
MOVE wa_afru-zzmach5  TO es_afrud-zzmach5.
MOVE wa_afru-zzmach6  TO es_afrud-zzmach6.
MOVE wa_afru-zzmquan1 TO es_afrud-zzmquan1.
MOVE wa_afru-zzmquan2 TO es_afrud-zzmquan2.
MOVE wa_afru-zzmquan3 TO es_afrud-zzmquan3.
MOVE wa_afru-zzmquan4 TO es_afrud-zzmquan4.
MOVE wa_afru-zzmquan5 TO es_afrud-zzmquan5.
MOVE wa_afru-zzmquan6 TO es_afrud-zzmquan6.
