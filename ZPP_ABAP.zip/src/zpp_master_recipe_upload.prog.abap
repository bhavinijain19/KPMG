*&---------------------------------------------------------------------*
*& Report ZPP_MASTER_RECIPE_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpp_master_recipe_upload.

INCLUDE zpp_master_recipe_upload_top.
INCLUDE zpp_master_recipe_upload_sel.
INCLUDE zpp_master_recipe_upload_f01.

*---------------------------------------------------------------------*
* SCREEN HANDLING
*---------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-group1 = 'UP'
      OR screen-group1 = 'MOD'.
      screen-input = COND #( WHEN r_up = 'X' THEN 1 ELSE 0 ).
    ENDIF.

    MODIFY SCREEN.
  ENDLOOP.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  IF r_up = 'X'.
    CALL FUNCTION 'F4_FILENAME'
      IMPORTING
        file_name = p_file.
  ENDIF.

*---------------------------------------------------------------------*
* MAIN
*---------------------------------------------------------------------*
START-OF-SELECTION.

  IF r_down = 'X'.
    PERFORM download_template.
    RETURN.
  ENDIF.
  PERFORM upload_excel.
  IF gt_excel IS NOT INITIAL.
    PERFORM execute_bdc.
  ENDIF.
