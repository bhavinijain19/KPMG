*&---------------------------------------------------------------------*
*& Include          ZPP_DEPENDENCY_UPLOAD_TOP
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Include          ZPP_DEPENDENCY_UPLOAD_TOP
*&---------------------------------------------------------------------*

TYPE-POOLS: truxs.   " Needed for TEXT_CONVERT_XLS_TO_SAP

CONSTANTS: c_lang TYPE sylangu VALUE 'E'.  " Description Language = EN

*--- Message log type for ALV
TYPES: BEGIN OF ty_msg,
         row_no   TYPE i,
         scen     TYPE char10,  " 'CREATE'/'EDITOR'/'STATUS'
         dep_name TYPE string,
         input1   TYPE string,  " dep_type / source / status
         mtype    TYPE char1,   " S/W/E/A
         mtext    TYPE string,
       END OF ty_msg.

*--- Create scenario upload row
TYPES: BEGIN OF ty_cre,
         dep_name TYPE string,
         dep_desc TYPE string,
         dep_type TYPE string,
       END OF ty_cre.

*--- Editor scenario upload row
TYPES: BEGIN OF ty_edit,
         srno     TYPE i,
         dep_name TYPE string,
         source   TYPE string,
       END OF ty_edit.

*--- Status change scenario upload row
TYPES: BEGIN OF ty_stat,
         dep_name TYPE string,
         status   TYPE string,  " we will force '3' at runtime
       END OF ty_stat.

*--- Global data: upload tables per scenario
DATA: gt_cre_up  TYPE STANDARD TABLE OF ty_cre  WITH DEFAULT KEY,
      gt_edit_up TYPE STANDARD TABLE OF ty_edit WITH DEFAULT KEY,
      gt_stat_up TYPE STANDARD TABLE OF ty_stat WITH DEFAULT KEY.

*--- Global data: ALV message log
DATA: gt_msgs TYPE STANDARD TABLE OF ty_msg WITH DEFAULT KEY.

*--- Scenario flag and file path
DATA: gv_scen TYPE char10.                        " 'CREATE'/'EDITOR'/'STATUS'

*--- ALV fieldcatalog (SLIS) and layout
DATA: gt_fcat TYPE slis_t_fieldcat_alv,
      gs_layo TYPE slis_layout_alv.

DATA: gv_row TYPE i.   " <--- ADDED: To track current processed row for ALV


*--- Track already processed dependencies in EDITOR scenario
DATA: gt_edit_done TYPE STANDARD TABLE OF string WITH DEFAULT KEY.   " <--- ADDED
