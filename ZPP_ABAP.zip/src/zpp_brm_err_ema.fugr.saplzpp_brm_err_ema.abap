*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_BRM_ERR_EMATOP.               " Global Data
  INCLUDE LZPP_BRM_ERR_EMAUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_BRM_ERR_EMAF...               " Subroutines
* INCLUDE LZPP_BRM_ERR_EMAO...               " PBO-Modules
* INCLUDE LZPP_BRM_ERR_EMAI...               " PAI-Modules
* INCLUDE LZPP_BRM_ERR_EMAE...               " Events
* INCLUDE LZPP_BRM_ERR_EMAP...               " Local class implement.
* INCLUDE LZPP_BRM_ERR_EMAT99.               " ABAP Unit tests
  INCLUDE LZPP_BRM_ERR_EMAF00                     . " subprograms
  INCLUDE LZPP_BRM_ERR_EMAI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
