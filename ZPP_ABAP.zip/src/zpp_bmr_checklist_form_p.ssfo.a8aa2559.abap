SELECT SINGLE *
  FROM afko
  INTO @DATA(ls_afko)
  WHERE aufnr = @aufnr_imp.
IF ls_afko IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*  SELECT SINGLE plnty,
*                plnnr,
*                plnkn,
*                zaehl,
*                arbid
*    FROM plpo
*    INTO @DATA(ls_plpo)
*    WHERE plnty = @ls_afko-plnty
*      AND plnnr = @ls_afko-plnnr
*      AND zaehl = @ls_afko-plnal.

  SELECT plnty,
         plnnr,
         plnkn,
         zaehl,
         arbid
    FROM plpo UP TO 1 ROWS
    INTO @DATA(ls_plpo)
    WHERE plnty = @ls_afko-plnty
      AND plnnr = @ls_afko-plnnr
      AND zaehl = @ls_afko-plnal ORDER BY PRIMARY KEY.
    ENDSELECT.
******************end of ATC changes 13/02/26   UDAYABAP03*************
ENDIF.

IF ls_plpo IS NOT INITIAL.
  SELECT SINGLE arbpl
      FROM crhd
      INTO lv_arbpl
      WHERE objty = 'A' AND objid = ls_plpo-arbid.
ENDIF.








































