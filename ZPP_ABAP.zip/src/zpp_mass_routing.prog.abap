*&---------------------------------------------------------------------*
*& Report  ZPP_MASS_ROUTING
*&
*&---------------------------------------------------------------------*
*& Created By     : Carina Jose
*& Creation Date  : 06/06/2020
*&---------------------------------------------------------------------*
REPORT zpp_mass_routing.

TABLES : mapl,plko,plpo,crhd,crve_b.
SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS : s_matnr FOR mapl-matnr,
                   s_werks FOR mapl-werks OBLIGATORY,
                   s_plnty FOR mapl-plnty DEFAULT 'N' NO INTERVALS,
                   s_plnal FOR mapl-plnal.

*PARAMETERS     : p_delkz AS CHECKBOX,
*                 p_all   AS CHECKBOX.
********************************************Added by Raj on 24.05.2023***********************************
  SELECTION-SCREEN BEGIN OF  BLOCK b2 WITH FRAME TITLE TEXT-002.
    PARAMETERS: "p_delkz  RADIOBUTTON GROUP r1 USER-COMMAND abc,
      p_loekz  RADIOBUTTON GROUP r1 USER-COMMAND abc,
      p_active RADIOBUTTON GROUP r1,
      p_all    RADIOBUTTON GROUP r1,
      "Added by UDAYABAP03 on 11.03.2026
      p_master RADIOBUTTON GROUP r1.
    "Added by UDAYABAP03 on 11.03.2026
  SELECTION-SCREEN END OF BLOCK b2.
********************************************Added by Raj on 24.05.2023***********************************

SELECTION-SCREEN : END OF BLOCK a1.

TYPES: BEGIN OF ty_t001w,
         werks TYPE werks_d,
       END OF ty_t001w.
DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w,
       wa_t001w TYPE ty_t001w.

TYPES : BEGIN OF ty_final,
          matnr TYPE mapl-matnr,
          werks TYPE mapl-werks,
          plnal TYPE mapl-plnal,
          ltxa1 TYPE plpo-ltxa1,  " Operation short text
          meinh TYPE plpo-meinh,
          bmsch TYPE plpo-bmsch,
          lar01 TYPE plpo-lar01,
          vge01 TYPE plpo-vge01,
          vgw01 TYPE plpo-vgw01,
          lar02 TYPE plpo-lar02,
          vge02 TYPE plpo-vge02,
          vgw02 TYPE plpo-vgw02,
          lar03 TYPE plpo-lar02,
          vge04 TYPE plpo-vge04, "Added by Bhaumik
          vgw04 TYPE plpo-vgw04, "Added by Bhaumik
          lar04 TYPE plpo-lar04, "Added by Bhaumik
          vge05 TYPE plpo-vge05, "Added by Bhaumik
          vgw05 TYPE plpo-vgw05, "Added by Bhaumik
          lar05 TYPE plpo-lar05, "Added by Bhaumik
          vge06 TYPE plpo-vge06, "Added by Bhaumik
          vgw06 TYPE plpo-vgw06, "Added by Bhaumik
          lar06 TYPE plpo-lar06, "Added by Bhaumik
          vge03 TYPE plpo-vge02,
          vgw03 TYPE plpo-vgw02,
          arbpl TYPE crhd-arbpl, " Work Center
          equnr TYPE crve_b-equnr, " Equipment Number
          maktg TYPE makt-maktg,
          ktext TYPE crtx-ktext, " Short Description
          plnnr TYPE mapl-plnnr, " Added by Raj on 24.10.2024
          delkz	TYPE cp_delkz, "Added by UDAYABAP03 on 11.03.2026
        END OF ty_final.


TYPES : BEGIN OF ty_mapl,
          matnr TYPE mapl-matnr,
          werks TYPE mapl-werks,
          plnty TYPE mapl-plnty,
          plnnr TYPE mapl-plnnr,
          plnal TYPE mapl-plnal,
          zkriz TYPE mapl-zkriz,
          zaehl TYPE mapl-zaehl,
        END OF ty_mapl.

TYPES : BEGIN OF ty_plko,
          plnty TYPE plko-plnty,
          plnnr TYPE plko-plnnr,
          plnal TYPE plko-plnal,
          zaehl TYPE plko-zaehl,
          delkz	TYPE cp_delkz, "Added by UDAYABAP03 on 11.03.2026
        END OF ty_plko.



TYPES : BEGIN OF ty_plpo,
          plnty TYPE plpo-plnty,
          plnnr TYPE plpo-plnnr,
          zaehl TYPE plpo-zaehl,
          arbid TYPE plpo-arbid,
          objty TYPE plpo-objty,
          ltxa1 TYPE plpo-ltxa1,
          meinh TYPE plpo-meinh,
          bmsch TYPE plpo-bmsch,
          lar01 TYPE plpo-lar01,
          vge01 TYPE plpo-vge01,
          vgw01 TYPE plpo-vgw01,
          lar02 TYPE plpo-lar02,
          vge02 TYPE plpo-vge02,
          vgw02 TYPE plpo-vgw02,
          lar03 TYPE plpo-lar02,
          vge03 TYPE plpo-vge02,
          vgw03 TYPE plpo-vgw02,
          vge04 TYPE plpo-vge04, "Added by Bhaumik
          vgw04 TYPE plpo-vgw04, "Added by Bhaumik
          lar04 TYPE plpo-lar04, "Added by Bhaumik
          vge05 TYPE plpo-vge05, "Added by Bhaumik
          vgw05 TYPE plpo-vgw05, "Added by Bhaumik
          lar05 TYPE plpo-lar05, "Added by Bhaumik
          vge06 TYPE plpo-vge06, "Added by Bhaumik
          vgw06 TYPE plpo-vgw06, "Added by Bhaumik
          lar06 TYPE plpo-lar06, "Added by Bhaumik
        END OF ty_plpo.

TYPES : BEGIN OF ty_crve_b,
          equnr TYPE crve_b-equnr,
          objty TYPE crve_b-objty,
          objid TYPE crve_b-objid,
        END OF ty_crve_b.

TYPES : BEGIN OF ty_plfh,
          plnty TYPE plfh-plnty,
          plnnr TYPE plfh-plnnr,
          pzlfh TYPE plfh-pzlfh,
          zaehl TYPE plfh-zaehl,
          objty TYPE plfh-objty,
          objid TYPE plfh-objid,
        END OF ty_plfh.

TYPES : BEGIN OF ty_crhd,
          objty TYPE crhd-objty,
          objid TYPE crhd-objid,
          arbpl TYPE crhd-arbpl,
        END OF ty_crhd.

TYPES : BEGIN OF ty_makt,
          matnr TYPE makt-matnr,
          spras TYPE makt-spras,
          maktg TYPE makt-maktg,
        END OF ty_makt.

TYPES : BEGIN OF ty_crtx,
          objty TYPE crtx-objty,
          objid TYPE crtx-objid,
          spras TYPE crtx-spras,
          ktext TYPE crtx-ktext,
        END OF ty_crtx.

DATA : it_mapl   TYPE STANDARD TABLE OF ty_mapl,
       wa_mapl   TYPE ty_mapl,
       it_plko   TYPE STANDARD TABLE OF ty_plko,
       wa_plko   TYPE ty_plko,
       it_plpo   TYPE STANDARD TABLE OF ty_plpo,
       wa_plpo   TYPE ty_plpo,
       it_plfh   TYPE STANDARD TABLE OF ty_plfh,
       wa_plfh   TYPE ty_plfh,
       it_crve_b TYPE STANDARD TABLE OF ty_crve_b,
       wa_crve_b TYPE ty_crve_b,
       it_crhd   TYPE STANDARD TABLE OF ty_crhd,
       wa_crhd   TYPE ty_crhd,
       it_makt   TYPE STANDARD TABLE OF ty_makt,
       wa_makt   TYPE ty_makt,
       it_crtx   TYPE STANDARD TABLE OF ty_crtx,
       wa_crtx   TYPE ty_crtx,
       it_final  TYPE STANDARD TABLE OF ty_final,
       wa_final  TYPE ty_final.

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE.



START-OF-SELECTION.
  PERFORM authorization_check.
  IF p_master = 'X'.  "Added by UDAYABAP03 on 11.03.2026
    PERFORM get_master. "Added by UDAYABAP03 on 11.03.2026
  ELSE.
    PERFORM get_data.
    PERFORM fill_fieldcatalog.
    PERFORM display_grid.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .


**********************************************
  SELECT matnr werks plnty plnnr plnal zkriz zaehl
    INTO CORRESPONDING FIELDS OF TABLE it_mapl
    FROM mapl
    WHERE matnr IN s_matnr AND
          werks IN s_werks AND
          plnty IN s_plnty AND
          plnal IN s_plnal.


  IF it_mapl IS NOT INITIAL.

    SELECT matnr spras maktg
      INTO CORRESPONDING FIELDS OF TABLE it_makt
      FROM makt
      FOR ALL ENTRIES IN it_mapl
      WHERE matnr = it_mapl-matnr AND
            spras = sy-langu.

****Changes by Squirrel(Manoj) for excluding cancelled list groups

    SELECT plnty,plnnr,plnal,zaehl FROM plas INTO TABLE @DATA(lt_plas)
        FOR ALL ENTRIES IN @it_mapl WHERE plnty = @it_mapl-plnty AND
             plnnr = @it_mapl-plnnr AND
             plnal = @it_mapl-plnal AND
             zaehl = @it_mapl-zaehl AND
             loekz EQ ''.


    IF lt_plas IS NOT INITIAL.
*    SELECT plnty plnnr plnal zaehl
*      INTO CORRESPONDING FIELDS OF TABLE it_plko
*      FROM plko
*      FOR ALL ENTRIES IN it_mapl
*      WHERE plnty = it_mapl-plnty AND
*            plnnr = it_mapl-plnnr AND
*            plnal = it_mapl-plnal AND
*            zaehl = it_mapl-zaehl .

      IF p_all = 'X' AND p_active NE 'X'.

        SELECT plnty plnnr plnal zaehl
        INTO CORRESPONDING FIELDS OF TABLE it_plko
        FROM plko
        FOR ALL ENTRIES IN lt_plas
        WHERE plnty = lt_plas-plnty AND
              plnnr = lt_plas-plnnr AND
              plnal = lt_plas-plnal AND
              zaehl = lt_plas-zaehl.
      ELSE.

        SELECT plnty plnnr plnal zaehl delkz
        INTO CORRESPONDING FIELDS OF TABLE it_plko
        FROM plko
        FOR ALL ENTRIES IN lt_plas
        WHERE plnty = lt_plas-plnty AND
              plnnr = lt_plas-plnnr AND
              plnal = lt_plas-plnal AND
              zaehl = lt_plas-zaehl AND
              loekz = p_loekz . "Added by Raj 25.05.2023
      ENDIF.

    ENDIF.

****Changes End
  ENDIF.

  IF it_plko IS NOT INITIAL.
    SELECT plnty plnnr pzlfh zaehl objty objid
      INTO CORRESPONDING FIELDS OF TABLE it_plfh
      FROM plfh
      FOR ALL ENTRIES IN it_plko
      WHERE plnty = it_plko-plnty AND
            plnnr = it_plko-plnnr AND
            zaehl = it_plko-zaehl.
  ENDIF.

  IF it_plfh IS NOT INITIAL.
    SELECT equnr objty objid
      INTO CORRESPONDING FIELDS OF TABLE it_crve_b
      FROM crve_b
      FOR ALL ENTRIES IN it_plfh
      WHERE objty = it_plfh-objty AND
            objid = it_plfh-objid.
  ENDIF.



  IF it_plko IS NOT INITIAL.
    SELECT plnty plnnr zaehl arbid objty ltxa1 meinh bmsch lar01 vge01 vgw01 lar02 vge02
      vgw02 lar03 vge03 vgw03 lar04 vge04 vgw04 lar05 vge05 vgw05 lar06 vge06 vgw06
      INTO CORRESPONDING FIELDS OF TABLE it_plpo
      FROM plpo
      FOR ALL ENTRIES IN it_plko
      WHERE plnty = it_plko-plnty AND
            plnnr = it_plko-plnnr AND
            zaehl = it_plko-zaehl .
  ENDIF.

  IF it_plpo IS NOT INITIAL.
    SELECT objty objid spras ktext
      INTO CORRESPONDING FIELDS OF TABLE it_crtx
      FROM crtx
      FOR ALL ENTRIES IN it_plpo
      WHERE objid = it_plpo-arbid AND
            spras = sy-langu.

    SELECT objty objid arbpl
      INTO CORRESPONDING FIELDS OF TABLE it_crhd
      FROM crhd
      FOR ALL ENTRIES IN it_plpo
      WHERE objid = it_plpo-arbid.
  ENDIF.

  LOOP AT it_mapl INTO wa_mapl.
    wa_final-matnr = wa_mapl-matnr.
    wa_final-werks = wa_mapl-werks.
    wa_final-plnal = wa_mapl-plnal.
    wa_final-plnnr = wa_mapl-plnnr."Added by Raj on 24.10.2024

    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_mapl-matnr.
    wa_final-maktg = wa_makt-maktg.

    READ TABLE it_plko INTO wa_plko WITH KEY plnty = wa_mapl-plnty
                                             plnnr = wa_mapl-plnnr
                                             plnal = wa_mapl-plnal
                                             zaehl = wa_mapl-zaehl .

****Added by Squirrel(Manoj) TO exclude items where loekz = 'X'.
    IF p_all NE 'X'.
      IF sy-subrc NE 0.
        CONTINUE.
      ENDIF.
    ENDIF.
****Changes End


    READ TABLE it_plfh INTO wa_plfh WITH KEY plnty = wa_plko-plnty
                                             plnnr = wa_plko-plnnr
                                             zaehl = wa_plko-zaehl .

    READ TABLE it_crve_b INTO wa_crve_b WITH KEY objty = wa_plfh-objty
                                                 objid = wa_plfh-objid.
    wa_final-equnr = wa_crve_b-equnr.

    READ TABLE it_plpo INTO wa_plpo WITH KEY plnty = wa_plko-plnty
                                             plnnr = wa_plko-plnnr
                                             zaehl = wa_plko-zaehl .
    wa_final-ltxa1 = wa_plpo-ltxa1.
    wa_final-meinh = wa_plpo-meinh.
    wa_final-bmsch = wa_plpo-bmsch.
    wa_final-lar01 = wa_plpo-lar01.
    wa_final-vge01 = wa_plpo-vge01.
    wa_final-vgw01 = wa_plpo-vgw01.

    wa_final-lar02 = wa_plpo-lar02.
    wa_final-vge02 = wa_plpo-vge02.
    wa_final-vgw02 = wa_plpo-vgw02.

    wa_final-lar03 = wa_plpo-lar03.
    wa_final-vge03 = wa_plpo-vge03.
    wa_final-vgw03 = wa_plpo-vgw03.

    wa_final-lar04 = wa_plpo-lar04.
    wa_final-vge04 = wa_plpo-vge04.
    wa_final-vgw04 = wa_plpo-vgw04.

    wa_final-lar05 = wa_plpo-lar05.
    wa_final-vge05 = wa_plpo-vge05.
    wa_final-vgw05 = wa_plpo-vgw05.

    wa_final-lar06 = wa_plpo-lar06.
    wa_final-vge06 = wa_plpo-vge06.
    wa_final-vgw06 = wa_plpo-vgw06.

    wa_final-delkz = wa_plko-delkz.

    READ TABLE it_crtx INTO wa_crtx WITH KEY objid = wa_plpo-arbid.
    wa_final-ktext = wa_crtx-ktext.

    READ TABLE it_crhd INTO wa_crhd WITH KEY objid = wa_plpo-arbid.
    wa_final-arbpl = wa_crhd-arbpl.

    APPEND wa_final TO it_final.
    CLEAR : wa_final,wa_mapl,wa_plko,wa_plpo,wa_crhd,wa_makt,wa_crtx.
************************************************************************************************

  ENDLOOP.





ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'MATNR'               'Material Number'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'WERKS'               'Plant'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PLNAL'               'Group Counter'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LTXA1'               'Operation short text'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LAR01'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW01'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE01'               'Unit'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LAR02'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW02'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE02'               'Unit'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LAR03'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW03'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE03'               'Unit'                'X'  'IT_FINAL'   .
  "Addded by bhaumik
  PERFORM fieldcat_append  USING  'LAR04'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW04'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE04'               'Unit'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'LAR05'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW05'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE05'               'Unit'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'LAR06'               'Activity Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGW06'               'Standard Value'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VGE05'               'Unit'                'X'  'IT_FINAL'   .
  "EOC by bhaumik
  PERFORM fieldcat_append  USING  'ARBPL'               'Work Center'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'EQUNR'               'Equipment Number'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'MAKTG'               'Material Description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KTEXT'               'Short Description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'BMSCH'               'Base Quantity'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'MEINH'               'UOM'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PLNNR'               'Group Number'                'X'  'IT_FINAL'   ."Added by Raj on 24.10.2024
  PERFORM fieldcat_append  USING  'DELKZ'               'Deletion Indicator'                'X'  'IT_FINAL'   . "Added by UDAYABAP03 on 11.03.2026
ENDFORM.
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
      it_events          = t_event[]
      i_save             = 'A'
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT werks FROM t001w INTO TABLE gt_t001w WHERE werks IN s_werks.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'Z_MASR_WRK'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_master
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_master .

  TYPES : BEGIN OF ty_master,
            matnr TYPE mapl-matnr,
            werks TYPE mapl-werks,
            plnal TYPE mapl-plnal,
            vornr TYPE vornr, "Operation Number
            ltxa1 TYPE plpo-ltxa1,  " Operation short text
            meinh TYPE plpo-meinh,
            bmsch TYPE plpo-bmsch,

            lar01 TYPE plpo-lar01,
            vge01 TYPE plpo-vge01,
            vgw01 TYPE plpo-vgw01,

            lar02 TYPE plpo-lar02,
            vge02 TYPE plpo-vge02,
            vgw02 TYPE plpo-vgw02,

            lar03 TYPE plpo-lar03,
            vge03 TYPE plpo-vge03,
            vgw03 TYPE plpo-vgw03,

            lar04 TYPE plpo-lar04, "Added by Bhaumik
            vge04 TYPE plpo-vge04, "Added by Bhaumik
            vgw04 TYPE plpo-vgw04, "Added by Bhaumik

            lar05 TYPE plpo-lar05, "Added by Bhaumik
            vge05 TYPE plpo-vge05, "Added by Bhaumik
            vgw05 TYPE plpo-vgw05, "Added by Bhaumik

            lar06 TYPE plpo-lar06, "Added by Bhaumik
            vge06 TYPE plpo-vge06, "Added by Bhaumik
            vgw06 TYPE plpo-vgw06, "Added by Bhaumik

            arbpl TYPE crhd-arbpl, " Work Center
*            equnr TYPE crve_b-equnr, " Equipment Number
            maktg TYPE makt-maktg,
            ktext TYPE crtx-ktext, " Short Description
            plnnr TYPE mapl-plnnr, " Added by Raj on 24.10.2024
            delkz TYPE cp_delkz, "Added by UDAYABAP03 on 11.03.2026
            steus type plpo-steus, "Added by UDAYABAP03 on 15.04.2026
          END OF ty_master.
  DATA : ls_master TYPE ty_master,
         lt_master TYPE TABLE OF ty_master.

  SELECT matnr werks plnty plnnr plnal zkriz zaehl
   INTO CORRESPONDING FIELDS OF TABLE it_mapl
   FROM mapl
   WHERE matnr IN s_matnr AND
         werks IN s_werks AND
         plnty = '2' AND
         plnal IN s_plnal.
  IF it_mapl IS NOT INITIAL.


    SELECT matnr spras maktg
      INTO CORRESPONDING FIELDS OF TABLE it_makt
      FROM makt
      FOR ALL ENTRIES IN it_mapl
      WHERE matnr = it_mapl-matnr AND
            spras = sy-langu.

****Changes by Squirrel(Manoj) for excluding cancelled list groups

    SELECT plnty,plnnr,plnal,plnkn,zaehl FROM plas INTO TABLE @DATA(lt_plas)
        FOR ALL ENTRIES IN @it_mapl WHERE
             plnty = @it_mapl-plnty AND
             plnnr = @it_mapl-plnnr AND
             plnal = @it_mapl-plnal AND
*             zaehl = @it_mapl-zaehl AND
             loekz EQ ''.


*    IF lt_plas IS NOT INITIAL.

*      SELECT plnty plnnr plnal zaehl delkz
*      INTO CORRESPONDING FIELDS OF TABLE it_plko
*      FROM plko
*      FOR ALL ENTRIES IN lt_plas
*      WHERE plnty = lt_plas-plnty AND
*            plnnr = lt_plas-plnnr AND
*            plnal = lt_plas-plnal AND
*            zaehl = lt_plas-zaehl AND
*            loekz = p_loekz .
*    ENDIF.

  ENDIF.


  IF lt_plas IS NOT INITIAL.
    SELECT plnty, plnnr, plnkn, zaehl, vornr, arbid, objty, ltxa1, meinh, bmsch, lar01, vge01, vgw01, lar02, vge02,
      vgw02, lar03, vge03, vgw03, lar04, vge04, vgw04, lar05, vge05, vgw05, lar06, vge06, vgw06 , pvzkn,
      steus "Added by UDAYABAP03 on 15.04.2026
      FROM plpo
      FOR ALL ENTRIES IN @lt_plas
      WHERE plnty = @lt_plas-plnty AND
            plnnr = @lt_plas-plnnr AND
            plnkn = @lt_plas-plnkn AND
            zaehl = @lt_plas-zaehl AND
      phflg IS NOT INITIAL
     INTO  TABLE @DATA(it_plpo_n).
  ENDIF.

  SELECT plnty, plnnr, plnkn, zaehl,
     arbid
    FROM plpo FOR ALL ENTRIES IN @lt_plas
    WHERE plnty = @lt_plas-plnty AND
              plnnr = @lt_plas-plnnr AND
              plnkn = @lt_plas-plnkn AND
              zaehl = @lt_plas-zaehl AND
    arbid IS NOT INITIAL
    INTO TABLE @DATA(lt_arbid).
  IF sy-subrc = 0.
    SORT lt_arbid BY plnty plnnr plnkn arbid arbid.
    DELETE ADJACENT DUPLICATES FROM lt_arbid COMPARING plnty plnnr plnkn zaehl arbid.
  ENDIF.

  IF lt_arbid IS NOT INITIAL.
    SELECT objty objid spras ktext
      INTO CORRESPONDING FIELDS OF TABLE it_crtx
      FROM crtx
      FOR ALL ENTRIES IN lt_arbid
      WHERE objid = lt_arbid-arbid AND
            spras = sy-langu.

    SELECT objty objid arbpl
      INTO CORRESPONDING FIELDS OF TABLE it_crhd
      FROM crhd
      FOR ALL ENTRIES IN lt_arbid
      WHERE objid = lt_arbid-arbid.
  ENDIF.
  SORT it_mapl BY plnty plnnr plnal.
  SORT lt_plas BY plnty plnnr plnal .
  SORT it_plpo_n BY plnty plnnr plnkn zaehl.

  LOOP AT it_mapl INTO wa_mapl.



**    READ TABLE it_plko INTO wa_plko WITH KEY plnty = wa_mapl-plnty
**                                             plnnr = wa_mapl-plnnr
**                                             plnal = wa_mapl-plnal
**                                             zaehl = wa_mapl-zaehl .
**
******Added by Squirrel(Manoj) TO exclude items where loekz = 'X'.
**    IF p_all NE 'X'.
**      IF sy-subrc NE 0.
**        CONTINUE.
**      ENDIF.
**    ENDIF.
******Changes End


*    READ TABLE it_plfh INTO wa_plfh WITH KEY plnty = wa_plko-plnty
*                                             plnnr = wa_plko-plnnr
*                                             zaehl = wa_plko-zaehl .

*    READ TABLE it_crve_b INTO wa_crve_b WITH KEY objty = wa_plfh-objty
*                                                 objid = wa_plfh-objid.
*    ls_master-equnr = wa_crve_b-equnr.

*    READ TABLE lt_plas INTO DATA(ls_plas) WITH KEY plnty = wa_mapl-plnty
*                                                   plnnr = wa_mapl-plnnr
*                                                   plnal = wa_mapl-plnal.
**                                                   zaehl = wa_mapl-zaehl.
    LOOP AT lt_plas INTO DATA(ls_plas) WHERE plnty = wa_mapl-plnty
                                          AND plnnr = wa_mapl-plnnr
                                          AND plnal = wa_mapl-plnal.
      ls_master-matnr = wa_mapl-matnr.
      ls_master-werks = wa_mapl-werks.
      ls_master-plnal = wa_mapl-plnal.

      READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_mapl-matnr.
      ls_master-maktg = wa_makt-maktg.


      READ TABLE it_plpo_n INTO DATA(wa_plpo_n) WITH KEY plnty = ls_plas-plnty
                                               plnnr = ls_plas-plnnr
                                               plnkn = ls_plas-plnkn
                                               zaehl = ls_plas-zaehl .
      IF sy-subrc = 0.

        ls_master-plnnr = wa_plpo_n-plnnr.

        ls_master-vornr = wa_plpo_n-vornr.
        ls_master-ltxa1 = wa_plpo_n-ltxa1.
        ls_master-meinh = wa_plpo_n-meinh.
        ls_master-bmsch = wa_plpo_n-bmsch.
        ls_master-lar01 = wa_plpo_n-lar01.
        ls_master-vge01 = wa_plpo_n-vge01.
        ls_master-vgw01 = wa_plpo_n-vgw01.

        ls_master-lar02 = wa_plpo_n-lar02.
        ls_master-vge02 = wa_plpo_n-vge02.
        ls_master-vgw02 = wa_plpo_n-vgw02.

        ls_master-lar03 = wa_plpo_n-lar03.
        ls_master-vge03 = wa_plpo_n-vge03.
        ls_master-vgw03 = wa_plpo_n-vgw03.

        ls_master-lar04 = wa_plpo_n-lar04.
        ls_master-vge04 = wa_plpo_n-vge04.
        ls_master-vgw04 = wa_plpo_n-vgw04.

        ls_master-lar05 = wa_plpo_n-lar05.
        ls_master-vge05 = wa_plpo_n-vge05.
        ls_master-vgw05 = wa_plpo_n-vgw05.

        ls_master-lar06 = wa_plpo_n-lar06.
        ls_master-vge06 = wa_plpo_n-vge06.
        ls_master-vgw06 = wa_plpo_n-vgw06.

*        ls_master-delkz = wa_plko-delkz.
        ls_master-steus = wa_plpo_n-steus.

        READ TABLE lt_arbid INTO DATA(ls_arbid) WITH KEY plnty = ls_plas-plnty
                                               plnnr = ls_plas-plnnr
                                               plnkn = wa_plpo_n-pvzkn.
        IF sy-subrc = 0.

          READ TABLE it_crtx INTO wa_crtx WITH KEY objid = ls_arbid-arbid.
          ls_master-ktext = wa_crtx-ktext.

          READ TABLE it_crhd INTO wa_crhd WITH KEY objid = ls_arbid-arbid.
          ls_master-arbpl = wa_crhd-arbpl.

        ENDIF.
        APPEND ls_master TO lt_master.
        CLEAR: ls_master, ls_plas,wa_plpo_n, wa_crhd, wa_makt, wa_crtx.
      ENDIF.
    ENDLOOP.
    CLEAR : wa_mapl.
  ENDLOOP.
  SORT lt_master BY matnr werks plnal vornr.

  "Display ALV
  DATA : lo_salv    TYPE REF TO cl_salv_table,
         lo_columns TYPE REF TO cl_salv_columns_table,
         lo_column  TYPE REF TO cl_salv_column_table.

  IF lt_master IS NOT INITIAL.
    TRY.
        CALL METHOD cl_salv_table=>factory
          IMPORTING
            r_salv_table = lo_salv
          CHANGING
            t_table      = lt_master.
      CATCH cx_salv_msg.
        " Error handling
        MESSAGE 'Error in ALV creation' TYPE 'E'.
    ENDTRY.
  ENDIF.

  " Get the columns object
  lo_columns = lo_salv->get_columns( ).
  " Optimize column widths
  lo_columns->set_optimize( abap_true ).

  " Enable all standard functions (Save layout, sort, filter, etc.)
  lo_salv->get_functions( )->set_all( abap_true ).


  lo_salv->display( ).

ENDFORM.
