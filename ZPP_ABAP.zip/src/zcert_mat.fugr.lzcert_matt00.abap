*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCERT_MAT.......................................*
DATA:  BEGIN OF STATUS_ZCERT_MAT                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCERT_MAT                     .
CONTROLS: TCTRL_ZCERT_MAT
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZCERT_MAT                     .
TABLES: ZCERT_MAT                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
