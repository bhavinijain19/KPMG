*&---------------------------------------------------------------------*
*&  Include           ZMM_BOM_REPORT_TOP
*&---------------------------------------------------------------------*

TABLES : mast,stko,stpo,cdpos.
TYPE-POOLS: slis.
TYPES : BEGIN OF ty_mast,
          matnr TYPE mast-matnr,
          werks TYPE mast-werks,
          stlnr TYPE mast-stlnr,
          stlal TYPE mast-stlal,
          losvn TYPE mast-losvn,
          losbs TYPE mast-losbs,
          andat TYPE mast-andat,
          aedat TYPE mast-aedat,
    key type string,
        END OF ty_mast,

        BEGIN OF ty_stko,
          stlty TYPE stko-stlty,
          stlal TYPE stko-stlal,
          stlnr TYPE stko-stlnr,
          bmeng TYPE stko-bmeng,
          bmein TYPE stko-bmein,
          lkenz TYPE stko-lkenz,
          andat TYPE stko-andat, "Added by Raj on 24.11.2023 .
          stlst TYPE stko-stlst,
          datuv type stko-datuv,
          guidx TYPE stko-guidx, "Added by Raj on 27.11.2023 .
            key type string,
        END OF ty_stko,

        BEGIN OF ty_stas,
          stlty TYPE stas-stlty,
          stlal TYPE stas-stlal,
          stlnr TYPE stas-stlnr,
          stlkn TYPE stas-stlkn,
          stasz TYPE stas-stasz,
        END OF ty_stas,

        BEGIN OF ty_stpo,
          stlty TYPE stpo-stlty,
          stlnr TYPE stpo-stlnr,
          stlkn TYPE stpo-stlkn,
          aedat TYPE stpo-aedat,
          andat TYPE stpo-andat, "Added by Raj on 27.11.2023
          idnrk TYPE stpo-idnrk,
          sanka TYPE stpo-sanka,
          menge TYPE stpo-menge,
          meins TYPE stpo-meins,
          matkl TYPE stpo-matkl,
          guidx TYPE stpo-guidx, "Added by Raj on 27.11.2023
        END OF ty_stpo,

        BEGIN OF ty_makt,
          matnr TYPE makt-matnr,
          spras TYPE makt-spras,
          maktx TYPE makt-maktx,
        END OF ty_makt.
" Begin of changes 4806
TYPES : BEGIN OF ty_mara,
          matnr TYPE mara-matnr,
          mtart TYPE mara-mtart,
          matkl TYPE mara-matkl, "Added by Raj on 30.06.2023
        END OF ty_mara.
" End of Changes 4806

***************************Added  by Raj on 11.10.2023*******************
TYPES : BEGIN OF ty_makt_d,
          matnr TYPE makt-matnr,
          maktx TYPE makt-maktx,
        END OF ty_makt_d.

DATA : it_maktd TYPE STANDARD TABLE OF ty_makt_d,
       wa_maktd TYPE ty_makt_d.


DATA : it_maktd1 TYPE STANDARD TABLE OF ty_makt_d,
       wa_maktd1 TYPE ty_makt_d.
************************Added by Raj on 11.10.2023********************
TYPES : BEGIN OF ty_final,
          werks     TYPE mast-werks,
          stlal     TYPE stko-stlal,
          bmeng     TYPE stko-bmeng,
          bmein     TYPE stko-bmein,
          lkenz     TYPE stko-lkenz,
          stlst     TYPE stko-stlst,
          idnrk     TYPE stpo-idnrk,
          maktx     TYPE makt-maktx,
          losvn     TYPE mast-losvn,
          bmein1    TYPE stko-bmein,
          losbs     TYPE mast-losbs,
          bmein2    TYPE stko-bmein,
          sanka     TYPE stpo-sanka,
          matnr     TYPE mast-matnr,
          menge     TYPE stpo-menge,
          meins     TYPE stpo-meins,
          matkl     TYPE stpo-matkl,
          stlkn     TYPE stpo-stlkn,
          mtart     TYPE mara-mtart,
          andat     TYPE mast-andat,
          aedat     TYPE mast-aedat,
          mtart1    TYPE mara-mtart,
          matkl1    TYPE mara-matkl,
          matkl2    TYPE mara-matkl,
          maktxd    TYPE makt-maktx, "Added by Raj on 11.10.2023
          price     TYPE p LENGTH 16 DECIMALS 2, "stprs, "Added by Rahul Vasita on 23.11.2023 12:11:29
          tot_price TYPE p LENGTH 16 DECIMALS 2, "stprs, "Added by Rahul Vasita on 23.11.2023 12:11:29
          datuv     type stko-datuv,
        END OF ty_final.



DATA : lt_mast  TYPE STANDARD TABLE OF ty_mast,
       ls_mast  TYPE ty_mast,
*       lt_mast1 TYPE STANDARD TABLE OF ty_mast,
*       ls_mast1 TYPE ty_mast,

       lt_stkot TYPE STANDARD TABLE OF ty_stko,
       ls_stkot TYPE ty_stko,


       lt_stko  TYPE STANDARD TABLE OF ty_stko,
       ls_stko  TYPE ty_stko,
       lt_stas  TYPE STANDARD TABLE OF ty_stas,
       ls_stas  TYPE ty_stas,
       lt_stpo  TYPE STANDARD TABLE OF ty_stpo,
       ls_stpo  TYPE ty_stpo,
       lt_makt  TYPE STANDARD TABLE OF ty_makt,
       ls_makt  TYPE ty_makt,
       lt_final TYPE STANDARD TABLE OF ty_final,
       ls_final TYPE ty_final,
       lt_mara  TYPE STANDARD TABLE OF ty_mara,   "Added by 4806
       ls_mara  TYPE ty_mara.                      "Added by 4806

*********************************************************************Changing data
DATA : "lt_mast  TYPE STANDARD TABLE OF ty_mast,
*       ls_mast  TYPE ty_mast,
  lt_mast1  TYPE STANDARD TABLE OF ty_mast,
  ls_mast1  TYPE ty_mast,

  lt_stko1  TYPE STANDARD TABLE OF ty_stko,
  ls_stko1  TYPE ty_stko,
  lt_stas1  TYPE STANDARD TABLE OF ty_stas,
  ls_stas1  TYPE ty_stas,
  lt_stpo1  TYPE STANDARD TABLE OF ty_stpo,
  ls_stpo1  TYPE ty_stpo,
  lt_makt1  TYPE STANDARD TABLE OF ty_makt,
  ls_makt1  TYPE ty_makt,
  lt_final1 TYPE STANDARD TABLE OF ty_final,
  ls_final1 TYPE ty_final,
  lt_mara1  TYPE STANDARD TABLE OF ty_mara,   "Added by 4806
  ls_mara1  TYPE ty_mara.                      "Added by 4806

********************************************************************Changing data



DATA: wa_fieldcat TYPE  slis_fieldcat_alv,
      gt_fieldcat TYPE slis_t_fieldcat_alv.

DATA: wa_fieldcat1 TYPE  slis_fieldcat_alv,
      gt_fieldcat1 TYPE slis_t_fieldcat_alv.
TYPES : BEGIN OF ty_t001w,
          werks TYPE t001w-werks,
        END OF ty_t001w.


DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w.
DATA : wa_t001w TYPE ty_t001w.
DATA : c_date TYPE mast-aedat."Added by Raj on 28.04.2023

TYPES:
*TYPES : BEGIN OF ty_cdhdr,
**          objectclas TYPE cdhdr-objectclas,
**          objectid   TYPE cdhdr-objectid,
**          changenr   TYPE cdhdr-changenr,
**        END OF ty_cdhdr,

  BEGIN OF ty_cdhdr1,
    objectclas TYPE cdhdr-objectclas,
    objectid   TYPE c LENGTH 18,
    changenr   TYPE cdhdr-changenr,
    udate      TYPE cdhdr-udate,
  END OF ty_cdhdr1.

TYPES: BEGIN OF ty_matnr,

         s_matnr TYPE mast-matnr,

       END OF ty_matnr.

DATA : it_cdhdr TYPE STANDARD TABLE OF cdhdr.
DATA : wa_cdhdr TYPE cdhdr.
DATA : it_cdhdr1 TYPE STANDARD TABLE OF ty_cdhdr1." WITH HEADER LINE..
DATA : wa_cdhdr1 TYPE ty_cdhdr1.
DATA : it_cdhdr2 TYPE STANDARD TABLE OF cdhdr.
DATA : wa_cdhdr2 TYPE cdhdr.
DATA : it_matnr TYPE STANDARD TABLE OF ty_matnr.

DATA : it_cdpos TYPE STANDARD TABLE OF cdred,
       wa_cdpos TYPE cdred.

TYPES: BEGIN OF ty_cdpos,
*         objectid TYPE mara-matnr,
         objectid TYPE cdpos-objectid,
       END OF ty_cdpos.
DATA: it_final_cdpos TYPE STANDARD TABLE OF ty_cdpos,
      wa_final_cdpos TYPE ty_cdpos.

TYPES : BEGIN OF ty_cdhdr,
          objectclas TYPE cdhdr-objectclas,
          objectid   TYPE cdhdr-objectid,
          changenr   TYPE cdhdr-changenr,
          username   TYPE cdhdr-username,
          udate      TYPE cdhdr-udate,
          tcode      TYPE cdhdr-tcode,
        END OF ty_cdhdr.

DATA : it_cdhdrr TYPE STANDARD TABLE OF ty_cdhdr,
       wa_cdhdrr TYPE ty_cdhdr.



TYPES : BEGIN OF ty_cdpos1,
          objectclas TYPE cdpos-objectclas,
          objectid   TYPE cdpos-objectid,
          changenr   TYPE cdpos-changenr,
          tabname    TYPE cdpos-tabname,
          tabkey     TYPE cdpos-tabkey,
        END OF ty_cdpos1.
DATA : it_cdpos1 TYPE STANDARD TABLE OF ty_cdpos1,
       wa_cdpos1 TYPE ty_cdpos1.


TYPES : BEGIN OF ty_mara1,
          matnr TYPE mara-matnr,
          mtart TYPE mara-mtart,
          matkl TYPE mara-matkl,
        END OF ty_mara1.

DATA : it_mara TYPE STANDARD TABLE OF ty_mara1,
       wa_mara TYPE ty_mara1.
