wa_parta-kurztext = 'COMPONENT PART A'.
*wa_parta-toleranzun2 = 'PART A'.
APPEND wa_parta TO it_parta.
CLEAR wa_parta.

wa_partb-kurztext = 'COMPONENT PART B'.
*wa_partb-toleranzun2 = 'PART B'.
APPEND wa_partb TO it_partb.
CLEAR wa_partb.

wa_other-kurztext = 'AFTER CURE PROPERTIES'.
APPEND wa_other TO it_other.
CLEAR wa_other.

LOOP AT it_final INTO wa_final WHERE prueflos = gv_sf1.
  wa_final-partb = ''.
  MODIFY it_final FROM wa_final TRANSPORTING partb.
ENDLOOP.

LOOP AT it_final INTO wa_final WHERE prueflos = gv_sf2.
  wa_final-parta = ''.
  MODIFY it_final FROM wa_final TRANSPORTING parta.
ENDLOOP.

SORT it_final ASCENDING BY parta partb other.
LOOP AT it_final INTO wa_final.

  IF wa_final-parta EQ 'X'.
    MOVE-CORRESPONDING wa_final TO wa_parta.
    APPEND wa_parta TO it_parta.
    CLEAR wa_parta.
  ENDIF.

  IF wa_final-partb EQ 'X'.
    MOVE-CORRESPONDING wa_final TO wa_partb.
    APPEND wa_partb TO it_partb.
    CLEAR wa_partb.
  ENDIF.

  IF wa_final-other EQ 'X'.
    MOVE-CORRESPONDING wa_final TO wa_other.
    APPEND wa_other TO it_other.
    CLEAR wa_other.
  ENDIF.

ENDLOOP.

LOOP AT it_parta INTO wa_parta.
  MOVE-CORRESPONDING wa_parta TO ls_final.
  APPEND ls_final TO lt_final.
  CLEAR: wa_parta, ls_final.
ENDLOOP.

LOOP AT it_partb INTO wa_partb.
  MOVE-CORRESPONDING wa_partb TO ls_final.
  APPEND ls_final TO lt_final.
  CLEAR: wa_partb, ls_final.
ENDLOOP.

LOOP AT it_other INTO wa_other.
  MOVE-CORRESPONDING wa_other TO ls_final.
  APPEND ls_final TO lt_final.
  CLEAR: wa_other, ls_final.
ENDLOOP.



















