FUNCTION-POOL ZPRT_CC                    MESSAGE-ID SV.

* INCLUDE LZPRT_CCD...                       " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPRT_CCT00                             . "view rel. data dcl.
