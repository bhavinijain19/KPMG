
*&---------------------------------------------------------------------*
*&  Include           ZXCOFTOP
*&---------------------------------------------------------------------*
DATA: wa_afru TYPE afrud.

DATA : p_value TYPE fieldname,
       p_field TYPE fieldname.
