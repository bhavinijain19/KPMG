*&---------------------------------------------------------------------*
*& Report ZBDC_QS31
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZBDC_QS31.


INCLUDE ZBDC_QS31_TOP.
INCLUDE ZBDC_QS31_SS.
INCLUDE ZBDC_QS31_IMP.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.

  PERFORM f4_filename.

  START-OF-SELECTION.
  PERFORM upload_file.
  PERFORM call_bdc.
  PERFORM fcat_log.
  PERFORM display_msg.
