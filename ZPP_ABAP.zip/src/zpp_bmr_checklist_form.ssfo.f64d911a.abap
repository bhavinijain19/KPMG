CLEAR: lv_q2.
IF ls_checklist-std_tmp IS NOT INITIAL.
  lv_q2 = ls_checklist-std_tmp.
  CONDENSE lv_q2.
ENDIF.






















