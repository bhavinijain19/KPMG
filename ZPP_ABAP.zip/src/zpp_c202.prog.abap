*&---------------------------------------------------------------------*
*& Report ZPP_C202
*&---------------------------------------------------------------------*
*       MODULE : Production Planning for Process                       *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*       Objective : Recipe Master Change                               *
*----------------------------------------------------------------------*
*       Date Created  :    09.04.2026                                  *
*       Instructed by :    KPMG - Dipesh Panwala                       *
*       Devloped by   :    KPMG - Bhaumik Patel                        *
*                                                                      *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
* Amendment History                                                    *
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR                  CR/ID            *
*......................................................................*
* <001>   Bhaumik Patel         DEVK906778                             *
* Reason: Recipe Master Change                                         *
*......................................................................*
* <002>                                                                *
* Reason:                                                              *
*----------------------------------------------------------------------*
REPORT zpp_c202.

INCLUDE zpp_c202_top.
INCLUDE zpp_c202_sel.
INCLUDE zpp_c202_f01.

*---------------------------------------------------------------------*
* SCREEN HANDLING
*---------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-group1 = 'UP'
      OR screen-group1 = 'MOD'.
      screen-input = COND #( WHEN r_up = 'X' THEN 1 ELSE 0 ).
    ENDIF.

    MODIFY SCREEN.
  ENDLOOP.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  IF r_up = 'X'.
    CALL FUNCTION 'F4_FILENAME'
      IMPORTING
        file_name = p_file.
  ENDIF.

*---------------------------------------------------------------------*
* MAIN
*---------------------------------------------------------------------*
START-OF-SELECTION.

  IF r_down = 'X'.
    PERFORM download_template.
    RETURN.
  ENDIF.
  PERFORM upload_excel.
  IF gt_excel IS NOT INITIAL.
    PERFORM execute_bdc.
  ENDIF.
