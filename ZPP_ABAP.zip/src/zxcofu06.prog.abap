*&---------------------------------------------------------------------*
*& Include          ZXCOFU06
*&---------------------------------------------------------------------*


CONSTANTS: lc_setuppower TYPE  char20 VALUE 'SET_P'.
CONSTANTS: lc_power TYPE  char20 VALUE 'P'.
SELECT SINGLE zorder_flow
  FROM aufk
  WHERE aufnr = @afrud_imp-aufnr
  INTO @DATA(lv_order).
IF lv_order = 'Y'.
  afrud_exp =  afrud_imp.
  CLEAR : afrud_exp-ism01 ,
  afrud_exp-ism02,
  afrud_exp-ism03 .
ELSEIF lv_order = 'N'.
  afrud_exp =  afrud_imp.
  SELECT SINGLE constant
    FROM zpp_cont_values
    WHERE plant = @afrud_imp-werks
    AND routinggrp = @caufvd_imp-plnnr
    AND groupcnt = @caufvd_imp-plnal
    AND operationno =  @afrud_imp-vornr
    AND setupfield = @lc_setuppower
    AND deletionflag = ' '
    INTO @DATA(lc_setup_val).
  IF lc_setup_val IS NOT INITIAL .
    afrud_exp-ism03 = afrud_exp-ism03 * lc_setup_val .
  ENDIF.

  SELECT SINGLE constant
   FROM zpp_cont_values
   WHERE plant = @afrud_imp-werks
   AND routinggrp = @caufvd_imp-plnnr
   AND groupcnt = @caufvd_imp-plnal
   AND operationno =  @afrud_imp-vornr
   AND setupfield = @lc_power
   AND deletionflag = ' '
   INTO @DATA(lc_power_val).
  IF lc_power_val IS NOT INITIAL.
    afrud_exp-ism06 = afrud_exp-ism06 * lc_power_val.
  ENDIF.
ENDIF.
