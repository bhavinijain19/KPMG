*&---------------------------------------------------------------------*
*& Include          ZPP_BMR_CHECKLIST_NEW_TOP
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_NEW_TOP
*&---------------------------------------------------------------------*


*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_TAB_CTRL' ITSELF
CONTROLS: lt_tab_ctrl TYPE TABLEVIEW USING SCREEN 9000.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_TAB_CTRL'
DATA:     g_lt_tab_ctrl_lines  LIKE sy-loopc.
*******************************Download attachement details***********

TYPES: BEGIN OF ty_sood_tab,   "SAPoffice: Object definition
         objtp    TYPE sood-objtp,           "Code for document class
         objyr    TYPE sood-objyr,           "Object: Year from ID
         objno    TYPE sood-objno,           "Object: Number from ID
         objdes   TYPE sood-objdes,          "Short description of contents
         file_ext TYPE sood-file_ext,        "File extension for PC application
         objlen   TYPE sood-objlen,          "Size of Document Content
         extct    TYPE sood-extct,           "Object contents are stored externally
       END OF ty_sood_tab.

DATA : it_sood_tab  TYPE STANDARD TABLE OF ty_sood_tab,
       it_sood_tab1 TYPE STANDARD TABLE OF ty_sood_tab,
       wa_sood_tab  TYPE ty_sood_tab.

TYPES : BEGIN OF ty_srgb,
          instid_a TYPE srgbtbrel-instid_a,
          instid_b TYPE srgbtbrel-instid_b,
        END OF ty_srgb.

DATA : it_srgb1 TYPE STANDARD TABLE OF ty_srgb,
       wa_srgb  TYPE ty_srgb.

TYPES : BEGIN OF ty_final,
          instid_a TYPE srgbtbrel-instid_a,
          objdes   TYPE sood-objdes,          "Short description of contents
        END OF ty_final.

DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.

DATA : s_int_a TYPE srgbtbrel-instid_a.
DATA : lv_int TYPE srgbtbrel-instid_a.
DATA : lv_folder TYPE string.
DATA : objcont_tab LIKE soli  OCCURS 0 WITH HEADER LINE.  "SAPoffice: line, length 255
DATA : bin_filesize LIKE soxwd-doc_length.               "SAPoffice: header table for MS WinWord objects
DATA : bakfilename_g LIKE rlgrap-filename.               "Program Fields/Screen Fields for SAPLGRAP--Local file
DATA : soc3key_g     LIKE soc3-srtfd.                    "SAPoffice: DB for objects (import/export)
DATA : lv_file TYPE string.
DATA : s_file TYPE string.
DATA : message_v1 TYPE string.
DATA : lv_msg TYPE string.
DATA : lv_belnr TYPE string.                             "Local vairable for sales document no
DATA : l_result      TYPE c,
       lv_aufnr      TYPE aufnr, "Added by Rahul Vasita on 16.05.2024 14:53:51
       l_datfilename TYPE string,                        "local variable for filename
       rtcode_g      LIKE sy-subrc.                      "Return Code of ABAP Statements
DATA : v_filename TYPE string  .
DATA : v_path  TYPE string.
DATA : v_fullpath  TYPE string.
DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE,
       gt_sort        TYPE slis_t_sortinfo_alv WITH HEADER LINE.

DATA : p_belnr TYPE bkpf-belnr.
DATA : p_path TYPE string VALUE 'D:\'.





******************************Download attachment details************
TABLES: afru.

DATA : v_fm_name TYPE  rs38l_fnam.
DATA : control_parameters TYPE ssfctrlop,
       control            TYPE ssfctrlop,
       output             TYPE ssfcompop,
       "Adding Start by Rahul Vasita on 03.05.2024 14:14:30
       gv_bin_filesize    TYPE i, " Store the file size
       lv_xstring1        TYPE xstring,
       lv_xstring2        TYPE xstring,
       ls_otfdata         TYPE ssfcrescl, " Smart Forms: Return value at end of form printing
       ls_reclist         TYPE somlreci1, " SAPoffice: Structure of the API Recipient List
       ls_pdf_tab         TYPE tline. " Workarea for SAP Script Text Lines

DATA: lt_reclist TYPE TABLE OF somlreci1, " SAPoffice: Structure of the API Recipient List
      lt_pdf_tab TYPE TABLE OF tline, " SAPscript: Text Lines
      lt_otf     TYPE TABLE OF itcoo, " OTF Structure
      lt_content TYPE STANDARD TABLE OF tdline,
      ls_content TYPE tdline,
      lt_objbin  TYPE TABLE OF solisti1, " SAPoffice: Single List with Column Length 255
      lt_objpack TYPE TABLE OF sopcklsti1. " SAPoffice: Description of Imported
DATA: pdf_merger TYPE REF TO cl_rspo_pdf_merge.
DATA: ex        TYPE REF TO cx_rspo_pdf_merge, lv_ex_txt TYPE string.
DATA: merged_document TYPE xstring.
DATA: rc    TYPE i VALUE 0, lnum TYPE i VALUE 0, p_sel TYPE i VALUE 1.
DATA: docindex TYPE i VALUE 0, errordoc TYPE xstring.
DATA: text1      TYPE string, error_text TYPE string.
"Adding End by Rahul Vasita on 03.05.2024 14:14:30

*DATA : v_con TYPE i. "Comment by Rahul Vasita on 06.06.2024 10:26:35
DATA : lt_checklist TYPE zpp_bmr_checklist_tt, "Added by Rahul Vasita on 03.05.2024 12:30:29
       ls_checklist TYPE zpp_bmr_checklist_ts. "Added by Rahul Vasita on 03.05.2024 12:30:31
*v_con = 1. "Comment by Rahul Vasita on 06.06.2024 10:26:37
TYPES : BEGIN OF ty_afko,
          aufnr TYPE afko-aufnr,
          rsnum TYPE afko-rsnum,
        END OF ty_afko.
DATA : it_afko TYPE STANDARD TABLE OF ty_afko,
       wa_afko TYPE ty_afko.

TYPES : BEGIN OF ty_afru,
          aufnr TYPE afru-aufnr,
          werks TYPE afru-werks,
        END OF ty_afru.
DATA : it_afru TYPE STANDARD TABLE OF ty_afru,
       wa_afru TYPE ty_afru.

DATA     print_opts LIKE itcpo.
DATA : wa_print TYPE print_co.
DATA: subrc LIKE sy-subrc.
DATA: v_charg TYPE afpo-charg.
DATA : v_gamng TYPE netpr.
DATA : v_stlal TYPE afko-stlal.
DATA : v_gmein TYPE afko-gmein.
DATA : v_chargd TYPE afpo-charg.
DATA : v_maktx TYPE makt-maktx.

DATA: off VALUE ' ',
      on  VALUE 'X'.

DATA : counter    TYPE n LENGTH 2.
DATA : counter1    TYPE n LENGTH 2.

TYPES : BEGIN OF ty_rseb,
          rsnum TYPE resb-rsnum,
          matnr TYPE resb-matnr,
          bdmng TYPE resb-bdmng,
          meins TYPE resb-meins,
        END OF ty_rseb.

DATA : wa_rseb TYPE ty_rseb,
       it_rseb TYPE STANDARD TABLE OF ty_rseb.


TYPES : BEGIN OF ty_makt,
          matnr TYPE makt-matnr,
          maktx TYPE makt-maktx,
        END OF ty_makt.

DATA : wa_makt TYPE ty_makt,
       it_makt TYPE STANDARD TABLE OF ty_makt.

TYPES : BEGIN OF ty_rseb1,
          srno  TYPE char5,
          matnr TYPE resb-matnr,
          bdmng TYPE resb-bdmng,
          meins TYPE resb-meins,
          batch TYPE c LENGTH 15,
          sign  TYPE c LENGTH 20,
        END OF ty_rseb1.

DATA : wa_rseb1 TYPE ty_rseb1,
       it_rseb1 TYPE STANDARD TABLE OF ty_rseb1.
DATA:
      lv_sum    TYPE resb-bdmng,
     wa_rseb_n TYPE ty_rseb1.

TYPES : BEGIN OF ty_rseb2,
          srno  TYPE char5,
          matnr TYPE resb-matnr,
          maktx TYPE makt-maktx,
          gross TYPE char10,
          tare  TYPE char10,
          net   TYPE char10,
        END OF ty_rseb2.

DATA : wa_rseb2 TYPE ty_rseb2,
       it_rseb2 TYPE STANDARD TABLE OF ty_rseb2.

TYPES : BEGIN OF ty_temp,
          matnr TYPE mara-matnr,
          werks TYPE werks_d,
        END OF ty_temp.

DATA : v_matnr TYPE afko-plnbez.

DATA : it_temp TYPE STANDARD TABLE OF ty_temp,
       wa_temp TYPE ty_temp.

DATA : caufvd_p_tab LIKE SORTED TABLE OF caufvd_p WITH UNIQUE KEY
                    aufnr                         WITH HEADER LINE.

DATA : wa_item LIKE SORTED TABLE OF caufvd_p WITH UNIQUE KEY
                    aufnr                         WITH HEADER LINE.

DATA : v_werks TYPE afru-werks.
DATA : wa_itema LIKE LINE OF wa_item.

*MODULE POOL DECLARATIONS Starts
TYPES : BEGIN OF ty_tbctrl,
          sel(1) TYPE c.
          INCLUDE STRUCTURE zpp_bmr_checklist_ts.
        TYPES : END OF ty_tbctrl.
DATA : lv_dynnr   TYPE sy-dynnr,
       ok_code1   TYPE sy-ucomm,
       p_aufnr    TYPE afru-aufnr,
       a(1)       TYPE c,
       lv_flag(1) TYPE c.
DATA: lt_listtab    TYPE TABLE OF zpp_bmr_list,
      ls_listtab    TYPE zpp_bmr_list,
      lt_list_trans TYPE TABLE OF zpp_bmr_list_t,
      ls_list_trans TYPE zpp_bmr_list_t.
DATA:lt_tbctrl TYPE TABLE OF ty_tbctrl,
     ls_tbctrl TYPE ty_tbctrl.
*MODULE POOL DECLARATIONS Ends

***SELECTION-SCREEN BEGIN OF SCREEN 9002 AS SUBSCREEN.
***PARAMETERS : p_aufnr TYPE afru-aufnr.
***PARAMETERS: a AS CHECKBOX.
***SELECTION-SCREEN END OF SCREEN 9002.
