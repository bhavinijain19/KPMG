*&---------------------------------------------------------------------*
*&  Include           ZPP_QP02_BOM_DEL_TOP
*&---------------------------------------------------------------------*
TYPE-POOLS : slis,abap.
TABLES : mapl.

TYPES : BEGIN OF ty_final,
          key(50)   TYPE c,
          matnr     TYPE mapl-matnr,
          werks     TYPE mapl-werks,
          plnty     TYPE mapl-plnty,
          plnnr     TYPE mapl-plnnr,
          plnal     TYPE mapl-plnal,
          zkriz     TYPE mapl-zkriz,
          zaehl     TYPE mapl-zaehl,
          loekz     TYPE plpo-loekz,
          verwe     TYPE plko-verwe,
          statu     TYPE plko-statu,
          andat     TYPE plko-andat,
          lifnr     TYPE lifnr,
          indic(1)  TYPE c,
          p_95(1)   TYPE c,
          msg(1000) TYPE c,
        END OF ty_final,

        BEGIN OF ty_metadata,
          matnr TYPE mapl-matnr,
          werks TYPE mapl-werks,
        END OF ty_metadata.

DATA : lt_final    TYPE TABLE OF ty_final,
       ls_final    TYPE ty_final,
       lt_metadata TYPE TABLE OF ty_metadata,
       ls_metadata TYPE ty_metadata,
       lt_mapl     TYPE TABLE OF mapl,
       ls_mapl     TYPE mapl.

DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE,
       messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA : lt_msgtab TYPE TABLE OF bdcmsgcoll,
       ls_msgtab TYPE bdcmsgcoll.

DATA : lt_fieldcat TYPE slis_t_fieldcat_alv,
       ls_fieldcat TYPE slis_fieldcat_alv,
       lt_header   TYPE slis_t_listheader,
       ls_header   TYPE slis_listheader,
       ls_layout   TYPE slis_layout_alv,
       ls_variant  TYPE disvariant.
