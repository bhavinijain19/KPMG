*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_TOP
*&---------------------------------------------------------------------*

TYPE-POOLS : slis , abap.

DATA : ok_code01 TYPE sy-ucomm,
       ok_code02 TYPE sy-ucomm.
DATA : lv_subrc  LIKE sy-subrc,
       lt_it_tab TYPE filetable.
DATA : lv_screen  TYPE sy-dynnr,
       lv_aufnr   TYPE aufnr,
       lv_flag    TYPE c,
       lv_cflag   TYPE c,
       gt_content TYPE STANDARD TABLE OF tdline,
       gs_content TYPE tdline.

TYPES : BEGIN OF ty_checklist,
          sel(1)       TYPE c,
          aufnr        TYPE aufnr,
          process_txt  TYPE char255,
          matnr        TYPE matnr,
          contribution TYPE p LENGTH 5 DECIMALS 2,
          std_tmp      TYPE p LENGTH 5,
          act_tmp      TYPE p LENGTH 5,
        END OF ty_checklist,
        BEGIN OF ty_log,
          sr_no        TYPE i,
          werks        TYPE werks_d,
          sf_matnr     TYPE zpp_bmr_list-sf_matnr,
          stlal        TYPE zpp_bmr_list-stlal,
          process_txt  TYPE zpp_bmr_list-process_txt,
          matnr        TYPE zpp_bmr_list-matnr,
          contribution TYPE zpp_bmr_list-contribution,
          std_tmp      TYPE zpp_bmr_list-std_tmp,
          std_time     TYPE zpp_bmr_list-std_time,
          msg1(255)    TYPE c,
          msg2(255)    TYPE c,
          flag(1)      TYPE c,
        END OF ty_log,
        BEGIN OF ty_final,
          sr_no        TYPE i,
          werks        TYPE werks_d,
          sf_matnr     TYPE zpp_bmr_list-sf_matnr,
          stlal        TYPE zpp_bmr_list-stlal,
          process_txt  TYPE zpp_bmr_list-process_txt,
          matnr        TYPE zpp_bmr_list-matnr,
          contribution TYPE zpp_bmr_list-contribution,
          std_tmp      TYPE zpp_bmr_list-std_tmp,
          std_time     TYPE zpp_bmr_list-std_time,
        END OF ty_final,

        BEGIN OF ty_bom,
          sf_matnr TYPE zpp_bmr_list-sf_matnr,
          stlal    TYPE zpp_bmr_list-stlal,
          matnr    TYPE zpp_bmr_list-matnr,
        END OF ty_bom.

DATA : lt_exfinal TYPE TABLE OF ty_final,
       ls_exfinal TYPE ty_final,
       lt_bom     TYPE TABLE OF ty_bom,
       ls_bom     TYPE ty_bom,
       lt_log     TYPE TABLE OF ty_log,
       ls_log     TYPE ty_log.
TYPES : ty_bom1 TYPE STANDARD TABLE OF ty_bom WITH EMPTY KEY.

DATA: lt_final TYPE TABLE OF zpp_bmr_list,
      ls_final TYPE zpp_bmr_list.
DATA : lt_fieldcat TYPE slis_t_fieldcat_alv,
       ls_fieldcat TYPE slis_fieldcat_alv,
       lt_header   TYPE slis_t_listheader,
       ls_header   TYPE slis_listheader,
       lt_sort     TYPE slis_t_sortinfo_alv,
       ls_sort     TYPE slis_sortinfo_alv,
       ls_layout   TYPE slis_layout_alv,
       ls_variant  TYPE disvariant.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CHECKLIST_TC' ITSELF
CONTROLS: lt_checklist_tc TYPE TABLEVIEW USING SCREEN 9001.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CHECKLIST_TC'
DATA:     g_lt_checklist_tc_lines  LIKE sy-loopc.

DATA:     ok_code LIKE sy-ucomm.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCD' ITSELF
CONTROLS: lt_ch_tcd TYPE TABLEVIEW USING SCREEN 9003.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCD'
DATA:     g_lt_ch_tcd_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCC' ITSELF
CONTROLS: lt_ch_tcc TYPE TABLEVIEW USING SCREEN 9004.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCC'
DATA:     g_lt_ch_tcc_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TC' ITSELF
CONTROLS: lt_ch_tc TYPE TABLEVIEW USING SCREEN 9001.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TC'
DATA:     g_lt_ch_tc_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCD1' ITSELF
CONTROLS: lt_ch_tcd1 TYPE TABLEVIEW USING SCREEN 9003.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCD1'
DATA:     g_lt_ch_tcd1_lines  LIKE sy-loopc.

*&SPWIZARD: DECLARATION OF TABLECONTROL 'LT_CH_TCC1' ITSELF
CONTROLS: lt_ch_tcc1 TYPE TABLEVIEW USING SCREEN 9004.

*&SPWIZARD: LINES OF TABLECONTROL 'LT_CH_TCC1'
DATA:     g_lt_ch_tcc1_lines  LIKE sy-loopc.
