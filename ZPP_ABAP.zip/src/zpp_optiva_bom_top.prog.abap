*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_BOM_TOP
*&---------------------------------------------------------------------*

DATA : ftp_handle       TYPE i,
       ftp_rfc_dest_aux LIKE rfcdes-rfcdest VALUE 'SAPFTPA',
       ftp_command(120) TYPE c,
       ftp_result       TYPE sdoki_ftp_result_t,
       pwd(30)          TYPE c,
       key              TYPE i VALUE 26101957,
       slen             TYPE i.
CONSTANTS   : c_tvarvc_matcre  TYPE rvari_vnam VALUE 'ZMM_OPTIVA_PATH'.
CONSTANTS : c_tvarvc_user TYPE rvari_vnam VALUE 'BARCODE_USER'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_pwd TYPE rvari_vnam VALUE 'BARCODE_PWD'.   "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_host TYPE rvari_vnam VALUE 'BARCODE_HOST'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_dest TYPE rvari_vnam VALUE 'BARCODE_DEST'. "Using it from ZMM_MAT_DATA report

CONSTANTS:
c_tvarvc_name TYPE rvari_vnam VALUE 'OPTIVA_BOM'.
CONSTANTS:
c_tvarvc_name1 TYPE rvari_vnam VALUE 'OPTIVA_BOM_DELE'.

CONSTANTS:
c_tvarvc_name2 TYPE rvari_vnam VALUE 'OPTIVA_BOM_MAIL'.


CONSTANTS:
pc_tvarvc_name TYPE rvari_vnam VALUE 'POPTIVA_BOM'.  "Added by Raj on 17.01.2025
CONSTANTS:
pc_tvarvc_name1 TYPE rvari_vnam VALUE 'POPTIVA_BOM_DELE'."Added by Raj on 17.01.2025

CONSTANTS:
pc_tvarvc_name2 TYPE rvari_vnam VALUE 'POPTIVA_BOM_MAIL'."Added by Raj on 17.01.2025




DATA: bcode_user TYPE char200.
DATA: bcode_pwd TYPE char200.
DATA: bcode_host TYPE char200.
DATA: bcode_dest TYPE char200.

DATA: matcre_path(500).

DATA: l_user(30) TYPE c, "VALUE 'APTLSFTP', "user name of ftp server
      l_pwd(30)  TYPE c, "VALUE 'Astral123', "password of ftp server
      l_host(64) TYPE c, "VALUE '192.168.54.74', "ip address of FTP server
      l_dest     LIKE rfcdes-rfcdest.
DATA: w_hdl  TYPE i,
      c_key  TYPE i VALUE 26101957,
      l_slen TYPE i.

DATA: BEGIN OF itab_tmp OCCURS 1,
        line(600)             ,
      END OF itab_tmp       .


"""""XML Read"""""

DATA: gcl_xml       TYPE REF TO cl_xml_document.

TYPES : BEGIN OF ty_files,
          appsrv_fname TYPE localfile, " rlgrap-filename,
        END   OF ty_files.

DATA: t_file_list TYPE TABLE OF epsfili WITH HEADER LINE,
      t_files     TYPE TABLE OF ty_files WITH HEADER LINE.

DATA: wrk_file1    LIKE epsf-epsdirnam,
      wrk_file2    LIKE epsf-epsdirnam,
      wrk_email    LIKE epsf-epsdirnam,
      lv_filename1 TYPE rcgfiletr-ftappl,
      lv_string    TYPE text4096.

DATA: gv_subrc      TYPE sy-subrc.

DATA: gv_xml_string TYPE string.
DATA:  wrk_bom_email TYPE adr6-smtp_addr.
*data:  wrk_bom_email type adr6-SMTP_ADDR.
TYPES: BEGIN OF ty_final,
         value TYPE string,
       END OF ty_final.
DATA: lt_final TYPE TABLE OF ty_final,
      ls_final TYPE ty_final.

TYPES: BEGIN OF ty_xml,

         raw(2000) TYPE c,

       END OF ty_xml.

*      Declaring the XML internal table

DATA:  g_t_xml_tab TYPE TABLE OF ty_xml INITIAL SIZE 0.
DATA:  wa_xml_tab TYPE ty_xml.
DATA:  g_xmldata TYPE xstring.
DATA:  g_t_xml_info TYPE TABLE OF smum_xmltb INITIAL SIZE 0.
DATA: gwa_xml_data  TYPE smum_xmltb.
DATA:  g_t_return TYPE STANDARD TABLE OF bapiret2.


"""""""XML DATA""""""""
TYPES: BEGIN OF ty_final1,
         item_code_matno(20),  "Material Number
         yeild_baseqty(20),     "Base Quantity
         c_effictive_from(10),
         attrib_val_plant(20),    "Plant
         item_code_matnoplant(40),    "Material & Plant
         """"line items
         item_code_bom_bomcomp(20), "BOM Component
         quantity(20),           "Base Quantity
         uom_code_comp_unit_of_measure(20),   "Component unit of measure
         attribute1_bom_usage(20),   "Bom_Usage
         attribute2_alt_bom(20),    "Alternative BOM
         attribute3_change_no(20),  "CHange Number
         attribute4_bom_status(20),  "BOM Status
         attribute5_item_cat(20),    ""Item category (bill of material)
         attribute6_sort_string(20),  "Sort String
         attribute7_item_no(20),      "Item Number
         attribute8_comp_scrap(20),    "Component scrap in percent
         attribute9_sel_indctr(20),   "Selection indicator
         attribute10_co_product(20),  "co_product
         attribute11_sel_indctr(20),   ""Selection indicator
         attribute12_indct_costing(20),  "Indicator for Relevancy to Costing
       END OF ty_final1.

DATA: lt_final1 TYPE TABLE OF ty_final1,
      ls_final1 TYPE ty_final1.

DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.

DATA:    p_mode    TYPE ctu_params-dismode VALUE 'N'.
DATA  : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

"""""""Mail Sending

DATA : lo_mime_helper TYPE REF TO cl_gbt_multirelated_service,
       lo_bcs         TYPE REF TO cl_bcs,
       lo_doc_bcs     TYPE REF TO cl_document_bcs,
       lo_recipient   TYPE REF TO if_recipient_bcs,
       lt_soli        TYPE TABLE OF soli,
       ls_soli        TYPE soli,
       lv_status      TYPE bcs_rqst.

TYPES : BEGIN OF t_message ,
*           lifnr   TYPE char10  , " Customer Number
          status  TYPE char4   , " Light Indicator
          vendor  TYPE char15,
          type    TYPE char4   , " Error Type
          message TYPE char255 , " Message Description
        END OF t_message    .

DATA: i_message   TYPE STANDARD TABLE OF t_message.
DATA: i_message1  TYPE STANDARD TABLE OF t_message.

DATA:count  TYPE i.
FIELD-SYMBOLS :
  <x_message>  TYPE t_message,
  <x_message1> TYPE t_message.
DATA : ls_log TYPE zpp_optiva_log. "Added by Rahul Vasita on 15.03.2024 17:27:27
