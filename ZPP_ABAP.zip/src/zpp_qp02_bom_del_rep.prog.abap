*&---------------------------------------------------------------------*
*& Report  ZPP_QP02_BOM_DEL_REP
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Report           : ZPP_QP02_BOM_DEL_REP                         ---*
*&--Package          :                                      ---*
*&--Description      : REPORT FOR MASS DELETION INDICATOR In QP02 / ---*
*&--Transaction Code : ZFI_OD_MIS                                   ---*
*&--Technical Owner  :                                             ---*
*&--Functional Owner :      ---*
*&--TR No            :                                    ---*
*&---------------------------------------------------------------------*
REPORT zpp_qp02_bom_del_rep.

INCLUDE zpp_qp02_bom_del_top.
INCLUDE zpp_qp02_bom_del_sel.
INCLUDE zpp_qp02_bom_del_sub.


START-OF-SELECTION.
  PERFORM get_data.
  PERFORM prcoess_data.
  PERFORM display_data.
