*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  DATA : lt_exldata TYPE TABLE OF alsmex_tabline,
         ls_exldata TYPE alsmex_tabline.
  DATA: lt_raw     TYPE truxs_t_text_data,
        lv_cnt     TYPE i,
        lv_prcount TYPE p LENGTH 5 DECIMALS 2.
  DATA: lv_round TYPE j_1itaxvar-j_1itaxam1."p LENGTH 13 DECIMALS 2
  REFRESH : lt_final[], lt_log[].

  IF lt_exfinal[] IS NOT INITIAL.

    SORT lt_exfinal BY sf_matnr stlal.
    LOOP AT lt_exfinal ASSIGNING FIELD-SYMBOL(<ls_exfinal>).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <ls_exfinal>-sf_matnr
        IMPORTING
          output = <ls_exfinal>-sf_matnr.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <ls_exfinal>-stlal
        IMPORTING
          output = <ls_exfinal>-stlal.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <ls_exfinal>-matnr
        IMPORTING
          output = <ls_exfinal>-matnr.

      MOVE-CORRESPONDING : <ls_exfinal> TO ls_bom.

      APPEND ls_bom TO lt_bom.
      CLEAR : ls_bom.
    ENDLOOP.
    SORT lt_bom BY sf_matnr stlal matnr.
    DELETE ADJACENT DUPLICATES FROM lt_bom COMPARING sf_matnr stlal matnr.

    LOOP AT lt_bom INTO ls_bom.

      CLEAR : lv_prcount.
      LOOP AT lt_exfinal INTO ls_exfinal WHERE ( ( sf_matnr = ls_bom-sf_matnr
                                           AND stlal = ls_bom-stlal
                                           AND matnr = ls_bom-matnr ) OR ( werks+0(1) = '7') ).
        lv_prcount = lv_prcount + ls_exfinal-contribution.
      ENDLOOP.

      IF lv_prcount IS NOT INITIAL.

        lv_round  = lv_prcount.
        CALL FUNCTION 'J_1I6_ROUND_TO_NEAREST_AMT'
          EXPORTING
            i_amount = lv_round
          IMPORTING
            e_amount = lv_round.

        lv_prcount  = lv_round.

      ENDIF.
      IF ls_bom-matnr = ' '.
        LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                           AND stlal = ls_bom-stlal
                                             AND matnr = ls_bom-matnr.
          ls_log-msg1 = 'RM Code is Blank & Details are Correct'.
          MOVE-CORRESPONDING : ls_exfinal TO ls_log.
          ls_log-version = ls_exfinal-version. """added by akshay dt.15.07.2025
          APPEND ls_log TO lt_log.
          CLEAR: ls_exfinal , ls_log.
        ENDLOOP.
      ELSE.
        IF lv_prcount = '100.00'.
          LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                             AND stlal = ls_bom-stlal
                                               AND matnr = ls_bom-matnr.
            ls_log-msg1 = 'Material Details are Correct'.
            MOVE-CORRESPONDING : ls_exfinal TO ls_log.
            ls_log-version = ls_exfinal-version. """added by akshay dt.15.07.2025
            APPEND ls_log TO lt_log.
            CLEAR: ls_exfinal , ls_log.
          ENDLOOP.
        ELSEIF lv_prcount < '100.00'.
          LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                             AND stlal = ls_bom-stlal
                                               AND matnr = ls_bom-matnr.
            ls_log-msg2 = 'Contribution Less Than Limit of 100%'.
            MOVE-CORRESPONDING : ls_exfinal TO ls_log.
            ls_log-flag = abap_true.
            ls_log-version = ls_exfinal-version. """added by akshay dt.15.07.2025
            APPEND ls_log TO lt_log.
            CLEAR: ls_exfinal , ls_log.
          ENDLOOP.
        ELSEIF lv_prcount > '100.00'.
          LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                             AND stlal = ls_bom-stlal
                                               AND matnr = ls_bom-matnr.
            ls_log-msg2 = 'Contribution Exceed Limit of 100%'.
            MOVE-CORRESPONDING : ls_exfinal TO ls_log.
            ls_log-flag = abap_true.
            ls_log-version = ls_exfinal-version. """added by akshay dt.15.07.2025
            APPEND ls_log TO lt_log.
            CLEAR: ls_exfinal , ls_log.
          ENDLOOP.
        ENDIF.
      ENDIF.
      CLEAR : ls_bom.
    ENDLOOP.


    SORT lt_log BY sr_no.
    ls_log = VALUE #( lt_log[ flag = abap_true ] OPTIONAL ).
    IF ls_log IS INITIAL.
      LOOP AT lt_log INTO ls_log.
        IF ls_log-msg2 = ' ' .
          MOVE-CORRESPONDING : ls_log TO ls_final.
          ls_final-mandt = sy-mandt.
          ls_final-version = ls_log-version. """added by akshay dt.15.07.2025
          APPEND ls_final TO lt_final.
          CLEAR : ls_log , ls_final.
        ENDIF.
      ENDLOOP.
    ELSE.
      READ TABLE lt_log INTO ls_log INDEX 1 .
      CLEAR: gv_plant.
      gv_plant = ls_log-werks.
      PERFORM send_error_email.
    ENDIF.

    IF lt_final[] IS NOT INITIAL.
      SORT lt_final BY sf_matnr stlal.
      MODIFY zpp_bmr_list FROM TABLE lt_final.
      IF sy-subrc = 0.
*        MESSAGE 'DATA UPLOADED SUCCESSFULLY' TYPE 'S'.
      ELSE.
*        MESSAGE 'ERROR WHILE UPLOADING DATA' TYPE 'S' DISPLAY LIKE 'E'.
      ENDIF.
    ENDIF.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  READ_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM read_data .
*****Transfer files from FTP to AL11
  DATA: lv_cmd    TYPE  char18  , "      sxpgcolist-name VALUE 'ZOPTIVB',
        lv_status TYPE extcmdexex-status,
        lv_code   TYPE extcmdexex-exitcode,
        wrk_email LIKE epsf-epsdirnam.

  lv_cmd = 'ZPOPTIVJ'.


  DATA: t_result         TYPE STANDARD TABLE OF btcxpm.
  CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
    EXPORTING
      commandname                   = lv_cmd
*     ADDITIONAL_PARAMETERS         = lv_parm
*     OPERATINGSYSTEM               = SY-OPSYS
*     TARGETSYSTEM                  = SY-HOST
*     DESTINATION                   =
*     STDOUT                        = 'X'
*     STDERR                        = 'X'
*     TERMINATIONWAIT               = 'X'
*     TRACE                         =
*     DIALOG                        =
    IMPORTING
      status                        = lv_status
      exitcode                      = lv_code
    TABLES
      exec_protocol                 = t_result
    EXCEPTIONS
      no_permission                 = 1
      command_not_found             = 2
      parameters_too_long           = 3
      security_risk                 = 4
      wrong_check_call_interface    = 5
      program_start_error           = 6
      program_termination_error     = 7
      x_error                       = 8
      parameter_expected            = 9
      too_many_parameters           = 10
      illegal_command               = 11
      wrong_asynchronous_parameters = 12
      cant_enq_tbtco_entry          = 13
      jobcount_generation_error     = 14
      OTHERS                        = 15.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
     WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


  """""""Read file from AL11"""""



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low
*      INTO wrk_file1
*      FROM tvarvc
*      WHERE name = 'POPTIVA_JOBCARD'.

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = 'POPTIVA_JOBCARD'
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix

*
  SELECT SINGLE low
      INTO wrk_file2
      FROM tvarvc
      WHERE name = 'OPTIVA_BOM_DELE' .

  CALL FUNCTION 'EPS_GET_DIRECTORY_LISTING '
    EXPORTING
      dir_name     = wrk_file1
      file_mask    = '*.*'
    TABLES
      dir_list     = t_file_list
    EXCEPTIONS
      access_error = 1
      OTHERS       = 2.
  IF sy-subrc IS INITIAL.
    LOOP AT t_file_list .
      t_files-appsrv_fname = t_file_list-name.
      APPEND t_files.
      CLEAR  t_files.
    ENDLOOP.
  ENDIF.

  LOOP AT t_files.

    CONCATENATE wrk_file1 '/' t_files-appsrv_fname INTO lv_filename1.
    CONDENSE: lv_filename1.
    OPEN DATASET  lv_filename1 FOR INPUT IN TEXT MODE ENCODING DEFAULT.

    CLEAR: gv_xml_string,wa_xml_tab,g_xmldata.
    REFRESH: g_t_xml_tab,g_t_xml_info,g_t_return.

    DO.
      READ DATASET  lv_filename1 INTO wa_xml_tab .
      IF sy-subrc NE 0.
        EXIT.
      ELSE.
        CONDENSE wa_xml_tab.
        APPEND  wa_xml_tab TO  g_t_xml_tab.
      ENDIF.
    ENDDO.

    IF g_t_xml_tab IS NOT INITIAL.
      CONCATENATE LINES OF g_t_xml_tab INTO gv_xml_string SEPARATED BY space.
    ENDIF.

    PERFORM data_upload.
    PERFORM get_data.
    PERFORM delete_file .

    CLEAR : ls_log.

  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_upload .

  CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
    EXPORTING
      text   = gv_xml_string
    IMPORTING
      buffer = g_xmldata
    EXCEPTIONS
      failed = 1
      OTHERS = 2.

  IF sy-subrc NE 0.
    MESSAGE 'Error in the XML file' TYPE 'E'.
  ENDIF.

  CALL FUNCTION 'SMUM_XML_PARSE'
    EXPORTING
      xml_input = g_xmldata
    TABLES
      xml_table = g_t_xml_info
      return    = g_t_return
    EXCEPTIONS
      OTHERS    = 0.

*”If XML parsing is not successful, return table will contain error messages
  READ TABLE g_t_return INTO DATA(wa_return) WITH KEY type = 'E'.

  IF sy-subrc EQ 0.
    MESSAGE 'Error converting the input XML file' TYPE 'E'.

  ELSE.
    REFRESH g_t_return.
    PERFORM data_operation.
  ENDIF.



ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DELETE_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM delete_file .
  DATA:  lv_tpath  LIKE sapb-sappfad.

  CONCATENATE wrk_file2 t_files-appsrv_fname INTO lv_tpath.
  CALL FUNCTION 'ARCHIVFILE_SERVER_TO_SERVER'
    EXPORTING
      sourcepath       = lv_filename1+0(70)
      targetpath       = lv_tpath
    EXCEPTIONS
      error_file       = 1
      no_authorization = 2
      OTHERS           = 3.
  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
  ENDIF.

  DELETE DATASET lv_filename1.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_OPERATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_operation .

  DATA: flag TYPE flag.
  CLEAR :flag,gwa_xml_data.
  DATA:fsformulaingr TYPE string.
  DATA: matno(255).
  DATA: lv_process_txt TYPE sstring.
  CLEAR fsformulaingr.
  DATA:lv_txt(4000) TYPE c.
  DATA(lv_lines) = lines( g_t_xml_info ).
  CLEAR:ls_final.REFRESH: lt_final , lt_exfinal.

  LOOP AT g_t_xml_info INTO gwa_xml_data .

    IF gwa_xml_data-cname = 'FORMULA_CODE'.
      ls_exfinal-sf_matnr = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'VERSION'.
      ls_exfinal-version = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'C_RMMG1_WERKS'.
      ls_exfinal-werks = gwa_xml_data-cvalue.
*    ELSEIF gwa_xml_data-cname = 'FORMULA_ID'.
*      ls_final-item_code_bom_bomcomp = gwa_xml_data-cvalue.
*    ELSEIF gwa_xml_data-cname = 'DM_OBJECT_TYPE'.
*      ls_final-quantity = gwa_xml_data-cvalue.
*    ELSEIF gwa_xml_data-cname = 'DM_LINE_ID'.
*      ls_final-uom_code_comp_unit_of_measure = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'FIELD1'.
      ls_exfinal-sr_no = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'FIELD2'.
      ls_exfinal-matnr = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'FIELD3'.
*      CONCATENATE  ls_exfinal-process_txt_n gwa_xml_data-cvalue INTO ls_exfinal-process_txt_n.
      CONCATENATE  ls_exfinal-process_txt gwa_xml_data-cvalue INTO ls_exfinal-process_txt.

*      ls_exfinal-process_txt_n =  lv_txt.
    ELSEIF gwa_xml_data-cname = 'FIELD4'.
      ls_exfinal-contribution = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'FIELD5'.
      ls_exfinal-std_tmp = gwa_xml_data-cvalue.
*    ELSEIF gwa_xml_data-cname = 'FIELD6'.
*      ls_final-attribute6_sort_string = gwa_xml_data-cvalue.
    ENDIF.

    IF gwa_xml_data-cname = 'FSFORMULAMATRIX_4' OR sy-tabix = lv_lines.
      APPEND ls_exfinal TO lt_exfinal.
      CLEAR:ls_exfinal-std_tmp,ls_exfinal-contribution,ls_exfinal-process_txt,ls_exfinal-matnr,ls_exfinal-sr_no,lv_process_txt,lv_txt.
    ENDIF.
  ENDLOOP.

  IF lt_exfinal[] IS NOT INITIAL.
    DELETE lt_exfinal INDEX 1.
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_ERROR_EMAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_error_email .

  CLEAR: ls_soli.
  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>errors found while uploading JOBCARD in SAP Check Attachment</P>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Error while uploading JOBCARD in SAP'.

*   Get Data For Attachment
  PERFORM load_data.
  cl_salv_table=>factory(
  EXPORTING
  list_display = abap_false
  IMPORTING
  r_salv_table = DATA(lo_salv_table)
  CHANGING
  t_table =  lt_log ).

  LOOP AT mt_columns ASSIGNING FIELD-SYMBOL(<column>).
    DATA(lo_column) = lo_salv_table->get_columns( )->get_column( <column>-column_name ).
    lo_column->set_long_text( CONV #( <column>-column_value ) ).
    lo_column->set_medium_text( CONV #( <column>-column_value ) ).
    lo_column->set_short_text( CONV #( <column>-column_value ) ).
  ENDLOOP.

  DATA(lt_fcat) = cl_salv_controller_metadata=>get_lvc_fieldcatalog(
   r_columns = lo_salv_table->get_columns( )
   r_aggregations = lo_salv_table->get_aggregations( ) ).


  cl_salv_bs_lex=>export_from_result_data_table(
  EXPORTING
  is_format = if_salv_bs_lex_format=>mc_format_xlsx
  ir_result_data_table = cl_salv_ex_util=>factory_result_data_table(
  r_data = REF #( lt_log )
  t_fieldcatalog = lt_fcat )
  IMPORTING
  er_result_file = DATA(rv_xstring) ).



* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                i_subject          = 'Error while uploading JOBCARD in SAP'
                i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).

  lo_bcs->set_document( i_document = lo_doc_bcs ).

* Set the email address
  SELECT * FROM zpp_brm_err_ema INTO TABLE @DATA(lt_email_id) WHERE plant = @gv_plant.
  IF sy-subrc = 0.
    LOOP AT lt_email_id INTO DATA(wa_email_id).
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wa_email_id-email_id ).

      lo_bcs->add_recipient( i_recipient = lo_recipient ).

    ENDLOOP.
*  * ATTACHMENT

    DATA(lv_excel_data) = rv_xstring.
    lo_doc_bcs->add_attachment(
    i_attachment_type = 'XLS'
    i_attachment_subject = 'Error while uploading JOBCARD in SAP'
    i_attachment_size = CONV #( xstrlen( lv_excel_data ) )
    i_att_content_hex = cl_bcs_convert=>xstring_to_solix( lv_excel_data ) ).

* Change the status.
    lv_status = 'N'.
    CALL METHOD lo_bcs->set_status_attributes
      EXPORTING
        i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
    TRY.
        lo_bcs->send( ).
        COMMIT WORK.
      CATCH cx_bcs INTO DATA(lx_bcs).
        ROLLBACK WORK.
    ENDTRY.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  LOAD_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM load_data .

  mt_columns = VALUE #( ( column_name = 'SR_NO'  column_value = 'Serial No.' )
                        ( column_name = 'WERKS'  column_value = 'Plant' )
                        ( column_name = 'SF_MATNR' column_value = 'SF Material' )
                        ( column_name = 'STLAL'  column_value = 'Alternative BOM' )
                        ( column_name = 'PROCESS_TXT'  column_value = 'Process TXT' )
                        ( column_name = 'MATNR' column_value = 'Material' )
                        ( column_name = 'CONTRIBUTION' column_value = 'Contribution' )
                        ( column_name = 'STD_TMP'  column_value = 'TMP' )
                        ( column_name = 'STD_TIME'  column_value = 'Time' )
                        ( column_name = 'MSG1' column_value = 'Sucess Msg' )
                        ( column_name = 'MSG2'  column_value = 'Error Msg' )
                        ( column_name = 'FLAG'  column_value = 'Error Flag.' )
  ).

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CONVERT_ITAB_EXCEL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM convert_itab_excel .

ENDFORM.
