*----------------------------------------------------------------------*
***INCLUDE ZXCO1O01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Module STATUS_0100 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

  ASSIGN ('(SAPLCOKO1)CAUFVD-WERKS') TO FIELD-SYMBOL(<x_werks>).
  ASSIGN ('(SAPLCOKO1)CAUFVD-AUART') TO FIELD-SYMBOL(<x_AUART>).
  IF <x_werks> IS ASSIGNED and  <x_AUART> IS ASSIGNED.
    select SINGLE * from zpp_cust_fields
      WHERE zplant = @<x_werks>
      and zordertype = @<x_AUART>
      and zdeletionflag is INITIAL
      into @data(ls_cust).
   IF ls_cust is INITIAL.
      LOOP AT SCREEN.
        IF screen-group1 = 'GP1'.
          screen-input = 0.
          screen-invisible = 0.
          MODIFY SCREEN.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
 "soc UDAYABAP01 uat Additions pt 26022026
  if  AUFK-ZORDER_FLOW is INITIAL.
  AUFK-ZORDER_FLOW = 'N'.
  endif.
  "Eoc UDAYABAP01 uat Additions pt 26022026
ENDMODULE.
