TYPES:BEGIN OF ty_spec,
        sr_no(5)   TYPE c,
        kurztext   TYPE qpmt-kurztext,
        toleranzob TYPE string,
        toleranzun TYPE string,
        masseinhsw TYPE qamv-masseinhsw,
        total_s    TYPE f,
        total_c    TYPE string,
      END OF ty_spec.















