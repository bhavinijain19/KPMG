*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_WORK_CENTER.................................*
DATA:  BEGIN OF STATUS_ZPP_WORK_CENTER               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_WORK_CENTER               .
CONTROLS: TCTRL_ZPP_WORK_CENTER
            TYPE TABLEVIEW USING SCREEN '9999'.
*.........table declarations:.................................*
TABLES: *ZPP_WORK_CENTER               .
TABLES: ZPP_WORK_CENTER                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
