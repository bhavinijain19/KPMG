*----------------------------------------------------------------------*
***INCLUDE LZZ_QE01O01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Module STATUS_9100 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_9100 OUTPUT.


   IMPORT w_qals TO w_qals FROM MEMORY ID 'QALS_DATA'.


  UNASSIGN <x_trtyp> .
  ASSIGN ('(SAPMV45A)T180-TRTYP') TO <x_trtyp>.
  IF <x_trtyp> IS ASSIGNED.
    IF <x_trtyp> = 'A'.
      LOOP AT SCREEN.
        IF screen-group1 = 'GP1'.
          screen-input = 0.
          MODIFY SCREEN.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDMODULE.
