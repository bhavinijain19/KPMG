class ZCL_IM_WORKORDER_CONFIRM_CRO6N definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_WORKORDER_CONFIRM .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_WORKORDER_CONFIRM_CRO6N IMPLEMENTATION.


  method IF_EX_WORKORDER_CONFIRM~AT_CANCEL_CHECK.
  endmethod.


  METHOD if_ex_workorder_confirm~at_save.

    DATA:lv_palqty TYPE gamng,
         lv_ordqty TYPE gamng.


 IF sy-tcode = 'COR6N'.

    SELECT SINGLE plnbez, auart
    FROM caufv
    INTO @DATA(ls_caufv)
    WHERE aufnr = @is_confirmation-aufnr.

    SELECT SINGLE wemng
    FROM afpo
    INTO @DATA(lv_wemng)
    WHERE aufnr = @is_confirmation-aufnr.

    SELECT SINGLE * FROM tvarvc
      INTO @DATA(ls_tvarvc) WHERE name EQ 'ZCO11N_MATERIALNO'
      AND low EQ @ls_caufv-plnbez.

  if sy-subrc is not initial.

    SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @ls_caufv-plnbez.
    SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
    IF sy-subrc IS INITIAL.
      SELECT SINGLE * FROM zwm_config INTO @DATA(lw_data) WHERE werks = @is_confirmation-werks AND auart = @ls_caufv-auart.
        IF lw_data IS NOT INITIAL.
          SELECT SUM( su_qty )
               FROM zwm_su
               INTO ( lv_palqty )
               WHERE aufnr   EQ is_confirmation-aufnr
                 AND pprint  EQ abap_true
                 AND del_flg EQ abap_false.
          lv_ordqty = is_confirmation-lmnga + lv_wemng.
          IF lv_ordqty GT lv_palqty.
            MESSAGE 'Confirmation qty should not exceed SU qty' TYPE 'E'.
          ENDIF.
        ENDIF.
    ENDIF.
  ENDIF.

ENDIF.
ENDMETHOD.


  method IF_EX_WORKORDER_CONFIRM~BEFORE_UPDATE.
    DATA(lv_check) = 'X'.
  endmethod.


  method IF_EX_WORKORDER_CONFIRM~INDIVIDUAL_CAPACITY.
  endmethod.


  method IF_EX_WORKORDER_CONFIRM~IN_UPDATE.
  endmethod.
ENDCLASS.
