*&---------------------------------------------------------------------*
*& Include          ZXCO1U11
*&---------------------------------------------------------------------*
*MOVE is_afrud-zzlot1     TO wa_afru-zzlot1 .
AUFK-zorder_flow = I_CAUFVD-zorder_flow.
