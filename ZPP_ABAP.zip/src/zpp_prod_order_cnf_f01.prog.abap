*&---------------------------------------------------------------------*
*& Include          ZPP_PROD_ORDER_CNF_F01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form authorization
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM authorization .
  AUTHORITY-CHECK OBJECT 'ZCNF_WERKS'
     ID 'WERKS' FIELD s_werks-low
     ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e007(zsd) WITH s_werks-low.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_data .

  TYPES: BEGIN OF ty_mfg_order,
           manufacturingorder         TYPE i_manufacturingorder-manufacturingorder,
           productionplant            TYPE i_manufacturingorder-productionplant,
           product                    TYPE i_manufacturingorder-product,
           manufacturingordertext     TYPE i_manufacturingorder-manufacturingordertext,
           mfgorderplannedtotalqty    TYPE i_manufacturingorder-mfgorderplannedtotalqty,
           manufacturingordercategory TYPE i_manufacturingorder-manufacturingordercategory,
           productionunit             TYPE i_manufacturingorder-productionunit,
           productionsupervisor       TYPE i_manufacturingorder-productionsupervisor,
           billofmaterial             TYPE i_manufacturingorder-billofmaterial,
           billofmaterialvariant      TYPE i_manufacturingorder-billofmaterialvariant,
           billofoperationstype       TYPE i_manufacturingorder-billofoperationstype,
           billofoperationsgroup      TYPE i_manufacturingorder-billofoperationsgroup,
           billofoperationsvariant    TYPE i_manufacturingorder-billofoperationsvariant,
           mfgorderscheduledstartdate TYPE dats,
           mfgorderscheduledenddate   TYPE dats,
           mfgorderactualreleasedate  TYPE dats,
           productionversion          TYPE i_manufacturingorder-productionversion,
           actualreleasedate          TYPE i_manufacturingorder-mfgorderactualreleasedate,
         END OF ty_mfg_order.

  DATA : gt_orders TYPE TABLE OF ty_mfg_order,
         lv_wc_id  TYPE i_workcenter-workcenterinternalid.

  IF p_rad1 = 'X' OR p_rad3 = 'X'.  "Radio button 1 & 3


    IF p_rad3 = 'X'.

      SELECT
       a~manufacturingorder,
       a~productionplant,
       a~product,
       a~manufacturingordertext,
       a~mfgorderplannedtotalqty,
       a~manufacturingordercategory,
       a~productionunit,
       a~productionsupervisor,
       a~billofmaterial,
       a~billofmaterialvariant,
       a~billofoperationstype,
       a~billofoperationsgroup,
       a~billofoperationsvariant,
       a~mfgorderscheduledstartdate,
       a~mfgorderscheduledenddate,
       a~mfgorderactualreleasedate,
       a~productionversion,
       a~mfgorderactualreleasedate
       FROM i_manufacturingorder      AS a
       INNER JOIN i_mfgorderwithstatus AS s
         ON s~manufacturingorder = a~manufacturingorder
       WHERE a~productionplant IN @s_werks
         AND a~manufacturingorder IN @s_aufnr
        AND a~productionsupervisor IN @s_fevor
         AND a~manufacturingordercategory IN ('10','40')
*         AND
*               s~orderisreleased              <> ' '
        AND ( s~orderistechnicallycompleted  <> ' '
            OR s~orderisdelivered             <> ' ' )

*            ( s~orderispartiallyconfirmed    <> ' '
*            OR s~orderisconfirmed             <> ' '
*            OR s~orderisclosed                <> ' '
*            OR s~orderisdeleted               <> ' ' )
  INTO TABLE @gt_orders.
      IF sy-subrc = 0.
        SORT gt_orders.
      ELSE.
        MESSAGE 'No Data Found!' TYPE 'E'.
      ENDIF.

    ELSE.
      "Manufacturing Order
      SELECT  a~manufacturingorder,
              a~productionplant,
              a~product,
              a~manufacturingordertext,
              a~mfgorderplannedtotalqty,
              a~manufacturingordercategory,
              a~productionunit,
              a~productionsupervisor,
              a~billofmaterial,
              a~billofmaterialvariant,
              a~billofoperationstype,
              a~billofoperationsgroup,
              a~billofoperationsvariant,
              a~mfgorderscheduledstartdate,
              a~mfgorderscheduledenddate,
              a~mfgorderactualreleasedate,
              a~productionversion,
              a~mfgorderactualreleasedate
        FROM i_manufacturingorder AS a
         INNER JOIN i_mfgorderwithstatus AS s
         ON s~manufacturingorder = a~manufacturingorder
          WHERE a~productionplant IN @s_werks
         AND a~manufacturingorder IN @s_aufnr
        AND a~productionsupervisor IN @s_fevor
         AND a~manufacturingordercategory IN ('10','40')
         AND  s~orderisreleased              <> ' '
        AND ( s~orderispartiallyconfirmed    <> ' '
            OR s~orderisdelivered            <> ' ' )
        INTO TABLE @gt_orders.
      IF sy-subrc = 0.
        SORT gt_orders.
      ELSE.
        MESSAGE 'No Data Found!' TYPE 'E'.
      ENDIF.
    ENDIF.


    "Order Confirmations
    SELECT manufacturingorder,
           mfgorderconfirmationgroup,
           materialdocument,
           materialdocumentyear,
           mfgorderconfirmation,
           mfgorderconfirmationentrydate,
           manufacturingorderoperation_2,
           workcenterinternalid,
           confyieldqtyinproductionunit,
           operationunit,
           opconfirmedworkquantity1,
           opworkquantityunit1,
           opconfirmedworkquantity2,
           opworkquantityunit2,
           opconfirmedworkquantity3,
           opworkquantityunit3,
           opconfirmedworkquantity4,
           opworkquantityunit4,
           opconfirmedworkquantity5,
           opworkquantityunit5,
           opconfirmedworkquantity6,
           opworkquantityunit6
      FROM i_mfgorderconfirmation
      FOR ALL ENTRIES IN @gt_orders
        WHERE manufacturingorder = @gt_orders-manufacturingorder
        AND mfgorderconfirmationentrydate IN @s_budat
        AND  isreversed = @abap_false
        AND isreversal = @abap_false
        INTO TABLE @DATA(gt_conf).


**
**    SELECT manufacturingorder,
**           materialdocument,
**           materialdocumentyear,
**           mfgorderconfirmationentrydate,
**           confyieldqtyinproductionunit,
**           operationunit,
**           workcenterinternalid
**      FROM i_mfgorderconfirmation
**      FOR ALL ENTRIES IN @gt_orders
**      WHERE manufacturingorder = @gt_orders-manufacturingorder
**      AND mfgorderconfirmationentrydate IN @s_budat
**        AND isreversed = @abap_false
**      INTO TABLE @DATA(gt_conf).
**    IF sy-subrc = 0.
**      SORT gt_conf.
**    ENDIF.


    "WorkCenter Text
    SELECT workcenterinternalid,
           workcenter
      FROM i_workcenter
      FOR ALL ENTRIES IN @gt_conf
      WHERE workcenterinternalid = @gt_conf-workcenterinternalid
      INTO TABLE @DATA(gt_workcenter).
    IF sy-subrc = 0.
      SORT gt_workcenter.
    ENDIF.


    IF p_mat = 'X'.  " Material



      "Material Group
      SELECT product,
             productgroup
        FROM i_product
        FOR ALL ENTRIES IN @gt_orders
        WHERE product = @gt_orders-product
        INTO TABLE @DATA(gt_product).
      IF sy-subrc = 0.
        SORT gt_product.
      ENDIF.




      "Material Documents
      SELECT materialdocument,
             materialdocumentyear,
             material,
             quantityinbaseunit,
             materialbaseunit," baseunit,
             storagelocation,
             goodsmovementtype
        FROM i_materialdocumentitem
        FOR ALL ENTRIES IN @gt_conf
        WHERE materialdocument     = @gt_conf-materialdocument
          AND materialdocumentyear = @gt_conf-materialdocumentyear
          AND goodsmovementtype IN ( '261', '531' )
        INTO TABLE @DATA(gt_matdoc).
      IF sy-subrc = 0.
        SORT gt_matdoc.
      ENDIF.

      SELECT product,
             productname
        FROM i_producttext
        FOR ALL ENTRIES IN @gt_matdoc
        WHERE product  = @gt_matdoc-material
          AND language = @sy-langu
        INTO TABLE @DATA(gt_text).
      IF sy-subrc = 0.
        SORT gt_text.
      ENDIF.


      "BOM Quantity and UOM
      SELECT billofmaterial,
             billofmaterialvariant,
             material,
             billofmaterialcomponent,
             billofmaterialitemquantity,
        billofmaterialitemunit
            " variablesizecompunitofmeasure
        FROM i_billofmaterialitemtp
        FOR ALL ENTRIES IN @gt_orders
        WHERE billofmaterial        = @gt_orders-billofmaterial
          AND billofmaterialvariant = @gt_orders-billofmaterialvariant
        INTO TABLE @DATA(gt_bom).
      IF sy-subrc = 0.
        SORT gt_bom.
      ENDIF.



*      DATA :ls_out TYPE ty_mat1.

      LOOP AT gt_conf ASSIGNING FIELD-SYMBOL(<fs_conf>).

        DATA(ls_out) = VALUE ty_mat1( ).

        LOOP AT gt_matdoc INTO DATA(ls_md)
          WHERE materialdocument = <fs_conf>-materialdocument AND
          materialdocumentyear = <fs_conf>-materialdocumentyear.
          "--------------------------------------------------
          " Manufacturing Order (Mandatory)
          "--------------------------------------------------
          READ TABLE gt_orders ASSIGNING FIELD-SYMBOL(<fs_ord>)
            WITH KEY manufacturingorder = <fs_conf>-manufacturingorder.

          IF sy-subrc = 0.
            ls_out-productionorder       = <fs_ord>-manufacturingorder.
            ls_out-plant                 = <fs_ord>-productionplant.
            ls_out-finished_material     = <fs_ord>-product.
            ls_out-finished_material_desc     = <fs_ord>-manufacturingordertext.
            ls_out-total_qty             = <fs_ord>-mfgorderplannedtotalqty.
            ls_out-total_qty_uom             = <fs_ord>-productionunit.
            ls_out-production_supervisor = <fs_ord>-productionsupervisor.


            "--------------------------------------------------
            " Product Group
            "--------------------------------------------------
            READ TABLE gt_product ASSIGNING FIELD-SYMBOL(<fs_prod>) WITH KEY product = ls_out-finished_material.
            IF sy-subrc = 0.
              ls_out-material_group = <fs_prod>-productgroup.
            ENDIF.

            "--------------------------------------------------
            " Confirmation Data
            "--------------------------------------------------
            ls_out-material_document  = <fs_conf>-materialdocument.
            ls_out-material_document_year  = <fs_conf>-materialdocumentyear.
            ls_out-posting_date       = <fs_conf>-mfgorderconfirmationentrydate.
            ls_out-produced_qty       = <fs_conf>-confyieldqtyinproductionunit.
            ls_out-produced_uom       = <fs_conf>-operationunit.

            "--------------------------------------------------
            " Material Document Item
            "--------------------------------------------------
*          READ TABLE gt_matdoc ASSIGNING FIELD-SYMBOL(<fs_md>)
*            WITH KEY materialdocument     = <fs_conf>-materialdocument
*                     materialdocumentyear = <fs_conf>-materialdocumentyear.
*          LOOP AT gt_matdoc INTO DATA(ls_md)
*            WHERE materialdocument = <fs_conf>-materialdocument AND
*            materialdocumentyear = <fs_conf>-materialdocumentyear.


*            IF sy-subrc = 0.
            ls_out-material_used     = ls_md-material.
            ls_out-used_qty          = ls_md-quantityinbaseunit.
            ls_out-used_qty_uom      = ls_md-materialbaseunit.
            ls_out-storage_location  = ls_md-storagelocation.
            ls_out-movement_type     = ls_md-goodsmovementtype.
            ls_out-comp_movement_type     = ls_md-goodsmovementtype.
*            ENDIF.

            "--------------------------------------------------
            " Used Material Description
            "--------------------------------------------------
            READ TABLE gt_text ASSIGNING FIELD-SYMBOL(<fs_txt>)
              WITH KEY product = ls_out-material_used.

            IF sy-subrc = 0.
              ls_out-material_used_desc = <fs_txt>-productname.
            ENDIF.

            "--------------------------------------------------
            " BOM Quantity & UOM
            "--------------------------------------------------
            READ TABLE gt_bom ASSIGNING FIELD-SYMBOL(<fs_bom>)
              WITH KEY billofmaterial        = <fs_ord>-billofmaterial
                       billofmaterialvariant = <fs_ord>-billofmaterialvariant
                       billofmaterialcomponent = ls_out-material_used.

            IF sy-subrc = 0.
*            ls_out-bom_qty = <fs_bom>-billofmaterialitemquantity.
              IF <fs_ord>-mfgorderplannedtotalqty > 0.
                ls_out-bom_qty    =   ( <fs_conf>-confyieldqtyinproductionunit * <fs_bom>-billofmaterialitemquantity ) / <fs_ord>-mfgorderplannedtotalqty.
              ENDIF.
              ls_out-bom_uom = <fs_bom>-billofmaterialitemunit.
            ENDIF.

            "--------------------------------------------------
            " Work Center
            "--------------------------------------------------
            READ TABLE gt_workcenter ASSIGNING FIELD-SYMBOL(<fs_wc>)
              WITH KEY workcenterinternalid = <fs_conf>-workcenterinternalid.

            IF sy-subrc = 0.
              ls_out-work_center = <fs_wc>-workcenter.
            ENDIF.

            "--------------------------------------------------
            " Deviation Calculation (Safe)
            "--------------------------------------------------
            IF ls_out-bom_qty IS NOT INITIAL AND ls_out-used_qty IS NOT INITIAL.

              ls_out-deviation_qty = ls_out-bom_qty - ls_out-used_qty.

              ls_out-deviation_pct = ( ls_out-deviation_qty / ls_out-bom_qty ) * 100.
            ENDIF.

            APPEND ls_out TO gt_mat1.
            CLEAR ls_out.


          ENDIF.
        ENDLOOP.
      ENDLOOP.


      IF gt_mat1[] IS NOT INITIAL.
        PERFORM f_matdisplay.
      ENDIF.



      " Activity   for Rad 1 and Rad 3

    ELSEIF p_act = 'X'.

      DATA : ls_act TYPE ty_act1.
      DATA : lt_opr   TYPE TABLE OF capp_opr,
             lt_phase TYPE TABLE OF capp_opr.

      SELECT manufacturingorder,
             mfgorderitemgoodsreceiptqty
        FROM i_manufacturingorderitem
        INTO TABLE @DATA(lt_mo_item)
        FOR ALL ENTRIES IN @gt_orders
        WHERE manufacturingorder = @gt_orders-manufacturingorder.

      SELECT a~product,
             a~productionplant AS plant,
             a~productionversion,
             p~costestimate,
             p~costinglotsize,
             p~costingdate,
             p~procmtaltvcostestimate
*             workcenterinternalid,
*             costestimatevalidfrom
      FROM i_productcostestimate AS p
        INNER JOIN i_manufacturingorder AS a
        ON a~product = p~product
        AND a~productionplant = p~plant
      INTO TABLE @DATA(gt_cost)
      FOR ALL ENTRIES IN @gt_conf
        WHERE costingdate  <= @gt_conf-mfgorderconfirmationentrydate
*        AND coste = @gt_conf-workcenterinternalid
        AND costestimatestatus = 'FR'
        AND a~manufacturingorder = @gt_conf-manufacturingorder.

      IF sy-subrc = 0.
        SORT gt_cost BY product plant productionversion costestimate costingdate DESCENDING.  "PROCMTALTVCOSTESTIMATE not blank
      ENDIF.



      SELECT costestimate,
             costctractivitytype,
             quantityinbaseunit,
             costingobject,
             operation,
             baseunit
      FROM i_productcostestimateitem
      INTO TABLE @DATA(gt_cost_item)
      FOR ALL ENTRIES IN @gt_cost
      WHERE costestimate = @gt_cost-costestimate
        AND costingitemcategory = 'E'
        AND costctractivitytype IN
            ('900001','900002','900003','900004','900005','900006').

      "Standard Workcenter
      SELECT workcenterinternalid,
             workcenter
            FROM i_workcenter
            FOR ALL ENTRIES IN @gt_cost_item
            WHERE workcenterinternalid = @gt_cost_item-costingobject
            INTO TABLE @DATA(gt_st_wc).
      IF sy-subrc = 0.
        SORT gt_st_wc.
      ENDIF.


      LOOP AT gt_orders INTO DATA(ls_order).

        LOOP AT gt_conf INTO DATA(ls_conf)
             WHERE manufacturingorder = ls_order-manufacturingorder.

          CLEAR ls_act.

          "Header
          ls_act-manufacturingorder = ls_order-manufacturingorder.
          ls_act-plant              = ls_order-productionplant.
          ls_act-product            = ls_order-product.
          ls_act-product_text       = ls_order-manufacturingordertext.
          ls_act-order_qty          = ls_order-mfgorderplannedtotalqty.
          ls_act-prod_supervisor    = ls_order-productionsupervisor.
          ls_act-sched_start        = ls_order-mfgorderscheduledstartdate.
          ls_act-sched_end          = ls_order-mfgorderscheduledenddate.
          ls_act-rel_date           = ls_order-mfgorderactualreleasedate.

          "Confirmation
          ls_act-conf_group = ls_conf-mfgorderconfirmationgroup.
          ls_act-conf_counter = ls_conf-mfgorderconfirmation.
          ls_act-conf_date = ls_conf-mfgorderconfirmationentrydate.
          ls_act-operation = ls_conf-manufacturingorderoperation_2.
          ls_act-produced_qty = ls_conf-confyieldqtyinproductionunit.
          ls_act-prod_uom = ls_conf-operationunit.

          "Actual Work Center
          READ TABLE gt_workcenter INTO DATA(ls_wc)
            WITH KEY workcenterinternalid = ls_conf-workcenterinternalid.
          IF sy-subrc = 0.
            ls_act-workcenter = ls_wc-workcenter.
            lv_wc_id = ls_wc-workcenterinternalid.
          ENDIF.


          "Utilised
          ls_act-utl_setup_lab  = ls_conf-opconfirmedworkquantity1.
          ls_act-utl_slab_unit   = ls_conf-opworkquantityunit1.

          ls_act-utl_setup_mach = ls_conf-opconfirmedworkquantity2.
          ls_act-utl_smach_unit = ls_conf-opworkquantityunit2.

          ls_act-utl_setup_pow  = ls_conf-opconfirmedworkquantity3.
          ls_act-utl_spow_unit = ls_conf-opworkquantityunit3.

          ls_act-utl_mach       = ls_conf-opconfirmedworkquantity4.
          ls_act-utl_mach_unit  = ls_conf-opworkquantityunit4.

          ls_act-utl_lab        = ls_conf-opconfirmedworkquantity5.
          ls_act-utl_lab_unit   = ls_conf-opworkquantityunit5.

          ls_act-utl_pow        = ls_conf-opconfirmedworkquantity6.
          ls_act-utl_pow_unit   = ls_conf-opworkquantityunit6.


          "Cost Estimate (date-valid)
          READ TABLE gt_cost INTO DATA(ls_cost)
            WITH KEY product = ls_order-product
                     plant = ls_order-productionplant
                     productionversion = ls_order-productionversion
                     .

          IF sy-subrc = 0.

            LOOP AT gt_cost_item INTO DATA(ls_item)
                 WHERE costestimate = ls_cost-costestimate AND operation = ls_conf-manufacturingorderoperation_2.

              CASE ls_item-costctractivitytype.
                WHEN '900003'.
                  ls_act-std_setup_lab = ls_item-quantityinbaseunit.
                  ls_act-std_lab_unit = ls_item-baseunit.

                WHEN '900001'.
                  ls_act-std_setup_mac = ls_item-quantityinbaseunit.
                  ls_act-std_mac_unit = ls_item-baseunit.

                WHEN '900005'.
                  ls_act-std_setup_pow = ls_item-quantityinbaseunit.
                  ls_act-std_pow_unit = ls_item-baseunit.

                WHEN '900002'.
                  ls_act-std_mac = ls_item-quantityinbaseunit.
                  ls_act-std_mac_u = ls_item-baseunit.

                WHEN '900004'.
                  ls_act-std_lab = ls_item-quantityinbaseunit.
                  ls_act-std_lab_u = ls_item-baseunit.

                WHEN '900006'.
                  ls_act-std_pow = ls_item-quantityinbaseunit.
                  ls_act-std_pow_u = ls_item-baseunit.

              ENDCASE.


              "Standard WC
              READ TABLE gt_st_wc INTO DATA(ls_swc)
                WITH KEY workcenterinternalid = ls_item-costingobject.
              IF sy-subrc = 0.
                ls_act-std_workcenter = ls_swc-workcenter.
              ENDIF.

            ENDLOOP.
          ENDIF.

          "Planned

          CALL FUNCTION 'CARO_ROUTING_READ'
            EXPORTING
*             DATE_FROM    = '19000101'
*             DATE_TO      = '99991231'
              plnty        = ls_order-billofoperationstype
              plnnr        = ls_order-billofoperationsgroup
              plnal        = ls_order-billofoperationsvariant
*             MATNR        =
*             BUFFER_DEL_FLG             = 'X'
*             DELETE_ALL_CAL_FLG         = 'X'
*             ADAPT_FLG    = 'X'
*             IV_CREATE_ADD_CHANGE       = ' '
*             WERKS        =
            TABLES
*             TSK_TAB      =
*             SEQ_TAB      =
              opr_tab      = lt_opr
              phase_tab    = lt_phase
*             SUBOPR_TAB   =
*             REL_TAB      =
*             COM_TAB      =
*             REFERR_TAB   =
*             REFMIS_TAB   =
*             IT_AENR      =
            EXCEPTIONS
              not_found    = 1
              ref_not_exp  = 2
              not_valid    = 3
              no_authority = 4
              OTHERS       = 5.
          IF sy-subrc <> 0.
* Implement suitable error handling here
          ENDIF.
          IF ls_order-manufacturingordercategory = '10'.

            READ TABLE lt_opr ASSIGNING FIELD-SYMBOL(<ls_opr>) WITH KEY arbid =  lv_wc_id.
            IF sy-subrc = 0.
              ls_act-pln_setup_lab = <ls_opr>-vgw01.
              ls_act-pln_setup_lab_unit = <ls_opr>-vge01.

              ls_act-pln_setup_mac = <ls_opr>-vgw02.
              ls_act-pln_setup_mac_unit = <ls_opr>-vge02.

              ls_act-pln_setup_pow = <ls_opr>-vgw03.
              ls_act-pln_setup_pow_unit = <ls_opr>-vge03.

              READ TABLE lt_mo_item INTO DATA(ls_mo)
                   WITH KEY manufacturingorder = ls_order-manufacturingorder.
              IF sy-subrc = 0 AND <ls_opr>-bmsch > 0.
                TRY.
                    ls_act-pln_mac = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw04 ) / <ls_opr>-bmsch.
                    ls_act-pln_mac_u = <ls_opr>-vge04.

                    ls_act-pln_lab = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw05 ) / <ls_opr>-bmsch.
                    ls_act-pln_lab_u = <ls_opr>-vge05.

                    ls_act-pln_pow = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw06 ) / <ls_opr>-bmsch.
                    ls_act-pln_pow_u = <ls_opr>-vge06.

                  CATCH cx_sy_arithmetic_error.
                ENDTRY.
              ENDIF.
            ENDIF.
          ELSEIF ls_order-manufacturingordercategory = '40'.
            READ TABLE lt_phase ASSIGNING FIELD-SYMBOL(<ls_phase>) WITH KEY arbid =  lv_wc_id.
            IF sy-subrc = 0.

              ls_act-pln_setup_lab = <ls_phase>-vgw01.
              ls_act-pln_setup_lab_unit = <ls_phase>-vge01.

              ls_act-pln_setup_mac = <ls_phase>-vgw02.
              ls_act-pln_setup_mac_unit = <ls_phase>-vge02.

              ls_act-pln_setup_pow = <ls_phase>-vgw03.
              ls_act-pln_setup_pow_unit = <ls_phase>-vge03.

              READ TABLE lt_mo_item INTO DATA(ls_mo_p)
                   WITH KEY manufacturingorder = ls_order-manufacturingorder.
              IF sy-subrc = 0 AND <ls_phase>-bmsch > 0.
                TRY.
                    ls_act-pln_mac = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw04 ) / <ls_phase>-bmsch.
                    ls_act-pln_mac_u = <ls_phase>-vge04.

                    ls_act-pln_lab = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw05 ) / <ls_phase>-bmsch.
                    ls_act-pln_lab_u = <ls_phase>-vge05.

                    ls_act-pln_pow = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw06 ) / <ls_phase>-bmsch.
                    ls_act-pln_pow_u = <ls_phase>-vge06.

                  CATCH cx_sy_arithmetic_error.
                ENDTRY.
              ENDIF.

            ENDIF.
          ENDIF.




          "Deviation example
          ls_act-dev_setup_lab = ls_act-pln_setup_lab - ls_act-utl_setup_lab.
          ls_act-dev_setup_mac = ls_act-pln_setup_mac - ls_act-utl_setup_mach.
          ls_act-dev_setup_pow = ls_act-pln_setup_pow - ls_act-utl_setup_pow.

          ls_act-dev_mac = ls_act-pln_mac - ls_act-utl_mach.
          ls_act-dev_lab = ls_act-pln_lab - ls_act-utl_lab.
          ls_act-dev_pow = ls_act-pln_pow - ls_act-utl_pow.

          IF ls_act-pln_setup_lab > 0.
            ls_act-dev_setup_lab_pct = ( ls_act-dev_setup_lab / ls_act-pln_setup_lab ) * 100.
          ENDIF.


          IF ls_act-pln_setup_mac > 0.
            ls_act-dev_setup_mac_pct = ( ls_act-dev_setup_mac / ls_act-pln_setup_mac ) * 100.
          ENDIF.

          IF ls_act-pln_setup_pow > 0.
            ls_act-dev_setup_pow_pct = ( ls_act-dev_setup_pow / ls_act-pln_setup_pow ) * 100.
          ENDIF.


          " LAB %
          IF ls_act-pln_lab > 0.
            ls_act-dev_lab_pct = ( ls_act-dev_lab / ls_act-pln_lab ) * 100.
          ENDIF.

          " MAC %
          IF ls_act-pln_mac > 0.
            ls_act-dev_mac_pct = ( ls_act-dev_mac / ls_act-pln_mac ) * 100.
          ENDIF.

          " POW %
          IF ls_act-pln_pow > 0.
            ls_act-dev_pow_pct = ( ls_act-dev_pow / ls_act-pln_pow ) * 100.
          ENDIF.

          APPEND ls_act TO gt_act1.
          CLEAR: ls_act, lt_opr, lt_phase, lv_wc_id.

        ENDLOOP.
      ENDLOOP.



      DATA : lo_alv2 TYPE REF TO cl_salv_table.
      IF gt_act1[] IS NOT INITIAL.
        TRY.
            cl_salv_table=>factory(
              IMPORTING r_salv_table = lo_alv2
              CHANGING  t_table      = gt_act1 ).
          CATCH cx_salv_msg.
        ENDTRY.


        DATA: lr_columns TYPE REF TO cl_salv_columns_table,
              lr_column  TYPE REF TO cl_salv_column_table.
        TRY.
            lr_columns = lo_alv2->get_columns( ).
            lr_columns->set_optimize( abap_true ).


            lr_column ?= lr_columns->get_column( 'CONF_GROUP' ).
            lr_column->set_long_text( 'Confirmation Number' ).

            lr_column ?= lr_columns->get_column( 'CONF_COUNTER' ).
            lr_column->set_long_text( 'Confirmation Counter' ).

            lr_column ?= lr_columns->get_column( 'CONF_DATE' ).
            lr_column->set_long_text( 'Confrm. Date' ).

            lr_column ?= lr_columns->get_column( 'OPERATION' ).
            lr_column->set_long_text( 'Operation / Phase Number' ).

            lr_column ?= lr_columns->get_column( 'STD_WORKCENTER' ).
            lr_column->set_long_text( 'Standard Work Center' ).

            lr_column ?= lr_columns->get_column( 'STD_SETUP_LAB' ).
            lr_column->set_long_text( 'Standard Setup Labour' ).
            lr_column ?= lr_columns->get_column( 'STD_SETUP_MAC' ).
            lr_column->set_long_text( 'Standard Setup Machine' ).
            lr_column ?= lr_columns->get_column( 'STD_SETUP_POW' ).
            lr_column->set_long_text( 'Standard Setup Power' ).

            lr_column ?= lr_columns->get_column( 'STD_LAB' ).
            lr_column->set_long_text( 'Standard Labour' ).
            lr_column ?= lr_columns->get_column( 'STD_MAC' ).
            lr_column->set_long_text( 'Standard Machine' ).
            lr_column ?= lr_columns->get_column( 'STD_POW' ).
            lr_column->set_long_text( 'Standard Power' ).

            lr_column ?= lr_columns->get_column( 'UTL_SETUP_LAB' ).
            lr_column->set_long_text( 'Utilised Setup Labour' ).
            lr_column ?= lr_columns->get_column( 'UTL_SETUP_MACH' ).
            lr_column->set_long_text( 'Utilised Setup Machine' ).
            lr_column ?= lr_columns->get_column( 'UTL_SETUP_POW' ).
            lr_column->set_long_text( 'Utilised Setup Power' ).

            lr_column ?= lr_columns->get_column( 'UTL_MACH' ).
            lr_column->set_long_text( 'Utilised Machine' ).

            lr_column ?= lr_columns->get_column( 'UTL_LAB' ).
            lr_column->set_long_text( 'Utilised Labour' ).

            lr_column ?= lr_columns->get_column( 'UTL_POW' ).
            lr_column->set_long_text( 'Utilised Power' ).


            lr_column ?= lr_columns->get_column( 'PLN_SETUP_MAC' ).
            lr_column->set_long_text( 'Planned Setup Machine' ).

            lr_column ?= lr_columns->get_column( 'PLN_SETUP_LAB' ).
            lr_column->set_long_text( 'Planned Setup Labour' ).

            lr_column ?= lr_columns->get_column( 'PLN_SETUP_POW' ).
            lr_column->set_long_text( 'Planned Setup Power' ).


            lr_column ?= lr_columns->get_column( 'PLN_MAC' ).
            lr_column->set_long_text( 'Planned Machine' ).

            lr_column ?= lr_columns->get_column( 'PLN_LAB' ).
            lr_column->set_long_text( 'Planned Labour' ).

            lr_column ?= lr_columns->get_column( 'PLN_POW' ).
            lr_column->set_long_text( 'Planned Power' ).

            lr_column ?= lr_columns->get_column( 'DEV_SETUP_LAB' ).
            lr_column->set_long_text( 'Deviation Setup Labour' ).

            lr_column ?= lr_columns->get_column( 'DEV_SETUP_MAC' ).
            lr_column->set_long_text( 'Deviation Setup Machine' ).

            lr_column ?= lr_columns->get_column( 'DEV_SETUP_POW' ).
            lr_column->set_long_text( 'Deviation Setup Power' ).


            lr_column ?= lr_columns->get_column( 'DEV_LAB' ).
            lr_column->set_long_text( 'Deviation Labour' ).

            lr_column ?= lr_columns->get_column( 'DEV_MAC' ).
            lr_column->set_long_text( 'Deviation Machine' ).

            lr_column ?= lr_columns->get_column( 'DEV_POW' ).
            lr_column->set_long_text( 'Deviation Power' ).


            lr_column ?= lr_columns->get_column( 'DEV_SETUP_LAB_PCT' ).
            lr_column->set_long_text( 'Deviation Setup Labour %' ).

            lr_column ?= lr_columns->get_column( 'DEV_SETUP_MAC_PCT' ).
            lr_column->set_long_text( 'Deviation Setup Machine %' ).

            lr_column ?= lr_columns->get_column( 'DEV_SETUP_POW_PCT' ).
            lr_column->set_long_text( 'Deviation Setup Power %' ).

            lr_column ?= lr_columns->get_column( 'DEV_LAB_PCT' ).
            lr_column->set_long_text( 'Deviation Labour %' ).

            lr_column ?= lr_columns->get_column( 'DEV_MAC_PCT' ).
            lr_column->set_long_text( 'Deviation Machine %' ).

            lr_column ?= lr_columns->get_column( 'DEV_POW_PCT' ).
            lr_column->set_long_text( 'Deviation Power %' ).

            lr_column ?= lr_columns->get_column( 'SCHED_START' ).
            lr_column->set_long_text( 'Schedule Start Date' ).

            lr_column ?= lr_columns->get_column( 'SCHED_END' ).
            lr_column->set_long_text( 'Schedule End Date' ).

            lr_column ?= lr_columns->get_column( 'REL_DATE' ).
            lr_column->set_long_text( 'Actual Release Date' ).
          CATCH cx_salv_msg.
        ENDTRY.
        DATA(lo_functions) = lo_alv2->get_functions( ).
        lo_functions->set_all( abap_true ).

        lo_alv2->display( ).


      ENDIF.
    ENDIF.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form f_matdisplay
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM f_matdisplay .

  DATA : lo_alv TYPE REF TO cl_salv_table.
  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_mat1 ).
    CATCH cx_salv_msg.
  ENDTRY.

  DATA(lo_cols) = lo_alv->get_columns( ).
  DATA: lo_col TYPE REF TO cl_salv_column.
  lo_cols->set_optimize( abap_true ).


  TRY.

      " Production Order
      lo_col = lo_cols->get_column( 'PRODUCTIONORDER' ).
      lo_col->set_long_text( 'Production Order' ).
      lo_col->set_medium_text( 'Prod Order' ).
      lo_col->set_short_text( 'Order' ).

      " Plant
      lo_col = lo_cols->get_column( 'PLANT' ).
      lo_col->set_long_text( 'Plant' ).
      lo_col->set_medium_text( 'Plant' ).
      lo_col->set_short_text( 'Plant' ).

      " Finished Material
      lo_col = lo_cols->get_column( 'FINISHED_MATERIAL' ).
      lo_col->set_long_text( 'Finished Material' ).
      lo_col->set_medium_text( 'Finished Mat.' ).
      lo_col->set_short_text( 'Material' ).

      " ✅ FIXED FIELD NAME
      lo_col = lo_cols->get_column( 'FINISHED_MATERIAL_DESC' ).
      lo_col->set_long_text( 'Finished Material Description' ).
      lo_col->set_medium_text( 'Material Desc.' ).
      lo_col->set_short_text( 'Mat Desc' ).

      " Material Group
      lo_col = lo_cols->get_column( 'MATERIAL_GROUP' ).
      lo_col->set_long_text( 'Material Group' ).
      lo_col->set_medium_text( 'Mat Group' ).
      lo_col->set_short_text( 'Grp' ).

      " Planned Quantity
      lo_col = lo_cols->get_column( 'TOTAL_QTY' ).
      lo_col->set_long_text( 'Planned Order Quantity' ).
      lo_col->set_medium_text( 'Planned Qty' ).
      lo_col->set_short_text( 'Qty' ).

      " Planned Qty UOM
      lo_col = lo_cols->get_column( 'TOTAL_QTY_UOM' ).
      lo_col->set_long_text( 'Planned Quantity Unit' ).
      lo_col->set_medium_text( 'Qty Unit' ).
      lo_col->set_short_text( 'UoM' ).

      " Material Document
      lo_col = lo_cols->get_column( 'MATERIAL_DOCUMENT' ).
      lo_col->set_long_text( 'Material Document' ).
      lo_col->set_medium_text( 'Mat Doc' ).
      lo_col->set_short_text( 'Doc' ).

      " ✅ FIXED FIELD NAME
      lo_col = lo_cols->get_column( 'MATERIAL_DOCUMENT_YEAR' ).
      lo_col->set_long_text( 'Material Document Year' ).
      lo_col->set_medium_text( 'Doc Year' ).
      lo_col->set_short_text( 'Year' ).

      " Posting Date
      lo_col = lo_cols->get_column( 'POSTING_DATE' ).
      lo_col->set_long_text( 'Posting Date' ).
      lo_col->set_medium_text( 'Post Date' ).
      lo_col->set_short_text( 'Date' ).

      " Produced Quantity
      lo_col = lo_cols->get_column( 'PRODUCED_QTY' ).
      lo_col->set_long_text( 'Material Produced Quantity' ).
      lo_col->set_medium_text( 'Produced Qty' ).
      lo_col->set_short_text( 'Prod Qty' ).

      " Produced UOM
      lo_col = lo_cols->get_column( 'PRODUCED_UOM' ).
      lo_col->set_long_text( 'Produced Quantity Unit' ).
      lo_col->set_medium_text( 'Prod Unit' ).
      lo_col->set_short_text( 'UoM' ).

      " Material Used
      lo_col = lo_cols->get_column( 'MATERIAL_USED' ).
      lo_col->set_long_text( 'Material Used' ).
      lo_col->set_medium_text( 'Used Material' ).
      lo_col->set_short_text( 'Material' ).

      " Material Used Desc
      lo_col = lo_cols->get_column( 'MATERIAL_USED_DESC' ).
      lo_col->set_long_text( 'Material Used Description' ).
      lo_col->set_medium_text( 'Material Desc.' ).
      lo_col->set_short_text( 'Mat Desc' ).

      " Used Quantity
      lo_col = lo_cols->get_column( 'USED_QTY' ).
      lo_col->set_long_text( 'Used Quantity' ).
      lo_col->set_medium_text( 'Used Qty' ).
      lo_col->set_short_text( 'Qty' ).

      " Used Qty UOM
      lo_col = lo_cols->get_column( 'USED_QTY_UOM' ).
      lo_col->set_long_text( 'Used Quantity Unit' ).
      lo_col->set_medium_text( 'Qty Unit' ).
      lo_col->set_short_text( 'UoM' ).

      " Storage Location
*          lo_col = lo_cols->get_column( 'STORAGE_LOCATION' ).
*          lo_col->set_long_text( 'Storage Location' ).
*          lo_col->set_medium_text( 'St. Loc' ).
*          lo_col->set_short_text( 'Loc' ).

      " Movement Type
      lo_col = lo_cols->get_column( 'MOVEMENT_TYPE' ).
      lo_col->set_long_text( 'Movement Type' ).
      lo_col->set_medium_text( 'MvT' ).
      lo_col->set_short_text( 'MvT' ).

      " Component Movement Type
      lo_col = lo_cols->get_column( 'COMP_MOVEMENT_TYPE' ).
      lo_col->set_long_text( 'Component Movement Type' ).
      lo_col->set_medium_text( 'Comp MvT' ).
      lo_col->set_short_text( 'MvT' ).

      " BOM Quantity
      lo_col = lo_cols->get_column( 'BOM_QTY' ).
      lo_col->set_long_text( 'BOM Quantity' ).
      lo_col->set_medium_text( 'BOM Qty' ).
      lo_col->set_short_text( 'BOM' ).

      " BOM UOM
      lo_col = lo_cols->get_column( 'BOM_UOM' ).
      lo_col->set_long_text( 'BOM Unit of Measure' ).
      lo_col->set_medium_text( 'BOM Unit' ).
      lo_col->set_short_text( 'UoM' ).

      " Deviation Quantity
      lo_col = lo_cols->get_column( 'DEVIATION_QTY' ).
      lo_col->set_long_text( 'Deviation Quantity' ).
      lo_col->set_medium_text( 'Deviation' ).
      lo_col->set_short_text( 'Dev Qty' ).

      " Deviation Percentage
      lo_col = lo_cols->get_column( 'DEVIATION_PCT' ).
      lo_col->set_long_text( 'Deviation Percentage' ).
      lo_col->set_medium_text( 'Deviation %' ).
      lo_col->set_short_text( '%' ).

      " Production Supervisor
      lo_col = lo_cols->get_column( 'PRODUCTION_SUPERVISOR' ).
      lo_col->set_long_text( 'Production Supervisor' ).
      lo_col->set_medium_text( 'Supervisor' ).
      lo_col->set_short_text( 'Supv' ).

      " Work Center
      lo_col = lo_cols->get_column( 'WORK_CENTER' ).
      lo_col->set_long_text( 'Work Center' ).
      lo_col->set_medium_text( 'Work Center' ).
      lo_col->set_short_text( 'WC' ).

    CATCH cx_salv_not_found.
  ENDTRY.

  " Enable ALL functions
  DATA(lo_functions) = lo_alv->get_functions( ).
  lo_functions->set_all( abap_true ).

  lo_alv->display( ).

ENDFORM.
*&---------------------------------------------------------------------*
*& Form f_rad2
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM f_rad2 .

  DATA : lt_opr   TYPE TABLE OF capp_opr,
         lt_phase TYPE TABLE OF capp_opr.

  SELECT a~manufacturingorder,
         a~productionplant,
         a~product,
         a~mfgorderplannedtotalqty,
         a~productionsupervisor,
         a~manufacturingordertext,
         a~mfgorderscheduledstartdate,
    a~manufacturingordercategory,
        a~mfgorderscheduledenddate,
        a~mfgorderactualreleasedate,
       a~billofoperationstype,
       a~billofoperationsgroup,
       a~billofoperationsvariant
    FROM i_manufacturingorder AS a
    INNER JOIN i_mfgorderwithstatus AS s
      ON s~manufacturingorder = a~manufacturingorder
       WHERE a~productionplant IN @s_werks
         AND a~manufacturingorder IN @s_aufnr
        AND a~productionsupervisor IN @s_fevor
         AND a~manufacturingordercategory IN ('10','40')
      AND s~orderisreleased <> ' '
      AND ( s~orderisconfirmed = ' '
      OR s~orderispartiallyconfirmed = ' '
    OR s~orderispartiallydelivered = ' ' )
*      OR s~orderisdelivered = ' '
*      OR s~orderistechnicallycompleted = ' '
*      OR s~orderisclosed = ' '
*      OR s~orderisdeleted = ' '
    INTO TABLE @DATA(lt_order).
  IF sy-subrc = 0.
    SORT lt_order.
  ELSE.
    MESSAGE 'Data Not Found!' TYPE 'E'.
  ENDIF.

  SELECT manufacturingorder,
         mfgorderitemgoodsreceiptqty
    FROM i_manufacturingorderitem
    FOR ALL ENTRIES IN @lt_order
    WHERE manufacturingorder = @lt_order-manufacturingorder
    INTO TABLE @DATA(lt_item).
  IF sy-subrc = 0.
    SORT lt_item.
  ENDIF.


  SELECT manufacturingorder,
        mfgorderconfirmationgroup,
        materialdocument,
        materialdocumentyear,
        mfgorderconfirmation,
        mfgorderconfirmationentrydate,
        manufacturingorderoperation_2,
        workcenterinternalid,
        confyieldqtyinproductionunit
   FROM i_mfgorderconfirmation
   FOR ALL ENTRIES IN @lt_order
     WHERE manufacturingorder = @lt_order-manufacturingorder
     AND mfgorderconfirmationentrydate IN @s_budat
     AND isreversed = @abap_false
     INTO TABLE @DATA(gt_conf).

  SELECT workcenterinternalid,
       workcenter
  FROM i_workcenter
  FOR ALL ENTRIES IN @gt_conf
  WHERE workcenterinternalid = @gt_conf-workcenterinternalid
  INTO TABLE @DATA(gt_workcenter).
  IF sy-subrc = 0.
    SORT gt_workcenter.
  ENDIF.


  IF p_mat = 'X'.

    TYPES: BEGIN OF ty_output,
             manufacturingorder   TYPE i_manufacturingorder-manufacturingorder,
             productionplant      TYPE i_manufacturingorder-productionplant,
             finishedmaterial     TYPE i_manufacturingorder-product,
             finishedmaterialdesc TYPE i_manufacturingorder-manufacturingordertext,
             totalqty             TYPE i_manufacturingorder-mfgorderplannedtotalqty,
             remainingqty         TYPE i_manufacturingorderitem-mfgorderitemgoodsreceiptqty,
             requiredmaterial     TYPE i_reservationitem-material,
             requiredmaterialdesc TYPE i_producttext-productname,
             totalreqqty          TYPE i_reservationitem-resvnitmrequiredqtyinbaseunit,
             remainingreqqty      TYPE i_reservationitem-resvnitmwithdrawnqtyinbaseunit,
             unit                 TYPE i_reservationitem-baseunit,
             productionsupervisor TYPE i_manufacturingorder-productionsupervisor,
           END OF ty_output.

    DATA : lt_final TYPE TABLE OF ty_output.


    SELECT referenceorder,
           material,
           resvnitmrequiredqtyinbaseunit,
           resvnitmwithdrawnqtyinbaseunit,
           baseunit
      FROM i_reservationitem
      FOR ALL ENTRIES IN @lt_order
      WHERE referenceorder = @lt_order-manufacturingorder
      INTO TABLE @DATA(lt_resv).



    SELECT product,
           productname
      FROM i_producttext
      FOR ALL ENTRIES IN @lt_resv
      WHERE product  = @lt_resv-material
        AND language = @sy-langu
      INTO TABLE @DATA(lt_mattext).



    LOOP AT lt_order INTO DATA(ls_order).

      READ TABLE lt_item INTO DATA(ls_item)
           WITH KEY manufacturingorder = ls_order-manufacturingorder.

      LOOP AT lt_resv INTO DATA(ls_resv)
           WHERE referenceorder = ls_order-manufacturingorder.

        READ TABLE lt_mattext INTO DATA(ls_text)
             WITH KEY product = ls_resv-material.

        READ TABLE gt_conf into DATA(ls_conf)
        WITH KEY manufacturingorder = ls_order-manufacturingorder.

        APPEND VALUE ty_output(
           manufacturingorder   = ls_order-manufacturingorder
           productionplant      = ls_order-productionplant
           finishedmaterial     = ls_order-product
           finishedmaterialdesc = ls_order-manufacturingordertext
           totalqty             = ls_order-mfgorderplannedtotalqty
           remainingqty         = ls_item-mfgorderitemgoodsreceiptqty
*           COND #(
*                           WHEN ls_item-mfgorderitemgoodsreceiptqty IS NOT INITIAL
*                           THEN ls_item-mfgorderitemgoodsreceiptqty
*                           ELSE ls_conf-confyieldqtyinproductionunit

           requiredmaterial     = ls_resv-material
           requiredmaterialdesc = ls_text-productname
           totalreqqty          = ls_resv-resvnitmrequiredqtyinbaseunit
           remainingreqqty      = ls_resv-resvnitmrequiredqtyinbaseunit - ls_resv-resvnitmwithdrawnqtyinbaseunit
           unit                 = ls_resv-baseunit
           productionsupervisor = ls_order-productionsupervisor
        ) TO lt_final.

      ENDLOOP.
    ENDLOOP.

    DATA: lo_alv  TYPE REF TO cl_salv_table,
          lo_cols TYPE REF TO cl_salv_columns_table,
          lo_col  TYPE REF TO cl_salv_column_table,
          lo_disp TYPE REF TO cl_salv_display_settings,
          lo_func TYPE REF TO cl_salv_functions_list.

    TRY.
        cl_salv_table=>factory(
          IMPORTING
            r_salv_table = lo_alv
          CHANGING
            t_table      = lt_final
        ).
      CATCH cx_salv_msg.
        MESSAGE 'Error creating ALV' TYPE 'E'.
    ENDTRY.

    lo_func = lo_alv->get_functions( ).
    lo_func->set_all( abap_true ).

    lo_cols = lo_alv->get_columns( ).
    lo_cols->set_optimize( abap_true ).
    lo_alv->display( ).


  ELSEIF p_act = 'X'.  "Activity

    TYPES: BEGIN OF ty_act2,

             manufacturingorder TYPE aufnr,
             plant              TYPE werks_d,
             product            TYPE matnr,
             product_text       TYPE maktx,
             order_qty          TYPE menge_d,
             remain_qty         TYPE menge_d,
             workcenter         TYPE arbpl,

             pln_setup_lab      TYPE p DECIMALS 3,
             pln_setup_lab_unit TYPE afru-ile01,
             pln_setup_mac      TYPE p DECIMALS 3,
             pln_setup_mac_unit TYPE afru-ile01,
             pln_setup_pow      TYPE p DECIMALS 3,
             pln_setup_pow_unit TYPE afru-ile01,

             pln_mac            TYPE p DECIMALS 3,
             pln_mac_u          TYPE afru-ile01,
             pln_lab            TYPE p DECIMALS 3,
             pln_lab_u          TYPE afru-ile01,
             pln_pow            TYPE p DECIMALS 3,
             pln_pow_u          TYPE afru-ile01,

             prod_supervisor    TYPE char12,
             sched_start        TYPE datum,
             sched_end          TYPE datum,
             rel_date           TYPE datum,

             mach_tim           TYPE p DECIMALS 2,
             lab_tim            TYPE p DECIMALS 2,
             pow_tim            TYPE p DECIMALS 2,

           END OF ty_act2.

    DATA : lt_act2 TYPE TABLE OF ty_act2,
           ls_act  TYPE ty_act2.
**
**    SELECT a~manufacturingorder,
**          a~productionplant,
**          a~product,
**          a~mfgorderplannedtotalqty,
**          a~productionsupervisor,
**          a~manufacturingordertext
**     FROM i_manufacturingorder AS a
**     INNER JOIN i_mfgorderwithstatus AS s
**       ON s~manufacturingorder = a~manufacturingorder
**     WHERE a~productionplant IN @s_werks
**       AND a~manufacturingordercategory IN ('10','40')
**       AND s~orderisreleased <> ' '
**       AND s~orderisconfirmed = ' '
**       AND s~orderispartiallyconfirmed = ' '
**       AND s~orderisdelivered = ' '
**       AND s~orderistechnicallycompleted = ' '
**       AND s~orderisclosed = ' '
**       AND s~orderisdeleted = ' '
**      INTO TABLE @DATA(lt_ord_act).
**    IF sy-subrc = 0.
**      SORT lt_ord_act.
**    ENDIF.
**
**    SELECT
**      manufacturingorder,
***      mfgorderplannedqty,
**      mfgorderitemgoodsreceiptqty
**    FROM i_manufacturingorderitem
**    FOR ALL ENTRIES IN @lt_ord_act
**    WHERE manufacturingorder = @lt_ord_act-manufacturingorder
**    INTO TABLE @data(lt_ord_item).
**      IF sy-subrc = 0.
**        Sort lt_ord_item.
**      ENDIF.


    LOOP AT lt_order INTO DATA(ls_ord).

      ls_act-manufacturingorder = ls_ord-manufacturingorder.
      ls_act-plant              = ls_ord-productionplant.
      ls_act-product            = ls_ord-product.
      ls_act-product_text       = ls_ord-manufacturingordertext.
      ls_act-order_qty          = ls_ord-mfgorderplannedtotalqty.
      ls_act-prod_supervisor    = ls_ord-productionsupervisor.
      ls_act-sched_start        = ls_ord-mfgorderscheduledstartdate.
      ls_act-sched_end          = ls_ord-mfgorderscheduledenddate.
      ls_act-rel_date           = ls_ord-mfgorderactualreleasedate.

      READ TABLE gt_conf ASSIGNING FIELD-SYMBOL(<fs_conf>) WITH KEY manufacturingorder = ls_ord-manufacturingorder.
      IF sy-subrc = 0.
        READ TABLE gt_workcenter ASSIGNING FIELD-SYMBOL(<fs_wc>) WITH KEY workcenterinternalid = <fs_conf>-workcenterinternalid.
        IF sy-subrc = 0.
          ls_act-workcenter = <fs_wc>-workcenter.
        ENDIF.
      ENDIF.

      "Planned

      CALL FUNCTION 'CARO_ROUTING_READ'
        EXPORTING
*         DATE_FROM    = '19000101'
*         DATE_TO      = '99991231'
          plnty        = ls_ord-billofoperationstype
          plnnr        = ls_ord-billofoperationsgroup
          plnal        = ls_ord-billofoperationsvariant
*         MATNR        =
*         BUFFER_DEL_FLG             = 'X'
*         DELETE_ALL_CAL_FLG         = 'X'
*         ADAPT_FLG    = 'X'
*         IV_CREATE_ADD_CHANGE       = ' '
*         WERKS        =
        TABLES
*         TSK_TAB      =
*         SEQ_TAB      =
          opr_tab      = lt_opr
          phase_tab    = lt_phase
*         SUBOPR_TAB   =
*         REL_TAB      =
*         COM_TAB      =
*         REFERR_TAB   =
*         REFMIS_TAB   =
*         IT_AENR      =
        EXCEPTIONS
          not_found    = 1
          ref_not_exp  = 2
          not_valid    = 3
          no_authority = 4
          OTHERS       = 5.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.
      IF ls_ord-manufacturingordercategory = '10'.

        READ TABLE lt_opr ASSIGNING FIELD-SYMBOL(<ls_opr>) INDEX 1.
        IF sy-subrc = 0.
          ls_act-pln_setup_lab = <ls_opr>-vgw01.
          ls_act-pln_setup_lab_unit = <ls_opr>-vge01.

          ls_act-pln_setup_mac = <ls_opr>-vgw02.
          ls_act-pln_setup_mac_unit = <ls_opr>-vge02.

          ls_act-pln_setup_pow = <ls_opr>-vgw03.
          ls_act-pln_setup_pow_unit = <ls_opr>-vge03.

          READ TABLE lt_item INTO DATA(ls_mo)
               WITH KEY manufacturingorder = ls_order-manufacturingorder.
          IF sy-subrc = 0 AND <ls_opr>-bmsch > 0.
            TRY.
                ls_act-pln_mac = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw04 ) / <ls_opr>-bmsch.
                ls_act-pln_mac_u = <ls_opr>-vge04.

                ls_act-pln_lab = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw05 ) / <ls_opr>-bmsch.
                ls_act-pln_lab_u = <ls_opr>-vge05.

                ls_act-pln_pow = ( ls_mo-mfgorderitemgoodsreceiptqty * <ls_opr>-vgw06 ) / <ls_opr>-bmsch.
                ls_act-pln_pow_u = <ls_opr>-vge06.

              CATCH cx_sy_arithmetic_error.
            ENDTRY.
          ENDIF.
        ENDIF.
      ELSEIF ls_ord-manufacturingordercategory = '40'.
        READ TABLE lt_phase ASSIGNING FIELD-SYMBOL(<ls_phase>) INDEX 1.
        IF sy-subrc = 0.

          ls_act-pln_setup_lab = <ls_phase>-vgw01.
          ls_act-pln_setup_lab_unit = <ls_phase>-vge01.

          ls_act-pln_setup_mac = <ls_phase>-vgw02.
          ls_act-pln_setup_mac_unit = <ls_phase>-vge02.

          ls_act-pln_setup_pow = <ls_phase>-vgw03.
          ls_act-pln_setup_pow_unit = <ls_phase>-vge03.

          READ TABLE lt_item INTO DATA(ls_mo_p)
               WITH KEY manufacturingorder = ls_order-manufacturingorder.
          IF sy-subrc = 0 AND <ls_phase>-bmsch > 0.
            TRY.
                ls_act-pln_mac = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw04 ) / <ls_phase>-bmsch.
                ls_act-pln_mac_u = <ls_phase>-vge04.

                ls_act-pln_lab = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw05 ) / <ls_phase>-bmsch.
                ls_act-pln_lab_u = <ls_phase>-vge05.

                ls_act-pln_pow = ( ls_mo_p-mfgorderitemgoodsreceiptqty * <ls_phase>-vgw06 ) / <ls_phase>-bmsch.
                ls_act-pln_pow_u = <ls_phase>-vge06.

              CATCH cx_sy_arithmetic_error.
            ENDTRY.
          ENDIF.

        ENDIF.
      ENDIF.
      IF ls_act-order_qty > 0.
        ls_act-mach_tim = ls_act-pln_mac / ls_act-order_qty.
        ls_act-lab_tim = ls_act-pln_lab / ls_act-order_qty.
        ls_act-pow_tim = ls_act-pln_pow / ls_act-order_qty.
      ENDIF.

      APPEND ls_act TO lt_act2.
      CLEAR: ls_act, lt_opr, lt_phase.
    ENDLOOP.

    DATA : lo_act TYPE REF TO cl_salv_table.

    IF lt_act2[] IS NOT INITIAL.
      TRY.
          cl_salv_table=>factory(
            IMPORTING r_salv_table = lo_act
            CHANGING  t_table      = lt_act2 ).
        CATCH cx_salv_msg.
      ENDTRY.
    ENDIF.

    DATA: lr_columns TYPE REF TO cl_salv_columns_table,
          lr_column  TYPE REF TO cl_salv_column_table.

    TRY.
        lr_columns = lo_act->get_columns( ).
        lr_columns->set_optimize( abap_true ).

        lr_column ?= lr_columns->get_column( 'PLN_SETUP_MAC' ).
        lr_column->set_long_text( 'Planned Setup Machine' ).

        lr_column ?= lr_columns->get_column( 'PLN_SETUP_LAB' ).
        lr_column->set_long_text( 'Planned Setup Labour' ).

        lr_column ?= lr_columns->get_column( 'PLN_SETUP_POW' ).
        lr_column->set_long_text( 'Planned Setup Power' ).


        lr_column ?= lr_columns->get_column( 'PLN_MAC' ).
        lr_column->set_long_text( 'Planned Machine' ).

        lr_column ?= lr_columns->get_column( 'PLN_LAB' ).
        lr_column->set_long_text( 'Planned Labour' ).

        lr_column ?= lr_columns->get_column( 'PLN_POW' ).
        lr_column->set_long_text( 'Planned Power' ).


        lr_column ?= lr_columns->get_column( 'SCHED_START' ).
        lr_column->set_long_text( 'Schedule Start Date' ).

        lr_column ?= lr_columns->get_column( 'SCHED_END' ).
        lr_column->set_long_text( 'Schedule End Date' ).

        lr_column ?= lr_columns->get_column( 'REL_DATE' ).
        lr_column->set_long_text( 'Actual Release Date' ).

        lr_column ?= lr_columns->get_column( 'MACH_TIM' ).
        lr_column->set_long_text( 'Machine time/Unit' ).

        lr_column ?= lr_columns->get_column( 'LAB_TIM' ).
        lr_column->set_long_text( 'Labour time/Unit' ).

        lr_column ?= lr_columns->get_column( 'POW_TIM' ).
        lr_column->set_long_text( 'Power time/Unit' ).


        DATA(lo_functions) = lo_act->get_functions( ).
        lo_functions->set_all( abap_true ).

        lo_act->display( ).
      CATCH cx_salv_msg.
    ENDTRY.

  ENDIF.
ENDFORM.
