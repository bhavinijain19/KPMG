*&---------------------------------------------------------------------*
*& Include          ZPP_IP_UPLOAD_TOP
*&---------------------------------------------------------------------*

TYPES : BEGIN OF ty_file_ip,
          material         TYPE matnr,                              " Material
          activity         TYPE vornr,                              " Activity
          control_key      TYPE steus,                              " Control Key
          plant            TYPE werks_d,                            " Plant
          description      TYPE kltxt,                              " Operation Short Text
          valid_from       TYPE char10,                             " Valid From DD.MM.YYYY
          task_list_usage  TYPE verwe,                              " Task List Usage
          task_list_status TYPE bapi1191_tsk_c-task_list_status,    " Task List Status
          task_list_uom    TYPE bapi1191_tsk_c-task_measure_unit,   " Task List UoM
          inspchar         TYPE qmerknrp,                           " Inspection Characteristic Number
          mstr_char        TYPE bapi1191_cha_c-mstr_char,           " MIC
          char_descr       TYPE qkurztext,                          " MIC Description
          method           TYPE bapi1191_cha_c-method,              " Inspection Method
          pmethod          TYPE bapi1191_cha_c-pmethod,             " Inspection Method Plan
          smpl_procedure   TYPE bapi1191_cha_c-smpl_procedure,      " Sampling Procedure
          dec_places       TYPE qstellen,                           " Decimal Place
          meas_unit        TYPE bapi1191_cha_c-meas_unit,           " Characteristics UoM
          target_val       TYPE bapi1191_cha_c-target_val,          " Target Value
          lw_tol_lmt       TYPE bapi1191_cha_c-lw_tol_lmt,          " Lower Tolerance Limit
          up_tol_lmt       TYPE bapi1191_cha_c-up_tol_lmt,          " Upper Tolerance Limit
          sel_set1         TYPE bapi1191_cha_c-sel_set1,            " Selected Set Code
          formula          TYPE bapi1191_cha_c-formula_field_1,     " Formula
        END OF ty_file_ip.

TYPES: BEGIN OF ty_log.
         INCLUDE TYPE ty_file_ip.
TYPES:   msgty   TYPE bapi_mtype,
         message TYPE string,
       END OF ty_log.

DATA: it_file TYPE TABLE OF ty_file_ip,
      wa_file TYPE ty_file_ip,
      t_log   TYPE TABLE OF ty_log,
      w_log   TYPE ty_log.

DATA: gt_raw     TYPE solix_tab,
      gv_bin_len TYPE i.

DATA: lt_task      TYPE STANDARD TABLE OF bapi1191_tsk_c,
      ls_task      TYPE bapi1191_tsk_c,
      lt_alloc     TYPE TABLE OF bapi1191_mtk_c,
      ls_alloc     TYPE bapi1191_mtk_c,
      lt_operation TYPE STANDARD TABLE OF bapi1191_opr_c,
      ls_operation TYPE bapi1191_opr_c,
      lt_char      TYPE STANDARD TABLE OF bapi1191_cha_c,
      ls_char      TYPE bapi1191_cha_c,
      lt_return    TYPE STANDARD TABLE OF bapiret2.
