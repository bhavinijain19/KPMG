*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_REASONTOP.                    " Global Data
  INCLUDE LZPP_REASONUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_REASONF...                    " Subroutines
* INCLUDE LZPP_REASONO...                    " PBO-Modules
* INCLUDE LZPP_REASONI...                    " PAI-Modules
* INCLUDE LZPP_REASONE...                    " Events
* INCLUDE LZPP_REASONP...                    " Local class implement.
* INCLUDE LZPP_REASONT99.                    " ABAP Unit tests
  INCLUDE LZPP_REASONF00                          . " subprograms
  INCLUDE LZPP_REASONI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
