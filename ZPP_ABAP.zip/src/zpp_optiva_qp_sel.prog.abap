*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_QP_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
PARAMETERS:p_file  TYPE rlgrap-filename." OBLIGATORY.
*           p_file1 TYPE rlgrap-filename OBLIGATORY, " Download FileName
*           p_mode  LIKE ctu_params-dismode DEFAULT 'A'.         " Mode .

PARAMETERS : v_rcl RADIOBUTTON GROUP rad2.
PARAMETERS : v_p RADIOBUTTON GROUP rad2.
PARAMETERS : c_excel AS CHECKBOX  .
SELECTION-SCREEN:END OF BLOCK a1.
