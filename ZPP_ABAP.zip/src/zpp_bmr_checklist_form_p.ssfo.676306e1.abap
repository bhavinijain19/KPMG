******************begin of ATC changes 13/02/26   UDAYABAP03*************
*SELECT SINGLE *
*  FROM afko
*  INTO @DATA(ls_afko)
*  WHERE aufnr = @aufnr_imp.
SELECT  *
  FROM afko UP TO 1 ROWS
  INTO @DATA(ls_afko)
  WHERE aufnr = @aufnr_imp ORDER BY PRIMARY KEY.
  ENDSELECT.

IF ls_afko IS NOT INITIAL.
*  SELECT SINGLE plnty,
*                plnnr,
*                plnkn,
*                zaehl,
*                arbid
*    FROM plpo
*    INTO @DATA(ls_plpo)
*    WHERE plnty = @ls_afko-plnty
*      AND plnnr = @ls_afko-plnnr
*      AND zaehl = @ls_afko-plnal.

  SELECT plnty,
         plnnr,
         plnkn,
         zaehl,
         arbid
    FROM plpo UP TO 1 ROWS
    INTO @DATA(ls_plpo)
    WHERE plnty = @ls_afko-plnty
      AND plnnr = @ls_afko-plnnr
      AND zaehl = @ls_afko-plnal ORDER BY PRIMARY KEY.
    ENDSELECT.
ENDIF.
******************end of ATC changes 13/02/26   UDAYABAP03*************
IF ls_plpo IS NOT INITIAL.
  SELECT SINGLE arbpl
      FROM crhd
      INTO lv_arbpl
      WHERE objty = 'A' AND objid = ls_plpo-arbid.
ENDIF.

IF lv_arbpl IS NOT INITIAL.
  SELECT SINGLE ktext
          FROM crtx
          INTO lv_ktext
          WHERE objty = 'A' AND objid = ls_plpo-arbid.
ENDIF.







































