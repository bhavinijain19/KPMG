*&---------------------------------------------------------------------*
*& Report  ZPP_INSPECTION_PLAN_UPLOAD
*&----------------------------------------------------------------------------*
*& Title: Inspection Plan Upload
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Cummins Infosystems Ltd, Pune
*& Functional Consultant : Sanjay Sahoo, KPIT Cummins Infosystems Ltd, Pune
*& Report Creation Date  : 07/10/2014
*& Transaction Code      :
*& Request Number        : DEVK900290
*&----------------------------------------------------------------------------*
REPORT zpp_inspection_plan_upload.

TYPES : BEGIN OF ty_data,
          steus(4),
          matnr(18),
          vornr(04),
*          arbpl(8), "Changed by UDAYABAP03 on 30.03.2026
          werks(4),
          sttag(10),
          verwe(3),
          statu(10),
          ltxa1(40),
          verwmerkm(8),          """""""""
          insptext(40),
          mkversion(5),          """""""""
          pmethode(8),
          pmtversion(6),
          stichprver(8),
          spckrit(3),
          stellen(3),
          masseinhsw(6),
          sollwert(16),
          toleranzun(16),
          toleranzob(16),
          selected_set(8),
          sequence_no(1),
        END OF ty_data.
DATA : it_data       TYPE TABLE OF ty_data,
       wa_data       TYPE ty_data,
       ls_data       TYPE ty_data,
       v_count       TYPE entry_act,
       count         TYPE char16,
       entry_act     TYPE entry_act, " VALUE 16,
       ls_v_count(2),
       v_field(50),
       flag.
DATA : ls_meins TYPE meins.
INCLUDE zbdcrecx1.
PARAMETERS : p_file  TYPE rlgrap-filename,
             p_plnal TYPE plnal DEFAULT '1' OBLIGATORY.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
*     FIELD_NAME    = ' '
    IMPORTING
      file_name     = p_file.



START-OF-SELECTION.
  PERFORM upload.
  PERFORM bdc.

*perform open_group.


*&---------------------------------------------------------------------*
*&      Form  UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload .
  DATA : vf_start_col TYPE i VALUE '1',      "start column
         vf_start_row TYPE i VALUE '2',      "start row
         vf_end_col   TYPE i VALUE '120',    "maximum column
         vf_end_row   TYPE i VALUE '10000'.  "maximum row
  DATA : it_excel TYPE  kcde_cells OCCURS 0 WITH HEADER LINE.
  DATA : vf_index TYPE i,
         " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*          v_index  TYPE char02.
         v_index  TYPE char2.
  " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
  FIELD-SYMBOLS : <fs>.
  CALL FUNCTION 'KCD_EXCEL_OLE_TO_INT_CONVERT'
    EXPORTING
      filename                = p_file
      i_begin_col             = vf_start_col
      i_begin_row             = vf_start_row
      i_end_col               = vf_end_col
      i_end_row               = vf_end_row
    TABLES
      intern                  = it_excel
    EXCEPTIONS
      inconsistent_parameters = 1
      upload_ole              = 2
      OTHERS                  = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


  SORT it_excel BY row col.
  LOOP AT it_excel.
    MOVE : it_excel-col TO vf_index.
    ASSIGN COMPONENT vf_index OF STRUCTURE wa_data TO <fs>.
    MOVE : it_excel-value TO <fs>.
    AT END OF row.
      APPEND wa_data TO it_data.
      CLEAR wa_data.
    ENDAT.
  ENDLOOP.


ENDFORM.                    " UPLOAD
*&---------------------------------------------------------------------*
*&      Form  BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc .
  LOOP AT it_data INTO wa_data.
    v_count = v_count + 1.
    ls_v_count = v_count.
    MOVE-CORRESPONDING wa_data TO ls_data.

    AT NEW matnr.
      PERFORM bdc_dynpro      USING 'SAPLCPDI' '8010'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'RC271-STTAG'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'RC27M-MATNR'
                                    ls_data-matnr."                              'RM01001029'.
      PERFORM bdc_field       USING 'RC271-PLNNR'
                                    ' ' ."                              'RM01001029'.
      PERFORM bdc_field       USING 'RC27M-WERKS'
                                    ls_data-werks."                              '1000'.
      PERFORM bdc_field       USING 'RC271-STTAG'
                                    ls_data-sttag."                              '01.09.2012'.


      PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'PLKOD-PLNAL'
                                    p_plnal.
*perform bdc_field       using 'PLKOD-KTEXT'
*                              'SAG BOLT YOKE YR9'.
*perform bdc_field       using 'PLKOD-WERKS'
*                              '1000'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLKOD-LOSVN'.
      PERFORM bdc_field       USING 'PLKOD-VERWE'
                                     ls_data-verwe."                             '5'.
      PERFORM bdc_field       USING 'PLKOD-STATU'
                                     ls_data-statu."                             '4'.
      PERFORM bdc_field       USING 'PLKOD-VAGRP'
                                    ''.
      PERFORM bdc_field       USING 'PLKOD-LOSVN'
                                    '0'.  "Changed by UDAYABAP03 on 30.03.2026
      PERFORM bdc_field       USING 'PLKOD-LOSBS'
                                    '99,999,999'.
      SELECT SINGLE meins FROM mara INTO ls_meins WHERE matnr EQ ls_data-matnr.
      CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
        EXPORTING
          input    = ls_meins
          language = sy-langu
        IMPORTING
*         LONG_TEXT            =
          output   = ls_meins
*         SHORT_TEXT           =
*         EXCEPTIONS
*         UNIT_NOT_FOUND       = 1
*         OTHERS   = 2
        .
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      PERFORM bdc_field       USING 'PLKOD-PLNME'
                                    ls_meins."                                                 'NOS'.


      PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=VOUE'.
**perform bdc_field       using 'PLKOD-KTEXT'
**                              'SAG BOLT YOKE YR9'.
**perform bdc_field       using 'PLKOD-WERKS'
**                              '1000'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLKOD-LOSVN'.
*perform bdc_field       using 'PLKOD-VERWE'
*                                                                  '5'.
*perform bdc_field       using 'PLKOD-STATU'
*                                                                  '4'.
*perform bdc_field       using 'PLKOD-LOSVN'
*                              '1'.
*perform bdc_field       using 'PLKOD-LOSBS'
*                              '99,999,999'.
*perform bdc_field       using 'PLKOD-PLNME'
*                              'NOS'.


      PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLPOD-LTXA1(01)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'PLPOD-VORNR(01)'
                                    ls_data-vornr."                                   'QA_LAB'.
      "Changed by UDAYABAP03 on 30.03.2026
**      PERFORM bdc_field       USING 'PLPOD-ARBPL(01)'
**                                    ls_data-arbpl."
      "Changed by UDAYABAP03 on 30.03.2026                                       'QA_LAB'.
      PERFORM bdc_field       USING 'PLPOD-STEUS(01)'
                                    ls_data-steus."                                   'QM01'.
      PERFORM bdc_field       USING 'PLPOD-LTXA1(01)'
                                    ls_data-ltxa1."                                   'Inspection'.


      PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLPOD-VORNR(01)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=QMUE'.
      PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                    '1'.
      PERFORM bdc_field       USING 'RC27X-FLG_SEL(01)'
                                    'X'.
    ENDAT.

    IF v_count EQ 14 AND flag IS INITIAL .
      flag = 'X'.
      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
      count = count + ( v_count - 1 ).
      CONDENSE count.
      PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                    count ."'13'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      ls_v_count = 2.
      v_count = 2.
    ELSEIF v_count EQ 14 AND flag IS NOT INITIAL.
      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
      count = count + ( v_count - 2 ).
      CONDENSE count.
      PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                     count ."'13'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      ls_v_count = 2.
      v_count = 2.
    ENDIF.
*    IF v_count MOD 14 EQ 0 OR flag EQ 'X'.
*      flag = 'X'.
*      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
*      PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
*                                     '13'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
**    entry_act = entry_act + 1.
*      IF v_count EQ 14.
*        CLEAR v_count.
*        ls_v_count = 02.
*        v_count = 1.
*      ENDIF.
*    ENDIF.

    PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'PLMKB-STICHPRVER(01)'.
*    if v_count mod 17 eq 0.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                   16.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    ls_v_count = '02'.
*    v_count = 2.
*    else.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
*    endif.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    endif.
*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
    CONCATENATE 'PLMKB-VERWMERKM(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING  v_field                       "'PLMKB-VERWMERKM(01)'
                                   ls_data-verwmerkm."                              'MIS'.
    CLEAR v_field.
    IF ls_data-insptext IS NOT INITIAL.
      CONCATENATE 'PLMKB-KURZTEXT(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                       "'PLMKB-VERWMERKM(01)'
                                     ls_data-insptext."                              'MIS'.
      CLEAR : v_field.
    ENDIF.
    CONCATENATE 'PLMKB-MKVERSION(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING  v_field                      " 'PLMKB-MKVERSION(01)'
                                   ls_data-mkversion."                              '1'.
*    concatenate 'PLMKB-KURZTEXT(' ls_v_count ')' into v_field.
*    perform bdc_field       using v_field                       "'PLMKB-KURZTEXT(01)'
*                                                                 'DIE MISMATCH'.
*    clear v_field.
    CONCATENATE 'PLMKB-PMETHODE(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING  v_field                 "'PLMKB-PMETHODE(01)'
                                   ls_data-pmethode."                               'DVC'.
    CLEAR v_field.
    CONCATENATE 'PLMKB-PMTVERSION(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING  v_field                   "'PLMKB-PMTVERSION(01)'
                                   ls_data-pmtversion."                              '1'.

    CLEAR v_field.
    CONCATENATE 'PLMKB-STICHPRVER(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING  v_field                   "'PLMKB-STICHPRVER(01)'
                                   ls_data-stichprver."                              'RPDSS'.
*abhishek on 07062014
    CLEAR v_field.
    CONCATENATE 'PLMKB-SPCKRIT(' ls_v_count ')' INTO v_field.
    PERFORM bdc_field       USING v_field                                               "'PLMKB-SPCKRIT(01)'
                                  ls_data-spckrit.
*abhishek on 07062014

    CLEAR v_field.





    PERFORM bdc_dynpro      USING 'SAPLQPAA' '1501'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ENT1'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-VERWMERKM'.
*perform bdc_field       using 'PLMKB-VERWMERKM'
*                              'MIS'.
*perform bdc_field       using 'PLMKB-QPMK_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-MKVERSION'
*                              '1'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.


    PERFORM bdc_dynpro      USING 'SAPLQPAA' '1502'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.


    PERFORM bdc_dynpro      USING 'SAPLQPAA' '1502'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ENT1'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.



*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
**    perform bdc_field       using 'BDC_CURSOR'
**                                  'PLMKB-MERKNR(01)'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '=QMNM'.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                  '1'.
*    concatenate 'RQPAS-SEL_FLG(' ls_v_count ')' into v_field.
*    perform bdc_field       using  v_field                        "'RQPAS-SEL_FLG(01)'
*                                  'X'.
*    clear v_field.
    IF ls_data-stellen IS NOT INITIAL.

      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0160'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
*    perform bdc_field       using 'PLMKB-KURZTEXT'
*                                  'DIE MISMATCH'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLMKB-STELLEN'.
      PERFORM bdc_field       USING 'PLMKB-STELLEN'
                                    ls_data-stellen."              '2'.
      PERFORM bdc_field       USING 'RQPAS-MASSEINHSW'
                                    ls_data-masseinhsw."           'mm'.

      "Changed by UDAYABAP03 on 30.03.2026
      IF ls_data-sollwert IS NOT INITIAL.
        PERFORM bdc_field       USING 'QFLTP-SOLLWERT'
                                       ls_data-sollwert."                            '5.50'.
      ENDIF.
      IF  ls_data-toleranzun IS NOT INITIAL .
        PERFORM bdc_field       USING 'QFLTP-TOLERANZUN'
                                      ls_data-toleranzun."
      ENDIF.

      IF ls_data-toleranzob IS NOT INITIAL.
        PERFORM bdc_field       USING 'QFLTP-TOLERANZOB'
                                      ls_data-toleranzob."           '            0.50'.
      ENDIF.

      "Changed by UDAYABAP03 on 30.03.2026

    ENDIF.

    IF ls_data-sequence_no EQ '2'.

      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0160'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'PLMKB-AUSWMENGE1'
                                    ls_data-selected_set.
      PERFORM bdc_field       USING 'PLMKB-AUSWMGWRK1'
                                    ls_data-werks.
    ENDIF.
*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-MERKNR(01)'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                  '1'.
*    concatenate 'RQPAS-SEL_FLG(' ls_v_count ')' into v_field.
*    perform bdc_field       using  v_field                        "'RQPAS-SEL_FLG(01)'
*                                  ' '.
*    clear v_field.


*perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-STICHPRVER(02)'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '/00'.
*perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                              '1'.
*perform bdc_field       using 'PLMKB-VERWMERKM(02)'
*                              'DA1'.
*perform bdc_field       using 'PLMKB-MKVERSION(02)'
*                              '1'.
*perform bdc_field       using 'PLMKB-KURZTEXT(02)'
*                              'dIAMETER'.
*perform bdc_field       using 'PLMKB-PMETHODE(02)'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-PMTVERSION(02)'
*                              '1'.
*perform bdc_field       using 'PLMKB-STICHPRVER(02)'
*                              'RPDSS'.
*perform bdc_field       using 'RQPAS-SEL_FLG(01)'
*                              ''.
*perform bdc_field       using 'RQPAS-SEL_FLG(02)'
*                              'X'.
*perform bdc_dynpro      using 'SAPLQPAA' '1501'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-VERWMERKM'.
*perform bdc_field       using 'PLMKB-VERWMERKM'
*                              'DA1'.
*perform bdc_field       using 'PLMKB-QPMK_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-MKVERSION'
*                              '1'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '1502'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '1502'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-MERKNR(02)'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=QMNM'.
*perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                              '1'.
*perform bdc_field       using 'RQPAS-SEL_FLG(02)'
*                              'X'.
*perform bdc_dynpro      using 'SAPLQPAA' '0160'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=QMBW'.
*perform bdc_field       using 'PLMKB-KURZTEXT'
*                              'dIAMETER'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'QFLTP-TOLERANZUN'.
*perform bdc_field       using 'PLMKB-STELLEN'
*                              '2'.
*perform bdc_field       using 'RQPAS-MASSEINHSW'
*                              'mm'.
*perform bdc_field       using 'QFLTP-TOLERANZUN'
*                              '           21.60'.
*perform bdc_field       using 'QFLTP-TOLERANZOB'
*                              '           22.70'.

*Dnyanesh on 25/06/14\
*    IF ls_v_count = 13.
*      v_count = 1.
*      CLEAR ls_v_count.
*    PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=P+'.
*    ENDIF.
*Dnyanesh on 25/06/14



    AT END OF matnr.
      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'QFLTP-TOLERANZUN(01)'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=QMBU'.
      PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                    '1'.
      PERFORM bdc_transaction USING 'QP01'.
      CLEAR : ls_v_count,v_count,flag.
    ENDAT.

*************************************************************Save
*    at end of steus.
*      perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*      perform bdc_field       using 'BDC_CURSOR'
*                                    'PLMKB-PRUEFEINH(01)'.
*      perform bdc_field       using 'BDC_OKCODE'
*                                    '=QMBU'.
*      perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                    '1'.
*      perform bdc_transaction using 'QP01'.
*    endat.
*************************************************************
    CLEAR :wa_data.
  ENDLOOP.
*perform close_group.
ENDFORM.                    " BDC


*CTUMODE  Processing Mode
*CUPDATE  Update mode
*P_FILE	File name

*text element
*S05  Processing Mode
*S06  Update
