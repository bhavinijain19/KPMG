*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_BOM_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
*PARAMETERS:p_file  TYPE rlgrap-filename." OBLIGATORY.
*           p_file1 TYPE rlgrap-filename OBLIGATORY, " Download FileName
*           p_mode  LIKE ctu_params-dismode DEFAULT 'A'.         " Mode .
PARAMETERS : v_rcl RADIOBUTTON GROUP rad2.
PARAMETERS : v_p RADIOBUTTON GROUP rad2.
PARAMETERS : c_excel AS CHECKBOX  .
SELECTION-SCREEN:END OF BLOCK a1.

*AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
*  CALL FUNCTION 'WS_FILENAME_GET'
*    EXPORTING
*      def_filename     = space
*      def_path         = space
*      mask             = ',*.*,*.*.'
*      mode             = space
*      title            = space
*    IMPORTING
*      filename         = p_file
**     RC               =
*    EXCEPTIONS
*      inv_winsys       = 1
*      no_batch         = 2
*      selection_cancel = 3
*      selection_error  = 4
*      OTHERS           = 5.
*  IF sy-subrc <> 0 AND sy-subrc <> 3.
*    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
*  ENDIF.
