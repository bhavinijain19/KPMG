*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_FM_SU_GEN_NEWTOP.             " Global Declarations
  INCLUDE LZWM_FM_SU_GEN_NEWUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_FM_SU_GEN_NEWF...             " Subroutines
* INCLUDE LZWM_FM_SU_GEN_NEWO...             " PBO-Modules
* INCLUDE LZWM_FM_SU_GEN_NEWI...             " PAI-Modules
* INCLUDE LZWM_FM_SU_GEN_NEWE...             " Events
* INCLUDE LZWM_FM_SU_GEN_NEWP...             " Local class implement.
* INCLUDE LZWM_FM_SU_GEN_NEWT99.             " ABAP Unit tests
