*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_QP_TOP
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_BOM_TOP
*&---------------------------------------------------------------------*

DATA : ftp_handle       TYPE i,
       ftp_rfc_dest_aux LIKE rfcdes-rfcdest VALUE 'SAPFTPA',
       ftp_command(120) TYPE c,
       ftp_result       TYPE sdoki_ftp_result_t,
       pwd(30)          TYPE c,
       key              TYPE i VALUE 26101957,
       slen             TYPE i.
CONSTANTS   : c_tvarvc_matcre  TYPE rvari_vnam VALUE 'ZMM_OPTIVA_PATH'.
CONSTANTS : c_tvarvc_user TYPE rvari_vnam VALUE 'BARCODE_USER'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_pwd TYPE rvari_vnam VALUE 'BARCODE_PWD'.   "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_host TYPE rvari_vnam VALUE 'BARCODE_HOST'. "Using it from ZMM_MAT_DATA report
CONSTANTS : c_tvarvc_dest TYPE rvari_vnam VALUE 'BARCODE_DEST'. "Using it from ZMM_MAT_DATA report

CONSTANTS:
 c_tvarvc_name TYPE rvari_vnam VALUE 'OPTIVA_QP'.
CONSTANTS:
c_tvarvc_name1 TYPE rvari_vnam VALUE 'OPTIVA_QP_DELE'.

CONSTANTS:
c_tvarvc_name2 TYPE rvari_vnam VALUE 'OPTIVA_QP_MAIL'.



CONSTANTS:
 pc_tvarvc_name TYPE rvari_vnam VALUE 'POPTIVA_QP'.        "Added by Raj on 17.01.2025
CONSTANTS:
pc_tvarvc_name1 TYPE rvari_vnam VALUE 'POPTIVA_QP_DELE'.

CONSTANTS:
pc_tvarvc_name2 TYPE rvari_vnam VALUE 'POPTIVA_QP_MAIL'.



DATA: bcode_user TYPE char200.
DATA: bcode_pwd TYPE char200.
DATA: bcode_host TYPE char200.
DATA: bcode_dest TYPE char200.

DATA: matcre_path(500).

DATA: l_user(30) TYPE c, "VALUE 'APTLSFTP', "user name of ftp server
      l_pwd(30)  TYPE c, "VALUE 'Astral123', "password of ftp server
      l_host(64) TYPE c, "VALUE '192.168.54.74', "ip address of FTP server
      l_dest     LIKE rfcdes-rfcdest.
DATA: w_hdl  TYPE i,
      c_key  TYPE i VALUE 26101957,
      l_slen TYPE i.

DATA: BEGIN OF itab_tmp OCCURS 1,
        line(600)             ,
      END OF itab_tmp       .


"""""XML Read"""""

DATA: gcl_xml       TYPE REF TO cl_xml_document.

TYPES : BEGIN OF ty_files,
          appsrv_fname TYPE localfile, " rlgrap-filename,
        END   OF ty_files.

DATA: t_file_list TYPE TABLE OF epsfili WITH HEADER LINE,
      t_files     TYPE TABLE OF ty_files WITH HEADER LINE.

DATA: wrk_file1    LIKE epsf-epsdirnam,
      wrk_file2    LIKE epsf-epsdirnam,
      wrk_email    LIKE epsf-epsdirnam,
      lv_filename1 TYPE rcgfiletr-ftappl,
      lv_string    TYPE text4096.

DATA: gv_subrc      TYPE sy-subrc.

DATA: gv_xml_string TYPE string.

DATA: wrk_qp_email TYPE adr6-smtp_addr.

TYPES: BEGIN OF ty_final,
         value TYPE string,
       END OF ty_final.
DATA: lt_final TYPE TABLE OF ty_final,
      ls_final TYPE ty_final.

TYPES: BEGIN OF ty_xml,

         raw(2000) TYPE c,

       END OF ty_xml.

*      Declaring the XML internal table

DATA:  g_t_xml_tab TYPE TABLE OF ty_xml INITIAL SIZE 0.
DATA:  wa_xml_tab TYPE ty_xml.
DATA:  g_xmldata TYPE xstring.
DATA:  g_t_xml_info TYPE TABLE OF smum_xmltb INITIAL SIZE 0.
DATA: gwa_xml_data  TYPE smum_xmltb.
DATA:  g_t_return TYPE STANDARD TABLE OF bapiret2.


"""""""XML DATA""""""""
TYPES: BEGIN OF ty_final1,
         item_code_matno(20),  "Material Number
         yeild_baseqty(20),     "Base Quantity
         c_effictive_from(10),
         attrib_val_plant(20),    "Plant
         """"line items
         item_code_bom_bomcomp(20), "BOM Component
         quantity(20),           "Base Quantity
         uom_code_comp_unit_of_measure(20),   "Component unit of measure
         attribute1_bom_usage(20),   "Bom_Usage
         attribute2_alt_bom(20),    "Alternative BOM
         attribute3_change_no(20),  "CHange Number
         attribute4_bom_status(20),  "BOM Status
         attribute5_item_cat(20),    ""Item category (bill of material)
         attribute6_sort_string(20),  "Sort String
         attribute7_item_no(20),      "Item Number
         attribute8_comp_scrap(20),    "Component scrap in percent
         attribute9_sel_indctr(20),   "Selection indicator
         attribute10_co_product(20),  "co_product
         attribute11_sel_indctr(20),   ""Selection indicator
         attribute12_indct_costing(20),  "Indicator for Relevancy to Costing
       END OF ty_final1.

DATA: lt_final1 TYPE TABLE OF ty_final1,
      ls_final1 TYPE ty_final1.

DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.

DATA:    p_mode    TYPE ctu_params-dismode VALUE 'N'.
DATA  : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

"""""""Mail Sending

DATA : lo_mime_helper TYPE REF TO cl_gbt_multirelated_service,
       lo_bcs         TYPE REF TO cl_bcs,
       sender         TYPE REF TO cl_cam_address_bcs, "Added by Rahul Vasita on 08.04.2024 17:21:10
       lo_doc_bcs     TYPE REF TO cl_document_bcs,
       lo_recipient   TYPE REF TO if_recipient_bcs,
       lt_soli        TYPE TABLE OF soli,
       ls_soli        TYPE soli,
       lv_status      TYPE bcs_rqst.



""""""""""QT Upload Program Declaration"""""""""


TYPES : BEGIN OF ty_data,
          steus(4),
          matnr(18),
          vornr(04),
          arbpl(8),
          werks(4),
          matnrwerks(22),
          sttag(10),
          verwe(3),
          statu(10),
          ltxa1(40),
          verwmerkm(8),          """""""""
          insptext(40),
          mkversion(6),          """""""""
          pmethode(8),
          pmtversion(6),
          stichprver(8),
          spckrit(3),
          stellen(3),
          masseinhsw(6),
          sollwert(16),
          toleranzun(16),
          toleranzob(16),
          selected_set(8),
          sequence_no(1),
          flg(1)          TYPE c, "Added by Rahul Vasita on 21.05.2024 15:29:32
        END OF ty_data.

DATA : it_data TYPE TABLE OF ty_data,
       wa_data TYPE ty_data,
       ls_data TYPE ty_data.



DATA: v_count       TYPE entry_act,
      count         TYPE char16,
      entry_act     TYPE entry_act, " VALUE 16,
      ls_v_count(2),
      p_plnal       TYPE plnal,
*        p_plnal TYPE plnal VALUE '1',
      flag,
      v_field(50).

DATA : ls_meins TYPE meins.

""""""""""""Declaration End

"""""""Mail Sending


TYPES : BEGIN OF t_message ,
*           lifnr   TYPE char10  , " Customer Number
          status  TYPE char4   , " Light Indicator
          vendor  TYPE char15,
          type    TYPE char4   , " Error Type
          message TYPE char255 , " Message Description
        END OF t_message    .

DATA: i_message   TYPE STANDARD TABLE OF t_message.
DATA: i_message1  TYPE STANDARD TABLE OF t_message.

FIELD-SYMBOLS :
  <x_message>  TYPE t_message,
  <x_message1> TYPE t_message.
DATA : ls_log TYPE zpp_optiva_qp. "Added by Rahul Vasita on 22.03.2024 14:46:47
DATA : lv_werks TYPE werks_d. "Added by Rahul Vasita on 03.04.2024 16:26:40
DATA : lv_email TYPE adr6-smtp_addr. "Added by Rahul Vasita on 09.04.2024 10:01:13
DATA : lv_uflag(1) TYPE c. "Added by Rahul Vasita on 21.05.2024 15:56:29
TYPES : BEGIN OF ty_qpmk,
          zaehler    TYPE qpmk-zaehler,
          mkmnr      TYPE qpmk-mkmnr,
          version    TYPE qpmk-version,
          steuerkz   TYPE qpmk-steuerkz,
          stellen    TYPE qpmk-stellen,
          masseinhsw TYPE qpmk-masseinhsw,
        END OF ty_qpmk,
        BEGIN OF ty_maillog,
          filename  TYPE localfile,
          indic(1)  TYPE c,
          f_indc(1) TYPE c,
          werks     TYPE werks_d,
          mic       TYPE char10,
        END OF ty_maillog.
DATA : lt_qpmk    TYPE TABLE OF ty_qpmk,
       ls_qpmk    TYPE ty_qpmk,
       lt_maillog TYPE TABLE OF ty_maillog,
       ls_maillog TYPE ty_maillog.
