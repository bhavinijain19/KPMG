*&---------------------------------------------------------------------*
*&  Include           ZPP_QP02_BOM_DEL_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  IF p_rb1 = abap_true.
    SELECT matnr
           werks
      FROM mapl
      INTO TABLE lt_metadata
      WHERE werks IN s_werks
        AND plnty = 'Q'
        AND loekz = abap_false
        AND parkz = abap_false
        AND aedat <= p_aedat.
  ELSEIF p_rb2 = abap_true.
    SELECT matnr
           werks
      FROM mapl
      INTO TABLE lt_metadata
      WHERE werks IN s_werks
        AND plnty = 'Q'
        AND loekz = abap_false
        AND parkz = abap_false
        AND aedat = p_aedat.
  ENDIF.

  SORT lt_metadata BY matnr werks.

  IF p_rb1 = abap_true.
    IF lt_metadata[] IS NOT INITIAL.
      SELECT matnr
             werks
             plnty
             plnnr
             plnal
             zkriz
             zaehl
             loekz
             aedat
             lifnr   "Added by Rutvi on 04.09.2024
        FROM mapl
        INTO  CORRESPONDING FIELDS OF TABLE lt_mapl
        FOR ALL ENTRIES IN lt_metadata
        WHERE matnr = lt_metadata-matnr
          AND werks = lt_metadata-werks
          AND plnty = 'Q'
          AND loekz = abap_false
          AND parkz = abap_false.
    ENDIF."IF lt_metadata[] is NOT INITIAL.
*        AND aedat = p_aedat.
  ELSEIF p_rb2 = abap_true.
    IF lt_metadata[] IS NOT INITIAL.
      SELECT matnr
             werks
             plnty
             plnnr
             plnal
             zkriz
             zaehl
             loekz
             aedat
             lifnr   "Added by Rutvi on 04.09.2024
        FROM mapl
        INTO  CORRESPONDING FIELDS OF TABLE lt_mapl
        FOR ALL ENTRIES IN lt_metadata
        WHERE matnr = lt_metadata-matnr
          AND werks = lt_metadata-werks
          AND plnty = 'Q'
          AND loekz = abap_false
          AND parkz = abap_false.
*        AND aedat = p_aedat.
    ENDIF."IF lt_metadata[] IS NOT INITIAL.
  ENDIF.

  SORT lt_mapl BY matnr werks.
  IF lt_mapl[] IS NOT INITIAL.
    SELECT a~plnty,
           a~plnnr,
           a~plnkn,
           a~zaehl,
           a~loekz,
           b~andat,
           b~verwe,
           b~statu
      FROM plpo AS a
      INNER JOIN plko AS b ON ( a~plnty = b~plnty AND a~plnnr = b~plnnr AND a~zaehl = b~zaehl )
      INTO TABLE @DATA(lt_plpo)
      FOR ALL ENTRIES IN @lt_mapl
      WHERE a~plnty = @lt_mapl-plnty
        AND a~plnnr = @lt_mapl-plnnr
        AND a~zaehl = @lt_mapl-zaehl.
  ENDIF."IF lt_mapl[] IS NOT INITIAL.
*  IF lt_plpo[] IS NOT INITIAL.
*    SELECT plnty,
*           plnnr,
*           plnal,
*           zaehl,
*           verwe,
*           statu
*      FROM plko
*      INTO TABLE @DATA(lt_plko)
*      FOR ALL ENTRIES IN @lt_plpo
*      WHERE plnty = @lt_plpo-plnty
*        AND plnnr = @lt_plpo-plnnr.
*  ENDIF.
  SORT lt_plpo BY plnty plnnr plnkn zaehl.
  REFRESH: lt_final[].
  LOOP AT lt_mapl INTO ls_mapl.
    DATA(ls_plpo) = VALUE #( lt_plpo[ plnty = ls_mapl-plnty plnnr = ls_mapl-plnnr zaehl = ls_mapl-zaehl ] OPTIONAL ).
    IF ls_plpo IS NOT INITIAL.
      ls_final-matnr = ls_mapl-matnr.
      ls_final-werks = ls_mapl-werks.
      ls_final-plnty = ls_plpo-plnty.
      ls_final-plnnr = ls_plpo-plnnr.
      ls_final-plnal = ls_mapl-plnal.
      ls_final-zkriz = ls_mapl-zkriz.
      ls_final-zaehl = ls_plpo-zaehl.
      ls_final-loekz = ls_plpo-loekz.
      ls_final-verwe = ls_plpo-verwe.
      ls_final-statu = ls_plpo-statu.
      ls_final-andat = ls_plpo-andat.
      ls_final-lifnr = ls_mapl-lifnr.   "Added by Rutvi on 04.09.2024
**      ls_final-key = ls_mapl-matnr && ls_plpo-plnnr." && ls_final-verwe && ls_final-statu." && ls_final-andat. "Comment by Rahul Vasita on 25.07.2024 10:48:46
**      ls_final-key = ls_mapl-matnr && ls_plpo-plnnr && ls_final-verwe && ls_final-statu && ls_final-andat && ls_final-zaehl. "Comment by Rahul Vasita on 25.07.2024 10:48:48
      ls_final-key = ls_mapl-matnr && ls_plpo-plnnr && ls_final-verwe && ls_final-statu && ls_final-andat && ls_final-zaehl. "Added by Rahul Vasita on 25.07.2024 10:48:48
      IF ls_final-verwe = '9'.
        ls_final-p_95 = '2'.
      ELSE.
        ls_final-p_95 = '1'.
      ENDIF.
      CONDENSE : ls_final-key.

      APPEND ls_final TO lt_final.
      CLEAR: ls_final.
    ENDIF."End of LS_PLPO
    CLEAR: ls_plpo , ls_mapl.
  ENDLOOP.

  SORT lt_final BY key zaehl.
  DATA(lt_final_copy) = lt_final[].     "Added by Rahul Vasita on 21.06.2024 14:01:01
  SORT lt_final_copy ASCENDING BY matnr p_95 lifnr zaehl DESCENDING. "Added by Rahul Vasita on 21.06.2024 14:01:35
  DELETE ADJACENT DUPLICATES FROM lt_final_copy COMPARING matnr p_95 lifnr. "Added by Rahul Vasita on 21.06.2024 14:02:56

  DATA: lv_plnty TYPE plpo-plnty,
        lv_plnnr TYPE plpo-plnnr,
        lv_zaehl TYPE plpo-zaehl,
        lv_verwe TYPE plko-verwe,
        lv_date  TYPE datum,
        lv_statu TYPE plko-statu.

  IF p_rb1 = abap_true.
    LOOP AT lt_final_copy INTO DATA(ls_copy).
      LOOP AT lt_final ASSIGNING FIELD-SYMBOL(<ls>) WHERE matnr = ls_copy-matnr AND andat = ls_copy-andat AND p_95 = ls_copy-p_95
                                                      AND zaehl = ls_copy-zaehl.
        <ls>-indic = abap_true.
      ENDLOOP.
    ENDLOOP.
  ELSE.
    LOOP AT lt_final_copy INTO ls_copy.
      LOOP AT lt_final ASSIGNING <ls> WHERE matnr = ls_copy-matnr  AND andat = ls_copy-andat AND p_95 = ls_copy-p_95
                                          AND zaehl = ls_copy-zaehl.
        <ls>-indic = abap_true.
      ENDLOOP.
    ENDLOOP.
  ENDIF."IF p_rb1 = abap_true.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRCOESS_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM prcoess_data .
  DATA : lv_date     TYPE char10,
         lv_index    TYPE sy-tabix,
         lv_totcnt   TYPE i,
         lv_msg(255) TYPE c,
         lv_field    TYPE char20,
         lv_count    TYPE i VALUE 0,
         lv_ent(2)   TYPE c.
*  CLEAR: lv_totcnt.
*  SORT lt_mapl DESCENDING BY plnal.
*  lv_count = VALUE #( lt_mapl[ 1 ]-plnal ).
  SORT lt_final BY zaehl.
  DESCRIBE TABLE lt_final LINES lv_totcnt.
  IF lt_final[] IS NOT INITIAL.

    DATA(lr_matnr) = VALUE rsdsselopt_t(
    FOR ls_final1 IN lt_final
      ( sign =  if_fsbp_const_range=>sign_include
        option = if_fsbp_const_range=>option_equal
        low = ls_final1-matnr ) ).

    SORT lr_matnr BY low.
    DELETE ADJACENT DUPLICATES FROM lr_matnr COMPARING low.

    LOOP AT lr_matnr INTO DATA(ls_matnr).

      LOOP AT lt_final ASSIGNING FIELD-SYMBOL(<ls_final>) WHERE matnr = ls_matnr-low."INTO ls_final.
        lv_count = lv_count + 1.
        lv_ent   = lv_count.
        CONDENSE lv_ent.
**      IF <ls_final>-indic = abap_true. "Comment by Rahul Vasita on 29.07.2024 17:09:44
**        CLEAR: lv_count. "Comment by Rahul Vasita on 29.07.2024 17:09:47
**      ELSE. "Comment by Rahul Vasita on 29.07.2024 17:09:49
*      CLEAR lv_index.
**      ENDIF."Comment by Rahul Vasita on 29.07.2024 17:09:51
*      lv_index = sy-tabix.
        IF <ls_final>-indic <> abap_true AND <ls_final>-loekz = abap_false.
*      IF lv_index < lv_totcnt AND <ls_final>-loekz = abap_false.

          PERFORM bdc_dynpro      USING 'SAPLCPDI' '8010'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'RC27M-WERKS'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'RC27M-MATNR'
                                        <ls_final>-matnr.
          PERFORM bdc_field       USING 'RC27M-WERKS'
                                        <ls_final>-werks.
          PERFORM bdc_field       USING 'RC271-PLNNR'
                                        <ls_final>-plnnr.
          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'RC27X-ENTRY_ACT'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                         lv_ent."'1'.
          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'PLKOD-PLNAL(10)'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=ALD1'.
          PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                        '1'.
          lv_field = |RC27X-FLG_SEL({ lv_count })|.
          PERFORM bdc_field       USING 'RC27X-FLG_SEL(01)'"lv_field
                                        abap_true.
          PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BU'.

          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'PLKOD-DELKZ'.
          PERFORM bdc_field       USING 'PLKOD-DELKZ'
                                         abap_true.

          CALL TRANSACTION 'QP02' USING bdcdata MODE p_mode MESSAGES INTO messtab.
          IF sy-subrc = 0.
            WAIT UP TO 5 SECONDS.
            <ls_final>-msg = 'Deletion Indicator Added SuccessFully'.
          ELSE.
            LOOP AT messtab INTO ls_msgtab WHERE msgtyp = 'E'.
              CALL FUNCTION 'FORMAT_MESSAGE'
                EXPORTING
                  id        = ls_msgtab-msgid
                  lang      = sy-langu
                  no        = ls_msgtab-msgnr
                  v1        = ls_msgtab-msgv1
                  v2        = ls_msgtab-msgv2
                  v3        = ls_msgtab-msgv3
                  v4        = ls_msgtab-msgv4
                IMPORTING
                  msg       = lv_msg
                EXCEPTIONS
                  not_found = 1
                  OTHERS    = 2.
              IF sy-subrc <> 0.
* Implement suitable error handling here
              ENDIF.
              CONCATENATE <ls_final>-msg lv_msg INTO <ls_final>-msg SEPARATED BY ' '.
              CLEAR: ls_msgtab , lv_msg.
            ENDLOOP.
            APPEND LINES OF messtab TO lt_msgtab.
          ENDIF.
        ENDIF."IF ls_final-plnal < lv_count.
        REFRESH bdcdata[].
*      CLEAR : ls_final.
      ENDLOOP.
      CLEAR: ls_matnr , lv_count.
    ENDLOOP.

  ENDIF.

**  cl_demo_output=>display( lt_msgtab[] ).

ENDFORM.
*----------------------------------------------------------------------*
*        Start new screen                                              *
*----------------------------------------------------------------------*
FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.
  IF fval <> abap_false.
    CLEAR bdcdata.
    bdcdata-fnam = fnam.
    bdcdata-fval = fval.
    APPEND bdcdata.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .
  DATA lv_colpos TYPE i VALUE 0.
  REFRESH : lt_fieldcat[],lt_header[].
  CLEAR : ls_layout , ls_variant.
  DEFINE fieldcat.
    lv_colpos = lv_colpos + 1.
    ls_fieldcat-col_pos = lv_colpos.
    ls_fieldcat-fieldname = &1.
    ls_fieldcat-seltext_l = &2.
    ls_fieldcat-outputlen = &3.

    APPEND ls_fieldcat TO lt_fieldcat.
    CLEAR ls_fieldcat.
  END-OF-DEFINITION.
  CLEAR : lv_colpos.
  fieldcat: 'MATNR' 'Material No' '10'.
  fieldcat: 'WERKS' 'PLANT CODE' '10'.
  fieldcat: 'PLNAL' 'GROUP COUNTER' '10'.
  fieldcat: 'VERWE' 'USAGE' '10'.
  fieldcat: 'STATU' 'STATUS' '10'.
  fieldcat: 'ANDAT' 'CREATION DATE' '10'.
  fieldcat: 'MSG' 'STATUS_MESSAGE' '50'.



  ls_layout-zebra = 'X'.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page = 'TOP-OF-PAGE'
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
    TABLES
      t_outtab           = lt_final[].
ENDFORM.
