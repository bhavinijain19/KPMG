*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_CUST_FIELDSTOP.               " Global Declarations
  INCLUDE LZPP_CUST_FIELDSUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_CUST_FIELDSF...               " Subroutines
* INCLUDE LZPP_CUST_FIELDSO...               " PBO-Modules
* INCLUDE LZPP_CUST_FIELDSI...               " PAI-Modules
* INCLUDE LZPP_CUST_FIELDSE...               " Events
* INCLUDE LZPP_CUST_FIELDSP...               " Local class implement.
* INCLUDE LZPP_CUST_FIELDST99.               " ABAP Unit tests
  INCLUDE LZPP_CUST_FIELDSF00                     . " subprograms
  INCLUDE LZPP_CUST_FIELDSI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
