*&---------------------------------------------------------------------*
*& Include          ZBDC_QS31_TOP
*&---------------------------------------------------------------------*
TYPES: BEGIN OF  ty_file,
         name(25) TYPE  c,
       END OF   ty_file.

TYPES: BEGIN OF ty_final,
         plant       TYPE string,
         insp_method TYPE string,
         valid_from  TYPE string,
         status      TYPE string,
         short_dis   TYPE string,
         serch_field TYPE string,
       END OF ty_final.
TYPES:BEGIN OF ty_error,
        mesg_type TYPE c,
        message   TYPE string,
      END OF ty_error.
DATA: it_file  TYPE TABLE OF ty_file,
      it_final TYPE TABLE OF ty_final,
      wa_file  TYPE ty_file,
      wa_final TYPE ty_final.

CONSTANTS:c_x TYPE c VALUE 'X'.
DATA:wa_bdcdata TYPE bdcdata,
     wa_messtab TYPE bdcmsgcoll.
DATA:it_bdcdata TYPE TABLE OF bdcdata,
     it_messtab TYPE TABLE OF bdcmsgcoll.
DATA:t_raw TYPE truxs_t_text_data.
DATA:lv_count(5) TYPE c.
DATA gs_ctu_params TYPE ctu_params.
DATA:wa_error TYPE ty_error,
     it_error TYPE TABLE OF ty_error,
     v_msg    TYPE string.
DATA:wa_fcat   TYPE slis_fieldcat_alv,
     it_fcat   TYPE slis_t_fieldcat_alv,
     wa_layout TYPE slis_layout_alv.
