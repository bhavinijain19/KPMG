*&----------------------------------------------------------------------------*
*& Report  ZPP_PRODUCTION_VER
*&----------------------------------------------------------------------------*
*& Title: Production Version Master
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Cummins Infosystems Ltd, Pune
*& Functional Consultant : Sanjay Sahoo, KPIT Cummins Infosystems Ltd, Pune
*& Report Creation Date  : 10/10/2014
*& Transaction Code      :
*& Request Number        : DEVK900374
*&----------------------------------------------------------------------------*

REPORT zpp_production_ver.


TYPE-POOLS : slis.
TYPE-POOLS : truxs.

TYPES : BEGIN OF st_final,
 " mandt(03)," TYPE mandt,                         "Client
  matnr(18)," TYPE matnr,                         "Material Number
  werks(04)," TYPE werks_d,                       "Plant
  verid(04)," TYPE verid,                         "Production Version
  bdatu(10)," TYPE char10,                         "Run-time end: production version
  adatu(10)," TYPE char10,                         "Valid-from date of production version
  stlal(02)," TYPE stalt,                         "Alternative BOM
  stlan(01)," TYPE stlan,                         "BOM Usage
  plnty(01)," TYPE plnty,                         "Task List Type
  plnnr(08)," TYPE plnnr,                         "Key for Task List Group
  alnal(02)," TYPE plnal,                         "Group Counter
  text1(40)," TYPE vers_text,                     "Short text on the production version
  bstmi(17)," TYPE sa_losvn,                      "Lower value of the lot-size interval
  bstma(17)," TYPE bstma,                         "Upper value of the lot-size interval
  mdv01(08),"Production line
  END OF st_final.

DATA : it_final TYPE TABLE OF st_final,
       wa_final TYPE st_final.

DATA : cnt TYPE i,
       wa_mkal TYPE mkal.

DATA : it_tbl   TYPE STANDARD TABLE OF mkal,
       wa_tbl   TYPE mkal,
       it_mkalu TYPE STANDARD TABLE OF mkal,
       it_mkald TYPE STANDARD TABLE OF mkal,
       it_mkala TYPE STANDARD TABLE OF mkal_aend.

DATA : i_temp   TYPE truxs_t_text_data.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS: p_uname LIKE rlgrap-filename OBLIGATORY.
"Upload File Name
SELECTION-SCREEN END OF BLOCK b1.


AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_uname.
  PERFORM file_get_name USING p_uname.

*======================================================================*
*                  S T A R T - O F - S E L E C T I O N                 *
*======================================================================*
START-OF-SELECTION.
* To read the upload file into an internal table

  PERFORM read_file.
  PERFORM map_data.
  PERFORM call_bapi.
*&---------------------------------------------------------------------*
*&      Form  READ_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM read_file .
  DATA : lstr_file TYPE string.
***
***  lstr_file = p_uname.
***
**** Function module to read the upload file into an internal table
***
***  CALL FUNCTION 'GUI_UPLOAD'
***    EXPORTING
***      filename                = lstr_file
***      filetype                = 'ASC'
***      has_field_separator     = 'X'
***    TABLES
***      data_tab                = git_final1
***    EXCEPTIONS
***      file_open_error         = 1
***      file_read_error         = 2
***      no_batch                = 3
***      gui_refuse_filetransfer = 4
***      invalid_type            = 5
***      no_authority            = 6
***      unknown_error           = 7
***      bad_data_format         = 8
***      header_not_allowed      = 9
***      separator_not_allowed   = 10
***      header_too_long         = 11
***      unknown_dp_error        = 12
***      access_denied           = 13
***      dp_out_of_memory        = 14
***      disk_full               = 15
***      dp_timeout              = 16
***      OTHERS                  = 17.
***  IF sy-subrc <> 0.
***    MESSAGE e021(zmm_msg).
***  ENDIF.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = i_temp
      i_filename           = p_uname
    TABLES
      i_tab_converted_data = it_final.

"DELETE it_final INDEX 1.
ENDFORM.                    " READ_FILE
*&---------------------------------------------------------------------*
*&      Form  FILE_GET_NAME
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_UNAME  text
*----------------------------------------------------------------------*
FORM file_get_name  USING  filename TYPE rlgrap-filename.
*get the file name along with the path from desktop

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      static        = 'X'
    CHANGING
      file_name     = filename      "file name along with the path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
    MESSAGE e022(zmm_msg) WITH filename.
  ENDIF.

ENDFORM.                    " FILE_GET_NAME
*&---------------------------------------------------------------------*
*&      Form  MAP_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM map_data .
  SORT it_final BY matnr verid.
  DELETE ADJACENT DUPLICATES FROM it_final COMPARING matnr verid werks.

  IF sy-subrc EQ 0.
    MESSAGE : 'Duplicate Entries In File' TYPE 'E'.
  ENDIF.
  LOOP AT it_final INTO wa_final.
    SELECT SINGLE * FROM mkal
      INTO CORRESPONDING FIELDS OF wa_mkal
      WHERE matnr EQ wa_final-matnr
      AND verid EQ wa_final-verid
      AND werks EQ wa_final-werks.

    IF sy-subrc EQ 0.
      MESSAGE : 'Entry Already Created' TYPE 'E'.
    ENDIF.
  "  wa_tbl-mandt  = wa_final-mandt.
    wa_tbl-matnr  = wa_final-matnr.
    wa_tbl-werks  = wa_final-werks.
    wa_tbl-verid  = wa_final-verid.
    PERFORM f_convert_date_internal USING wa_final-bdatu CHANGING wa_tbl-bdatu.
    PERFORM f_convert_date_internal USING wa_final-adatu CHANGING wa_tbl-adatu.

*    wa_tbl-bdatu  = wa_final-bdatu.
*    wa_tbl-adatu  = wa_final-adatu.
    wa_tbl-stlal  = wa_final-stlal.
    wa_tbl-stlan  = wa_final-stlan.
    wa_tbl-plnty  = wa_final-plnty.
    wa_tbl-plnnr  = wa_final-plnnr.
    wa_tbl-alnal  = wa_final-alnal.
    wa_tbl-text1  = wa_final-text1.
    wa_tbl-bstmi  = wa_final-bstmi.
    wa_tbl-bstma  = wa_final-bstma.
    wa_tbl-prfg_f = '1'.
    wa_tbl-prdat      = sy-datum.
    wa_tbl-prfg_s = '1'.
    "dj
    wa_tbl-mdv01 = wa_final-mdv01.
    APPEND wa_tbl TO it_tbl.
    CLEAR : wa_tbl,wa_final.
  ENDLOOP.
ENDFORM.                    " MAP_DATA
*&---------------------------------------------------------------------*
*&      Form  CALL_BAPI
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM call_bapi .
  CALL FUNCTION 'CM_FV_PROD_VERS_DB_UPDATE'
    TABLES
      it_mkal_i    = it_tbl
      it_mkal_u    = it_mkalu
      it_mkal_d    = it_mkald
      it_mkal_aend = it_mkala.

  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
    EXPORTING
      wait = 'X'.
  MESSAGE : 'Data Uploaded Successfully' TYPE 'S'.
ENDFORM.                    " CALL_BAPI
*&---------------------------------------------------------------------*
*&      Form  F_CONVERT_DATE_INTERNAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_WA_MAIN_GWLDT_I  text
*      <--P_WA_ITOB_GWLDT  text
*----------------------------------------------------------------------*
FORM f_convert_date_internal  USING    p_ext
                              CHANGING p_int.
  DATA: lv_date_i TYPE string,
        lv_date_e TYPE string.

  lv_date_e = p_ext.

CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
  EXPORTING
    date_external                  = lv_date_e
   accept_initial_date             = 'X'
 IMPORTING
   date_internal                   = lv_date_i
* EXCEPTIONS
*   DATE_EXTERNAL_IS_INVALID       = 1
*   OTHERS                         = 2
          .
IF sy-subrc = 0.
 p_int = lv_date_i.
ENDIF.


ENDFORM.                    " F_CONVERT_DATE_INTERNAL
