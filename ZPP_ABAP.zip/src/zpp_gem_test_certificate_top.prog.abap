*&---------------------------------------------------------------------*
*&  Include           ZPP_TEST_CERTIFICATE_TOP
*&---------------------------------------------------------------------*

TYPE-POOLS : slis.

TYPES : BEGIN OF ty_final,
          kurztext        TYPE qamv-kurztext,
          toleranzob      TYPE qamv-toleranzob,
          toleranzun      TYPE qamv-toleranzun,
          sortfeld        TYPE qmtb-sortfeld,
          original_input  TYPE qamr-pruefbemkt,
          prueflos        TYPE qplos,
          merknr          TYPE qamr-merknr,
          masseinhsw      TYPE msehl,
          toleranzun1     TYPE  string,
          toleranzob1     TYPE  string,
          toleranzun2     TYPE string,
          toleranzun3     TYPE string,
          original_input1 TYPE string, "Added by Raj on 20.09.2023
        END OF ty_final.

TYPES : BEGIN OF ty_fin,
          parta          TYPE char1,
          partb          TYPE char1,
          other          TYPE char1,
          kurztext       TYPE qamv-kurztext,
          toleranzob     TYPE qamv-toleranzob,
          toleranzun     TYPE qamv-toleranzun,
          sortfeld       TYPE qmtb-sortfeld,
          original_input TYPE qamr-pruefbemkt,
          prueflos       TYPE qplos,
          merknr         TYPE qamr-merknr,
          masseinhsw     TYPE msehl,
          toleranzun1    TYPE  string,
          toleranzob1    TYPE  string,
          toleranzun2    TYPE string,
          toleranzun3    TYPE string,
*          original_input1 TYPE string, "Added by Raj on 20.09.2023
        END OF ty_fin.

TYPES : BEGIN OF ty_fin1,
          parta          TYPE char1,
          kurztext       TYPE qamv-kurztext,
          toleranzob     TYPE qamv-toleranzob,
          toleranzun     TYPE qamv-toleranzun,
          sortfeld       TYPE qmtb-sortfeld,
          original_input TYPE qamr-pruefbemkt,
          merknr         TYPE qamr-merknr,
          masseinhsw     TYPE msehl,
          toleranzun1    TYPE  string,
          toleranzob1    TYPE  string,
          toleranzun2    TYPE string,
          toleranzun3    TYPE string,
*          original_input1 TYPE string, "Added by Raj on 20.09.2023
        END OF ty_fin1.

DATA : wa_header TYPE zpp_test_certificate.


DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE                   ty_final.

DATA : lt_final TYPE STANDARD TABLE OF ty_fin,
       ls_final TYPE                   ty_fin.

DATA : lt_fin TYPE STANDARD TABLE OF ty_fin1,
       ls_fin TYPE                   ty_fin1.


TYPES : BEGIN OF ty_final1,
          prueflos       TYPE qamr-prueflos,
          merknr         TYPE qamr-merknr,
          gruppe1        TYPE qamr-gruppe1,
          code1          TYPE qamr-code1,
          original_input TYPE qamr-pruefbemkt,
          kurztext       TYPE qpct-kurztext,
          kurztext1(30),
        END OF ty_final1.

DATA : it_final1 TYPE TABLE OF ty_final1,
       wa_final1 TYPE          ty_final1.

TYPES: BEGIN OF ty_mseg,
         mblnr TYPE mseg-mblnr,
         mjahr TYPE mseg-mjahr,
         matnr TYPE mseg-matnr,
         werks TYPE mseg-werks,
         charg TYPE mseg-charg,
         meins TYPE mseg-meins,
       END OF ty_mseg.

DATA : it_mseg TYPE STANDARD TABLE OF ty_mseg,
       wa_mseg TYPE ty_mseg,
       gt_mseg TYPE STANDARD TABLE OF ty_mseg,
       gs_mseg TYPE ty_mseg.

DATA : lv_output TYPE mseh3,
       lv_stext  TYPE mseht,
       lv_ltext  TYPE msehl,
       gv_matnr  TYPE qals-matnr,
       gv_charg  TYPE qals-charg,
       gv_maktx  TYPE makt-maktx.

DATA : it_fieldcat   TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       it_listheader TYPE slis_t_listheader WITH HEADER LINE,
       t_event       TYPE slis_t_event WITH HEADER LINE,
       fs_layout     TYPE slis_layout_alv,
       ref           TYPE REF TO cl_gui_alv_grid,
       lv_werk       TYPE qals-werk,
       lv_mblnr      TYPE qals-mblnr,
       lv_aufnr      TYPE qals-aufnr,
       lv_lines      TYPE n LENGTH 2,
       lv_line1      TYPE n LENGTH 2.

DATA : gv_sf1 TYPE qals-prueflos,
       gv_sf2 TYPE qals-prueflos.

DATA: v_werks TYPE qamv-qmtb_werks."Added by Raj on 06.09.2023

"Adding Start by Rahul Vasita on 05.04.2024 12:21:07

DATA : lv_scrno  TYPE sy-dynnr,
       lv_result TYPE c.

"Adding End by Rahul Vasita on 05.04.2024 12:21:07
