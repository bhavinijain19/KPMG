*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_REASON......................................*
DATA:  BEGIN OF STATUS_ZPP_REASON                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_REASON                    .
CONTROLS: TCTRL_ZPP_REASON
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZPP_REASON                    .
TABLES: ZPP_REASON                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
