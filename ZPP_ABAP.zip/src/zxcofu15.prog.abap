*&---------------------------------------------------------------------*
*& Include          ZXCOFU15
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZXCOFU15
*&---------------------------------------------------------------------*
TABLES: afru.

LOOP AT afrud_tab.
  afrud_tab-zzlot1  = wa_afru-zzlot1.
  afrud_tab-zzlot2  = wa_afru-zzlot2.
  afrud_tab-zzshift = wa_afru-zzshift.
*  afrud_tab-zzreason = wa_afru-zzreason.
  afrud_tab-zzres1  = wa_afru-zzres1.
  afrud_tab-zzres2  = wa_afru-zzres2.
  afrud_tab-zzres3  = wa_afru-zzres3.
  afrud_tab-zzres4  = wa_afru-zzres4.
  afrud_tab-zzres5  = wa_afru-zzres5.
  afrud_tab-zzres6  = wa_afru-zzres6.
  afrud_tab-zzquan1 = wa_afru-zzquan1.
  afrud_tab-zzquan2 = wa_afru-zzquan2.
  afrud_tab-zzquan3 = wa_afru-zzquan3.
  afrud_tab-zzquan4 = wa_afru-zzquan4.
  afrud_tab-zzquan5 = wa_afru-zzquan5.
  afrud_tab-zzquan6 = wa_afru-zzquan6.

  afrud_tab-zzrres1  = wa_afru-zzrres1 .
  afrud_tab-zzrres2  = wa_afru-zzrres2 .
  afrud_tab-zzrres3  = wa_afru-zzrres3 .
  afrud_tab-zzrres4  = wa_afru-zzrres4 .
  afrud_tab-zzrres5  = wa_afru-zzrres5 .
  afrud_tab-zzrres6  = wa_afru-zzrres6 .
  afrud_tab-zzrquan1 = wa_afru-zzrquan1.
  afrud_tab-zzrquan2 = wa_afru-zzrquan2.
  afrud_tab-zzrquan3 = wa_afru-zzrquan3.
  afrud_tab-zzrquan4 = wa_afru-zzrquan4.
  afrud_tab-zzrquan5 = wa_afru-zzrquan5.
  afrud_tab-zzrquan6 = wa_afru-zzrquan6.

  afrud_tab-zzmach1  = wa_afru-zzmach1.
  afrud_tab-zzmach2  = wa_afru-zzmach2.
  afrud_tab-zzmach3  = wa_afru-zzmach3.
  afrud_tab-zzmach4  = wa_afru-zzmach4.
  afrud_tab-zzmach5  = wa_afru-zzmach5.
  afrud_tab-zzmach6  = wa_afru-zzmach6.
  afrud_tab-ZZMQUAN1 = wa_afru-ZZMQUAN1.
  afrud_tab-ZZMQUAN2 = wa_afru-ZZMQUAN2.
  afrud_tab-ZZMQUAN3 = wa_afru-ZZMQUAN3.
  afrud_tab-ZZMQUAN4 = wa_afru-ZZMQUAN4.
  afrud_tab-ZZMQUAN5 = wa_afru-ZZMQUAN5.
  afrud_tab-ZZMQUAN6 = wa_afru-ZZMQUAN6.

  MODIFY afrud_tab.
ENDLOOP.
