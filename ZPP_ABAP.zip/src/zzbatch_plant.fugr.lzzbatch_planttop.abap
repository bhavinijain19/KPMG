FUNCTION-POOL ZZBATCH_PLANT              MESSAGE-ID SV.

* INCLUDE LZZBATCH_PLANTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZZBATCH_PLANTT00                       . "view rel. data dcl.
