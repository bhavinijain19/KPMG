FUNCTION-POOL ZBATCH_MAT_GRP             MESSAGE-ID SV.

* INCLUDE LZBATCH_MAT_GRPD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBATCH_MAT_GRPT00                      . "view rel. data dcl.
