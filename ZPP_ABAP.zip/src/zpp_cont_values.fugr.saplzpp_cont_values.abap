*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_CONT_VALUESTOP.               " Global Declarations
  INCLUDE LZPP_CONT_VALUESUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_CONT_VALUESF...               " Subroutines
* INCLUDE LZPP_CONT_VALUESO...               " PBO-Modules
* INCLUDE LZPP_CONT_VALUESI...               " PAI-Modules
* INCLUDE LZPP_CONT_VALUESE...               " Events
* INCLUDE LZPP_CONT_VALUESP...               " Local class implement.
* INCLUDE LZPP_CONT_VALUEST99.               " ABAP Unit tests
  INCLUDE LZPP_CONT_VALUESF00                     . " subprograms
  INCLUDE LZPP_CONT_VALUESI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
