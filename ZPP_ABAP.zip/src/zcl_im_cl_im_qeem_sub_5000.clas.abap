class ZCL_IM_CL_IM_QEEM_SUB_5000 definition
  public
  create public .

public section.

  interfaces IF_EX_QEEM_SUBSCREEN_5000 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_CL_IM_QEEM_SUB_5000 IMPLEMENTATION.


  METHOD if_ex_qeem_subscreen_5000~get_data.
  MOVE IF_EX_QEEM_SUBSCREEN_5000~G_QALS TO E_QALS.
  MOVE IF_EX_QEEM_SUBSCREEN_5000~G_QALT TO E_QALT.
  MOVE IF_EX_QEEM_SUBSCREEN_5000~G_QAPO TO E_QAPO.
  MOVE IF_EX_QEEM_SUBSCREEN_5000~G_QAPP TO E_QAPP.
  ENDMETHOD.


  METHOD if_ex_qeem_subscreen_5000~process_ok_code.

  case i_ok_code.
    when '+BADI5000_1'.
      call function 'QSTEXM_STABI_HISTORY'.
    when others.
  endcase.

  ENDMETHOD.


  METHOD if_ex_qeem_subscreen_5000~put_data.
    DATA(w_qals) = i_qals.
    IF i_qals IS NOT INITIAL.
      FREE MEMORY ID 'QALS_DATA'.
      SELECT SINGLE *
        FROM zpp_qe01_cust
        WHERE plant EQ @w_qals-werk
        AND ilot EQ @w_qals-prueflos
        INTO @DATA(gs_ZPP_QE01) .
      IF sy-subrc IS INITIAL.
        w_qals-zz1_zcontrol_ind_ilh = gs_ZPP_QE01-zcontrol_indi.
        w_qals-zz1_zloc_ilh = gs_ZPP_QE01-zloc.
        w_qals-zz1_zsample_qty_ilh = gs_ZPP_QE01-zsample_qty.
      ENDIF.
      EXPORT w_qals FROM w_qals TO MEMORY ID 'QALS_DATA'.
    ENDIF.
    MOVE i_qals TO if_ex_qeem_subscreen_5000~g_qals.
    MOVE i_qalt TO if_ex_qeem_subscreen_5000~g_qalt.
    MOVE i_qapo TO if_ex_qeem_subscreen_5000~g_qapo.
    MOVE i_qapp TO if_ex_qeem_subscreen_5000~g_qapp.
*    CALL FUNCTION 'ZFM_SET_DATA_QE01'
*      EXPORTING
*        is_qals       = w_qals
*              .





  ENDMETHOD.
ENDCLASS.
