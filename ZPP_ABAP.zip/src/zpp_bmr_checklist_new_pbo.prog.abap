*&---------------------------------------------------------------------*
*& Include          ZPP_BMR_CHECKLIST_NEW_PBO
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_NEW_PBO
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.
  SET PF-STATUS '9000_STATUSN'.
*  SET TITLEBAR 'xxx'.
  LOOP AT SCREEN.
    IF screen-group1 = 'MOD' OR
       screen-group1 = 'PAG' OR
       screen-group1 = 'MAR' .
      screen-active = 0.
*      screen-invisible = 1.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.
ENDMODULE.

*&SPWIZARD: OUTPUT MODULE FOR TC 'LT_TAB_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: UPDATE LINES FOR EQUIVALENT SCROLLBAR
MODULE lt_tab_ctrl_change_tc_attr OUTPUT.
  DESCRIBE TABLE lt_tbctrl LINES lt_tab_ctrl-lines.
ENDMODULE.

*&SPWIZARD: OUTPUT MODULE FOR TC 'LT_TAB_CTRL'. DO NOT CHANGE THIS LINE!
*&SPWIZARD: GET LINES OF TABLECONTROL
MODULE lt_tab_ctrl_get_lines OUTPUT.
  g_lt_tab_ctrl_lines = sy-loopc.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  MODIFY_TABLE  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE modify_table OUTPUT.
  IF p_aufnr IS INITIAL OR lt_tbctrl[] IS INITIAL.
    LOOP AT SCREEN.
      IF screen-group1 = 'HD1'.
*        screen-active = 0.
*        screen-invisible = 1.
        screen-input = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ELSE.
    LOOP AT SCREEN.
      IF screen-group1 = 'HD1'.
*        screen-active = 1.
*        screen-invisible = 0.
        screen-input = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF."IF p_aufnr IS INITIAL.
ENDMODULE.
