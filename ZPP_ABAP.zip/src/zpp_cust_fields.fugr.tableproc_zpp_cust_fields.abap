*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_CUST_FIELDS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_CUST_FIELDS     .

  PERFORM TABLEPROC.

ENDFUNCTION.
