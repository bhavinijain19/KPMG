FUNCTION-POOL ZPP_OPTIVA_LOG             MESSAGE-ID SV.

* INCLUDE LZPP_OPTIVA_LOGD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_OPTIVA_LOGT00                      . "view rel. data dcl.
