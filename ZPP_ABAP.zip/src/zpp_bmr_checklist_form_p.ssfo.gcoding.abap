TYPES : BEGIN OF ty_mnp,
  stlnr TYPE stpo-stlnr,
  matnr TYPE mast-matnr,
  maktx TYPE makt-maktx,
  END OF ty_mnp.


  SELECT stpo~stlnr, mast~matnr, makt~maktx
    FROM stpo
    INNER JOIN mast on stpo~stlnr = mast~stlnr
    INNER JOIN makt on mast~matnr = makt~matnr
    Into TABLE @gt_mnp WHERE STPO~IDNRK = @WA_TEMP-MATNR AND MAST~WERKS = @WA_TEMP-WERKS.
SORT gt_mnp BY matnr.
DELETE ADJACENT DUPLICATES FROM gt_mnp COMPARING matnr.
LOOP AT  gt_mnP ASSIGNING FIELD-SYMBOL(<lf_mnp>).
   lv_no = lv_no  + 1.
  <lf_mnp>-stlnr = lv_no.

  ENDLOOP.




















