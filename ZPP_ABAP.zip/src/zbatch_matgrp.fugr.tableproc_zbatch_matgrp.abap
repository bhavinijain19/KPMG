*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBATCH_MATGRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBATCH_MATGRP       .

  PERFORM TABLEPROC.

ENDFUNCTION.
