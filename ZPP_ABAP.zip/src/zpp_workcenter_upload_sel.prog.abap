*&---------------------------------------------------------------------*
*& Include          ZPP_WORKCENTER_UPLOAD_SEL
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&  Include          ZPP_WORKCENTER_UPLOAD_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS: p_create RADIOBUTTON GROUP rb DEFAULT 'X',
            p_change RADIOBUTTON GROUP rb .
PARAMETERS: p_outfil TYPE rlgrap-filename.
PARAMETERS: p_mode   TYPE c DEFAULT 'A'.          "A=Foreground, N=Background
*PARAMETERS: p_tcode  TYPE tcode DEFAULT 'ZCR01'.  "Run ZCR01 by default
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN PUSHBUTTON /1(30) pb_tmpl USER-COMMAND tmpl.

*TEXT-001 = 'Workcenter Upload (ZCR01 / CR01)'.
