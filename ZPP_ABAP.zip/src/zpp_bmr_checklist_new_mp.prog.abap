*&---------------------------------------------------------------------*
*& Modulpool  ZPP_BMR_CHECKLIST_NEW_MP
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
*&----------------------Development Details----------------------------*
*&--Report           : ZPP_BMR_CHECKLIST_NEW_MP                     ---*
*&--Package          : ZPP_ABAP                                     ---*
*&--Description      : Module Pool for BMR & CheckList              ---*
*&--Transaction Code : ZPP_BMR_SF_NEW                               ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP ) / PARTH SHUKLA       ---*
*&--Functional Owner : SOURAV( ABHIYANTA ) / VIPUL KULSHRESTHA      ---*
*&--TR No            : DEVK942367                                   ---*
*&---------------------------------------------------------------------*
PROGRAM zpp_bmr_checklist_new_mp.

INCLUDE zpp_bmr_checklist_new_top.
INCLUDE zpp_bmr_checklist_new_pbo.
INCLUDE zpp_bmr_checklist_new_pai.
INCLUDE zpp_bmr_checklist_new_forms.
