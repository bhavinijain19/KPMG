FUNCTION-POOL ZWM_FM_SU_GEN_NEW.            "MESSAGE-ID ..

* INCLUDE LZWM_FM_SU_GEN_NEWD...             " Local class definition
