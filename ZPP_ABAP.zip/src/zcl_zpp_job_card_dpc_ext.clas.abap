class ZCL_ZPP_JOB_CARD_DPC_EXT definition
  public
  inheriting from ZCL_ZPP_JOB_CARD_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZPP_JOB_CARD_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    TYPES: tty_bmr_list TYPE STANDARD TABLE OF zpp_bmr_list WITH EMPTY KEY.
    DATA: lt_processed_items TYPE TABLE OF zpp_bmr_list_st.
    DATA: ls_deep_data TYPE zcl_zpp_job_card_mpc_ext=>ty_deep_entity.
    DATA: ls_existing TYPE zpp_bmr_list.
    io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_data ).
    SELECT * FROM zpp_bmr_list
      FOR ALL ENTRIES IN @ls_deep_data-toitems
      WHERE sr_no       = @ls_deep_data-toitems-sr_no
        AND werks       = @ls_deep_data-toitems-werks
        AND sf_matnr    = @ls_deep_data-toitems-sf_matnr
        AND stlal       = @ls_deep_data-toitems-stlal
        AND process_txt = @ls_deep_data-toitems-process_txt
        AND matnr       = @ls_deep_data-toitems-matnr
        AND contribution = @ls_deep_data-toitems-contribution
      INTO TABLE @DATA(lt_jobcard).

    LOOP AT ls_deep_data-toitems ASSIGNING FIELD-SYMBOL(<fs_item>).
      DATA(ls_jobcard) = VALUE zpp_bmr_list_st( ).
      MOVE-CORRESPONDING ls_deep_data TO ls_jobcard. " Header fields
      MOVE-CORRESPONDING <fs_item> TO ls_jobcard.   " Item fields

      IF ls_jobcard-werks IS INITIAL OR ls_jobcard-sf_matnr IS INITIAL OR ls_jobcard-version IS INITIAL.
        ls_jobcard-reason = ls_jobcard-reason && |Mandatory fields missing,|.
        ls_jobcard-error_type = 'E'.
      ENDIF.

      IF ls_jobcard-contribution > 100 OR ls_jobcard-contribution < 0.
        ls_jobcard-reason = ls_jobcard-reason && |Contribution % out of range,|.
        ls_jobcard-error_type = 'E'. " You can concatenate types if needed
      ENDIF.
      ls_existing = VALUE #( lt_jobcard[
                             sr_no        = <fs_item>-sr_no
                             werks        = <fs_item>-werks
                             sf_matnr     = <fs_item>-sf_matnr
                             stlal        = <fs_item>-stlal
                             process_txt  = <fs_item>-process_txt
                             matnr        = <fs_item>-matnr
                             contribution = <fs_item>-contribution ] OPTIONAL ).
      IF ls_existing IS INITIAL.
        ls_jobcard-created_by = sy-uname.
        GET TIME STAMP FIELD ls_jobcard-cr_timestamp.
      ELSE.
        ls_jobcard-created_by = ls_existing-created_by.
        ls_jobcard-cr_timestamp = ls_existing-cr_timestamp.
        ls_jobcard-changed_by = sy-uname.
        GET TIME STAMP FIELD ls_jobcard-chg_timestamp.
      ENDIF.

      APPEND ls_jobcard TO lt_processed_items.
      CLEAR: ls_existing.
    ENDLOOP.

    DATA(lv_any_error) = xsdbool( line_exists( lt_processed_items[ error_type = 'E' ] ) ).

    IF lv_any_error = abap_false.
      DATA(lt_db_insert) = CORRESPONDING tty_bmr_list( lt_processed_items ).

      MODIFY zpp_bmr_list FROM TABLE lt_db_insert.

      IF sy-subrc = 0.
        COMMIT WORK.
****        me->send_success_email( ls_deep_data ).
      ELSE.
        ROLLBACK WORK.
      ENDIF.
    ELSE.
      ROLLBACK WORK.
****      me->send_failure_email( ls_deep_data ).
    ENDIF.

    ls_deep_data-toitems = CORRESPONDING #( lt_processed_items ).
    copy_data_to_ref( EXPORTING is_data = ls_deep_data CHANGING cr_data = er_deep_entity ).
  ENDMETHOD.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
**  EXPORTING
**    iv_entity_name          =
**    iv_entity_set_name      =
**    iv_source_name          =
**    it_key_tab              =
**    it_navigation_path      =
**    io_tech_request_context =
**  IMPORTING
**    er_entity               =
**    es_response_context     =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
**  EXPORTING
**    iv_entity_name           =
**    iv_entity_set_name       =
**    iv_source_name           =
**    it_filter_select_options =
**    it_order                 =
**    is_paging                =
**    it_navigation_path       =
**    it_key_tab               =
**    iv_filter_string         =
**    iv_search_string         =
**    io_tech_request_context  =
**  IMPORTING
**    er_entityset             =
**    es_response_context      =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.
ENDCLASS.
