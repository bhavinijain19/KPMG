*&---------------------------------------------------------------------*
*& Include          ZXCOFU14
*&---------------------------------------------------------------------*
*BREAK-POINT.
select single ZORDER_FLOW
  from AUFK
  WHERE AUFNR = @AFRUD_IMP-aufnr
  into @data(lv_order).
*  if lv_order = 'Y'.
clear : AFRUD_EXP-ISM01 ,
AFRUD_EXP-ISM02,
AFRUD_EXP-ISM03 .
*    endif.


********** Retrofit Object **********************************

DATA:lv_palqty TYPE gamng,
     lv_ordqty TYPE gamng.

IF sy-tcode EQ 'CO11N'  AND ( sy-ucomm EQ 'BU' or sy-ucomm EQ 'MB03' ).
  SELECT SINGLE * FROM tvarvc INTO @DATA(ls_tvarvc) WHERE name EQ 'ZCO11N_MATERIALNO' AND low EQ @caufvd_imp-matnr.
  IF sy-subrc IS NOT INITIAL.
    SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @caufvd_imp-matnr.
    SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
    IF sy-subrc IS INITIAL.
      SELECT SINGLE * FROM zwm_config INTO @DATA(lw_data) WHERE werks = @caufvd_imp-werks AND auart = @caufvd_imp-auart.
      IF lw_data IS NOT INITIAL.
        SELECT SUM( su_qty )
             FROM zwm_su
             INTO ( lv_palqty )
             WHERE aufnr   EQ caufvd_imp-aufnr
               AND pprint  EQ abap_true
               AND del_flg EQ abap_false.
        lv_ordqty = afrud_imp-lmnga + caufvd_imp-gwemg.
        IF lv_ordqty GT lv_palqty.
          MESSAGE 'Confirmation qty should not exceed SU qty' TYPE 'E'.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
**************************************************
