*&---------------------------------------------------------------------*
*& Report  ZPP_TEST_CERTIFICATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zpp_gem_test_certificate.
TABLES : qals.
INCLUDE zpp_gem_test_certificate_top.
*INCLUDE zpp_test_certificate_top.
DATA : v_fm_name1 TYPE  rs38l_fnam.
DATA: p_werks TYPE qals-werk.
DATA : v_bukrs TYPE t001-bukrs.

DATA: g_type TYPE dd01v-datatype.
DATA: g_string(10) TYPE c.

DATA: it_listheader1 TYPE slis_t_listheader.

DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv.

DATA: ok_code LIKE sy-ucomm,
      save_ok LIKE sy-ucomm,
      ucomm   LIKE sy-ucomm.

DATA : it_stpov TYPE TABLE OF stpov.
DATA : lv_cscequi TYPE TABLE OF cscequi,
       lv_cscknd  TYPE TABLE OF cscknd,
       lv_cscmat  TYPE TABLE OF cscmat,
       lv_cscstd  TYPE TABLE OF cscstd,
       lv_csctpl  TYPE TABLE OF csctpl.

DATA: wa_add_old TYPE zwa_address_old.

TYPES : BEGIN OF t_header,
          plant_name1(40),
          plant_street(60),
          plant_house_num1(10),
          plant_house_num2(10),
          plant_str_suppl1(40),
          plant_str_suppl2(40),
          plant_str_suppl3(40),
          plant_city1(40),
          plant_city2(40),
          plant_post_code1(10),
          plant_region(10),
          plant_country(10),
          tel_number(10),
          smtp_addr(25),
        END OF t_header.
DATA : wa_headers TYPE t_header.
DATA : it_headers TYPE STANDARD TABLE OF t_header.
DATA : v_adrnr TYPE kna1-adrnr.
DATA : v_country TYPE t005t-landx50.
DATA : v_butxt TYPE t001-butxt.
DATA : v_cadrnr TYPE t001-adrnr.
DATA : v_cregion TYPE adrc-region.
DATA : v_ccountry TYPE adrc-country.

DATA: p_date TYPE qals-enstehdat.
DATA :
       wa_compaddr TYPE zwa_invcomp_add1.

DATA : v_fcompname(70).
DATA : p_bukrs TYPE t001-bukrs.




TYPES : BEGIN OF ty_finals,
          check TYPE char1,
          matnr TYPE mara-matnr,
          maktx TYPE makt-maktx,
        END OF ty_finals.

DATA : lv_matnr TYPE mara-matnr.
DATA : lv_matnr1  TYPE mara-matnr.
DATA : lv_charg TYPE qals-charg.
DATA : lv_maktx TYPE makt-maktx.

DATA : it_finals TYPE STANDARD TABLE OF ty_finals,
       wa_finals TYPE ty_finals.

DATA: BEGIN OF lt_exclude OCCURS 0,
        fcode LIKE sy-ucomm,
      END OF lt_exclude .

DATA: v_events TYPE slis_t_event,
      wa_event TYPE slis_alv_event.


SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
*SELECT-OPTIONS  : s_pruef FOR qals-prueflos." OBLIGATORY.
  PARAMETERS : s_pruef TYPE qals-prueflos.

SELECTION-SCREEN :  END OF BLOCK b1.

START-OF-SELECTION.

  SELECT prueflos,
         werk,
         matnr,
         charg,
         mjahr,
         mblnr FROM qals INTO TABLE @DATA(lt_qals) WHERE prueflos = @s_pruef.

********************    Authorization object
  SELECT SINGLE werk
       FROM qals INTO @p_werks WHERE prueflos = @s_pruef.



  IF s_pruef IS NOT INITIAL.
    SELECT SINGLE enstehdat FROM qals INTO p_date WHERE prueflos = s_pruef.
  ENDIF.

  IF p_werks IS NOT INITIAL.
    SELECT SINGLE bukrs FROM t001k INTO v_bukrs WHERE bwkey = p_werks.
  ENDIF.


  CALL FUNCTION 'Z_FM_SD_ADDRESS_OLD'
    EXPORTING
      im_werks    = v_bukrs
      im_fromdate = p_date
      im_typeind  = 'C'
    IMPORTING
      wa_add      = wa_add_old.

  IF wa_add_old IS NOT INITIAL AND wa_add_old-fcompname IS INITIAL.
    v_butxt = wa_add_old-name1.
    wa_compaddr-street = wa_add_old-street.
    wa_compaddr-street_address1 = wa_add_old-str_suppl1.
    wa_compaddr-city_address1      = wa_add_old-city1.
    wa_compaddr-city_address2      = wa_add_old-city2.
    wa_compaddr-pincode = wa_add_old-post_code1.
    SELECT SINGLE bezei FROM t005u INTO wa_compaddr-state_address1 WHERE bland EQ wa_add_old-region AND land1 = wa_add_old-country AND spras = 'EN'.
    SELECT SINGLE landx50 FROM t005t INTO wa_compaddr-country_addr WHERE land1 = wa_add_old-country AND spras = 'EN'.
    wa_compaddr-tel_number      = wa_add_old-tel_number.
    wa_compaddr-fax_number      = wa_add_old-fax_number.
    wa_compaddr-email           = wa_add_old-email.
    wa_compaddr-website         = wa_add_old-website.
  ELSE.
    wa_compaddr-fcompname = wa_add_old-fcompname.
    v_fcompname = wa_add_old-fcompname.
    SELECT SINGLE butxt adrnr  FROM t001 INTO ( v_butxt, v_cadrnr )  WHERE bukrs = v_bukrs.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT SINGLE street post_code1 str_suppl1 city1 city2 region country tel_number fax_number FROM adrc
*          INTO ( wa_compaddr-street, wa_compaddr-pincode, wa_compaddr-street_address1, wa_compaddr-city_address1,wa_compaddr-city_address2, v_cregion,
*                 v_ccountry,wa_compaddr-tel_number,wa_compaddr-fax_number )
*          WHERE addrnumber = v_cadrnr.

    SELECT street post_code1 str_suppl1 city1 city2 region country tel_number fax_number FROM adrc
    INTO ( wa_compaddr-street , wa_compaddr-pincode , wa_compaddr-street_address1 , wa_compaddr-city_address1 , wa_compaddr-city_address2 , v_cregion , v_ccountry , wa_compaddr-tel_number , wa_compaddr-fax_number ) UP TO 1 ROWS WHERE addrnumber = v_cadrnr
    ORDER BY PRIMARY KEY .
    ENDSELECT.
* End of Quick Fix


    SELECT SINGLE smtp_addr FROM adr6 INTO ( wa_compaddr-email )  WHERE addrnumber = v_cadrnr.
    SELECT SINGLE uri_srch FROM adr12 INTO ( wa_compaddr-website )  WHERE addrnumber = v_cadrnr.
    TRANSLATE wa_compaddr-website TO LOWER CASE.
    SELECT SINGLE paval FROM t001z INTO wa_compaddr-panno WHERE bukrs = v_bukrs AND party = 'J_1I02'.
    SELECT SINGLE bezei FROM t005u INTO wa_compaddr-state_address1 WHERE bland EQ v_cregion AND land1 = v_ccountry AND spras = 'EN'.
    SELECT SINGLE landx50 FROM t005t INTO wa_compaddr-country_addr WHERE land1 = v_ccountry AND spras = 'EN'.

*             if v_bukrs = '7000'.
    IF v_bukrs = '4000'.
      SELECT SINGLE telnr_call FROM adr2 INTO wa_compaddr-tel_number WHERE addrnumber = v_cadrnr AND consnumber = '4'.
      SELECT SINGLE smtp_addr FROM adr6 INTO ( wa_compaddr-email )  WHERE addrnumber = v_cadrnr AND consnumber = '2'.
    ENDIF.


  ENDIF.


*clear :wa_headers,wa_add_old.
*CALL FUNCTION 'Z_FM_SD_ADDRESS_OLD'
*    EXPORTING
*      im_werks    = v_bukrs
*      im_fromdate = p_date
*      im_typeind  = 'C'
*    IMPORTING
*      wa_add      = wa_add_old.
*
*
*       IF wa_add_old IS NOT INITIAL AND wa_add_old-fcompname IS INITIAL.
*
*         wa_headers-plant_name1 = wa_add_old-name1.
*    wa_headers-plant_street = wa_add_old-street.
*    wa_headers-plant_house_num1 = wa_add_old-house_num1.
*    wa_headers-plant_house_num2 = wa_add_old-house_num2.
*    wa_headers-plant_str_suppl1 = wa_add_old-str_suppl1.
*    wa_headers-plant_str_suppl2 = wa_add_old-str_suppl2.
*    wa_headers-plant_str_suppl3 = wa_add_old-str_suppl3.
*    wa_headers-plant_city1      = wa_add_old-city1.
*    wa_headers-plant_city2      = wa_add_old-city2.
*    wa_headers-plant_post_code1 = wa_add_old-post_code1.
*    wa_headers-plant_region     = wa_add_old-region.
*    wa_headers-plant_country    =  wa_add_old-country.
*    wa_headers-tel_number      = wa_add_old-tel_number.
*  wa_headers-smtp_addr  = wa_add_old-email.
*    else.
*    SELECT SINGLE t001~adrnr adrc~name1 adrc~street adrc~house_num1 adrc~house_num2 adrc~str_suppl1 adrc~str_suppl2
*                  adrc~str_suppl3 adrc~city1 adrc~city2 adrc~post_code1 adrc~region adrc~country adrc~tel_number
*                  FROM t001 INNER JOIN adrc ON t001~adrnr = adrc~addrnumber
*                  INTO (v_adrnr,wa_headers-plant_name1,wa_headers-plant_street,wa_headers-plant_house_num1,wa_headers-plant_house_num2,
*                  wa_headers-plant_str_suppl1,wa_headers-plant_str_suppl2,wa_headers-plant_str_suppl3,wa_headers-plant_city1,wa_headers-plant_city2,
*                  wa_headers-plant_post_code1,wa_headers-plant_region,wa_headers-plant_country,wa_headers-tel_number) WHERE t001~bukrs = v_bukrs.
*       SELECT SINGLE smtp_addr FROM adr6 INTO wa_headers-smtp_addr WHERE addrnumber = v_adrnr.
*         SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_headers-plant_country AND spras = 'EN'.
*           wa_headers-plant_country = v_country.
*      endif.
**********************Authorisation Object*******************

  LOOP AT lt_qals INTO DATA(wa_qalss).
    AUTHORITY-CHECK OBJECT 'ZPAINT_WRK'
       ID 'WERKS' FIELD wa_qalss-werk
       ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_qalss-werk.
    ENDIF.
    CLEAR :wa_qalss-werk.
  ENDLOOP.

******************Authorisation Object*******************

  LOOP AT lt_qals INTO DATA(wa_qals1).

    CALL FUNCTION 'CS_WHERE_USED_MAT'
      EXPORTING
        datub                      = sy-datum
        datuv                      = sy-datum
        matnr                      = wa_qals1-matnr
        werks                      = wa_qals1-werk
      TABLES
        wultb                      = it_stpov
        equicat                    = lv_cscequi
        kndcat                     = lv_cscknd
        matcat                     = lv_cscmat
        stdcat                     = lv_cscstd
        tplcat                     = lv_csctpl
      EXCEPTIONS
        call_invalid               = 1
        material_not_found         = 2
        no_where_used_rec_found    = 3
        no_where_used_rec_selected = 4
        no_where_used_rec_valid    = 5
        OTHERS                     = 6.

    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
    CLEAR : wa_qals1.
  ENDLOOP.

  REFRESH : it_finals.
  LOOP AT it_stpov INTO DATA(wa_stpo).
    wa_finals-matnr = wa_stpo-matnr.
    wa_finals-maktx = wa_stpo-ojtxb.
    APPEND wa_finals TO it_finals.
    CLEAR : wa_finals,wa_stpo.

  ENDLOOP .


  PERFORM event_call.
  PERFORM populate_event.

  PERFORM field_catlog.
*  PERFORM build_listheader USING it_listheader1.
  PERFORM display_alv.

FORM field_catlog.

  wa_fcat-outputlen = 1. wa_fcat-fieldname = 'CHECK'. wa_fcat-seltext_m = 'Selection'. wa_fcat-seltext_l = 'Selection'.
  wa_fcat-checkbox = 'X'. .APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'MATNR'.       wa_fcat-tabname = 'IT_FINALS'. wa_fcat-seltext_m =  'Material No.'.
  wa_fcat-outputlen = '18'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MAKTX'.       wa_fcat-tabname = 'IT_FINALS'. wa_fcat-seltext_m =  'Material Desc.'.
  wa_fcat-outputlen = '40'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.



ENDFORM.

FORM display_alv.


  DATA : i_grid_settings TYPE lvc_s_glay.
  DATA : fun TYPE TABLE OF rseul_fun.
  DATA : wa_fun LIKE LINE OF fun.
  DATA : it_exclude TYPE slis_t_extab,
         wa_exclude TYPE slis_extab.


  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS1'
      i_callback_user_command  = 'USER_COMMAND'
*     i_callback_top_of_page   = 'TOP_OF_PAGE1'
*     i_grid_title             = text-013
      is_layout                = wa_layout
      it_fieldcat              = it_fcat
*     it_sort                  = gt_sort
*     it_excluding             = it_exclude
      i_grid_settings          = i_grid_settings
      it_events                = v_events
    TABLES
      t_outtab                 = it_finals
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.
*  i_grid_settings-edt_cll_cb = 'X'.
ENDFORM.


FORM pf_status1 USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'MAIN3000'.
ENDFORM.



FORM pf_status USING rt_extab TYPE slis_t_extab.
***  Added on 10.03.2026
*  DELETE rt_extab[] WHERE fcode = '&ALL' .
*  DELETE rt_extab[] WHERE fcode = '&SAL' .
*
*DELETE rt_extab[] WHERE fcode = '&UMC'.
*DELETE rt_extab[] WHERE fcode = '%SL'.
*DELETE rt_extab[] WHERE fcode = '&OL0'.
*DELETE rt_extab[] WHERE fcode = '&OAD'.
*DELETE rt_extab[] WHERE fcode = '&AVE'.
*DELETE rt_extab[] WHERE fcode = '&XPA'.
*
*DELETE rt_extab[] WHERE fcode = '&EB9'.
*DELETE rt_extab[] WHERE fcode = '&ETA'.
*DELETE rt_extab[] WHERE fcode = '&ODN'.
*DELETE rt_extab[] WHERE fcode = '&LFO'.
*DELETE rt_extab[] WHERE fcode = '&SUM'.
*DELETE rt_extab[] WHERE fcode = '&XXL'.
*DELETE rt_extab[] WHERE fcode = '&AQW'.
*DELETE rt_extab[] WHERE fcode = '%PC'.

  DELETE rt_extab[] WHERE fcode IS NOT INITIAL.

***  Added on 10.03.2026
  SET PF-STATUS 'CERTIFICATE12'.
ENDFORM.

FORM user_command USING p_ucomm TYPE sy-ucomm
                        wa_selfield TYPE slis_selfield.

  save_ok = p_ucomm.
  CLEAR ok_code.
  DATA: rs_selfield TYPE slis_selfield.

  CASE save_ok.

    WHEN 'CANC'.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT'.
*      LEAVE PROGRAM.
      LEAVE TO SCREEN 0.
    WHEN 'BACK'.
      LEAVE TO SCREEN 0.

    WHEN '&EXECUTE'.

*      refresh : lt_fin,lt_final.
      READ TABLE it_finals INTO wa_finals INDEX wa_selfield-tabindex.

      lv_matnr = wa_finals-matnr.
      lv_maktx = wa_finals-maktx.

      SELECT prueflos,
              matnr,
              charg,
              mjahr,
              mblnr FROM qals INTO TABLE @DATA(lt_qals) WHERE prueflos = @s_pruef.

********************    Authorization object
*      SELECT SINGLE werk
*           FROM qals INTO @p_werks WHERE prueflos = @s_pruef.
*
*      AUTHORITY-CHECK OBJECT 'Z_CERT_WRK'
*         ID 'WERKS' FIELD p_werks
*         ID 'ACTVT' FIELD '03'.
*      IF sy-subrc <> 0.
*        MESSAGE e007(zsd) WITH p_werks.
*      ENDIF.
*      CLEAR : p_werks.

**************

      SELECT SINGLE matnr charg FROM qals INTO ( gv_matnr , gv_charg ) WHERE prueflos = s_pruef.
      SELECT SINGLE maktx FROM makt INTO gv_maktx WHERE matnr EQ gv_matnr.

      IF lt_qals IS NOT INITIAL.

        SELECT matnr,
               spras,
               maktx FROM makt INTO TABLE @DATA(lt_makt) FOR ALL ENTRIES IN @lt_qals WHERE matnr = @lt_qals-matnr AND spras = 'E'.

        SELECT matnr,
               charg,
               hsdat FROM mch1 INTO TABLE @DATA(lt_mch1) FOR ALL ENTRIES IN @lt_qals WHERE matnr = @lt_qals-matnr AND charg = @lt_qals-charg.

        SELECT mblnr,
               mjahr,
               matnr,
               werks,
               charg,
               meins FROM mseg INTO TABLE @DATA(lt_mseg) FOR ALL ENTRIES IN @lt_qals  WHERE mblnr = @lt_qals-mblnr AND mjahr = @lt_qals-mjahr.


* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
        SORT lt_mseg BY mblnr mjahr.

* End of Quick Fix
      ENDIF.

      DELETE lt_mseg WHERE matnr NA 'SF'.
      DELETE lt_mseg WHERE meins NE 'KG'.
      REFRESH : it_mseg.

      DESCRIBE TABLE lt_mseg LINES lv_lines.

      gt_mseg[] = lt_mseg[].

      IF lv_lines GE '02'.


        READ TABLE gt_mseg INTO gs_mseg INDEX 1.
        IF sy-subrc = 0.
          MOVE-CORRESPONDING gs_mseg TO wa_mseg.
          APPEND wa_mseg TO it_mseg.
          CLEAR wa_mseg.
        ENDIF.

        READ TABLE gt_mseg INTO gs_mseg INDEX 2.
        IF sy-subrc = 0.
          MOVE-CORRESPONDING gs_mseg TO wa_mseg.
          APPEND wa_mseg TO it_mseg.
          CLEAR wa_mseg.
        ENDIF.

        REFRESH lt_mseg.

        lt_mseg[] = it_mseg[].

      ENDIF.

      DELETE lt_mseg WHERE charg IS INITIAL.

      IF lt_mseg IS NOT INITIAL.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT prueflos,
*               matnr,
*               charg  FROM qals INTO TABLE @DATA(lt_qals1) FOR ALL ENTRIES IN @lt_mseg WHERE matnr = @lt_mseg-matnr AND charg = @lt_mseg-charg.

        SELECT prueflos ,
         matnr ,
         charg FROM qals INTO TABLE @DATA(lt_qals1) FOR ALL ENTRIES IN @lt_mseg WHERE matnr = @lt_mseg-matnr AND charg = @lt_mseg-charg
         ORDER BY PRIMARY KEY .
* End of Quick Fix


**********************************************************************************************************************************

        DESCRIBE TABLE lt_qals1 LINES lv_line1.

        IF lv_line1 GE '02'.

          READ TABLE lt_qals1 INTO DATA(ls_qals1) INDEX 1.
          IF sy-subrc = 0.
            gv_sf1 = ls_qals1-prueflos.
          ENDIF.

          READ TABLE lt_qals1 INTO ls_qals1 INDEX 2.
          IF sy-subrc = 0.
            gv_sf2 = ls_qals1-prueflos.
          ENDIF.

        ENDIF.

      ELSE.

        MESSAGE 'No data found' TYPE 'S' DISPLAY LIKE 'E'.
        LEAVE LIST-PROCESSING.

      ENDIF.

*      IF lt_qals1 IS NOT INITIAL. "Commented by Raj on 30.07.2024 To display only selection screen lot details only

*        SELECT prueflos,
*               kurztext,
*               pmethode,
*               verwmerkm,
*               mkversion,
*               merknr,
*               qmtb_werks,
*               toleranzob,
*               toleranzun,
*               masseinhsw FROM qamv INTO TABLE @DATA(lt_qamv) FOR ALL ENTRIES IN @lt_qals1 WHERE prueflos = @lt_qals1-prueflos.
      IF lt_qals IS NOT INITIAL.

        SELECT prueflos,
           kurztext,
           pmethode,
           verwmerkm,
           mkversion,
           merknr,
           qmtb_werks,
           toleranzob,
           toleranzun,
           masseinhsw FROM qamv INTO TABLE @DATA(lt_qamv) FOR ALL ENTRIES IN @lt_qals WHERE prueflos = @lt_qals-prueflos.

        IF lt_qamv IS NOT INITIAL.

          SELECT mkmnr, kurztext FROM qpmt INTO TABLE @DATA(lt_qpmt) FOR ALL ENTRIES IN @lt_qamv WHERE zaehler = @lt_qamv-qmtb_werks
                                                                                                   AND mkmnr = @lt_qamv-verwmerkm.

        ENDIF.

*        SELECT prueflos,
*               merknr,
*               pruefbemkt,
*               gruppe1,
*               code1,
*               original_input FROM qamr INTO TABLE @DATA(lt_qamr) FOR ALL ENTRIES IN @lt_qals1 WHERE prueflos = @lt_qals1-prueflos.


        SELECT prueflos,
                      merknr,
                      pruefbemkt,
                      gruppe1,
                      code1,
                      original_input FROM qamr INTO TABLE @DATA(lt_qamr) FOR ALL ENTRIES IN @lt_qals WHERE prueflos = @lt_qals-prueflos.

        IF lt_qamr IS NOT INITIAL.

          SELECT katalogart,
                 codegruppe,
                 code,
                 sprache,
                 kurztext FROM qpct INTO TABLE @DATA(lt_qpct) FOR ALL ENTRIES IN @lt_qamr WHERE codegruppe = @lt_qamr-gruppe1 AND code = @lt_qamr-code1
                                                                                            AND sprache = 'E'.

        ENDIF.

      ENDIF.

      IF lt_qamv IS NOT INITIAL.

        "comment start by Rahul Vasita on 25.04.2024
**        SELECT werks,
**               pmtnr,
**               version,
**               sortfeld FROM qmtb INTO TABLE @DATA(lt_qmtb) FOR ALL ENTRIES IN @lt_qamv WHERE pmtnr = @lt_qamv-pmethode AND version = @lt_qamv-mkversion
**                                                                                              AND werks = @lt_qamv-qmtb_werks.
        "comment end by Rahul Vasita on 25.04.2024
        SELECT werks,
               pmtnr,
               version,
               sortfeld FROM qmtb INTO TABLE @DATA(lt_qmtb) FOR ALL ENTRIES IN @lt_qamv WHERE pmtnr = @lt_qamv-pmethode AND werks = @lt_qamv-qmtb_werks.

        SORT lt_qmtb ASCENDING BY werks pmtnr version DESCENDING. "Added by Rahul Vasita on 25.04.2024
        DELETE ADJACENT DUPLICATES FROM lt_qmtb COMPARING werks pmtnr. "Added by Rahul Vasita on 25.04.2024

      ENDIF.


      LOOP AT lt_qamr INTO DATA(ls_qamr1).

        wa_final1-prueflos = ls_qamr1-prueflos.
        wa_final1-merknr   = ls_qamr1-merknr.
        IF ls_qamr1-original_input IS NOT INITIAL.
          wa_final1-original_input = ls_qamr1-original_input.
        ELSE.
          wa_final1-original_input = ls_qamr1-pruefbemkt.
        ENDIF.


        READ TABLE lt_qpct INTO DATA(ls_qpct) WITH KEY codegruppe = ls_qamr1-gruppe1 code = ls_qamr1-code1.
        IF sy-subrc = 0.
          wa_final1-kurztext = ls_qpct-kurztext.
        ENDIF.

        APPEND wa_final1 TO it_final1.
        CLEAR: wa_final1,ls_qamr1,ls_qpct.

      ENDLOOP.

      DATA: w_expo         TYPE qpmk-sollwert,
            w_expo1        TYPE qpmk-sollwert,
            w_expo2        TYPE qpmk-sollwert, "Added By Raj on 20.09.2023


            w_pckdeci(16)  TYPE p DECIMALS 3, "Added By Raj on 20.09.2023
*        w_pckdeci(16)  TYPE p DECIMALS 1,"Comment by Raj on 20.09.2023
            w_pckdeci1(16) TYPE p DECIMALS 3, "Added by Raj on 20.09.2023
*        w_pckdeci1(16) TYPE p DECIMALS 1."Comment by Raj on 20.09.2023
            w_pckdeci2(16) TYPE p DECIMALS 3. "Added by Raj on 20.09.2023

*********************Header Deatails************
      wa_header-matnr = lv_matnr.
      wa_header-maktx = lv_maktx.

      READ TABLE lt_qals INTO DATA(wa_qals) INDEX 1.
      SELECT SINGLE hsdat FROM mch1 INTO wa_header-hsdat WHERE matnr = wa_qals-matnr AND charg = wa_qals-charg.
      wa_header-charg = wa_qals-charg.
*        select single charg from qals into wa_header-charg where prueflos = s_pruef.

      REFRESH : it_final.

      LOOP AT lt_qamv INTO DATA(ls_qamv).

        CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
          EXPORTING
            input          = ls_qamv-masseinhsw
            language       = sy-langu
          IMPORTING
            long_text      = lv_ltext
            output         = lv_output
            short_text     = lv_stext
          EXCEPTIONS
            unit_not_found = 1
            OTHERS         = 2.
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ENDIF.



        v_werks = ls_qamv-qmtb_werks."Added By Raj on 06.09.2023

******************************************************************************************

        " Added By Pratik M Date - 02.02.2024
        DATA gt_char TYPE TABLE OF  bapi2045d1.

        " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
        CALL FUNCTION 'BAPI_INSPOPER_GETDETAIL' "#EC CI_USAGE_OK[2438131]
          " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
          EXPORTING
            insplot                = ls_qamv-prueflos
            inspoper               = '0010'
            read_insppoints        = 'X'
            read_char_requirements = 'X'
            read_char_results      = 'X'
            read_sample_results    = 'X'
*           read_single_results    = 'X'
*           read_chars_with_classes = 'X'
*           READ_CHARS_WITHOUT_RECORDING       = ' '
*           RES_ORG                = ' '
            char_filter_no         = '1'
            char_filter_tcode      = 'QE11'
            max_insppoints         = 100
            insppoint_from         = 0
*           HANDHELD_APPLICATION   = ' '
*           RESULT_COPY            = ' '
* IMPORTING
*           OPERATION              =
*           INSPPOINT_REQUIREMENTS =
*           RETURN                 =
          TABLES
*           INSPPOINTS             =
            char_requirements      = gt_char.
*   CHAR_RESULTS                       =
*   SAMPLE_RESULTS                     =
*   SINGLE_RESULTS                     =

        READ TABLE gt_char INTO DATA(gs_char) WITH KEY inspchar = ls_qamv-merknr.
        wa_final-masseinhsw = gs_char-meas_unit.

        " End of Changes Date - 02.02.2024
******************************************************************************************

        wa_final-prueflos   = ls_qamv-prueflos.
        wa_final-merknr     = ls_qamv-merknr.

        wa_final-toleranzun = ls_qamv-toleranzun.
        MOVE : wa_final-toleranzun TO w_expo,
                w_expo TO w_pckdeci.
        wa_final-toleranzun1 = w_pckdeci.

        wa_final-toleranzob = ls_qamv-toleranzob.
        MOVE : wa_final-toleranzob TO w_expo1,
               w_expo1 TO w_pckdeci1.
        wa_final-toleranzob1 = w_pckdeci1.

*************Added by Raj on 20.09.2023**********************
*    MOVE : wa_final-original_input TO w_expo2,
*           w_expo2 TO w_pckdeci2.
*    wa_final-original_input1 = w_pckdeci2.

************Added by Raj on 20.09.2023***********************
        READ TABLE lt_qpmt INTO DATA(ls_qpmt) WITH KEY mkmnr = ls_qamv-verwmerkm.
        IF sy-subrc = 0.
*          wa_final-kurztext = ls_qpmt-kurztext."Commented by Raj on 29.07.2024
        ENDIF.

        IF  wa_final-toleranzun1 = 0 AND wa_final-toleranzob1 = 0.
          MOVE ls_qamv-kurztext TO wa_final-toleranzun2.
        ELSE .
          CONCATENATE wa_final-toleranzun1 '-' wa_final-toleranzob1 INTO wa_final-toleranzun2.
        ENDIF.

*        READ TABLE lt_qmtb INTO DATA(ls_qmtb) WITH KEY pmtnr = ls_qamv-pmethode version = ls_qamv-mkversion werks = ls_qamv-qmtb_werks."Commented by Raj on 25.04.2024
        READ TABLE lt_qmtb INTO DATA(ls_qmtb) WITH KEY pmtnr = ls_qamv-pmethode  werks = ls_qamv-qmtb_werks.
        IF sy-subrc = 0.
          wa_final-sortfeld = ls_qmtb-sortfeld.
        ENDIF.

        READ TABLE it_final1 INTO wa_final1 WITH KEY prueflos = ls_qamv-prueflos merknr = ls_qamv-merknr.
        IF sy-subrc = 0.
          "Changed by UDAYABAP03 on 13.04.2026
*          wa_final-original_input = wa_final1-original_input.
          IF wa_final1-original_input IS NOT INITIAL.
            wa_final-original_input = wa_final1-original_input.
          ELSE.
            wa_final-original_input = wa_final1-kurztext.
          ENDIF.
          "Changed by UDAYABAP03 on 13.04.2026
        ENDIF.

        wa_final-kurztext = ls_qamv-kurztext."Added by Raj on 29.07.2024

        APPEND wa_final TO it_final.
        CLEAR: wa_final,ls_qamv,g_type,lv_ltext,lv_output.",gs_char.

      ENDLOOP.

*      READ TABLE lt_mseg INTO DATA(ls_mseg) INDEX 2.
*      IF sy-subrc NE 0.

      REFRESH : lt_fin.
      LOOP AT it_final INTO wa_final.
        MOVE-CORRESPONDING wa_final TO ls_fin.
        APPEND ls_fin TO lt_fin.
        CLEAR: wa_final, ls_fin.
      ENDLOOP.

      SORT lt_fin ASCENDING BY merknr.

      PERFORM fill_listheader.
      PERFORM fill_fieldcatalog1.
      PERFORM fill_layout.
      PERFORM display1.

*      ELSE.
*        REFRESH : lt_final.
*
*        LOOP AT it_final INTO wa_final.
*          MOVE-CORRESPONDING wa_final TO ls_final.
*          IF wa_final-prueflos = gv_sf1.
*            ls_final-parta = 'X'.
*          ELSEIF wa_final-prueflos = gv_sf2.
*            ls_final-partb = 'X'.
*          ENDIF.
*          APPEND ls_final TO lt_final.
*          CLEAR: wa_final, ls_final.
*        ENDLOOP.
*
*        SORT lt_final ASCENDING BY prueflos merknr.
*
*        PERFORM fill_listheader.
*        PERFORM fill_fieldcatalog.
*        PERFORM fill_layout.
*        PERFORM display.
*
*      ENDIF.

      REFRESH :lt_fin , lt_final.
      CLEAR : lv_matnr , lv_maktx.

  ENDCASE.








ENDFORM.

FORM fill_listheader .
  REFRESH : it_listheader.

  it_listheader-typ = 'H'.
  it_listheader-key = ' '.
  it_listheader-info = 'SFG Selection'.
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Date :' .
  CONCATENATE  sy-datum+6(2)

               sy-datum+4(2)
               sy-datum(4)
               INTO it_listheader-info
               SEPARATED BY '/'.
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Material :' .
  " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  CONCATENATE  lv_matnr '(' lv_maktx')'      "#EC CI_FLDEXT_OK[2215424]
               INTO it_listheader-info
               SEPARATED BY space.
  " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Batch :' .
  it_listheader-info = gv_charg.
  APPEND it_listheader.

ENDFORM.


FORM display1 .
  DATA : i_grid_settings TYPE lvc_s_glay.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS'
      i_callback_user_command  = 'USER_COMMAND2'
      i_callback_top_of_page   = 'TOP_OF_PAGE'
      is_layout                = fs_layout
      it_fieldcat              = it_fieldcat[]
      it_events                = t_event[]
      i_grid_settings          = i_grid_settings
      i_save                   = 'A'
    TABLES
      t_outtab                 = lt_fin[]
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

*refresh : lt_fin[].

ENDFORM.


FORM fill_fieldcatalog .

  REFRESH: it_fieldcat.

  PERFORM fieldcat_append  USING  'PARTA'               'PART A'               'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'PARTB'               'PART B'               'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'OTHER'               'OTHER'                'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'KURZTEXT'            'PROPERTIES'           'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'SORTFELD'            'TESTING STANDARD'     'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'TOLERANZUN2'         'SPECIFICATION'        'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'ORIGINAL_INPUT'      'RESULTS'              'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'MASSEINHSW'          'UNIT'                 'X' ' ' ' ' 'LT_FINAL' .

ENDFORM.




FORM fill_fieldcatalog1 .

  REFRESH: it_fieldcat.

  PERFORM fieldcat_append  USING  'PARTA'               'SELECTION'            'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'KURZTEXT'            'PROPERTIES'           'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'SORTFELD'            'TESTING STANDARD'     'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'TOLERANZUN2'         'SPECIFICATION'        'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'ORIGINAL_INPUT'      'RESULTS'              'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'MASSEINHSW'          'UNIT'                 'X' ' ' ' ' 'LT_FINAL' .

ENDFORM.

FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_check)
                               VALUE(p_edit)
                               VALUE(p_table).

  it_fieldcat-fieldname   = p_fname.
  it_fieldcat-seltext_l   = p_ftext.
  it_fieldcat-fix_column  = p_fixcol.
  it_fieldcat-checkbox    = p_check.
  it_fieldcat-edit        = p_edit.
  it_fieldcat-tabname     = p_table.

  APPEND it_fieldcat.
ENDFORM.


FORM fill_layout .

  t_event-name = slis_ev_top_of_page.
  t_event-form = 'TOP_OF_PAGE'.
  APPEND t_event.
  fs_layout-colwidth_optimize = 'X'.

ENDFORM.
FORM top_of_page.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_listheader[].

ENDFORM.


FORM display .
  DATA : i_grid_settings TYPE lvc_s_glay.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS'
      i_callback_user_command  = 'USER_COMMAND1'
      i_callback_top_of_page   = 'TOP_OF_PAGE'
      is_layout                = fs_layout
      it_fieldcat              = it_fieldcat[]
      it_events                = t_event[]
      i_grid_settings          = i_grid_settings
      i_save                   = 'A'
    TABLES
      t_outtab                 = lt_final[]
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

*refresh : lt_final[].

ENDFORM.


FORM user_command1 USING r_ucomm TYPE sy-ucomm r_field TYPE slis_selfield.

  CASE r_ucomm.

      " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
    WHEN
'FORM'                                        "#EC CI_USAGE_OK[2270335]
.
      " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

      SORT lt_final ASCENDING BY prueflos  merknr.

      CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
        IMPORTING
          e_grid = ref.

      CALL METHOD ref->check_changed_data.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname = 'ZPP_GEM_TEST_CERT1'
        IMPORTING
          fm_name  = v_fm_name1.
      IF sy-subrc <> 0.
*       Implement suitable error handling here
      ENDIF.

      CALL FUNCTION v_fm_name1
        EXPORTING
          wa_header = wa_header
          gv_sf1    = gv_sf1
          gv_sf2    = gv_sf2
          v_werks   = v_werks
        TABLES
          it_final  = lt_final.

      IF sy-subrc <> 0.
      ENDIF.

  ENDCASE.

ENDFORM.


FORM user_command2 USING r_ucomm TYPE sy-ucomm r_field TYPE slis_selfield.

  CASE r_ucomm.

      " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
    WHEN
'FORM'                                        "#EC CI_USAGE_OK[2270335]
.
      " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

      SORT lt_fin ASCENDING BY merknr.

      CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
        IMPORTING
          e_grid = ref.

      CALL METHOD ref->check_changed_data.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname = 'ZPP_GEM_TEST_CERT'
        IMPORTING
          fm_name  = v_fm_name1.
      IF sy-subrc <> 0.
*       Implement suitable error handling here
      ENDIF.

      "Adding Start by Rahul Vasita on 05.04.2024 13:46:45
      CLEAR lv_result.
      CALL FUNCTION 'K_KKB_POPUP_RADIO2'
        EXPORTING
          i_title   = 'Please Select Form to Print'
          i_text1   = 'Gem Paints'
          i_text2   = 'Astral Paints'
          i_default = 'Gem Paints'
        IMPORTING
          i_result  = lv_result
        EXCEPTIONS
          cancel    = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      CASE lv_result.
        WHEN '1'.
          CALL FUNCTION v_fm_name1
            EXPORTING
              wa_header   = wa_header
              v_werks     = v_werks
              p_indic     = 'G'
              wa_compaddr = wa_compaddr    "Plant Address based on Date OLD and NEW Address will be print on the test certificate
              v_butxt     = v_butxt
            TABLES
              lt_fin      = lt_fin.

          IF sy-subrc <> 0.
          ENDIF.
        WHEN '2'.
          CALL FUNCTION v_fm_name1
            EXPORTING
              wa_header   = wa_header
              v_werks     = v_werks
              p_indic     = 'A'
              wa_compaddr = wa_compaddr
              v_butxt     = v_butxt
            TABLES
              lt_fin      = lt_fin.

          IF sy-subrc <> 0.
          ENDIF.
      ENDCASE.

      "Adding End by Rahul Vasita on 05.04.2024 13:46:45



  ENDCASE.





ENDFORM.

FORM event_call.
  CALL FUNCTION 'REUSE_ALV_EVENTS_GET'
    EXPORTING
      i_list_type = 0
    IMPORTING
      et_events   = v_events
*  EXCEPTIONS
*     LIST_TYPE_WRONG       = 1
*     OTHERS      = 2
    .
  IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.
ENDFORM.

FORM populate_event.
  READ TABLE v_events INTO wa_event WITH KEY name = 'USER_COMMAND'.
  IF sy-subrc EQ 0.
    wa_event-form = 'USER_COMMAND'.
    MODIFY v_events FROM wa_event TRANSPORTING form WHERE name =
   wa_event-name.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.
  SET PF-STATUS '9000_STATUS'.
*  SET TITLEBAR 'xxx'.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.
  CASE ok_code.
    WHEN '&YES'.

    WHEN '&NO'.
      LEAVE TO SCREEN 0.
  ENDCASE.
ENDMODULE.
