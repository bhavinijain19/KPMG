*&---------------------------------------------------------------------*
*& Include          ZPP_MASTER_RECIPE_UPLOAD_F01
*&---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* DOWNLOAD TEMPLATE
*---------------------------------------------------------------------*
FORM download_template.

  DATA: lv_fname TYPE string,
        lv_path  TYPE string,
        lv_full  TYPE string.

  TYPES: BEGIN OF ty_template,
           col TYPE string,
         END OF ty_template.
  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  CLEAR lt_template.

  CONCATENATE 'Recipe Number' 'Recipe Group' 'Key date' 'Entry Act' 'Entry Act' 'Operation' 'Control Key'
              'Operation description' 'Base Qty' 'Unit' 'Setup Labor' 'Setup Machine' 'Setup Power' 'Machine' 'Labor' 'Power'
    INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
  APPEND ls_template TO lt_template.

  "Save dialog & download"
  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING default_extension = 'xls'
              default_file_name = COND string(
                 WHEN r_down = 'X' THEN 'Master_recipe_Template.xls' )
    CHANGING  filename = lv_fname path = lv_path fullpath = lv_full ).

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  cl_gui_frontend_services=>gui_download(
    EXPORTING filename = lv_full filetype = 'ASC' write_field_separator = abap_true
    CHANGING  data_tab = lt_template ).

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.

ENDFORM.
*---------------------------------------------------------------------*
* UPLOAD EXCEL
*---------------------------------------------------------------------*
FORM upload_excel.

  DATA: gt_raw     TYPE solix_tab,
        gv_bin_len TYPE i.

  DATA: lv_xstring    TYPE xstring,
        lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
        lv_docname    TYPE string,
        lt_worksheets TYPE STANDARD TABLE OF string,
        lv_worksheet  TYPE string,
        lv_lines      TYPE i,
        lo_data       TYPE REF TO data.

  DATA: lv_fname   TYPE string.

  FIELD-SYMBOLS: <lt_data>      TYPE STANDARD TABLE,
                 <ls_data>      TYPE any,
                 <lv_value_tmp> TYPE any,
                 <lv_value>     TYPE any.
  lv_fname = p_file.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  CREATE OBJECT lo_excel
    EXPORTING
      document_name = lv_docname
      xdocument     = lv_xstring.

  IF lo_excel IS NOT INITIAL.
    lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
      IMPORTING
        worksheet_names = lt_worksheets ).
  ENDIF.

  DESCRIBE TABLE lt_worksheets LINES lv_lines.

  IF lt_worksheets[] IS NOT INITIAL.
    READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
    lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
    ASSIGN lo_data->* TO <lt_data>.
  ENDIF.

  IF <lt_data> IS ASSIGNED.
    LOOP AT <lt_data> ASSIGNING <ls_data> FROM 2.
      CLEAR: gs_excel.
      DO.
        ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data> TO <lv_value_tmp>.
        IF sy-subrc EQ 0.
          ASSIGN COMPONENT sy-index OF STRUCTURE gs_excel TO <lv_value>.
          IF sy-subrc EQ 0.
            <lv_value> = <lv_value_tmp>.
          ENDIF.
        ELSE.
          EXIT.
        ENDIF.
      ENDDO.
      IF gs_excel IS NOT INITIAL.
        APPEND gs_excel TO gt_excel.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.

*---------------------------------------------------------------------*
* EXECUTE BDC – C201
*---------------------------------------------------------------------*
FORM execute_bdc.
  DATA : scroll TYPE char1,
         lv_str TYPE string.

  LOOP AT gt_excel ASSIGNING FIELD-SYMBOL(<fs_excel>).
    <fs_excel>-plnal_002 = |{ <fs_excel>-plnal_002 ALPHA = IN }|.
    <fs_excel>-vornr_006 = |{ <fs_excel>-vornr_006 ALPHA = IN }|.
  ENDLOOP.

  SELECT s~plnnr, s~plnal, s~zaehl, s~plnkn,
         p~vgw01, p~vgw02, p~vgw03, p~vgw04,
         p~vgw05, p~vgw06, p~bmsch, p~steus
    FROM plas AS s
    INNER JOIN plpo AS p ON p~plnnr = s~plnnr
                        AND p~plnkn = s~plnkn
                        AND p~zaehl = s~zaehl
    FOR ALL ENTRIES IN @gt_excel
    WHERE s~plnnr = @gt_excel-plnnr_001 " Recipe Number
      AND s~plnal = @gt_excel-plnal_002 " Group Counter
      AND s~plnty = '2'                 " Task List Type for Recipes
      AND p~vornr = @gt_excel-vornr_006 " Operation Number
      AND p~phflg <> @space
    INTO TABLE @DATA(lt_result).


  LOOP AT gt_excel INTO gs_excel.
**  READ   TABLE gt_excel INTO gs_excel INDEX 1.
    REFRESH gt_bdcdata.

    READ TABLE lt_result INTO DATA(ls_master) WITH KEY plnnr = gs_excel-plnnr_001
                                                       plnal = gs_excel-plnal_002.

    IF sy-subrc = 0.
      IF gs_excel-bmsch_010 IS INITIAL. gs_excel-bmsch_010 = ls_master-bmsch. ENDIF.
      IF gs_excel-vgw01_012 IS INITIAL. gs_excel-vgw01_012 = ls_master-vgw01. ENDIF.
      IF gs_excel-vgw02_015 IS INITIAL. gs_excel-vgw02_015 = ls_master-vgw02. ENDIF.
      IF gs_excel-vgw03_018 IS INITIAL. gs_excel-vgw03_018 = ls_master-vgw03. ENDIF.
      IF gs_excel-vgw04_021 IS INITIAL. gs_excel-vgw04_021 = ls_master-vgw04. ENDIF.
      IF gs_excel-vgw05_024 IS INITIAL. gs_excel-vgw05_024 = ls_master-vgw05. ENDIF.
      IF gs_excel-vgw06_027 IS INITIAL. gs_excel-vgw06_027 = ls_master-vgw06. ENDIF.
    ENDIF.

    PERFORM bdc_dynpro      USING 'SAPLCPDI' '4000'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC271-STTAG'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'RC271-PLNNR'
                                  gs_excel-plnnr_001.
    PERFORM bdc_field       USING 'RC271-PLNAL'
                                  gs_excel-plnal_002.
    PERFORM bdc_field       USING 'RC271-STTAG'
                                  gs_excel-sttag_003.
    PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RC27X-ENTRY_ACT'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=ENT1'.
    PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                  gs_excel-entry_act_004.
    PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'PLPOD-VORNR(01)'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=PICK'.
    PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                  gs_excel-entry_act_005.
    PERFORM bdc_dynpro      USING 'SAPLCPDO' '4410'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'PLPOD-LAR06'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'PLPOD-VORNR'
                                  gs_excel-vornr_006.
    PERFORM bdc_field       USING 'PLPOD-STEUS'
                                  gs_excel-steus_007.
    PERFORM bdc_field       USING 'PLPOD-CKSELKZ'
                                  'X'. "gs_excel-ckselkz_008.
    PERFORM bdc_field       USING 'PLPOD-LTXA1'
                                  gs_excel-ltxa1_009.
    PERFORM bdc_field       USING 'PLPOD-BMSCH'
                                  gs_excel-bmsch_010.
    PERFORM bdc_field       USING 'PLPOD-MEINH'
                                  gs_excel-meinh_011.
    PERFORM bdc_field       USING 'PLPOD-VGW01'
                                  gs_excel-vgw01_012.
    PERFORM bdc_field       USING 'PLPOD-VGE01'
                                  'MIN'. "gs_excel-vge01_013.
    PERFORM bdc_field       USING 'PLPOD-LAR01'
                                  '900003'. "gs_excel-lar01_014.
    PERFORM bdc_field       USING 'PLPOD-VGW02'
                                  gs_excel-vgw02_015.
    PERFORM bdc_field       USING 'PLPOD-VGE02'
                                  'MIN'. "gs_excel-vge02_016.
    PERFORM bdc_field       USING 'PLPOD-LAR02'
                                  '900001'. "gs_excel-lar02_017.
    PERFORM bdc_field       USING 'PLPOD-VGW03'
                                  gs_excel-vgw03_018.
    PERFORM bdc_field       USING 'PLPOD-VGE03'
                                  'MIN'. "gs_excel-vge03_019.
    PERFORM bdc_field       USING 'PLPOD-LAR03'
                                  '900005'. "gs_excel-lar03_020.
    PERFORM bdc_field       USING 'PLPOD-VGW04'
                                  gs_excel-vgw04_021.
    PERFORM bdc_field       USING 'PLPOD-VGE04'
                                  'MIN'. "gs_excel-vge04_022.
    PERFORM bdc_field       USING 'PLPOD-LAR04'
                                  '900002'. "gs_excel-lar04_023.
    PERFORM bdc_field       USING 'PLPOD-VGW05'
                                  gs_excel-vgw05_024.
    PERFORM bdc_field       USING 'PLPOD-VGE05'
                                  'MIN'. "gs_excel-vge05_025.
    PERFORM bdc_field       USING 'PLPOD-LAR05'
                                  '900004'. "gs_excel-lar05_026.
    PERFORM bdc_field       USING 'PLPOD-VGW06'
                                  gs_excel-vgw06_027.
    PERFORM bdc_field       USING 'PLPOD-VGE06'
                                  'MIN'. "gs_excel-vge06_028.
    PERFORM bdc_field       USING 'PLPOD-LAR06'
                                  '900006'. "gs_excel-lar06_029.
    PERFORM bdc_dynpro      USING 'SAPLCPDO' '4410'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'PLPOD-VORNR'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
    PERFORM bdc_field       USING 'PLPOD-VORNR'
                                  gs_excel-vornr_006.
    PERFORM bdc_field       USING 'PLPOD-STEUS'
                                  gs_excel-steus_007.
    PERFORM bdc_field       USING 'PLPOD-CKSELKZ'
                                  'X'. "gs_excel-ckselkz_032.
    PERFORM bdc_field       USING 'PLPOD-LTXA1'
                                  gs_excel-ltxa1_009.
    PERFORM bdc_field       USING 'PLPOD-BMSCH'
                                  gs_excel-bmsch_010.
    PERFORM bdc_field       USING 'PLPOD-MEINH'
                                  gs_excel-meinh_011.


    PERFORM bdc_field       USING 'PLPOD-VGW01'
                                gs_excel-vgw01_012.
    PERFORM bdc_field       USING 'PLPOD-VGE01'
                                  'MIN'. "gs_excel-vge01_013.
    PERFORM bdc_field       USING 'PLPOD-LAR01'
                                  '900003'. "gs_excel-lar01_014.
    PERFORM bdc_field       USING 'PLPOD-VGW02'
                                  gs_excel-vgw02_015.
    PERFORM bdc_field       USING 'PLPOD-VGE02'
                                  'MIN'. "gs_excel-vge02_016.
    PERFORM bdc_field       USING 'PLPOD-LAR02'
                                  '900001'. "gs_excel-lar02_017.
    PERFORM bdc_field       USING 'PLPOD-VGW03'
                                  gs_excel-vgw03_018.
    PERFORM bdc_field       USING 'PLPOD-VGE03'
                                  'MIN'. "gs_excel-vge03_019.
    PERFORM bdc_field       USING 'PLPOD-LAR03'
                                  '900005'. "gs_excel-lar03_020.
    PERFORM bdc_field       USING 'PLPOD-VGW04'
                                  gs_excel-vgw04_021.
    PERFORM bdc_field       USING 'PLPOD-VGE04'
                                  'MIN'. "gs_excel-vge04_022.
    PERFORM bdc_field       USING 'PLPOD-LAR04'
                                  '900002'. "gs_excel-lar04_023.
    PERFORM bdc_field       USING 'PLPOD-VGW05'
                                  gs_excel-vgw05_024.
    PERFORM bdc_field       USING 'PLPOD-VGE05'
                                  'MIN'. "gs_excel-vge05_025.
    PERFORM bdc_field       USING 'PLPOD-LAR05'
                                  '900004'. "gs_excel-lar05_026.
    PERFORM bdc_field       USING 'PLPOD-VGW06'
                                  gs_excel-vgw06_027.
    PERFORM bdc_field       USING 'PLPOD-VGE06'
                                  'MIN'. "gs_excel-vge06_028.
    PERFORM bdc_field       USING 'PLPOD-LAR06'
                                  '900006'. "gs_excel-lar06_029.

**  PERFORM bdc_field       USING 'PLPOD-VGW01'
**                                gs_excel-vgw01_036.
**  PERFORM bdc_field       USING 'PLPOD-VGE01'
**                                gs_excel-vge01_037.
**  PERFORM bdc_field       USING 'PLPOD-LAR01'
**                                gs_excel-lar01_038.
**  PERFORM bdc_field       USING 'PLPOD-VGW02'
**                                gs_excel-vgw02_039.
**  PERFORM bdc_field       USING 'PLPOD-VGE02'
**                                gs_excel-vge02_040.
**  PERFORM bdc_field       USING 'PLPOD-LAR02'
**                                gs_excel-lar02_041.
**  PERFORM bdc_field       USING 'PLPOD-VGW03'
**                                gs_excel-vgw03_042.
**  PERFORM bdc_field       USING 'PLPOD-VGE03'
**                                gs_excel-vge03_043.
**  PERFORM bdc_field       USING 'PLPOD-LAR03'
**                                gs_excel-lar03_044.
**  PERFORM bdc_field       USING 'PLPOD-VGW04'
**                                gs_excel-vgw04_045.
**  PERFORM bdc_field       USING 'PLPOD-VGE04'
**                                gs_excel-vge04_046.
**  PERFORM bdc_field       USING 'PLPOD-LAR04'
**                                gs_excel-lar04_047.
**  PERFORM bdc_field       USING 'PLPOD-VGW05'
**                                gs_excel-vgw05_048.
**  PERFORM bdc_field       USING 'PLPOD-VGE05'
**                                gs_excel-vge05_049.
**  PERFORM bdc_field       USING 'PLPOD-LAR05'
**                                gs_excel-lar05_050.
**  PERFORM bdc_field       USING 'PLPOD-VGW06'
**                                gs_excel-vgw06_051.
**  PERFORM bdc_field       USING 'PLPOD-VGE06'
**                                gs_excel-vge06_052.
**  PERFORM bdc_field       USING 'PLPOD-LAR06'
**                                gs_excel-lar06_053.

    CALL TRANSACTION 'C202' USING gt_bdcdata MODE  p_mode UPDATE 'S' MESSAGES INTO gt_msg.

    CLEAR gs_excel.
  ENDLOOP.

ENDFORM.
*---------------------------------------------------------------------*
* BDC PERFORM ROUTINES
*---------------------------------------------------------------------*
FORM bdc_dynpro USING p_prog p_dyn.
  CLEAR gs_bdcdata.
  gs_bdcdata-program  = p_prog.
  gs_bdcdata-dynpro   = p_dyn.
  gs_bdcdata-dynbegin = 'X'.
  APPEND gs_bdcdata TO gt_bdcdata.
ENDFORM.

FORM bdc_field USING p_fnam p_fval.
  CLEAR gs_bdcdata.
  gs_bdcdata-fnam = p_fnam.
  gs_bdcdata-fval = p_fval.
  APPEND gs_bdcdata TO gt_bdcdata.
ENDFORM.
