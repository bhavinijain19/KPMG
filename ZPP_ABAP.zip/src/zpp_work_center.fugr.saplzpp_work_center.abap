*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_WORK_CENTERTOP.               " Global Declarations
  INCLUDE LZPP_WORK_CENTERUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_WORK_CENTERF...               " Subroutines
* INCLUDE LZPP_WORK_CENTERO...               " PBO-Modules
* INCLUDE LZPP_WORK_CENTERI...               " PAI-Modules
* INCLUDE LZPP_WORK_CENTERE...               " Events
* INCLUDE LZPP_WORK_CENTERP...               " Local class implement.
* INCLUDE LZPP_WORK_CENTERT99.               " ABAP Unit tests
  INCLUDE LZPP_WORK_CENTERF00                     . " subprograms
  INCLUDE LZPP_WORK_CENTERI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
