*&---------------------------------------------------------------------*
*&  Include           ZPP_OPTIVA_QP_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  READ_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM read_data .

*****Transfer files from FTP to AL11
*  DATA:lv_cmd    TYPE sxpgcolist-name VALUE 'ZOPTIVQ',
*       lv_status TYPE extcmdexex-status,.
*       lv_code   TYPE extcmdexex-exitcode.

  DATA: lv_cmd    TYPE  char18  , "      sxpgcolist-name VALUE 'ZOPTIVB',
        lv_status TYPE extcmdexex-status,
        lv_code   TYPE extcmdexex-exitcode.

  IF v_rcl = 'X'.  "Added  by Raj on 17.01.2025
    lv_cmd = 'ZOPTIVQ'.
  ELSEIF v_p = 'X'.
    lv_cmd = 'ZPOPTIVQ'.
  ENDIF.





  DATA: t_result         TYPE STANDARD TABLE OF btcxpm.
*  IF c_excel IS INITIAL. """added by akshay dt.24.03.2025
    CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
      EXPORTING
        commandname                   = lv_cmd
*       ADDITIONAL_PARAMETERS         = lv_parm
*       OPERATINGSYSTEM               = SY-OPSYS
*       TARGETSYSTEM                  = SY-HOST
*       DESTINATION                   =
*       STDOUT                        = 'X'
*       STDERR                        = 'X'
*       TERMINATIONWAIT               = 'X'
*       TRACE                         =
*       DIALOG                        =
      IMPORTING
        status                        = lv_status
        exitcode                      = lv_code
      TABLES
        exec_protocol                 = t_result
      EXCEPTIONS
        no_permission                 = 1
        command_not_found             = 2
        parameters_too_long           = 3
        security_risk                 = 4
        wrong_check_call_interface    = 5
        program_start_error           = 6
        program_termination_error     = 7
        x_error                       = 8
        parameter_expected            = 9
        too_many_parameters           = 10
        illegal_command               = 11
        wrong_asynchronous_parameters = 12
        cant_enq_tbtco_entry          = 13
        jobcount_generation_error     = 14
        OTHERS                        = 15.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
       WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

*  ENDIF. """added by akshay dt.24.03.2025
*CONSTANTS:
* c_tvarvc_name TYPE rvari_vnam VALUE 'ZOPTIVA'.



  IF v_rcl = 'X'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*            INTO wrk_file1
*            FROM tvarvc
*            WHERE name = c_tvarvc_name .

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = C_TVARVC_NAME
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    SELECT SINGLE low
           INTO wrk_file2
           FROM tvarvc
           WHERE name = c_tvarvc_name1 .



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_email
*        FROM tvarvc
*        WHERE name = c_tvarvc_name2 .

SELECT LOW
 INTO WRK_EMAIL FROM TVARVC UP TO 1 ROWS WHERE NAME = C_TVARVC_NAME2
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    wrk_qp_email = wrk_email.

  ELSEIF v_p = 'X'.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_file1
*        FROM tvarvc
*        WHERE name = pc_tvarvc_name .

SELECT LOW
 INTO WRK_FILE1 FROM TVARVC UP TO 1 ROWS WHERE NAME = PC_TVARVC_NAME
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    SELECT SINGLE low
           INTO wrk_file2
           FROM tvarvc
           WHERE name = pc_tvarvc_name1 .



* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT SINGLE low
*        INTO wrk_email
*        FROM tvarvc
*        WHERE name = pc_tvarvc_name2 .

SELECT LOW
 INTO WRK_EMAIL FROM TVARVC UP TO 1 ROWS WHERE NAME = PC_TVARVC_NAME2
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    wrk_qp_email = wrk_email.
  ENDIF.
*****Transfer of file end

  """""""Read file from AL11"""""
*  CREATE OBJECT gcl_xml.

* begin  of code added on 18.05.2020


*  wrk_file1 = '\\SAPDEV\sapmnt\trans\OPTIVA\IMPORT'.

  CALL FUNCTION 'EPS_GET_DIRECTORY_LISTING '
    EXPORTING
*     dir_name     = '/usr/sap/trans/' "p_dirnam "'/usr/sap/trans/RTGS'
*     dir_name     = '\\SAPDEV\sapmnt\trans\hsbcpmt\inward' "Added on 09.04.2020 by JKT
*     dir_name     = '\\SAPDEV\sapmnt\trans\OPTIVA\IMPORT' "Added on 09.04.2020 by JKT
      dir_name     = wrk_file1
      file_mask    = '*.*'
    TABLES
      dir_list     = t_file_list
    EXCEPTIONS
      access_error = 1
      OTHERS       = 2.
  IF sy-subrc IS INITIAL.
    LOOP AT t_file_list .
      t_files-appsrv_fname = t_file_list-name.
      APPEND t_files.
      CLEAR  t_files.
    ENDLOOP.
  ENDIF.

  DELETE t_files WHERE appsrv_fname+0(4) <> 'SPEC'.

  LOOP AT t_files.
    CLEAR: gv_xml_string,wa_xml_tab,g_xmldata.
    REFRESH: g_t_xml_tab,g_t_xml_info,g_t_return.

    CONCATENATE wrk_file1 '/' t_files-appsrv_fname INTO lv_filename1.
    CONDENSE: lv_filename1.
    OPEN DATASET  lv_filename1 FOR INPUT IN TEXT MODE ENCODING DEFAULT.
    "Adding Start by Rahul Vasita on 22.03.2024 14:47:07
    SELECT SINGLE file_name user_name  u_date  u_time
      FROM zpp_optiva_qp
      INTO CORRESPONDING FIELDS OF ls_log
      WHERE file_name = t_files-appsrv_fname.
    IF sy-subrc <> 0.
      ls_log-mandt = sy-mandt.
      ls_log-file_name = t_files-appsrv_fname.
      ls_log-user_name = sy-uname.
      ls_log-u_date = sy-datum.
      ls_log-u_time = sy-uzeit.
      "Adding End by Rahul Vasita on 22.03.2024 14:47:07

      DO.
        READ DATASET  lv_filename1 INTO wa_xml_tab .
        IF sy-subrc NE 0.
          EXIT.
        ELSE.
          CONDENSE wa_xml_tab.
          APPEND  wa_xml_tab TO  g_t_xml_tab.
        ENDIF.
      ENDDO.

      IF g_t_xml_tab IS NOT INITIAL.
        CONCATENATE LINES OF g_t_xml_tab INTO gv_xml_string SEPARATED BY space.
*      CONCATENATE LINES OF g_t_xml_tab INTO gv_xml_string.
      ENDIF.

      PERFORM data_upload.
    ENDIF."End of LS_LOG "Added by Rahul Vasita on 22.03.2024 14:48:05
    IF c_excel IS INITIAL.  """added by akshay dt.24.03.2025
      PERFORM delete_file .
    ENDIF. """EOC by akshay dt.24.03.2025
    CLEAR ls_data. "Added by Rahul Vasita on 22.03.2024 14:48:56

  ENDLOOP.



ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_upload .

  CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
    EXPORTING
      text   = gv_xml_string
    IMPORTING
      buffer = g_xmldata
    EXCEPTIONS
      failed = 1
      OTHERS = 2.

  IF sy-subrc NE 0.
    MESSAGE 'Error in the XML file' TYPE 'E'.
  ENDIF.

  CALL FUNCTION 'SMUM_XML_PARSE'
    EXPORTING
      xml_input = g_xmldata
    TABLES
      xml_table = g_t_xml_info
      return    = g_t_return
    EXCEPTIONS
      OTHERS    = 0.

*”If XML parsing is not successful, return table will contain error messages
  READ TABLE g_t_return INTO DATA(wa_return) WITH KEY type = 'E'.

  IF sy-subrc EQ 0.
    MESSAGE 'Error converting the input XML file' TYPE 'E'.

  ELSE.
    REFRESH g_t_return.
    PERFORM data_operation.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DATA_OPERATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM data_operation .

  DATA: flag TYPE flag.
  CLEAR flag.
  DATA:fsformulaingr TYPE string.
  CLEAR fsformulaingr.
  CLEAR:ls_final1,ls_data.REFRESH: lt_final1,it_data, lt_qpmk[].
  LOOP AT g_t_xml_info INTO gwa_xml_data .
    IF gwa_xml_data-cname = 'FSSPECIFICATIONTP'.
      flag = 'X'.
      fsformulaingr = 'FSSPECIFICATIONTP'.
    ENDIF.

    IF gwa_xml_data-cname = 'VERSION'.
      ls_data-mkversion = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'DESCRIPTION'.
      ls_data-ltxa1 = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'C_EFFECTIVE_FROM'.
      CONCATENATE gwa_xml_data-cvalue+8(2) gwa_xml_data-cvalue+5(2) gwa_xml_data-cvalue+0(4) INTO ls_data-sttag SEPARATED BY '.'.
    ELSEIF gwa_xml_data-cname = 'MATERIAL_CODE'.
      IF ls_data-matnr IS INITIAL.
        ls_data-matnr = gwa_xml_data-cvalue.
      ENDIF.
    ELSEIF gwa_xml_data-cname = 'ATTRIB_VAL'.
      IF ls_data-werks IS INITIAL .
        ls_data-werks =  gwa_xml_data-cvalue.
        IF ls_data-werks IS NOT INITIAL.  "Added by Rahul Vasita on 03.04.2024 16:27:55
          CLEAR : lv_werks.               "Added by Rahul Vasita on 03.04.2024 16:27:59
          lv_werks = ls_data-werks.       "Added by Rahul Vasita on 03.04.2024 16:28:02
        ENDIF.                            "Added by Rahul Vasita on 03.04.2024 16:28:06
      ENDIF.
      """"Line items
    ELSEIF gwa_xml_data-cname = 'PARAM_CODE'.
      ls_data-verwmerkm = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'MINVAL'.
      ls_data-toleranzun = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'TARGET'.
      ls_data-sollwert = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'MAXVAL'.
      ls_data-toleranzob = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'TEST_CODE'.
      ls_data-pmethode = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE1'.
      ls_data-steus = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE2'.
      ls_data-arbpl = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE3'.
      ls_data-verwe = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE4'.
      ls_data-statu = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE5'.
      ls_data-stichprver = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE6'.
      ls_data-spckrit = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE10'.
      ls_data-vornr = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'ATTRIBUTE12'.
      ls_data-insptext = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'UOM_CODE'.
      ls_data-masseinhsw = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'DECIMALS'.
      ls_data-stellen = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'TESTMETHODVERSION'.
      ls_data-pmtversion = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'QUALITYPARAM'.
      ls_data-selected_set = gwa_xml_data-cvalue.
    ELSEIF gwa_xml_data-cname = 'SEQUENCE'.
      ls_data-sequence_no = gwa_xml_data-cvalue.
    ENDIF.

    IF ls_data-matnr IS NOT INITIAL AND ls_data-werks IS NOT INITIAL.
      CONCATENATE ls_data-matnr ls_data-werks INTO ls_data-matnrwerks.
    ENDIF.

    IF flag = 'X' AND fsformulaingr = 'FSSPECIFICATIONTP'.
      "Adding Start by Rahul Vasita on 21.05.2024 15:36:59
      IF lt_qpmk[] IS INITIAL.
        SELECT zaehler  mkmnr  version  steuerkz  stellen  masseinhsw
            FROM qpmk
            INTO TABLE lt_qpmk
            WHERE zaehler = ls_data-werks AND mkmnr = ls_data-verwmerkm.
      ELSE.
        SELECT zaehler  mkmnr  version  steuerkz  stellen  masseinhsw
            FROM qpmk
            APPENDING TABLE lt_qpmk
            WHERE zaehler = ls_data-werks AND mkmnr = ls_data-verwmerkm.
      ENDIF.

      IF lt_qpmk[] IS NOT INITIAL.
        SORT lt_qpmk DESCENDING BY version.
        ls_qpmk = VALUE #( lt_qpmk[ zaehler = ls_data-werks mkmnr = ls_data-verwmerkm ] OPTIONAL ).
        IF ls_qpmk IS NOT INITIAL.
          IF ls_qpmk-steuerkz+0(2) = 'XX'.
*            IF ls_data-stellen <> ' ' AND ls_data-masseinhsw <> ' '. "Comment by Rahul Vasita on 31.05.2024 11:25:00
*            IF ls_data-stellen <> ' '. "Comment by Rahul Vasita on 31.05.2024 15:42:57
            IF ls_data-stellen = ' '.
*              ls_data-flg = abap_true. "Comment by Rahul Vasita on 31.05.2024 11:25:23
              ls_data-stellen = '0'. "Added by Rahul Vasita on 31.05.2024 11:25:33
            ELSE.
*              ls_data-stellen = ls_qpmk-stellen. "Added by Rahul Vasita on 31.05.2024 11:32:19 "Comment by Rahul Vasita on 31.05.2024 17:12:50
*              ls_data-flg = abap_false. "Comment by Rahul Vasita on 31.05.2024 11:26:08
            ENDIF.
          ELSEIF ls_qpmk-steuerkz+0(2) = '  '.
*            ls_data-flg = abap_true. "Comment by Rahul Vasita on 31.05.2024 11:26:11
          ENDIF.
        ENDIF."ls_qpmk is NOT INITIAL.
        CLEAR : ls_qpmk.
      ENDIF."IF lt_qpmk[] IS NOT INITIAL.
**      REFRESH : lt_qpmk[]. "Comment by Rahul Vasita on 25.05.2024 17:05:27
      "Adding End by Rahul Vasita on 21.05.2024 15:36:59
      APPEND ls_data TO it_data.
      CLEAR:  ls_data-verwmerkm,ls_data-toleranzun,ls_data-sollwert,
              ls_data-toleranzob,ls_data-pmethode,ls_data-steus,
              ls_data-arbpl,ls_data-verwe,ls_data-statu,
              ls_data-stichprver,ls_data-spckrit,ls_data-vornr,
              ls_data-insptext ,ls_data-masseinhsw, ls_data-stellen,
              ls_data-pmtversion ,ls_data-selected_set, ls_data-sequence_no.
      CLEAR: flag,fsformulaingr.
      CLEAR : ls_data-flg. "Added by Rahul Vasita on 27.05.2024 10:39:24

    ENDIF.
  ENDLOOP.


  IF ls_data IS NOT INITIAL.
    "Adding Start by Rahul Vasita on 27.05.2024 10:39:44
    IF lt_qpmk[] IS INITIAL.
      SELECT zaehler  mkmnr  version  steuerkz  stellen  masseinhsw
          FROM qpmk
          INTO TABLE lt_qpmk
          WHERE zaehler = ls_data-werks AND mkmnr = ls_data-verwmerkm.
    ELSE.
      SELECT zaehler  mkmnr  version  steuerkz  stellen  masseinhsw
          FROM qpmk
          APPENDING TABLE lt_qpmk
          WHERE zaehler = ls_data-werks AND mkmnr = ls_data-verwmerkm.
    ENDIF."IF lt_qpmk[] IS INITIAL.

    IF lt_qpmk[] IS NOT INITIAL.
      SORT lt_qpmk DESCENDING BY version.
      ls_qpmk = VALUE #( lt_qpmk[ zaehler = ls_data-werks mkmnr = ls_data-verwmerkm ] OPTIONAL ).
      IF ls_qpmk IS NOT INITIAL.
        IF ls_qpmk-steuerkz+0(2) = 'XX'.
*          IF ls_data-stellen <> ' ' AND ls_data-masseinhsw <> ' '. "Comment by Rahul Vasita on 31.05.2024 11:26:24
          IF ls_data-stellen = ' '.
*            ls_data-flg = abap_true. "Comment by Rahul Vasita on 31.05.2024 11:26:32
            ls_data-stellen = '0'. "Added by Rahul Vasita on 31.05.2024 11:25:33
          ELSE.
*            IF ls_data-stellen < ls_qpmk-stellen. "Comment by Rahul Vasita on 31.05.2024 16:23:01
*            ls_data-stellen = ls_qpmk-stellen. "Added by Rahul Vasita on 31.05.2024 11:32:19
*            ENDIF. "Comment by Rahul Vasita on 31.05.2024 16:23:04
*            ls_data-flg = abap_false. "Comment by Rahul Vasita on 31.05.2024 11:26:36
          ENDIF.
        ELSEIF ls_qpmk-steuerkz+0(2) = '  '.
*          ls_data-flg = abap_true. "Comment by Rahul Vasita on 31.05.2024 11:26:40
        ENDIF.
      ENDIF."ls_qpmk is NOT INITIAL.
      CLEAR : ls_qpmk.
    ENDIF."IF lt_qpmk[] IS NOT INITIAL.
    "Adding End by Rahul Vasita on 27.05.2024 10:39:44
    APPEND ls_data TO it_data.
    CLEAR: ls_data.
    DELETE it_data INDEX 1.
  ENDIF.
  "Adding Start by Rahul Vasita on 21.05.2024 15:56:56
*  CLEAR : lv_uflag. "Comment by Rahul Vasita on 31.05.2024 11:34:56
*  READ TABLE it_data INTO ls_data WITH KEY flg = abap_false. "Comment by Rahul Vasita on 25.05.2024 15:50:16
*  IF sy-subrc = 0. "Comment by Rahul Vasita on 25.05.2024 15:50:19
  "Comment Start by Rahul Vasita on 31.05.2024 11:34:12
****  LOOP AT it_data INTO ls_data WHERE flg = abap_false.
****    lv_uflag = abap_true.
****    IF ls_data-stellen = ' '.
****      ls_maillog-filename = ls_log-file_name.
****      ls_maillog-indic = 'X'.
****      ls_maillog-f_indc = 'Q'.
****      ls_maillog-werks = ls_data-werks.
****      ls_maillog-mic = ls_data-verwmerkm.
****      APPEND ls_maillog TO lt_maillog.
****      CLEAR : ls_maillog.
*****      PERFORM send_mail_file USING ls_log-file_name 'X' 'Q'. "Added by Rahul Vasita on 22.05.2024 15:26:28
****    ELSEIF ls_data-masseinhsw = ' '.
****      ls_qpmk = VALUE #( lt_qpmk[ zaehler = ls_data-werks mkmnr = ls_data-verwmerkm ] OPTIONAL ).
****      IF ls_qpmk-masseinhsw = ' '.
****        ls_maillog-filename = ls_log-file_name.
****        ls_maillog-indic = 'X'.
****        ls_maillog-f_indc = 'Q'.
****        ls_maillog-werks = ls_data-werks.
****        ls_maillog-mic = ls_data-verwmerkm.
****        APPEND ls_maillog TO lt_maillog.
****        CLEAR : ls_maillog.
****
*****        PERFORM send_mail_file USING ls_log-file_name 'X' 'U'. "Added by Rahul Vasita on 22.05.2024 15:26:28
****      ENDIF."IF ls_qpmk-masseinhsw = ' '.
****    ENDIF.
****  ENDLOOP.
****  IF lt_maillog[] IS NOT INITIAL  .
****    PERFORM send_mail_errordata USING lt_maillog[].
****  ENDIF.
  "Comment End by Rahul Vasita on 31.05.2024 11:34:12
*  ENDIF. "Comment by Rahul Vasita on 25.05.2024 15:50:21
  "Adding End by Rahul Vasita on 21.05.2024 15:56:56


*  WRITE: 'Test'.
*  IF lv_uflag <>  abap_true. "Added by Rahul Vasita on 21.05.2024 16:00:47 "Comment by Rahul Vasita on 31.05.2024 11:35:14
  """ADDED BY AKSHAY DT.19.03.2025
  IF c_excel IS NOT INITIAL.
    IF it_data[] IS NOT INITIAL .
      PERFORM download_excel_file.
    ENDIF.
    """EOC DT.19.03.2025
  ELSE."""ADDED BY AKSHAY DT.19.03.2025
    PERFORM bdc_upload.

  ENDIF. """ADDED BY AKSHAY DT.19.03.2025
*  ENDIF. "Added by Rahul Vasita on 21.05.2024 16:00:49 "Comment by Rahul Vasita on 31.05.2024 11:35:17

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc_upload .
  CLEAR : lv_uflag . "Added by Rahul Vasita on 21.05.2024 16:01:15
  REFRESH: messtab.
  LOOP AT it_data INTO wa_data.

    IF wa_data-matnr IS INITIAL.
      lv_uflag = abap_true. "Added by Rahul Vasita on 21.05.2024 16:03:44
      PERFORM send_mail USING 'MATNR'.
    ENDIF.

    IF wa_data-werks IS INITIAL. "Added by Rahul Vasita on 21.05.2024 16:03:58
      lv_uflag = abap_true. "Added by Rahul Vasita on 21.05.2024 16:03:44
      PERFORM send_mail USING 'WERKS'."Added by Rahul Vasita on 21.05.2024 16:04:01
    ENDIF."Added by Rahul Vasita on 21.05.2024 16:04:00

    IF lv_uflag <> abap_true.


      v_count = v_count + 1.
      ls_v_count = v_count.
      MOVE-CORRESPONDING wa_data TO ls_data.

      AT NEW matnr.
        PERFORM bdc_dynpro      USING 'SAPLCPDI' '8010'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'RC271-STTAG'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        PERFORM bdc_field       USING 'RC27M-MATNR'
                                      ls_data-matnr."                              'RM01001029'.
        PERFORM bdc_field       USING 'RC271-PLNNR'
                                      ' ' ."                              'RM01001029'.
        PERFORM bdc_field       USING 'RC27M-WERKS'
                                      ls_data-werks."                              '1000'.
        PERFORM bdc_field       USING 'RC271-STTAG'
                                      ls_data-sttag."                              '01.09.2012'.


        SELECT SINGLE MAX( plnal ) AS plnal FROM mapl INTO @DATA(lv_plnal)
               WHERE matnr = @ls_data-matnr AND werks = @ls_data-werks AND loekz = '' AND plnty = 'Q'.

        IF lv_plnal IS NOT INITIAL.
          p_plnal = lv_plnal + 1.
          """""'test"""""""'
          PERFORM bdc_dynpro      USING 'SAPLCPDI' '1200'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'RC27X-ENTRY_ACT'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=ANLG'.

          PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                        '1'.
          PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'PLKOD-PLNAL'
                                        p_plnal.
        ELSE.
          p_plnal = 1.
          PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'PLKOD-PLNAL'
                                        p_plnal.

        ENDIF.
        """""""""""""""""""
*      IF 1 = 2.
*      PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
*      PERFORM bdc_field       USING 'PLKOD-PLNAL'
*                                    p_plnal.
*      ENDIF.

*perform bdc_field       using 'PLKOD-KTEXT'
*                              'SAG BOLT YOKE YR9'.
*perform bdc_field       using 'PLKOD-WERKS'
*                              '1000'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLKOD-LOSVN'.
        PERFORM bdc_field       USING 'PLKOD-VERWE'
                                       ls_data-verwe."                             '5'.
        PERFORM bdc_field       USING 'PLKOD-STATU'
                                       ls_data-statu."                             '4'.
        PERFORM bdc_field       USING 'PLKOD-VAGRP'
                                      ''.
        PERFORM bdc_field       USING 'PLKOD-LOSVN'
                                      '1'.
        PERFORM bdc_field       USING 'PLKOD-LOSBS'
                                      '99,999,999'.
        SELECT SINGLE meins FROM mara INTO ls_meins WHERE matnr EQ ls_data-matnr.
        CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
          EXPORTING
            input    = ls_meins
            language = sy-langu
          IMPORTING
*           LONG_TEXT            =
            output   = ls_meins
*           SHORT_TEXT           =
*         EXCEPTIONS
*           UNIT_NOT_FOUND       = 1
*           OTHERS   = 2
          .
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ENDIF.

        PERFORM bdc_field       USING 'PLKOD-PLNME'
                                      ls_meins."                                                 'NOS'.


        PERFORM bdc_dynpro      USING 'SAPLCPDA' '1200'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=VOUE'.
**perform bdc_field       using 'PLKOD-KTEXT'
**                              'SAG BOLT YOKE YR9'.
**perform bdc_field       using 'PLKOD-WERKS'
**                              '1000'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLKOD-LOSVN'.
*perform bdc_field       using 'PLKOD-VERWE'
*                                                                  '5'.
*perform bdc_field       using 'PLKOD-STATU'
*                                                                  '4'.
*perform bdc_field       using 'PLKOD-LOSVN'
*                              '1'.
*perform bdc_field       using 'PLKOD-LOSBS'
*                              '99,999,999'.
*perform bdc_field       using 'PLKOD-PLNME'
*                              'NOS'.


        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLPOD-LTXA1(01)'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        PERFORM bdc_field       USING 'PLPOD-VORNR(01)'
                                      ls_data-vornr."                                   'QA_LAB'.
        PERFORM bdc_field       USING 'PLPOD-ARBPL(01)'
                                      ls_data-arbpl."                                   'QA_LAB'.
        PERFORM bdc_field       USING 'PLPOD-STEUS(01)'
                                      ls_data-steus."                                   'QM01'.
        PERFORM bdc_field       USING 'PLPOD-LTXA1(01)'
                                      ls_data-ltxa1."                                   'Inspection'.


        PERFORM bdc_dynpro      USING 'SAPLCPDI' '1400'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLPOD-VORNR(01)'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=QMUE'.
        PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                      '1'.
        PERFORM bdc_field       USING 'RC27X-FLG_SEL(01)'
                                      'X'.
      ENDAT.

      IF v_count EQ 14 AND flag IS INITIAL .
        flag = 'X'.
        PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
        count = count + ( v_count - 1 ).
        CONDENSE count.
        PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                      count ."'13'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        ls_v_count = 2.
        v_count = 2.
      ELSEIF v_count EQ 14 AND flag IS NOT INITIAL.
        PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
        count = count + ( v_count - 2 ).
        CONDENSE count.
        PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                       count ."'13'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        ls_v_count = 2.
        v_count = 2.
      ENDIF.
*    IF v_count MOD 14 EQ 0 OR flag EQ 'X'.
*      flag = 'X'.
*      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
*      PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
*                                     '13'.
*      PERFORM bdc_field       USING 'BDC_OKCODE'
*                                    '/00'.
**    entry_act = entry_act + 1.
*      IF v_count EQ 14.
*        CLEAR v_count.
*        ls_v_count = 02.
*        v_count = 1.
*      ENDIF.
*    ENDIF.

      PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLMKB-STICHPRVER(01)'.
*    if v_count mod 17 eq 0.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                   16.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    ls_v_count = '02'.
*    v_count = 2.
*    else.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
*    endif.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    endif.
*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
******************************     added 22.04.2024 for mk version changes
      SELECT SINGLE MAX( version ) AS version FROM qpmk INTO @DATA(mkversion)
               WHERE mkmnr = @ls_data-verwmerkm AND werks = @ls_data-werks .
      ls_data-mkversion = mkversion.

      SELECT SINGLE MAX( version ) AS version FROM qmtb INTO @DATA(pmtversion)
            WHERE pmtnr = @ls_data-pmethode AND werks = @ls_data-werks .
      ls_data-pmtversion = pmtversion.

********************** ended 22.04.2024

      CONCATENATE 'PLMKB-VERWMERKM(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                       "'PLMKB-VERWMERKM(01)'
                                     ls_data-verwmerkm."                              'MIS'.
      CLEAR v_field.
      IF ls_data-insptext IS NOT INITIAL.
        CONCATENATE 'PLMKB-KURZTEXT(' ls_v_count ')' INTO v_field.
        PERFORM bdc_field       USING  v_field                       "'PLMKB-VERWMERKM(01)'
                                       ls_data-insptext."                              'MIS'.
        CLEAR : v_field.
      ENDIF.
      CONCATENATE 'PLMKB-MKVERSION(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                      " 'PLMKB-MKVERSION(01)'
                                     ls_data-mkversion."                              '1'.
*    concatenate 'PLMKB-KURZTEXT(' ls_v_count ')' into v_field.
*    perform bdc_field       using v_field                       "'PLMKB-KURZTEXT(01)'
*                                                                 'DIE MISMATCH'.
*    clear v_field.
      CONCATENATE 'PLMKB-PMETHODE(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                 "'PLMKB-PMETHODE(01)'
                                     ls_data-pmethode."                               'DVC'.
      CLEAR v_field.
      CONCATENATE 'PLMKB-PMTVERSION(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                   "'PLMKB-PMTVERSION(01)'
                                     ls_data-pmtversion."                              '1'.

      CLEAR v_field.
      CONCATENATE 'PLMKB-STICHPRVER(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING  v_field                   "'PLMKB-STICHPRVER(01)'
                                     ls_data-stichprver."                              'RPDSS'.
*abhishek on 07062014
      CLEAR v_field.
      CONCATENATE 'PLMKB-SPCKRIT(' ls_v_count ')' INTO v_field.
      PERFORM bdc_field       USING v_field                                               "'PLMKB-SPCKRIT(01)'
                                    ls_data-spckrit.
*abhishek on 07062014

      CLEAR v_field.





      PERFORM bdc_dynpro      USING 'SAPLQPAA' '1501'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=ENT1'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-VERWMERKM'.
*perform bdc_field       using 'PLMKB-VERWMERKM'
*                              'MIS'.
*perform bdc_field       using 'PLMKB-QPMK_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-MKVERSION'
*                              '1'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.


      PERFORM bdc_dynpro      USING 'SAPLQPAA' '1502'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.


      PERFORM bdc_dynpro      USING 'SAPLQPAA' '1502'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=ENT1'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.



*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
**    perform bdc_field       using 'BDC_CURSOR'
**                                  'PLMKB-MERKNR(01)'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '=QMNM'.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                  '1'.
*    concatenate 'RQPAS-SEL_FLG(' ls_v_count ')' into v_field.
*    perform bdc_field       using  v_field                        "'RQPAS-SEL_FLG(01)'
*                                  'X'.
*    clear v_field.
      IF ls_data-stellen IS NOT INITIAL.

        PERFORM bdc_dynpro      USING 'SAPLQPAA' '0160'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
*    perform bdc_field       using 'PLMKB-KURZTEXT'
*                                  'DIE MISMATCH'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'PLMKB-STELLEN'.
        PERFORM bdc_field       USING 'PLMKB-STELLEN'
                                      ls_data-stellen."              '2'.
        PERFORM bdc_field       USING 'RQPAS-MASSEINHSW'
                                      ls_data-masseinhsw."           'mm'.
*abhishek on 07062014
        PERFORM bdc_field       USING 'QFLTP-SOLLWERT'
                                       ls_data-sollwert."                            '5.50'.
*abhishek on 07062014
        PERFORM bdc_field       USING 'QFLTP-TOLERANZUN'
                                      ls_data-toleranzun."           '            0.00'.
        PERFORM bdc_field       USING 'QFLTP-TOLERANZOB'
                                      ls_data-toleranzob."           '            0.50'.


      ENDIF.

      IF ls_data-sequence_no EQ '2'.

        PERFORM bdc_dynpro      USING 'SAPLQPAA' '0160'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        PERFORM bdc_field       USING 'PLMKB-AUSWMENGE1'
                                      ls_data-selected_set.
        PERFORM bdc_field       USING 'PLMKB-AUSWMGWRK1'
                                      ls_data-werks.
      ENDIF.
*    perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*    perform bdc_field       using 'BDC_CURSOR'
*                                  'PLMKB-MERKNR(01)'.
*    perform bdc_field       using 'BDC_OKCODE'
*                                  '/00'.
*    perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                  '1'.
*    concatenate 'RQPAS-SEL_FLG(' ls_v_count ')' into v_field.
*    perform bdc_field       using  v_field                        "'RQPAS-SEL_FLG(01)'
*                                  ' '.
*    clear v_field.


*perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-STICHPRVER(02)'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '/00'.
*perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                              '1'.
*perform bdc_field       using 'PLMKB-VERWMERKM(02)'
*                              'DA1'.
*perform bdc_field       using 'PLMKB-MKVERSION(02)'
*                              '1'.
*perform bdc_field       using 'PLMKB-KURZTEXT(02)'
*                              'dIAMETER'.
*perform bdc_field       using 'PLMKB-PMETHODE(02)'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-PMTVERSION(02)'
*                              '1'.
*perform bdc_field       using 'PLMKB-STICHPRVER(02)'
*                              'RPDSS'.
*perform bdc_field       using 'RQPAS-SEL_FLG(01)'
*                              ''.
*perform bdc_field       using 'RQPAS-SEL_FLG(02)'
*                              'X'.
*perform bdc_dynpro      using 'SAPLQPAA' '1501'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-VERWMERKM'.
*perform bdc_field       using 'PLMKB-VERWMERKM'
*                              'DA1'.
*perform bdc_field       using 'PLMKB-QPMK_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-MKVERSION'
*                              '1'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '1502'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '1502'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=ENT1'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-PMETHODE'.
*perform bdc_field       using 'PLMKB-PMETHODE'
*                              'DVC'.
*perform bdc_field       using 'PLMKB-QMTB_WERKS'
*                              '1000'.
*perform bdc_field       using 'PLMKB-PMTVERSION'
*                              '1'.
*perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'PLMKB-MERKNR(02)'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=QMNM'.
*perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                              '1'.
*perform bdc_field       using 'RQPAS-SEL_FLG(02)'
*                              'X'.
*perform bdc_dynpro      using 'SAPLQPAA' '0160'.
*perform bdc_field       using 'BDC_OKCODE'
*                              '=QMBW'.
*perform bdc_field       using 'PLMKB-KURZTEXT'
*                              'dIAMETER'.
*perform bdc_field       using 'BDC_CURSOR'
*                              'QFLTP-TOLERANZUN'.
*perform bdc_field       using 'PLMKB-STELLEN'
*                              '2'.
*perform bdc_field       using 'RQPAS-MASSEINHSW'
*                              'mm'.
*perform bdc_field       using 'QFLTP-TOLERANZUN'
*                              '           21.60'.
*perform bdc_field       using 'QFLTP-TOLERANZOB'
*                              '           22.70'.

*Dnyanesh on 25/06/14\
*    IF ls_v_count = 13.
*      v_count = 1.
*      CLEAR ls_v_count.
*    PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=P+'.
*    ENDIF.
*Dnyanesh on 25/06/14



      AT END OF matnr.
        PERFORM bdc_dynpro      USING 'SAPLQPAA' '0150'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'QFLTP-TOLERANZUN(01)'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=QMBU'.
        PERFORM bdc_field       USING 'RQPAS-ENTRY_ACT'
                                      '1'.
*      PERFORM bdc_transaction USING 'QP01'.
        REFRESH: messtab.
        CALL TRANSACTION 'QP01' USING bdcdata MODE p_mode
                                 MESSAGES INTO messtab.

        IF messtab[] IS NOT INITIAL.
          PERFORM process_message.
        ENDIF.

        CLEAR : ls_v_count,v_count,flag,mkversion.
        REFRESH: bdcdata.
      ENDAT.

*************************************************************Save
*    at end of steus.
*      perform bdc_dynpro      using 'SAPLQPAA' '0150'.
*      perform bdc_field       using 'BDC_CURSOR'
*                                    'PLMKB-PRUEFEINH(01)'.
*      perform bdc_field       using 'BDC_OKCODE'
*                                    '=QMBU'.
*      perform bdc_field       using 'RQPAS-ENTRY_ACT'
*                                    '1'.
*      perform bdc_transaction using 'QP01'.
*    endat.
*************************************************************
    ENDIF."IF lv_uflag = abap_true. "Added by Rahul Vasita on 21.05.2024 16:07:40
    CLEAR :wa_data.


  ENDLOOP.

ENDFORM.


FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.

*----------------------------------------------------------------------*
*        Insert field                                                  *
*----------------------------------------------------------------------*
FORM bdc_field USING fnam fval.

  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_TRANSACTION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_1102   text
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SEND_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_mail USING lv_str.
  DATA : lv_sender TYPE adr6-smtp_addr.
  CLEAR: ls_soli , lv_sender.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low FROM tvarvc INTO lv_sender WHERE name = 'ZSENDER_MAIL' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_SENDER UP TO 1 ROWS WHERE NAME = 'ZSENDER_MAIL' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
*  IF ls_final1-item_code_matno = ''. "Comment by Rahul Vasita on 21.05.2024 16:06:17
  IF lv_str = 'MATNR'.
    ls_soli-line = '<P>Material Number is missing.-</P>'.
    APPEND ls_soli TO lt_soli.
  ENDIF.

*  IF ls_final1-attrib_val_plant = ''. "Comment by Rahul Vasita on 21.05.2024 16:06:35
  IF lv_str = 'WERKS'.
    ls_soli-line = '<P>Plant is missing.-</P>'.
    APPEND ls_soli TO lt_soli.
  ENDIF.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Error in inspection file'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Missing fields in inspection file'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).
  "Adding Start by Rahul Vasita on 08.04.2024 17:21:51
  sender = cl_cam_address_bcs=>create_internet_address(
       i_address_string = lv_sender   ).
  CALL METHOD lo_bcs->set_sender( sender ).
  "Adding End by Rahul Vasita on 08.04.2024 17:21:51
  lo_bcs->set_document( i_document = lo_doc_bcs ).

  CLEAR : lv_email.
  IF lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:35
* Set the email address
    SELECT SINGLE smtp_addr INTO lv_email FROM zpp_optiva_mail WHERE werks = lv_werks ."Added by Rahul Vasita on 03.04.2024 16:31:39
    IF lv_email IS NOT INITIAL.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                        i_address_string =  lv_email ).
    ELSE.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                  i_address_string =  wrk_qp_email ).
    ENDIF."lv_email IS NOT INITIAL.
  ELSE. "Added by Rahul Vasita on 03.04.2024 16:31:41
* Set the email address
    lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wrk_qp_email ).
  ENDIF."lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:44

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PROCESS_MESSAGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_message .

  DATA : lv_msg TYPE string,
         wa_msg TYPE bdcmsgcoll.
  REFRESH: i_message, i_message1.
  CLEAR: wa_msg.
  LOOP AT messtab INTO wa_msg.

    CALL FUNCTION 'FORMAT_MESSAGE'
      EXPORTING
        id   = wa_msg-msgid
        lang = sy-langu
        no   = wa_msg-msgnr
        v1   = wa_msg-msgv1
        v2   = wa_msg-msgv2
        v3   = wa_msg-msgv3
        v4   = wa_msg-msgv4
      IMPORTING
        msg  = lv_msg.

    IF wa_msg-msgtyp = 'E'.

      UNASSIGN <x_message>.
      APPEND INITIAL LINE TO i_message ASSIGNING <x_message>.
      IF <x_message> IS ASSIGNED.
*        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message>-status       = icon_led_green        .
*        <x_message>-vendor = ls_xk02-vendor.
        <x_message>-type         = wa_msg-msgtyp       .
        <x_message>-message      = lv_msg                .
      ENDIF.

    ELSEIF wa_msg-msgtyp = 'S'.
*      CONTINUE.

      UNASSIGN <x_message1>.
      APPEND INITIAL LINE TO i_message1 ASSIGNING <x_message1>.
      IF <x_message1> IS ASSIGNED.
*        <x_message>-lifnr        = wa_msg-msgv1         .
        <x_message1>-status       = icon_led_green        .
*        <x_message>-vendor = ls_xk02-vendor.
        <x_message1>-type         = wa_msg-msgtyp       .
        <x_message1>-message      = lv_msg                .
      ENDIF.

    ENDIF.

    DELETE messtab WHERE msgnr = wa_msg-msgnr.
  ENDLOOP.

  IF i_message IS NOT INITIAL.
    PERFORM send_error_mail.
  ENDIF.

  IF i_message1 IS NOT INITIAL.
    PERFORM send_success_mail.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_ERROR_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_error_mail .
  DATA : lv_sender TYPE adr6-smtp_addr.

  CLEAR: ls_soli , lv_sender.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low FROM tvarvc INTO lv_sender WHERE name = 'ZSENDER_MAIL' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_SENDER UP TO 1 ROWS WHERE NAME = 'ZSENDER_MAIL' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

  REFRESH: lt_soli.
  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>Below are the errors found while uploading QP in SAP</P>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  LOOP AT i_message INTO DATA(ls_imessage).
    CONCATENATE '<P>' ls_imessage-message '</P>' INTO ls_soli-line.
    APPEND ls_soli TO lt_soli.
  ENDLOOP.

*ls_soli-line = '<P>Material Number is missing.-</P>'.
*APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P> This is System Generated Mail Do not Replay-' && sy-sysid && '</P>'.
  APPEND ls_soli TO lt_soli.


  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Error while uploading QP in SAP'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Error while uploading QP in SAP'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).
  "Adding Start by Rahul Vasita on 08.04.2024 17:21:51
  sender = cl_cam_address_bcs=>create_internet_address(
       i_address_string = lv_sender   ).
  CALL METHOD lo_bcs->set_sender( sender ).
  "Adding End by Rahul Vasita on 08.04.2024 17:21:51

  lo_bcs->set_document( i_document = lo_doc_bcs ).

  CLEAR : lv_email.
  IF lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:35
* Set the email address
    SELECT SINGLE smtp_addr INTO lv_email FROM zpp_optiva_mail WHERE werks = lv_werks ."Added by Rahul Vasita on 03.04.2024 16:31:39
    IF lv_email IS NOT INITIAL.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                        i_address_string =  lv_email ).
    ELSE.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                  i_address_string =  wrk_qp_email ).
    ENDIF."lv_email IS NOT INITIAL.
  ELSE. "Added by Rahul Vasita on 03.04.2024 16:31:41
* Set the email address
    lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wrk_qp_email ).
  ENDIF."lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:44

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DELETE_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM delete_file .

  DATA:  lv_tpath  LIKE sapb-sappfad.

*CONCATENATE wrk_file1 t_files-appsrv_fname INTO lv_tpath.
*lv_tpath = '\\SAPDEV\sapmnt\trans\archfile'.
  CONCATENATE wrk_file2 t_files-appsrv_fname INTO lv_tpath.
**--DELETE FILE ON THE APPLICATION SERVER AFTER DOWNLOAD
  CALL FUNCTION 'ARCHIVFILE_SERVER_TO_SERVER'
    EXPORTING
      sourcepath       = lv_filename1+0(70)
      targetpath       = lv_tpath
    EXCEPTIONS
      error_file       = 1
      no_authorization = 2
      OTHERS           = 3.
  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

  ELSE.

  ENDIF.
  INSERT zpp_optiva_qp FROM ls_log. "Added by Rahul Vasita on 22.03.2024 14:50:07
  IF sy-subrc = 0.  "Added by Rahul Vasita on 22.05.2024 11:26:28
    COMMIT WORK. "Added by Rahul Vasita on 22.05.2024 11:26:29
    MESSAGE 'Data Inserted into ZPP_OPTIVA_QP' TYPE 'S'.
  ELSE. "Added by Rahul Vasita on 22.05.2024 14:30:58
    MODIFY zpp_optiva_qp FROM ls_log. "Added by Rahul Vasita on 22.05.2024 14:30:57
    IF sy-subrc = 0.
      COMMIT WORK.
      MESSAGE 'Data Modified into ZPP_OPTIVA_QP' TYPE 'S'.
      PERFORM send_mail_file USING ls_log-file_name ' ' ' '.
    ENDIF.
  ENDIF. "Added by Rahul Vasita on 22.05.2024 11:26:31
  DELETE DATASET lv_filename1.
*   ENDIF.
*   REFRESH: gt_main,it_error.
*   CLEAR: lv_count.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_SUCCESS_MAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_success_mail .
  DATA : lv_sender TYPE adr6-smtp_addr.
  CLEAR: ls_soli , lv_sender.
  REFRESH: lt_soli.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low FROM tvarvc INTO lv_sender WHERE name = 'ZSENDER_MAIL' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_SENDER UP TO 1 ROWS WHERE NAME = 'ZSENDER_MAIL' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<P>Below are the success message found while uploading QP in SAP</P>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  LOOP AT i_message1 INTO DATA(ls_imessage1).
    CONCATENATE '<P>' ls_imessage1-message '</P>' INTO ls_soli-line.
    APPEND ls_soli TO lt_soli.
  ENDLOOP.

*ls_soli-line = '<P>Material Number is missing.-</P>'.
*APPEND ls_soli TO lt_soli.

  ls_soli-line = '<P>' && 'Filename - ' && t_files-appsrv_fname && '</P>'.
  APPEND ls_soli TO lt_soli.

  "Adding Start by Rahul Vasita on 22.05.2024 14:39:51
  ls_soli-line = '<P> This is System Generated Mail Do not Replay-' && sy-sysid && '</P>'.
  APPEND ls_soli TO lt_soli.
  "Adding End by Rahul Vasita on 22.05.2024 14:39:51

*  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
*  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'Successfully uploaded the QP in SAP'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Successfully uploaded the QP in SAP'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).
  "Adding Start by Rahul Vasita on 08.04.2024 17:21:51
  sender = cl_cam_address_bcs=>create_internet_address(
       i_address_string = lv_sender   ).
  CALL METHOD lo_bcs->set_sender( sender ).
  "Adding End by Rahul Vasita on 08.04.2024 17:21:51
  lo_bcs->set_document( i_document = lo_doc_bcs ).

  CLEAR : lv_email.
  IF lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:35
* Set the email address
    SELECT SINGLE smtp_addr INTO lv_email FROM zpp_optiva_mail WHERE werks = lv_werks ."Added by Rahul Vasita on 03.04.2024 16:31:39
    IF lv_email IS NOT INITIAL.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                        i_address_string =  lv_email ).
    ELSE.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                  i_address_string =  wrk_qp_email ).
    ENDIF."lv_email IS NOT INITIAL.
  ELSE. "Added by Rahul Vasita on 03.04.2024 16:31:41
* Set the email address
    lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wrk_qp_email ).
  ENDIF."lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:44

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_MAIL_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_mail_file USING filename e_flag lv_flag.
  DATA : lv_sender TYPE adr6-smtp_addr.
  CLEAR: ls_soli , lv_sender.
  REFRESH: lt_soli.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low FROM tvarvc INTO lv_sender WHERE name = 'ZSENDER_MAIL' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_SENDER UP TO 1 ROWS WHERE NAME = 'ZSENDER_MAIL' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  IF e_flag = ' '.
    ls_soli-line = |<P>File { filename } Already Uploaded on Date { ls_log-u_date+6(2) }.{ ls_log-u_date+4(2) }.{ ls_log-u_date+0(4) } By { ls_log-user_name } </P>|.
    APPEND ls_soli TO lt_soli.
    CLEAR: ls_soli.
  ELSE.
    IF lv_flag = 'Q'.
      ls_soli-line = |<P> Please Check Quanitative Decimal Value in File-{ filename } </P>|.
      APPEND ls_soli TO lt_soli.
      CLEAR: ls_soli.
    ELSEIF lv_flag = 'U'.
      ls_soli-line = |<P> Please Check Quanitative UoM Value in File-{ filename } </P>|.
      APPEND ls_soli TO lt_soli.
      CLEAR: ls_soli.
    ENDIF.
  ENDIF.

  ls_soli-line = '<P> This is System Generated Mail Do not Replay-' && sy-sysid && '</P>'.
  APPEND ls_soli TO lt_soli.

*  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
*  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'File Already Exists'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Optiva File'&& filename && 'Status'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).
  "Adding Start by Rahul Vasita on 08.04.2024 17:21:51
  sender = cl_cam_address_bcs=>create_internet_address(
       i_address_string = lv_sender   ).
  CALL METHOD lo_bcs->set_sender( sender ).
  "Adding End by Rahul Vasita on 08.04.2024 17:21:51
  lo_bcs->set_document( i_document = lo_doc_bcs ).

  CLEAR : lv_email.
  IF lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:35
* Set the email address
    SELECT SINGLE smtp_addr INTO lv_email FROM zpp_optiva_mail WHERE werks = lv_werks ."Added by Rahul Vasita on 03.04.2024 16:31:39
    IF lv_email IS NOT INITIAL.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                        i_address_string =  lv_email ).
    ELSE.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                  i_address_string =  wrk_qp_email ).
    ENDIF."lv_email IS NOT INITIAL.
  ELSE. "Added by Rahul Vasita on 03.04.2024 16:31:41
* Set the email address
    lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wrk_qp_email ).
  ENDIF."lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:44

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SEND_MAIL_ERRORDATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_MAILLOG[]  text
*----------------------------------------------------------------------*
FORM send_mail_errordata  USING    p_lt_maillog LIKE lt_maillog.
  DATA : lv_sender TYPE adr6-smtp_addr,
         filename  TYPE localfile.
  CLEAR: ls_soli , lv_sender.
  REFRESH: lt_soli.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE low FROM tvarvc INTO lv_sender WHERE name = 'ZSENDER_MAIL' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_SENDER UP TO 1 ROWS WHERE NAME = 'ZSENDER_MAIL' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


  " Create the main object of the mail.
  CREATE OBJECT lo_mime_helper.

  " Create the mail content.-----"CLASSIC WAY"
  ls_soli-line = '<!DOCTYPE html PUBLIC “-//IETF//DTD HTML 5.0//EN">'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<HTML>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  ls_soli-line = '<BODY>'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

*ls_soli-line = 'Hi Dear,<P>Matrail Number is missing in below file-</P>'.
  ls_soli-line = 'Hi Dear,'.
  APPEND ls_soli TO lt_soli.
  CLEAR: ls_soli.

  "Comment Start by Rahul Vasita on 27.05.2024 12:39:35
**  IF e_flag = ' '.
**    ls_soli-line = |<P>File { filename } Already Uploaded on Date { ls_log-u_date+6(2) }.{ ls_log-u_date+4(2) }.{ ls_log-u_date+0(4) } By { ls_log-user_name } </P>|.
**    APPEND ls_soli TO lt_soli.
**    CLEAR: ls_soli.
**  ELSE.
**    IF lv_flag = 'Q'.
**      ls_soli-line = |<P> Please Check Quanitative Decimal Value in File-{ filename } </P>|.
**      APPEND ls_soli TO lt_soli.
**      CLEAR: ls_soli.
**    ELSEIF lv_flag = 'U'.
**      ls_soli-line = |<P> Please Check Quanitative UoM Value in File-{ filename } </P>|.
**      APPEND ls_soli TO lt_soli.
**      CLEAR: ls_soli.
**    ENDIF.
**  ENDIF.
  "Comment End by Rahul Vasita on 27.05.2024 12:39:35
  LOOP AT p_lt_maillog INTO ls_maillog.
    IF ls_maillog-f_indc = 'Q'.
      ls_soli-line = |<P> Please Check Quanitative Decimal Value for { ls_maillog-mic } in File-{ ls_maillog-filename } , Plant { ls_maillog-werks } </P>|.
      APPEND ls_soli TO lt_soli.
      CLEAR: ls_soli.
    ELSEIF ls_maillog-f_indc = 'U'.
      ls_soli-line = |<P> Please Check Quanitative UoM Value for { ls_maillog-mic } in File-{ ls_maillog-filename } , Plant { ls_maillog-werks } </P>|.
      APPEND ls_soli TO lt_soli.
      CLEAR: ls_soli.
    ENDIF.
    filename = ls_maillog-filename. "Added by Rahul Vasita on 27.05.2024 12:43:46
    CLEAR : ls_maillog.
  ENDLOOP.
  ls_soli-line = '<P> This is System Generated Mail Do not Replay-' && sy-sysid && '</P>'.
  APPEND ls_soli TO lt_soli.

*  ls_soli-line = '<P>Kindly resolve the issue and upload again</P>'.
*  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</BODY>'.
  APPEND ls_soli TO lt_soli.

  ls_soli-line = '</HTML>'.
  APPEND ls_soli TO lt_soli.

  " Set the HTML body of the mail
  CALL METHOD lo_mime_helper->set_main_html
    EXPORTING
      content     = lt_soli
      description = 'File Already Exists'.

* Set the subject of the mail.
  lo_doc_bcs = cl_document_bcs=>create_from_multirelated(
                  i_subject          = 'Optiva File'&& filename && 'Status'
                  i_importance       = '1'                " 1~High Priority  5~Average priority 9~Low priority
                  i_multirel_service = lo_mime_helper ).

  lo_bcs = cl_bcs=>create_persistent( ).
  "Adding Start by Rahul Vasita on 08.04.2024 17:21:51
  sender = cl_cam_address_bcs=>create_internet_address(
       i_address_string = lv_sender   ).
  CALL METHOD lo_bcs->set_sender( sender ).
  "Adding End by Rahul Vasita on 08.04.2024 17:21:51
  lo_bcs->set_document( i_document = lo_doc_bcs ).

  CLEAR : lv_email.
  IF lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:35
* Set the email address
    SELECT SINGLE smtp_addr INTO lv_email FROM zpp_optiva_mail WHERE werks = lv_werks ."Added by Rahul Vasita on 03.04.2024 16:31:39
    IF lv_email IS NOT INITIAL.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                        i_address_string =  lv_email ).
    ELSE.
      lo_recipient = cl_cam_address_bcs=>create_internet_address(
                  i_address_string =  wrk_qp_email ).
    ENDIF."lv_email IS NOT INITIAL.
  ELSE. "Added by Rahul Vasita on 03.04.2024 16:31:41
* Set the email address
    lo_recipient = cl_cam_address_bcs=>create_internet_address(
                      i_address_string =  wrk_qp_email ).
  ENDIF."lv_werks IS NOT INITIAL. "Added by Rahul Vasita on 03.04.2024 16:31:44

  lo_bcs->add_recipient( i_recipient = lo_recipient ).

* Change the status.
  lv_status = 'N'.
  CALL METHOD lo_bcs->set_status_attributes
    EXPORTING
      i_requested_status = lv_status.

*&---------------------------------------------------------------------*
*& Send the email
*&---------------------------------------------------------------------*
  TRY.
      lo_bcs->send( ).
      COMMIT WORK.
    CATCH cx_bcs INTO DATA(lx_bcs).
      ROLLBACK WORK.
  ENDTRY.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_EXCEL_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_excel_file .
  DATA: d_count TYPE i.
  DATA: d_filename      TYPE string,
        d_path          TYPE string,
        d_fullpath      TYPE string,
        d_result        TYPE i,
        d_default_fname TYPE string,
        d_fname         LIKE rlgrap-filename.
  DATA : BEGIN OF it_header OCCURS 0,
           line(50) TYPE c,
         END OF it_header.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'File Directory'
      default_extension = 'XLS'
      initial_directory = 'D:\'
    CHANGING
      filename          = d_filename
      path              = d_path
      fullpath          = d_fullpath
      user_action       = d_result.

  CHECK sy-subrc = 0.

*  d_fname = d_filename.

*  CALL FUNCTION 'SAP_CONVERT_TO_XLS_FORMAT'
*    EXPORTING
*      i_filename        = d_fname
*    TABLES
*      i_tab_sap_data    = it_data
*    EXCEPTIONS
*      conversion_failed = 1
*      OTHERS            = 2.
  it_header-line = 'STEUS'.
  APPEND it_header.
  it_header-line = 'MATNR'.
  APPEND it_header.
  it_header-line = 'VORNR'.
  APPEND it_header.
  it_header-line = 'ARBPL'.
  APPEND it_header.
  it_header-line = 'WERKS'.
  APPEND it_header.
  it_header-line = 'MATNRWERKS'.
  APPEND it_header.
  it_header-line = 'STTAG'.
  APPEND it_header.
  it_header-line = 'VERWE'.
  APPEND it_header.
  it_header-line = 'STATU'.
  APPEND it_header.
  it_header-line = 'LTXA1'.
  APPEND it_header.
  it_header-line = 'VERWMERKM'.
  APPEND it_header.
  it_header-line = 'INSPTEXT'.
  APPEND it_header.
  it_header-line = 'MKVERSION'.
  APPEND it_header.
  it_header-line = 'PMETHODE'.
  APPEND it_header.
  it_header-line = 'PMTVERSION'.
  APPEND it_header.
  it_header-line = 'STICHPRVER'.
  APPEND it_header.
  it_header-line = 'SPCKRIT'.
  APPEND it_header.
  it_header-line = 'STELLEN'.
  APPEND it_header.
  it_header-line = 'MASSEINHSW'.
  APPEND it_header.
  it_header-line = 'SOLLWERT'.
  APPEND it_header.
  it_header-line = 'TOLERANZUN'.
  APPEND it_header.
  it_header-line = 'TOLERANZOB'.
  APPEND it_header.
  it_header-line = 'SELECTED_SET'.
  APPEND it_header.
  it_header-line = 'SEQUENCE_NO'.
  APPEND it_header.
  it_header-line = 'FLG'.
  APPEND it_header.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename              = d_filename
      filetype              = 'ASC'
      write_field_separator = 'X'
    TABLES
      data_tab              = it_data
      fieldnames            = it_header.
  IF sy-subrc = 0.
    MESSAGE i006(aq) WITH 'File was downloaded'.
  ENDIF.
ENDFORM.
