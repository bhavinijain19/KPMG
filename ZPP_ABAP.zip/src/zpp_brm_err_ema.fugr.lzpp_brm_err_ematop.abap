FUNCTION-POOL ZPP_BRM_ERR_EMA            MESSAGE-ID SV.

* INCLUDE LZPP_BRM_ERR_EMAD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_BRM_ERR_EMAT00                     . "view rel. data dcl.
