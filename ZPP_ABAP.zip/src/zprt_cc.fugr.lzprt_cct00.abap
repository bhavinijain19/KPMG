*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPRT_CC.........................................*
DATA:  BEGIN OF STATUS_ZPRT_CC                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPRT_CC                       .
CONTROLS: TCTRL_ZPRT_CC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZPRT_CC                       .
TABLES: ZPRT_CC                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
