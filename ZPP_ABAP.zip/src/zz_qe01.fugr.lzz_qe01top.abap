FUNCTION-POOL ZZ_QE01.                      "MESSAGE-ID ..
TABLES: QALS.

DATA: w_qals TYPE qals.
*---------------------------------------------------------------------*
*       FIELD SYMBOLS
*---------------------------------------------------------------------*
FIELD-SYMBOLS: <x_trtyp> TYPE t180.


DATA : gs_ZPP_QE01 TYPE zpp_qe01_cust.
* INCLUDE LZZ_QE01D...                       " Local class definition
