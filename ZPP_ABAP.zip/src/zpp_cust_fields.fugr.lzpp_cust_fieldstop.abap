FUNCTION-POOL ZPP_CUST_FIELDS            MESSAGE-ID SV.

* INCLUDE LZPP_CUST_FIELDSD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_CUST_FIELDST00                     . "view rel. data dcl.
