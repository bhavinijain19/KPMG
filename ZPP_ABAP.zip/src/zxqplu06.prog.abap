*&---------------------------------------------------------------------*
*& Include          ZXQPLU06
*&---------------------------------------------------------------------*

*E_QALS_CUST-ZCONTROL_IND .

*FIELD-SYMBOLS: <fs_qals_value> TYPE qals-zcontrol_ind.
*
*" Assign the global variable from your function group to the field-symbol
*ASSIGN ('(SAPLZZ_QE01)QALS-ZCONTROL_IND') TO <fs_qals_value>.
*
*IF sy-subrc = 0 AND <fs_qals_value> IS NOT INITIAL.
*  e_qals_cust-zcontrol_ind = <fs_qals_value>.
*ENDIF.
