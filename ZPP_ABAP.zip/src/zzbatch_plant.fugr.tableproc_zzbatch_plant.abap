*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZZBATCH_PLANT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZZBATCH_PLANT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
