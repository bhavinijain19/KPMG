FUNCTION-POOL ZPP_WORK_CENTER            MESSAGE-ID SV.

* INCLUDE LZPP_WORK_CENTERD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_WORK_CENTERT00                     . "view rel. data dcl.
