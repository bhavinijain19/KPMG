*&---------------------------------------------------------------------*
*& Report ZPP_IP_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpp_ip_upload.

INCLUDE zpp_ip_upload_top.
INCLUDE zpp_ip_upload_scr.
INCLUDE zpp_ip_upload_form.

INITIALIZATION.
  " Setting button text and optional icon
  btn_tpl = '@49@ Download Template'.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'DTL'. " User-command assigned to the button
      PERFORM download_template.
  ENDCASE.

*&---------------------------------------------------------------------*
*&                          SEARCH HELP
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_flname.
  PERFORM value_request.                                     "VALUE REQUEST FOR FILE
*&---------------------------------------------------------------------*
*&                       START OF SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM validations.
  PERFORM upload_excel.
  PERFORM create_ip.
  IF t_log IS NOT INITIAL.
    PERFORM download_log_to_excel. " Saves file first
    PERFORM display_log.           " Then shows result on screen
  ENDIF.
