*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_MACHINETOP.                   " Global Declarations
  INCLUDE LZPP_MACHINEUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_MACHINEF...                   " Subroutines
* INCLUDE LZPP_MACHINEO...                   " PBO-Modules
* INCLUDE LZPP_MACHINEI...                   " PAI-Modules
* INCLUDE LZPP_MACHINEE...                   " Events
* INCLUDE LZPP_MACHINEP...                   " Local class implement.
* INCLUDE LZPP_MACHINET99.                   " ABAP Unit tests
  INCLUDE LZPP_MACHINEF00                         . " subprograms
  INCLUDE LZPP_MACHINEI00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
