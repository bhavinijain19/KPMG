*&---------------------------------------------------------------------*
*& Report  ZPP_OPTIVA_BOM_UPLOAD
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT ZPP_OPTIVA_BOM_UPLOAD.

INCLUDE ZPP_OPTIVA_BOM_TOP.
INCLUDE ZPP_OPTIVA_BOM_SEL.
INCLUDE ZPP_OPTIVA_BOM_SUB.


START-OF-SELECTION.

PERFORM read_data.
