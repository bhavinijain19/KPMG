*&---------------------------------------------------------------------*
*& Report  ZPP_PRODUCTION_ORDER_CONF_DET
*&-------------------------------------------------------------------*
*& TITLE: PRODUCTION ORDER CONFIRMATION DETAILS
*&-------------------------------------------------------------------*
*& REPORT AUTHOR         : HARDIK PATEL,
*& FUNCTIONAL CONSULTANT : SANJAY SAHOO,
*& REPORT CREATION DATE  : 26/12/2014
*& TRANSACTION CODE      : ZPP_CNF
*& REQUEST NUMBER        : DEVK901335
*&-------------------------------------------------------------------*

REPORT zpp_prod_co_cnf.
TABLES : aufk,aufm,afko.
*&---------------------------------------------------------------------*
*DATA DECLARATION
*&---------------------------------------------------------------------*
TYPES : BEGIN OF t_afru,
          aufnr TYPE afru-aufnr,
          rueck TYPE afru-rueck,
          arbid TYPE afru-arbid,
          werks TYPE afru-werks,
          ile01 TYPE afru-ile01,
          ism01 TYPE afru-ism01,
          ile02 TYPE afru-ile01,
          ism02 TYPE afru-ism01,
          ile03 TYPE afru-ile01,
          ism03 TYPE afru-ism01,
          arbpl TYPE crhd-arbpl,
          lmnga TYPE afru-lmnga,
          meinh TYPE afru-meinh,
          stzhl TYPE afru-stzhl,
          rmzhl TYPE afru-rmzhl,
          budat TYPE afru-budat,
        END OF t_afru.
DATA : wa_afru TYPE t_afru.
DATA : it_afru TYPE STANDARD TABLE OF t_afru.
DATA : wa_afru1 TYPE t_afru.
DATA : it_afru1 TYPE STANDARD TABLE OF t_afru.

TYPES : BEGIN OF t_objnr,
          aufnr TYPE afru-aufnr,
          objnr TYPE caufv-objnr,
          igmng TYPE caufv-igmng,
        END OF t_objnr.
DATA : wa_objnr TYPE t_objnr.
DATA : it_objnr TYPE STANDARD TABLE OF t_objnr.

TYPES : BEGIN OF t_jest,
          objnr TYPE jest-objnr,
          stat  TYPE jest-stat,
          inact TYPE j_inact,
        END OF t_jest.
DATA : wa_jest TYPE t_jest.
DATA : it_jest TYPE STANDARD TABLE OF t_jest.

TYPES : BEGIN OF t_afko,
          aufnr  TYPE afko-aufnr,
          plnal  TYPE afko-plnal,
          plnty  TYPE afko-plnty,
          plnnr  TYPE afko-plnnr,
          plnbez TYPE afko-plnbez,
          sdatv  TYPE afko-sdatv,
          stlnr  TYPE afko-stlnr,
          stlst  TYPE afko-stlst,
          stlal  TYPE afko-stlal,
          stlan  TYPE afko-stlan,
          gamng  TYPE afko-gamng,
          gmein  TYPE afko-gmein,
          gstrs  TYPE afko-gstrs,
          gltrs  TYPE afko-gltrs,
          ftrmi  TYPE afko-ftrmi,
          rsnum  TYPE afko-rsnum, "Added by Raj on 14.02.2024
        END OF t_afko.
DATA : wa_afko TYPE t_afko.
DATA : it_afko TYPE STANDARD TABLE OF t_afko.


TYPES : BEGIN OF ty_stko,
          stlnr TYPE stko-stlnr,
          stlal TYPE stko-stlal,
          stkoz TYPE stko-stkoz,
          loekz TYPE stko-loekz,
          stlst TYPE stko-stlst,
          bmeng TYPE stko-bmeng,
        END OF ty_stko.

DATA : it_stko TYPE STANDARD TABLE OF ty_stko,
       wa_stko TYPE ty_stko.



TYPES : BEGIN OF t_aufk,
          aufnr TYPE afko-aufnr,
        END OF t_aufk.
DATA : wa_aufk TYPE t_aufk.
DATA : it_aufk TYPE STANDARD TABLE OF t_aufk.

TYPES : BEGIN OF t_plgrp,
          aufnr TYPE afko-aufnr,
          plgrp TYPE caufv-fevor,
        END OF t_plgrp.
DATA : wa_plgrp TYPE t_plgrp.
DATA : it_plgrp TYPE STANDARD TABLE OF t_plgrp.

TYPES : BEGIN OF t_makt,
          matnr TYPE makt-matnr,
          maktx TYPE makt-maktx,
        END OF t_makt.
DATA : wa_makt TYPE t_makt.
DATA : it_makt TYPE STANDARD TABLE OF t_makt.

DATA : wa_makt1 TYPE t_makt.                   "Added by Raj on 09.01.2024
DATA : it_makt1 TYPE STANDARD TABLE OF t_makt."Added by Raj on 09.01.2024

TYPES : BEGIN OF t_stpo,
          stlnr TYPE stpo-stlnr,
          idnrk TYPE stpo-idnrk,
          posnr TYPE stpo-posnr,
        END OF t_stpo.
DATA : wa_stpo TYPE t_stpo.
DATA : it_stpo TYPE STANDARD TABLE OF t_stpo.
DATA : wa_stpo1 TYPE t_stpo.
DATA : it_stpo1 TYPE STANDARD TABLE OF t_stpo.


TYPES : BEGIN OF ty_stpo,
          stlnr  TYPE stpo-stlnr,
          stpoz  TYPE stpo-stpoz,
          idnrk  TYPE stpo-idnrk,
          posnr  TYPE stpo-posnr,
          menge  TYPE stpo-menge,
          lv_key TYPE string,
        END OF ty_stpo.

DATA : lt_stpo1 TYPE STANDARD TABLE OF ty_stpo,
       ls_stpo1 TYPE ty_stpo.

DATA : lt_stpo TYPE STANDARD TABLE OF ty_stpo,
       ls_stpo TYPE ty_stpo.

TYPES : BEGIN OF t_101,
          mblnr TYPE aufm-mblnr,
          aufnr TYPE aufm-aufnr,
          matnr TYPE aufm-matnr,
          menge TYPE aufm-menge,
          meins TYPE aufm-meins,
        END OF t_101.
DATA : wa_101 TYPE t_101.
DATA : it_101 TYPE STANDARD TABLE OF t_101.

TYPES : BEGIN OF t_261,
          mblnr TYPE aufm-mblnr,
          zeile TYPE aufm-zeile,
          aufnr TYPE aufm-aufnr,
          matnr TYPE aufm-matnr,
          menge TYPE aufm-menge,
          meins TYPE aufm-meins,
          werks TYPE aufm-werks,
          shkzg TYPE aufm-shkzg,
          budat TYPE aufm-budat,
          rsnum TYPE rsnum,
        END OF t_261.
DATA : wa_261 TYPE t_261.
DATA : it_261 TYPE STANDARD TABLE OF t_261.
**************************** 27.07.2021
TYPES: BEGIN OF ty_afko,
         aufnr TYPE afko-aufnr,
         rsnum TYPE afko-rsnum,
       END OF ty_afko.
DATA: it_afko1 TYPE STANDARD TABLE OF ty_afko,
      wa_afko1 TYPE ty_afko.
************
DATA : lv_temmatnr TYPE mara-matnr.
DATA : lv_tot_qty TYPE aufm-menge.
TYPES : BEGIN OF t_262,
          mblnr TYPE mseg-mblnr,
          zeile TYPE mseg-zeile,
          smbln TYPE mseg-smbln,
          smblp TYPE mseg-smblp,
          matnr TYPE mseg-matnr,
          shkzg TYPE aufm-shkzg,
        END OF t_262.
TYPES : BEGIN OF t_resb,
          rsnum    TYPE rsnum,
          matnr    TYPE matnr,
          bdmng    TYPE bdmng,
          meins    TYPE meins,
          shkzg    TYPE shkzg,
          aufnr    TYPE aufnr,
          lv_maktx TYPE makt-maktx, "Added by Raj on 09.01.2024
        END OF t_resb.
DATA : wa_262 TYPE t_262.
DATA : it_262 TYPE STANDARD TABLE OF t_262.
DATA : it_resb TYPE STANDARD TABLE OF t_resb,
       wa_resb TYPE t_resb.




TYPES : BEGIN OF ty_resb1,

          rsnum TYPE resb-rsnum,
          aufnr TYPE resb-aufnr,
          stlnr TYPE resb-stlnr,
          stpoz TYPE resb-stpoz,
        END OF ty_resb1.

DATA : it_resbb TYPE STANDARD TABLE OF ty_resb1,
       wa_resbb TYPE ty_resb1.



TYPES : BEGIN OF t_final,
          aufnr    TYPE aufm-aufnr,
          mblnr    TYPE aufm-aufnr,
          101matnr TYPE aufm-matnr,
          totmenge TYPE aufm-menge,
          totmeins TYPE aufm-meins,
          101menge TYPE aufm-menge,
          101meins TYPE aufm-meins,
          261matnr TYPE aufm-matnr,
          261menge TYPE aufm-menge,
          261meins TYPE aufm-meins,
          werks    TYPE aufm-werks,
          budat    TYPE aufm-budat,
        END OF t_final.
DATA : wa_final TYPE t_final.
DATA : it_final TYPE STANDARD TABLE OF t_final.
DATA : it_finallt0 TYPE STANDARD TABLE OF t_final.
TYPES : BEGIN OF t_final1,
          key_om        TYPE string,
          faufnr        TYPE aufm-aufnr,
          fmblnr        TYPE aufm-aufnr,
          f101matnr     TYPE aufm-matnr,
          maktx         TYPE maktx,
          matkl         TYPE matkl,
          ftotmenge(30),
          ftotmeins     TYPE aufm-meins,
          101menge      TYPE aufm-menge,
          101meins      TYPE aufm-meins,
          261matnr      TYPE aufm-matnr,
          maktx1        TYPE maktx,
          261menge      TYPE aufm-menge,
          261meins      TYPE aufm-meins,
          werks         TYPE aufm-werks,
          stbmenge      TYPE aufm-menge,
          stbmeins      TYPE meins,
          devmenge      TYPE aufm-menge,
          devmenpe      TYPE aufm-menge,
          devmeins      TYPE meins,
          plgrp         TYPE caufv-fevor,
          budat         TYPE aufm-budat,
          stdprc        TYPE dmbtr,
          curmap        TYPE vmkum,
*          indel         TYPE char1,
          reqty         TYPE aufm-menge, "Added by Raj on 09.01.2024
          stlal         TYPE mast-stlal, "alternative BOM "Added by Raj on 19.02.2024  "Matching purpose through BAPI and which are missed components
*        key_om      type string,
          stlnr         TYPE stko-stlnr, "BOM added by Raj on 20.02.2024"Matching purpose through BAPI and which are missed components
        END OF t_final1.
DATA : wa_final1 TYPE t_final1.
DATA : it_final1 TYPE STANDARD TABLE OF t_final1.
DATA : it_final2 TYPE STANDARD TABLE OF t_final1."Added by Raj on 19.02.2024
DATA: wa_final2 TYPE t_final1.
DATA : wa_final01 TYPE t_final1.
DATA : it_final01 TYPE STANDARD TABLE OF t_final1.

TYPES : BEGIN OF t_fin1,
          aufnr    TYPE afru-aufnr,
          werks    TYPE afru-werks,
          vgw01    TYPE afru-ism01,
          vge01    TYPE afru-ile01,
          vgw02    TYPE afru-ism01,
          vge02    TYPE afru-ile01,
          vgw03    TYPE afru-ism01,
          vge03    TYPE afru-ile01,
          lmnga    TYPE afru-lmnga,
          meinh    TYPE afru-meinh,
          ile01    TYPE afru-ile01,
          ism01    TYPE afru-ism01,
          ile02    TYPE afru-ile01,
          ism02    TYPE afru-ism01,
          ile03    TYPE afru-ile01,
          ism03    TYPE afru-ism01,
          rqvgw01  TYPE afru-ism01,
          rqvge01  TYPE afru-ile01,
          rqvgw02  TYPE afru-ism01,
          rqvge02  TYPE afru-ile01,
          rqvgw03  TYPE afru-ism01,
          rqvge03  TYPE afru-ile01,
          gamng    TYPE afko-gamng,
          rmzhl    TYPE afru-rmzhl,
          devvgw01 TYPE afru-ism01,
          devvgp01 TYPE afru-ism01,
          devvge01 TYPE afru-ile01,
          devvgw02 TYPE afru-ism01,
          devvgp02 TYPE afru-ism01,
          devvge02 TYPE afru-ile01,
          devvgw03 TYPE afru-ism01,
          devvgp03 TYPE afru-ism01,
          devvge03 TYPE afru-ile01,
          matnr    TYPE makt-matnr,
          maktx    TYPE makt-maktx,
          plgrp    TYPE caufv-fevor,
          gstrs    TYPE afko-gstrs,
          gltrs    TYPE afko-gltrs,
          budat    TYPE afru-budat,
          arbpl    TYPE crhd-arbpl,
          ftrmi    TYPE afko-ftrmi,
        END OF t_fin1.
DATA : wa_fin1 TYPE t_fin1.
DATA : it_fin1 TYPE STANDARD TABLE OF t_fin1.

TYPES : BEGIN OF t_fin2,
          aufnr    TYPE afru-aufnr,
          totalqty TYPE afko-gamng,
          vgw01    TYPE afru-ism01,
          vge01    TYPE afru-ile01,
          vgw02    TYPE afru-ism01,
          vge02    TYPE afru-ile01,
          vgw03    TYPE afru-ism01,
          vge03    TYPE afru-ile01,
          remqty   TYPE afko-gamng,
          rqvgw01  TYPE afru-ism01,
          rqvge01  TYPE afru-ile01,
          rqvgw02  TYPE afru-ism01,
          rqvge02  TYPE afru-ile01,
          rqvgw03  TYPE afru-ism01,
          rqvge03  TYPE afru-ile01,
          matnr    TYPE makt-matnr,
          maktx    TYPE makt-maktx,
          plgrp    TYPE caufv-fevor,
          gstrs    TYPE afko-gstrs,
          gltrs    TYPE afko-gltrs,
          ftrmi    TYPE afko-ftrmi,
          werks    TYPE werks_d,
*          indel    TYPE char1,
        END OF t_fin2.
DATA : wa_fin2 TYPE t_fin2.
DATA : it_fin2 TYPE STANDARD TABLE OF t_fin2.

TYPES : BEGIN OF t_fin,
          faufnr     TYPE afru-aufnr,
          fwerks     TYPE afru-werks,
          fgamng(30),
          fvgw01(30),
          fvge01(30),
          fvgw02(30),
          fvge02(30),
          fvgw03(30),
          fvge03(30),
          lmnga      TYPE afru-lmnga,
          meinh      TYPE afru-meinh,
          ile01      TYPE afru-ile01,
          ism01      TYPE afru-ism01,
          ile02      TYPE afru-ile01,
          ism02      TYPE afru-ism01,
          ile03      TYPE afru-ile01,
          ism03      TYPE afru-ism01,
          rqvgw01    TYPE afru-ism01,
          rqvge01    TYPE afru-ile01,
          rqvgw02    TYPE afru-ism01,
          rqvge02    TYPE afru-ile01,
          rqvgw03    TYPE afru-ism01,
          rqvge03    TYPE afru-ile01,
          devvgw01   TYPE afru-ism01,
          devvgp01   TYPE afru-ism01,
          devvge01   TYPE afru-ile01,
          devvgw02   TYPE afru-ism01,
          devvgp02   TYPE afru-ism01,
          devvge02   TYPE afru-ile01,
          devvgw03   TYPE afru-ism01,
          devvgp03   TYPE afru-ism01,
          devvge03   TYPE afru-ile01,
          matnr      TYPE makt-matnr,
          maktx      TYPE makt-maktx,
          plgrp      TYPE caufv-fevor,
          gstrs      TYPE afko-gstrs,
          gltrs      TYPE afko-gltrs,
          budat      TYPE afru-budat,
          arbpl      TYPE crhd-arbpl,
          ftrmi      TYPE afko-ftrmi,
          arbpl1     TYPE arbpl,
          stdst      TYPE ckis-menge,
          stdmc      TYPE ckis-menge,
          stdlb      TYPE ckis-menge,
*          indel      TYPE char1,
        END OF t_fin.
DATA : wa_fin TYPE t_fin.
DATA : it_fin TYPE STANDARD TABLE OF t_fin.
DATA : lt_stzu   TYPE STANDARD TABLE OF stzu,
       lt_mast   TYPE STANDARD TABLE OF mast,
       lt_keko   TYPE STANDARD TABLE OF keko,
       lt_plpo   TYPE STANDARD TABLE OF plpo,
       lt_crhd   TYPE STANDARD TABLE OF crhd,
       lt_ckis   TYPE STANDARD TABLE OF ckis,
*       lt_ckis1  TYPE STANDARD TABLE OF ckis, "Commented by Raj on 06.03.2024
       lt_mbew   TYPE STANDARD TABLE OF mbew,
       lt_mbew1  TYPE STANDARD TABLE OF mbew,
       lwa_mbew1 TYPE mbew,
       lwa_mbew  TYPE mbew,
       lwa_ckis  TYPE ckis,
*       lwa_ckis1 TYPE ckis,                  "Commented by Raj on 06.03.2024
       lwa_crhd  TYPE crhd,
       lwa_plpo  TYPE plpo,
       lwa_keko  TYPE keko,
       lwa_mast  TYPE mast,
       lwa_stzu  TYPE stzu.


********************Begin of Changes Added by Raj on 06.03.2024***************
TYPES : BEGIN OF ty_ckis,
          kalnr TYPE ckis-kalnr,
          kadky TYPE ckis-kadky,
          elemt TYPE ckis-elemt,
          menge TYPE ckis-menge,
          meeht TYPE ckis-meeht,
        END OF ty_ckis.

DATA : lt_ckis1  TYPE STANDARD TABLE OF ty_ckis,
       lwa_ckis1 TYPE ty_ckis.
*******************Begin of Changes Added by Raj on 06.03.2024***************


TYPES : BEGIN OF t_caufv,
          aufnr  TYPE caufv-aufnr,
          plnbez TYPE caufv-plnbez,
          gamng  TYPE caufv-gamng,
          igmng  TYPE caufv-igmng,
          idat2  TYPE caufv-idat2,
          fevor  TYPE caufv-fevor,
          werks  TYPE werks_d,
        END OF t_caufv.
DATA : wa_caufv TYPE t_caufv.
DATA : it_caufv TYPE STANDARD TABLE OF t_caufv.

TYPES : BEGIN OF t_temp,
          aufnr    TYPE caufv-aufnr,
          101matnr TYPE caufv-plnbez,
          maktx    TYPE maktx,
          matkl    TYPE matkl,
          totqty   TYPE caufv-gamng,
          remqty   TYPE caufv-igmng,
          261matnr TYPE caufv-plnbez,
          maktx1   TYPE maktx,
          ormenge  TYPE cs_e_mnglg,
          ormeins  TYPE afru-meinh,
          reqmenge TYPE cs_e_mnglg,
          reqmeins TYPE afru-meinh,
          plgrp    TYPE caufv-fevor,
*          indel    TYPE char1,
        END OF t_temp.
TYPES : BEGIN OF t_fevor,
          plgrp TYPE caufv-fevor,
        END OF t_fevor.
TYPES : BEGIN OF t_mara,
          matnr TYPE matnr,
          matkl TYPE matkl,
        END OF t_mara.
DATA : wa_temp TYPE t_temp.
DATA : it_temp TYPE STANDARD TABLE OF t_temp.
DATA : wa_fin3 TYPE t_temp.
DATA : it_fin3 TYPE STANDARD TABLE OF t_temp.
DATA : it_fevor TYPE STANDARD TABLE OF t_fevor,
       wa_fevor TYPE t_fevor,
       it_mara  TYPE STANDARD TABLE OF t_mara,
       wa_mara  TYPE t_mara.

DATA : v_aufnr        TYPE aufm-aufnr,
       v_aufnr1       TYPE aufm-aufnr,
       v_mblnr        TYPE aufm-aufnr,
       v_mblnr1       TYPE aufm-aufnr,
       v_101matnr     TYPE aufm-matnr,
       v_totmenge(30),
       v_totmeins     TYPE aufm-meins,
       gd_repid       TYPE sy-repid,
       g_save         TYPE c VALUE 'X',
       g_variant      TYPE disvariant,
       gx_variant     TYPE disvariant.
DATA : it_stb TYPE TABLE OF stpox.
DATA : wa_stb TYPE stpox.
DATA : it_opr_tab TYPE STANDARD TABLE OF capp_opr.
DATA : wa_opr_tab TYPE capp_opr.
DATA : v_date(10).
DATA : v_werks     TYPE afru-werks,
       v_gamng(30),
       v_vgw01     TYPE afru-ism01,
       v_vge01     TYPE afru-ile01,
       v_vgw02     TYPE afru-ism01,
       v_vge02     TYPE afru-ile01,
       v_vgw03     TYPE afru-ism01,
       v_vge03     TYPE afru-ile01.
DATA : v_difqty TYPE caufv-gamng.
DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv.

TYPES : BEGIN OF gt_t001w,
          werks TYPE t001w-werks,                  " PLANT
          name1 TYPE t001w-name1,                  " NAME
        END OF gt_t001w.

DATA: wa_t001w TYPE gt_t001w,
      it_t001w TYPE TABLE OF gt_t001w.

DATA : lv_counter TYPE stko-stkoz.

*&---------------------------------------------------------------------*
*SELECTION SCREEN
*&---------------------------------------------------------------------*

SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_aufnr FOR aufk-aufnr OBLIGATORY.
SELECT-OPTIONS : s_werks FOR aufm-werks OBLIGATORY NO-EXTENSION NO INTERVALS.
SELECT-OPTIONS : s_fevor FOR afko-fevor NO INTERVALS NO-DISPLAY.
SELECT-OPTIONS : s_budat FOR aufm-budat NO-EXTENSION.
PARAMETERS : p_time RADIOBUTTON GROUP rad1 DEFAULT 'X'.
PARAMETERS : p_quan RADIOBUTTON GROUP rad1.
SELECTION-SCREEN : END OF BLOCK a1.

SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE text-002.
PARAMETERS : p_prod RADIOBUTTON GROUP rad2 DEFAULT 'X'.
*PARAMETERS : p_rem RADIOBUTTON GROUP rad2.
PARAMETERS : p_del RADIOBUTTON GROUP rad2.
SELECTION-SCREEN : END OF BLOCK b1.
SELECTION-SCREEN BEGIN OF BLOCK c1 WITH FRAME TITLE text-003 .
PARAMETERS: variant LIKE disvariant-variant.
SELECTION-SCREEN END OF BLOCK c1.
*&---------------------------------------------------------------------*
INITIALIZATION.
*&---------------------------------------------------------------------*
  gx_variant-report = sy-repid.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.

AT SELECTION-SCREEN.
  IF s_aufnr[] IS INITIAL AND s_budat[] IS INITIAL.
    MESSAGE 'Please Enter either Date or Order No at least' TYPE 'E'.
  ENDIF.
*  IF s_aufnr IS INITIAL AND s_budat IS INITIAL.
*    MESSAGE 'Posting date is required' TYPE 'E'.
*    LEAVE LIST-PROCESSING.
*  ELSEIF s_aufnr IS INITIAL AND s_fevor IS INITIAL.
*    MESSAGE 'Posting date is required' TYPE 'E'.
*    LEAVE LIST-PROCESSING.
*  ELSEIF s_budat IS INITIAL AND s_fevor IS INITIAL AND s_aufnr IS INITIAL.
*    MESSAGE 'Posting date is required' TYPE 'E'.
*    LEAVE LIST-PROCESSING.
*  ENDIF.

*&---------------------------------------------------------------------*
START-OF-SELECTION.
*&---------------------------------------------------------------------*
  PERFORM authorization.
  IF p_prod = 'X' OR p_del = 'X'.
    SELECT aufnr plnal plnty plnnr plnbez sdatv stlnr stlst stlal stlan gamng gmein gstrs gltrs ftrmi rsnum "rsnum added by raj on 14.04.2024
    FROM afko INTO TABLE it_afko WHERE aufnr IN s_aufnr AND fevor IN s_fevor.
    IF it_afko IS NOT INITIAL.
      SELECT matnr maktx FROM makt INTO TABLE it_makt FOR ALL ENTRIES IN it_afko WHERE matnr = it_afko-plnbez.
      SELECT matnr matkl FROM mara INTO TABLE it_mara FOR ALL ENTRIES IN it_afko WHERE matnr = it_afko-plnbez.
    ENDIF.
    SELECT DISTINCT aufnr FROM aufk INTO TABLE it_aufk WHERE aufnr IN s_aufnr AND werks IN s_werks AND autyp = '10'.

***Begin of changes***Added by Raj on 14.02.2024**********

    IF it_afko IS NOT INITIAL.
*      SELECT stlnr stlst bmeng FROM stko INTO CORRESPONDING FIELDS OF TABLE
*        it_stko FOR ALL ENTRIES IN it_afko WHERE stlnr = it_afko-stlnr AND stlst = it_afko-stlst.

      SELECT stlnr stlal stkoz stlst bmeng FROM stko INTO CORRESPONDING FIELDS OF TABLE
      it_stko FOR ALL ENTRIES IN it_afko WHERE stlnr = it_afko-stlnr AND stlst  = it_afko-stlst AND loekz NE 'X'.




      SELECT  rsnum  aufnr stpoz stlnr FROM resb INTO CORRESPONDING FIELDS OF TABLE it_resbb FOR ALL ENTRIES IN it_afko WHERE rsnum = it_afko-rsnum.

*FOR BOM QTY
      IF it_resbb IS NOT INITIAL.
        SELECT stlnr stpoz idnrk posnr menge FROM stpo INTO CORRESPONDING FIELDS OF TABLE
        lt_stpo FOR ALL ENTRIES IN it_resbb  WHERE stlnr = it_resbb-stlnr AND stpoz =  it_resbb-stpoz.
      ENDIF.


    ENDIF.
*  **End of changes***Added by Raj on 14.02.2024**********
    IF p_time = 'X'.
      PERFORM get_actvt.
      PERFORM actvt_fcat.
      PERFORM alv_display.
    ENDIF.

    IF p_quan = 'X'.
      PERFORM get_qty.
      PERFORM qty_fcat.
      PERFORM alv_display.
    ENDIF.
  ENDIF.

*  IF p_rem = 'X'.
*    SELECT aufnr plnal plnty plnnr plnbez sdatv stlnr stlst stlal stlan gamng gmein gstrs gltrs ftrmi
*    FROM afko INTO TABLE it_afko WHERE aufnr IN s_aufnr AND fevor IN s_fevor.
*    SELECT matnr maktx FROM makt INTO TABLE it_makt FOR ALL ENTRIES IN it_afko WHERE matnr = it_afko-plnbez.
*    SELECT matnr matkl FROM mara INTO TABLE it_mara FOR ALL ENTRIES IN it_afko WHERE matnr = it_afko-plnbez.
*    SELECT DISTINCT aufnr FROM aufk INTO TABLE it_aufk WHERE aufnr IN s_aufnr AND werks IN s_werks AND autyp = '10'.
*
*    IF p_time = 'X'.
*      PERFORM get_actvt1.
*      PERFORM actvt_fcat1.
*      PERFORM alv_display1.
*    ENDIF.
*
*    IF p_quan = 'X'.
*      PERFORM get_qty1.
*      PERFORM qty_fcat1.
*      PERFORM alv_display1.
*    ENDIF.
*  ENDIF.
*&---------------------------------------------------------------------*
*&      FORM  GET_ACTVT
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM get_actvt .
  IF it_afko IS NOT INITIAL.
    SELECT afru~aufnr afru~rueck afru~arbid afru~werks afru~ile01 afru~ism01 afru~ile02 afru~ism02 afru~ile03 afru~ism03 crhd~arbpl
    afru~lmnga afru~meinh afru~stzhl afru~rmzhl afru~budat
    FROM afru INNER JOIN crhd ON afru~arbid = crhd~objid
    INTO TABLE it_afru WHERE afru~aufnr IN s_aufnr AND afru~werks IN s_werks AND afru~budat IN s_budat
    AND afru~stokz NE 'X'.

    DELETE it_afru WHERE stzhl NE ''.
    SORT it_afru BY aufnr rmzhl.

    SELECT aufnr fevor FROM caufv INTO TABLE it_plgrp FOR ALL ENTRIES IN it_afru WHERE aufnr = it_afru-aufnr AND fevor IN s_fevor.
    SORT it_plgrp BY aufnr plgrp.
    DELETE ADJACENT DUPLICATES FROM it_plgrp COMPARING aufnr plgrp.

    SELECT aufnr objnr igmng FROM caufv INTO TABLE it_objnr FOR ALL ENTRIES IN it_afru WHERE aufnr = it_afru-aufnr AND fevor IN s_fevor.
    SORT it_objnr BY aufnr objnr.
    DELETE ADJACENT DUPLICATES FROM it_objnr COMPARING aufnr objnr.
    IF p_del = 'X'.
      SELECT objnr stat inact FROM jest INTO TABLE it_jest FOR ALL ENTRIES IN it_objnr
                                           WHERE objnr = it_objnr-objnr AND stat IN ('I0012','I0045')
      AND  inact NE 'X'.
    ELSE.
      SELECT objnr stat inact FROM jest INTO TABLE it_jest
      FOR ALL ENTRIES IN it_objnr WHERE objnr = it_objnr-objnr." AND stat IN ('I0012','I0045'). "changed 20/05/2015
    ENDIF.
    SORT it_jest BY objnr.
    IF p_del = 'X'.
      LOOP AT it_jest INTO wa_jest.
        IF ( wa_jest-stat = 'I0012' OR wa_jest-stat = 'I0045' )
          AND wa_jest-inact = 'X'.
          DELETE it_jest WHERE objnr = wa_jest-objnr.
        ENDIF.
        CLEAR wa_jest.
      ENDLOOP.
    ELSE.
      LOOP AT it_jest INTO wa_jest.
        IF ( wa_jest-stat = 'I0012' OR wa_jest-stat = 'I0045' )
          AND wa_jest-inact <> 'X'.
          DELETE it_jest WHERE objnr = wa_jest-objnr.
        ENDIF.
        CLEAR wa_jest.
      ENDLOOP.
    ENDIF.
  ENDIF.
  it_afru1 = it_afru.
  REFRESH it_afru.
  CLEAR wa_afru.
  IF p_prod = 'X'.
    LOOP AT it_afru1 INTO wa_afru1.
      READ TABLE it_aufk INTO wa_aufk WITH KEY aufnr = wa_afru1-aufnr.
      IF sy-subrc = 0.
        READ TABLE it_objnr INTO wa_objnr WITH KEY aufnr = wa_afru1-aufnr.
        READ TABLE it_jest  INTO wa_jest  WITH KEY objnr = wa_objnr-objnr.
        IF sy-subrc = 0.
          MOVE-CORRESPONDING wa_afru1 TO wa_afru.   "19/05/2015
          APPEND wa_afru TO it_afru.
          CLEAR wa_afru.
**        ELSE.     COMMENTED "19/05/2015
**          MOVE-CORRESPONDING wa_afru1 TO wa_afru.
**          APPEND wa_afru TO it_afru.
**          CLEAR wa_afru.
        ENDIF.
        CLEAR : wa_afru1,wa_objnr,wa_jest.
      ENDIF.
      CLEAR : wa_aufk.
    ENDLOOP.
  ENDIF.

  IF p_del = 'X'.
    LOOP AT it_afru1 INTO wa_afru1.
      READ TABLE it_aufk INTO wa_aufk WITH KEY aufnr = wa_afru1-aufnr.
      IF sy-subrc = 0.
        READ TABLE it_objnr INTO wa_objnr WITH KEY aufnr = wa_afru1-aufnr.
        READ TABLE it_jest  INTO wa_jest  WITH KEY objnr = wa_objnr-objnr.
        IF sy-subrc = 0.
          IF wa_jest-stat = 'I0045'.
            IF wa_objnr-igmng IS NOT INITIAL.
              MOVE-CORRESPONDING wa_afru1 TO wa_afru.
              APPEND wa_afru TO it_afru.
              CLEAR wa_afru.
            ENDIF.
          ELSE.
            MOVE-CORRESPONDING wa_afru1 TO wa_afru.
            APPEND wa_afru TO it_afru.
            CLEAR wa_afru.
          ENDIF.
        ELSE.
        ENDIF.
        CLEAR : wa_afru1,wa_objnr,wa_jest.
      ENDIF.
      CLEAR : wa_aufk.
    ENDLOOP.
  ENDIF.

  LOOP AT it_afru INTO wa_afru.
    MOVE-CORRESPONDING wa_afru TO wa_fin1.
    AT NEW aufnr.
      IF wa_fin1-ile01 = 'H'.
        wa_fin1-ism01 = wa_fin1-ism01 * 60.
        wa_fin1-ile01 = 'MIN'.
      ENDIF.
    ENDAT.
    IF wa_fin1-ile02 = 'H'.
      wa_fin1-ism02 = wa_fin1-ism02 * 60.
      wa_fin1-ile02 = 'MIN'.
    ENDIF.
    IF wa_fin1-ile03 = 'H'.
      wa_fin1-ism03 = wa_fin1-ism03 * 60.
      wa_fin1-ile03 = 'MIN'.
    ENDIF.

    READ TABLE it_afko INTO wa_afko WITH KEY aufnr = wa_afru-aufnr.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_afko-plnbez.
    wa_fin1-gamng = wa_afko-gamng.
    IF NOT wa_afko-plnty IS INITIAL AND NOT wa_afko-plnnr IS INITIAL AND NOT wa_afko-plnal IS INITIAL AND NOT wa_afko-plnbez IS INITIAL.
      CALL FUNCTION 'CARO_ROUTING_READ'
        EXPORTING
          date_from            = '19000101'
          date_to              = '99991231'
          plnty                = wa_afko-plnty
          plnnr                = wa_afko-plnnr
          plnal                = wa_afko-plnal
          matnr                = wa_afko-plnbez
          buffer_del_flg       = 'X'
          delete_all_cal_flg   = 'X'
          adapt_flg            = 'X'
          iv_create_add_change = ' '
        TABLES
          opr_tab              = it_opr_tab.
      IF sy-subrc = 0.
        READ TABLE it_opr_tab INTO wa_opr_tab INDEX 1.
        AT NEW aufnr.
          wa_fin1-vgw01 = wa_opr_tab-vgw01.
          wa_fin1-vge01 = wa_opr_tab-vge01.
          IF wa_fin1-vge01 = 'H'.
            wa_fin1-vgw01 = wa_fin1-vgw01 * 60.
            wa_fin1-vge01 = 'MIN'.
          ENDIF.
        ENDAT.
        wa_fin1-vgw02 = ( 1 * wa_opr_tab-vgw02 ) / wa_opr_tab-bmsch.
        wa_fin1-vge02 = wa_opr_tab-vge02.
        IF wa_fin1-vge02 = 'H'.
          wa_fin1-vgw02 = wa_fin1-vgw02 * 60.
          wa_fin1-vge02 = 'MIN'.
        ENDIF.
        wa_fin1-vgw03 = ( 1 * wa_opr_tab-vgw03 ) / wa_opr_tab-bmsch.
        wa_fin1-vge03 = wa_opr_tab-vge03.
        IF wa_fin1-vge03 = 'H'.
          wa_fin1-vgw03 = wa_fin1-vgw03 * 60.
          wa_fin1-vge03 = 'MIN'.
        ENDIF.

        wa_fin1-rqvgw01 = wa_fin1-vgw01.
        wa_fin1-rqvge01 = wa_opr_tab-vge01.
        wa_fin1-rqvgw02 = ( wa_fin1-vgw02 * wa_afru-lmnga ).
        wa_fin1-rqvge02 = wa_opr_tab-vge02.
        wa_fin1-rqvgw03 = ( wa_fin1-vgw03 * wa_afru-lmnga ).
        wa_fin1-rqvge03 = wa_opr_tab-vge03.


        wa_fin1-devvgw01 = wa_fin1-rqvgw01 - wa_fin1-ism01.
        IF ( wa_fin1-rqvgw01 = '0.000' AND wa_fin1-ism01 = '0.000' ).
          wa_fin1-devvgp01 = '0.000'.
        ELSEIF ( wa_fin1-rqvgw01 = '0.000' OR wa_fin1-ism01 = '0.000' ).
          wa_fin1-devvgp01 = '100.000'.
        ELSE.
          wa_fin1-devvgp01 = ( ( wa_fin1-rqvgw01 - wa_fin1-ism01 ) / wa_fin1-rqvgw01 ) * 100.
        ENDIF.
        wa_fin1-devvge01 = wa_fin1-rqvge01.
        wa_fin1-devvgw02 = wa_fin1-rqvgw02 - wa_fin1-ism02.
        IF ( wa_fin1-rqvgw02 = '0.000' AND wa_fin1-ism02 = '0.000' ).
          wa_fin1-devvgp02 = '0.000'.
        ELSEIF ( wa_fin1-rqvgw02 = '0.000' OR wa_fin1-ism02 = '0.000' ).
          wa_fin1-devvgp02 = '100.000'.
        ELSE.
          wa_fin1-devvgp02 = ( ( wa_fin1-rqvgw02 - wa_fin1-ism02 ) / wa_fin1-rqvgw02 ) * 100.
        ENDIF.
        wa_fin1-devvge02 = wa_fin1-rqvge02.
        wa_fin1-devvgw03 = wa_fin1-rqvgw03 - wa_fin1-ism03.
        IF ( wa_fin1-rqvgw03 = '0.000' AND wa_fin1-ism03 = '0.000' ).
          wa_fin1-devvgp03 = '0.000'.
        ELSEIF ( wa_fin1-rqvgw03 = '0.000' OR wa_fin1-ism03 = '0.000' ).
          wa_fin1-devvgp03 = '100.000'.
        ELSE.
          wa_fin1-devvgp03 = ( ( wa_fin1-rqvgw03 - wa_fin1-ism03 ) / wa_fin1-rqvgw03 ) * 100.
        ENDIF.
        wa_fin1-devvge03 = wa_fin1-rqvge03.
      ENDIF.
    ENDIF.
    wa_fin1-matnr = wa_makt-matnr.
    wa_fin1-maktx = wa_makt-maktx.
    wa_fin1-gstrs = wa_afko-gstrs.
    wa_fin1-gltrs = wa_afko-gltrs.
    READ TABLE it_plgrp INTO wa_plgrp WITH KEY aufnr = wa_afru-aufnr.
    wa_fin1-plgrp = wa_plgrp-plgrp.
    wa_fin1-budat = wa_afru-budat.
    wa_fin1-arbpl = wa_afru-arbpl.
    wa_fin1-ftrmi = wa_afko-ftrmi.
    APPEND wa_fin1 TO it_fin1.
    CLEAR : wa_fin1,wa_opr_tab,wa_afko,wa_afru,wa_makt,wa_plgrp.
    REFRESH it_opr_tab.
  ENDLOOP.

  SORT it_fin1 BY aufnr rmzhl.

  LOOP AT it_fin1 INTO wa_fin1.
    MOVE-CORRESPONDING wa_fin1 TO wa_fin.
    v_werks = wa_fin1-werks.
    v_gamng = wa_fin1-gamng.
    v_vgw01 = wa_fin1-vgw01.
    v_vge01 = wa_fin1-vge01.
    v_vgw02 = wa_fin1-vgw02.
    v_vge02 = wa_fin1-vge02.
    v_vgw03 = wa_fin1-vgw03.
    v_vge03 = wa_fin1-vge03.
*AT NEW AUFNR.
    wa_fin-faufnr  = wa_fin1-aufnr.
    wa_fin-fwerks = v_werks.
    wa_fin-fgamng = v_gamng.
    wa_fin-fvgw01 = v_vgw01.
    wa_fin-fvge01 = v_vge01.
    wa_fin-fvgw02 = v_vgw02.
    wa_fin-fvge02 = v_vge02.
    wa_fin-fvgw03 = v_vgw03.
    wa_fin-fvge03 = v_vge03.
*ENDAT.
    CONDENSE wa_fin-fgamng.
    CONDENSE wa_fin-fvgw01.
    CONDENSE wa_fin-fvge01.
    CONDENSE wa_fin-fvgw02.
    CONDENSE wa_fin-fvge02.
    CONDENSE wa_fin-fvgw03.
    CONDENSE wa_fin-fvge03.
    APPEND wa_fin TO it_fin.
    CLEAR : wa_fin,wa_fin1,v_werks,v_gamng,v_vgw01,v_vge01,v_vgw02,v_vge02,v_vgw03,v_vge03.
  ENDLOOP.

  DELETE it_fin WHERE lmnga IS INITIAL.
  IF it_fin[] IS NOT INITIAL.
    SELECT * FROM keko
             INTO TABLE lt_keko
             FOR ALL ENTRIES IN it_fin
             WHERE matnr = it_fin-matnr
               AND werks = it_fin-fwerks.
    SORT lt_keko[] BY matnr kadat DESCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_keko[] COMPARING matnr.
    IF lt_keko[] IS NOT INITIAL.
      SELECT  kalnr  kadky  elemt menge meeht FROM ckis
               INTO TABLE lt_ckis1
               FOR ALL ENTRIES IN lt_keko
               WHERE kalnr = lt_keko-kalnr
                 AND elemt IN ('102','103','104').
      SORT lt_ckis1[] BY kalnr kadky DESCENDING.

      SELECT * FROM plpo
               INTO TABLE lt_plpo
               FOR ALL ENTRIES IN lt_keko
               WHERE plnty = lt_keko-plnty
                 AND plnnr = lt_keko-plnnr
                 AND plnkn = '1'.
      IF lt_plpo[] IS NOT INITIAL.
        SELECT * FROM crhd
                 INTO TABLE lt_crhd
                 FOR ALL ENTRIES IN lt_plpo
                 WHERE objty = 'A'
                   AND objid = lt_plpo-arbid.
        LOOP AT it_fin INTO wa_fin.
          CLEAR:lwa_keko.
          READ TABLE lt_keko INTO lwa_keko WITH KEY matnr = wa_fin-matnr
                                                    werks = wa_fin-fwerks.
          IF sy-subrc EQ 0.
            CLEAR : lwa_plpo.
            READ TABLE lt_plpo INTO lwa_plpo WITH KEY plnty = lwa_keko-plnty
                                                      plnnr = lwa_keko-plnnr.
            IF sy-subrc EQ 0.
              CLEAR : lwa_crhd.
              READ TABLE lt_crhd INTO lwa_crhd WITH KEY objid = lwa_plpo-arbid.
              IF sy-subrc EQ 0.
                wa_fin-arbpl1 = lwa_crhd-arbpl.
                MODIFY it_fin FROM wa_fin TRANSPORTING arbpl1.
              ENDIF.
            ENDIF.
            CLEAR : lwa_ckis1.
            READ TABLE lt_ckis1 INTO lwa_ckis1 WITH KEY kalnr = lwa_keko-kalnr
                                                        elemt = '102'.
            IF sy-subrc EQ 0.
              wa_fin-stdst = lwa_ckis1-menge.
              wa_fin-fvge01 = lwa_ckis1-meeht.
            ENDIF.
            CLEAR : lwa_ckis1.
            READ TABLE lt_ckis1 INTO lwa_ckis1 WITH KEY kalnr = lwa_keko-kalnr
                                                        elemt = '103'.
            IF sy-subrc EQ 0.
              wa_fin-stdmc = lwa_ckis1-menge.
              wa_fin-fvge02 = lwa_ckis1-meeht.
            ENDIF.
            CLEAR : lwa_ckis1.
            READ TABLE lt_ckis1 INTO lwa_ckis1 WITH KEY kalnr = lwa_keko-kalnr
                                                        elemt = '104'.
            IF sy-subrc EQ 0.
              wa_fin-stdlb = lwa_ckis1-menge.
              wa_fin-fvge03 = lwa_ckis1-meeht.
            ENDIF.
            MODIFY it_fin FROM wa_fin TRANSPORTING stdst stdmc stdlb fvge01 fvge02 fvge03.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.                    " GET_ACTVT
*&---------------------------------------------------------------------*
*&      FORM  ACTVT_FCAT
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM actvt_fcat .
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'FAUFNR'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Production Order No'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'FWERKS'.  wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Plant'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'MATNR'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Material No'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'MAKTX'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Material Description'.
  wa_fcat-outputlen = '30'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'FGAMNG'.    wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Order Qty'.
  wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'ARBPL'.    wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Actual Work Center'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'ARBPL1'.    wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Std.Work Center'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = 'FVGW01'. wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Setup Time'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
***********
  wa_fcat-col_pos = 6.  wa_fcat-fieldname = 'STDST'. wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Std.Setup'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
***********
  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'FVGE01'. wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 8.  wa_fcat-fieldname = 'FVGW02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'M/C Time/Unit'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*********
  wa_fcat-col_pos = 9.  wa_fcat-fieldname = 'STDMC'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Std.Machine'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*********
  wa_fcat-col_pos = 10.  wa_fcat-fieldname = 'FVGE02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 11.  wa_fcat-fieldname = 'FVGW03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Labor Time/Unit'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

********
  wa_fcat-col_pos = 12.  wa_fcat-fieldname = 'STDLB'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Std.Labor Time'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
********
  wa_fcat-col_pos = 13.  wa_fcat-fieldname = 'FVGE03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'BUDAT'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Confrm. Date'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 15.  wa_fcat-fieldname = 'LMNGA'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Produced Qty'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 16.  wa_fcat-fieldname = 'MEINH'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Uom'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 17.  wa_fcat-fieldname = 'ISM01'.     wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Utilised Setup Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 18.  wa_fcat-fieldname = 'ILE01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 19.  wa_fcat-fieldname = 'ISM02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Utilised M/C Time '.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 20.  wa_fcat-fieldname = 'ILE02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =   'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 21.  wa_fcat-fieldname = 'ISM03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Utilised Labor Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'ILE03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 23.  wa_fcat-fieldname = 'RQVGW01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Planned Setup Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 24.  wa_fcat-fieldname = 'RQVGE01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =   'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 25.  wa_fcat-fieldname = 'RQVGW02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Planned M/C Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 26.  wa_fcat-fieldname = 'RQVGE02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 27.  wa_fcat-fieldname = 'RQVGW03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Planned Labor Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 28.  wa_fcat-fieldname = 'RQVGE03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 29.  wa_fcat-fieldname = 'DEVVGW01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Deviation Setup Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 30.  wa_fcat-fieldname = 'DEVVGP01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  ' % Dev. Setup Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 31.  wa_fcat-fieldname = 'DEVVGE01'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =   'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 32.  wa_fcat-fieldname = 'DEVVGW02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Deviation M/C Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 33.  wa_fcat-fieldname = 'DEVVGP02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  '% Dev. M/C Time '.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 34.  wa_fcat-fieldname = 'DEVVGE02'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 35.  wa_fcat-fieldname = 'DEVVGW03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Deviation Labor Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 36.  wa_fcat-fieldname = 'DEVVGP03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  '% Dev. Labor Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 37.  wa_fcat-fieldname = 'DEVVGE03'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 38.  wa_fcat-fieldname = 'PLGRP'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Prodn Supv'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 39.  wa_fcat-fieldname = 'GSTRS'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Schd. Start Dt'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 40.  wa_fcat-fieldname = 'GLTRS'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Schd. End Dt'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 41.  wa_fcat-fieldname = 'FTRMI'.       wa_fcat-tabname = 'IT_FIN'. wa_fcat-seltext_l =  'Act Release Date'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_layout-zebra = 'X'.
ENDFORM.                    " ACTVT_FCAT

*&---------------------------------------------------------------------*
*&      FORM  GET_QTY
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM get_qty .

  SELECT DISTINCT mblnr aufnr matnr menge meins FROM aufm INTO TABLE it_101 WHERE aufnr IN s_aufnr AND bwart = '101'
  AND werks IN s_werks AND budat IN s_budat.
  SORT it_101 BY aufnr mblnr.

  IF NOT it_101 IS INITIAL.
    SELECT mblnr zeile aufnr matnr menge meins werks shkzg budat rsnum FROM aufm INTO TABLE it_261 FOR ALL ENTRIES IN it_101 WHERE aufnr = it_101-aufnr
    AND mblnr = it_101-mblnr AND bwart IN ('261','531') AND werks IN s_werks AND budat IN s_budat.
    SELECT matnr maktx FROM makt APPENDING TABLE it_makt FOR ALL ENTRIES IN it_261 WHERE matnr = it_261-matnr.
    SELECT matnr matkl FROM mara APPENDING TABLE it_mara FOR ALL ENTRIES IN it_261 WHERE matnr = it_261-matnr.
    SORT it_makt BY matnr.
    DELETE ADJACENT DUPLICATES FROM it_makt COMPARING matnr.
    SORT it_mara BY matnr.
    DELETE ADJACENT DUPLICATES FROM it_mara COMPARING matnr.
    SORT it_261 BY aufnr.

************    for speedy process  27.07.2021
    SELECT aufnr rsnum FROM afko INTO TABLE it_afko1 FOR ALL ENTRIES IN it_261 WHERE aufnr = it_261-aufnr.

    SELECT rsnum matnr bdmng meins shkzg aufnr FROM resb INTO TABLE it_resb
                                              FOR ALL ENTRIES IN it_afko1 WHERE rsnum = it_afko1-rsnum.

*******************Begin of changes Added by Raj on 09.01.2024************
    SELECT  matnr  maktx FROM makt INTO TABLE it_makt1
                                               FOR ALL ENTRIES IN it_resb  WHERE matnr = it_resb-matnr.


*    DATA : lv_key TYPE string.
*    DATA: lv_pmt TYPE stpo-menge.
*    LOOP AT lt_stpo INTO ls_stpo.
*
*      CONCATENATE ls_stpo-stlnr ls_stpo-idnrk INTO lv_key.
*      ls_stpo-lv_key = lv_key.
*      MODIFY lt_stpo FROM ls_stpo TRANSPORTING lv_key.
**       lv_menge = lv_menge + ls_stpo-menge.
*      CLEAR : ls_stpo.
*    ENDLOOP.

*    SORT lt_stpo BY idnrk.
*    LOOP AT lt_stpo INTO ls_stpo.
*      lv_pmt = lv_pmt + ls_stpo-menge.
*      AT END OF idnrk.
*        ls_stpo-menge = lv_pmt.
*        MODIFY lt_stpo FROM ls_stpo TRANSPORTING menge.
*        CLEAR :ls_stpo,lv_pmt.
*      ENDAT.
**    endloop.
*
*
*
*    ENDLOOP.
*
*    SORT lt_stpo BY menge DESCENDING.
*    DELETE ADJACENT DUPLICATES FROM lt_stpo COMPARING lv_key .
************Summation of material qty if repeated********
*    DATA : lv_amt TYPE resb-bdmng.
*    SORT it_resb BY matnr.
*    LOOP AT it_resb INTO wa_resb.
*      lv_amt = lv_amt + wa_resb-bdmng.
*      AT END OF matnr.
*        wa_resb-bdmng = lv_amt.
*        MODIFY it_resb FROM wa_resb TRANSPORTING bdmng.
*        CLEAR : wa_resb,lv_amt.
*      ENDAT.
*      CLEAR : wa_resb.
*    ENDLOOP.
*
*    SORT it_resb BY bdmng DESCENDING.
*    DELETE ADJACENT DUPLICATES FROM it_resb COMPARING matnr.
*************Summation of material qty if repeated********
    LOOP AT it_makt1 INTO wa_makt1.
      LOOP AT it_resb INTO wa_resb WHERE  matnr = wa_makt1-matnr.
**       wa_resb-matnr = wa_makt1-matnr.
        wa_resb-lv_maktx = wa_makt1-maktx.
        MOVE-CORRESPONDING wa_makt1 TO wa_resb.
        MODIFY it_resb FROM wa_resb TRANSPORTING lv_maktx.
*      ENDIF.
        CLEAR :wa_resb.

      ENDLOOP.
      CLEAR: wa_makt1.
    ENDLOOP.



*******************Begin of changes Added by Raj on 09.01.2024************
******************** comment by parth 27.07.2021
*    SELECT rsnum matnr bdmng meins shkzg aufnr FROM resb INTO TABLE it_resb
*                                               FOR ALL ENTRIES IN it_261 WHERE aufnr = it_261-aufnr
*and werks = it_261-werks.

***********
*

    SELECT mblnr zeile smbln smblp matnr shkzg FROM mseg INTO TABLE it_262 FOR ALL ENTRIES IN it_261 WHERE smbln = it_261-mblnr
    AND  smblp = it_261-zeile AND bwart IN ('262','532') AND matnr = it_261-matnr.

    LOOP AT it_262 INTO wa_262.
      DELETE it_261 WHERE mblnr = wa_262-smbln AND zeile = wa_262-smblp AND matnr = wa_262-matnr.
      CLEAR wa_262.
    ENDLOOP.
  ENDIF.
****loop at it_261 into wa_261 where rsnum <> ' '.
****READ TABLE it_resb into wa_resb WITH  KEY rsnum = wa_261-rsnum
****                                          matnr = wa_261-matnr.
****if sy-subrc = 0.
****DELETE
****ENDIF.
**** ENDLOOP.
  LOOP AT it_261 INTO wa_261.
    IF wa_261-shkzg = 'S'.
      wa_261-menge = wa_261-menge * -1.
      MODIFY it_261 FROM wa_261 TRANSPORTING menge.
    ENDIF.
    CLEAR wa_261.
  ENDLOOP.
******************** not use code comment by parth 27.07.2021
*  IF NOT it_afko IS INITIAL.
*    SELECT stlnr idnrk posnr FROM stpo INTO TABLE it_stpo1 FOR ALL ENTRIES IN it_afko WHERE stlnr = it_afko-stlnr.
*    SORT it_stpo1 BY stlnr idnrk posnr.
*    DELETE ADJACENT DUPLICATES FROM it_stpo1 COMPARING stlnr idnrk posnr.
*    SELECT matnr maktx FROM makt APPENDING TABLE it_makt FOR ALL ENTRIES IN it_stpo1 WHERE matnr = it_stpo1-idnrk.
*    SORT it_makt BY matnr.
*    DELETE ADJACENT DUPLICATES FROM it_makt COMPARING matnr.
*  ENDIF.
*
*  LOOP AT it_stpo1 INTO wa_stpo1.
*    READ TABLE it_afko INTO wa_afko WITH KEY stlnr = wa_stpo1-stlnr.
*    READ TABLE it_261 INTO wa_261 WITH KEY aufnr = wa_afko-aufnr matnr = wa_stpo1-idnrk.
*    IF sy-subrc = 0.
*      MOVE-CORRESPONDING wa_stpo1 TO wa_stpo.
*      APPEND wa_stpo TO it_stpo.
*    ENDIF.
*    CLEAR : wa_stpo1,wa_afko,wa_stpo.
*  ENDLOOP.
********************************** comment end by parth 27.07.2021
  SORT it_261 BY aufnr mblnr matnr.


  SELECT aufnr fevor FROM caufv INTO TABLE it_plgrp FOR ALL ENTRIES IN it_261 WHERE aufnr = it_261-aufnr AND fevor IN s_fevor.
  SORT it_plgrp BY aufnr plgrp.
  DELETE ADJACENT DUPLICATES FROM it_plgrp COMPARING aufnr plgrp.


  LOOP AT it_261 INTO wa_261.
    READ TABLE it_aufk INTO wa_aufk WITH KEY aufnr = wa_261-aufnr.
    IF sy-subrc = 0.
      v_aufnr = wa_261-aufnr.
*AT NEW MBLNR.
      READ TABLE it_101 INTO wa_101 WITH KEY aufnr = v_aufnr mblnr = wa_261-mblnr.
      wa_final-aufnr    = wa_101-aufnr.
      wa_final-mblnr    = wa_101-mblnr.
      wa_final-101matnr = wa_101-matnr.
      wa_final-101menge = wa_101-menge.
      wa_final-101meins = wa_101-meins.
      SELECT SINGLE gamng gmein INTO (wa_final-totmenge,wa_final-totmeins) FROM afko WHERE aufnr = v_aufnr.
*ENDAT.
*      wa_final-261matnr = wa_261-matnr. " Commented on 06.07.2015
**********************************     Begin of changes on 06.07.2015
      wa_final-261matnr = wa_261-matnr.
      IF lv_temmatnr = wa_261-matnr AND v_aufnr1 = wa_261-aufnr AND v_mblnr1 = wa_261-mblnr.
        lv_tot_qty =  lv_tot_qty + wa_261-menge.
      ELSE.
        lv_tot_qty = wa_261-menge.
      ENDIF.
      wa_final-261menge =  lv_tot_qty.
      lv_temmatnr = wa_final-261matnr.
      v_aufnr1 = wa_261-aufnr.
      v_mblnr1 = wa_261-mblnr.
***********************************      End of Changes on 06.07.2015
*      wa_final-261menge = wa_261-menge.
*      wa_final-261meins = wa_261-meins.
      wa_final-werks    = wa_261-werks.
      wa_final-budat    = wa_261-budat.
      APPEND wa_final TO it_final.
      CLEAR : wa_final,wa_261,wa_101.
    ENDIF.
    CLEAR : wa_aufk.
  ENDLOOP.
  DATA : lt_final  TYPE STANDARD TABLE OF t_final,
         lw_final  TYPE t_final,
         lt_final1 TYPE STANDARD TABLE OF t_final,
         lw_final1 TYPE t_final.

  SORT it_final BY aufnr.
************************************Changed on 06.07.2015
  SORT it_final BY aufnr 261matnr 261menge DESCENDING.
  it_finallt0[] = it_final[].
  DELETE it_final WHERE 261menge < 0.
  DELETE it_finallt0 WHERE 261menge > 0.
  SORT it_finallt0 BY aufnr 261matnr 261menge ASCENDING.

  LOOP AT it_finallt0 INTO wa_final.
    APPEND wa_final TO it_final.
  ENDLOOP.
*************************************End of changes on 06.07.2015


*  lt_final1 = it_final.
*  SORT lt_final1 BY aufnr mblnr.
*  DELETE ADJACENT DUPLICATES FROM lt_final1 COMPARING aufnr mblnr.
*  LOOP AT lt_final1 INTO lw_final1.
  LOOP AT it_final INTO wa_final." where aufnr = lw_final1-aufnr
    "and mblnr = lw_final1-mblnr.
    lw_final = wa_final.
    APPEND wa_final TO lt_final1.
    AT END OF mblnr.
      LOOP AT it_resb INTO wa_resb WHERE aufnr = lw_final-aufnr.
        CLEAR wa_final.
        wa_final-aufnr = wa_resb-aufnr.
        wa_final-mblnr = lw_final-mblnr.
        wa_final-101matnr = lw_final-101matnr.
        wa_final-261matnr = wa_resb-matnr.
        wa_final-totmenge = lw_final-totmenge.
        wa_final-totmeins = lw_final-totmeins.
        wa_final-101menge = lw_final-101menge.
        wa_final-101meins = lw_final-101meins.
        wa_final-werks = lw_final-werks.
        wa_final-budat = lw_final-budat.
*        wa_final-261menge = wa_resb-bdmng. "Added by Raj on 09.01.2024
*        wa_final-261meins = wa_resb-meins. "Added by Raj on 09.01.2024
*        wa_final-261meins = lw_final-261meins.
*        wa_final-mein
*        wa_final-maktx = wa_resb-lv_maktx.
        APPEND wa_final TO lt_final1.
        CLEAR : wa_final,wa_resb.
      ENDLOOP.
    ENDAT.
    CLEAR lw_final.
  ENDLOOP.
*  sort lt_final1 by   261matnr 261menge ASCENDING.
  SORT lt_final1 BY aufnr mblnr 101matnr 261matnr.
*   SORT lt_final1 BY aufnr mblnr 101matnr 261matnr DESCENDING.
  DELETE ADJACENT DUPLICATES FROM lt_final1 COMPARING aufnr mblnr 101matnr 261matnr.
  LOOP AT lt_final1 INTO wa_final.
    READ TABLE it_final INTO lw_final WITH KEY aufnr = wa_final-aufnr
                                               mblnr = wa_final-mblnr
                                               101matnr = wa_final-101matnr
                                               261matnr = wa_final-261matnr.
    IF sy-subrc = 0.
      MODIFY lt_final1 FROM lw_final  .
    ENDIF.
  ENDLOOP.
  CLEAR it_final.
  it_final = lt_final1.
*    ENDLOOP.
  LOOP AT it_final INTO wa_final.
    MOVE-CORRESPONDING wa_final TO wa_final1.
    v_mblnr    = wa_final-mblnr.
    v_101matnr = wa_final-101matnr.
    v_totmenge = wa_final-totmenge.
    v_totmeins = wa_final-totmeins.
*AT NEW AUFNR.
    wa_final1-faufnr    = wa_final-aufnr.
    wa_final1-fmblnr    = v_mblnr.
    wa_final1-f101matnr = v_101matnr.
    wa_final1-ftotmenge = v_totmenge.
    wa_final1-ftotmeins = v_totmeins.
*ENDAT.
    READ TABLE it_afko INTO wa_afko WITH KEY aufnr = wa_final-aufnr.
    CONCATENATE wa_afko-sdatv+6(2) '.' wa_afko-sdatv+4(2) '.' wa_afko-sdatv+0(4) INTO v_date.
    READ TABLE it_stpo INTO wa_stpo WITH KEY stlnr = wa_afko-stlnr.
    CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
      EXPORTING
        capid                 = 'PP01'
        datuv                 = wa_afko-sdatv
        emeng                 = wa_final-totmenge
        mktls                 = 'X'
        mtnrv                 = wa_final-101matnr
        stlal                 = wa_afko-stlal
        stlan                 = wa_afko-stlan
        stpst                 = 0
        svwvo                 = 'X'
        werks                 = wa_final-werks
        vrsvo                 = 'X'
      TABLES
        stb                   = it_stb
      EXCEPTIONS
        alt_not_found         = 1
        call_invalid          = 2
        material_not_found    = 3
        missing_authorization = 4
        no_bom_found          = 5
        no_plant_data         = 6
        no_suitable_bom_found = 7
        conversion_error      = 8
        OTHERS                = 9.
    IF sy-subrc = 0.
*      READ TABLE it_stb INTO wa_stb WITH KEY idnrk = wa_final-261matnr. "POSNR = WA_STPO-POSNR. "changes 21/05/2015
      READ TABLE it_resb INTO wa_resb WITH KEY aufnr = wa_final-aufnr
                                               matnr = wa_final-261matnr.
      IF sy-subrc = 0.
        IF wa_resb-shkzg = 'S'.
          wa_resb-bdmng = wa_resb-bdmng * -1.
        ENDIF.
*IF WA_STB-MSIGN = '+'.
        wa_final1-stbmenge    = ( wa_resb-bdmng / wa_final-totmenge ) * wa_final-101menge.
        wa_final1-stbmeins    = wa_resb-meins.
      ENDIF.
*ENDIF.
    ENDIF.
    wa_final1-devmenge = wa_final1-stbmenge - wa_final1-261menge.
    IF wa_final1-stbmenge = '0.000' OR wa_final1-261menge = '0.000'.
      wa_final1-devmenpe = '100.000'.
    ELSEIF wa_final1-stbmenge = '0.000' AND  wa_final1-261menge = '0.000'.
      wa_final1-devmenpe = '0.000'.
    ELSE.
      wa_final1-devmenpe = ( ( wa_final1-stbmenge - wa_final1-261menge ) / wa_final1-stbmenge ) * 100.
    ENDIF.
    wa_final1-devmeins = wa_final1-stbmeins.
    READ TABLE it_plgrp INTO wa_plgrp WITH KEY aufnr = wa_final-aufnr.
    IF sy-subrc = 0.
      wa_final1-plgrp = wa_plgrp-plgrp.
    ENDIF.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_final-101matnr.
    IF sy-subrc = 0.
      wa_final1-maktx = wa_makt-maktx.
    ENDIF.
    CLEAR wa_makt.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_final-261matnr.
    IF sy-subrc = 0.
      wa_final1-maktx1 = wa_makt-maktx.
    ENDIF.
    READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_final-101matnr.
    IF sy-subrc = 0.
      wa_final1-matkl = wa_mara-matkl.
    ENDIF.
    APPEND wa_final1 TO it_final1.
    CLEAR : wa_final,wa_final1,v_mblnr,v_101matnr,v_totmenge,v_totmeins,wa_afko,wa_stpo,v_date,wa_plgrp,wa_makt,
            wa_mara,wa_resb.
  ENDLOOP.
  SORT it_plgrp BY plgrp.
  IF s_fevor IS NOT INITIAL.
    DATA  li_plgrp TYPE STANDARD TABLE OF t_plgrp.
    SORT it_final1 BY plgrp.
    DELETE it_final1 WHERE plgrp = ' '.
    li_plgrp = it_plgrp.
    DELETE ADJACENT DUPLICATES FROM li_plgrp COMPARING plgrp.
    LOOP AT it_final1 INTO wa_final1.
      READ TABLE li_plgrp INTO wa_plgrp WITH KEY plgrp = wa_final1-plgrp.
      IF sy-subrc <> 0.
        DELETE it_final1 WHERE plgrp = wa_final1-plgrp.
      ENDIF.
      CLEAR : wa_plgrp,wa_final1.
    ENDLOOP.
  ENDIF.
  DELETE it_final1 WHERE 101menge IS INITIAL.

  SELECT aufnr objnr igmng FROM caufv INTO TABLE it_objnr FOR ALL ENTRIES IN it_final1 WHERE aufnr = it_final1-faufnr.
  SORT it_objnr BY aufnr objnr.
  DELETE ADJACENT DUPLICATES FROM it_objnr COMPARING aufnr objnr.
  IF p_del = 'X'.
    SELECT objnr stat inact FROM jest INTO TABLE it_jest FOR ALL ENTRIES IN it_objnr
                                         WHERE objnr = it_objnr-objnr AND stat IN ('I0012','I0045')
    AND  inact NE 'X'.
  ELSE.
    SELECT objnr stat inact FROM jest INTO TABLE it_jest FOR ALL ENTRIES IN it_objnr
    WHERE objnr = it_objnr-objnr ."AND stat IN ('I0012','I0045'). "added 20/05/2015
  ENDIF.

  SORT it_jest BY objnr.
  IF p_del = 'X'.
    LOOP AT it_jest INTO wa_jest.
      IF ( wa_jest-stat = 'I0012' OR wa_jest-stat = 'I0045' )
        AND wa_jest-inact = 'X'.
        DELETE it_jest WHERE objnr = wa_jest-objnr.
      ENDIF.
      CLEAR wa_jest.
    ENDLOOP.
  ELSE.
    LOOP AT it_jest INTO wa_jest.
      IF ( wa_jest-stat = 'I0012' OR wa_jest-stat = 'I0045' )
        AND wa_jest-inact <> 'X'.
        DELETE it_jest WHERE objnr = wa_jest-objnr.
      ENDIF.
      CLEAR wa_jest.
    ENDLOOP.
  ENDIF.
  it_final01 = it_final1.
  REFRESH it_final1.
  CLEAR wa_final1.
  IF p_prod = 'X'.
    LOOP AT it_final01 INTO wa_final01.
      READ TABLE it_objnr INTO wa_objnr WITH KEY aufnr = wa_final01-faufnr.
      READ TABLE it_jest  INTO wa_jest  WITH KEY objnr = wa_objnr-objnr.
      IF sy-subrc = 0.
        MOVE-CORRESPONDING wa_final01 TO wa_final1.  " ADDED 19/05/2015
        APPEND wa_final1 TO it_final1.
        CLEAR wa_final1.
**      ELSE.                    "commented 19/05/2015
**        MOVE-CORRESPONDING wa_final01 TO wa_final1.
**        APPEND wa_final1 TO it_final1.
**        CLEAR wa_final1.
      ENDIF.
      CLEAR : wa_final01,wa_objnr,wa_jest.
    ENDLOOP.
  ENDIF.

  IF p_del = 'X'.
    LOOP AT it_final01 INTO wa_final01.
      READ TABLE it_objnr INTO wa_objnr WITH KEY aufnr = wa_final01-faufnr.
      READ TABLE it_jest  INTO wa_jest  WITH KEY objnr = wa_objnr-objnr.
      IF sy-subrc = 0.
        IF wa_jest-stat = 'I0045'.
          IF wa_objnr-igmng IS NOT INITIAL.
            MOVE-CORRESPONDING wa_final01 TO wa_final1.
            APPEND wa_final1 TO it_final1.
            CLEAR wa_final1.
          ENDIF.
        ELSE.
          MOVE-CORRESPONDING wa_final01 TO wa_final1.
          APPEND wa_final1 TO it_final1.
          CLEAR wa_final1.
        ENDIF.
      ELSE.
      ENDIF.
      CLEAR : wa_final01,wa_objnr,wa_jest.
    ENDLOOP.
  ENDIF.
  SORT it_final1[] BY f101matnr.
**************************************  comment by parth 13.02.2023
*  IF it_final1[] IS NOT INITIAL.
*    SELECT * FROM keko
*             INTO TABLE lt_keko
*             FOR ALL ENTRIES IN it_final1
*             WHERE matnr = it_final1-f101matnr
*               AND werks = it_final1-werks.
**    SELECT * FROM mbew
**               INTO TABLE lt_mbew1
**               FOR ALL ENTRIES IN lt_final1
**               WHERE matnr = lt_final1-261matnr
**                 AND bwkey = lt_final1-werks
**                 AND bwtar = space.
*
*    SORT lt_keko[] BY matnr kadat DESCENDING.
*    DELETE ADJACENT DUPLICATES FROM lt_keko[] COMPARING matnr.
*    IF lt_keko[] IS NOT INITIAL.
**      SELECT * FROM ckis
**               INTO TABLE lt_ckis
**               FOR ALL ENTRIES IN lt_keko
**               WHERE bzobj = lt_keko-bzobj
**               AND kalnr = lt_keko-kalnr
**               AND kalka = lt_keko-kalka
**               AND kadky = lt_keko-kadky
**               AND tvers = lt_keko-tvers
**               AND bwvar = lt_keko-bwvar.
********************** comment by parth 13.02.2024
**      SELECT * FROM ckis
**             INTO TABLE lt_ckis
**             FOR ALL ENTRIES IN lt_keko
**             WHERE lednr = '00'
**             AND  bzobj = lt_keko-bzobj
**             AND kalnr = lt_keko-kalnr
**             AND kalka = lt_keko-kalka
**             AND kadky = lt_keko-kadky
**             AND tvers = lt_keko-tvers
**             AND bwvar = lt_keko-bwvar.
***               AND typps = 'M'.
***                 AND matnr Ne space.
**      DELETE lt_ckis WHERE typps <> 'M'.
*****************   end by parth 13.02.2024
*
*      IF lt_ckis[] IS NOT INITIAL.
**        SELECT * FROM mbew
**                 INTO TABLE lt_mbew
**                 FOR ALL ENTRIES IN lt_ckis
**                 WHERE matnr = lt_ckis-matnr
**                   AND bwkey = lt_ckis-werks
**                   AND bwtar = space.
*      ENDIF.
*      LOOP AT it_final1 INTO wa_final1.
*        CLEAR : lwa_keko.
*        READ TABLE lt_keko INTO lwa_keko WITH KEY matnr = wa_final1-f101matnr
*                                                  werks = wa_final1-werks.
*        IF sy-subrc EQ 0.
*          CLEAR : lwa_ckis.
*          READ TABLE lt_ckis INTO lwa_ckis WITH KEY kalnr = lwa_keko-kalnr
*                                                    matnr = wa_final1-261matnr.
*          IF sy-subrc EQ 0.
*            IF lwa_ckis-gpreis IS NOT INITIAL.
*              wa_final1-stdprc = lwa_ckis-gpreis.
*            ELSEIF lwa_ckis-fpreis IS NOT INITIAL.
*              wa_final1-stdprc = lwa_ckis-fpreis.
*            ENDIF.
*            MODIFY it_final1 FROM wa_final1 TRANSPORTING stdprc.
**            CLEAR : lwa_mbew.
**            READ TABLE lt_mbew INTO lwa_mbew WITH KEY matnr = lwa_ckis-matnr vprsv = 'V'.
**            IF sy-subrc EQ 0.
**              wa_final1-curmap = lwa_mbew-verpr.
**              MODIFY it_final1 FROM wa_final1 TRANSPORTING curmap.
**            ELSE.
**              CLEAR : lwa_mbew.
**              READ TABLE lt_mbew INTO lwa_mbew WITH KEY matnr = lwa_ckis-matnr vprsv = 'S'.
**              IF sy-subrc EQ 0.
**                wa_final1-curmap = lwa_mbew-stprs.
**                MODIFY it_final1 FROM wa_final1 TRANSPORTING curmap.
**              ENDIF.
**            ENDIF.
**          ELSE.
**            CLEAR : lwa_mbew1.
**            READ TABLE lt_mbew1 INTO lwa_mbew1 WITH KEY matnr = wa_final1-261matnr vprsv = 'V'.
**            IF sy-subrc EQ 0.
**              wa_final1-curmap = lwa_mbew1-verpr.
**              MODIFY it_final1 FROM wa_final1 TRANSPORTING curmap.
**            ELSE.
**              CLEAR : lwa_mbew1.
**              READ TABLE lt_mbew1 INTO lwa_mbew1 WITH KEY matnr = wa_final1-261matnr vprsv = 'S'.
**              IF sy-subrc EQ 0.
**                wa_final1-curmap = lwa_mbew1-stprs.
**                MODIFY it_final1 FROM wa_final1 TRANSPORTING curmap.
**              ENDIF.
**            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*  ENDIF.
*********************** comment by parth 13.02.2024

*******************Added by Raj on 22.01.2024****************
  DATA : lv_mat TYPE makt-maktx.
  DATA: key_om TYPE string.

  IF it_final1 IS NOT INITIAL.
    LOOP AT it_final1 INTO wa_final1.
      CONCATENATE wa_final1-faufnr wa_final1-fmblnr INTO key_om.
      wa_final1-key_om = key_om.
      IF wa_final1-maktx1 IS INITIAL.
        LOOP AT it_resb INTO wa_resb WHERE matnr = wa_final1-261matnr.
          wa_final1-maktx1 = wa_resb-lv_maktx.
          wa_final1-stbmeins = wa_resb-meins.
          wa_final1-devmeins = wa_final1-stbmeins.
*          wa_final1-261meins = wa_resb-meins.

          MODIFY it_final1 FROM wa_final1 TRANSPORTING maktx1 stbmeins devmeins 261meins .
          CLEAR : wa_resb.
        ENDLOOP.

      ENDIF.
      MODIFY it_final1 FROM wa_final1 TRANSPORTING key_om.
      CLEAR : wa_final1,key_om.
    ENDLOOP.
  ENDIF.


  IF it_final1 IS NOT INITIAL.
    LOOP AT it_final1 INTO wa_final1.
      LOOP AT it_resb INTO wa_resb WHERE matnr = wa_final1-261matnr.
        IF wa_final1-stbmeins IS INITIAL.
          wa_final1-stbmeins = wa_resb-meins.
          wa_final1-devmeins = wa_final1-stbmeins.
*          wa_final1-261meins = wa_resb-meins.

          MODIFY it_final1 FROM wa_final1 TRANSPORTING stbmeins devmeins 261meins .
          CLEAR : wa_resb.
        ENDIF.
        CLEAR :wa_final1,wa_resb.
      ENDLOOP.
*      CLEAR : wa_final1,wa_resb.
    ENDLOOP.

  ENDIF.

***********BOM Qty*********
  DATA : lv_bmeng TYPE stko-bmeng.

*  it_final2[] = it_final1[].



*  IF it_final1 IS NOT INITIAL.
*    LOOP AT it_final1 INTO wa_final1.
*      READ TABLE it_afko INTO wa_afko WITH KEY aufnr = wa_final1-faufnr.
*      IF sy-subrc = 0.
*        READ TABLE it_stko INTO wa_stko WITH KEY stlnr = wa_afko-stlnr stlst = wa_afko-stlst.
*      ENDIF.
*      CONCATENATE wa_afko-stlnr wa_final1-261matnr INTO lv_key.
*      READ TABLE lt_stpo INTO ls_stpo WITH KEY lv_key = lv_key.
**      IF sy-subrc = 0.
*      IF  wa_stko-bmeng IS NOT INITIAL.
*        lv_bmeng =    ( ls_stpo-menge  / wa_stko-bmeng ) * wa_final1-101menge . "/ 1000.
*      ENDIF.
**      AT END OF key_om.
*
*      wa_final1-reqty  =       lv_bmeng .       "( ls_stpo-menge  *  wa_afko-gamng ) / wa_stko-bmeng . "/ 1000.
*      wa_final1-stlal = wa_stko-stlal.
*      wa_final1-stlnr = wa_stko-stlnr.
*
*      MODIFY it_final1 FROM wa_final1 TRANSPORTING reqty stlal stlnr.
*      CLEAR : lv_bmeng,wa_final1.
*
**      ENDAT.
*
** modify it_final1 from wa_final1 transporting reqty.
*      CLEAR : wa_final1,wa_afko,lv_key,ls_stpo,wa_stko.
*    ENDLOOP.
*  ENDIF.
*
*  it_final2[] = it_final1[].
*  DELETE ADJACENT DUPLICATES FROM it_final2 COMPARING f101matnr.
*
*  DATA : it_sttab TYPE STANDARD TABLE OF stpo_api02,
*         wa_sttab TYPE stpo_api02.
*  DATA : lv_matnrr TYPE mara-matnr.
*  DATA : lv_qty TYPE resb-bdmng.
*  DATA: lv_stlnr TYPE stko-stlnr.


*  LOOP AT it_final2 INTO wa_final2.
*    lv_stlnr = wa_final2-stlnr.
*    CALL FUNCTION 'CSAP_MAT_BOM_READ'
*      EXPORTING
*        material    = wa_final2-f101matnr
*        plant       = wa_final2-werks
*        bom_usage   = '1'
*        alternative = wa_final2-stlal
*      TABLES
*        t_stpo      = it_sttab.
*
*    IF it_sttab IS NOT INITIAL.
*      LOOP AT it_sttab INTO wa_sttab.
*        READ TABLE lt_stpo INTO ls_stpo WITH KEY idnrk = wa_sttab-component stlnr = wa_sttab-bom_no.
*        IF sy-subrc <> 0.
*          IF wa_sttab-comp_qty IS NOT INITIAL.
*            CALL FUNCTION 'MOVE_CHAR_TO_NUM'
*              EXPORTING
*                chr = wa_sttab-comp_qty
*              IMPORTING
*                num = lv_qty.
*          ENDIF.
*          wa_final1-261matnr = wa_sttab-component.
*          SELECT SINGLE maktx FROM makt INTO lv_mat WHERE matnr = wa_final1-261matnr.
*          wa_final1-faufnr = wa_final2-faufnr.
*          wa_final1-f101matnr = wa_final2-f101matnr.
*          wa_final1-maktx1 = lv_mat.
*          wa_final1-reqty   = lv_qty.
*          APPEND wa_final1 TO it_final1.
*          CLEAR :wa_sttab,lv_qty,lv_mat.
*        ENDIF.
*        CLEAR : wa_sttab,ls_stpo.
*      ENDLOOP.
*
*    ENDIF.
*    DELETE lt_stpo WHERE stlnr = lv_stlnr.
*    REFRESH : it_sttab.
*    CLEAR :wa_final1,LV_STLNR.
*  ENDLOOP.



*  LOOP AT it_sttab INTO wa_sttab.
*    READ TABLE lt_stpo INTO ls_stpo WITH KEY idnrk = wa_sttab-component.
*    IF sy-subrc <> 0.
*      if wa_sttab-comp_qty is not INITIAL.
*     CALL FUNCTION 'MOVE_CHAR_TO_NUM'
*     EXPORTING
*       CHR             = wa_sttab-comp_qty
*     IMPORTING
*       NUM             = lv_qty.
*      endif.
*      wa_final1-261matnr = wa_sttab-component.
*      select single maktx from makt into lv_mat where matnr = wa_final1-261matnr.
*      wa_final1-maktx1 = lv_mat.
*      wa_final1-reqty   = lv_qty.
*      APPEND wa_final1 TO it_final1.
*      CLEAR :wa_final1,wa_sttab,lv_qty,lv_mat.
*    ENDIF.
*    CLEAR : wa_sttab,ls_stpo.
*  ENDLOOP.


*******************Added by Raj on 22.01.2024****************
ENDFORM.                    " GET_QTY
*&---------------------------------------------------------------------*
*&      FORM  QTY_FCAT
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM qty_fcat .
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'FAUFNR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Production Order No'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'FMBLNR'.  wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material Doc No'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'WERKS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Plant'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'F101MATNR'.    wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Finished Material'.
  wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MAKTX'.    wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Finished Material Desc.'.
  wa_fcat-outputlen = '30'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MATKL'.    wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Material Group'.
  wa_fcat-outputlen = '15'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'FTOTMENGE'. wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Prod. Ord. Total Qty'.
  wa_fcat-outputlen = '8'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'FTOTMEINS'. wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = '101MENGE'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material Produced Qty'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 6.  wa_fcat-fieldname = '101MEINS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'BUDAT'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Posting Date'.
  wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 7.  wa_fcat-fieldname = '261MATNR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material Used'.
  wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'MAKTX1'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Material Used Desc.'.
  wa_fcat-outputlen = '30'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 8.  wa_fcat-fieldname = '261MENGE'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Used Qty'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*  wa_fcat-col_pos = 9.  wa_fcat-fieldname = '261MEINS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Unit'.
*  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 10.  wa_fcat-fieldname = 'STBMENGE'.     wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'BOM Qty'.  "Uncomment on 26.02.2024
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


*  wa_fcat-col_pos = 10.  wa_fcat-fieldname = 'STBMENGE'.     wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Required Qty'.
*  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 11.  wa_fcat-fieldname = 'STBMEINS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 12.  wa_fcat-fieldname = 'DEVMENGE'.     wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  'Deviation in Qty'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 12.  wa_fcat-fieldname = 'DEVMENPE'.     wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_l =  '% Deviation in Qty'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 13.  wa_fcat-fieldname = 'DEVMEINS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'PLGRP'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Prodn Supv'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*  wa_fcat-col_pos = 15.  wa_fcat-fieldname = 'STDPRC'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Std.Price'.
*  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*
*  wa_fcat-col_pos = 16.  wa_fcat-fieldname = 'CURMAP'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Current Price'.
*  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


*  wa_fcat-col_pos = 16.  wa_fcat-fieldname = 'REQTY'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'BOM Qty'.
*  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.  "Added by Raj on 09.01.2024

  wa_layout-zebra = 'X'.
ENDFORM.                    " QTY_FCAT
*&---------------------------------------------------------------------*
*&      FORM  ALV_DISPLAY
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM alv_display .

  IF p_time = 'X'.
    gd_repid = sy-repid.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = sy-repid
        i_callback_top_of_page = 'TOP_PAGE'
        is_layout              = wa_layout
        it_fieldcat            = it_fcat
        i_save                 = 'X'
        is_variant             = g_variant
      TABLES
        t_outtab               = it_fin
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

  ENDIF.

  IF p_quan = 'X'.
    gd_repid = sy-repid.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = gd_repid
        i_callback_top_of_page = 'TOP_PAGE'
        is_layout              = wa_layout
        it_fieldcat            = it_fcat
        i_save                 = 'X'
        is_variant             = g_variant
      TABLES
        t_outtab               = it_final1
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.

ENDFORM.                    " ALV_DISPLAY

FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).

  wa_header-typ = 'H'.
  IF p_time = 'X'.
    wa_header-info = 'Activity Details for Orders'.
  ELSE.
    wa_header-info = 'Material Details for Orders'.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_aufnr-high IS INITIAL.
    CONCATENATE 'Order No :- ' s_aufnr-low  ' TO ' s_aufnr-high INTO wa_header-info SEPARATED BY space.
  ELSE.
    LOOP AT s_aufnr.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_aufnr-low IS INITIAL.
          CONCATENATE wa_header-info ',' s_aufnr-low INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Order No :- ' s_aufnr-low INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_werks-high IS INITIAL.
    CONCATENATE 'Plant :- ' s_werks-low  ' TO ' s_werks-high INTO wa_header-info SEPARATED BY space.
  ELSE.
    LOOP AT s_werks.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_werks-low IS INITIAL.
          CONCATENATE wa_header-info ',' s_werks-low INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Plant :- ' s_werks-low INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_budat-high IS INITIAL.
    CONCATENATE s_budat-low+6(2) '-' s_budat-low+4(2) '-' s_budat-low+0(4) INTO v_lowdate.
    CONCATENATE s_budat-high+6(2) '-' s_budat-high+4(2) '-' s_budat-high+0(4) INTO v_highdate.
    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
  ELSE.
    CONCATENATE s_budat-low+6(2) '-' s_budat-low+4(2) '-' s_budat-low+0(4) INTO v_lowdate.
    LOOP AT s_budat.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_budat-low IS INITIAL.
          CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Date :- ' v_lowdate INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CLEAR : v_lowdate,v_highdate.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_header.
*      I_LOGO             = 'ASTRALS'.

  CLEAR wa_header.
  REFRESH it_header.
ENDFORM.

*&---------------------------------------------------------------------*
*&      FORM  GET_ACTVT1
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM get_actvt1 .
**** Begin of 19/05/2015
  SELECT afru~aufnr afru~rueck afru~arbid afru~werks afru~ile01 afru~ism01 afru~ile02 afru~ism02 afru~ile03 afru~ism03 crhd~arbpl
  afru~lmnga afru~meinh afru~stzhl afru~rmzhl afru~budat
  FROM afru INNER JOIN crhd ON afru~arbid = crhd~objid
  INTO TABLE it_afru WHERE afru~aufnr IN s_aufnr AND afru~werks IN s_werks AND afru~budat IN s_budat
  AND afru~stokz NE 'X'.

  DELETE it_afru WHERE stzhl NE ''.
  SORT it_afru BY aufnr rmzhl.
  IF it_afru IS NOT INITIAL.
    SELECT aufnr plnbez gamng igmng idat2 fevor werks FROM caufv INTO TABLE it_caufv FOR ALL ENTRIES IN it_afru WHERE aufnr EQ it_afru-aufnr
    AND erdat IN s_budat AND werks IN s_werks AND fevor IN s_fevor.
    SELECT aufnr plnbez gamng igmng idat2 fevor FROM caufv APPENDING TABLE it_caufv FOR ALL ENTRIES IN it_afko WHERE aufnr EQ it_afko-aufnr.
**** end of 19/05/2015
  ENDIF.
**  SELECT aufnr plnbez gamng igmng idat2 fevor FROM caufv INTO TABLE it_caufv FOR ALL ENTRIES IN IT_AFKO WHERE aufnr EQ it_afru-aufnr
**AND erdat IN s_budat AND werks IN s_werks.
  IF it_caufv IS NOT INITIAL.
    SORT it_caufv BY aufnr. "added 19/05/2015
    DELETE it_caufv WHERE idat2 NE '00000000'.
    DELETE ADJACENT DUPLICATES FROM it_caufv COMPARING aufnr aufnr plnbez gamng igmng idat2 fevor.  " added 19/05/2015

    SELECT aufnr objnr igmng FROM caufv INTO TABLE it_objnr FOR ALL ENTRIES IN it_caufv WHERE aufnr = it_caufv-aufnr.
    SORT it_objnr BY aufnr objnr.
    DELETE ADJACENT DUPLICATES FROM it_objnr COMPARING aufnr objnr.

    SELECT objnr stat FROM jest INTO TABLE it_jest FOR ALL ENTRIES IN it_objnr WHERE objnr = it_objnr-objnr AND stat IN ('I0012','I0045').
    SORT it_jest BY stat.     "added 19/05/2015
    DELETE it_jest WHERE ( stat = 'I0012' OR stat = 'I0045' ).
    LOOP AT it_caufv INTO wa_caufv.
      READ TABLE it_aufk INTO wa_aufk WITH KEY aufnr = wa_caufv-aufnr.
      IF sy-subrc = 0.
        IF wa_caufv-gamng GT wa_caufv-igmng." AND wa_caufv-igmng IS NOT INITIAL. "commented 19/05/2015
          wa_fin2-aufnr = wa_caufv-aufnr.
          wa_fin2-werks = wa_caufv-werks.
          READ TABLE it_afko INTO wa_afko WITH KEY aufnr = wa_caufv-aufnr.
          IF NOT wa_afko-plnty IS INITIAL AND NOT wa_afko-plnnr IS INITIAL AND NOT wa_afko-plnal IS INITIAL AND NOT wa_afko-plnbez IS INITIAL.
            CALL FUNCTION 'CARO_ROUTING_READ'
              EXPORTING
                date_from            = '19000101'
                date_to              = '99991231'
                plnty                = wa_afko-plnty
                plnnr                = wa_afko-plnnr
                plnal                = wa_afko-plnal
                matnr                = wa_afko-plnbez
                buffer_del_flg       = 'X'
                delete_all_cal_flg   = 'X'
                adapt_flg            = 'X'
                iv_create_add_change = ' '
              TABLES
                opr_tab              = it_opr_tab.
            IF sy-subrc = 0.
              READ TABLE it_opr_tab INTO wa_opr_tab INDEX 1.
              wa_fin2-vgw01 = wa_opr_tab-vgw01.
              wa_fin2-vge01 = wa_opr_tab-vge01.
              IF wa_fin2-vge01 = 'H'.
                wa_fin2-vgw01 = wa_fin2-vgw01 * 60.
                wa_fin2-vge01 = 'MIN'.
              ENDIF.
              wa_fin2-vgw02 = ( 1 * wa_opr_tab-vgw02 ) / wa_opr_tab-bmsch.
              wa_fin2-vge02 = wa_opr_tab-vge02.
              IF wa_fin2-vge02 = 'H'.
                wa_fin2-vgw02 = wa_fin2-vgw02 * 60.
                wa_fin2-vge02 = 'MIN'.
              ENDIF.
              wa_fin2-vgw03 = ( 1 * wa_opr_tab-vgw03 ) / wa_opr_tab-bmsch.
              wa_fin2-vge03 = wa_opr_tab-vge03.
              IF wa_fin2-vge03 = 'H'.
                wa_fin2-vgw03 = wa_fin2-vgw03 * 60.
                wa_fin2-vge03 = 'MIN'.
              ENDIF.
              v_difqty = wa_caufv-gamng - wa_caufv-igmng .
              wa_fin2-totalqty = wa_caufv-gamng.
              wa_fin2-remqty = wa_caufv-gamng - wa_caufv-igmng.
* WA_FIN2-RQVGW01 = ( V_DIFQTY * WA_FIN2-VGW01 ) / WA_CAUFV-GAMNG.
* WA_FIN2-RQVGE01 = WA_OPR_TAB-VGE01.
              wa_fin2-rqvgw01 = wa_fin2-vgw01.
              wa_fin2-rqvge01 = wa_opr_tab-vge01.
              wa_fin2-rqvgw02 = v_difqty * wa_fin2-vgw02.
              wa_fin2-rqvge02 = wa_opr_tab-vge02.
              wa_fin2-rqvgw03 = v_difqty * wa_fin2-vgw03.
              wa_fin2-rqvge03 = wa_opr_tab-vge03.
              READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_caufv-plnbez.
              wa_fin2-matnr = wa_makt-matnr.
              wa_fin2-maktx = wa_makt-maktx.
              wa_fin2-plgrp = wa_caufv-fevor.
              wa_fin2-gstrs = wa_afko-gstrs.
              wa_fin2-gltrs = wa_afko-gltrs.
              wa_fin2-ftrmi = wa_afko-ftrmi.
              APPEND wa_fin2 TO it_fin2.
            ENDIF.
          ENDIF.
        ENDIF.
        CLEAR : wa_fin2,wa_opr_tab,wa_afko,wa_caufv,v_difqty,wa_makt.
        REFRESH it_opr_tab.
      ENDIF.
      CLEAR : wa_aufk.
      CLEAR : wa_caufv.
    ENDLOOP.
  ENDIF.
ENDFORM.                    " GET_ACTVT1
*&---------------------------------------------------------------------*
*&      FORM  ACTVT_FCAT1
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM actvt_fcat1 .
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'AUFNR'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Production Order No'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'MATNR'.    wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Material No'.
  wa_fcat-outputlen = '15'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MAKTX'.    wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Material Description'.
  wa_fcat-outputlen = '30'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'TOTALQTY'.    wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Prod. Ord. Total Qty'.
  wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'VGW01'. wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Setup Time'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'VGE01'. wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = 'VGW02'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'M/C Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 6.  wa_fcat-fieldname = 'VGE02'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'VGW03'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Labor Time'.
  wa_fcat-outputlen = '9'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 8.  wa_fcat-fieldname = 'VGE03'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 9.  wa_fcat-fieldname = 'REMQTY'.    wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_m =  'Remaining Qty'.
  wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 17.  wa_fcat-fieldname = 'RQVGW01'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Planned Setup Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 18.  wa_fcat-fieldname = 'RQVGE01'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =   'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 19.  wa_fcat-fieldname = 'RQVGW02'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Planned Machine Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 20.  wa_fcat-fieldname = 'RQVGE02'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 21.  wa_fcat-fieldname = 'RQVGW03'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Planned Labor Time'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'RQVGE03'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 23.  wa_fcat-fieldname = 'PLGRP'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Prodn Supv'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 24.  wa_fcat-fieldname = 'GSTRS'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Sched. Start Dt'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 25.  wa_fcat-fieldname = 'GLTRS'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Sched. End Dt'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 26.  wa_fcat-fieldname = 'FTRMI'.       wa_fcat-tabname = 'IT_FIN2'. wa_fcat-seltext_l =  'Act. Release Dt'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_layout-zebra = 'X'.
ENDFORM.                    " ACTVT_FCAT1
*&---------------------------------------------------------------------*
*&      FORM  ALV_DISPLAY1
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM alv_display1 .
  IF p_time = 'X'.
    gd_repid = sy-repid.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = gd_repid
        i_callback_top_of_page = 'TOP_PAGE'
        is_layout              = wa_layout
        it_fieldcat            = it_fcat
        i_save                 = 'X'
        is_variant             = g_variant
      TABLES
        t_outtab               = it_fin2
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.

  IF p_quan = 'X'.
    gd_repid = sy-repid.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = gd_repid
        i_callback_top_of_page = 'TOP_PAGE'
        is_layout              = wa_layout
        it_fieldcat            = it_fcat
        i_save                 = 'X'
        is_variant             = g_variant
      TABLES
        t_outtab               = it_fin3
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.

ENDFORM.                    " ALV_DISPLAY1
*&---------------------------------------------------------------------*
*&      FORM  GET_QTY1
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM get_qty1 .

  SELECT aufnr plnbez gamng igmng idat2 fevor FROM caufv INTO TABLE it_caufv FOR ALL ENTRIES IN it_afko WHERE aufnr EQ it_afko-aufnr
  AND erdat IN s_budat AND werks IN s_werks AND fevor IN s_fevor.

  DELETE it_caufv WHERE idat2 NE '00000000'.
  SELECT rsnum matnr bdmng meins shkzg aufnr FROM resb INTO TABLE it_resb
  FOR ALL ENTRIES IN it_caufv WHERE aufnr = it_caufv-aufnr.
  LOOP AT it_caufv INTO wa_caufv.
    READ TABLE it_aufk INTO wa_aufk WITH KEY aufnr = wa_caufv-aufnr.
    IF sy-subrc = 0.
      IF wa_caufv-gamng GT wa_caufv-igmng.
        v_difqty = wa_caufv-gamng - wa_caufv-igmng.
        READ TABLE it_afko INTO wa_afko WITH KEY aufnr = wa_caufv-aufnr.

**-------- FOR TOTAL QTY--------------------------------------------**
        CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
          EXPORTING
            capid                 = 'PP01'
            datuv                 = wa_afko-sdatv
            emeng                 = wa_caufv-gamng
            mktls                 = 'X'
            mtnrv                 = wa_caufv-plnbez
            stlal                 = wa_afko-stlal
            stlan                 = wa_afko-stlan
            stpst                 = 0
            svwvo                 = 'X'
            werks                 = s_werks-low
            vrsvo                 = 'X'
          TABLES
            stb                   = it_stb
          EXCEPTIONS
            alt_not_found         = 1
            call_invalid          = 2
            material_not_found    = 3
            missing_authorization = 4
            no_bom_found          = 5
            no_plant_data         = 6
            no_suitable_bom_found = 7
            conversion_error      = 8
            OTHERS                = 9.
        IF sy-subrc = 0.
*          LOOP AT it_stb INTO wa_stb.  changes 21/052015
          LOOP AT it_resb INTO wa_resb WHERE aufnr = wa_caufv-aufnr.
            IF wa_resb-shkzg = 'S'.
              wa_resb-bdmng =  wa_resb-bdmng * -1.
            ENDIF.
            wa_temp-aufnr       = wa_caufv-aufnr.
            wa_temp-101matnr    = wa_caufv-plnbez.
            wa_temp-totqty      = wa_caufv-gamng.
            wa_temp-remqty      = wa_caufv-gamng - wa_caufv-igmng.
            wa_temp-261matnr    = wa_resb-matnr.
            wa_temp-ormenge     = wa_resb-bdmng.
            wa_temp-ormeins     = wa_resb-meins.
            APPEND wa_temp TO it_temp.
            CLEAR : wa_temp,wa_resb.
          ENDLOOP.
        ENDIF.
        REFRESH : it_stb.

**-------- FOR REMAINING QTY--------------------------------------------**
        CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
          EXPORTING
            capid                 = 'PP01'
            datuv                 = wa_afko-sdatv
            emeng                 = v_difqty
            mktls                 = 'X'
            mtnrv                 = wa_caufv-plnbez
            stlal                 = wa_afko-stlal
            stlan                 = wa_afko-stlan
            stpst                 = 0
            svwvo                 = 'X'
            werks                 = s_werks-low
            vrsvo                 = 'X'
          TABLES
            stb                   = it_stb
          EXCEPTIONS
            alt_not_found         = 1
            call_invalid          = 2
            material_not_found    = 3
            missing_authorization = 4
            no_bom_found          = 5
            no_plant_data         = 6
            no_suitable_bom_found = 7
            conversion_error      = 8
            OTHERS                = 9.
        IF sy-subrc = 0.
*          LOOP AT it_stb INTO wa_stb. changes 21/05/2015
          LOOP AT it_resb INTO wa_resb WHERE aufnr = wa_caufv-aufnr.
            IF wa_resb-shkzg = 'S'.
              wa_resb-bdmng =  wa_resb-bdmng * -1.
            ENDIF.
            LOOP AT it_temp INTO wa_temp WHERE 261matnr = wa_resb-matnr AND aufnr = wa_caufv-aufnr.
              wa_temp-reqmenge    = ( wa_resb-bdmng / wa_temp-totqty ) * wa_temp-remqty.
              wa_temp-reqmeins    = wa_resb-meins.
              MODIFY it_temp FROM wa_temp TRANSPORTING reqmenge reqmeins.
              CLEAR: wa_temp,wa_resb.
            ENDLOOP.
          ENDLOOP.
        ENDIF.
        REFRESH it_stb.
        IF it_temp IS NOT INITIAL.
          SELECT matnr maktx FROM makt APPENDING TABLE it_makt FOR ALL ENTRIES IN it_temp
          WHERE matnr = it_temp-261matnr.
        ENDIF.
        SORT it_makt BY matnr.
        LOOP AT it_temp INTO wa_temp.
          MOVE-CORRESPONDING wa_temp TO wa_fin3.
          wa_fin3-plgrp = wa_caufv-fevor.
          READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_temp-261matnr.
          IF sy-subrc = 0.
            wa_fin3-maktx = wa_makt-maktx.
          ENDIF.
          CLEAR wa_makt.
          READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_temp-101matnr.
          IF sy-subrc = 0.
            wa_fin3-maktx1 = wa_makt-maktx.
          ENDIF.
          CLEAR wa_makt.
          READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_temp-101matnr.
          IF sy-subrc = 0.
            wa_fin3-matkl = wa_mara-matkl.
          ENDIF.
          CLEAR wa_mara.
          APPEND wa_fin3 TO it_fin3.
          CLEAR : wa_fin3,wa_temp.
        ENDLOOP.
      ENDIF.
      REFRESH it_temp.
      CLEAR : wa_caufv,wa_afko,v_difqty.
    ENDIF.
    CLEAR : wa_aufk.
  ENDLOOP.
ENDFORM.                    " GET_QTY1
*&---------------------------------------------------------------------*
*&      FORM  QTY_FCAT1
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM qty_fcat1 .

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'AUFNR'.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Production Order No'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = '101MATNR'.    wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Finished Material'.
  wa_fcat-outputlen = '17'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MAKTX'.    wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_l =  'Finished Material Desc.'.
  wa_fcat-outputlen = '30'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'MAKTL'.    wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Material Group'.
  wa_fcat-outputlen = '17'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'TOTQTY'. wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Total Qty'.
  wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'REMQTY'. wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Remaining Qty'.
  wa_fcat-outputlen = '14'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = '261MATNR'.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Required Material'.
  wa_fcat-outputlen = '17'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = 'MAKTX1'.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_l =  'Required Material Desc.'.
  wa_fcat-outputlen = '30'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 6.  wa_fcat-fieldname = 'ORMENGE'.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Total Req Qty'.
  wa_fcat-outputlen = '14'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'ORMEINS '.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_m =  'Unit'.
  wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 8.  wa_fcat-fieldname = 'REQMENGE'.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_l =  'Remaining Req. Qty'.
  wa_fcat-outputlen = '14'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 9.  wa_fcat-fieldname = 'REQMEINS '.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_l =  'Unit'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 10.  wa_fcat-fieldname = 'PLGRP '.       wa_fcat-tabname = 'IT_FIN3'. wa_fcat-seltext_l =  'Prodn Supv'.
  wa_fcat-outputlen = '9'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_layout-zebra = 'X'.
ENDFORM.                    " QTY_FCAT1
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization .
  SELECT werks FROM t001w INTO TABLE it_t001w WHERE werks IN s_werks.
  LOOP AT it_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'ZCNF_WRK'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.

ENDFORM.
