*&---------------------------------------------------------------------*
*& Report  ZPP_DAILY_PRODUCTION_BI
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zpp_daily_production_bi.



TABLES: mvke,aufm,marc.

*&---------------------------------------------------------------------*
*& Type-Pool Declaration
*&---------------------------------------------------------------------*
TYPE-POOLS: slis.

*&---------------------------------------------------------------------*
*& ALV Data Declaration
*&---------------------------------------------------------------------*
DATA: it_fieldcat            TYPE slis_t_fieldcat_alv.
DATA: wa_fieldcat            LIKE LINE OF it_fieldcat.
DATA: t_list_top_of_page     TYPE slis_t_listheader.
DATA: it_events              TYPE slis_t_event WITH HEADER LINE.
DATA: g_save                 TYPE c VALUE 'A'.
DATA: gx_save                TYPE c VALUE 'A'.
DATA: gx_variant             TYPE disvariant.
DATA: g_variant              TYPE disvariant.
DATA: gs_layout              TYPE slis_layout_alv.
DATA: t_formname_top_of_page TYPE slis_formname VALUE 'TOP_OF_PAGE'.
DATA: t_i_event              TYPE slis_alv_event.
*--- Object and variable declaration list for ALV grid display-------*
DATA: lt_fieldcat  TYPE slis_t_fieldcat_alv,
      lwa_fieldcat TYPE slis_fieldcat_alv,
      gd_layout    TYPE slis_layout_alv,
      gd_repid     LIKE sy-repid.

TYPES : BEGIN OF t_mvke,
          kondm TYPE mvke-kondm,
          mvgr1 TYPE mvke-mvgr1,
          matnr TYPE mvke-matnr,
        END OF t_mvke.

DATA : it_mvke TYPE STANDARD TABLE OF t_mvke,
       wa_mvke TYPE t_mvke.
TYPES : BEGIN OF t_mara,
          matnr TYPE mara-matnr,
          mtart TYPE mara-mtart,
          matkl TYPE mara-matkl,
          ntgew TYPE mara-ntgew,
        END OF t_mara.

DATA : it_mara TYPE STANDARD TABLE OF t_mara,
       wa_mara TYPE t_mara.

DATA : it_rm261mara TYPE STANDARD TABLE OF t_mara,
       it_rp261mara TYPE STANDARD TABLE OF t_mara,
       it_rp531mara TYPE STANDARD TABLE OF t_mara,
       it_sc531mara TYPE STANDARD TABLE OF t_mara.

DATA : it_marc TYPE STANDARD TABLE OF marc,
       wa_marc TYPE marc.

TYPES : BEGIN OF t_mseg,
          mblnr      TYPE mseg-mblnr,
          mjahr      TYPE mseg-mjahr,
          aufnr      TYPE mseg-aufnr,
          bwart      TYPE mseg-bwart,
          smbln      TYPE mseg-smbln,
          matnr      TYPE mseg-matnr,
          werks      TYPE mseg-werks,
          menge      TYPE mseg-menge,
          meins      TYPE mseg-meins,
          budat_mkpf TYPE mseg-budat_mkpf,
        END OF t_mseg.

DATA : it_mseg TYPE STANDARD TABLE OF t_mseg,
       wa_mseg TYPE t_mseg.



TYPES : BEGIN OF t_aufm,
          mblnr TYPE aufm-mblnr,
          aufnr TYPE aufm-aufnr,

          mjahr TYPE aufm-mjahr,
          budat TYPE aufm-budat,
          bwart TYPE aufm-bwart,
          matnr TYPE aufm-matnr,
          menge TYPE aufm-menge,
          werks TYPE aufm-werks,
          matkl TYPE mara-matkl,

        END OF t_aufm.

DATA : it_aufm TYPE STANDARD TABLE OF t_aufm,
       wa_aufm TYPE t_aufm.
DATA : it_aufm1 TYPE STANDARD TABLE OF t_aufm,
       wa_aufm1 TYPE t_aufm.
DATA : it_aufm2 TYPE STANDARD TABLE OF t_aufm,
       wa_aufm2 TYPE t_aufm.
DATA : it_aufm_mvty TYPE  STANDARD TABLE OF t_aufm,
       wa_aufm_mvty TYPE t_aufm.

DATA : it_aufmrm261 TYPE STANDARD TABLE OF t_aufm,
       wa_aufmrm261 TYPE t_aufm.
DATA : it_aufmrp261 TYPE STANDARD TABLE OF t_aufm,
       wa_aufmrp261 TYPE t_aufm.
DATA : it_aufmrp531 TYPE STANDARD TABLE OF t_aufm,
       wa_aufmrp531 TYPE t_aufm.
DATA : it_aufmsc531 TYPE STANDARD TABLE OF t_aufm,
       wa_aufmsc531 TYPE t_aufm.

TYPES: BEGIN OF t_afko,
         aufnr  TYPE afko-aufnr,
         plnbez TYPE afko-plnbez,
       END OF t_afko.
DATA : it_afko TYPE STANDARD TABLE OF t_afko,
       wa_afko TYPE t_afko.

TYPES : BEGIN OF t_afru,
          aufnr TYPE afru-aufnr,
          arbid TYPE afru-arbid,
        END OF t_afru.
DATA : it_afru TYPE STANDARD TABLE OF t_afru,
       wa_afru TYPE t_afru.

TYPES : BEGIN OF t_crhd,
          objid TYPE crhd-objid,
          arbpl TYPE crhd-arbpl,
        END OF t_crhd.
DATA : it_crhd TYPE STANDARD TABLE OF t_crhd,
       wa_crhd TYPE t_crhd.

DATA : it_makt TYPE STANDARD TABLE OF makt,
       wa_makt TYPE makt.
DATA : v_rm01 TYPE aufm-menge.
DATA : v_1rm01 TYPE aufm-menge.
DATA : v_rp TYPE aufm-menge.
DATA : v_1rp TYPE aufm-menge.
DATA : v_vp TYPE aufm-menge.
DATA : v_1vp TYPE aufm-menge.
DATA : v_sc TYPE aufm-menge.
DATA : v_1sc TYPE aufm-menge.
DATA : v_matnr TYPE mvke-matnr.
DATA : qty  TYPE aufm-menge.
DATA : 1qty  TYPE aufm-menge.
DATA: v_aufnr TYPE aufm-aufnr.
DATA: v_werks TYPE aufm-werks.
DATA : v_budat TYPE mseg-budat_mkpf.

TYPES: BEGIN OF t_final,
         matnr     TYPE mvke-matnr,
         aufnr     TYPE aufm-aufnr,
         mblnr     TYPE aufm-mblnr,
         mgp       TYPE mvke-mvgr1,
         desm      TYPE tvm1t-bezei,
         desk      TYPE t178t-vtext,
         prg       TYPE mvke-kondm,
         rm01      TYPE aufm-menge,
         1rm01     TYPE aufm-menge,
         rp        TYPE aufm-menge,
         1rp       TYPE aufm-menge,
         vp        TYPE aufm-menge,
         1vp       TYPE aufm-menge,
         sc        TYPE aufm-menge,
         1sc       TYPE aufm-menge,
         value     TYPE aufm-menge,
         rpavg     TYPE aufm-menge,
         scavg     TYPE aufm-menge,
         desc      TYPE makt-maktx,
         qty       TYPE aufm-menge,
         1qty      TYPE aufm-menge,
         type(15),
         arbpl     TYPE crhd-arbpl,
         group(50),
         weight    TYPE p DECIMALS 2,
         werks     TYPE aufm-werks,
         budat     TYPE aufm-budat,
         mdesc(60),
       END OF t_final.
DATA: it_final TYPE STANDARD TABLE OF t_final,
      wa_final TYPE t_final.

DATA: it_final1 TYPE STANDARD TABLE OF t_final,
      wa_final1 TYPE t_final.
DATA : it_tvm1t TYPE STANDARD TABLE OF tvm1t,
       wa_tvm1t TYPE tvm1t.

DATA : it_t178t TYPE STANDARD TABLE OF t178t,
       wa_t178t TYPE t178t.

TYPES : BEGIN OF ty_matkl,
          low TYPE mara-matkl,
        END OF ty_matkl.
DATA : it_rm261  TYPE STANDARD TABLE OF ty_matkl,
       wa_rm261  TYPE ty_matkl,
       it_rp261  TYPE STANDARD TABLE OF ty_matkl,
       wa_rp261  TYPE ty_matkl,
       it_rp531  TYPE STANDARD TABLE OF ty_matkl,
       wa_rp531  TYPE ty_matkl,
       it_sc531  TYPE STANDARD TABLE OF ty_matkl,
       wa_sc531  TYPE ty_matkl,
       it_grpdel TYPE STANDARD TABLE OF ty_matkl,
       wa_grpdel TYPE ty_matkl.

TYPES : BEGIN OF ty_wcdel,
          arbpl TYPE crhd-arbpl,
        END OF ty_wcdel.
DATA : it_wcdel TYPE STANDARD TABLE OF ty_wcdel,
       wa_wcdel TYPE ty_wcdel.

TYPES: BEGIN OF ty_t001w,
         werks TYPE werks_d,
       END OF ty_t001w.
DATA : it_t001w TYPE STANDARD TABLE OF ty_t001w,
       wa_t001w TYPE ty_t001w.

DATA : it_aufm_mara TYPE STANDARD TABLE OF t_mara.

DATA : dbs TYPE dbcon-con_name.
DATA : wa_flag(1),
       lv_mjahr   TYPE aufm-mjahr,
       lv_mjahr1  TYPE aufm-mjahr.
wa_flag = 0.


CONSTANTS : c_rm261  TYPE rvari_vnam VALUE 'ZPP_RM261_NEW',
            c_rp261  TYPE rvari_vnam VALUE 'ZPP_RP261_NEW',
            c_rp531  TYPE rvari_vnam VALUE 'ZPP_RP531_NEW',
            c_sc531  TYPE rvari_vnam VALUE 'ZPP_SC531_NEW',
            c_grpdel TYPE rvari_vnam VALUE 'Z_PRD_GRP_DEL',
            c_wcdel  TYPE rvari_vnam VALUE 'Z_PRD_WC_DEL'.

*======================================================================*
*                     SELECTION SCREEN                                 *
*======================================================================*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS: s_plant FOR marc-werks OBLIGATORY.
SELECT-OPTIONS: s_budat FOR aufm-budat OBLIGATORY.
SELECT-OPTIONS: s_mjahr FOR aufm-mjahr NO-DISPLAY.
SELECTION-SCREEN : END OF BLOCK b1.

SELECTION-SCREEN : BEGIN OF BLOCK a3 WITH FRAME TITLE text-003.
*PARAMETERS: variant LIKE disvariant-variant.
PARAMETERS : chk1 AS CHECKBOX.
SELECTION-SCREEN : END OF BLOCK a3.

*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
START-OF-SELECTION.
*&---------------------------------------------------------------------*
*  PERFORM authorization_check.
  PERFORM get_data.
  PERFORM transfer_bi.
*  PERFORM build_fieldcatalog.
* perform build_layout.
*  PERFORM display_alv_report.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  SELECT low
     INTO TABLE it_rm261
     FROM tvarvc
     WHERE name = c_rm261 .

  SELECT low
    INTO TABLE it_rp261
    FROM tvarvc
    WHERE name = c_rp261 .

  SELECT low
     INTO TABLE it_rp531
     FROM tvarvc
     WHERE name = c_rp531 .

  SELECT low
   INTO TABLE it_sc531
   FROM tvarvc
   WHERE name = c_sc531 .

*  SELECT low
*   INTO TABLE it_grpdel
*   FROM tvarvc
*   WHERE name = c_grpdel .
*
*  SELECT low
*   INTO TABLE it_wcdel
*   FROM tvarvc
*   WHERE name = c_wcdel .


  SELECT kondm mvgr1 matnr FROM mvke INTO TABLE it_mvke.
*    WHERE vkorg = '1000'
*    AND vtweg   = '10'
*    AND mvgr1 IN ('01','02','03').


  "---------------------------------------------------------------------------------------
  SELECT matnr mtart matkl ntgew FROM mara INTO TABLE it_mara
    WHERE mtart IN ('FERT','HALB').

*  SELECT matnr mtart matkl FROM mara INTO TABLE it_rm261mara
*    FOR ALL ENTRIES IN it_rm261
*    WHERE mtart IN ('FERT','HALB')
*    AND   matkl = it_rm261-low.
*
*  SELECT matnr mtart matkl FROM mara INTO TABLE it_rp261mara
*   FOR ALL ENTRIES IN it_rp261
*   WHERE mtart IN ('FERT','HALB')
*   AND   matkl = it_rp261-low.
*
*
*  SELECT matnr mtart matkl FROM mara INTO TABLE it_rp531mara
*   FOR ALL ENTRIES IN it_rp531
*   WHERE mtart IN ('FERT','HALB')
*   AND   matkl = it_rp531-low.
*
*
*  SELECT matnr mtart matkl FROM mara INTO TABLE it_sc531mara
* FOR ALL ENTRIES IN it_sc531
* WHERE mtart IN ('FERT','HALB')
* AND   matkl = it_sc531-low.

  "----------------------------------------------------------------------------------------



  IF it_mvke IS NOT INITIAL.
    SORT it_mvke BY mvgr1 kondm.
    SELECT * FROM t178t INTO TABLE it_t178t
      FOR ALL ENTRIES IN it_mvke
      WHERE kondm = it_mvke-kondm
      AND spras  = 'EN'.

    SELECT * FROM tvm1t INTO TABLE it_tvm1t
      FOR ALL ENTRIES IN it_mvke
       WHERE mvgr1 = it_mvke-mvgr1
       AND spras  = 'EN'.
  ENDIF.

  IF s_budat-low IS NOT INITIAL.
    IF s_budat-low+4(2) GT '03'.
      lv_mjahr = s_budat-low+0(4).
    ELSE.
      lv_mjahr = s_budat-low+0(4) - 1.
    ENDIF.
  ENDIF.

  IF s_budat-high IS NOT INITIAL.
    IF s_budat-high+4(2) GT '03'.
      lv_mjahr1 = s_budat-high+0(4).
    ELSE.
      lv_mjahr1 = s_budat-high+0(4) - 1.
    ENDIF.
  ENDIF.

  IF lv_mjahr IS NOT INITIAL AND lv_mjahr1 IS NOT INITIAL.
    IF lv_mjahr NE lv_mjahr1.
      s_mjahr-sign   = 'I'.
      s_mjahr-option = 'EQ'.
      s_mjahr-low    = lv_mjahr.
      APPEND s_mjahr.
      s_mjahr-sign   = 'I'.
      s_mjahr-option = 'EQ'.
      s_mjahr-low    = lv_mjahr1.
      APPEND s_mjahr.
    ELSE.
      s_mjahr-sign   = 'I'.
      s_mjahr-option = 'EQ'.
      s_mjahr-low    = lv_mjahr.
      APPEND s_mjahr.
    ENDIF.
  ELSEIF lv_mjahr IS NOT INITIAL.
    s_mjahr-sign   = 'I'.
    s_mjahr-option = 'EQ'.
    s_mjahr-low    = lv_mjahr.
    APPEND s_mjahr.
  ENDIF.

  IF it_mara IS NOT INITIAL.
    SELECT aufnr mblnr mjahr matnr bwart menge budat FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm
       FOR ALL ENTRIES IN it_mara
       WHERE mjahr IN s_mjahr
       AND   budat IN s_budat
       AND   werks IN s_plant
       AND   matnr = it_mara-matnr
       AND   bwart IN ('101','102').


    SELECT aufnr mblnr mjahr matnr bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm_mvty
       FOR ALL ENTRIES IN it_aufm
       WHERE mjahr IN s_mjahr
       AND   budat IN s_budat
       AND   werks IN s_plant
       AND   aufnr EQ it_aufm-aufnr.


    SELECT matnr,mtart,matkl
      FROM mara
      INTO TABLE @DATA(it_aufm_mara)
      FOR ALL ENTRIES IN @it_aufm_mvty
      WHERE matnr = @it_aufm_mvty-matnr.
*       AND   matnr = it_mara-matnr.
*       AND   bwart IN ('101','102').
  ENDIF.

*  ------------------------------------------------------------------------------------------------------
*  IF it_rm261mara IS NOT INITIAL.
*    SELECT aufnr mblnr mjahr matnr bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufmrm261
*       FOR ALL ENTRIES IN it_rm261mara
*       WHERE budat IN s_budat
*       AND   werks = s_plant
*       AND   matnr = it_rm261mara-matnr
*       AND   bwart IN ('101','102').
*      APPEND LINES OF it_aufmrm261 TO it_aufm.
*  ENDIF.
*
*
*  IF it_rp261mara IS NOT INITIAL.
*    SELECT aufnr mblnr mjahr matnr bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufmrp261
*    FOR ALL ENTRIES IN it_rp261mara
*    WHERE budat IN s_budat
*    AND   werks = s_plant
*    AND   matnr = it_rp261mara-matnr
*    AND   bwart IN ('101','102').
*      APPEND LINES OF it_aufmrp261 TO it_aufm.
*  ENDIF.
*
*
*  IF it_rp531mara IS NOT INITIAL.
*    SELECT aufnr mblnr mjahr matnr bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufmrp531
*    FOR ALL ENTRIES IN it_rp531mara
*    WHERE budat IN s_budat
*    AND   werks = s_plant
*    AND   matnr = it_rp531mara-matnr
*    AND   bwart IN ('101','102').
*     APPEND LINES OF it_aufmrp531 TO it_aufm.
*  ENDIF.
*
*
*  IF it_sc531mara IS NOT INITIAL.
*    SELECT aufnr mblnr mjahr matnr bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufmsc531
*    FOR ALL ENTRIES IN it_sc531mara
*    WHERE budat IN s_budat
*    AND   werks = s_plant
*    AND   matnr = it_sc531mara-matnr
*    AND   bwart IN ('101','102').
*   APPEND LINES OF it_aufmsc531 TO it_aufm.
*  ENDIF.


  "--------------------------------------------------------------------------------------------------------------------------------


  IF it_aufm IS NOT INITIAL.
    SELECT mblnr mjahr aufnr bwart smbln matnr werks menge meins budat_mkpf
      FROM mseg
      INTO TABLE it_mseg
      FOR ALL ENTRIES IN it_aufm
      WHERE mblnr = it_aufm-mblnr
      AND   mjahr = it_aufm-mjahr
      AND   werks IN s_plant
      AND   budat_mkpf IN s_budat
      AND   matnr = it_aufm-matnr
*        AND   SMBLN   = ' '
      AND   bwart = it_aufm-bwart.
  ENDIF.

  IF it_aufm IS NOT INITIAL.
    SELECT aufnr arbid FROM afru INTO TABLE it_afru
          FOR ALL ENTRIES IN it_aufm
          WHERE aufnr = it_aufm-aufnr.
  ENDIF.

  IF it_afru IS NOT INITIAL.
    SELECT objid arbpl FROM crhd INTO TABLE it_crhd
      FOR ALL ENTRIES IN it_afru
      WHERE objid = it_afru-arbid.
  ENDIF.


*  IT_AUFM4[] = IT_AUFM[].
* loop at it_aufm into wa_aufm.
*    READ TABLE  INTO WA_AUFM4 WITH KEY MATNR = WA_AUFM-MATNR.

  IF  it_aufm_mvty IS NOT INITIAL.
    SORT it_aufm_mvty BY aufnr.

    "----------------------------------------------------------------------------------------------------------------

    LOOP AT it_aufm_mvty INTO wa_aufm_mvty.

      "RM261
      CLEAR: wa_mara.
      MOVE-CORRESPONDING wa_aufm_mvty TO wa_aufmrm261.
*      READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_aufm_mvty-matnr.
      READ TABLE it_aufm_mara INTO wa_mara WITH KEY matnr = wa_aufm_mvty-matnr.
      IF sy-subrc = '0'.
        READ TABLE it_rm261 INTO wa_rm261 WITH KEY low = wa_mara-matkl.
        IF sy-subrc = '0'.
          wa_aufmrm261-matkl = wa_mara-matkl.
          APPEND wa_aufmrm261 TO it_aufmrm261.
        ENDIF.
      ENDIF.

      "RP261
      CLEAR: wa_mara.
      MOVE-CORRESPONDING wa_aufm_mvty TO wa_aufmrp261.
      READ TABLE it_aufm_mara INTO wa_mara WITH KEY matnr = wa_aufm_mvty-matnr.
      IF sy-subrc = '0'.
        READ TABLE it_rp261 INTO wa_rp261 WITH KEY low = wa_mara-matkl.
        IF sy-subrc = '0'.
          wa_aufmrp261-matkl = wa_mara-matkl.
          APPEND wa_aufmrp261 TO it_aufmrp261.
        ENDIF.
      ENDIF.

      "RP531
      CLEAR: wa_mara.
      MOVE-CORRESPONDING wa_aufm_mvty TO wa_aufmrp531.
      READ TABLE it_aufm_mara INTO wa_mara WITH KEY matnr = wa_aufm_mvty-matnr.
      IF sy-subrc = '0'.
        READ TABLE it_rp531 INTO wa_rp531 WITH KEY low = wa_mara-matkl.
        IF sy-subrc = '0'.
          wa_aufmrp531-matkl = wa_mara-matkl.
          APPEND wa_aufmrp531 TO it_aufmrp531.
        ENDIF.
      ENDIF.

      "SC531
      CLEAR: wa_mara.
      MOVE-CORRESPONDING wa_aufm_mvty TO wa_aufmsc531.
      READ TABLE it_aufm_mara INTO wa_mara WITH KEY matnr = wa_aufm_mvty-matnr.
      IF sy-subrc = '0'.
        READ TABLE it_sc531 INTO wa_sc531 WITH KEY low = wa_mara-matkl.
        IF sy-subrc = '0'.
          wa_aufmsc531-matkl = wa_mara-matkl.
          APPEND wa_aufmsc531 TO it_aufmsc531.
        ENDIF.
      ENDIF.




      CLEAR : wa_aufmrm261,wa_aufmrp261,wa_aufmrp531,wa_aufmsc531, wa_rm261, wa_mara, wa_aufm,wa_aufm_mvty.
    ENDLOOP.
*************************
    IF it_aufmrm261 IS NOT INITIAL.
      SELECT mblnr aufnr mjahr budat bwart matnr menge werks  FROM aufm INTO TABLE it_aufm1
             FOR ALL ENTRIES IN it_aufmrm261
             WHERE  budat IN s_budat
             AND   bwart IN ('261','262')
             AND   werks IN s_plant
             AND aufnr = it_aufmrm261-aufnr
              AND   matnr = it_aufmrm261-matnr.

*             AND
**            AND   matnr = it_aufmrm261-matnr
**            AND   bwart IN ('261','262','531','532').
*             AND   bwart IN ('261','262').
      APPEND LINES OF it_aufm1 TO it_aufm2.
    ENDIF.

    IF it_aufmrp261 IS NOT INITIAL.

      SELECT mblnr aufnr mjahr budat bwart matnr menge werks  FROM aufm INTO TABLE it_aufm1
             FOR ALL ENTRIES IN it_aufmrp261
             WHERE  budat IN s_budat
             AND   bwart IN ('261','262')
             AND   werks IN s_plant
             AND aufnr = it_aufmrp261-aufnr
            AND   matnr = it_aufmrp261-matnr.

*             WHERE aufnr = it_aufmrp261-aufnr
*             AND   werks = s_plant
*             AND   budat IN s_budat
**           AND   matnr = it_aufmrp261-matnr
**           AND   bwart IN ('261','262','531','532').
*             AND   bwart IN ('261','262').

      APPEND LINES OF it_aufm1 TO it_aufm2.

    ENDIF.

    IF it_aufmrp531 IS NOT INITIAL.
      SELECT mblnr aufnr  mjahr budat bwart matnr menge werks FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
                FOR ALL ENTRIES IN it_aufmrp531
                WHERE  budat IN s_budat
                AND   bwart IN ('531','532')
                AND   werks IN s_plant
                AND aufnr = it_aufmrp531-aufnr
                 AND   matnr = it_aufmrp531-matnr.
*                WHERE aufnr = it_aufmrp531-aufnr
*                AND   werks = s_plant
*                AND   budat IN s_budat
**          AND   matnr = it_aufmrp531-matnr
**          AND   bwart IN ('261','262','531','532').
*                AND   bwart IN ('531','532').

      APPEND LINES OF it_aufm1 TO it_aufm2.

    ENDIF.

    IF it_aufmsc531 IS NOT INITIAL.
      SELECT mblnr aufnr mjahr budat bwart matnr menge werks  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
                 FOR ALL ENTRIES IN it_aufmsc531
                 WHERE  budat IN s_budat
                AND   bwart IN ('531','532')
                AND   werks IN s_plant
                AND aufnr = it_aufmsc531-aufnr
                AND   matnr = it_aufmsc531-matnr.

*                 WHERE aufnr = it_aufmsc531-aufnr
*                 AND   werks = s_plant
*                 AND   budat IN s_budat
**             AND   matnr = it_aufmsc531-matnr
**             AND   bwart IN ('261','262','531','532').
*                 AND   bwart IN ('531','532').

      APPEND LINES OF it_aufm1 TO it_aufm2.
    ENDIF.
*
    SORT it_aufm2 BY mblnr aufnr mjahr matnr bwart.

*    DELETE ADJACENT DUPLICATES FROM it_aufm2 COMPARING aufnr mblnr mjahr matnr bwart. "commented on 25.03.2022
    "---------------------------------------------------------------------------


*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*         FOR ALL ENTRIES IN it_aufm
*         WHERE aufnr = it_aufm-aufnr
*         AND   werks = s_plant
*         AND   budat IN s_budat
*         AND   matnr LIKE 'RM03%'
*         AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.

*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*    FOR ALL ENTRIES IN it_aufm
*    WHERE aufnr = it_aufm-aufnr
*    AND   werks = s_plant
*    AND   budat IN s_budat
*    AND   matnr LIKE 'PG%'
*    AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'PC%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND  budat IN s_budat
*       AND   matnr LIKE 'RP%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'SC%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CC01%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CG01%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*     FOR ALL ENTRIES IN it_aufm
*     WHERE aufnr = it_aufm-aufnr
*     AND   werks = s_plant
*     AND   budat IN s_budat
*     AND   matnr LIKE 'LN01%'
*     AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*      FOR ALL ENTRIES IN it_aufm
*      WHERE aufnr = it_aufm-aufnr
*      AND   werks = s_plant
*      AND   budat IN s_budat
*      AND   matnr LIKE 'RM05%'
*      AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*      FOR ALL ENTRIES IN it_aufm
*      WHERE aufnr = it_aufm-aufnr
*      AND   werks = s_plant
*      AND   budat IN s_budat
*      AND   matnr LIKE 'CF04%'
*      AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CCG03%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CFG04%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CC03%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
*
*
*    SELECT aufnr mblnr matnr  bwart menge budat  FROM aufm INTO CORRESPONDING FIELDS OF TABLE it_aufm1
*       FOR ALL ENTRIES IN it_aufm
*       WHERE aufnr = it_aufm-aufnr
*       AND   werks = s_plant
*       AND   budat IN s_budat
*       AND   matnr LIKE 'CC04%'
*       AND   bwart IN ('261','262','531','532').
*
*    APPEND LINES OF it_aufm1 TO it_aufm2.
  ENDIF.


  IF it_aufm2 IS NOT INITIAL.
    SELECT aufnr plnbez FROM afko INTO TABLE it_afko
       FOR ALL ENTRIES IN it_aufm2
       WHERE aufnr = it_aufm2-aufnr.
  ENDIF.

  IF it_afko IS NOT INITIAL.
    SELECT * FROM  makt  INTO TABLE it_makt
      FOR ALL ENTRIES IN it_afko
      WHERE matnr = it_afko-plnbez.
  ENDIF.





  SORT it_aufm2 BY mblnr aufnr .
  SORT it_mseg BY mblnr  aufnr .
  LOOP AT it_aufm2 INTO wa_aufm2.

    AT NEW mblnr.
      READ TABLE it_mseg INTO wa_mseg WITH KEY mblnr = wa_aufm2-mblnr  bwart = '101'.
      IF sy-subrc = 0.
        qty = qty + wa_mseg-menge.
      ENDIF.
      CLEAR: wa_mseg.
      READ TABLE it_mseg INTO wa_mseg WITH KEY smbln = wa_aufm2-mblnr  bwart = '102'.
      IF sy-subrc = 0.
        1qty = 1qty + wa_mseg-menge.
      ENDIF.
    ENDAT.
*     read table it_aufm2 into wa_aufm2 with key matnr = wa_mvke-matnr.

    "-----------------------------------------------------------------------------------------------------
*   READ TABLE it_afko INTO wa_afko WITH KEY aufnr =  wa_aufm2-aufnr.
*    CLEAR @V_MATKL.
    SELECT SINGLE matkl
      INTO @DATA(v_matkl)
      FROM mara
      WHERE matnr = @wa_aufm2-matnr.
*    READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_aufm2-matnr.
    IF sy-subrc ='0'.
      "RM261
*       READ TABLE it_rm261  INTO wa_rm261 WITH KEY low = wa_mara-matkl.
      READ TABLE it_rm261  INTO wa_rm261 WITH KEY low = v_matkl.
      IF sy-subrc ='0'.
        IF wa_aufm2-bwart = '261'.
          v_rm01 = v_rm01 + wa_aufm2-menge.
        ENDIF.
        IF wa_aufm2-bwart = '262'.
          v_1rm01 = v_1rm01 + wa_aufm2-menge.
        ENDIF.
      ENDIF.

      "RP261
*       READ TABLE it_rp261  INTO wa_rp261 WITH KEY low = wa_mara-matkl.
      READ TABLE it_rp261  INTO wa_rp261 WITH KEY low = v_matkl.
      IF sy-subrc ='0'.
        IF wa_aufm2-bwart = '261'.
          v_rp = v_rp + wa_aufm2-menge.
        ENDIF.
        IF wa_aufm2-bwart = '262'.
          v_1rp = v_1rp + wa_aufm2-menge.
        ENDIF.
      ENDIF.

      "RP531
*       READ TABLE it_rp531  INTO wa_rp531 WITH KEY low = wa_mara-matkl.
      READ TABLE it_rp531  INTO wa_rp531 WITH KEY low = v_matkl.
      IF sy-subrc ='0'.
        IF wa_aufm2-bwart = '531'.
          v_vp = v_vp + wa_aufm2-menge.
        ENDIF.
        IF wa_aufm2-bwart = '532'.
          v_1vp = v_1vp + wa_aufm2-menge.
        ENDIF.
      ENDIF.


      "SC531
*       READ TABLE it_sc531  INTO wa_sc531 WITH KEY low = wa_mara-matkl.
      READ TABLE it_sc531  INTO wa_sc531 WITH KEY low = v_matkl.
      IF sy-subrc ='0'.
        IF wa_aufm2-bwart = '531'.
          v_sc = v_sc + wa_aufm2-menge.
        ENDIF.
        IF wa_aufm2-bwart = '532'.
          v_1sc = v_1sc + wa_aufm2-menge.
        ENDIF.
      ENDIF.

    ENDIF.
    CLEAR : wa_sc531,wa_rp531,wa_rp261,wa_rm261,wa_mara,wa_afko,v_matkl.
    "-------------------------------------------------------------------------------------------------------

*    IF ( wa_aufm2-matnr CP 'RM01*' OR wa_aufm2-matnr CP 'PG*' OR wa_aufm2-matnr CP 'PC*' OR wa_aufm2-matnr CP 'RM03*'
*          OR wa_aufm2-matnr CP 'LN01*' OR wa_aufm2-matnr CP 'CC01*'OR wa_aufm2-matnr CP 'CG01*'OR wa_aufm2-matnr CP 'RM05*'
*          OR wa_aufm2-matnr CP 'CF04*'OR wa_aufm2-matnr CP 'CCG03*'OR wa_aufm2-matnr CP 'CFG04*' OR wa_aufm2-matnr CP 'CC03*' OR wa_aufm2-matnr CP 'CC04*')
*        AND ( wa_aufm2-bwart = '261' ) .
*      v_rm01 = v_rm01 + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'RM01*' OR wa_aufm2-matnr CP 'PG*' OR wa_aufm2-matnr CP 'PC*' OR wa_aufm2-matnr CP 'RM03*'
*              OR wa_aufm2-matnr CP 'LN01*' OR wa_aufm2-matnr CP 'CC01*'OR wa_aufm2-matnr CP 'CG01*'
*      OR wa_aufm2-matnr CP 'RM05*'OR wa_aufm2-matnr CP 'CF04*'OR wa_aufm2-matnr CP 'CCG03*'OR wa_aufm2-matnr CP 'CFG04*'
*      OR wa_aufm2-matnr CP 'CC03*' OR wa_aufm2-matnr CP 'CC04*')
*       AND ( wa_aufm2-bwart = '262' ).
*      v_1rm01 = v_1rm01 + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'RP*')  AND ( wa_aufm2-bwart = '261').
*      v_rp = v_rp + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'RP*')  AND ( wa_aufm2-bwart = '262').
*      v_1rp = v_1rp + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'RP*')  AND ( wa_aufm2-bwart = '531').
*      v_vp = v_vp + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'RP*')  AND ( wa_aufm2-bwart = '532').
*      v_1vp = v_1vp + wa_aufm2-menge.
*
*    ELSEIF ( wa_aufm2-matnr CP 'SC*')  AND ( wa_aufm2-bwart = '531').
*      v_sc = v_sc + wa_aufm2-menge.
*    ELSEIF ( wa_aufm2-matnr CP 'SC*')  AND ( wa_aufm2-bwart = '532').
*      v_1sc = v_1sc + wa_aufm2-menge.
*    ENDIF.



*     READ TABLE IT_MVKE INTO WA_MVKE WITH KEY MATNR = WA_AUFM2-MATNR.
*     V_MATNR = WA_MVKE-MATNR.
    v_aufnr = wa_aufm2-aufnr.
    v_werks = wa_aufm2-werks.
    v_budat = wa_aufm2-budat.
    AT END OF mblnr.
      READ TABLE it_afko INTO wa_afko WITH KEY aufnr = v_aufnr.
      READ TABLE it_mvke INTO wa_mvke WITH KEY matnr = wa_afko-plnbez.
      READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_afko-plnbez.
      READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_afko-plnbez.

      wa_final-matnr = wa_afko-plnbez.
      wa_final-desc  = wa_makt-maktx.
      wa_final-aufnr = v_aufnr.

*      IF wa_mvke-mvgr1 = ' '.
*
*        IF wa_mara-matkl = 'COLUMN'.
*
*          wa_final-mgp = '01'.
*
**         ELSEIF WA_MARA-MATKL = 'PP'.
**            WA_FINAL-MGP = '03'.
*
*        ELSE.
*          wa_final-mgp = '02'.
*
*
*        ENDIF.
*      ELSE.
*        wa_final-mgp = wa_mvke-mvgr1.
*      ENDIF.
      wa_final-mgp = wa_mvke-mvgr1.
      wa_final-prg = wa_mvke-kondm.
      wa_final-rm01 =  v_rm01.
      wa_final-1rm01 =  v_1rm01.
      wa_final-rp    = v_rp.
      wa_final-1rp = v_1rp.
      wa_final-vp  = v_vp.
      wa_final-1vp  = v_1vp.
      wa_final-sc  = v_sc.
      wa_final-1sc  = v_1sc.
      wa_final-qty = qty.
      wa_final-1qty = 1qty.
      wa_final-mblnr = wa_aufm2-mblnr.
      wa_final-werks = v_werks.
      wa_final-budat = v_budat.


      APPEND wa_final TO it_final.
      CLEAR: v_matnr,v_rm01,v_1rm01,v_rp,v_1rp,v_vp,v_1vp,v_sc,v_1sc,wa_mvke,wa_afko,qty,1qty,v_aufnr,v_werks,v_budat.
    ENDAT.
  ENDLOOP.
  it_final1[] = it_final[].

  LOOP AT it_final INTO wa_final.
    READ TABLE it_final1 INTO wa_final1 WITH KEY aufnr = wa_final-aufnr.
    READ TABLE it_tvm1t INTO wa_tvm1t WITH KEY mvgr1 = wa_final-mgp.
    READ TABLE it_t178t INTO wa_t178t WITH KEY kondm = wa_final-prg.
    READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_final-matnr.
*    READ TABLE it_mvke INTO wa_mvke WITH KEY matnr = wa_final-matnr.
    READ TABLE it_afru INTO wa_afru WITH KEY aufnr = wa_final-aufnr.
    READ TABLE it_crhd INTO wa_crhd WITH KEY objid = wa_afru-arbid.

*    IF  wa_final-mgp = '01'.
*      wa_final-type = 'PIPE'.
*    ELSEIF wa_final-mgp = '02'.
*      wa_final-type = 'FITTINGS'.
*    ELSE.
*      wa_final-type = 'PP'.
*
*    ENDIF.

*    WA_fINAL-DESM =  WA_TVM1T-BEZEI.
    wa_final-type =  wa_tvm1t-bezei.
    wa_final-desm = wa_mara-matkl.
    wa_final-aufnr = wa_final-aufnr.
    wa_final-desk = wa_t178t-vtext.
*    IF wa_final-desk = 'AQUARIUSFAB FITTINGS'.
*      wa_final-group = 'AQUARIUS'.
*    ELSEIF
*       wa_final-desk = 'AQUA BRASS FITTINGS'.
*      wa_final-group = 'AQUARIUS'.
*    ELSEIF
*       wa_final-desk = 'AQUARIUS+MFGFITTING'.
*      wa_final-group = 'AQUARIUS'.
*
*    ELSEIF
*     wa_final-desk = 'AQUARIUSMFGFITTING'.
*      wa_final-group = 'AQUARIUS'.
*
*    ELSEIF
*    wa_final-desk = 'AQUARIUS+ MFGPIPE'.
*      wa_final-group = 'AQUARIUS'.
*
*    ELSEIF
*    wa_final-desk = 'AQUARIUSMFGPIPE'.
*      wa_final-group = 'AQUARIUS'.
*
*    ELSEIF
*     wa_final-desk = 'BMMFGFITTING'.
*      wa_final-group = 'BLAZE MST'.
*
*    ELSEIF
*    wa_final-desk = 'BMMFGPIPE'.
*      wa_final-group = 'BLAZE MST'.
*
*    ELSEIF
*  wa_final-desk = 'COLUMNMFGPIPE'.
*      wa_final-group = 'COLUMN'.
*
*    ELSEIF
*  wa_final-desk = 'CORZAN FAB.FITTING'.
*      wa_final-group = 'CORZAN'.
*
*    ELSEIF
*  wa_final-desk = 'CORZANMFGFITTING'.
*      wa_final-group = 'CORZAN'.
*
*    ELSEIF
*  wa_final-desk = 'CORZANMFGPIPE'.
*      wa_final-group = 'CORZAN'.
*
*    ELSEIF
*  wa_final-desk = 'FGMFGACCESSORY'.
*      wa_final-group = 'FLOWGUARD'.
*
*    ELSEIF
*  wa_final-desk = 'FGMFGFITTING'.
*      wa_final-group = 'FLOWGUARD'.
*
*    ELSEIF
*  wa_final-desk = 'FGMFGPIPE'.
*      wa_final-group = 'FLOWGUARD'.
*
*    ELSEIF
*    wa_final-desk = 'UGMFGFITTING'.
*      wa_final-group = 'UND GRND'.
*
*    ELSEIF
*    wa_final-desk = 'COMPOSITE MFG PIPE'.
*      wa_final-group = 'COMPOSITE'.
*    ENDIF.
    wa_final-arbpl = wa_crhd-arbpl." work center

*    READ TABLE IT_AFKO INTO WA_AFKO WITH KEY PLNBEZ = WA_FINAL-MATNR.
    wa_final-rm01 = wa_final-rm01 - wa_final-1rm01.
    wa_final-rp   = wa_final-rp - wa_final-1rp.
    wa_final-vp = wa_final-vp - wa_final-1vp.
    wa_final-sc = wa_final-sc - wa_final-1sc.
    wa_final-qty  = wa_final-qty - wa_final-1qty.
    wa_final-value = ( wa_final-rm01 + wa_final-rp ) - ( wa_final-vp + wa_final-sc ).
    IF wa_final-rm01 IS NOT INITIAL OR wa_final-rp IS NOT INITIAL.
      wa_final-rpavg = ( wa_final-vp * 100 ) / ( wa_final-rm01 + wa_final-rp ).
    ENDIF.
    IF wa_final-rm01 IS NOT INITIAL OR wa_final-rp IS NOT INITIAL.
      wa_final-scavg = ( wa_final-sc * 100 ) / ( wa_final-rm01 + wa_final-rp ).
    ENDIF.
    IF wa_final-qty GT 0.
      wa_final-weight = ( ( wa_final-qty * wa_mara-ntgew ) / 1000 ).
    ENDIF.
    MODIFY  it_final FROM wa_final TRANSPORTING desm desk rm01 rp vp sc value type arbpl aufnr rpavg scavg group qty weight.
    CLEAR: wa_final,wa_tvm1t,wa_t178t,wa_mara,wa_afru,wa_crhd.
  ENDLOOP.

*  LOOP AT it_grpdel INTO wa_grpdel.
*    DELETE it_final WHERE desm = wa_grpdel-low.
*    CLEAR : wa_grpdel.
*  ENDLOOP.
*
*  LOOP AT it_wcdel INTO wa_wcdel.
*    DELETE it_final WHERE arbpl CP wa_wcdel-arbpl.
*    CLEAR : wa_wcdel.
*  ENDLOOP.


*  DELETE it_final WHERE desm = 'COMPOUND'.
*  DELETE it_final WHERE arbpl CP 'SFGR*'.
*  DELETE it_final WHERE arbpl CP 'SFCC*'.
*  DELETE it_final WHERE arbpl CP 'SFCN*'.
*  DELETE it_final WHERE arbpl CP 'HFGR*'.
*  DELETE it_final WHERE arbpl CP 'DFGR*'.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_fieldcatalog .
  DEFINE fill_fieldcat.
    lwa_fieldcat-col_pos       = &1.
    lwa_fieldcat-tabname       = &2.
    lwa_fieldcat-fieldname     = &3.
    lwa_fieldcat-ref_tabname   = &4.
    lwa_fieldcat-ref_fieldname = &5.
    lwa_fieldcat-seltext_l     = &6.
    lwa_fieldcat-hotspot       = &7.
    append lwa_fieldcat to lt_fieldcat.
    clear  lwa_fieldcat.
  END-OF-DEFINITION.
  fill_fieldcat 1    'IT_FINAL'  'MATNR'  ''  'MATNR'  'Material'                    ''.
  fill_fieldcat 1    'IT_FINAL'  'DESC'  ''  'DESC'  'Material Desc'                    ''.
*  fill_fieldcat 1    'IT_FINAL'  'MGP'  ''  'MGP'  'Material Group 1'                    ''.
  fill_fieldcat 1    'IT_FINAL'  'DESM'  ''  'DESM'  'Material Group 1 Desc'                    ''.
*  fill_fieldcat 2    'IT_FINAL'  'PRG'  ''  'PRG'  'Pricing Group'                       ''.
  fill_fieldcat 2    'IT_FINAL'  'TYPE'  ''  'TYPE'  'TYPE'                       ''.
*  fill_fieldcat 2    'IT_FINAL'  'GROUP'  ''  'GROUP'  'GROUP'                       ''.
  fill_fieldcat 2    'IT_FINAL'  'DESK'  ''  'DESK'  'Pricing Group Desc'                       ''.
  fill_fieldcat 2    'IT_FINAL'  'ARBPL'  ''  'ARBPL'  'Work Center'                       ''.
  fill_fieldcat 2    'IT_FINAL'  'AUFNR'  ''  'AUFNR'  'Order Number'                       ''.


  fill_fieldcat 3    'IT_FINAL'  'RM01'  ''  'RM01'  'RM_CONSUMPTION'                       ''.

  fill_fieldcat 4    'IT_FINAL'  'RP'  ''  'RP'  'RP_CONSUMPTION'                           ''.
  fill_fieldcat 5    'IT_FINAL'  'VP'  ''  'VP'  'RP_GENERATION'                           ''.
  fill_fieldcat 6    'IT_FINAL'  'SC'  ''  'SC'    'SC_GENERATION'                           ''.
  fill_fieldcat 7    'IT_FINAL'  'VALUE'  ''  'VALUE'     'NET CONSUMPTION'                           ''.
  fill_fieldcat 7    'IT_FINAL'  'RPAVG'  ''  'RPAVG'     'RP AVERAGE'                           ''.
  fill_fieldcat 7    'IT_FINAL'  'SCAVG'  ''  'SCAVG'     'SC AVERAGE'                           ''.
  fill_fieldcat 7    'IT_FINAL'  'QTY'  ''  'QTY'     'QUANTITY'                           ''.
*  fill_fieldcat 8    'IT_FINAL'  'SUCH'  ''  'SUCH'  'As Such'                        ''.
*  fill_fieldcat 9    'IT_FINAL'  'CL_BAL'  ''  'CLBAL'  'Closing Balance'                        ''.
ENDFORM.                    " BUILD_FIELDCATALOG

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_REPORT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv_report .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      is_layout          = gd_layout
*     i_callback_user_command = 'USER_COMMAND'
*     i_callback_top_of_page  = 'TOP-OF-PAGE'
      it_fieldcat        = lt_fieldcat
      i_save             = 'A'
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
ENDFORM.                    " DISPLAY_ALV_REPORT
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
*  SELECT werks
*     FROM t001w
*     INTO TABLE @DATA(it_t001w)
*     WHERE werks = @s_plant.
*  LOOP AT it_t001w INTO wa_t001w.
*    AUTHORITY-CHECK OBJECT 'Z_PRD_WERK'
*       ID 'WERKS' FIELD wa_t001w-werks
*       ID 'ACTVT' FIELD '03'.
*    IF sy-subrc <> 0.
*      MESSAGE e007(zsd) WITH wa_t001w-werks.
*    ENDIF.
*    CLEAR :  wa_t001w.
*  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  TRANSFER_BI
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM transfer_bi .

  dbs = 'MSSQL'.

  EXEC SQL.
    CONNECT TO :DBS
  ENDEXEC. "#EC CI_EXECSQL

  IF chk1 = 'X'.
    LOOP AT it_final INTO wa_final.
      IF wa_flag = 0.
        EXEC SQL.

          DELETE FROM SAP_BI_PROD_CUBE2

        ENDEXEC. "#EC CI_EXECSQL
        wa_flag = 1.
      ENDIF.

      EXEC SQL.

        insert into SAP_BI_PROD_CUBE2
        ( DOCUMENTNUMBER,PLANT,POSTINGDATE,WORKCENTER,TYPE1,MATERIALGROUP1DESC,MATERIAL,MATERIALDESC
         ,PRICINGGROUPDESC
         ,RM_ISSUE,RP_CONSUMPTION,RP_GENERATION,SC_GENERATION,NETCONSUMPTION,QTYPRODUCED,ORDERNUMBER,TONNAGE)
        values  ( :wa_final-MBLNR,:wa_final-WERKS,:wa_final-BUDAT, :wa_final-ARBPL, :wa_final-DESM, :wa_final-mdesc,
                  :wa_final-MATNR,:wa_final-DESC,:wa_final-DESK,:wa_final-RM01,:wa_final-RP,
                  :wa_final-VP,:wa_final-SC,:wa_final-VALUE,:wa_final-QTY,:wa_final-AUFNR,:wa_final-WEIGHT)




      ENDEXEC. "#EC CI_EXECSQL
*    endif.
    ENDLOOP.
  ELSE.
    LOOP AT it_final INTO wa_final.
      IF wa_flag = 0.
        EXEC SQL.

          DELETE FROM SAP_BI_PROD_CUBE2 WHERE POSTINGDATE >= :s_budat-low

        ENDEXEC. "#EC CI_EXECSQL
        wa_flag = 1.
      ENDIF.

      EXEC SQL.

        insert into SAP_BI_PROD_CUBE2
         ( DOCUMENTNUMBER,PLANT,POSTINGDATE,WORKCENTER,TYPE1,MATERIALGROUP1DESC,MATERIAL,MATERIALDESC
          ,PRICINGGROUPDESC
          ,RM_ISSUE,RP_CONSUMPTION,RP_GENERATION,SC_GENERATION,NETCONSUMPTION,QTYPRODUCED,ORDERNUMBER,TONNAGE)
         values  ( :wa_final-MBLNR,:wa_final-WERKS,:wa_final-BUDAT, :wa_final-ARBPL, :wa_final-DESM,:wa_final-mdesc,
                   :wa_final-MATNR,:wa_final-DESC,:wa_final-DESK,:wa_final-RM01,:wa_final-RP,
                   :wa_final-VP,:wa_final-SC,:wa_final-VALUE,:wa_final-QTY,:wa_final-AUFNR,:wa_final-WEIGHT)





      ENDEXEC. "#EC CI_EXECSQL
*    endif.
    ENDLOOP.
  ENDIF.
*SORT IT_FINAL BY PRTDTL.
  WRITE:/  'Update Successfully'.                  " GET_DATA
ENDFORM.

*ENDFORM.
