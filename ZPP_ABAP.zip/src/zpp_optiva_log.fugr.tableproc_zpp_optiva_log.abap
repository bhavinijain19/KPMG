*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_OPTIVA_LOG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_OPTIVA_LOG      .

  PERFORM TABLEPROC.

ENDFUNCTION.
