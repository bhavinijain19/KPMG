*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBATCH_MATGRPTOP.                 " Global Declarations
  INCLUDE LZBATCH_MATGRPUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBATCH_MATGRPF...                 " Subroutines
* INCLUDE LZBATCH_MATGRPO...                 " PBO-Modules
* INCLUDE LZBATCH_MATGRPI...                 " PAI-Modules
* INCLUDE LZBATCH_MATGRPE...                 " Events
* INCLUDE LZBATCH_MATGRPP...                 " Local class implement.
* INCLUDE LZBATCH_MATGRPT99.                 " ABAP Unit tests
  INCLUDE LZBATCH_MATGRPF00                       . " subprograms
  INCLUDE LZBATCH_MATGRPI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
