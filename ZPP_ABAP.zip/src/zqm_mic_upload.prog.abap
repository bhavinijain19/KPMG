*&---------------------------------------------------------------------*
*& Report ZQM_MIC_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZQM_MIC_UPLOAD.

*$*$----------------------------------------------------------------$
*$*$   Tables                                                       $
*$*$----------------------------------------------------------------$
TABLES: qpmk,t100.

*$*$----------------------------------------------------------------$*$*
*$*$   Selection Screen                                             $*$*
*$*$----------------------------------------------------------------$*$*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.

PARAMETERS       : p_path   LIKE rlgrap-filename.
SELECTION-SCREEN   SKIP.
SELECTION-SCREEN   BEGIN OF BLOCK b2 WITH FRAME TITLE text-002.
PARAMETERS       : mode_a   RADIOBUTTON   GROUP r1,
                   mode_e   RADIOBUTTON   GROUP r1.
*                   mode_n   radiobutton   group r1.
SELECTION-SCREEN   END OF BLOCK b2.

SELECTION-SCREEN END   OF BLOCK b1.

*$*$----------------------------------------------------------------$*$*
*$*$   Data Declaration                                             $*$*
*$*$----------------------------------------------------------------$*$*
DATA: BEGIN OF itab  OCCURS 1,
        werks        TYPE   qpmk-werks,     " Plant
        mkmnr        TYPE   qpmk-mkmnr,     " Master insp.charac
        gueltigab(10),                      " Valid From
        type         TYPE   c,              " Qualitative / Quantitative
        loekz        TYPE   qpmk-loekz,     " Status
        konsistent   TYPE   qpmk-konsistent,
        kurztext     TYPE   qpmt-kurztext,  " Short text
        sortfeld     TYPE   qpmk-sortfeld,  " Search field
        dummy20      TYPE   qpmk-dummy20,   " Info Field 2 23.05.2007 Mathivanan.G
        pruefkat     TYPE   c,              " Char attribute
        tolerunten   TYPE   c,              " Lower Specification Limit
        toleroben    TYPE   c,              " Upper Specification Limit
        sollpruef    TYPE   c,              " Check Target Value
        stichpr      TYPE   c,              " Sampling Procedure
        estukz5      TYPE   c,              " Sampling Procedure
        estukz3      TYPE   c,              " Single Result
        fehlrec      TYPE   c,              " Defect Recording
        rzwang4      TYPE   c,              " Required Characteristic
        rzwang1      TYPE   c,              " Optional Characteristic
        pumfkz1      TYPE   c,              " Scope Not Fixed
        pumfkz4      TYPE   c,              " Fixed Scope
        dokukz2      TYPE   c,              " Doc. Req. if Rejectd
        dokukz3      TYPE   c,              " Documentation Required
        ausslos      TYPE   c,              " Score and Scrap Share
        messwerte    TYPE   c,              " Measured Value
        aendbeleg    TYPE   c,              " RR Change Docs
        druck1       TYPE   c,              " Print
        druck2       TYPE   c,              " Do not print
        keineformel  TYPE   c,              " No Formula
        formelmk     TYPE   c,
        stellen(2)      TYPE   c,"QPMK-STELLEN,    " Decimal Places
        masseinhsw   TYPE   rmqsd-masseinhsw, "Measurement Unit
        lzeitkz      TYPE   rqmst-lzeitkz,    "Long term Inspection
        auswmenge2   TYPE   qpmz-auswmenge2, " Catalogs
        auswmenge1(8)   TYPE   c,
        codegrqual   TYPE   qpmk-codegrqual, " General
        codequal     TYPE   qpmk-codequal,  "  General
        codegr9o     TYPE   qpmk-codegr9o,  " At upper spec. limit
        code9o       TYPE   qpmk-code9o,    " At upper spec. limit
        codegr9u     TYPE   qpmk-codegr9u,  " At lower spec. limit
        code9u       TYPE   qpmk-code9u,    " At lower spec. limit
        atnam(30)        TYPE c,
        "KONSISTENT   TYPE   QPMK-KONSISTENT,"In complete Copy Model
        "STELLEN      TYPE   QPMK-STELLEN,   "Decimal Places
**-- Fields ADDED by VICKY on 09.05.2005
        katalgart2(1)  TYPE c,


        toleranzun   TYPE   qfltp-toleranzun,"Lower Limit
        toleranzob   TYPE   qfltp-toleranzob,"Upper Limit

**-- Fields addition over
      END   OF itab.

***************Data Declarations
DATA: BEGIN OF itab_temp OCCURS 0,
      field1(40),
      field2(40),
      field3(40),
      field4(40),
      field5(40),
      field6(40),
      field7(40),
      field8(40),
      field9(40),
      field10(40),
      field11(40),
      field12(40),
      field13(40),
      field14(40),
      field15(40),
      field16(40),
      field17(40),
      field18(40),
      field19(40),
      field20(40),
      field21(40),
      field22(40),
      field23(40),
      field24(40),
      field25(40),
      field26(40),
      field27(40),
      field28(40),
      field29(40),
      field30(40),
      field31(40),
      field32(40),
      field33(40),
      field34(40),
      field35(40),
      field36(40),
      field37(40),
      field38(40),
      field39(40),
      field40(40),
      field41(40),
      field42(40),
      field43(40),
      field44(40),
      field45(40),
      field46(40),
      field47(40),
      field48(40),
      field49(40),
      field50(40),
      field51(40),
      field52(40),
      field53(40),
      field54(40),
      field55(40),
      field56(40),
      field57(40),
      field58(40),
      field59(40),
      field60(40),
      field61(40),
      field62(40),
      field63(40),
      field64(40),
      field65(40),
      field66(40),
      field67(40),
      field68(40),
      field69(40),
      field70(40),
      field71(40),
      field72(40),
      field73(40),
      field74(40),
      field75(40),
      field76(40),
      field77(40),
      field78(40),
      field79(40),
      field80(40),
      field81(40),
      field82(40),
      field83(40),
      field84(40),
      field85(40),
      field86(40),
      field87(40),
      field88(40),
      field89(40),
      field90(40),
      field91(40),
      field92(40),
      field93(40),
      field94(40),
      field95(40),
      field96(40),
      field97(40),
      field98(40),
      field99(40),
      field100(40),
  END OF itab_temp.

*Table for DATA Transfer from Temporary Table to the ITAB
DATA : data_tab LIKE itab_temp OCCURS 0 WITH HEADER LINE.



DATA: BEGIN OF error_tab  OCCURS 1.
INCLUDE  STRUCTURE  itab.
DATA  END   OF error_tab.

DATA: BEGIN OF bdcdata    OCCURS 1.
INCLUDE  STRUCTURE  bdcdata.
DATA  END   OF bdcdata.

DATA: g_mode,
      g_tabix      TYPE  sy-tabix.
DATA : p_path_str TYPE string.

**********************************************************************************************************************************
*Error Table's  structure
DATA: BEGIN OF x_err,
          werks TYPE bdcdata-fval,
          mkmnr TYPE bdcdata-fval,
          msgty LIKE sy-msgty,
          msgno LIKE sy-msgno,
          text  TYPE string,
     END OF x_err.

*Error Table
DATA: it_err LIKE STANDARD TABLE OF x_err WITH HEADER LINE.

*SUBRC field reflecting transaction Status
DATA: l_subrc LIKE sy-subrc.

*variables to keep the count of the number records and output zebra.
DATA: v_records TYPE i VALUE 0,
      v_total TYPE i VALUE 0,
      v_flip_flop TYPE i VALUE 0.

*variable to keep the count of the number records.
DATA: v_continue_flag TYPE i VALUE 0.

*variable for item loop
DATA: v_item TYPE i VALUE 0.
************************************************************************************************************************************




*$*$----------------------------------------------------------------$*$*
*$*$   At Selection Screen On Value Request                         $*$*
*$*$----------------------------------------------------------------$*$*

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_path.
  CALL FUNCTION 'WS_FILENAME_GET'
      EXPORTING
           def_filename     = space
           def_path         = space
           mask             = ',*.*,*.*.'
           mode             = space
           title            = space
      IMPORTING
           filename         = p_path
*         RC               =
       EXCEPTIONS
            inv_winsys       = 1
            no_batch         = 2
            selection_cancel = 3
            selection_error  = 4
            OTHERS           = 5.
  IF sy-subrc <> 0 AND sy-subrc <> 3.
    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
  ENDIF.

*$*$----------------------------------------------------------------$*$*
*$*$   Start of Selection                                           $*$*
*$*$----------------------------------------------------------------$*$*

START-OF-SELECTION.

  IF mode_a EQ 'X'.
    g_mode = 'A'.
  ELSEIF mode_e EQ 'X'.
    g_mode = 'E'.
*  ELSEIF mode_n EQ 'X'.
*    g_mode = 'N'.
  ENDIF.

  PERFORM  upload.
  PERFORM  tranfer_itab_temp_to_itab.
  PERFORM  check_data.
  PERFORM  process_bdc.
  PERFORM  log_report.
*  PERFORM  write_error_tab.

*$*$----------------------------------------------------------------$*$*
*$*$   End of Selection                                             $*$*
*$*$----------------------------------------------------------------$*$*

END-OF-SELECTION.

*&---------------------------------------------------------------------*
*&      Form  upload
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM upload .
DATA: it_type   TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING

*     I_FIELD_SEPERATOR          =
*     i_line_header              = 'X'

      i_tab_raw_data             = it_type
      i_filename                 = p_path
    TABLES
      i_tab_converted_data       = itab_temp
   EXCEPTIONS
     conversion_failed          = 1
     OTHERS                     = 2
            .
  IF sy-subrc <> 0.
 MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
****
****
****
****  CALL FUNCTION 'WS_UPLOAD'
****    EXPORTING
****      filename                = p_path
****      filetype                = 'DAT'
****    TABLES
****      data_tab                = itab_temp
****    EXCEPTIONS
****      conversion_error        = 1
****      file_open_error         = 2
****      file_read_error         = 3
****      invalid_type            = 4
****      no_batch                = 5
****      unknown_error           = 6
****      invalid_table_width     = 7
****      gui_refuse_filetransfer = 8
****      customer_error          = 9
****      no_authority            = 10
****      OTHERS                  = 11.
****  IF sy-subrc <> 0.
****     MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
****         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
****  ENDIF.
****  break abap.
****  p_path_str = p_path.
*CALL FUNCTION 'GUI_UPLOAD'
*  EXPORTING
*    filename                      = P_PATH_STR
*    FILETYPE                      = 'ASC'
*    HAS_FIELD_SEPARATOR           = 'X'
**   HEADER_LENGTH                 = 0
**   READ_BY_LINE                  = 'X'
**   DAT_MODE                      = ' '
**   CODEPAGE                      = ' '
**   IGNORE_CERR                   = ABAP_TRUE
**   REPLACEMENT                   = '#'
**   CHECK_BOM                     = ' '
**   VIRUS_SCAN_PROFILE            =
**   NO_AUTH_CHECK                 = ' '
** IMPORTING
**   FILELENGTH                    =
**   HEADER                        =
*  tables
*    data_tab                      = ITAB
** EXCEPTIONS
**   FILE_OPEN_ERROR               = 1
**   FILE_READ_ERROR               = 2
**   NO_BATCH                      = 3
**   GUI_REFUSE_FILETRANSFER       = 4
**   INVALID_TYPE                  = 5
**   NO_AUTHORITY                  = 6
**   UNKNOWN_ERROR                 = 7
**   BAD_DATA_FORMAT               = 8
**   HEADER_NOT_ALLOWED            = 9
**   SEPARATOR_NOT_ALLOWED         = 10
**   HEADER_TOO_LONG               = 11
**   UNKNOWN_DP_ERROR              = 12
**   ACCESS_DENIED                 = 13
**   DP_OUT_OF_MEMORY              = 14
**   DISK_FULL                     = 15
**   DP_TIMEOUT                    = 16
**   OTHERS                        = 17
*          .
*IF sy-subrc <> 0.
** MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
**         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
*ENDIF.

ENDFORM.                    " upload

*&---------------------------------------------------------------------*
*&      Form  check_data
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM check_data .

  LOOP AT itab.
    g_tabix = sy-tabix.
    SELECT SINGLE * FROM qpmk
                    WHERE zaehler EQ itab-werks
                    AND   mkmnr   EQ itab-mkmnr.
    IF sy-subrc EQ 0.
      MOVE-CORRESPONDING itab TO error_tab.
      APPEND error_tab.
      CLEAR error_tab.
      DELETE itab INDEX g_tabix.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " check_data

*&---------------------------------------------------------------------*
*&      Form  write_error_tab
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM write_error_tab .
  WRITE:/ 'Following Master Inspection characteristics already exist'.
  LOOP AT error_tab.
    AT FIRST.
      ULINE.
      WRITE:/ sy-vline , 'Plant',
              sy-vline , 'Master insp.charac' ,
              sy-vline.
      ULINE.
    ENDAT.
    WRITE:/ sy-vline , itab-werks,
            sy-vline , itab-mkmnr,
            sy-vline.
    AT LAST.
      ULINE.
    ENDAT.
  ENDLOOP.
ENDFORM.                    " write_error_tab

*&---------------------------------------------------------------------*
*&      Form  process_bdc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM process_bdc .
  LOOP AT itab.
    IF itab-gueltigab EQ ' '.
      CONCATENATE   sy-datum+6(2) sy-datum+4(2) sy-datum+0(4) INTO itab-gueltigab.
    ENDIF.
    PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'QPMK-MKMNR'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '/00'.
    PERFORM bdc_field       USING 'QPMK-WERKS'     itab-werks.
    PERFORM bdc_field       USING 'QPMK-MKMNR'     itab-mkmnr.
    PERFORM bdc_field       USING 'QPMK-GUELTIGAB' itab-gueltigab.
    PERFORM bdc_field       USING 'RMQSD-ATNAM'    itab-atnam.
    PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'QPMK-LOEKZ'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '/00'.

    IF itab-type EQ 'X'.
      PERFORM bdc_field       USING 'RMQSD-QUANTITAET'  'X'.
    ELSE.
      PERFORM bdc_field       USING 'RMQSD-QUALITAET'  'X'.
    ENDIF.

    PERFORM bdc_field       USING 'QPMK-LOEKZ'      itab-loekz.
    PERFORM bdc_field       USING 'QPMK-KONSISTENT' itab-konsistent.
    PERFORM bdc_field       USING 'VSKT-KURZTEXT'   itab-kurztext.
    PERFORM bdc_field       USING 'QPMK-SORTFELD'   itab-sortfeld.
    PERFORM bdc_field       USING 'QPMK-DUMMY20'    itab-dummy20. " Change 23.05.2007 Mathivanan.G
    PERFORM bdc_dynpro      USING 'SAPLQSS0'        '0100'.
   PERFORM bdc_field       USING 'BDC_CURSOR'       'RQMST-FEHLREC'.
    PERFORM bdc_field       USING 'BDC_OKCODE'      '=ENT1'.

    IF itab-type  EQ 'X'.
      PERFORM bdc_field       USING 'RQMST-TOLERUNTEN'  itab-tolerunten.
      PERFORM bdc_field       USING 'RQMST-TOLEROBEN'   itab-toleroben.
      PERFORM bdc_field       USING 'RQMST-SOLLPRUEF'   itab-sollpruef.
    ELSE.
      PERFORM bdc_field       USING 'RQMST-PRUEFKAT'    itab-pruefkat.
    ENDIF.
    PERFORM bdc_field       USING 'RQMST-STICHPR'     itab-stichpr.
    PERFORM bdc_field       USING 'RQMST-ESTUKZ3'     itab-estukz3.
    PERFORM bdc_field       USING 'RQMST-ESTUKZ5'     itab-estukz5.
    PERFORM bdc_field       USING 'RQMST-RZWANG1'     itab-rzwang1.
    PERFORM bdc_field       USING 'RQMST-RZWANG4'     itab-rzwang4.
    PERFORM bdc_field       USING 'RQMST-FEHLREC'     itab-fehlrec.

    PERFORM bdc_dynpro      USING 'SAPLQSS0'           '0101'.
   PERFORM bdc_field       USING 'BDC_CURSOR'          'RQMST-MESSWERTE'.
    PERFORM bdc_field       USING 'BDC_OKCODE'         '=ENT1'.
    PERFORM bdc_field       USING 'RQMST-PUMFKZ1'      itab-pumfkz1.
    PERFORM bdc_field       USING 'RQMST-PUMFKZ4'      itab-pumfkz4.
    PERFORM bdc_field       USING 'RQMST-DOKUKZ2'      itab-dokukz2.
    PERFORM bdc_field       USING 'RQMST-DOKUKZ3'      itab-dokukz3.
    PERFORM bdc_field       USING 'RQMST-AUSSLOS'      itab-ausslos.
    PERFORM bdc_field       USING 'RQMST-LZEITKZ'      itab-lzeitkz.
    PERFORM bdc_field       USING 'RQMST-MESSWERTE'    itab-messwerte.    "added on 08/07/2010
    PERFORM bdc_field       USING 'RQMST-AENDBELEG'    itab-aendbeleg.
    PERFORM bdc_field       USING 'RQMST-DRUCK1'       itab-druck1.
    PERFORM bdc_field       USING 'RQMST-DRUCK2'       itab-druck2.
*   Quantitative


    IF itab-type EQ 'X'.
      IF NOT itab-keineformel IS INITIAL.
      PERFORM bdc_field     USING 'RQMST-KEINEFORMEL'  itab-keineformel.
      ELSEIF NOT itab-formelmk IS INITIAL.
      PERFORM bdc_field     USING 'RQMST-FORMELMK'  itab-formelmk.
      ENDIF.
    ENDIF.

*--------------------------Modified by Rohit on 25/06/2010------------------------------------------*

*     IF itab-fehlrec EQ 'X'.
**      PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0101'.
**      PERFORM bdc_field       USING 'BDC_CURSOR'     'RMQSD-VSTEUERKZ'.
**      PERFORM bdc_field       USING 'BDC_OKCODE'     '=KT'.

***      PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0106'.
***      PERFORM BDC_FIELD       USING 'BDC_CURSOR'     'QPMZ-AUSWMENGE1'.
***      PERFORM bdc_field       USING 'BDC_OKCODE'     '=WEIT'.
      IF itab-type EQ 'X'.

******   Code added by Chinmoy 06042011
        PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'QPMK-LOEKZ'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '=QD'.

*    IF itab-type EQ 'X'.
      PERFORM bdc_field       USING 'RMQSD-QUANTITAET'  'X'.
*    ELSE.
*      PERFORM bdc_field       USING 'RMQSD-QUALITAET'  'X'.
*    ENDIF.

    PERFORM bdc_field       USING 'QPMK-LOEKZ'      itab-loekz.
    PERFORM bdc_field       USING 'QPMK-KONSISTENT' itab-konsistent.
    PERFORM bdc_field       USING 'VSKT-KURZTEXT'   itab-kurztext.
    PERFORM bdc_field       USING 'QPMK-SORTFELD'   itab-sortfeld.
    PERFORM bdc_field       USING 'QPMK-DUMMY20'    itab-dummy20. " Change 23.05.2007 Mathivanan.G



******   Code ended by Chinmoy 06042011

      PERFORM bdc_dynpro      USING 'SAPMQSDA'    '0108'.
      PERFORM bdc_field       USING 'BDC_CURSOR'  'RMQSD-MASSEINHSW'.
      PERFORM bdc_field       USING 'BDC_OKCODE'  '=WEIT'.
      PERFORM bdc_field       USING 'QPMK-STELLEN'       itab-stellen.
      PERFORM bdc_field       USING 'QFLTP-TOLERANZUN'   itab-toleranzun.
      PERFORM bdc_field       USING 'QFLTP-TOLERANZOB'   itab-toleranzob.

      PERFORM bdc_field       USING 'RMQSD-MASSEINHSW'      itab-masseinhsw .
**
**        PERFORM bdc_field      USING 'QPMZ-KATALGART2'  itab-KATALGART2.
**        PERFORM bdc_field      USING 'QPMZ-AUSWMENGE2'  itab-auswmenge1. "itab-auswmenge2. 'QPMZ-AUSWMENGE2'
***        PERFORM bdc_field      USING 'QPMZ-AUSWMGWRK2'  itab-werks.
**        PERFORM bdc_field      USING 'QPMK-CODEQUAL'    itab-codequal.
**        PERFORM bdc_field      USING 'QPMK-CODEGRQUAL'  itab-codegrqual.
**        PERFORM bdc_field      USING 'QPMK-CODE9O'      itab-code9o.
**        PERFORM bdc_field      USING 'QPMK-CODEGR9O'    itab-codegr9o.
**        PERFORM bdc_field      USING 'QPMK-CODE9U'      itab-code9u.
**        PERFORM bdc_field      USING 'QPMK-CODEGR9U'    itab-codegr9u.
      ELSE.
**        ******   Code added by Chinmoy 06042011
        PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'QPMK-LOEKZ'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '=KT'.

*    IF itab-type EQ 'X'.
*      PERFORM bdc_field       USING 'RMQSD-QUANTITAET'  'X'.
*    ELSE.
      PERFORM bdc_field       USING 'RMQSD-QUALITAET'  'X'.
*    ENDIF.

    PERFORM bdc_field       USING 'QPMK-LOEKZ'      itab-loekz.
    PERFORM bdc_field       USING 'QPMK-KONSISTENT' itab-konsistent.
    PERFORM bdc_field       USING 'VSKT-KURZTEXT'   itab-kurztext.
    PERFORM bdc_field       USING 'QPMK-SORTFELD'   itab-sortfeld.
    PERFORM bdc_field       USING 'QPMK-DUMMY20'    itab-dummy20. " Change 23.05.2007 Mathivanan.G



******   Code ended by Chinmoy 06042011


              PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0106'.
      PERFORM bdc_field       USING 'BDC_CURSOR'     'QPMZ-AUSWMENGE1'.
      PERFORM bdc_field       USING 'BDC_OKCODE'     '=WEIT'.
        PERFORM bdc_field      USING 'QPMZ-AUSWMENGE1'  itab-auswmenge1. "itab-auswmenge2.
        PERFORM bdc_field      USING 'QPMZ-AUSWMGWRK1'  itab-werks.
        PERFORM bdc_field      USING 'QPMK-CODEQUAL'    itab-codequal.
        PERFORM bdc_field      USING 'QPMK-CODEGRQUAL'  itab-codegrqual.
      ENDIF.
*      PERFORM BDC_DYNPRO      USING 'SAPMQSDA'       '0101'.
*      PERFORM BDC_FIELD       USING 'BDC_CURSOR'     'RMQSD-VSTEUERKZ'.
*      PERFORM BDC_FIELD       USING 'BDC_OKCODE'     '=QD'.
**-- Modified by vicky on 09.05.2005
*      IF ITAB-TYPE EQ 'X' .
*        PERFORM BDC_DYNPRO      USING 'SAPMQSDA'    '0108'.
*        PERFORM BDC_FIELD       USING 'BDC_CURSOR'  'RMQSD-MASSEINHSW'.
*        PERFORM BDC_FIELD       USING 'BDC_OKCODE'  '=WEIT'.
*        PERFORM BDC_FIELD       USING 'QPMK-STELLEN'   ITAB-STELLEN .
*        PERFORM BDC_FIELD       USING 'RMQSD-MASSEINHSW'
*                                                  ITAB-MASSEINHSW .
*      ENDIF.
*    ENDIF.
*--------------------------End of Modification By Rohit on 25/06/2010-----------------------------------------*
**-- Modified by vicky on 09.05.2005
**    IF itab-type EQ 'X' .
**--
**      PERFORM bdc_dynpro     USING  'SAPMQSDA'    '0101' .
**      PERFORM bdc_field      USING  'BDC_CURSOR'  'RMQSD-ATNAM' .
**      PERFORM bdc_field      USING  'BDC_OKCODE'  '=QD' .
**--
**      PERFORM bdc_dynpro      USING 'SAPMQSDA'    '0108'.
**      PERFORM bdc_field       USING 'BDC_CURSOR'  'RMQSD-MASSEINHSW'.
**      PERFORM bdc_field       USING 'BDC_OKCODE'  '=WEIT'.
**      PERFORM bdc_field       USING 'QPMK-STELLEN'   itab-stellen.
**      PERFORM bdc_field       USING 'QFLTP-TOLERANZUN'   itab-TOLERANZUN.
**      PERFORM bdc_field       USING 'QFLTP-TOLERANZOB'   itab-TOLERANZOB.
**
**      PERFORM bdc_field       USING 'RMQSD-MASSEINHSW'
**                                                itab-masseinhsw .

**    ENDIF.
**-- Modification over by vicky on 09.05.2005
    PERFORM bdc_dynpro      USING 'SAPMQSDA'       '0101'.
    PERFORM bdc_field       USING 'BDC_CURSOR'     'RMQSD-VSTEUERKZ'.
    PERFORM bdc_field       USING 'BDC_OKCODE'     '=BU'.


    CALL TRANSACTION 'QS21' USING bdcdata MODE g_mode .

****************Error Log creation

*      IMPORT l_subrc FROM MEMORY ID 'SY_SUBRC'.
    IF sy-msgid = 'QS' AND sy-msgty = 'E'.
      v_continue_flag  = 1.
      SELECT SINGLE * FROM t100 INTO t100 WHERE arbgb = sy-msgid
                                         AND msgnr = sy-msgno AND sprsl = 'E'.

*     MOVE-CORRESPONDING itab TO it_err.
      it_err-text  = t100-text.
      it_err-msgty = sy-msgty.
      it_err-mkmnr = itab-mkmnr.
      it_err-werks = itab-werks.
      it_err-msgno = sy-msgno.
      APPEND it_err.
      CLEAR it_err.
*************        CLEAR: SY-MSGTY , SY-MSGID.
      CONTINUE.
    ELSE.
      SELECT SINGLE * FROM t100 INTO t100 WHERE arbgb = sy-msgid
                                   AND msgnr = sy-msgno AND sprsl = 'E'.
      it_err-text  = t100-text.
      it_err-msgty = sy-msgty.
      it_err-mkmnr = itab-mkmnr.
      it_err-werks = itab-werks.
      it_err-msgno = sy-msgno.
      APPEND it_err.
      CLEAR it_err.
      v_continue_flag = 0.
      v_records = v_records + 1.

    ENDIF.

************End of Error Log creation










    CLEAR bdcdata.
    REFRESH bdcdata.
  ENDLOOP.
ENDFORM.                    " process_bdc

*---------------------------------------------------------------------*
*       FORM bdc_okcode                                               *
*---------------------------------------------------------------------*
*       ........                                                      *
*---------------------------------------------------------------------*
*  -->  fnam                                                          *
*  -->  value(p_code)                                                 *
*---------------------------------------------------------------------*

FORM bdc_okcode USING fnam VALUE(p_code) TYPE c.
  CLEAR bdcdata.
  MOVE: 'BDC_OKCODE' TO bdcdata-fnam,
        p_code       TO bdcdata-fval.
  APPEND bdcdata.
ENDFORM.                    "bdc_okcode

*---------------------------------------------------------------------*
*       FORM bdc_dynpro                                               *
*---------------------------------------------------------------------*
*       ........                                                      *
*---------------------------------------------------------------------*
*  -->  program                                                       *
*  -->  dynpro                                                        *
*---------------------------------------------------------------------*

FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM.                               "BDC_DYNPRO

*---------------------------------------------------------------------*
*       FORM bdc_field                                                *
*---------------------------------------------------------------------*
*       ........                                                      *
*---------------------------------------------------------------------*
*  -->  fnam                                                          *
*  -->  fval                                                          *
*---------------------------------------------------------------------*

FORM bdc_field USING fnam fval.
  CLEAR bdcdata.
  bdcdata-fnam = fnam.
  bdcdata-fval = fval.
  APPEND bdcdata.
ENDFORM.                    "bdc_field
*&---------------------------------------------------------------------*
*&      Form  log_report
*&---------------------------------------------------------------------*
FORM log_report .


  WRITE:/ 'The total number of records processed were                 : ', v_total.
  WRITE:/ 'The total number of records successfully processed records : ', v_records.

  WRITE:/1(50) sy-uline.
  WRITE:/1  sy-vline,
         2  'Master insp.charac.' COLOR COL_HEADING,
         17 sy-vline,
         18 'Error Text' COLOR COL_HEADING,
         50 sy-vline.
  WRITE:/1(50) sy-uline.

  LOOP AT it_err.

    v_flip_flop = sy-tabix MOD 2.
    IF  v_flip_flop = 0.
      FORMAT INTENSIFIED OFF.
    ELSE.
      FORMAT INTENSIFIED ON.
    ENDIF.
    IF it_err-msgty = 'E'.
      FORMAT COLOR COL_NEGATIVE.
      WRITE:/1  sy-vline,
             2(15)  it_err-mkmnr,
             17 sy-vline,
             18(32) it_err-text,
             50 sy-vline.
    ELSEIF it_err-msgty = 'W'.
      FORMAT COLOR COL_TOTAL.
      WRITE:/1  sy-vline,
             2  it_err-mkmnr,
             17 sy-vline,
             18(32) it_err-text,
             50 sy-vline.
    ELSE.
      FORMAT COLOR COL_POSITIVE.
      WRITE:/1  sy-vline,
             2(15)  it_err-mkmnr,
             17 sy-vline,
             18(32) it_err-text,
             50 sy-vline.
    ENDIF.

    FORMAT RESET.
  ENDLOOP.
  WRITE:/1(50) sy-uline.

ENDFORM.                    " log_report



FORM tranfer_itab_temp_to_itab .
DATA   cnt(3)..
  DATA   v_temp(20).
  DATA:  v_fl,
         v_lcnt(3).
  FIELD-SYMBOLS: <fs>,
                 <f_str>,
                 <f_data>,
                 <f_itab> .

  data_tab[] = itab_temp[].
  DATA v_fldnam LIKE dd03l-fieldname.
  REFRESH itab_temp.
  CLEAR itab_temp.
  READ TABLE data_tab INDEX 1.
  itab_temp = data_tab.
  DELETE data_tab INDEX 1.
* Fields may be with table name.Removing table names
  CLEAR cnt.
  LOOP AT data_tab.
    CLEAR cnt.
    DO 170 TIMES.
      cnt = cnt + 1.
      CONCATENATE 'itab_temp-FIELD' cnt INTO v_fldnam.

      CONDENSE v_fldnam NO-GAPS.
      ASSIGN (v_fldnam) TO <fs>.
      CONCATENATE 'DATA_TAB-FIELD' cnt INTO v_fldnam.
      CONDENSE v_fldnam NO-GAPS.
      ASSIGN (v_fldnam) TO <f_data>.
      IF <fs> CS '-'.
        SPLIT <fs> AT '-' INTO v_temp <fs>.
      ENDIF.
      CONCATENATE 'ITAB-' <fs> INTO v_fldnam.
      CONDENSE v_fldnam NO-GAPS.
      ASSIGN (v_fldnam) TO <f_itab> .
      IF sy-subrc NE 0 .
        IF v_fl IS INITIAL .
          "ERR_FIELD-FLD_NAME = <FS> .
          "ERR_FIELD-POS = CNT.
          "APPEND ERR_FIELD.
          "CLEAR ERR_FIELD.
        ENDIF.
      ELSE.
        v_lcnt = cnt.
        <f_itab> = <f_data>.
      ENDIF.
    ENDDO.
    "IF NOT ERR_FIELD[] IS INITIAL.
     " SORT ERR_FIELD BY POS.
      "READ TABLE ERR_FIELD INDEX 1.
     " IF ERR_FIELD-POS LT V_LCNT.
     "   WRITE: 'Error in Field Determination'.
     "   LOOP AT ERR_FIELD.
     "     WRITE:/ ERR_FIELD-FLD_NAME, ERR_FIELD-POS.
     "   ENDLOOP.
     "   EXIT.
    "  ELSE.
     "   REFRESH ERR_FIELD.
     " ENDIF.
    "ENDIF.
    APPEND itab.
    CLEAR itab.
    v_fl = 1.
  ENDLOOP.
  IF v_fl = 1.
    "REFRESH ERR_FIELD.
  ENDIF.

ENDFORM.                    " tranfer_itab_temp_to_itab
