
*=====================================================================*
* Include : ZPP_RESOURCE_UPLOAD_F01
* Purpose : Excel upload (.XLS), BDCDATA build from SHDB, template dl
*=====================================================================*

*---------------------------------------------------------------------*
* Initialize screen elements
*---------------------------------------------------------------------*
FORM init_screen.
  pb_tmpl = 'Download Template'.
ENDFORM.

*---------------------------------------------------------------------*
* F4 help for file selection
*---------------------------------------------------------------------*
FORM f4_file.
  CALL FUNCTION 'F4_FILENAME'
    IMPORTING file_name = p_outfil.
ENDFORM.

*---------------------------------------------------------------------*
* Handle selection screen commands (template download)
*---------------------------------------------------------------------*
FORM handle_screen_command.
  CASE sy-ucomm.
    WHEN 'DISP'.
      IF p_create = 'X'.
        pb_tmpl = 'Download Create Template'.
      ELSEIF p_change = 'X'.
        pb_tmpl = 'Download Change Template'.
      ENDIF.

    WHEN 'TMPL'.
      PERFORM download_template_xls.
  ENDCASE.
ENDFORM.

*---------------------------------------------------------------------*
* Template Download (Create now; Change stub for later)
* Header order matches Workcenter_BDC sheet (mapping by position)
*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
* Template Download (Create now; Change stub later)
* - Row 1: technical headers (match st_upload order)
* - Row 2: business-friendly labels (your line)
*---------------------------------------------------------------------*
FORM download_template_xls.
  DATA: lv_fname TYPE string, lv_path TYPE string, lv_full TYPE string.

  TYPES: BEGIN OF ty_template, col TYPE string, END OF ty_template.
  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  CLEAR lt_template.

  IF p_create = 'X'.
    "---------------------- Row 1: technical headers ----------------------"
    CONCATENATE
      'WERKS' 'ARBPL' 'VERWE' 'STEXT' 'VERAN' 'PLANV' 'VGWTS' 'RGEKZ' 'STEUS'
      'KAPART1' 'KTEXT1' 'PLANR1' 'MOSID1' 'KALID1' 'VERSA1' 'MEINS1' 'NGRAD1' 'AZNOR1' 'KAPTER1'
      'DATUV1' 'DATUB1' 'SPROG1' 'ANZTG1' 'ANZSH1' 'FABTG1' 'FORK1A_1' 'FORK1B_1' 'FORK2_1'
      'KAPART2' 'KTEXT2' 'PLANR2' 'KALID2' 'VERSA2' 'MEINS2' 'BEGZT2' 'ENDZT2' 'PAUSE2'
      'NGRAD2' 'AZNOR2' 'KAPTER2' 'FORK1A_2' 'FORK1B_2' 'FORK2_2'
      'SCHED_KAPART' 'FORT1' 'FORT2' 'FORT3'
      'KOSTL'
      'LAR1' 'LAR2' 'LAR3' 'LAR4' 'LAR5' 'LAR6'

      'FOR1' 'FOR2' 'FOR3' 'FOR4' 'FOR5'
'FOR6'


      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    APPEND ls_template TO lt_template.

    "---------------------- Row 2: friendly labels ----------------------"
    CONCATENATE
      'Plant' 'Workcenter' 'Workcenter Category' 'Description' 'Person responsible' 'Usage'
      'Standard value key' 'Backflush' 'Control key'
      'Capacity category' 'Capacity short Text' 'Capacity Responsible' 'Grouping for shift '
      'Factory calendar ID' 'Active Version' 'Base Unit of Measurement for Capacity'
      'Capacity utilization' 'No. of indiv. cap.' 'Relevent fo finite scheduling Indicator'
      'Valid from' 'Valid to' 'Shift Sequence' 'Length of cycle' 'Number of shifts' 'Work days'
      'Capacity Utilazation' 'Setup formula' 'Processing formula'
      'Formula for teardown capacity requirements'
      'Capacity category' 'Capacity short Text' 'Capacity Responsible' 'Factory calendar ID'
      'Active Version' 'Base Unit of Measurement for Capacity' 'Start time' 'Finish'
      'length Breaks' 'Capacity utilization' 'No. of indiv. cap.'
      'Relevent fo finite scheduling Indicator' 'Setup formula' 'Processing formula'
      'Formula for teardown capacity requirements' 'Capacity Category(Scheduling)'
      'Duration of set up' 'Processing Duration' 'Duration of teardown' 'Cost Center'
      'Labor setup' 'Machine setup' 'Power setup' 'Machine' 'Labor' 'Power'
      'Formula' 'Formula' 'Formula' 'Formula' 'Formula' 'Formula'
      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    APPEND ls_template TO lt_template.

  ELSEIF p_change = 'X'.
    "Keep change stub (can add 2nd label row later similarly)"
    CONCATENATE 'WERKS' 'ARBPL' 'FIELD_TO_CHANGE' 'NEW_VALUE'
      INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    APPEND ls_template TO lt_template.
  ELSE.
    MESSAGE 'Please select Create or Change before downloading template.' TYPE 'E'.
    RETURN.
  ENDIF.

  "Save dialog & download"
  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING default_extension = 'xls'
              default_file_name = COND string(
                 WHEN p_create = 'X' THEN 'Resource_Create_Template.xls'
                 WHEN p_change = 'X' THEN 'Resource_Change_Template.xls' )
    CHANGING  filename = lv_fname path = lv_path fullpath = lv_full
  ).

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  cl_gui_frontend_services=>gui_download(
    EXPORTING filename = lv_full
              filetype = 'ASC'
              write_field_separator = abap_true
    CHANGING  data_tab = lt_template
  ).

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.
ENDFORM.


*---------------------------------------------------------------------*
* Upload Excel file (.XLS) using standard FM (GUI based)
*---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* - Skips row 1 via i_line_header = 'X'
* - Skips row 2 (friendly labels) explicitly below
*---------------------------------------------------------------------*
FORM upload_file.
  DATA it_type TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'          "Row 1 = header; auto-skipped
      i_tab_raw_data       = it_type
      i_filename           = p_outfil
    TABLES
      i_tab_converted_data = it_upload
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error in uploading file' TYPE 'E'.
  ENDIF.

  "Now row-1 of it_upload corresponds to the friendly label row from Excel (row-2).
  "Delete it safely only if it really looks like the label row."
  IF lines( it_upload ) > 0.
*    READ TABLE it_upload INDEX 1 INTO wa_upload.
*    IF wa_upload-werks = 'Plant'
*       AND wa_upload-arbpl = 'Workcenter'
*       AND wa_upload-verwe = 'Workcenter Category'.
      DELETE it_upload INDEX 1.   "Data now starts from Excel row 3
*    ENDIF.
  ENDIF.

ENDFORM.


*---------------------------------------------------------------------*
* Process Create Resource (CRC1)
*---------------------------------------------------------------------*
FORM process_create_crc1.
  LOOP AT it_upload INTO wa_upload.
    REFRESH: bdcdata, messtab.
    CLEAR:   wa_log.

    PERFORM build_bdc_crc1 USING wa_upload.

    CALL TRANSACTION 'CRC1'
      USING bdcdata
      MODE   p_mode
      UPDATE 'S'
      MESSAGES INTO messtab.

    PERFORM handle_messages USING wa_upload.
  ENDLOOP.
ENDFORM.

*---------------------------------------------------------------------*
* Build BDCDATA for CRC1 – mirrors SHDB RESOURCE_UPL sequence
*---------------------------------------------------------------------*
FORM build_bdc_crc1 USING ps TYPE st_upload.

  "---- Initial ----"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '0091'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=NEXT'.
  PERFORM bdc_field  USING 'RC68A-WERKS'    ps-werks.
  PERFORM bdc_field  USING 'RCRDE-RESOURCE' ps-arbpl.
  PERFORM bdc_field  USING 'RCRDE-VERWE'    ps-verwe.

  "---- Basic / Default values ----"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '/00'.
  IF ps-stext  IS NOT INITIAL. PERFORM bdc_field USING 'P1000-STEXT'  ps-stext.  ENDIF.
  IF ps-veran  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-VERAN'  ps-veran.  ENDIF.
  IF ps-planv  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-PLANV'  ps-planv.  ENDIF.
  IF ps-vgwts  IS NOT INITIAL. PERFORM bdc_field USING 'P3000-VGWTS'  ps-vgwts.  ENDIF.
  IF ps-rgekz  = 'X'.          PERFORM bdc_field USING 'P3000-RGEKZ'  'X'.       ENDIF.
  IF ps-steus  IS NOT INITIAL. PERFORM bdc_field USING 'P3003-STEUS'  ps-steus.  ENDIF.
  "Recorded hops"
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=VORA'.
  PERFORM bdc_field  USING 'BDC_OKCODE'     '=KAUE'.

  "================ Capacity 1 (pos 01) ================"
  IF ps-kapart1 IS NOT INITIAL.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'       '/00'.
    PERFORM bdc_field  USING 'RC68A-KAPART(01)' ps-kapart1.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'.
    IF ps-ktext1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKT-KTEXT' ps-ktext1. ENDIF.
    IF ps-planr1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-PLANR' ps-planr1. ENDIF.
    IF ps-mosid1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MOSID' ps-mosid1. ENDIF.
    IF ps-kalid1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-KALID' ps-kalid1. ENDIF.
    IF ps-versa1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-VERSA' ps-versa1. ENDIF.
    IF ps-meins1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MEINS' ps-meins1. ENDIF.
    IF ps-ngrad1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-NGRAD' ps-ngrad1. ENDIF.
    IF ps-aznor1  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-AZNOR' ps-aznor1. ENDIF.
    IF ps-kapter1 = 'X'.        PERFORM bdc_field USING 'KAKO-KAPTER' 'X'.      ENDIF.

    "Validity line insert + specific dates/shifts"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'.
    PERFORM bdc_field  USING 'BDC_OKCODE'        '=INSI'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-BEGZT' '00:00:00'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-ENDZT' '00:00:00'.
    PERFORM bdc_field  USING 'KAZA_DEFAULT-PAUSE' '00:00:00'.
    IF ps-ngrad1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA_DEFAULT-NGRAD' ps-ngrad1. ENDIF.
    IF ps-aznor1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA_DEFAULT-ANZHL' ps-aznor1. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'.
    PERFORM bdc_field  USING 'BDC_OKCODE'        '/00'.
    IF ps-datuv1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-DATUV(01)' ps-datuv1. ENDIF.
    IF ps-datub1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-DATUB(01)' ps-datub1. ENDIF.
    IF ps-sprog1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-SPROG(01)' ps-sprog1. ENDIF.
    IF ps-anztg1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-ANZTG(01)' ps-anztg1. ENDIF.
    IF ps-anzsh1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-ANZSH(01)' ps-anzsh1. ENDIF.
    IF ps-fabtg1 IS NOT INITIAL. PERFORM bdc_field USING 'KAZA-FABTG(01)' ps-fabtg1. ENDIF.

    "Back to resource and place formula keys for line 1"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0116'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'       '=NPOS'.
    IF ps-fork1a_1 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORKN(01)' ps-fork1a_1. ENDIF.
    "If you must set processing/teardown separately on same line, add them here if required by your variant."
  ENDIF.

  "================ Capacity 2 (pos 02) ================"
  IF ps-kapart2 IS NOT INITIAL.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
    PERFORM bdc_field  USING 'BDC_OKCODE'       '/00'.
    PERFORM bdc_field  USING 'RC68A-KAPART(02)' ps-kapart2.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'.
    IF ps-ktext2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKT-KTEXT' ps-ktext2. ENDIF.
    IF ps-planr2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-PLANR' ps-planr2. ENDIF.
    IF ps-kalid2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-KALID' ps-kalid2. ENDIF.
    IF ps-versa2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-VERSA' ps-versa2. ENDIF.
    IF ps-meins2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-MEINS' ps-meins2. ENDIF.

    PERFORM bdc_dynpro USING 'SAPLCRK0' '0133'.
    IF ps-begzt2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-BEGZT' ps-begzt2. ENDIF.
    IF ps-endzt2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-ENDZT' ps-endzt2. ENDIF.
    IF ps-pause2  IS NOT INITIAL. PERFORM bdc_field USING 'RC68K-PAUSE' ps-pause2. ENDIF.
    IF ps-ngrad2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-NGRAD'  ps-ngrad2. ENDIF.
    IF ps-aznor2  IS NOT INITIAL. PERFORM bdc_field USING 'KAKO-AZNOR'  ps-aznor2. ENDIF.
    IF ps-kapter2 = 'X'.        PERFORM bdc_field USING 'KAKO-KAPTER' 'X'. ENDIF.

    "Back & formula key for line 2"
    PERFORM bdc_dynpro USING 'SAPLCRK0' '0101'. PERFORM bdc_field USING 'BDC_OKCODE' '=BACK'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'. PERFORM bdc_field USING 'BDC_OKCODE' '/00'.
    IF ps-fork1a_2 IS NOT INITIAL. PERFORM bdc_field USING 'P3006-FORKN(02)' ps-fork1a_2. ENDIF.
  ENDIF.

  "================ Costing + LAR/FOR (01..06) ================"
  IF ps-kostl IS NOT INITIAL OR
     ps-lar1  IS NOT INITIAL OR ps-for1 IS NOT INITIAL OR
     ps-lar2  IS NOT INITIAL OR ps-for2 IS NOT INITIAL OR
     ps-lar3  IS NOT INITIAL OR ps-for3 IS NOT INITIAL OR
     ps-lar4  IS NOT INITIAL OR ps-for4 IS NOT INITIAL OR
     ps-lar5  IS NOT INITIAL OR ps-for5 IS NOT INITIAL OR
     ps-lar6  IS NOT INITIAL OR ps-for6 IS NOT INITIAL.

    PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'. PERFORM bdc_field USING 'BDC_OKCODE' '/00'.
    PERFORM bdc_dynpro USING 'SAPLCRA0' '1004'.
    PERFORM bdc_field  USING 'P1001-BEGDA' sy-datum.
    PERFORM bdc_field  USING 'P1001-ENDDA' '99991231'.
    IF ps-kostl IS NOT INITIAL. PERFORM bdc_field USING 'CRKEYK-KOSTL' ps-kostl. ENDIF.

    "Map 6 pairs"
    IF ps-lar1 IS NOT INITIAL OR ps-for1 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(01)' ps-lar1.
      PERFORM bdc_field USING 'RC68A-FORXX(01)' ps-for1.
    ENDIF.
    IF ps-lar2 IS NOT INITIAL OR ps-for2 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(02)' ps-lar2.
      PERFORM bdc_field USING 'RC68A-FORXX(02)' ps-for2.
    ENDIF.
    IF ps-lar3 IS NOT INITIAL OR ps-for3 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(03)' ps-lar3.
      PERFORM bdc_field USING 'RC68A-FORXX(03)' ps-for3.
    ENDIF.
    IF ps-lar4 IS NOT INITIAL OR ps-for4 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(04)' ps-lar4.
      PERFORM bdc_field USING 'RC68A-FORXX(04)' ps-for4.
    ENDIF.
    IF ps-lar5 IS NOT INITIAL OR ps-for5 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(05)' ps-lar5.
      PERFORM bdc_field USING 'RC68A-FORXX(05)' ps-for5.
    ENDIF.
    IF ps-lar6 IS NOT INITIAL OR ps-for6 IS NOT INITIAL.
      PERFORM bdc_field USING 'RC68A-LARXX(06)' ps-lar6.
      PERFORM bdc_field USING 'RC68A-FORXX(06)' ps-for6.
    ENDIF.
  ENDIF.

  "================ Save ================"
  PERFORM bdc_dynpro USING 'SAPLCRA0' '4000'.
  PERFORM bdc_field  USING 'BDC_OKCODE' '=UPD'.

ENDFORM.

*---------------------------------------------------------------------*
* BDC helpers
*---------------------------------------------------------------------*
FORM bdc_dynpro USING pv_prog pv_dynnr.
  DATA ls TYPE bdcdata.
  CLEAR ls.
  ls-program  = pv_prog.
  ls-dynpro   = pv_dynnr.
  ls-dynbegin = 'X'.
  APPEND ls TO bdcdata.
ENDFORM.

FORM bdc_field USING pv_fnam pv_fval.
  DATA ls TYPE bdcdata.
  CLEAR ls.
  ls-fnam = pv_fnam.
  ls-fval = pv_fval.
  APPEND ls TO bdcdata.
ENDFORM.

*---------------------------------------------------------------------*
* Collect messages into simple log (list-based; SALV optional later)
*---------------------------------------------------------------------*
FORM handle_messages USING ps TYPE st_upload.
  DATA lv_text TYPE string.
  LOOP AT messtab INTO DATA(lsm).
    DATA(lv_line) = ||.
    CALL FUNCTION 'MESSAGE_TEXT_BUILD'
      EXPORTING msgid = lsm-msgid msgnr = lsm-msgnr
                msgv1 = lsm-msgv1 msgv2 = lsm-msgv2
                msgv3 = lsm-msgv3 msgv4 = lsm-msgv4
      IMPORTING message_text_output = lv_line.
    IF lv_text IS INITIAL.
      lv_text = lv_line.
    ELSE.
      CONCATENATE lv_text lv_line INTO lv_text SEPARATED BY ' | '.
    ENDIF.
  ENDLOOP.

  wa_log-werks   = ps-werks.
  wa_log-arbpl   = ps-arbpl.
  wa_log-status  = COND #( WHEN line_exists( messtab[ msgtyp = 'E' ] ) THEN 'Error'
                           WHEN line_exists( messtab[ msgtyp = 'W' ] ) THEN 'Warn'
                           ELSE 'Success' ).
  wa_log-message = COND string( WHEN lv_text IS INITIAL THEN 'No messages' ELSE lv_text ).
  APPEND wa_log TO it_log.
ENDFORM.

*---------------------------------------------------------------------*
* Display log (simple list)
*---------------------------------------------------------------------*
FORM display_log.
  FORMAT COLOR COL_HEADING INTENSIFIED ON.
  WRITE: / 'WERKS', 12 'ARBPL', 35 'STATUS', 46 'MESSAGE'.
  ULINE.
  FORMAT RESET.
  LOOP AT it_log INTO wa_log.
    WRITE: / wa_log-werks, 12 wa_log-arbpl, 35 wa_log-status, 46 wa_log-message.
  ENDLOOP.
ENDFORM.
