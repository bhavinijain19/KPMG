CLEAR:lv_q3.
IF ls_checklist-act_tmp IS NOT INITIAL.
  lv_q3 = ls_checklist-act_tmp.
  CONDENSE lv_q3.
ENDIF.





















