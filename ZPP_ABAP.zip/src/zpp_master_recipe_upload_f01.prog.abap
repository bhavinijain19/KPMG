*&---------------------------------------------------------------------*
*& Include          ZPP_MASTER_RECIPE_UPLOAD_F01
*&---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* DOWNLOAD TEMPLATE
*---------------------------------------------------------------------*
FORM download_template.

  DATA: lv_fname TYPE string,
        lv_path  TYPE string,
        lv_full  TYPE string.

  TYPES: BEGIN OF ty_template,
           col TYPE string,
         END OF ty_template.
  DATA: lt_template TYPE STANDARD TABLE OF ty_template,
        ls_template TYPE ty_template.

  CLEAR lt_template.

  CONCATENATE
    'Group Number' 'Counter' 'Valid from date' 'Plant' 'Short text' 'Task list UOM' 'From Lot Size'
    'To Lot Size' 'Operation' 'Phase' 'Superior operation' 'Destination' 'Work Center' 'Control Key'
    'Operation short text' 'Base Qty' 'UOM' 'Setup labor' 'Setup Machine' 'Setup Power' 'Machine' 'Labor'
    'Power' 'Material code' 'Production version' 'Production version Text' 'BOM usage' 'Alt BOM' 'Production Line'
    INTO ls_template-col SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
  APPEND ls_template TO lt_template.

  "Save dialog & download"
  cl_gui_frontend_services=>file_save_dialog(
    EXPORTING default_extension = 'xls'
              default_file_name = COND string(
                 WHEN r_down = 'X' THEN 'Master_recipe_Template.xls' )
    CHANGING  filename = lv_fname path = lv_path fullpath = lv_full ).

  IF lv_full IS INITIAL.
    MESSAGE 'Template save cancelled.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  cl_gui_frontend_services=>gui_download(
    EXPORTING filename = lv_full filetype = 'ASC' write_field_separator = abap_true
    CHANGING  data_tab = lt_template ).

  MESSAGE 'Template downloaded successfully.' TYPE 'S'.

ENDFORM.

*---------------------------------------------------------------------*
* BDC PERFORM ROUTINES
*---------------------------------------------------------------------*
FORM bdc_dynpro USING p_prog p_dyn.
  CLEAR gs_bdcdata.
  gs_bdcdata-program  = p_prog.
  gs_bdcdata-dynpro   = p_dyn.
  gs_bdcdata-dynbegin = 'X'.
  APPEND gs_bdcdata TO gt_bdcdata.
ENDFORM.

FORM bdc_field USING p_fnam p_fval.
  CLEAR gs_bdcdata.
  gs_bdcdata-fnam = p_fnam.
  gs_bdcdata-fval = p_fval.
  APPEND gs_bdcdata TO gt_bdcdata.
ENDFORM.

*---------------------------------------------------------------------*
* UPLOAD EXCEL
*---------------------------------------------------------------------*
FORM upload_excel.
  DATA it_type TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = gt_excel
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error reading Excel file' TYPE 'E'.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
* EXECUTE BDC – C201
*---------------------------------------------------------------------*
FORM execute_bdc.
  DATA : scroll TYPE char1,
         lv_str TYPE string.

*  LOOP AT gt_excel INTO gs_excel.
  READ   TABLE gt_excel INTO gs_excel INDEX 1.

  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4000'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'RC271-STTAG'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.
  PERFORM bdc_field       USING 'RC271-PLNNR'
                                gs_excel-plnnr. "record-plnnr_001.
  PERFORM bdc_field       USING 'RC271-PLNAL'
                                gs_excel-plnal. "record-plnal_002.
  PERFORM bdc_field       USING 'RC271-STTAG'
                                gs_excel-sttag. "record-sttag_003.
  PERFORM bdc_field       USING 'RC271-PROFIDNETZ'
                                'PI01'. "record-profidnetz_004.
  PERFORM bdc_dynpro      USING 'SAPLCPDA' '4210'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLKOD-PLNME'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '/00'.
  PERFORM bdc_field       USING 'PLKOD-WERKS'
                                gs_excel-werks. "record-werks_005.
  PERFORM bdc_field       USING 'PLKOD-PLNAL'
                                gs_excel-plnal. "record-plnal_006.
  PERFORM bdc_field       USING 'PLKOD-KTEXT'
                                gs_excel-ktext. "record-ktext_007.
  PERFORM bdc_field       USING 'PLKOD-VERWE'
                                '1'. "record-verwe_008.
  PERFORM bdc_field       USING 'PLKOD-STATU'
                                '4'. "record-statu_009.
  PERFORM bdc_field       USING 'PLKOD-BMSCH'
                                gs_excel-bmsch. "record-bmsch_010.
  PERFORM bdc_field       USING 'PLKOD-LOSBS'
                                gs_excel-losbs. "record-losbs_011.
  PERFORM bdc_field       USING 'PLKOD-PLNME'
                                gs_excel-plnme. "record-plnme_012.
  PERFORM bdc_dynpro      USING 'SAPLCPDA' '4210'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLKOD-WERKS'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=VOUE'.
  PERFORM bdc_field       USING 'PLKOD-WERKS'
                                gs_excel-werks. "record-werks_013.
  PERFORM bdc_field       USING 'PLKOD-PLNAL'
                                gs_excel-plnal. "record-plnal_014.
  PERFORM bdc_field       USING 'PLKOD-KTEXT'
                                gs_excel-ktext. "record-ktext_015.
  PERFORM bdc_field       USING 'PLKOD-VERWE'
                                '1'. "record-verwe_008.
  PERFORM bdc_field       USING 'PLKOD-STATU'
                                '4'. "record-statu_009.
  PERFORM bdc_field       USING 'PLKOD-BMSCH'
                                gs_excel-bmsch. "record-bmsch_010.
  PERFORM bdc_field       USING 'PLKOD-LOSBS'
                                gs_excel-losbs. "record-losbs_011.
  PERFORM bdc_field       USING 'PLKOD-PLNME'
                                gs_excel-plnme. "record-plnme_012.

*  LOOP AT gt_excel INTO gs_excel.

  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLPOD-ARBPL(01)'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=ENT1'.
  PERFORM bdc_field       USING 'PLPOD-ARBPL(01)'
                                gs_excel-arbpl. "record-arbpl_01_021.
  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLPOD-PHSEQ(02)'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=ENT1'.
  PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                '1'. "record-entry_act_022.
  PERFORM bdc_field       USING 'PLPOD-PHFLG(02)'
                                gs_excel-phflg. "record-phflg_02_023.
  PERFORM bdc_field       USING 'PLPOD-PVZNR(02)'
                                gs_excel-pvznr. "record-pvznr_02_024.
  PERFORM bdc_field       USING 'PLPOD-PHSEQ(02)'
                                gs_excel-phseq. "record-phseq_02_025.
  PERFORM bdc_field       USING 'PLPOD-ARBPL(02)'
                                gs_excel-arbpl. "record-arbpl_02_026.

  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'RC27X-ENTRY_ACT'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=ENT1'.
*  PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
*                                gs_excel-entry_act. "record-entry_act_027.
  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLPOD-VORNR(01)'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=PICK'.
*  PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
*                                gs_excel-entry_act. "record-entry_act_028.

  LOOP AT gt_excel INTO gs_excel.

    PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=P+'.

    PERFORM bdc_dynpro      USING 'SAPLCPDO' '4410'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'PLPOD-LAR06'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    IF ( sy-tabix MOD 2 ) = 0.

      PERFORM bdc_field       USING 'PLPOD-VORNR'
                                    gs_excel-vornr. "record-vornr_029.
      PERFORM bdc_field       USING 'PLPOD-STEUS'
                                    gs_excel-steus. "record-steus_030.
      PERFORM bdc_field       USING 'PLPOD-CKSELKZ'
                                    'X'. "record-ckselkz_031.
      PERFORM bdc_field       USING 'PLPOD-BMSCH'
                                    gs_excel-bmsch. "record-bmsch_032.
      PERFORM bdc_field       USING 'PLPOD-MEINH'
                                    gs_excel-meinh. "record-meinh_033.
      PERFORM bdc_field       USING 'PLPOD-VGW01'
                                    gs_excel-vgw01. "record-vgw01_034.
      PERFORM bdc_field       USING 'PLPOD-VGE01'
                                    'MIN'. "record-vge01_035.
      PERFORM bdc_field       USING 'PLPOD-LAR01'
                                    '900003'. "record-lar01_036.
      PERFORM bdc_field       USING 'PLPOD-UMREZ'
                                    '1'. "record-umrez_037.
      PERFORM bdc_field       USING 'PLPOD-UMREN'
                                    '1'. "record-umren_038.
      PERFORM bdc_field       USING 'PLPOD-VGW02'
                                    gs_excel-vgw02. "record-vgw02_039.
      PERFORM bdc_field       USING 'PLPOD-VGE02'
                                    'MIN'. "record-vge02_040.
      PERFORM bdc_field       USING 'PLPOD-LAR02'
                                    '900001'. "record-lar02_041.
      PERFORM bdc_field       USING 'PLPOD-VGW03'
                                    gs_excel-vgw03. "record-vgw03_042.
      PERFORM bdc_field       USING 'PLPOD-VGE03'
                                    'MIN'. "record-vge03_043.
      PERFORM bdc_field       USING 'PLPOD-LAR03'
                                    '900005'. "record-lar03_044.
      PERFORM bdc_field       USING 'PLPOD-VGW04'
                                    gs_excel-vgw04. "record-vgw04_045.
      PERFORM bdc_field       USING 'PLPOD-VGE04'
                                    'MIN'. "record-vge04_046.
      PERFORM bdc_field       USING 'PLPOD-LAR04'
                                    '900005'. "record-lar04_047.
      PERFORM bdc_field       USING 'PLPOD-VGW05'
                                    gs_excel-vgw05. "record-vgw05_048.
      PERFORM bdc_field       USING 'PLPOD-VGE05'
                                    'MIN'. "record-vge05_049.
      PERFORM bdc_field       USING 'PLPOD-LAR05'
                                    '900004'. "record-lar05_050.
      PERFORM bdc_field       USING 'PLPOD-VGW06'
                                    gs_excel-vgw06. "record-vgw06_051.
      PERFORM bdc_field       USING 'PLPOD-VGE06'
                                    'MIN'. "record-vge06_052.
      PERFORM bdc_field       USING 'PLPOD-LAR06'
                                    '900006'. "record-lar06_053.

      PERFORM bdc_dynpro      USING 'SAPLCPDO' '4410'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'PLPOD-LAR06'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'PLPOD-VORNR'
                                    gs_excel-vornr. "record-vornr_029.
      PERFORM bdc_field       USING 'PLPOD-STEUS'
                                    gs_excel-steus. "record-steus_030.
      PERFORM bdc_field       USING 'PLPOD-CKSELKZ'
                                    'X'. "record-ckselkz_031.
      PERFORM bdc_field       USING 'PLPOD-BMSCH'
                                    gs_excel-bmsch. "record-bmsch_032.
      PERFORM bdc_field       USING 'PLPOD-MEINH'
                                    gs_excel-meinh. "record-meinh_033.
      PERFORM bdc_field       USING 'PLPOD-VGW01'
                                    gs_excel-vgw01. "record-vgw01_034.
      PERFORM bdc_field       USING 'PLPOD-VGE01'
                                    'MIN'. "record-vge01_035.
      PERFORM bdc_field       USING 'PLPOD-LAR01'
                                    '900003'. "record-lar01_036.
      PERFORM bdc_field       USING 'PLPOD-UMREZ'
                                    '1'. "record-umrez_037.
      PERFORM bdc_field       USING 'PLPOD-UMREN'
                                    '1'. "record-umren_038.
      PERFORM bdc_field       USING 'PLPOD-VGW02'
                                    gs_excel-vgw02. "record-vgw02_039.
      PERFORM bdc_field       USING 'PLPOD-VGE02'
                                    'MIN'. "record-vge02_040.
      PERFORM bdc_field       USING 'PLPOD-LAR02'
                                    '900001'. "record-lar02_041.
      PERFORM bdc_field       USING 'PLPOD-VGW03'
                                    gs_excel-vgw03. "record-vgw03_042.
      PERFORM bdc_field       USING 'PLPOD-VGE03'
                                    'MIN'. "record-vge03_043.
      PERFORM bdc_field       USING 'PLPOD-LAR03'
                                    '900005'. "record-lar03_044.
      PERFORM bdc_field       USING 'PLPOD-VGW04'
                                    gs_excel-vgw04. "record-vgw04_045.
      PERFORM bdc_field       USING 'PLPOD-VGE04'
                                    'MIN'. "record-vge04_046.
      PERFORM bdc_field       USING 'PLPOD-LAR04'
                                    '900005'. "record-lar04_047.
      PERFORM bdc_field       USING 'PLPOD-VGW05'
                                    gs_excel-vgw05. "record-vgw05_048.
      PERFORM bdc_field       USING 'PLPOD-VGE05'
                                    'MIN'. "record-vge05_049.
      PERFORM bdc_field       USING 'PLPOD-LAR05'
                                    '900004'. "record-lar05_050.
      PERFORM bdc_field       USING 'PLPOD-VGW06'
                                    gs_excel-vgw06. "record-vgw06_051.
      PERFORM bdc_field       USING 'PLPOD-VGE06'
                                    'MIN'. "record-vge06_052.
      PERFORM bdc_field       USING 'PLPOD-LAR06'
                                    '900006'. "record-lar06_053.

    ELSE.
      PERFORM bdc_field    USING 'PLPOD-VORNR' gs_excel-vornr.
      PERFORM bdc_field    USING 'PLPOD-STEUS' gs_excel-steus.
    ENDIF.

  ENDLOOP.
  PERFORM bdc_dynpro      USING 'SAPLCPDI' '4400'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'PLPOD-VORNR(01)'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=OMBO'.
  PERFORM bdc_field       USING 'RC27X-ENTRY_ACT'
                                gs_excel-entry_act. "record-entry_act_079.
  PERFORM bdc_dynpro      USING 'SAPLCM01' '1010'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'RC27M-VERID'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                'GOON'.
  PERFORM bdc_field       USING 'RC27M-MATNR'
                                gs_excel-matnr. "record-matnr_080.
  PERFORM bdc_field       USING 'RC27M-WERKS'
                                gs_excel-werks. "record-werks_081.
  PERFORM bdc_field       USING 'RC27M-VERID'
                                gs_excel-verid. "record-verid_082.


  PERFORM bdc_dynpro      USING 'SAPLCMFV' '0200'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'MKAL-MDV01'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                'ENTR'.
  PERFORM bdc_field       USING 'MKAL-VERID'
                                gs_excel-verid. "record-verid_083.
  PERFORM bdc_field       USING 'MKAL-TEXT1'
                                gs_excel-text1. "record-text1_084.
  PERFORM bdc_field       USING 'MKAL-BSTMA'
                                '99,999,999.000'. "record-bstma_085.
  PERFORM bdc_field       USING 'MKAL-ADATU'
                                '12.01.2026'. "record-adatu_086.
  PERFORM bdc_field       USING 'MKAL-BDATU'
                                '31.12.9999'. "record-bdatu_087.
  PERFORM bdc_field       USING 'MKAL-STLAL'
                                gs_excel-stlal. "record-stlal_088.
  PERFORM bdc_field       USING 'MKAL-STLAN'
                                gs_excel-stlan. "record-stlan_089.
  PERFORM bdc_field       USING 'MKAL-MDV01'
                                gs_excel-mdv01. "record-mdv01_090.
  PERFORM bdc_dynpro      USING 'SAPLCMFV' '0200'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'MKAL-VERID'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BACK'.
  PERFORM bdc_field       USING 'MKAL-VERID'
                                gs_excel-verid. "record-verid_091.
  PERFORM bdc_field       USING 'MKAL-TEXT1'
                                gs_excel-text1. "record-text1_092.
  PERFORM bdc_field       USING 'MKAL-BSTMA'
                                '99,999,999.000'. "recordrecord-bstma_093.
  PERFORM bdc_field       USING 'MKAL-ADATU'
                                '31.12.9999'. "record-adatu_094.
  PERFORM bdc_field       USING 'MKAL-BDATU'
                                '31.12.9999'. "record-bdatu_095.
  PERFORM bdc_field       USING 'MKAL-STLAL'
                                gs_excel-stlal. "record-stlal_096.
  PERFORM bdc_field       USING 'MKAL-STLAN'
                                gs_excel-stlal. "record-stlan_097.
  PERFORM bdc_field       USING 'MKAL-MDV01'
                                gs_excel-mdv01. "record-mdv01_098.
  PERFORM bdc_dynpro      USING 'SAPLCMDI' '4000'.
  PERFORM bdc_field       USING 'BDC_CURSOR'
                                'STPOB-IDNRK(01)'.
  PERFORM bdc_field       USING 'BDC_OKCODE'
                                '=BU'.


  CALL TRANSACTION 'C201' USING gt_bdcdata MODE  p_mode UPDATE 'S' MESSAGES INTO gt_msg.


ENDFORM.
