FUNCTION-POOL ZPP_BMR_LIST               MESSAGE-ID SV.

* INCLUDE LZPP_BMR_LISTD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_BMR_LISTT00                        . "view rel. data dcl.
