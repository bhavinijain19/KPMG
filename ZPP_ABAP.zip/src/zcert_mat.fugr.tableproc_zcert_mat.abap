*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCERT_MAT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCERT_MAT           .

  PERFORM TABLEPROC.

ENDFUNCTION.
