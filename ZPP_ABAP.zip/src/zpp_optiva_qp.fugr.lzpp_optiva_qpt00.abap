*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_OPTIVA_QP...................................*
DATA:  BEGIN OF STATUS_ZPP_OPTIVA_QP                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_OPTIVA_QP                 .
CONTROLS: TCTRL_ZPP_OPTIVA_QP
            TYPE TABLEVIEW USING SCREEN '9002'.
*.........table declarations:.................................*
TABLES: *ZPP_OPTIVA_QP                 .
TABLES: ZPP_OPTIVA_QP                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
