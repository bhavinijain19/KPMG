*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_WORK_CENTER
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_WORK_CENTER     .

  PERFORM TABLEPROC.

ENDFUNCTION.
