*&---------------------------------------------------------------------*
*&  Include           ZPP_BMR_CHECKLIST_SUB
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  DATA : lt_exldata TYPE TABLE OF alsmex_tabline,
         ls_exldata TYPE alsmex_tabline.
  DATA: lt_raw     TYPE truxs_t_text_data,
        lv_cnt     TYPE i,
        lv_prcount TYPE p LENGTH 5 DECIMALS 2.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_field_seperator    = 'X'
      i_line_header        = 'X'
      i_tab_raw_data       = lt_raw
      i_filename           = p_file
*     I_STEP               = 1
    TABLES
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*       i_tab_converted_data = lt_exfinal
      i_tab_converted_data = lt_exfinal "#EC CI_FLDEXT_OK[2215424]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  SORT lt_exfinal BY sf_matnr stlal.
  LOOP AT lt_exfinal ASSIGNING FIELD-SYMBOL(<ls_exfinal>).
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <ls_exfinal>-sf_matnr
      IMPORTING
        output = <ls_exfinal>-sf_matnr.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <ls_exfinal>-stlal
      IMPORTING
        output = <ls_exfinal>-stlal.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = <ls_exfinal>-matnr
      IMPORTING
        output = <ls_exfinal>-matnr.

    MOVE-CORRESPONDING : <ls_exfinal> TO ls_bom.

    APPEND ls_bom TO lt_bom.
    CLEAR : ls_bom.
  ENDLOOP.
  SORT lt_bom BY sf_matnr stlal matnr.
  DELETE ADJACENT DUPLICATES FROM lt_bom COMPARING sf_matnr stlal matnr.

  "New Logic Starts
  LOOP AT lt_bom INTO ls_bom.

    CLEAR : lv_prcount.
    LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                         AND stlal = ls_bom-stlal
                                         AND matnr = ls_bom-matnr.
      lv_prcount = lv_prcount + ls_exfinal-contribution.
      "Comment Start by Rahul Vasita on 05.06.2024 16:12:16
***      IF lv_prcount <= '100.00' .
***        ls_log-msg1 = 'Material Details are Correct'.
***        MOVE-CORRESPONDING : ls_exfinal TO ls_log.
***      ELSE.
***        ls_log-msg2 = 'Contribution Exceed Limit of 100%'.
***        MOVE-CORRESPONDING : ls_exfinal TO ls_log.
***      ENDIF."IF lv_prcount < '0.00'.
***      APPEND ls_log TO lt_log.
***      CLEAR: ls_exfinal , ls_log.
      "Comment End by Rahul Vasita on 05.06.2024 16:12:16
    ENDLOOP.
    IF ls_bom-matnr = ' '.
      LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                         AND stlal = ls_bom-stlal
                                           AND matnr = ls_bom-matnr.
        ls_log-msg1 = 'RM Code is Blank & Details are Correct'.
        MOVE-CORRESPONDING : ls_exfinal TO ls_log.
        APPEND ls_log TO lt_log.
        CLEAR: ls_exfinal , ls_log.
      ENDLOOP.
    ELSE.
      IF lv_prcount = '100.00'.
        LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                           AND stlal = ls_bom-stlal
                                             AND matnr = ls_bom-matnr.
          ls_log-msg1 = 'Material Details are Correct'.
          MOVE-CORRESPONDING : ls_exfinal TO ls_log.
          APPEND ls_log TO lt_log.
          CLEAR: ls_exfinal , ls_log.
        ENDLOOP.
      ELSEIF lv_prcount < '100.00'.
        LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                           AND stlal = ls_bom-stlal
                                             AND matnr = ls_bom-matnr.
          ls_log-msg2 = 'Contribution Less Than Limit of 100%'.
          MOVE-CORRESPONDING : ls_exfinal TO ls_log.
          ls_log-flag = abap_true.
          APPEND ls_log TO lt_log.
          CLEAR: ls_exfinal , ls_log.
        ENDLOOP.
      ELSEIF lv_prcount > '100.00'.
        LOOP AT lt_exfinal INTO ls_exfinal WHERE sf_matnr = ls_bom-sf_matnr
                                           AND stlal = ls_bom-stlal
                                             AND matnr = ls_bom-matnr.
          ls_log-msg2 = 'Contribution Exceed Limit of 100%'.
          MOVE-CORRESPONDING : ls_exfinal TO ls_log.
          ls_log-flag = abap_true.
          APPEND ls_log TO lt_log.
          CLEAR: ls_exfinal , ls_log.
        ENDLOOP.
      ENDIF."IF lv_prcount = '100.00'.
    ENDIF."IF ls_bom-matnr = ' '.
    CLEAR : ls_bom.
  ENDLOOP.

*  CLEAR lv_cnt.
*  lv_cnt = 0.
  SORT lt_log BY sr_no. "Added by Rahul Vasita on 10.06.2024 13:47:24
  ls_log = VALUE #( lt_log[ flag = abap_true ] OPTIONAL ).
  IF ls_log IS INITIAL.
    LOOP AT lt_log INTO ls_log.
      IF ls_log-msg2 = ' ' .
*        lv_cnt  = lv_cnt + 1.
        MOVE-CORRESPONDING : ls_log TO ls_final.
        ls_final-mandt = sy-mandt.
*        ls_final-sr_no = lv_cnt .

        APPEND ls_final TO lt_final.
        CLEAR : ls_log , ls_final.
      ENDIF."IF ls_log-msg1 <> ' ' AND ls_log-msg2 <> ' '.
    ENDLOOP.
  ENDIF."IF ls_log is INITIAL.
  "New Logic Ends

  "Comment Start by Rahul Vasita on 05.06.2024 14:36:03
**  LOOP AT lt_exldata INTO ls_exldata.
**    MOVE-CORRESPONDING ls_exldata TO ls_bom.
**    APPEND ls_bom TO lt_bom.
**    CLEAR : ls_bom , ls_exldata.
**  ENDLOOP.
**  SORT lt_bom BY sf_matnr stlnr matnr.
**  DELETE ADJACENT DUPLICATES FROM lt_bom COMPARING sf_matnr stlnr matnr.
**
**  LOOP AT lt_exfinal INTO ls_exfinal.
**    MOVE-CORRESPONDING : ls_exfinal TO ls_final.
**    ls_final-mandt = sy-mandt.
**
**    APPEND ls_final TO lt_final.
**    CLEAR : ls_exfinal , ls_final.
**  ENDLOOP.
  "Comment End by Rahul Vasita on 05.06.2024 14:36:03
  IF lt_final[] IS NOT INITIAL.
    SORT lt_final BY sf_matnr stlal.
    MODIFY zpp_bmr_list FROM TABLE lt_final.
    IF sy-subrc = 0.
      MESSAGE 'DATA UPLOADED SUCCESSFULLY' TYPE 'S'.
    ELSE.
      MESSAGE 'ERROR WHILE UPLOADING DATA' TYPE 'S' DISPLAY LIKE 'E'.
    ENDIF.
  ENDIF."lt_final[] IS NOT INITIAL.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_MATERIAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_material .
  IF p_sfmat IS NOT INITIAL.
    SELECT *
      FROM zpp_bmr_list
      INTO CORRESPONDING FIELDS OF TABLE lt_final
      WHERE sf_matnr = p_sfmat AND stlal = p_stlal.
    SORT lt_final BY sf_matnr stlal.
  ELSE.
    MESSAGE 'Please Enter Finish Material Number' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF."IF p_aufnr IS NOT INITIAL.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .
  DATA lv_colpos TYPE i VALUE 0.
  IF lt_log[] IS NOT INITIAL.
    REFRESH : lt_fieldcat[],lt_header[].
    CLEAR : ls_layout , ls_variant.
    DEFINE fieldcat.
      lv_colpos = lv_colpos + 1.
      ls_fieldcat-col_pos = lv_colpos.
      ls_fieldcat-fieldname = &1.
      ls_fieldcat-seltext_m = &2.
      ls_fieldcat-seltext_l = &3.
      ls_fieldcat-outputlen = &4.
      ls_fieldcat-do_sum = &5.

      APPEND ls_fieldcat TO lt_fieldcat.
      CLEAR ls_fieldcat.
    END-OF-DEFINITION.
    CLEAR : lv_colpos.
    fieldcat : 'SR_NO' 'SR NO.' 'SR NO.' ' ' ''.
    fieldcat : 'WERKS' 'PLANT' 'PLANT' '15' ''.
    fieldcat : 'SF_MATNR' 'MATERIAL' 'MATERIAL CODE' '15' ''.
    fieldcat : 'STLAL' 'ALT. BOM' 'ALT. BOM' '15' ''.
    fieldcat : 'MATNR' 'MATERAIL' 'MATERIAL' '15' 'X'.
    fieldcat : 'CONTRIBUTION' 'CONTRIBUTION' 'CONTRIBUTION' '15' 'X'.
    fieldcat : 'STD_TMP'  'STD_TMP'  'STD_TMP' '15' ''.
    fieldcat : 'STD_TIME' 'STD_TIME' 'STD_TIME' '15' ''.
    fieldcat : 'MSG1' 'MESSAGE 1' 'MESSAGE 1' '50' ''.
    fieldcat : 'MSG2' 'MESSAGE 2' 'MESSAGE 2' '50' ''.

    ls_layout-zebra = 'X'.

    CLEAR ls_sort.
    ls_sort-fieldname = 'MATNR'.
    ls_sort-spos = '1'.
    ls_sort-up = 'X'.
    ls_sort-subtot = 'X'.
    APPEND ls_sort TO lt_sort.

**    CLEAR ls_sort.
**    ls_sort-fieldname = 'SR_NO'.
**    ls_sort-spos = '1'.
**    ls_sort-up = 'X'.
**    APPEND ls_sort TO lt_sort.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program = sy-repid
        is_layout          = ls_layout
        it_fieldcat        = lt_fieldcat[]
        it_sort            = lt_sort[]
        i_save             = 'A'
      TABLES
        t_outtab           = lt_log[].

  ELSE.
    MESSAGE 'No Data Found' TYPE 'S' DISPLAY LIKE 'E'.
  ENDIF.
ENDFORM.
