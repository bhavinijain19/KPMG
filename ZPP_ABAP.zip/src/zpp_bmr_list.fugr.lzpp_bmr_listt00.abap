*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_BMR_LIST....................................*
DATA:  BEGIN OF STATUS_ZPP_BMR_LIST                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_BMR_LIST                  .
CONTROLS: TCTRL_ZPP_BMR_LIST
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
*******start change on 17/12/2025*****
*TABLES: *ZPP_BMR_LIST                  .
*TABLES: ZPP_BMR_LIST
*******End change on 17/12/2025*****                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
