class ZCL_ZQM_INSP_PLAN_01_DPC_EXT definition
  public
  inheriting from ZCL_ZQM_INSP_PLAN_01_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
    redefinition .
  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZQM_INSP_PLAN_01_DPC_EXT IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
    TYPES:
      BEGIN OF ty_response,
        ionuniqueid       TYPE string,
        version           TYPE string,
        specificationid   TYPE string,
        specificationcode TYPE string,
        materialcode      TYPE string,
        flag              TYPE string, " e.g., 'S' for Success, 'E' for Error
        messages          TYPE TABLE OF zst_messages WITH EMPTY KEY,
      END OF ty_response.
    DATA: ls_deep_data TYPE zcl_zqm_insp_plan_01_mpc_ext=>ty_s_deep_plan,
          lv_json      TYPE string,
          ls_deep      TYPE zcl_zqm_insp_plan_01_mpc_ext=>ty_s_deep_plan,
          lt_return    TYPE bapiret2_t,
          ls_response  TYPE zcl_zqm_insp_plan_01_mpc_ext=>ty_s_deep_plan.

    " This one line now fills the header AND all nested tables at once!
    io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_data ). "#EC CI_FLDEXT_OK[2215424]

    DATA(lo_manager) = NEW zcl_insp_plan_manager( ).

    lo_manager->create_plan_from_json( EXPORTING is_deep_data = ls_deep_data CHANGING es_response = ls_response ).
    copy_data_to_ref( EXPORTING is_data = ls_response
                    CHANGING cr_data = er_deep_entity ). "#EC CI_FLDEXT_OK[2215424]
  ENDMETHOD.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITY
**  EXPORTING
**    iv_entity_name          =
**    iv_entity_set_name      =
**    iv_source_name          =
**    it_key_tab              =
**    it_navigation_path      =
**    io_tech_request_context =
**  IMPORTING
**    er_entity               =
**    es_response_context     =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~GET_ENTITYSET
**  EXPORTING
**    iv_entity_name           =
**    iv_entity_set_name       =
**    iv_source_name           =
**    it_filter_select_options =
**    it_order                 =
**    is_paging                =
**    it_navigation_path       =
**    it_key_tab               =
**    iv_filter_string         =
**    iv_search_string         =
**    io_tech_request_context  =
**  IMPORTING
**    er_entityset             =
**    es_response_context      =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.
  endmethod.
ENDCLASS.
