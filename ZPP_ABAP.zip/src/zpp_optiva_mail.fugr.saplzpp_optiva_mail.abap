*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_OPTIVA_MAILTOP.               " Global Data
  INCLUDE LZPP_OPTIVA_MAILUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_OPTIVA_MAILF...               " Subroutines
* INCLUDE LZPP_OPTIVA_MAILO...               " PBO-Modules
* INCLUDE LZPP_OPTIVA_MAILI...               " PAI-Modules
* INCLUDE LZPP_OPTIVA_MAILE...               " Events
* INCLUDE LZPP_OPTIVA_MAILP...               " Local class implement.
* INCLUDE LZPP_OPTIVA_MAILT99.               " ABAP Unit tests
  INCLUDE LZPP_OPTIVA_MAILF00                     . " subprograms
  INCLUDE LZPP_OPTIVA_MAILI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
