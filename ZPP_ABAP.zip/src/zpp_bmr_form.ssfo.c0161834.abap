CLEAR: lv_mktxt.
IF wa_item-matnr IS NOT INITIAL.
  SELECT SINGLE maktx
          FROM makt
          INTO lv_mktxt
          WHERE spras = sy-langu
            AND matnr = wa_item-matnr.
ENDIF.





















