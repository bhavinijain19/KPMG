*&---------------------------------------------------------------------*
*& Include          ZPP_PROD_ORDER_CNF_TOP
*&---------------------------------------------------------------------*


*&---------------------------------------------------------------------*
*SELECTION SCREEN
*&---------------------------------------------------------------------*
TABLES : aufk,aufm,afko.


TYPES: BEGIN OF ty_mat1,
         productionorder        TYPE aufnr,
         plant                  TYPE werks_d,
         finished_material      TYPE matnr,
         finished_material_desc TYPE string,
         material_group         TYPE matkl,
         total_qty              TYPE menge_d,
         total_qty_uom          TYPE meins,
         material_document      TYPE mblnr,
         material_document_year TYPE mjahr,
         posting_date           TYPE budat,
         produced_qty           TYPE menge_d,
         produced_uom           TYPE meins,
         material_used          TYPE matnr,
         material_used_desc     TYPE char50, " string,
         used_qty               TYPE menge_d,
         used_qty_uom           TYPE meins,
         storage_location       TYPE lgort_d,
         movement_type          TYPE bwart,
         comp_movement_type     TYPE bwart,
         bom_qty                TYPE menge_d,
         bom_uom                TYPE meins,
         deviation_qty          TYPE menge_d,
         deviation_pct          TYPE p DECIMALS 2,
         production_supervisor  TYPE afko-fevor, "string,
         work_center            TYPE char50,
       END OF ty_mat1,

       BEGIN OF ty_act1,

         manufacturingorder TYPE aufnr,
         plant              TYPE werks_d,
         product            TYPE matnr,
         product_text       TYPE maktx,
         order_qty          TYPE menge_d,
         workcenter         TYPE arbpl,
         conf_group         TYPE pph_rueck, "Confirmation Number
         conf_counter       TYPE pph_rmzhl,
         conf_date          TYPE datum,
         operation          TYPE vornr,
         std_workcenter     TYPE arbpl,

         std_setup_lab      TYPE p DECIMALS 3, "Standard Setup Labour
         std_lab_unit       TYPE afru-ile01,
         std_setup_mac      TYPE p DECIMALS 3,
         std_mac_unit       TYPE afru-ile01,
         std_setup_pow      TYPE p DECIMALS 3,
         std_pow_unit       TYPE afru-ile01,

         std_lab            TYPE p DECIMALS 3,
         std_lab_u          TYPE afru-ile01,
         std_mac            TYPE p DECIMALS 3,
         std_mac_u          TYPE afru-ile01,
         std_pow            TYPE p DECIMALS 3,
         std_pow_u          TYPE afru-ile01,

         produced_qty       TYPE menge_d,
         prod_uom           TYPE meins,

         utl_setup_lab      TYPE p DECIMALS 3,  "Utilized Setup Labour
         utl_slab_unit      TYPE afru-ile01,

         utl_setup_mach     TYPE p DECIMALS 3,
         utl_smach_unit     TYPE afru-ile01,

         utl_setup_pow      TYPE p DECIMALS 3,
         utl_spow_unit      TYPE afru-ile01,

         utl_lab            TYPE p DECIMALS 3,
         utl_lab_unit       TYPE afru-ile01,
         utl_mach           TYPE p DECIMALS 3,
         utl_mach_unit      TYPE afru-ile01,
         utl_pow            TYPE p DECIMALS 3,
         utl_pow_unit       TYPE afru-ile01,

         pln_setup_lab      TYPE p DECIMALS 3,
         pln_setup_lab_unit TYPE afru-ile01,
         pln_setup_mac      TYPE p DECIMALS 3,
         pln_setup_mac_unit TYPE afru-ile01,
         pln_setup_pow      TYPE p DECIMALS 3,
         pln_setup_pow_unit TYPE afru-ile01,

         pln_mac            TYPE p DECIMALS 3,
         pln_mac_u          TYPE afru-ile01,
         pln_lab            TYPE p DECIMALS 3,
         pln_lab_u          TYPE afru-ile01,
         pln_pow            TYPE p DECIMALS 3,
         pln_pow_u          TYPE afru-ile01,

         dev_setup_lab      TYPE p DECIMALS 3,
         dev_setup_mac      TYPE p DECIMALS 3,
         dev_setup_pow      TYPE p DECIMALS 3,

         dev_lab            TYPE p DECIMALS 3,
         dev_mac            TYPE p DECIMALS 3,
         dev_pow            TYPE p DECIMALS 3,

         dev_setup_lab_pct  TYPE p DECIMALS 2,
         dev_setup_mac_pct  TYPE p DECIMALS 2,
         dev_setup_pow_pct  TYPE p DECIMALS 2,

         dev_lab_pct        TYPE p DECIMALS 3,
         dev_mac_pct        TYPE p DECIMALS 3,
         dev_pow_pct        TYPE p DECIMALS 3,


         prod_supervisor    TYPE i_manufacturingorder-productionsupervisor,
         sched_start        TYPE datum,
         sched_end          TYPE datum,
         rel_date           TYPE datum,

       END OF ty_act1.



DATA: gt_mat1 TYPE TABLE OF ty_mat1,
      gt_act1 TYPE TABLE OF ty_act1.


SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS : s_aufnr FOR aufk-aufnr.
  SELECT-OPTIONS : s_werks FOR aufm-werks OBLIGATORY NO-EXTENSION NO INTERVALS.
  SELECT-OPTIONS : s_fevor FOR afko-fevor NO INTERVALS.
  SELECT-OPTIONS : s_budat FOR aufm-budat NO-EXTENSION.
  PARAMETERS : p_act RADIOBUTTON GROUP rad1 DEFAULT 'X'.
  PARAMETERS : p_mat RADIOBUTTON GROUP rad1.
SELECTION-SCREEN : END OF BLOCK a1.

SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-002.
  PARAMETERS : p_rad1 RADIOBUTTON GROUP rad2 DEFAULT 'X'.
  PARAMETERS : p_rad2 RADIOBUTTON GROUP rad2.
  PARAMETERS : p_rad3 RADIOBUTTON GROUP rad2.
SELECTION-SCREEN : END OF BLOCK b1.
