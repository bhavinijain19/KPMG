class ZCL_WORKORDER_UPDATE_CUS_FIELD definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_WORKORDER_UPDATE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKORDER_UPDATE_CUS_FIELD IMPLEMENTATION.


  method IF_EX_WORKORDER_UPDATE~ARCHIVE_OBJECTS.
  endmethod.


  method IF_EX_WORKORDER_UPDATE~AT_SAVE.
    FIELD-SYMBOLS: <ZFLOW> TYPE any.
    DATA(l_path) = '(SAPLXCO1)AUFK-ZORDER_FLOW'.
    ASSIGN (l_path) TO <ZFLOW>.
    IF <ZFLOW> IS ASSIGNED.
      IF <zflow> IS INITIAL.
          <ZFLOW> = 'N'.
      ENDIF.
    ENDIF.


  endmethod.
ENDCLASS.
