FUNCTION-POOL ZCERT_MAT                  MESSAGE-ID SV.

* INCLUDE LZCERT_MATD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCERT_MATT00                           . "view rel. data dcl.
