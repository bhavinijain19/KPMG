*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_BMR_LISTTOP.                  " Global Data
  INCLUDE LZPP_BMR_LISTUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_BMR_LISTF...                  " Subroutines
* INCLUDE LZPP_BMR_LISTO...                  " PBO-Modules
* INCLUDE LZPP_BMR_LISTI...                  " PAI-Modules
* INCLUDE LZPP_BMR_LISTE...                  " Events
* INCLUDE LZPP_BMR_LISTP...                  " Local class implement.
* INCLUDE LZPP_BMR_LISTT99.                  " ABAP Unit tests
  INCLUDE LZPP_BMR_LISTF00                        . " subprograms
  INCLUDE LZPP_BMR_LISTI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
