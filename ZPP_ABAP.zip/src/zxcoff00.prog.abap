*----------------------------------------------------------------------*
***INCLUDE ZXCOFF00.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  F_HELP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0007   text
*----------------------------------------------------------------------*
FORM f_help  USING    p_range TYPE fieldname
             CHANGING p_value .
  FIELD-SYMBOLS : <f_value> TYPE any.
  DATA   : lv_reas TYPE zde_reasc.
  RANGES : s_reas FOR lv_reas.
  TYPES:BEGIN OF ty_help3,
          zzreas TYPE zde_reasc,
          zztext TYPE acttext,
        END OF ty_help3.
  DATA t_help3 TYPE STANDARD TABLE OF ty_help3.
  DATA: lv_retfield   TYPE dfies-fieldname,
        lt_return_tab LIKE ddshretval OCCURS 0 WITH HEADER LINE.
  s_reas-sign = 'I'.
  s_reas-option = 'CP'.
  s_reas-low = p_range.
  APPEND s_reas.

  SELECT zzreas
         zztext
     INTO TABLE t_help3
      FROM zpp_reason
       WHERE zzreas IN s_reas.
  lv_retfield = 'ZZREAS'.
  ASSIGN (p_value) TO <f_value>.
  SORT t_help3.
*--Calling the function module for F4 help.
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = lv_retfield
      value_org       = 'S'
    TABLES
      value_tab       = t_help3[]
      return_tab      = lt_return_tab
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc = 0.
    READ TABLE lt_return_tab INDEX 1.
    <f_value> = lt_return_tab-fieldval.
  ENDIF.
ENDFORM.                    " F_HELP
