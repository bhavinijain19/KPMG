FUNCTION-POOL ZQM_QP_INTERFACE_FG.          "MESSAGE-ID ..

* INCLUDE LZQM_QP_INTERFACE_FGD...           " Local class definition
