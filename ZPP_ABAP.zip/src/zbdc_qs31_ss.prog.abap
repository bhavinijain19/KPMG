*&---------------------------------------------------------------------*
*& Include          ZBDC_QS31_SS
*&---------------------------------------------------------------------*


SELECTION-SCREEN: BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.

PARAMETERS: p_file  TYPE rlgrap-filename.
PARAMETERS: p_mode TYPE CTU_MODE DEFAULT 'A'.

SELECTION-SCREEN: END OF BLOCK b1.
