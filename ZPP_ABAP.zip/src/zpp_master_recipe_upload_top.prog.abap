*&---------------------------------------------------------------------*
*& Include          ZPP_MASTER_RECIPE_UPLOAD_TOP
*&---------------------------------------------------------------------*

*---------------------------------------------------------------------*
* TYPES – Excel Structure (As per latest template)
*---------------------------------------------------------------------*
  TYPES: BEGIN OF ty_excel,
           entry_act TYPE i,
           plnnr     TYPE plnnr,       "Group Number
           plnal     TYPE plnal,       "Counter
           sttag     TYPE char10,      "Valid from date
           werks     TYPE werks_d,     "Plan
           ktext     TYPE plantext,    "Short text
           plnme     TYPE meins,       "Task list UOM
           losvn     TYPE char17,      "From Lot Size
           losbs     TYPE char17,      "To Lot Size
           vornr     TYPE vornr,       "Operation
           phflg     TYPE char1,       "Phase
           pvznr     TYPE pvznr,       "Superior operation
           phseq     TYPE char2,       "Destination
           arbpl     TYPE arbpl,       "Work Center
           steus     TYPE steus,       "Control Key
           ltxa1     TYPE ltxa1,       "Operation short text
           bmsch     TYPE char17,      "Base Qty
           meinh     TYPE meinh,       "UOM
           vgw01     TYPE vgwrt,       "Setup labor
           vgw02     TYPE vgwrt,       "Setup Machine
           vgw03     TYPE vgwrt,       "Setup Power
           vgw04     TYPE vgwrt,       "Machine
           vgw05     TYPE vgwrt,       "Labor
           vgw06     TYPE vgwrt,       "Power
           matnr     TYPE matnr,       "Material code
           verid     TYPE verid,       "Production version
           text1     TYPE vers_text,   "Production version Text
           stlan     TYPE stlan,       "BOM usage
           stlal     TYPE stlal,       "Alt BOM
           mdv01     TYPE char8,       "Production Line
         END OF ty_excel.

  DATA: gt_excel TYPE STANDARD TABLE OF ty_excel,
        gs_excel TYPE ty_excel.

  DATA: gt_bdcdata TYPE STANDARD TABLE OF bdcdata,
        gs_bdcdata TYPE bdcdata,
        gt_msg     TYPE STANDARD TABLE OF bdcmsgcoll.
