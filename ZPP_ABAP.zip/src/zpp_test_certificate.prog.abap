*&---------------------------------------------------------------------*
*& Report  ZPP_TEST_CERTIFICATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zpp_test_certificate.
TABLES : qals.
INCLUDE zpp_test_certificate_top.
DATA : v_fm_name1 TYPE  rs38l_fnam.
DATA: p_werks TYPE qals-werk.

DATA: g_type TYPE dd01v-datatype.
DATA: g_string(10) TYPE c.

SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS  : s_pruef FOR qals-prueflos OBLIGATORY.
SELECTION-SCREEN :  END OF BLOCK b1.

START-OF-SELECTION.

  SELECT prueflos,
         matnr,
         charg,
         mjahr,
         mblnr FROM qals INTO TABLE @DATA(lt_qals) WHERE prueflos IN @s_pruef.

********************    Authorization object

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE werk
*       FROM qals INTO @p_werks WHERE prueflos IN @s_pruef.

SELECT WERK
 FROM QALS INTO @P_WERKS UP TO 1 ROWS WHERE PRUEFLOS IN @S_PRUEF
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


  AUTHORITY-CHECK OBJECT 'Z_CERT_WRK'
     ID 'WERKS' FIELD p_werks
     ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e007(zsd) WITH p_werks.
  ENDIF.
  CLEAR : p_werks.

**************


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE matnr charg FROM qals INTO ( gv_matnr , gv_charg ) WHERE prueflos IN s_pruef.

SELECT MATNR CHARG FROM QALS INTO ( GV_MATNR , GV_CHARG ) UP TO 1 ROWS WHERE PRUEFLOS IN S_PRUEF
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

  SELECT SINGLE maktx FROM makt INTO gv_maktx WHERE matnr EQ gv_matnr.

  IF lt_qals IS NOT INITIAL.

    SELECT matnr,
           spras,
           maktx FROM makt INTO TABLE @DATA(lt_makt) FOR ALL ENTRIES IN @lt_qals WHERE matnr = @lt_qals-matnr AND spras = 'E'.

    SELECT matnr,
           charg,
           hsdat FROM mch1 INTO TABLE @DATA(lt_mch1) FOR ALL ENTRIES IN @lt_qals WHERE matnr = @lt_qals-matnr AND charg = @lt_qals-charg.

    SELECT mblnr,
           mjahr,
           matnr,
           werks,
           charg,
           meins FROM mseg INTO TABLE @DATA(lt_mseg) FOR ALL ENTRIES IN @lt_qals  WHERE mblnr = @lt_qals-mblnr AND mjahr = @lt_qals-mjahr.


* Quick Fix Insert a SORT statement after the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
SORT LT_MSEG BY MBLNR MJAHR.

* End of Quick Fix
ENDIF.

  DELETE lt_mseg WHERE matnr NA 'SF'.
  DELETE lt_mseg WHERE meins NE 'KG'.

  DESCRIBE TABLE lt_mseg LINES lv_lines.

  gt_mseg[] = lt_mseg[].

  IF lv_lines GE '02'.

    READ TABLE gt_mseg INTO gs_mseg INDEX 1.
    IF sy-subrc = 0.
      MOVE-CORRESPONDING gs_mseg TO wa_mseg.
      APPEND wa_mseg TO it_mseg.
      CLEAR wa_mseg.
    ENDIF.

    READ TABLE gt_mseg INTO gs_mseg INDEX 2.
    IF sy-subrc = 0.
      MOVE-CORRESPONDING gs_mseg TO wa_mseg.
      APPEND wa_mseg TO it_mseg.
      CLEAR wa_mseg.
    ENDIF.

    REFRESH lt_mseg.

    lt_mseg[] = it_mseg[].

  ENDIF.

  DELETE lt_mseg WHERE charg IS INITIAL.

  IF lt_mseg IS NOT INITIAL.

**********************************************************************************************************************************
    " Added By Pratik M. Date - 02.02.2024

*    READ TABLE lt_mseg INTO wa_mseg with key matnr = gv_matnr.
*    SELECT prueflos,
*           matnr,
*           charg  FROM qals INTO TABLE @DATA(lt_qals1) WHERE prueflos IN @s_pruef .

    " End of Changes.

" Commented By Pratik M. Date - 02.02.2024

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT prueflos,
*           matnr,
*           charg  FROM qals INTO TABLE @DATA(lt_qals1) FOR ALL ENTRIES IN @lt_mseg WHERE matnr = @lt_mseg-matnr AND charg = @lt_mseg-charg.

SELECT PRUEFLOS ,
 MATNR ,
 CHARG FROM QALS INTO TABLE @DATA(LT_QALS1) FOR ALL ENTRIES IN @LT_MSEG WHERE MATNR = @LT_MSEG-MATNR AND CHARG = @LT_MSEG-CHARG
 ORDER BY PRIMARY KEY .
* End of Quick Fix


**********************************************************************************************************************************

    DESCRIBE TABLE lt_qals1 LINES lv_line1.

    IF lv_line1 GE '02'.

      READ TABLE lt_qals1 INTO DATA(ls_qals1) INDEX 1.
      IF sy-subrc = 0.
        gv_sf1 = ls_qals1-prueflos.
      ENDIF.

      READ TABLE lt_qals1 INTO ls_qals1 INDEX 2.
      IF sy-subrc = 0.
        gv_sf2 = ls_qals1-prueflos.
      ENDIF.

    ENDIF.

  ELSE.

    MESSAGE 'No data found' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.

  ENDIF.

  IF lt_qals1 IS NOT INITIAL.

    SELECT prueflos,
           kurztext,
           pmethode,
           verwmerkm,
           mkversion,
           merknr,
           qmtb_werks,
           toleranzob,
           toleranzun,
           masseinhsw FROM qamv INTO TABLE @DATA(lt_qamv) FOR ALL ENTRIES IN @lt_qals1 WHERE prueflos = @lt_qals1-prueflos.

    IF lt_qamv IS NOT INITIAL.

      SELECT mkmnr, kurztext FROM qpmt INTO TABLE @DATA(lt_qpmt) FOR ALL ENTRIES IN @lt_qamv WHERE zaehler = @lt_qamv-qmtb_werks
                                                                                               AND mkmnr = @lt_qamv-verwmerkm.

    ENDIF.

    SELECT prueflos,
           merknr,
           pruefbemkt,
           gruppe1,
           code1,
           original_input FROM qamr INTO TABLE @DATA(lt_qamr) FOR ALL ENTRIES IN @lt_qals1 WHERE prueflos = @lt_qals1-prueflos.

    IF lt_qamr IS NOT INITIAL.

      SELECT katalogart,
             codegruppe,
             code,
             sprache,
             kurztext FROM qpct INTO TABLE @DATA(lt_qpct) FOR ALL ENTRIES IN @lt_qamr WHERE codegruppe = @lt_qamr-gruppe1 AND code = @lt_qamr-code1
                                                                                        AND sprache = 'E'.

    ENDIF.

  ENDIF.

  IF lt_qamv IS NOT INITIAL.

    SELECT werks,
           pmtnr,
           version,
           sortfeld FROM qmtb INTO TABLE @DATA(lt_qmtb) FOR ALL ENTRIES IN @lt_qamv WHERE pmtnr = @lt_qamv-pmethode AND version = @lt_qamv-mkversion
                                                                                          AND werks = @lt_qamv-qmtb_werks.

  ENDIF.

****************Added by Raj on 22.09.2023*************
  LOOP AT lt_qamv INTO DATA(wa_qamv).
    MOVE-CORRESPONDING wa_qamv TO wa_temp.
    APPEND wa_temp TO it_temp.
    CLEAR :wa_qamv,wa_temp.
  ENDLOOP.

  IF lt_qamv IS NOT INITIAL.
    SELECT zuom zzuom FROM zpp_unit INTO TABLE it_zpp_unit FOR ALL ENTRIES IN it_temp WHERE zuom = it_temp-masseinhsw.
  ENDIF.
***************Added by Raj on 22.09.2023**************
  LOOP AT lt_qamr INTO DATA(ls_qamr1).

    wa_final1-prueflos = ls_qamr1-prueflos.
    wa_final1-merknr   = ls_qamr1-merknr.
    IF ls_qamr1-original_input IS NOT INITIAL.
      wa_final1-original_input = ls_qamr1-original_input.
    ELSE.
      wa_final1-original_input = ls_qamr1-pruefbemkt.
    ENDIF.


    READ TABLE lt_qpct INTO DATA(ls_qpct) WITH KEY codegruppe = ls_qamr1-gruppe1 code = ls_qamr1-code1.
    IF sy-subrc = 0.
      wa_final1-kurztext = ls_qpct-kurztext.
    ENDIF.

*    IF ls_qamr1-original_input IS INITIAL.
*      MOVE wa_final1-kurztext TO wa_final1-original_input.
*    ENDIF.

    APPEND wa_final1 TO it_final1.
    CLEAR: wa_final1,ls_qamr1,ls_qpct.

  ENDLOOP.

  DATA: w_expo         TYPE qpmk-sollwert,
        w_expo1        TYPE qpmk-sollwert,
        w_expo2        TYPE qpmk-sollwert, "Added By Raj on 20.09.2023


        w_pckdeci(16)  TYPE p DECIMALS 3, "Added By Raj on 20.09.2023
*        w_pckdeci(16)  TYPE p DECIMALS 1,"Comment by Raj on 20.09.2023
        w_pckdeci1(16) TYPE p DECIMALS 3, "Added by Raj on 20.09.2023
*        w_pckdeci1(16) TYPE p DECIMALS 1."Comment by Raj on 20.09.2023
        w_pckdeci2(16) TYPE p DECIMALS 3. "Added by Raj on 20.09.2023

  LOOP AT lt_qals INTO DATA(wa_qals).

    wa_header-charg = wa_qals-charg.

    READ TABLE lt_makt INTO DATA(ls_makt) WITH KEY matnr = wa_qals-matnr.
    IF sy-subrc = 0.
      wa_header-maktx = ls_makt-maktx.
    ENDIF.

    READ TABLE lt_mch1 INTO DATA(wa_mchl) WITH KEY matnr = wa_qals-matnr charg = wa_qals-charg.
    IF sy-subrc = 0.
      wa_header-hsdat = wa_mchl-hsdat.
    ENDIF.

  ENDLOOP.

  LOOP AT lt_qamv INTO DATA(ls_qamv).

    CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
      EXPORTING
        input          = ls_qamv-masseinhsw
        language       = sy-langu
      IMPORTING
        long_text      = lv_ltext
        output         = lv_output
        short_text     = lv_stext
      EXCEPTIONS
        unit_not_found = 1
        OTHERS         = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

******Added by Raj on 22.09.2023**********************
*    READ TABLE it_zpp_unit INTO wa_zpp_unit WITH KEY zuom = ls_qamv-masseinhsw. "comment 21.12.2023
*    READ TABLE it_zpp_unit INTO wa_zpp_unit WITH KEY zuom = lv_output. " added 21.12.2023.

    v_werks = ls_qamv-qmtb_werks."Added By Raj on 06.09.2023

*   wa_final-masseinhsw = lv_ltext."Commented by Raj on 21.09.2023

*    wa_final-masseinhsw = wa_zpp_unit-zztext."Added by Raj on 21.09.2023 .This(UOM TEXT or Description) will fetch from ZPP_UNIT table
*
*    if wa_final-masseinhsw is INITIAL.
*     wa_final-masseinhsw = lv_ltext."Commented by Raj on 21.09.2023
*     endif.
*********************UOM Changes on 03.11.2023***********
*    IF wa_zpp_unit IS NOT INITIAL.
*      wa_final-masseinhsw = wa_zpp_unit-zzuom.
*    ELSE.
*      wa_final-masseinhsw = ls_qamv-masseinhsw." comment 21.12.2023
*      wa_final-masseinhsw = lv_output. " added 21.12.2023                  " Commeneted By Pratik M. - 02.02.2024
*    ENDIF.
*******************UOM Changes on 03.11.2023************

******************************************************************************************

    " Added By Pratik M Date - 02.02.2024
    DATA gt_char TYPE TABLE OF  bapi2045d1.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    CALL FUNCTION 'BAPI_INSPOPER_GETDETAIL'    "#EC CI_USAGE_OK[2438131]
      EXPORTING
        insplot                = ls_qamv-prueflos
        inspoper               = '0010'
        read_insppoints        = 'X'
        read_char_requirements = 'X'
        read_char_results      = 'X'
        read_sample_results    = 'X'
*       read_single_results    = 'X'
*       read_chars_with_classes = 'X'
*       READ_CHARS_WITHOUT_RECORDING       = ' '
*       RES_ORG                = ' '
        char_filter_no         = '1'
        char_filter_tcode      = 'QE11'
        max_insppoints         = 100
        insppoint_from         = 0
*       HANDHELD_APPLICATION   = ' '
*       RESULT_COPY            = ' '
* IMPORTING
*       OPERATION              =
*       INSPPOINT_REQUIREMENTS =
*       RETURN                 =
      TABLES
*       INSPPOINTS             =
        char_requirements      = gt_char.
*   CHAR_RESULTS                       =
*   SAMPLE_RESULTS                     =
*   SINGLE_RESULTS                     =

" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    READ TABLE gt_char INTO DATA(gs_char) WITH KEY inspchar = ls_qamv-merknr.
    wa_final-masseinhsw = gs_char-meas_unit.

    " End of Changes Date - 02.02.2024
******************************************************************************************

    wa_final-prueflos   = ls_qamv-prueflos.
    wa_final-merknr     = ls_qamv-merknr.

    wa_final-toleranzun = ls_qamv-toleranzun.
    MOVE : wa_final-toleranzun TO w_expo,
            w_expo TO w_pckdeci.
    wa_final-toleranzun1 = w_pckdeci.

    wa_final-toleranzob = ls_qamv-toleranzob.
    MOVE : wa_final-toleranzob TO w_expo1,
           w_expo1 TO w_pckdeci1.
    wa_final-toleranzob1 = w_pckdeci1.

*************Added by Raj on 20.09.2023**********************
*    MOVE : wa_final-original_input TO w_expo2,
*           w_expo2 TO w_pckdeci2.
*    wa_final-original_input1 = w_pckdeci2.

************Added by Raj on 20.09.2023***********************
    READ TABLE lt_qpmt INTO DATA(ls_qpmt) WITH KEY mkmnr = ls_qamv-verwmerkm.
    IF sy-subrc = 0.
      wa_final-kurztext = ls_qpmt-kurztext.
    ENDIF.

    IF  wa_final-toleranzun1 = 0 AND wa_final-toleranzob1 = 0.
      MOVE ls_qamv-kurztext TO wa_final-toleranzun2.
    ELSE .
      CONCATENATE wa_final-toleranzun1 '-' wa_final-toleranzob1 INTO wa_final-toleranzun2.
    ENDIF.

    READ TABLE lt_qmtb INTO DATA(ls_qmtb) WITH KEY pmtnr = ls_qamv-pmethode version = ls_qamv-mkversion werks = ls_qamv-qmtb_werks.
    IF sy-subrc = 0.
      wa_final-sortfeld = ls_qmtb-sortfeld.
    ENDIF.

    READ TABLE it_final1 INTO wa_final1 WITH KEY prueflos = ls_qamv-prueflos merknr = ls_qamv-merknr.
    IF sy-subrc = 0.
      wa_final-original_input = wa_final1-original_input.
*       wa_final-original_input1 = wa_final1-original_input."Commented By Raj on 20.09.2023

*************Added by Raj on 20.09.2023**********************
*      CALL FUNCTION 'NUMERIC_CHECK'
*        EXPORTING
*          string_in = wa_final-original_input
*        IMPORTING
*          htype     = g_type.
*
*      IF g_type = 'NUMC'.
*        MOVE : wa_final-original_input TO w_expo2,
*               w_expo2 TO w_pckdeci2.
*        wa_final-original_input1 = w_pckdeci2.
*      ELSE.
*        wa_final-original_input1 = wa_final-original_input.
*      ENDIF.

************Added by Raj on 20.09.2023***********************
    ENDIF.

    APPEND wa_final TO it_final.
    CLEAR: wa_final,ls_qamv,g_type,wa_zpp_unit,lv_ltext,lv_output.",gs_char.

  ENDLOOP.

  READ TABLE lt_mseg INTO DATA(ls_mseg) INDEX 2.
  IF sy-subrc NE 0.

    LOOP AT it_final INTO wa_final.
      MOVE-CORRESPONDING wa_final TO ls_fin.
      APPEND ls_fin TO lt_fin.
      CLEAR: wa_final, ls_fin.
    ENDLOOP.

    SORT lt_fin ASCENDING BY merknr.

    PERFORM fill_listheader.
    PERFORM fill_fieldcatalog1.
    PERFORM fill_layout.
    PERFORM display1.

  ELSE.

    LOOP AT it_final INTO wa_final.
      MOVE-CORRESPONDING wa_final TO ls_final.
      IF wa_final-prueflos = gv_sf1.
        ls_final-parta = 'X'.
      ELSEIF wa_final-prueflos = gv_sf2.
        ls_final-partb = 'X'.
      ENDIF.
      APPEND ls_final TO lt_final.
      CLEAR: wa_final, ls_final.
    ENDLOOP.

    SORT lt_final ASCENDING BY prueflos merknr.

    PERFORM fill_listheader.
    PERFORM fill_fieldcatalog.
    PERFORM fill_layout.
    PERFORM display.

  ENDIF.


*&---------------------------------------------------------------------*
*&      Form  FILL_LISTHEADER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_listheader .

  it_listheader-typ = 'H'.
  it_listheader-key = ' '.
  it_listheader-info = 'SFG Selection'.
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Date :' .
  CONCATENATE  sy-datum+6(2)

               sy-datum+4(2)
               sy-datum(4)
               INTO it_listheader-info
               SEPARATED BY '/'.
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Material :' .
" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  CONCATENATE  gv_matnr '(' gv_maktx ')'    "#EC CI_FLDEXT_OK[2215424]
               INTO it_listheader-info
               SEPARATED BY space.
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Batch :' .
  it_listheader-info = gv_charg.
  APPEND it_listheader.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .

  REFRESH: it_fieldcat.

  PERFORM fieldcat_append  USING  'PARTA'               'PART A'               'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'PARTB'               'PART B'               'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'OTHER'               'OTHER'                'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'KURZTEXT'            'PROPERTIES'           'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'SORTFELD'            'TESTING STANDARD'     'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'TOLERANZUN2'         'SPECIFICATION'        'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'ORIGINAL_INPUT'      'RESULTS'              'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'MASSEINHSW'          'UNIT'                 'X' ' ' ' ' 'LT_FINAL' .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0045   text
*      -->P_0046   text
*      -->P_0047   text
*      -->P_0048   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_check)
                               VALUE(p_edit)
                               VALUE(p_table).

  it_fieldcat-fieldname   = p_fname.
  it_fieldcat-seltext_l   = p_ftext.
  it_fieldcat-fix_column  = p_fixcol.
  it_fieldcat-checkbox    = p_check.
  it_fieldcat-edit        = p_edit.
  it_fieldcat-tabname     = p_table.

  APPEND it_fieldcat.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS'
      i_callback_user_command  = 'USER_COMMAND'
      i_callback_top_of_page   = 'TOP_OF_PAGE'
      is_layout                = fs_layout
      it_fieldcat              = it_fieldcat[]
      it_events                = t_event[]
      i_save                   = 'A'
    TABLES
      t_outtab                 = lt_final[]
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_layout .

  t_event-name = slis_ev_top_of_page.
  t_event-form = 'TOP_OF_PAGE'.
  APPEND t_event.
  fs_layout-colwidth_optimize = 'X'.

ENDFORM.
FORM top_of_page.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_listheader[].

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PF_STATUS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM pf_status USING rt_extab TYPE slis_t_extab.
 "Added on 10.03.2026 UDAYABAP03
  Delete rt_extab[] WHERE fcode is NOT INITIAL.
 "Added on 10.03.2026 UDAYABAP03
  SET PF-STATUS 'CERTIFICATE'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  USER_COMMAND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM user_command USING r_ucomm TYPE sy-ucomm r_field TYPE slis_selfield.

  CASE r_ucomm.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    WHEN 'FORM'.   "#EC CI_USAGE_OK[2270335]
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

      SORT lt_final ASCENDING BY prueflos	merknr.

      CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
        IMPORTING
          e_grid = ref.

      CALL METHOD ref->check_changed_data.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname = 'ZPP_TEST_CERT1'
        IMPORTING
          fm_name  = v_fm_name1.
      IF sy-subrc <> 0.
*       Implement suitable error handling here
      ENDIF.

      CALL FUNCTION v_fm_name1
        EXPORTING
          wa_header = wa_header
          gv_sf1    = gv_sf1
          gv_sf2    = gv_sf2
          v_werks   = v_werks
        TABLES
          it_final  = lt_final.

      IF sy-subrc <> 0.
      ENDIF.

  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog1 .

  REFRESH: it_fieldcat.

  PERFORM fieldcat_append  USING  'PARTA'               'SELECTION'            'X' 'X' 'X' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'KURZTEXT'            'PROPERTIES'           'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'SORTFELD'            'TESTING STANDARD'     'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'TOLERANZUN2'         'SPECIFICATION'        'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'ORIGINAL_INPUT'      'RESULTS'              'X' ' ' ' ' 'LT_FINAL' .
  PERFORM fieldcat_append  USING  'MASSEINHSW'          'UNIT'                 'X' ' ' ' ' 'LT_FINAL' .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display1 .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'PF_STATUS'
      i_callback_user_command  = 'USER_COMMAND1'
      i_callback_top_of_page   = 'TOP_OF_PAGE'
      is_layout                = fs_layout
      it_fieldcat              = it_fieldcat[]
      it_events                = t_event[]
      i_save                   = 'A'
    TABLES
      t_outtab                 = lt_fin[]
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

ENDFORM.
FORM user_command1 USING r_ucomm TYPE sy-ucomm r_field TYPE slis_selfield.

  CASE r_ucomm.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    WHEN 'FORM'.     "#EC CI_USAGE_OK[2270335]
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

      SORT lt_fin ASCENDING BY merknr.

      CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
        IMPORTING
          e_grid = ref.

      CALL METHOD ref->check_changed_data.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname = 'ZPP_TEST_CERT'
        IMPORTING
          fm_name  = v_fm_name1.
      IF sy-subrc <> 0.
*       Implement suitable error handling here
      ENDIF.

      CALL FUNCTION v_fm_name1
        EXPORTING
          wa_header = wa_header
          v_werks   = v_werks
        TABLES
          lt_fin    = lt_fin.

      IF sy-subrc <> 0.
      ENDIF.

  ENDCASE.

ENDFORM.
