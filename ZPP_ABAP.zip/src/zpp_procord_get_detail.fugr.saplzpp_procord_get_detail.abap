*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_PROCORD_GET_DETAILTOP.        " Global Declarations
  INCLUDE LZPP_PROCORD_GET_DETAILUXX.        " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_PROCORD_GET_DETAILF...        " Subroutines
* INCLUDE LZPP_PROCORD_GET_DETAILO...        " PBO-Modules
* INCLUDE LZPP_PROCORD_GET_DETAILI...        " PAI-Modules
* INCLUDE LZPP_PROCORD_GET_DETAILE...        " Events
* INCLUDE LZPP_PROCORD_GET_DETAILP...        " Local class implement.
* INCLUDE LZPP_PROCORD_GET_DETAILT99.        " ABAP Unit tests
