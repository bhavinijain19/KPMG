*&---------------------------------------------------------------------*
*& Report ZPP_WORKCENTER_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZPP_WORKCENTER_UPLOAD.

INCLUDE zpp_workcenter_upload_top.
INCLUDE zpp_workcenter_upload_sel.
INCLUDE zpp_workcenter_upload_f01.

*-------------------------------------------------------------*
* Initialization
*-------------------------------------------------------------*
INITIALIZATION.
  PERFORM init_screen.

*-------------------------------------------------------------*
* F4 Help for file
*-------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_outfil.
  PERFORM f4_file.

*-------------------------------------------------------------*
* Selection screen commands
*-------------------------------------------------------------*
AT SELECTION-SCREEN.
  PERFORM handle_screen_command.

*-------------------------------------------------------------*
* Main processing
*-------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM upload_file.

  IF it_upload[] IS INITIAL.
    MESSAGE 'No data found in upload file' TYPE 'I'.
    EXIT.
  ENDIF.

  "Create path (Change can be added later similar to CRC2)"
  IF p_create = 'X'.
    PERFORM process_create_zcr01.
  ELSE.
    MESSAGE 'Change mode is not implemented yet.' TYPE 'S' DISPLAY LIKE 'W'.
  ENDIF.

END-OF-SELECTION.
  PERFORM display_log.
