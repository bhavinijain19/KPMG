*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_BRM_ERR_EMA.................................*
DATA:  BEGIN OF STATUS_ZPP_BRM_ERR_EMA               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_BRM_ERR_EMA               .
CONTROLS: TCTRL_ZPP_BRM_ERR_EMA
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZPP_BRM_ERR_EMA               .
TABLES: ZPP_BRM_ERR_EMA                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
