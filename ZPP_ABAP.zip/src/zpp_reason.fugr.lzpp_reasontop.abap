FUNCTION-POOL ZPP_REASON                 MESSAGE-ID SV.

* INCLUDE LZPP_REASOND...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_REASONT00                          . "view rel. data dcl.
