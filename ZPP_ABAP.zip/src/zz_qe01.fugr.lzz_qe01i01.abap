*----------------------------------------------------------------------*
***INCLUDE LZZ_QE01I01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9100 INPUT.
    DATA(ok_code) = sy-ucomm.
  CASE ok_code.
    WHEN 'BU' .
      gs_zpp_qe01-PLANT = w_qals-werk.
      gs_zpp_qe01-ILOT = w_qals-prueflos.
      gs_zpp_qe01-prod_order = w_qals-AUFNR.
      gs_zpp_qe01-material = w_qals-MATNR.
      gs_zpp_qe01-batch = w_qals-charg.
      gs_zpp_qe01-zcontrol_indi = w_qals-zz1_zcontrol_ind_ilh.
      gs_zpp_qe01-zloc = w_qals-zz1_zloc_ilh.
      gs_zpp_qe01-zsample_qty = w_qals-zz1_zsample_qty_ilh.
      gs_zpp_qe01-created_on = sy-datum.
      gs_zpp_qe01-created_by = sy-uname.
      MODIFY ZPP_QE01_cust FROM gs_zpp_qe01.
    WHEN 'ENT0'.

    WHEN OTHERS.
  ENDCASE.
ENDMODULE.
