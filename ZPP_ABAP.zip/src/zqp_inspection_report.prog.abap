*&---------------------------------------------------------------------*
*& Report  ZQP_INSPECTION_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zqp_inspection_report.
TABLES: mapl.
TYPE-POOLS : slis.

*&-------------------------------SELECTION SCREEN--------------------------------------------------&*
SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
PARAMETERS  : s_werks TYPE mapl-werks OBLIGATORY.
*SELECT-OPTIONS: s_matnr FOR mapl-matnr OBLIGATORY,
SELECT-OPTIONS: s_matnr FOR mapl-matnr ,
                s_date  FOR mapl-datuv OBLIGATORY.
*                s_plnnr FOR mapl-plnnr .
SELECTION-SCREEN:END OF BLOCK a1.
*&---------------------------------------------------------------------*

*&-------------------------------DATA DECLARATION--------------------------------------*

TYPES : BEGIN OF ty_final,
          matnr      TYPE mapl-matnr,
          werks      TYPE mapl-werks,
          plnnr      TYPE mapl-plnnr,
          datuv      TYPE mapl-datuv,
          vornr      TYPE plpo-vornr,
          arbid      TYPE plpo-arbid,
          steus      TYPE plpo-steus,
          ltxa1      TYPE plpo-ltxa1,

          merknr     TYPE plmk-merknr,
          kurztext   TYPE plmk-kurztext,
          quantitat  TYPE plmk-katab1,
          katab1     TYPE plmk-katab1,
          verwmerkm  TYPE plmk-verwmerkm,
          mkversion  TYPE plmk-mkversion,
          qpmk_werks TYPE plmk-qmtb_werks,
          pmethode   TYPE plmk-pmethode,
          pmtversion TYPE plmk-pmtversion,
          qmtb_werks TYPE plmk-qmtb_werks,
          stichprver TYPE plmk-stichprver,
          masseinhsw TYPE plmk-masseinhsw,
          stellen    TYPE plmk-stellen,
*          toleranzun TYPE plmk-toleranzun,
*          toleranzob TYPE plmk-toleranzob,
*          sollwert   TYPE plmk-sollwert,
          toleranzun TYPE p decimals 3,
          toleranzob TYPE p decimals 3,
          sollwert   TYPE p decimals 3,

          katalgart1 TYPE plmk-katalgart1,
          auswmenge1 TYPE plmk-auswmenge1,
          auswmgwrk1 TYPE plmk-auswmgwrk1,
          codegruppe TYPE qpac-codegruppe,
          code       TYPE qpac-code,
          ktext      TYPE plko-ktext,
          verwe      TYPE plko-verwe,
          arbpl      TYPE crhd-arbpl,
          kurztext1  TYPE qpct-kurztext,
          plnal      TYPE mapl-plnal,
          meinh      TYPE plpo-meinh,
          bmsch      TYPE plpo-bmsch,
          mseh6      TYPE t006a-mseh6,
          loekz type plmk-loekz,"Added by Raj on 26.05.2023
          delkz type plko-delkz,"Added by Raj on 26.05.2023
          lifnr type mapl-lifnr,
        END OF ty_final.

DATA : it_final TYPE STANDARD TABLE OF ty_final.
*FIELD-SYMBOLS : <fs_final> TYPE ty_final.
DATA : fs_final TYPE ty_final.
DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       it_fieldcat1   TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv.
*&-------------------------------------------------------------------------------------*


*&---------------------------------------------------------------------*
START-OF-SELECTION.
*&---------------------------------------------------------------------*
  PERFORM authorization_check.
  PERFORM get_data.
  PERFORM fill_fieldcatalog.
  PERFORM display_grid.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  AUTHORITY-CHECK OBJECT 'ZQM_WERKS'
      ID 'WERKS' FIELD s_werks
      ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e007(zsd) WITH s_werks.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  SELECT matnr,werks,plnnr,plnal,datuv,lifnr FROM mapl
    INTO TABLE @DATA(it_mapl)
    WHERE matnr IN @s_matnr
    AND   werks = @s_werks
    AND   plnty = 'Q'
    AND   datuv IN @s_date.
*    AND   plnnr IN @s_plnnr.

  IF sy-subrc = 0.

    SELECT plnnr,plnkn,vornr,steus,arbid,ltxa1,meinh,bmsch
      FROM plpo
      INTO TABLE @DATA(it_plpo)
      FOR ALL ENTRIES IN @it_mapl
      WHERE plnnr = @it_mapl-plnnr.

*    SELECT * FROM t006a
*      INTO TABLE @DATA(it_t006a)
*      FOR ALL ENTRIES IN @it_plpo
*      WHERE spras = 'E'
*      AND   msehi = @it_plpo-meinh
      .

    SELECT objid,arbpl
      FROM crhd
      INTO TABLE @DATA(it_crhd)
      FOR ALL ENTRIES IN @it_plpo
      WHERE objid = @it_plpo-arbid.

    SELECT plnty,plnnr,plnal,verwe,statu,losvn,losbs,ktext,delkz     "DELKZ added by raj on 26.05.2023
      FROM plko
      INTO TABLE @DATA(it_plko)
      FOR ALL ENTRIES IN @it_mapl
      WHERE plnnr = @it_mapl-plnnr
      AND   plnal = @it_mapl-plnal.


    SELECT plnty,plnnr,plnal,plnkn
      FROM plas
      INTO TABLE @DATA(it_plas)
      FOR ALL ENTRIES IN   @it_plko
      WHERE plnty = @it_plko-plnty
      AND   plnnr = @it_plko-plnnr
      AND   plnal = @it_plko-plnal.

    SELECT plnnr,plnkn,merknr,loekz,qmtb_werks,pmethode,pmtversion,qpmk_zaehl,
           verwmerkm,mkversion,kurztext, stellen, masseinhsw,sollwert,toleranzob,  "LOEKZ added by raj on 26.05.2023
           toleranzun, stichprver, katab1,katalgart1,auswmenge1,auswmgwrk1
    FROM plmk
    INTO TABLE @DATA(it_plmk)
*    FOR ALL ENTRIES IN @it_plko
    FOR ALL ENTRIES IN @it_plas
    WHERE plnnr = @it_plas-plnnr
      AND plnkn = @it_plas-plnkn.

    SELECT * FROM t006a
      INTO TABLE @DATA(it_t006a)
      FOR ALL ENTRIES IN @it_plmk
      WHERE spras = 'E'
      AND   msehi = @it_plmk-masseinhsw.

    SELECT werks,auswahlmge,codegruppe,code, katalogart
      FROM qpac
      INTO TABLE @DATA(it_qpac)
      FOR ALL ENTRIES IN @it_plmk
      WHERE werks = @it_plmk-auswmgwrk1
      AND  katalogart = @it_plmk-katalgart1
      AND   auswahlmge = @it_plmk-auswmenge1.

    SELECT codegruppe,code,kurztext
      FROM qpct
      INTO TABLE @DATA(it_qpct)
      FOR ALL ENTRIES IN @it_qpac
      WHERE codegruppe = @it_qpac-codegruppe
      AND   code = @it_qpac-code
      AND   sprache = 'E'.


  ENDIF.




  LOOP AT it_mapl ASSIGNING FIELD-SYMBOL(<fs_mapl>) .

    fs_final-matnr  = <fs_mapl>-matnr.
    fs_final-werks     = <fs_mapl>-werks.
    fs_final-plnnr     = <fs_mapl>-plnnr.
    fs_final-plnal     = <fs_mapl>-plnal.
    fs_final-datuv     = <fs_mapl>-datuv.
      fs_final-lifnr     = <fs_mapl>-lifnr."Added by Raj on 01.06.2023


    READ TABLE it_plko ASSIGNING FIELD-SYMBOL(<fs_plko>) WITH KEY plnnr = <fs_mapl>-plnnr
                                                                  plnal = <fs_mapl>-plnal.
    IF <fs_plko> IS ASSIGNED.
      fs_final-ktext = <fs_plko>-ktext.
      fs_final-verwe  = <fs_plko>-verwe.
      fs_final-delkz = <fs_plko>-delkz."Added by raj on 26.05.2023
    ENDIF.

    READ TABLE it_plpo ASSIGNING FIELD-SYMBOL(<fs_plpo>) WITH KEY plnnr = <fs_mapl>-plnnr.
    IF <fs_plpo> IS ASSIGNED.
      fs_final-vornr = <fs_plpo>-vornr.
      fs_final-arbid = <fs_plpo>-arbid.
      fs_final-steus = <fs_plpo>-steus.
      fs_final-ltxa1 = <fs_plpo>-ltxa1.
      fs_final-meinh = <fs_plpo>-meinh.
      fs_final-bmsch = <fs_plpo>-bmsch.

      READ TABLE it_crhd ASSIGNING FIELD-SYMBOL(<fs_crhd>) WITH KEY objid = <fs_plpo>-arbid.
      IF <fs_crhd> IS ASSIGNED.
        fs_final-arbpl = <fs_crhd>-arbpl.
      ENDIF.



      READ TABLE it_plas ASSIGNING FIELD-SYMBOL(<fs_plas>) WITH KEY  plnty = <fs_plko>-plnty
                                                                     plnnr = <fs_plko>-plnnr
                                                                     plnal = <fs_plko>-plnal.



*      LOOP AT it_plmk ASSIGNING FIELD-SYMBOL(<fs_plmk>) WHERE plnnr = <fs_plko>-plnnr.
      LOOP AT it_plmk ASSIGNING FIELD-SYMBOL(<fs_plmk>) WHERE plnnr = <fs_plas>-plnnr
                                                         AND  plnkn = <fs_plas>-plnkn.
        IF <fs_plmk> IS ASSIGNED.
          fs_final-merknr = <fs_plmk>-merknr.
          fs_final-kurztext = <fs_plmk>-kurztext.
          fs_final-katab1 = <fs_plmk>-katab1.
          fs_final-verwmerkm = <fs_plmk>-verwmerkm.
          fs_final-mkversion = <fs_plmk>-mkversion.
          fs_final-qmtb_werks = <fs_plmk>-qmtb_werks.
          fs_final-pmethode = <fs_plmk>-pmethode.
          fs_final-pmtversion = <fs_plmk>-pmtversion.
          fs_final-qmtb_werks = <fs_plmk>-qmtb_werks.
          fs_final-stichprver = <fs_plmk>-stichprver.
          fs_final-masseinhsw = <fs_plmk>-masseinhsw.
          fs_final-stellen = <fs_plmk>-stellen.
          fs_final-toleranzun = <fs_plmk>-toleranzun.
          fs_final-toleranzob = <fs_plmk>-toleranzob.
          fs_final-sollwert = <fs_plmk>-sollwert.
          fs_final-katalgart1 = <fs_plmk>-katalgart1.
          fs_final-auswmenge1 = <fs_plmk>-auswmenge1.
          fs_final-auswmgwrk1 = <fs_plmk>-auswmgwrk1.
          fs_final-loekz   = <fs_plmk>-loekz."Added by raj on 26.05.2023

          IF fs_final-katab1 IS INITIAL.
            fs_final-quantitat = 'X'.
          ENDIF.

           READ TABLE it_t006a ASSIGNING FIELD-SYMBOL(<fs_t006a>) WITH KEY msehi = <fs_plmk>-masseinhsw.
          IF <fs_t006a> IS ASSIGNED.
           if <fs_t006a>-msehi is not INITIAL.
            fs_final-mseh6 = <fs_t006a>-mseh6.
           endif.
         ENDIF.

*
*          READ TABLE it_qpac ASSIGNING FIELD-SYMBOL(<fs_qpac>) WITH KEY werks = <fs_plmk>-auswmgwrk1
*                                                                   katalogart = <fs_plmk>-katalgart1
*                                                                   auswahlmge = <fs_plmk>-auswmenge1.

*          LOOP AT it_qpac ASSIGNING FIELD-SYMBOL(<fs_qpac>) WHERE werks = <fs_plmk>-auswmgwrk1
*                                                                  AND       katalogart = <fs_plmk>-katalgart1
*                                                                    AND     auswahlmge = <fs_plmk>-auswmenge1..
*
*
*            IF <fs_qpac> IS ASSIGNED.
*              fs_final-codegruppe = <fs_qpac>-codegruppe.
*              fs_final-code = <fs_qpac>-code.
*
*              READ TABLE it_qpct ASSIGNING FIELD-SYMBOL(<fs_qpct>) WITH KEY codegruppe = <fs_qpac>-codegruppe
*                                                                        code = <fs_qpac>-code.
*              IF <fs_qpct> IS ASSIGNED.
*                fs_final-kurztext1 = <fs_qpct>-kurztext.
*              ENDIF.
*            ENDIF.
**
*            APPEND fs_final TO it_final.
*            UNASSIGN <fs_qpct>.
*            CLEAR :  fs_final-codegruppe,fs_final-code,fs_final-kurztext1.
*          ENDLOOP.


        ENDIF.

*        IF sy-subrc = 4.
          APPEND fs_final TO it_final.
*        ENDIF.

*        APPEND fs_final TO it_final.
*        MODIFY it_final FROM fs_final.
        CLEAR :  fs_final-quantitat,fs_final-codegruppe,fs_final-code,fs_final-kurztext1,fs_final-merknr, fs_final-kurztext, fs_final-katab1,
         fs_final-verwmerkm,fs_final-mkversion, fs_final-qmtb_werks,fs_final-pmethode, fs_final-pmtversion,  fs_final-qmtb_werks, fs_final-stichprver,
         fs_final-masseinhsw, fs_final-stellen, fs_final-toleranzun, fs_final-toleranzob,fs_final-sollwert, fs_final-katalgart1, fs_final-auswmenge1,
         fs_final-auswmgwrk1,fs_final-mseh6  .
*     UNASSIGN <fs_plmk>.
*        UNASSIGN <fs_qpac>.
*        UNASSIGN <fs_qpct>.
      ENDLOOP.
      CLEAR : fs_final.
    ENDIF.

*    READ TABLE it_plmk ASSIGNING FIELD-SYMBOL(<fs_plmk>) WITH KEY plnnr = <fs_plpo>-plnnr.






  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'MATNR'               'Material'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'WERKS'               'Plant'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PLNNR'               'Group Number'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PLNAL'               'Group Counter'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'DATUV'               'Valid Date'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KTEXT'               'Description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VERWE'               'Usage'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VORNR'               'Operation Number'                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'ARBID'               'Work Center'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'ARBPL'               'Work Center'                'X'  'IT_FINAL'   .


  PERFORM fieldcat_append  USING  'STEUS'               'Control Key'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LTXA1'               'Description'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'MEINH'               'UOM'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'BMSCH'               'Base Qty'                'X'  'IT_FINAL'   .

  PERFORM fieldcat_append  USING  'MERKNR'               'Inspection Characteristic Number'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'QUANTITAT'               'Quantitive'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KATAB1'               'Qualitive'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'VERWMERKM'               'Master Inspection Characteristics'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KURZTEXT'               'Short Text for Inspection Characteristic'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'MKVERSION'               'Version'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'QMTB_WERKS'               'Plant for Inspection Method'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PMETHODE'               'Inspection Method'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'PMTVERSION'               'Version Number '                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'STICHPRVER'               'Sampling Procedure '                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'MASSEINHSW'               'Unit of Measurementc'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'MSEH6'               'Unit of Measurementc'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'STELLEN'               'Decimal'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'TOLERANZUN'               'Lower'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'TOLERANZOB'               'Upper'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'SOLLWERT'               'Target'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'KATALGART1'               'Catalog Type'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'AUSWMENGE1'               'CCD/Set'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'AUSWMGWRK1'               'Plant'                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'CODEGRUPPE'               'Code Group'                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'CODE'               'Code'                'X'  'IT_FINAL'   .
*  PERFORM fieldcat_append  USING  'KURZTEXT1'               'Code Description'                'X'  'IT_FINAL'   .
  PERFORM fieldcat_append  USING  'LOEKZ'               'Deletion Indicator'                'X'  'IT_FINAL'   ."Added by Raj on 26.05.2023
  PERFORM fieldcat_append  USING  'DELKZ'               'Deletion flag'                'X'  'IT_FINAL'   ."Added by Raj on 26.05.2023
 PERFORM fieldcat_append  USING  'LIFNR'               'Vendor'                'X'  'IT_FINAL'   ."Added by Raj on 26.05.2023


ENDFORM.
FORM fieldcat_append USING VALUE(p_fname)
                           VALUE(p_ftext)
                           VALUE(p_fixcol)
                           VALUE(p_table).

  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.
  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page  = 'TOP_OF_PAGE'
*     i_callback_user_command = 'USER_COMMANDS'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
*     it_events          = t_event[]
      i_save             = 'A'
*     it_sort            = i_sort
    TABLES
      t_outtab           = it_final
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.
