"Name: \PR:SAPLCORU_S\IC:LCORU_SFP1\SE:END\EI
ENHANCEMENT 0 ZPP_COR6N_VALIDATION.
*SELECT SINGLE
*  * FROM tvarvc
*  INTO @DATA(ls_tvarvc)
*   WHERE name EQ 'ZCO11N_MATERIALNO'
*  AND low EQ @caufvd-matnr.
*  IF sy-subrc IS NOT INITIAL.
*    SELECT SINGLE mtart FROM mara INTO @DATA(lv_mtart) WHERE matnr EQ @caufvd_imp-matnr.
*    SELECT SINGLE * FROM tvarvc INTO ls_tvarvc WHERE name EQ 'ZWM_MATERIAL_TYPE' AND low EQ lv_mtart.
*    IF sy-subrc IS INITIAL.
*      SELECT SINGLE * FROM zwm_config INTO @DATA(lw_data) WHERE werks = @caufvd_imp-werks AND auart = @caufvd-auart.
*      IF lw_data IS NOT INITIAL.
*        SELECT SUM( su_qty )
*             FROM zwm_su
*             INTO ( lv_palqty )
*             WHERE aufnr   EQ caufvd_imp-aufnr
*               AND pprint  EQ abap_true
*               AND del_flg EQ abap_false.
*        lv_ordqty = afrud-lmnga + caufvd-gwemg.
*        IF lv_ordqty GT lv_palqty.
*          MESSAGE 'Confirmation qty should not exceed SU qty' TYPE 'E'.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.
ENDENHANCEMENT.
