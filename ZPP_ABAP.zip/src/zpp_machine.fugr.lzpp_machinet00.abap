*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_MACHINE.....................................*
DATA:  BEGIN OF STATUS_ZPP_MACHINE                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_MACHINE                   .
CONTROLS: TCTRL_ZPP_MACHINE
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZPP_MACHINE                   .
TABLES: ZPP_MACHINE                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
