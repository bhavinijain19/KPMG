*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBATCH_MAT_GRP..................................*
DATA:  BEGIN OF STATUS_ZBATCH_MAT_GRP                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBATCH_MAT_GRP                .
CONTROLS: TCTRL_ZBATCH_MAT_GRP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBATCH_MAT_GRP                .
TABLES: ZBATCH_MAT_GRP                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
