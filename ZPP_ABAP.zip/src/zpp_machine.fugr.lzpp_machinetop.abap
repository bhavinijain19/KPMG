FUNCTION-POOL ZPP_MACHINE                MESSAGE-ID SV.

* INCLUDE LZPP_MACHINED...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_MACHINET00                         . "view rel. data dcl.
