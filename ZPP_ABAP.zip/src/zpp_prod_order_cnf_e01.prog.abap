*&---------------------------------------------------------------------*
*& Include          ZPP_PROD_ORDER_CNF_E01
*&---------------------------------------------------------------------*

START-OF-SELECTION.
  PERFORM authorization.
  IF p_rad1 = 'X' OR p_rad3 = 'X'.
    PERFORM get_data.
  ELSEIF p_rad2 = 'X'.
    PERFORM f_rad2.
  ENDIF.
