*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBATCH_MONTHTOP.                  " Global Declarations
  INCLUDE LZBATCH_MONTHUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBATCH_MONTHF...                  " Subroutines
* INCLUDE LZBATCH_MONTHO...                  " PBO-Modules
* INCLUDE LZBATCH_MONTHI...                  " PAI-Modules
* INCLUDE LZBATCH_MONTHE...                  " Events
* INCLUDE LZBATCH_MONTHP...                  " Local class implement.
* INCLUDE LZBATCH_MONTHT99.                  " ABAP Unit tests
  INCLUDE LZBATCH_MONTHF00                        . " subprograms
  INCLUDE LZBATCH_MONTHI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
