*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPRT_CCTOP.                       " Global Declarations
  INCLUDE LZPRT_CCUXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPRT_CCF...                       " Subroutines
* INCLUDE LZPRT_CCO...                       " PBO-Modules
* INCLUDE LZPRT_CCI...                       " PAI-Modules
* INCLUDE LZPRT_CCE...                       " Events
* INCLUDE LZPRT_CCP...                       " Local class implement.
* INCLUDE LZPRT_CCT99.                       " ABAP Unit tests
  INCLUDE LZPRT_CCF00                             . " subprograms
  INCLUDE LZPRT_CCI00                             . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
