*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZQM_QP_INTERFACE_FGTOP.           " Global Declarations
  INCLUDE LZQM_QP_INTERFACE_FGUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZQM_QP_INTERFACE_FGF...           " Subroutines
* INCLUDE LZQM_QP_INTERFACE_FGO...           " PBO-Modules
* INCLUDE LZQM_QP_INTERFACE_FGI...           " PAI-Modules
* INCLUDE LZQM_QP_INTERFACE_FGE...           " Events
* INCLUDE LZQM_QP_INTERFACE_FGP...           " Local class implement.
* INCLUDE LZQM_QP_INTERFACE_FGT99.           " ABAP Unit tests
