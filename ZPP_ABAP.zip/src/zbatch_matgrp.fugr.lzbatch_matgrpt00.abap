*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBATCH_MATGRP...................................*
DATA:  BEGIN OF STATUS_ZBATCH_MATGRP                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBATCH_MATGRP                 .
CONTROLS: TCTRL_ZBATCH_MATGRP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBATCH_MATGRP                 .
TABLES: ZBATCH_MATGRP                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
