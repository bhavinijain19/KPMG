*&----------------------------------------------------------------------------*
*& Report  ZPM_EQUI_MASTER
*&----------------------------------------------------------------------------*
*& Title: Equipment Mater Upload
*&----------------------------------------------------------------------------*
*& Report Author         : Gaurav Dubey, KPIT Cummins Infosystems Ltd, Pune
*& Functional Consultant : Lokesh Jha, KPIT Cummins Infosystems Ltd, Pune
*& Report Creation Date  : 02/10/2014
*& Transaction Code      :
*& Request Number        : DEVK900196
*&----------------------------------------------------------------------------*
REPORT zpm_equi_master_change.
*&----------------------------------------------------------------------------*
*&    TABLES
*&----------------------------------------------------------------------------*
TABLES : equi, equz, itob,t100.
*&---------------------------------------------------------------------*
*&   Type pools declaration
*&---------------------------------------------------------------------*
TYPE-POOLS:slis.
*&----------------------------------------------------------------------------*
*&    TYPES
*&----------------------------------------------------------------------------*

TYPES : BEGIN OF ty_main,
          equip(18),          "Equipment No.
          eqtyp(1),           "Category
          shtxt(40),          "Description
          datab(10),          "Valid From
          eqart(10),          "Object Type
          begru(04),          "Autho Group
          groes(18),          "Size/dimension
          inbdt(10),          "Start up Date of Technical Object
          herst(20),          "Manufacturere
          typbz(20),          "Mfg. Model No.
          mapar(20),          "Manufacturer Part No.
          serge(20),          "Manufacturer Serial No.
          herld(3),           "Country
          baujj(4),           "Year
          swerk(4),           "Maintenance Plant
          stort(4),           "Location
          beber(3),           "Plant Section
          arbpl(8),           "PP Work Center
          abckz(3),           "ABC Indicator
          eqfnr(30),          "Sort Field
          anlnr(10),          "Assets
          kostl(10),          "Cost Center
          iwerk(4),           "Planning Plant
          ingrp(4),           "Palnner Group
          gewrk(8),           "Main.Work Center
*    WERGW(4),          "Plant Assc. with work center
          rbnr(9),           "Catalog Profile
          tplnr(30),          "Functional Location
          datum(10),          "Date
          hequi(18),          "Superior_Equip
          tidnr(25),          "Technical_Iden_No.
          submt(18),          "Const_Type
*    uzeit(8),          "Time
          gwldt_i(10),          "Begin guarantee
          gwlen_i(10) ,         "Warranty End Date
          planv(3) ,          "Taks List Usages
          steuf(4),           "Control Key
          ewform(6),           "Usages Formula
          warpl(12),          "Maintenance Plan
          imrc_point(12),         "Measuring Points

        END OF ty_main.
*&----------------------------------------------------------------------------*
*&    INTERNAL TABLES
*&----------------------------------------------------------------------------*
DATA : set_layout  TYPE slis_layout_alv,
       gt_fieldcat TYPE slis_t_fieldcat_alv,
       wa_fieldcat TYPE slis_fieldcat_alv.
DATA : equipment TYPE bapi_itob_parms-equipment.
*       gt_conv TYPE STANDARD TABLE OF ty_conv,
DATA : gt_main TYPE STANDARD TABLE OF ty_main,
       wa_main TYPE ty_main,
       wa_itob TYPE itob.
CONSTANTS : gc_zie01 TYPE sy-tcode VALUE 'ZIE01',
            gc_zie02 TYPE sy-tcode VALUE 'ZIE02'.
DATA : bdcdata LIKE bdcdata OCCURS 0 WITH HEADER LINE.
DATA  : messtab LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.
DATA: l_mstring(480).


DATA: gv_inst_date TYPE bapi_itob_parms-inst_date.

DATA : sindex TYPE sy-tabix.
DATA: idx      TYPE char4.
*&-----------------------------------------------------*
*&  BAPI Data Declaration     BAPI_EQUI_GETLIST   BAPI_EQUI_GETDETAIL   BAPI_EQUI_CREATE
*&-----------------------------------------------------*
DATA: wa_value_equipment       TYPE bapi_itob_parms,
      wa_data_general_exp      TYPE bapi_itob,
*      wa_data_general_exp1 TYPE bapi_itob,
      wa_data_general_exp_copy TYPE bapi_itob,
      wa_data_specific_exp     TYPE bapi_itob_eq_only,
      wa_data_install          TYPE  bapi_itob_eq_install.
*      wa_data_specific_exp1 TYPE bapi_itob_eq_only.
DATA : value_data_general  LIKE  bapi_itob OCCURS 0,
       value_data_specific LIKE  bapi_itob_eq_only OCCURS 0.
DATA : wa_value_data_general  TYPE bapi_itob,
       wa_value_data_specific TYPE bapi_itob_eq_only.
DATA : return        TYPE bapiret2,
       t_return      TYPE bapiret2,
       t_return_temp TYPE STANDARD TABLE OF bapiret2,
       it_type       TYPE truxs_t_text_data.
DATA : e_group_opened,
       file_path TYPE string.

DATA : zfunval TYPE bapi_itob_eq_only-read_floc.


*&----------------------------------------------------------------------------*
*&    SELECTION SCREEN
*&----------------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS : mod LIKE ctu_params-dismode DEFAULT 'A'.
PARAMETERS : file_url LIKE rlgrap-filename OBLIGATORY. " Output File
SELECTION-SCREEN END OF BLOCK b1.

*&----------------------------------------------------------------------------*
*&    AT SELECTION-SCREEN
*&----------------------------------------------------------------------------*

AT SELECTION-SCREEN ON VALUE-REQUEST FOR file_url.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name  = syst-cprog
      dynpro_number = syst-dynnr
      field_name    = 'FILE_URL'
    IMPORTING
      file_name     = file_url.

*&----------------------------------------------------------------------------*
*&    START-OF-SELECTION.
*&----------------------------------------------------------------------------*

START-OF-SELECTION.

  IF NOT file_url IS INITIAL.
    MOVE  file_url TO file_path.
    PERFORM read_file.
  ENDIF.

  IF gt_main[] IS NOT INITIAL.
*    PERFORM f_bapi_equi_upload.
    PERFORM f_bdc_upload.
***    perform write_mesage.
  ELSE.
    MESSAGE 'FILE IS EMPTY!!!!  '  TYPE 'E'.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  READ_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM read_file .
  DATA: p_file TYPE rlgrap-filename.
  p_file = file_path.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = gt_main
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
  DELETE gt_main INDEX 1.
ENDFORM.                    " READ_FILE
*&---------------------------------------------------------------------*
*&      Form  F_BAPI_EQUI_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_bapi_equi_upload .
  break sap_abap.
  LOOP AT gt_main INTO wa_main.
    CLEAR return.
    sindex = sy-tabix.
    idx = sindex.
*   PERFORM f_bapi.
    PERFORM f_maintain_single.
    CLEAR wa_main.
  ENDLOOP.

ENDFORM.                    " F_BAPI_EQUI_UPLOAD
*&---------------------------------------------------------------------*
*&      Form  F_BAPI
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_bapi .
*** Data General
  wa_data_general_exp-objecttype = wa_main-eqart.
  wa_data_general_exp-start_from = wa_main-datab.
  wa_data_general_exp-manfacture = wa_main-herst.
  wa_data_general_exp-manmodel   = wa_main-typbz.
  wa_data_general_exp-manparno   = wa_main-mapar.
  wa_data_general_exp-manserno   = wa_main-serge.
  wa_data_general_exp-planplant  = wa_main-iwerk.
  wa_data_general_exp-constyear  = wa_main-baujj.
  wa_data_general_exp-maintplant = wa_main-swerk.
  wa_data_general_exp-maintloc   = wa_main-stort.
  wa_data_general_exp-plsectn    = wa_main-beber.
  wa_data_general_exp-abcindic   = wa_main-abckz.
  wa_data_general_exp-sortfield  = wa_main-eqfnr.
  wa_data_general_exp-costcenter = wa_main-kostl.
  wa_data_general_exp-plangroup  = wa_main-ingrp.
  wa_data_general_exp-descript   = wa_main-shtxt.
  wa_data_general_exp-work_ctr   = wa_main-gewrk.
  wa_data_general_exp-asset_no   = wa_main-anlnr.

*** Data Specific
  wa_data_specific_exp-read_floc       = wa_main-tplnr.
  wa_data_specific_exp-equicatgry      = wa_main-eqtyp.
  wa_data_specific_exp-read_valid_from = wa_main-datab.

  gv_inst_date = wa_main-inbdt.

*** Installation data
  wa_data_install-funcloc = wa_main-tplnr.
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
  CALL FUNCTION 'BAPI_EQUI_CREATE'"#EC CI_USAGE_OK[2438131]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
    EXPORTING
*     EXTERNAL_NUMBER   =
      data_general      = wa_data_general_exp
      data_specific     = wa_data_specific_exp
      valid_date        = gv_inst_date
      data_install      = wa_data_install
    IMPORTING
      equipment         = equipment
      data_general_exp  = wa_value_data_general
      data_specific_exp = wa_value_data_specific
      return            = return.
  t_return = return.
  IF return IS NOT INITIAL AND (
    return-type EQ 'E' OR
    return-type EQ 'A' OR
    return-type EQ 'X' ).

  ELSE.
    CLEAR return.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'
      IMPORTING
        return = return.
  ENDIF.
  WRITE:/ return-message.


ENDFORM.                    " F_BAPI
*&---------------------------------------------------------------------*
*&      Form  F_MAINTAIN_SINGLE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_maintain_single .

  wa_itob-eqart = wa_main-eqart.
  PERFORM f_convert_date_internal USING wa_main-datab CHANGING wa_itob-datab.
  PERFORM f_convert_date_internal USING wa_main-inbdt CHANGING wa_itob-inbdt.

  wa_itob-herst = wa_main-herst.
  wa_itob-typbz = wa_main-typbz.
  wa_itob-mapar = wa_main-mapar.
  wa_itob-serge = wa_main-serge.
  wa_itob-iwerk = wa_main-iwerk.
  wa_itob-baujj = wa_main-baujj.
  wa_itob-swerk = wa_main-swerk.
  wa_itob-stort = wa_main-stort.
  wa_itob-beber = wa_main-beber.
  wa_itob-abckz = wa_main-abckz.
  wa_itob-eqfnr = wa_main-eqfnr.
  wa_itob-kostl = wa_main-kostl.
  wa_itob-ingrp = wa_main-ingrp.
  wa_itob-shtxt = wa_main-shtxt.
  wa_itob-wkctr = wa_main-gewrk.
  wa_itob-ppsid = wa_main-arbpl.
  wa_itob-ppsidi = 'D'.
  wa_itob-anlnr  = wa_main-anlnr.
  wa_itob-anlnri = 'D'.

  wa_itob-tplnr = wa_main-tplnr.

  wa_itob-eqtyp = wa_main-eqtyp.
  PERFORM f_convert_date_internal USING wa_main-gwldt_i CHANGING wa_itob-gwldt.
  PERFORM f_convert_date_internal USING wa_main-gwlen_i CHANGING wa_itob-gwlen.

*wa_itob-gwldt = wa_main-gwldt_i.
*wa_itob-gwlen = wa_main-gwlen_i.

  CALL FUNCTION 'ITOB_EQUIPMENT_CREATE_SINGLE'
    EXPORTING
*     I_HANDLE       =
      i_auth_tcode   = 'IE01'
*     I_FILTER_DATA  = 'X'
*     I_WRITE_BUFFER = 'X'
*     I_POST_BUFFER  = 'X'
      i_commit_work  = 'S'
      i_object_rec   = wa_itob
      i_valid_date   = wa_itob-datab
*     I_INSTALL_REC  =
    IMPORTING
      e_object_rec   = wa_itob
    EXCEPTIONS
      not_successful = 1
      OTHERS         = 2.
  IF sy-subrc <> 0.
    CONCATENATE 'Equipment not created of Line no' idx INTO return-message SEPARATED BY space.
  ELSE.
    CONCATENATE 'Equipment no' wa_itob-equnr 'created' INTO return-message SEPARATED BY space.
  ENDIF.
  WRITE:/ return-message.
  CLEAR wa_itob.
ENDFORM.                    " F_MAINTAIN_SINGLE
*&---------------------------------------------------------------------*
*&      Form  F_CONVERT_DATE_INTERNAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_WA_MAIN_DATAB  text
*      <--P_WA_ITOB_DATAB  text
*----------------------------------------------------------------------*
FORM f_convert_date_internal  USING    p_ext
                              CHANGING p_int.
  DATA: lv_date_i TYPE string,
        lv_date_e TYPE string.

  lv_date_e = p_ext.

  CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
    EXPORTING
      date_external       = lv_date_e
      accept_initial_date = 'X'
    IMPORTING
      date_internal       = lv_date_i
* EXCEPTIONS
*     DATE_EXTERNAL_IS_INVALID       = 1
*     OTHERS              = 2
    .
  IF sy-subrc = 0.
    p_int = lv_date_i.
  ENDIF.


ENDFORM.                    " F_CONVERT_DATE_INTERNAL
*&---------------------------------------------------------------------*
*&      Form  F_BDC_UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_bdc_upload .
*  LOOP AT gt_main INTO wa_main.
*
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0100'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'RM63E-EQTYP'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '/00'.
*    PERFORM bdc_field       USING 'RM63E-DATSL'
*                                  wa_main-datab.
*    PERFORM bdc_field       USING 'RM63E-EQTYP'
*                                  wa_main-eqtyp.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=T\02'.
*    PERFORM bdc_field       USING 'ITOB-EQART'
*                                  wa_main-eqart.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-SERGE'.
*    PERFORM bdc_field       USING 'ITOB-HERST'
*                                  wa_main-herst.
*    PERFORM bdc_field       USING 'ITOB-SERGE'
*                                  wa_main-serge.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '/00'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-EQFNR'.
*    PERFORM bdc_field       USING 'ITOB-SWERK'
*                                  wa_main-swerk.
*    PERFORM bdc_field       USING 'ITOB-STORT'
*                                  wa_main-stort.
*    PERFORM bdc_field       USING 'ITOB-BEBER'
*                                  wa_main-beber.
*    PERFORM bdc_field       USING 'ITOBATTR-ARBPL'
*                                  wa_main-arbpl.
*    PERFORM bdc_field       USING 'ITOB-ABCKZ'
*                                  wa_main-abckz.
*    PERFORM bdc_field       USING 'ITOB-EQFNR'
*                                  wa_main-eqfnr.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=T\03'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-EQFNR'.
*    PERFORM bdc_field       USING 'ITOB-SWERK'
*                                  wa_main-swerk.
*    PERFORM bdc_field       USING 'ITOB-STORT'
*                                  wa_main-stort.
*    PERFORM bdc_field       USING 'ITOB-BEBER'
*                                  wa_main-beber.
*    PERFORM bdc_field       USING 'ITOBATTR-ARBPL'
*                                  wa_main-arbpl.
*    PERFORM bdc_field       USING 'ITOB-ABCKZ'
*                                  wa_main-abckz.
*    PERFORM bdc_field       USING 'ITOB-EQFNR'
*                                  wa_main-eqfnr.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  'PICK'.
*    PERFORM bdc_field       USING 'ITOB-BUKRS'
*                                  wa_main-bukrs.
*    PERFORM bdc_field       USING 'ITOB-ANLNR'
*                                  wa_main-anlnr.
*    PERFORM bdc_field       USING 'ITOB-KOSTL'
*                                  wa_main-kostl.
*    PERFORM bdc_field       USING 'ITOB-IWERK'
*                                  wa_main-iwerk.
*    PERFORM bdc_field       USING 'ITOB-INGRP'
*                                  wa_main-ingrp.
*    PERFORM bdc_field       USING 'ITOBATTR-GEWRK'
*                                  wa_main-gewrk.
*    PERFORM bdc_field       USING 'ITOB-RBNR'
*                                  wa_main-rbnr.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=T\04'.
*    PERFORM bdc_field       USING 'ITOB-BUKRS'
*                                  wa_main-bukrs.
*    PERFORM bdc_field       USING 'ITOB-KOSTL'
*                                  wa_main-kostl.
*    PERFORM bdc_field       USING 'ITOB-IWERK'
*                                  wa_main-iwerk.
*    PERFORM bdc_field       USING 'ITOB-INGRP'
*                                  wa_main-ingrp.
*    PERFORM bdc_field       USING 'ITOBATTR-GEWRK'
*                                  wa_main-gewrk.
*    PERFORM bdc_field       USING 'ITOBATTR-WERGW'
*                                  wa_main-wergw.
*    PERFORM bdc_field       USING 'ITOB-RBNR'
*                                  wa_main-rbnr.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-SHTXT'.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=CIPL'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-SHTXT'.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPLIEL2' '0100'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'IEQINSTALL-TPLNR'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=EXIT'.
*    PERFORM bdc_field       USING 'IEQINSTALL-TPLNR'
*                                  wa_main-tplnr.
*    PERFORM bdc_field       USING 'IEQINSTALL-DATUM'
*                                  wa_main-datum.
*    PERFORM bdc_field       USING 'IEQINSTALL-UZEIT'
*                                  wa_main-uzeit.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '/00'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-SHTXT'.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
*    PERFORM bdc_field       USING 'BDC_OKCODE'
*                                  '=BU'.
*    PERFORM bdc_field       USING 'BDC_CURSOR'
*                                  'ITOB-SHTXT'.
*    PERFORM bdc_field       USING 'ITOB-SHTXT'
*                                  wa_main-shtxt.
*    PERFORM bdc_field       USING 'ITOB-DATAB'
*                                  wa_main-datab.
*  ENDLOOP.
  PERFORM f_new_bdc.

ENDFORM.                    " F_BDC_UPLOAD
*&---------------------------------------------------------------------*
*&      Form  F_NEW_BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f_new_bdc .
  LOOP AT gt_main INTO wa_main.
    CLEAR bdcdata.
    REFRESH bdcdata[].
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'RM63E-EQUNR'.
      PERFORM bdc_field       USING 'RM63E-EQUNR'
                                    wa_main-equip.

    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
**    IF wa_main-eqtyp EQ 'P'.
**
**    ENDIF.
**    PERFORM bdc_field       USING 'RM63E-DATSL'
**                                  wa_main-datab.
**    PERFORM bdc_field       USING 'RM63E-EQTYP'
**                                  wa_main-eqtyp.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'ITOB-BEGRU'
                                  wa_main-begru.
    PERFORM bdc_field       USING 'ITOB-GROES'
                                  wa_main-groes.
    PERFORM bdc_field       USING 'ITOB-INBDT'
                                  wa_main-inbdt.
    PERFORM bdc_field       USING 'ITOB-EQART'
                                  wa_main-eqart.
    PERFORM bdc_field       USING 'ITOB-HERST'
                                  wa_main-herst.
    PERFORM bdc_field       USING 'ITOB-HERLD'
                                  wa_main-herld.
    PERFORM bdc_field       USING 'ITOB-TYPBZ'
                                  wa_main-typbz.
    PERFORM bdc_field       USING 'ITOB-BAUJJ'
                                  wa_main-baujj.
    PERFORM bdc_field       USING 'ITOB-MAPAR'
                                  wa_main-mapar.
    PERFORM bdc_field       USING 'ITOB-SERGE'
                                  wa_main-serge.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=T\02'.
    PERFORM bdc_field       USING 'ITOB-BEGRU'
                                  wa_main-begru.
    PERFORM bdc_field       USING 'ITOB-GROES'
                                  wa_main-groes.
    PERFORM bdc_field       USING 'ITOB-INBDT'
                                  wa_main-inbdt.
    PERFORM bdc_field       USING 'ITOB-EQART'
                                  wa_main-eqart.
    PERFORM bdc_field       USING 'ITOB-HERST'
                                  wa_main-herst.
    PERFORM bdc_field       USING 'ITOB-HERLD'
                                  wa_main-herld.
    PERFORM bdc_field       USING 'ITOB-TYPBZ'
                                  wa_main-typbz.
    PERFORM bdc_field       USING 'ITOB-BAUJJ'
                                  wa_main-baujj.
    PERFORM bdc_field       USING 'ITOB-MAPAR'
                                  wa_main-mapar.
    PERFORM bdc_field       USING 'ITOB-SERGE'
                                  wa_main-serge.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-SHTXT'.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-EQFNR'.
    PERFORM bdc_field       USING 'ITOB-SWERK'
                                  wa_main-swerk.
    PERFORM bdc_field       USING 'ITOB-STORT'
                                  wa_main-stort.
    PERFORM bdc_field       USING 'ITOB-BEBER'
                                  wa_main-beber.
    PERFORM bdc_field       USING 'ITOBATTR-ARBPL'
                                  wa_main-arbpl.
    PERFORM bdc_field       USING 'ITOB-ABCKZ'
                                  wa_main-abckz.
    PERFORM bdc_field       USING 'ITOB-EQFNR'
                                  wa_main-eqfnr.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-EQFNR'.
    PERFORM bdc_field       USING 'ITOB-SWERK'
                                  wa_main-swerk.
    PERFORM bdc_field       USING 'ITOB-STORT'
                                  wa_main-stort.
    PERFORM bdc_field       USING 'ITOB-BEBER'
                                  wa_main-beber.
    PERFORM bdc_field       USING 'ITOBATTR-ARBPL'
                                  wa_main-arbpl.
    PERFORM bdc_field       USING 'ITOB-ABCKZ'
                                  wa_main-abckz.
    PERFORM bdc_field       USING 'ITOB-EQFNR'
                                  wa_main-eqfnr.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=T\03'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-EQFNR'.
    PERFORM bdc_field       USING 'ITOB-SWERK'
                                  wa_main-swerk.
    PERFORM bdc_field       USING 'ITOB-STORT'
                                  wa_main-stort.
    PERFORM bdc_field       USING 'ITOB-BEBER'
                                  wa_main-beber.
    PERFORM bdc_field       USING 'ITOBATTR-ARBPL'
                                  wa_main-arbpl.
    PERFORM bdc_field       USING 'ITOB-ABCKZ'
                                  wa_main-abckz.
    PERFORM bdc_field       USING 'ITOB-EQFNR'
                                  wa_main-eqfnr.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
*PERFORM bdc_field       USING 'ITOB-BUKRS'
*                              wa_main-bukrs.
    PERFORM bdc_field       USING 'ITOB-ANLNR'
                                  wa_main-anlnr.
    PERFORM bdc_field       USING 'ITOB-KOSTL'
                                  wa_main-kostl.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-RBNR'.
    PERFORM bdc_field       USING 'ITOB-IWERK'
                                  wa_main-iwerk.
    PERFORM bdc_field       USING 'ITOB-INGRP'
                                  wa_main-ingrp.
    PERFORM bdc_field       USING 'ITOBATTR-GEWRK'
                                  wa_main-gewrk.
    PERFORM bdc_field       USING 'ITOB-RBNR'
                                  wa_main-rbnr.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=T\04'.
*PERFORM bdc_field       USING 'ITOB-BUKRS'
*                              wa_main-bukrs.
    PERFORM bdc_field       USING 'ITOB-ANLNR'
                                  wa_main-anlnr.
    PERFORM bdc_field       USING 'ITOB-KOSTL'
                                  wa_main-kostl.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-RBNR'.
    PERFORM bdc_field       USING 'ITOB-IWERK'
                                  wa_main-iwerk.
    PERFORM bdc_field       USING 'ITOB-INGRP'
                                  wa_main-ingrp.
    PERFORM bdc_field       USING 'ITOBATTR-GEWRK'
                                  wa_main-gewrk.
*PERFORM bdc_field       USING 'ITOBATTR-WERGW'
*                              wa_main-wergw.
    PERFORM bdc_field       USING 'ITOB-RBNR'
                                  wa_main-rbnr.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=CIPL'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-SHTXT'.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPLIEL2' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'IEQINSTALL-DATUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    IF wa_main-tplnr IS NOT INITIAL.
      PERFORM bdc_field       USING 'IEQINSTALL-TPLNR'
                                    wa_main-tplnr.
    ELSEIF wa_main-hequi IS NOT INITIAL.
      PERFORM bdc_field       USING 'IEQINSTALL-HEQNR'
                                    wa_main-hequi.

    ENDIF.
    PERFORM bdc_field       USING 'IEQINSTALL-DATUM'
                                  wa_main-datum.
    PERFORM bdc_field       USING 'IEQINSTALL-UZEIT'
                                  sy-uzeit.
    PERFORM bdc_dynpro      USING 'SAPLIEL2' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'IEQINSTALL-DATUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'IEQINSTALL-DATUM'
                                  wa_main-datum.
    PERFORM bdc_field       USING 'IEQINSTALL-UZEIT'
                                  sy-uzeit.
    PERFORM bdc_dynpro      USING 'SAPLIEL2' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'IEQINSTALL-DATUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'IEQINSTALL-DATUM'
                                  wa_main-datum.
    PERFORM bdc_field       USING 'IEQINSTALL-UZEIT'
                                  sy-uzeit.
    PERFORM bdc_dynpro      USING 'SAPLIEL2' '0100'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'IEQINSTALL-DATUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=EXIT'.
    PERFORM bdc_field       USING 'IEQINSTALL-DATUM'
                                  wa_main-datum.
    PERFORM bdc_field       USING 'IEQINSTALL-UZEIT'
                                  sy-uzeit.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=T\05'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-SHTXT'.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'WCHECK_V_H-GWLEN_I'.
    PERFORM bdc_field       USING 'WCHECK_V_H-GWLDT_I'
                                  wa_main-gwldt_i.
    PERFORM bdc_field       USING 'WCHECK_V_H-GWLEN_I'
                                  wa_main-gwlen_i.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.
*** For P type Equipment
    IF wa_main-eqtyp EQ 'P'.
      PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '=T\06'.
      PERFORM bdc_field       USING 'BDC_CURSOR'
                                    'ITOB-SHTXT'.
      PERFORM bdc_field       USING 'ITOB-SHTXT'
                                    wa_main-shtxt.
      PERFORM bdc_field       USING 'ITOB-DATAB'
                                    wa_main-datab.
      PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
      PERFORM bdc_field       USING 'BDC_OKCODE'
                                    '/00'.
      PERFORM bdc_field       USING 'EFHM-PLANV'
                                    wa_main-planv.
      PERFORM bdc_field       USING 'EFHM-STEUF'
                                    wa_main-steuf.
      PERFORM bdc_field       USING 'EFHM-EWFORM'
                                    wa_main-ewform.
      PERFORM bdc_field       USING 'EQUI-WARPL'
                                    wa_main-warpl.
      PERFORM bdc_field       USING 'EQUI-IMRC_POINT'
                                    wa_main-imrc_point.

    ENDIF.
*** end.
    PERFORM bdc_dynpro      USING 'SAPMIEQ0' '0101'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
*PERFORM bdc_field       USING 'WCHECK_V_H-GWLDT_I'
*                              wa_main-gwldt_i.
*PERFORM bdc_field       USING 'WCHECK_V_H-GWLEN_I'
*                              wa_main-gwlen_i.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'ITOB-SHTXT'.
    PERFORM bdc_field       USING 'ITOB-SHTXT'
                                  wa_main-shtxt.
    PERFORM bdc_field       USING 'ITOB-DATAB'
                                  wa_main-datab.

    CALL TRANSACTION 'IE02' USING bdcdata MODE mod
                                MESSAGES INTO messtab.
  ENDLOOP.


  LOOP AT messtab.

    SELECT SINGLE * FROM t100 WHERE sprsl = messtab-msgspra
                              AND   arbgb = messtab-msgid
                              AND   msgnr = messtab-msgnr.
    IF sy-subrc = 0.
      l_mstring = t100-text.
      IF l_mstring CS '&1'.
        REPLACE '&1' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&2' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&3' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&4' WITH messtab-msgv4 INTO l_mstring.
      ELSE.
        REPLACE '&' WITH messtab-msgv1 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv2 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv3 INTO l_mstring.
        REPLACE '&' WITH messtab-msgv4 INTO l_mstring.
      ENDIF.
      CONDENSE l_mstring.
      WRITE: / messtab-msgtyp, l_mstring(250).
    ELSE.
      WRITE: / messtab.
    ENDIF.
  ENDLOOP.
ENDFORM.                    " F_NEW_BDC

*&---------------------------------------------------------------------*
*&      Form  BDC_DYNPRO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PROGRAM    text
*      -->DYNPRO     text
*----------------------------------------------------------------------*

FORM bdc_dynpro USING program dynpro.
  CLEAR bdcdata.
  bdcdata-program  = program.
  bdcdata-dynpro   = dynpro.
  bdcdata-dynbegin = 'X'.
  APPEND bdcdata.
ENDFORM. "BDC_DYNPRO

*&---------------------------------------------------------------------*
*&      Form  BDC_FIELD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->FNAM       text
*      -->FVAL       text
*----------------------------------------------------------------------*

FORM bdc_field USING fnam fval.
  IF fval <> ''.
    CLEAR bdcdata.
    bdcdata-fnam = fnam.
    bdcdata-fval = fval.
    APPEND bdcdata.
  ENDIF.
ENDFORM. "BDC_FIELD
