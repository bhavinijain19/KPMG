*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_OPTIVA_MAIL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_OPTIVA_MAIL     .

  PERFORM TABLEPROC.

ENDFUNCTION.
