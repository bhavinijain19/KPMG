*&---------------------------------------------------------------------*
*& Report  ZPP_ROUTING_CHANGE_LOG
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zpp_bom_change_log.
TABLES: mast.
TYPES : BEGIN OF ty_mast,
          mandt TYPE mast-mandt,
          matnr TYPE mast-matnr,
          werks TYPE mast-werks,
          stlnr TYPE mast-stlnr,
          key   TYPE cdhdr-objectid,
        END OF ty_mast.
DATA: it_mast TYPE STANDARD TABLE OF ty_mast,
      wa_mast TYPE ty_mast.

TYPES: BEGIN OF ty_makt,
         matnr TYPE makt-matnr,
         maktx TYPE makt-maktx,
       END OF ty_makt.
DATA: it_makt TYPE STANDARD TABLE OF ty_makt,
      wa_makt TYPE ty_makt.

TYPES: BEGIN OF ty_makt1,
         matnr TYPE makt-matnr,
         maktx TYPE makt-maktx,
       END OF ty_makt1.
DATA: it_makt1 TYPE STANDARD TABLE OF ty_makt1,
      wa_makt1 TYPE ty_makt1.

TYPES : BEGIN OF ty_stpo,
          mandt TYPE stpo-mandt,
          stlty TYPE stpo-stlty,
          stlnr TYPE stpo-stlnr,
          stlkn TYPE stpo-stlkn,
          stpoz TYPE stpo-stpoz,
          idnrk TYPE stpo-idnrk,
          key   TYPE cdred-tabkey,
        END OF ty_stpo.
DATA: it_stpo TYPE STANDARD TABLE OF ty_stpo,
      wa_stpo TYPE ty_stpo.

DATA: fdate TYPE cdhdr-udate.
DATA: tdate TYPE cdhdr-udate.
DATA: it_cdhdr TYPE STANDARD TABLE OF cdhdr,
      wa_cdhdr TYPE cdhdr.

DATA : it_cdpos TYPE STANDARD TABLE OF cdred,
       wa_cdpos TYPE cdred.
DATA: it_stas TYPE STANDARD TABLE OF stas,
      wa_stas TYPE stas.

DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
       fs_layout      TYPE slis_layout_alv,
       t_event        TYPE slis_t_event WITH HEADER LINE.


TYPES: BEGIN OF ty_cdpos,
         matnr     TYPE mast-matnr,
         werks     TYPE mast-werks,
         username  TYPE cdred-username,
         udate     TYPE cdred-udate,
         utime     TYPE cdred-utime,
         tcode     TYPE cdred-tcode,
         ftext     TYPE cdred-ftext,
         f_old     TYPE cdred-f_old,
         f_new     TYPE cdred-f_new,
         chngind   TYPE cdred-chngind,
         idnrk     TYPE stpo-idnrk,
         idnrkdesc TYPE makt-maktx,
         mdesc     TYPE makt-maktx,
         stlal     TYPE stas-stlal,
       END OF ty_cdpos.
DATA: it_final_cdpos TYPE STANDARD TABLE OF ty_cdpos,
      wa_final_cdpos TYPE ty_cdpos.

SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-002.
PARAMETERS     : s_werks TYPE mast-werks OBLIGATORY.
SELECT-OPTIONS : s_matnr FOR mast-matnr,
                 s_dt FOR sy-datum OBLIGATORY.
SELECTION-SCREEN : END OF BLOCK a1.

START-OF-SELECTION.
  PERFORM authorization_check.
  PERFORM get_data.
  PERFORM fill_fieldcatalog.
  PERFORM display_grid.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  SELECT mandt matnr werks stlnr
    FROM mast INTO TABLE it_mast
    WHERE matnr IN s_matnr AND
          werks = s_werks.

  SELECT matnr maktx
    FROM makt INTO TABLE it_makt
    FOR ALL ENTRIES IN it_mast
    WHERE matnr = it_mast-matnr.

  IF it_mast IS INITIAL.
    MESSAGE 'Material does not exit' TYPE 'E'.
  ENDIF.

  SELECT mandt stlty stlnr stlkn stpoz idnrk
     FROM stpo INTO TABLE it_stpo
     FOR ALL ENTRIES IN it_mast
     WHERE stlnr = it_mast-stlnr.

  SELECT matnr maktx
    FROM makt INTO TABLE it_makt1
    FOR ALL ENTRIES IN it_stpo
    WHERE matnr = it_stpo-idnrk.

  SELECT *
    FROM stas INTO TABLE it_stas
    FOR ALL ENTRIES IN it_stpo
    WHERE stlnr = it_stpo-stlnr.


  LOOP AT it_mast INTO wa_mast.
    CONCATENATE wa_mast-mandt 'M' wa_mast-stlnr INTO wa_mast-key.

    MODIFY it_mast FROM wa_mast TRANSPORTING key.
  ENDLOOP.

  LOOP AT it_stpo INTO wa_stpo.
    CONCATENATE wa_stpo-mandt wa_stpo-stlty wa_stpo-stlnr wa_stpo-stlkn wa_stpo-stpoz INTO wa_stpo-key.
    MODIFY it_stpo FROM wa_stpo TRANSPORTING key.
  ENDLOOP.

  fdate = s_dt-low.
  tdate = s_dt-high.

" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
SORT IT_MAST BY STLNR.
" ATC Correction for S4 HANA **END OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
  DELETE ADJACENT DUPLICATES FROM it_mast COMPARING stlnr.

  LOOP AT it_mast INTO wa_mast.

    CALL FUNCTION 'CHANGEDOCUMENT_READ_HEADERS'
      EXPORTING
*       ARCHIVE_HANDLE             = 0
        date_of_change             = fdate
        objectclass                = 'STUE'
        objectid                   = wa_mast-key
*       TIME_OF_CHANGE             = '000000'
        username                   = '*'
*       LOCAL_TIME                 = ' '
*       TIME_ZONE                  = 'UTC'
        date_until                 = tdate
*       TIME_UNTIL                 = '235959'
*       NOPLUS_ASWILDCARD_INOBJID  = ' '
*       READ_CHANGEDOCU            = ' '
*       I_HOT                      = ' '
      TABLES
        i_cdhdr                    = it_cdhdr
      EXCEPTIONS
        no_position_found          = 1
        wrong_access_to_archive    = 2
        time_zone_conversion_error = 3
        OTHERS                     = 4.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.


    LOOP AT it_cdhdr INTO wa_cdhdr.

      CALL FUNCTION 'CHANGEDOCUMENT_READ_POSITIONS'
        EXPORTING
          archive_handle          = '0'
          changenumber            = wa_cdhdr-changenr
*         TABLEKEY                = ' '
*         TABLENAME               = ' '
*         TABLEKEY254             = ' '
*         KEYGUID                 = ' '
*         KEYGUID_STR             = ' '
*         I_PREP_UNIT             = 'X'
*         I_HOT                   = ' '
*     IMPORTING
*         HEADER                  =
*         ET_CDRED_STR            =
        TABLES
*         EDITPOS                 =
          editpos_with_header     = it_cdpos
        EXCEPTIONS
          no_position_found       = 1
          wrong_access_to_archive = 2
          OTHERS                  = 3.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      LOOP AT it_cdpos INTO wa_cdpos.

        IF  wa_cdpos-chngind = 'I' AND wa_cdpos-tcode = 'CS01'  .

        ELSE.

          wa_final_cdpos-matnr = wa_mast-matnr.
          READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_mast-matnr.
          IF sy-subrc = 0.
            wa_final_cdpos-mdesc = wa_makt-maktx.
          ENDIF.
          wa_final_cdpos-werks = wa_mast-werks.
          wa_final_cdpos-username = wa_cdpos-username.
          wa_final_cdpos-udate = wa_cdpos-udate.
          wa_final_cdpos-utime = wa_cdpos-utime.
          wa_final_cdpos-tcode = wa_cdpos-tcode.
          wa_final_cdpos-ftext = wa_cdpos-ftext.
          wa_final_cdpos-f_old = wa_cdpos-f_old.
          wa_final_cdpos-f_new = wa_cdpos-f_new.
          wa_final_cdpos-chngind = wa_cdpos-chngind.
          clear:wa_Stpo.
          READ TABLE it_stpo INTO wa_stpo WITH KEY key = wa_cdpos-tabkey.
          IF sy-subrc = 0.
            wa_final_cdpos-idnrk = wa_stpo-idnrk.
          ENDIF.
           if  wa_cdpos-chngind <> 'D'.
          READ TABLE it_makt1 INTO wa_makt1 WITH KEY matnr = wa_stpo-idnrk.
          IF sy-subrc = 0.
            wa_final_cdpos-idnrkdesc = wa_makt1-maktx.
          ENDIF.
           ENDIF.
          if  wa_cdpos-chngind <> 'D'.
          READ TABLE it_stas INTO wa_stas WITH KEY stlnr = wa_stpo-stlnr stlkn = wa_stpo-stlkn .
          IF sy-subrc = 0.
            wa_final_cdpos-stlal = wa_stas-stlal.
          ENDIF.
          ENDIF.
          APPEND wa_final_cdpos TO it_final_cdpos.
          CLEAR: wa_final_cdpos,wa_cdpos,wa_stpo,wa_makt,wa_makt1,wa_stas.
        ENDIF.
        CLEAR: wa_final_cdpos,wa_cdpos,wa_stpo,wa_makt,wa_makt1.
      ENDLOOP.
      CLEAR: wa_cdhdr.
    ENDLOOP.

    CLEAR: wa_mast.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_FIELDCATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_fieldcatalog .
  PERFORM fieldcat_append  USING  'MATNR'               'Material Number'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'STLAL'               'Alternative BOM'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'MDESC'               'Material Discription'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'WERKS'               'Plant'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'USERNAME'            'User name '                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'UDATE'               'Changed Date'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'UTIME'               'Changed Time'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'FTEXT'               'Explanatory short text'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'F_OLD'               'Old contents of changed field'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'F_NEW'               'New contents of changed field'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'CHNGIND'              'Change Type'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'IDNRK'                'BOM component'                'X'  'IT_FINAL_CDPOS'   .
  PERFORM fieldcat_append  USING  'IDNRKDESC'             'BOM component Discription'                'X'  'IT_FINAL_CDPOS'   .


ENDFORM.
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table).
  t_fieldcatalog-fieldname   = p_fname.
  t_fieldcatalog-seltext_l   = p_ftext.
  t_fieldcatalog-fix_column  = p_fixcol.
  t_fieldcatalog-tabname     = p_table.

  APPEND t_fieldcatalog.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_grid .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
*     i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout          = fs_layout
      it_fieldcat        = t_fieldcatalog[]
      it_events          = t_event[]
      i_save             = 'A'
    TABLES
      t_outtab           = it_final_cdpos
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  DATA: in_werks TYPE t001w-werks.
  SELECT  SINGLE werks FROM t001w INTO in_werks WHERE werks = s_werks.
  IF sy-subrc = 0.
    AUTHORITY-CHECK OBJECT 'Z_MASR_WRK'
    ID 'WERKS' FIELD in_werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH in_werks.
    ENDIF.
  ENDIF.

ENDFORM.
