*&---------------------------------------------------------------------*
*& Report  ZPP_CS11_REPORT
*&
*&-------------------------------------------------------------------*
*& REPORT AUTHOR         : RAJ KUMAR BESTHA
*& TECHNICAL LEAD        : PARTH SHUKLA
*& FUNCTIONAL CONSULTANT : PRATHMESH
*& FUNCTIONAL LEAD       : VIPUL KULSHRESTHA
*& REPORT CREATION DATE  :
*& TRANSACTION CODE      : ZPP_CS11
*& REQUEST NUMBER        :
*&-------------------------------------------------------------------*
REPORT zpp_cs11_report2.

**********************Selection screen input Variables**************
TABLES : mast.
SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-002.

*PARAMETERS:   s_werks TYPE mast-werks OBLIGATORY.
*SELECT-OPTIONS s_matnr FOR mast-matnr NO INTERVALS.
*PARAMETERS     : s_dt TYPE sy-datum .
*PARAMETERS   : s_stlal TYPE mast-stlal.
*PARAMETERS : s_capid TYPE tc04-capid.
*PARAMETERS :s_emeng TYPE rc29l-emeng.
*PARAMETERS :s_mehrs TYPE c DEFAULT 'X'.
*PARAMETERS: s_ehndl       TYPE c DEFAULT '1'.
PARAMETERS:p_file  TYPE rlgrap-filename OBLIGATORY.
PARAMETERS:p_file1 TYPE rlgrap-filename OBLIGATORY. " Download FileName

SELECTION-SCREEN : END OF BLOCK a1.
**********************Selection screen input Variables************
*********************Declaration of variables*********************
TYPES : BEGIN OF ty_struct,
          col_name(30),
        END OF ty_struct,
        ty_columns TYPE STANDARD TABLE OF ty_struct WITH EMPTY KEY.

DATA : lt_columns TYPE ty_struct,
       lt_temp    TYPE dfies_tab.


DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv.
DATA : it_stpo TYPE TABLE OF stpo_api02.
DATA : wa_stpo TYPE stpo_api02.

TYPES : BEGIN OF ty_data,

*** start of change **
*          matnr(18),
          matnr(40),
** end of change **
          werks(4),
          stlal(2),
          date(10),
          capid(4),
          emeng(13),
        END OF ty_data.


DATA :it_type TYPE truxs_t_text_data.
DATA : file_name TYPE string.
DATA : it_data TYPE STANDARD TABLE  OF ty_data, " WITH HEADER LINE,
       wa_data TYPE ty_data.

TYPES:
  BEGIN OF ty_s_cline,
    line TYPE c LENGTH 1024, " Line of type Character
  END OF ty_s_cline .

DATA: gr_table     TYPE REF TO cl_salv_table,          " Basis Class for Simple Tables
      gt_outtab    TYPE STANDARD TABLE OF sflight,     " Flight
      lr_functions TYPE REF TO cl_salv_functions_list, " Generic and User-Defined Functions in List-Type Tables
      lr_layout    TYPE REF TO cl_salv_layout,         " Settings for Layout
      lv_xml_type  TYPE salv_bs_constant,
      lv_xml       TYPE xstring,
      gt_srctab    TYPE STANDARD TABLE OF ty_s_cline,
      gt_len       TYPE i,                             " Len of type Integers
      lv_file_xlsx TYPE string,
      lv_file      TYPE localfile,                     " Local file for upload/download
      ls_key       TYPE salv_s_layout_key,             " Layout Key
      lr_content   TYPE REF TO cl_salv_form_element.   " General Element in Design Object

TYPES: BEGIN OF alv_stb.

         INCLUDE STRUCTURE stpox_alv.
         TYPES:   info(3) TYPE c,
*         types : matnr type mara-matnr,
       END OF alv_stb.

DATA: it_tabb TYPE STANDARD TABLE OF alv_stb,
      wa_tabb TYPE alv_stb.

TYPES : BEGIN OF final,
          matnr TYPE mara-matnr,
          maktx TYPE makt-maktx,
          stufe TYPE stpox_alv-stufe,
          posnr TYPE stpox_alv-posnr,
          idnrk TYPE stpox_alv-idnrk,
          ojtxp TYPE stpox_alv-ojtxp,
          werks TYPE stpox_alv-werks,
          mngko TYPE stpox_alv-mngko,
          meins TYPE stpox_alv-meins,

        END OF final.

*DATA: it_temp TYPE STANDARD TABLE OF ty_temp,
*      wa_temp TYPE ty_temp.

*TYPES: BEGIN OF final.
**TYPES : matnr   TYPE mara-matnr.
*         INCLUDE STRUCTURE stpox_alv.
*         TYPES:   info(3) TYPE c.
*TYPES : matnr TYPE mara-matnr,
*        END OF final.

DATA: it_final TYPE STANDARD TABLE OF final,
      wa_final TYPE final.

DATA : v_maktx TYPE makt-maktx.




DATA :  stb_fields_tb TYPE slis_t_fieldcat_alv.


FIELD-SYMBOLS : <gv_tab> TYPE STANDARD TABLE,
                <wa_tab> TYPE alv_stb.

*DATA : t_listheader   TYPE slis_t_listheader   WITH HEADER LINE,
*       t_fieldcatalog TYPE slis_t_fieldcat_alv WITH HEADER LINE,
*       fs_layout      TYPE slis_layout_alv,
*       t_event        TYPE slis_t_event WITH HEADER LINE.

*DATA : it_stpo TYPE TABLE OF stpo_api02.
DATA : it_stpo1 TYPE TABLE OF stpo_api02.
DATA : wa_stpo1 TYPE stpo_api02.

TYPES: BEGIN OF  ty_itab,
         matnr TYPE mara-matnr.
         INCLUDE TYPE stpox.
       TYPES:            END OF  ty_itab.


TYPES: BEGIN OF  ty_final,
         ind    TYPE char1,
         lv_no  TYPE char2,
         matnr  TYPE mara-matnr,
         matnr1 TYPE mara-matnr. "For Selection screen material purpose
*         lv_cr type char4.       "For Coloring of row purpose
         INCLUDE TYPE stpo_api02.
       TYPES:            END OF  ty_final.

DATA : it_final_tab TYPE STANDARD TABLE OF ty_final,
       wa_final_tab TYPE ty_final.
DATA: lr_pay_conf_data TYPE REF TO data.

DATA : it_tab TYPE STANDARD TABLE OF ty_final,
       wa_tab TYPE ty_final.

DATA : counter    TYPE i,
       main_count TYPE i,
       lv_nos     TYPE i.

DATA :lv_cr TYPE char4.


TYPES : BEGIN OF ty_mast,
          matnr TYPE mast-matnr,
          werks TYPE mast-werks,
          stlal TYPE mast-stlal,
        END OF ty_mast.

DATA : it_mast TYPE STANDARD TABLE  OF ty_mast,
       wa_mast TYPE ty_mast.


DATA: BEGIN OF alv_tab OCCURS 0.
        INCLUDE STRUCTURE stpox_alv.
        DATA:   info(3) TYPE c,
      END OF alv_tab.

DATA : count TYPE i .
*data : counter type i value '1'.
DATA alv_abap TYPE TABLE OF abaplist.
*
*******************************Declarations of variables***************
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'WS_FILENAME_GET'
    EXPORTING
      def_filename     = space
      def_path         = space
      mask             = ',*.*,*.*.'
      mode             = space
      title            = space
    IMPORTING
      filename         = p_file
*     RC               =
    EXCEPTIONS
      inv_winsys       = 1
      no_batch         = 2
      selection_cancel = 3
      selection_error  = 4
      OTHERS           = 5.
  IF sy-subrc <> 0 AND sy-subrc <> 3.
    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file1.
  PERFORM f4_help1.
******************************Execution of program**********************
START-OF-SELECTION.
  PERFORM upload.                 "Input file data
  PERFORM authorization_check.   "Authorisation checking
  PERFORM get_data.          "Fetching the data
*  PERFORM field_catlog.      "Processing the Fetched data
  PERFORM alv_grid_display.  "Display the Processed data
*
FORM get_data.
*  count = 0.

*  wa_tabb-matnr = s_matnr-low.
*
*  APPEND wa_tabb to it_tabb.

  LOOP AT it_data INTO wa_data.

    READ TABLE it_mast INTO DATA(wa_mast) WITH KEY matnr = wa_data-matnr werks = wa_data-werks." stlal = wa_data-stlal.
    IF sy-subrc = 0.
*    count = count  + 1 .
*    IF count = 1.
      cl_salv_bs_runtime_info=>set(
  EXPORTING display  = abap_false
            metadata = abap_false
            data     = abap_true ).


      REFRESH alv_tab.
      SUBMIT rcs11001

      WITH pm_mtnrv  = wa_data-matnr

      WITH  pm_werks = wa_data-werks

      WITH  pm_stlal = wa_data-stlal

      WITH pm_datuv = wa_data-date

      WITH pm_capid = wa_data-capid

      WITH pm_mehrs = 'X'

      WITH pm_ehndl = '1'

      WITH pm_emeng = wa_data-emeng

      AND RETURN .

      TRY .
          cl_salv_bs_runtime_info=>get_data_ref(
        IMPORTING r_data = lr_pay_conf_data ).
          ASSIGN lr_pay_conf_data->* TO <gv_tab>.
        CATCH cx_root.

      ENDTRY.

*       wa_tabb-matnr = s_matnr-low.
*      APPEND wa_tabb TO it_tabb.



      IF sy-subrc = 0.  """added by akshay dt.26.05.2025
" ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*         APPEND LINES OF <gv_tab> TO it_tabb.
        APPEND LINES OF <gv_tab> TO it_tabb. "#EC CI_FLDEXT_OK[2522971]
" ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
      ELSE.
        MESSAGE 'Invalid Data Check Excel' TYPE 'E'.
      ENDIF. """added by akshay dt.26.05.2025

*      wa_final-matnr = wa_matnr-low.     "Main Material appending
*      APPEND wa_final TO it_final.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE maktx FROM makt INTO v_maktx WHERE matnr = wa_data-matnr.

SELECT MAKTX FROM MAKT INTO V_MAKTX UP TO 1 ROWS WHERE MATNR = WA_DATA-MATNR
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


      LOOP AT it_tabb INTO wa_tabb.

        wa_final-matnr    = wa_data-matnr.
        wa_final-maktx = v_maktx.
        wa_final-stufe   = wa_tabb-stufe.
        wa_final-ojtxp  = wa_tabb-ojtxp.
        wa_final-werks  = wa_tabb-werks.
        wa_final-meins  = wa_tabb-meins.
        wa_final-mngko   = wa_tabb-mngko.
        wa_final-idnrk  = wa_tabb-idnrk.
        wa_final-posnr  = wa_tabb-posnr.
        APPEND wa_final TO it_final.
        CLEAR : wa_tabb,wa_final.

      ENDLOOP.


      CLEAR : wa_final,v_maktx.
      REFRESH :it_tabb.

*      wa_tabb-matnr = s_matnr-low.
*      MODIFY it_tabb from wa_tabb TRANSPORTING matnr.

*    ELSE."co-2
*
*      cl_salv_bs_runtime_info=>set(
*  EXPORTING display  = abap_false
*            metadata = abap_false
*            data     = abap_true ).
*      REFRESH alv_tab.
*      SUBMIT rcs11001
*
*       WITH pm_mtnrv  = s_matnr-low
*
*      WITH  pm_werks = s_werks
*
*      WITH  pm_stlal = s_stlal
*
*      WITH pm_datuv = s_dt
*
*      WITH pm_capid = s_capid
*
*      WITH pm_mehrs = s_mehrs
*
*      WITH pm_ehndl = s_ehndl
*
*      WITH pm_emeng = s_emeng
*
*      AND RETURN .
*
*      TRY .
*          cl_salv_bs_runtime_info=>get_data_ref(
*        IMPORTING r_data = lr_pay_conf_data ).
*          ASSIGN lr_pay_conf_data->* TO <gv_tab>.
*        CATCH cx_root.
*
*      ENDTRY.
*      APPEND LINES OF <gv_tab> TO it_tabb[].
*      CALL FUNCTION 'CSAP_MAT_BOM_READ'
*        EXPORTING
*          material    = s_matnr-low
*          plant       = s_werks
*          bom_usage   = '1'
*          alternative = s_stlal
*        TABLES
*          t_stpo      = it_stpo.
*
*      LOOP AT it_stpo INTO wa_stpo.
**        LOOP AT <gv_tab> ASSIGNING FIELD-SYMBOL(<ls_temp>) WHERE ('STUFE') ."AND dobjt = wa_stpo-component.
*        LOOP AT it_tabb ASSIGNING FIELD-SYMBOL(<ls_temp>) WHERE stufe = 1 AND dobjt = wa_stpo-component."AND dobjt = wa_stpo-component.
**          <ls_temp>-stufe = count.
*        ENDLOOP.
*      ENDLOOP.
*    ENDIF.



*    counter = counter + 1.
    ENDIF.

    CLEAR : wa_data.
  ENDLOOP.



*  cl_demo_output=>display( it_tabb ).
ENDFORM.




FORM field_catlog.

*  CALL FUNCTION 'REUSE_ALV_FIELDCATALOG_MERGE'
*    EXPORTING
*      i_program_name         = sy-repid
*     i_internal_tabname     = 'IT_TABB'
**      i_structure_name       = 'STPOX_ALV'
*
**     I_CLIENT_NEVER_DISPLAY = 'X'
*     I_INCLNAME             = sy-repid
**     I_BYPASSING_BUFFER     =
**     I_BUFFER_ACTIVE        =
*    CHANGING
*      ct_fieldcat            = it_fcat[]
*    EXCEPTIONS
*      inconsistent_interface = 1
*      program_error          = 2
*      OTHERS                 = 3.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.


*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LV_NO'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Level No.'.
*  wa_fcat-outputlen = '18'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
*
**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MATNR1'.       wa_fcat-tabname = 'IT_TABB'. wa_fcat-seltext_m =  'Finished Material'.
**  wa_fcat-outputlen = '18'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
*
**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MATNR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sub Material'.
**  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
*
*  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'ITEM_NO'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'ITEM NO'.
*  wa_fcat-outputlen = '8'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
**
*  wa_fcat-col_pos = 204.
*  wa_fcat-fieldname = 'INFO'.
*  wa_fcat-seltext_m =  'INFORMATION'.
**  wa_fcat-outputlen = '18'.
*  APPEND wa_fcat TO it_fcat.
*  CLEAR wa_fcat.
**
*  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'COMP_QTY'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Component Qty.'.
*  wa_fcat-outputlen = '18'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
*  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'COMP_UNIT'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Component Unit'.
*  wa_fcat-outputlen = '18'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
**  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'MAKTX'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Material Description'.
**  wa_fcat-outputlen = '30'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

ENDFORM.


*FORM top_page.
*  DATA : wa_header TYPE slis_listheader.
*  DATA : it_header TYPE slis_t_listheader.
*  DATA : v_wheret(100).
*  DATA : v_lowdate(10).
*  DATA : v_highdate(10).
*
*
*
*  wa_header-typ = 'H'.
**  IF v_all = 'X'.
*  wa_header-info = 'Display BOM Explosion Multi-Level'.
*
*
*  APPEND wa_header TO it_header.
*  CLEAR wa_header.
*
*  wa_header-typ = 'S'.
*
*
*  DATA : v_date TYPE char10.
*
*
*  CALL FUNCTION 'CONVERSION_EXIT_PDATE_OUTPUT'
*    EXPORTING
*      input  = sy-datum
*    IMPORTING
*      output = v_date.
*
*  CONCATENATE 'Date :- ' v_date INTO wa_header-info SEPARATED BY space.
*
*  APPEND wa_header TO it_header.
*  CLEAR wa_header.
*  CLEAR : v_lowdate,v_highdate.
*
*  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
*    EXPORTING
*      it_list_commentary = it_header.
**     i_logo             = 'ASTRAL_2020'.
**      i_logo             = 'LOGO_K'.
*
*
*ENDFORM.

*FORM build_layout.
*
*  wa_layout-no_input          = 'X'.
*  wa_layout-colwidth_optimize = 'X'.
*  wa_layout-info_fieldname =      'LINE_COLOR'.
*
*ENDFORM.                    " BUILD_LAYOUT



FORM alv_grid_display.

*  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
*    EXPORTING
*      i_callback_program = sy-repid
**      is_layout          = wa_layout
*      it_fieldcat        = it_fcat[]
*    TABLES
*      t_outtab           = it_tabb[]
*    EXCEPTIONS
*      program_error      = 1
*      OTHERS             = 2.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.



*  ENDIF.

  DATA: lv_file TYPE string.
  lv_file = p_file1.


  TRY.

      cl_salv_table=>factory(
        IMPORTING
          r_salv_table = gr_table
        CHANGING
          t_table      = it_final[] ).

    CATCH cx_salv_msg.                                  "#EC NO_HANDLER

  ENDTRY.

  lr_functions = gr_table->get_functions( ).

  lr_functions->set_all( abap_true ).

  lr_layout = gr_table->get_layout( ).

  ls_key-report = sy-repid.

  lr_layout->set_key( ls_key ).

  lr_layout->set_save_restriction( if_salv_c_layout=>restrict_user_independant ).

  gr_table->set_top_of_list( lr_content ).

  gr_table->set_end_of_list( lr_content ).

*  gr_table->display( ).

  lv_xml_type =  if_salv_bs_xml=>c_type_xlsx. "if_salv_bs_xml=>c_type_mhtml.

  lv_xml      = gr_table->to_xml( xml_type = lv_xml_type ).

  CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
    EXPORTING
      buffer        = lv_xml
*     APPEND_TO_TABLE       = ' '
    IMPORTING
      output_length = gt_len
    TABLES
      binary_tab    = gt_srctab.


  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      bin_filesize            = gt_len
      filename                = lv_file
      filetype                = 'BIN'
    CHANGING
      data_tab                = gt_srctab
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      not_supported_by_gui    = 22
      error_no_gui            = 23
      OTHERS                  = 24.

  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

  ELSE. " ELSE -> IF sy-subrc <> 0

    MESSAGE 'Excel file downloaded!' TYPE 'S'.

  ENDIF. " IF sy-subrc <> 0
***  CALL FUNCTION 'GUI_DOWNLOAD'
***    EXPORTING
****     BIN_FILESIZE            =
***      filename                = 'C:\Users\b.rajkumar\Desktop\ASTRALGEM.XLS'
***      filetype                = 'ASC'
****     APPEND                  = ' '
***      write_field_separator   = ' '
****     HEADER                  = '00'
****     TRUNC_TRAILING_BLANKS   = ' '
****     WRITE_LF                = 'X'
****     COL_SELECT              = ' '
****     COL_SELECT_MASK         = ' '
****     DAT_MODE                = ' '
****     CONFIRM_OVERWRITE       = ' '
****     NO_AUTH_CHECK           = ' '
****     CODEPAGE                = ' '
****     IGNORE_CERR             = ABAP_TRUE
****     REPLACEMENT             = '#'
****     WRITE_BOM               = ' '
****     TRUNC_TRAILING_BLANKS_EOL       = 'X'
****     WK1_N_FORMAT            = ' '
****     WK1_N_SIZE              = ' '
****     WK1_T_FORMAT            = ' '
****     WK1_T_SIZE              = ' '
****     WRITE_LF_AFTER_LAST_LINE        = ABAP_TRUE
****     SHOW_TRANSFER_STATUS    = ABAP_TRUE
****     VIRUS_SCAN_PROFILE      = '/SCET/GUI_DOWNLOAD'
**** IMPORTING
****     FILELENGTH              =
***    TABLES
***      data_tab                = it_tabb
****     FIELDNAMES              =
***    EXCEPTIONS
***      file_write_error        = 1
***      no_batch                = 2
***      gui_refuse_filetransfer = 3
***      invalid_type            = 4
***      no_authority            = 5
***      unknown_error           = 6
***      header_not_allowed      = 7
***      separator_not_allowed   = 8
***      filesize_not_allowed    = 9
***      header_too_long         = 10
***      dp_error_create         = 11
***      dp_error_send           = 12
***      dp_error_write          = 13
***      unknown_dp_error        = 14
***      access_denied           = 15
***      dp_out_of_memory        = 16
***      disk_full               = 17
***      dp_timeout              = 18
***      file_not_found          = 19
***      dataprovider_exception  = 20
***      control_flush_error     = 21
***      OTHERS                  = 22.
***  IF sy-subrc <> 0.
**** Implement suitable error handling here
***  ENDIF.




*  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
*    EXPORTING
*      i_callback_program = sy-repid
*      it_fieldcat        = it_fcat[]
*    TABLES
*      t_outtab           = it_tabb[]
*    EXCEPTIONS
*      program_error      = 1
*      OTHERS             = 2.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*  ENDIF.

ENDFORM.

FORM f4_help1 .
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name = sy-repid
    IMPORTING
      file_name    = p_file1.

ENDFORM.

FORM upload .
  file_name  = p_file.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = it_data
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
  ENDIF.


  IF it_data IS NOT INITIAL.
    SELECT matnr werks stlal FROM mast INTO TABLE it_mast FOR ALL ENTRIES IN it_data WHERE matnr = it_data-matnr AND werks =  it_data-werks." AND stlal = it_data-stlal.
  ENDIF.


ENDFORM.

FORM authorization_check .

  DATA : lv_msg TYPE string.

  LOOP AT it_data INTO wa_data.
    AUTHORITY-CHECK OBJECT 'ZCS11_WRKS'
        ID 'WERKS' FIELD wa_data-werks
        ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      CONCATENATE 'Your are not authorised for '
      wa_data-werks 'plant'
      INTO lv_msg SEPARATED BY space.
      MESSAGE lv_msg TYPE 'E'.
    ENDIF.
    CLEAR : wa_tab.
  ENDLOOP.

ENDFORM.
