*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZZBATCH_PLANTTOP.                 " Global Declarations
  INCLUDE LZZBATCH_PLANTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZZBATCH_PLANTF...                 " Subroutines
* INCLUDE LZZBATCH_PLANTO...                 " PBO-Modules
* INCLUDE LZZBATCH_PLANTI...                 " PAI-Modules
* INCLUDE LZZBATCH_PLANTE...                 " Events
* INCLUDE LZZBATCH_PLANTP...                 " Local class implement.
* INCLUDE LZZBATCH_PLANTT99.                 " ABAP Unit tests
  INCLUDE LZZBATCH_PLANTF00                       . " subprograms
  INCLUDE LZZBATCH_PLANTI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
