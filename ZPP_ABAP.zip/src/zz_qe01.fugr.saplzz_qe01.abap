*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZZ_QE01TOP.                       " Global Declarations
  INCLUDE LZZ_QE01UXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZZ_QE01F...                       " Subroutines
* INCLUDE LZZ_QE01O...                       " PBO-Modules
* INCLUDE LZZ_QE01I...                       " PAI-Modules
* INCLUDE LZZ_QE01E...                       " Events
* INCLUDE LZZ_QE01P...                       " Local class implement.
* INCLUDE LZZ_QE01T99.                       " ABAP Unit tests

INCLUDE lzz_qe01o01.

INCLUDE lzz_qe01i01.
