
**BREAK-POINT.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*SELECT SINGLE prueflos
*              enstehdat
*       FROM qals
*       INTO ( lv_prueflos , lv_enstehdat )
*       WHERE werk = wa_temp-werks
*         AND aufnr = aufnr_imp.

SELECT prueflos
       enstehdat
       FROM qals UP TO 1 ROWS
       INTO ( lv_prueflos , lv_enstehdat )
       WHERE werk = wa_temp-werks
         AND aufnr = aufnr_imp ORDER BY PRIMARY KEY.
  ENDSELECT.
******************end of ATC changes 13/02/26   UDAYABAP03*************
CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
  EXPORTING
    input  = lv_prueflos
  IMPORTING
    output = lv_prueflos.

lv_lotdate = lv_enstehdat+6(2) && '.' &&
             lv_enstehdat+4(2) && '.' &&
             lv_enstehdat+0(4).




















