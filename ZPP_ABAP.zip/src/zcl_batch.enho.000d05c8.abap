"Name: \PR:SAPLCOKO\FO:HEADER_UPDATE\SE:BEGIN\EI
ENHANCEMENT 0 ZCL_BATCH.
*DATA : lt_resb_bt_tmp     TYPE TABLE OF resbb,
*       lt_resb_bt_old_tmp TYPE TABLE OF  aresb.
*
*CALL FUNCTION 'CO_BC_RESB_BT_FETCH'
*  TABLES
*    et_resb_bt     = lt_resb_bt_tmp
*    et_resb_bt_old = lt_resb_bt_old_tmp
*  EXCEPTIONS
*    OTHERS         = 1.
*IF sy-subrc = 0.
**  DELETE lt_resb_bt_tmp WHERE charg IS INITIAL OR rgekz IS INITIAL.
*  IF lt_resb_bt_tmp[] IS NOT INITIAL.
*    DELETE lt_resb_bt_tmp WHERE charg IS INITIAL OR rgekz IS INITIAL.
*    IF lt_resb_bt_tmp[] is NOT INITIAL.
*
*      SELECT SINGLE * FROM zpp_param INTO @DATA(ls_param)
*        WHERE param1 = 'PP_BATCH'
*          AND param2 = 'SNRO'
*          AND param3 = @caufvd-auart
*          AND value1 = @abap_false.
*      IF sy-subrc = 0.
*        DATA(ls_resb) = VALUE #( lt_resb_bt_tmp[ matnr+11(1) = ls_param-value2 ] OPTIONAL ).
*        IF ls_resb IS NOT INITIAL.
*          afpod-charg = ls_resb-charg.
*          CLEAR ls_resb.
*        ELSE.
*          SELECT SINGLE * FROM zglb_enhc_tab INTO @DATA(ls_enh) WHERE modu = 'PPQM' AND enhc_name = 'AY_BATCH_COPY' AND indi = 'X'.
*          IF sy-subrc = 0 AND afpod-dwerk ='A301'.
*            READ TABLE lt_resb_bt_tmp INTO ls_resb INDEX 1.
*            IF sy-subrc = 0.
*              afpod-charg = ls_resb-charg.
*              CLEAR ls_resb.
*            ENDIF.
*          ELSE.
*            SELECT SINGLE * FROM zpp_param INTO @DATA(ls_param1)
*          WHERE param1 = @caufvd-werks
*            AND param2 = @caufvd-auart
*            AND value1 = @abap_true.
*            IF sy-subrc EQ 0.
*              CLEAR afpod-charg.
*            ENDIF.
*          ENDIF.
*        ENDIF.
**      ENDIF.
*    ELSE.
*          SELECT SINGLE * FROM zpp_param INTO ls_param1
*          WHERE param1 = caufvd-werks
*          AND param2 = caufvd-auart
*          AND value1 = abap_true.
*          IF sy-subrc EQ 0.
*            CLEAR afpod-charg.
*          ENDIF.
*    ENDIF.
*  ELSE.
*
*    IF caufvd-rsnum IS NOT INITIAL.
*      SELECT * FROM resb  WHERE rsnum = @caufvd-rsnum AND charg IS NOT INITIAL INTO TABLE @DATA(lt_batch).
*      DELETE lt_batch WHERE rgekz IS INITIAL.
**      IF sy-subrc = 0.
*      IF lt_batch[] IS NOT INITIAL.
**        afpod-charg = lv_batch.
*        SELECT SINGLE * FROM zpp_param INTO ls_param
*      WHERE param1 = 'PP_BATCH'
*        AND param2 = 'SNRO'
*        AND param3 = caufvd-auart
*        AND value1 = abap_false.
*        IF sy-subrc = 0.
*          ls_resb = VALUE #( lt_batch[ matnr+11(1) = ls_param-value2 ] OPTIONAL ).
*          IF ls_resb IS NOT INITIAL.
*            afpod-charg = ls_resb-charg.
*            CLEAR ls_resb.
*          ELSE.
*            SELECT SINGLE * FROM zglb_enhc_tab INTO ls_enh WHERE modu = 'PPQM' AND enhc_name = 'AY_BATCH_COPY' AND indi = 'X'.
*            IF sy-subrc = 0 AND afpod-dwerk ='A301'.
*              READ TABLE lt_batch INTO ls_resb INDEX 1.
*              IF sy-subrc = 0.
*                afpod-charg = ls_resb-charg.
*                CLEAR ls_resb.
*              ELSE.
*                SELECT SINGLE * FROM zpp_param INTO ls_param1
*                WHERE param1 = caufvd-werks
*                AND param2 = caufvd-auart
*                AND value1 = abap_true.
*                IF sy-subrc EQ 0.
*                  CLEAR afpod-charg.
*                ENDIF.
*              ENDIF.
*            ELSE.
*              SELECT SINGLE * FROM zpp_param INTO ls_param1
*                                              WHERE param1 = caufvd-werks
*                                              AND param2 = caufvd-auart
*                                              AND value1 = abap_true.
*              IF sy-subrc EQ 0.
*                CLEAR afpod-charg.
*              ENDIF.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*
*      ELSE.
*        SELECT SINGLE * FROM zpp_param INTO ls_param1
*      WHERE param1 = caufvd-werks
*        AND param2 = caufvd-auart
*        AND value1 = abap_true.
*        IF sy-subrc EQ 0.
*          CLEAR afpod-charg.
*        ENDIF.
*      ENDIF.
*    ELSE.
*
*      SELECT SINGLE * FROM zpp_param INTO ls_param1
*    WHERE param1 = caufvd-werks
*      AND param2 = caufvd-auart
*      AND value1 = abap_true.
*      IF sy-subrc EQ 0.
*        CLEAR afpod-charg.
*      ENDIF.
*
*    ENDIF.
*  ENDIF.
*  REFRESH : lt_resb_bt_tmp[], lt_resb_bt_old_tmp[].
*
*ENDIF.
ENDENHANCEMENT.
