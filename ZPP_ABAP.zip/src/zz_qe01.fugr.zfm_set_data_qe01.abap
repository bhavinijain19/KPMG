FUNCTION ZFM_SET_DATA_QE01.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IS_QALS) TYPE  QALS
*"----------------------------------------------------------------------
*  CLEAR w_qals.
 w_qals-zz1_zcontrol_ind_ilh    =  is_qals-zz1_zcontrol_ind_ilh .
 w_qals-zz1_zloc_ilh    =  is_qals-zz1_zloc_ilh.
 w_qals-zz1_zsample_qty_ilh  =  is_qals-zz1_zsample_qty_ilh .




ENDFUNCTION.
