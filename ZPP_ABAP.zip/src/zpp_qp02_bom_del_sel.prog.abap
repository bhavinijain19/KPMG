*&---------------------------------------------------------------------*
*&  Include           ZPP_QP02_BOM_DEL_SEL
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.
PARAMETERS : p_rb1 RADIOBUTTON GROUP rg1,
             p_rb2 RADIOBUTTON GROUP rg1.

SELECT-OPTIONS : s_werks FOR mapl-werks NO INTERVALS.
PARAMETERS: p_aedat TYPE datum.

**PARAMETERS : p_matnr TYPE mapl-matnr OBLIGATORY,
**             p_werks TYPE mapl-werks OBLIGATORY,
**             p_plnnr TYPE mapl-plnnr OBLIGATORY.
PARAMETERS : p_mode  TYPE ctu_params-dismode DEFAULT 'A'.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON s_werks.

  SELECT DISTINCT werks
       FROM t001w
       INTO TABLE @DATA(lt_werks)
       WHERE werks IN @s_werks.


  LOOP AT lt_werks INTO DATA(ls_werks).
    AUTHORITY-CHECK OBJECT 'ZQP02_WERK' ID 'WERKS' FIELD ls_werks-werks
                                        ID 'ACTVT' FIELD '06'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not Authorized for Plant - ' && ls_werks-werks TYPE 'S' DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.
  ENDLOOP.



AT SELECTION-SCREEN ON p_mode.
  SELECT SINGLE name,
         low
    FROM tvarvc
    INTO @DATA(ls_bdc)
    WHERE name = 'ZQP02_DELETE'
      AND type = 'S'
      AND low = @sy-uname.
  IF sy-subrc <> 0.
    MESSAGE 'You are not Authorized for Running BDC in Foregrouond' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.
