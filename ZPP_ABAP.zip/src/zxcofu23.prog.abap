*&---------------------------------------------------------------------*
*& Include          ZXCOFU23
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Include           ZXCOFU23
*&---------------------------------------------------------------------*
MOVE is_afrud-zzlot1     TO wa_afru-zzlot1 .
MOVE is_afrud-zzlot2     TO wa_afru-zzlot2 .
MOVE is_afrud-zzshift    TO wa_afru-zzshift.
*MOVE is_afrud-zzreason   TO wa_afru-zzreason.
MOVE is_afrud-zzres1     TO wa_afru-zzres1 .
MOVE is_afrud-zzres2     TO wa_afru-zzres2 .
MOVE is_afrud-zzres3     TO wa_afru-zzres3 .
MOVE is_afrud-zzres4     TO wa_afru-zzres4 .
MOVE is_afrud-zzres5     TO wa_afru-zzres5 .
MOVE is_afrud-zzres6     TO wa_afru-zzres6 .
MOVE is_afrud-zzquan1    TO wa_afru-zzquan1.
MOVE is_afrud-zzquan2    TO wa_afru-zzquan2.
MOVE is_afrud-zzquan3    TO wa_afru-zzquan3.
MOVE is_afrud-zzquan4    TO wa_afru-zzquan4.
MOVE is_afrud-zzquan5    TO wa_afru-zzquan5.
MOVE is_afrud-zzquan6    TO wa_afru-zzquan6.


MOVE is_afrud-zzrres1     TO wa_afru-zzrres1 .
MOVE is_afrud-zzrres2     TO wa_afru-zzrres2 .
MOVE is_afrud-zzrres3     TO wa_afru-zzrres3 .
MOVE is_afrud-zzrres4     TO wa_afru-zzrres4 .
MOVE is_afrud-zzrres5     TO wa_afru-zzrres5 .
MOVE is_afrud-zzrres6     TO wa_afru-zzrres6 .
MOVE is_afrud-zzrquan1    TO wa_afru-zzrquan1.
MOVE is_afrud-zzrquan2    TO wa_afru-zzrquan2.
MOVE is_afrud-zzrquan3    TO wa_afru-zzrquan3.
MOVE is_afrud-zzrquan4    TO wa_afru-zzrquan4.
MOVE is_afrud-zzrquan5    TO wa_afru-zzrquan5.
MOVE is_afrud-zzrquan6    TO wa_afru-zzrquan6.


  MOVE is_afrud-zzmach1  TO wa_afru-zzmach1.
  MOVE is_afrud-zzmach2  TO wa_afru-zzmach2.
  MOVE is_afrud-zzmach3  TO wa_afru-zzmach3.
  MOVE is_afrud-zzmach4  TO wa_afru-zzmach4.
  MOVE is_afrud-zzmach5  TO wa_afru-zzmach5.
  MOVE is_afrud-zzmach6  TO wa_afru-zzmach6.
  MOVE is_afrud-ZZMQUAN1 TO wa_afru-ZZMQUAN1.
  MOVE is_afrud-ZZMQUAN2 TO wa_afru-ZZMQUAN2.
  MOVE is_afrud-ZZMQUAN3 TO wa_afru-ZZMQUAN3.
  MOVE is_afrud-ZZMQUAN4 TO wa_afru-ZZMQUAN4.
  MOVE is_afrud-ZZMQUAN5 TO wa_afru-ZZMQUAN5.
  MOVE is_afrud-ZZMQUAN6 TO wa_afru-ZZMQUAN6.
