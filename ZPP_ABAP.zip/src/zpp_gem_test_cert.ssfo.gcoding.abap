
SORT lt_fin ASCENDING BY Parta.

LOOP AT lt_fin INTO ls_fin WHERE parta EQ 'X'.

  MOVE-CORRESPONDING ls_fin TO wa_final.
  APPEND wa_final TO it_final.
  CLEAR: wa_final, ls_fin.

ENDLOOP.




















