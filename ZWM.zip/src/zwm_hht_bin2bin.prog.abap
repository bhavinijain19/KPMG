*************************************************************************************
*Object Name              : ZWM_HHT_BIN2BIN.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Module pool to transfer data of one bin to another using
*                           HHT device.
*************************************************************************************
PROGRAM ZWM_HHT_BIN2BIN.

include : ZWM_HHT_BIN2BIN_top,           "data declaration.
          ZWM_HHT_BIN2BIN_scr,           "include for screen declaration.
          zwm_hht_bin2bin_module.        "include for MODULES.

*********************************************************
*Start of Selection event.
*********************************************************
START-OF-SELECTION.
*********************************************************
*calling screen 9001.
*********************************************************
  call screen 9001.
