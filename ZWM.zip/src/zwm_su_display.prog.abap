*************************************************************************************
*Object Name              : ZWM_SU_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 05/04/2019.
*************************************************************************************
*Description              : PROGRAM FOR SU DISPLAY.
*************************************************************************************
PROGRAM ZWM_SU_DISPLAY.

INCLUDE : ZWM_SU_DISPLAY_TOP,
          ZWM_SU_DISPLAY_SCR,
          ZWM_SU_DISPLAY_MODULE.

*********************************************************
*Start of selection event.
*********************************************************
start-OF-SELECTION.
*********************************************************
*calling screen 9001.
*********************************************************
call SCREEN 9001.
