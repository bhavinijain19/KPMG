*&---------------------------------------------------------------------*
*& Include          ZWM_WOSCHEME_S01
*&---------------------------------------------------------------------*

SELECTION-SCREEN: BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_loadno FOR zmm_load_sloc1-load_no,
                  s_suno FOR zmm_load_sloc1-su_no,
                  s_deliv FOR zmm_load_sloc1-obd_no,
                  s_matnr FOR zmm_load_sloc1-matnr,
                  s_batch FOR zmm_load_sloc1-batch_no,
                  s_plant FOR zmm_load_sloc1-plant,
                  s_date FOR zmm_load_sloc1-entry_date,
                  s_loadst FOR zmm_load_sloc1-load_status.
SELECTION-SCREEN: END OF BLOCK b1.
