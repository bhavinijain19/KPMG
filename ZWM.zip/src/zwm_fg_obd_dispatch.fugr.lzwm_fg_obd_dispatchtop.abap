FUNCTION-POOL ZWM_FG_OBD_DISPATCH.          "MESSAGE-ID ..

* INCLUDE LZWM_FG_OBD_DISPATCHD...           " Local class definition
