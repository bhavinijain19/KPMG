*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_STATUS_8O01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_8001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8001 OUTPUT.
*APPEND 'BACK' TO fcode.
*  SET PF-STATUS 'ZHU_8001'.

*  SET PF-STATUS 'ZHU_8001' EXCLUDING fcode.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8001 INPUT.
  DATA: lv_datum TYPE datum.
  lv_datum = sy-datum - 5.
  CASE sy-ucomm.
    WHEN 'PREV'.
      LEAVE TO SCREEN 8000.
*      CALL SCREEN 8000.
    WHEN 'SNLOAD'.
      CALL SCREEN 8002.
    WHEN 'SOLOAD'.
*      CLEAR: lt_load.
****************Validation for Used id & plant**********
      SELECT werks FROM zwm_uid_plant INTO TABLE it_plnt
                                      WHERE user_id = sy-uname.
      IF sy-subrc = 0.
****************Validation for Used id & plant**********
        SELECT load_no su_no entry_date load_status
          FROM zmm_load_sloc1
          INTO TABLE lt_load
          FOR ALL ENTRIES IN it_plnt
          WHERE entry_date GE lv_datum
            AND load_status = 'I'
            AND plant = it_plnt-plant.
****************Validation for Used id & plant**********
        IF sy-subrc = 0.
****************Validation for Used id & plant**********
          SORT lt_load BY load_no .
          DELETE ADJACENT DUPLICATES FROM lt_load COMPARING load_no.
          SORT lt_load BY load_no DESCENDING.
          DESCRIBE TABLE lt_load LINES cnt110.
          CALL SCREEN 8110.
****************Validation for Used id & plant**********
        ELSE.
          MESSAGE 'Data not found' TYPE 'I'.
          RETURN.
        ENDIF.
      ELSE.
        MESSAGE 'Authorization missing for Plant' TYPE 'I'.
      ENDIF.
****************Validation for Used id & plant**********
  ENDCASE.
ENDMODULE.
