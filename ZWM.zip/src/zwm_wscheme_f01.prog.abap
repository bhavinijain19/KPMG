*&---------------------------------------------------------------------*
*& Include          ZWM_WOSCHEME_F01
*&---------------------------------------------------------------------*

SELECT * FROM zmm_load_sloc2
  INTO TABLE @DATA(lt_load)
  WHERE load_no IN @s_loadno
  AND su_no IN @s_suno
  AND obd_no IN @s_deliv
  AND matnr IN @s_matnr
  AND batch_no IN @s_batch
  AND plant IN @s_plant
  AND entry_date IN @s_date
  AND load_status IN @s_loadst.

IF lt_load IS NOT INITIAL.
  SELECT matnr, maktx
    FROM makt
    INTO TABLE @DATA(lt_makt)
    FOR ALL ENTRIES IN @lt_load
    WHERE matnr EQ @lt_load-matnr.
ENDIF.

LOOP AT lt_load ASSIGNING FIELD-SYMBOL(<lfs_load>).
  lwa_final-batch_no = <lfs_load>-batch_no.
  lwa_final-bin_loc = <lfs_load>-bin_loc.
  lwa_final-entry_date = <lfs_load>-entry_date.
  lwa_final-err_msg = <lfs_load>-err_msg.
  lwa_final-load_item = <lfs_load>-load_item.
  lwa_final-load_no = <lfs_load>-load_no.
  lwa_final-load_status = <lfs_load>-load_status.
  lwa_final-matnr = <lfs_load>-matnr.
  lwa_final-obd_headitem = <lfs_load>-obd_headitem.
  lwa_final-obd_lineitem = <lfs_load>-obd_lineitem.
  lwa_final-obd_no = <lfs_load>-obd_no.
  lwa_final-plant = <lfs_load>-plant.
  lwa_final-quantity = <lfs_load>-quantity.
  lwa_final-storage_loc = <lfs_load>-storage_loc.
  lwa_final-su_no = <lfs_load>-su_no.
  lwa_final-su_qty = <lfs_load>-su_qty.
  lwa_final-to_create_date = <lfs_load>-to_create_date.
  lwa_final-to_no = <lfs_load>-to_no.
  lwa_final-uom = <lfs_load>-uom.
  lwa_final-free_qty = <lfs_load>-free_qty.

  READ TABLE lt_makt ASSIGNING FIELD-SYMBOL(<lfs_makt>) WITH KEY matnr = <lfs_load>-matnr.
  IF sy-subrc IS INITIAL.
    lwa_final-maktx = <lfs_makt>-maktx.
  ENDIF.

  APPEND lwa_final TO lt_final.
  CLEAR lwa_final.
ENDLOOP.

CLEAR ls_fcat.
ls_fcat-fieldname = 'LOAD_NO'.
ls_fcat-seltext_m = 'Load Number'.
ls_fcat-seltext_l = 'Load Number'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'LOAD_ITEM'.
ls_fcat-seltext_m = 'Load Item'.
ls_fcat-seltext_l = 'Load Item'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'SU_NO'.
ls_fcat-seltext_m = 'Stoarge Unit No.'.
ls_fcat-seltext_l = 'Storage Unit Number'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'OBD_NO'.
ls_fcat-seltext_m = 'Delivery'.
ls_fcat-seltext_l = 'Delivery'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'OBD_LINEITEM'.
ls_fcat-seltext_m = 'Del. Line Item'.
ls_fcat-seltext_l = 'Delivery Line Item'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'OBD_HEADITEM'.
ls_fcat-seltext_m = 'Del. Head Item'.
ls_fcat-seltext_l = 'Delivery Head Item'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'ENTRY_DATE'.
ls_fcat-seltext_m = 'Date'.
ls_fcat-seltext_l = 'Date'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'STORAGE_LOC'.
ls_fcat-seltext_m = 'Storage Location'.
ls_fcat-seltext_l = 'Storage Location'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'PLANT'.
ls_fcat-seltext_m = 'Plant'.
ls_fcat-seltext_l = 'Plant'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'MATNR'.
ls_fcat-seltext_m = 'Material'.
ls_fcat-seltext_l = 'Material'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'MAKTX'.
ls_fcat-seltext_m = 'Mat. Desc.'.
ls_fcat-seltext_l = 'Material Description'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'BATCH_NO'.
ls_fcat-seltext_m = 'Batch No.'.
ls_fcat-seltext_l = 'Batch Number'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'QUANTITY'.
ls_fcat-seltext_m = 'Quantity'.
ls_fcat-seltext_l = 'Quantity'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'UOM'.
ls_fcat-seltext_m = 'UOM'.
ls_fcat-seltext_l = 'UOM'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'BIN_LOC'.
ls_fcat-seltext_m = 'Stor. Bin'.
ls_fcat-seltext_l = 'Storage Bin'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'LOAD_STATUS'.
ls_fcat-seltext_m = 'Load Status'.
ls_fcat-seltext_l = 'Loading Status'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'SU_QTY'.
ls_fcat-seltext_m = 'Available Stock'.
ls_fcat-seltext_l = 'Available Stock'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'TO_CREATE_DATE'.
ls_fcat-seltext_m = 'Creation Date'.
ls_fcat-seltext_l = 'Transfer Creation Date'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'TO_NO'.
ls_fcat-seltext_m = 'Tra. Ord. No.'.
ls_fcat-seltext_l = 'Transfer Order Number'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'FREE_QTY'.
ls_fcat-seltext_m = 'Free Qty'.
ls_fcat-seltext_l = 'Free Quantity'.
APPEND ls_fcat TO lt_fcat.

CLEAR ls_fcat.
ls_fcat-fieldname = 'ERR_MSG'.
ls_fcat-seltext_m = 'Error Message'.
ls_fcat-seltext_l = 'Error Message'.
APPEND ls_fcat TO lt_fcat.

CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
  EXPORTING
    i_callback_program = sy-repid
    it_fieldcat        = lt_fcat
  TABLES
    t_outtab           = lt_final
  EXCEPTIONS
    program_error      = 1
    OTHERS             = 2.

IF sy-subrc <> 0.
* Implement suitable error handling here
ENDIF.
