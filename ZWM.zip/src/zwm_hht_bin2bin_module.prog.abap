*************************************************************************************
*Object Name              : ZWM_HHT_BIN2BIN_MODULE.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : PBO,PAI,MOdule iclude
*************************************************************************************

*********************************************************
*PBO of screen 9001.
*********************************************************
MODULE status_9001 OUTPUT.
  SET PF-STATUS 'PF_9001'.

   LOOP AT SCREEN.                                              "for making LGTYPD parameter field uneditable.
    IF screen-name = 'P_LGTYPD'.
      screen-input = 0.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.
  CASE ok_code.
*********************************************************
*BACK button is pressed.
*********************************************************
    WHEN 'BACK'.
      REFRESH : it_lqua,it_lqua1,it_bdcdata.                  "clearing all variables on back button.
      CLEAR wa_bdcdata.
      CLEAR : p_lgtyps,
      gv_tanum,
      p_lgtypd ,
      v_lgnum ,
      v_lgtyp ,
      v_lgpla ,
      p_lgplas,
      v1_lgtyp ,
      v1_lgpla ,
      v_lgber ,
      p_lgber,
      p_lgnum,
      p_lgplad,
      wa_ltap_creat,
      it_ltap_creat.
      leave to SCREEN 0.
*********************************************************
*ENTER is pressed.
*********************************************************
    WHEN 'ENTER'.
*********************************************************
*Validating user input on selection screen.
*********************************************************

      IF flag_enter EQ 1.
        SELECT SINGLE lgnum lgtyp lgpla
            FROM lagp
            INTO v_lagp
            WHERE lgnum EQ p_lgnum
            AND   lgtyp EQ p_lgtyps
            AND   lgpla EQ p_lgplas.

        IF sy-subrc NE 0.
          flag = 1.
        ENDIF.

        SELECT SINGLE lgtyp
                      lgpla
                      lgber
        FROM lagp
        INTO v_lagp1
        WHERE  lgpla EQ p_lgplad
        AND   lgber  EQ p_lgber.
        IF sy-subrc = 0.
          flag = 2.
          v_lgnum  = p_lgnum.
          v_lgpla  = p_lgplas.
          v_lgtyp  = p_lgtyps.
          v1_lgtyp = p_lgtypd.
          v_lgber  = p_lgber.
          v1_lgpla = p_lgplad.
        ENDIF.
        IF sy-subrc NE 0.

          flag2 = 1.
          flag = 3.
        ENDIF.
      ENDIF.
      IF flag_enter EQ 0.
        p_lgtypd = p_lgtyps.
        flag_enter = 1.
      ENDIF.

      IF p_lgplas EQ p_lgplad.
        flag2 = 2.
        flag = 3.
      ENDIF.

  ENDCASE.
  IF flag = 1.
    MESSAGE i000(zbin_to_bin) DISPLAY LIKE 'E'.

  ELSEIF flag2 = 1.
    MESSAGE i001(zbin_to_bin) DISPLAY LIKE 'E'.
    CLEAR flag2.
  ELSEIF flag2 = 2.
    MESSAGE i003(zbin_to_bin) DISPLAY LIKE 'E'.
    CLEAR flag2.
  ENDIF.
  IF flag = 2.
    CALL SCREEN 9002.                                 "calling screen 9002.
  ENDIF.

ENDMODULE.
*********************************************************
*Mdule Selection to get selected values.
*********************************************************
MODULE transp_itab_out OUTPUT.
  CLEAR wa_lqua.
  idx = sy-stepl + line.
  READ TABLE it_lqua INTO wa_lqua INDEX idx.
  IF sy-subrc EQ 0.
    wa_lqua = it_lqua[ idx ].
  ENDIF.
ENDMODULE.

MODULE transp_itab_in INPUT.
  lines = sy-loopc.
  idx = sy-stepl + line.
  "modify it_lqua FROM wa_lqua INDEX idx.
ENDMODULE.

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
*********************************************************
*PAI of screen 9001.
*********************************************************
MODULE user_command_9001 INPUT.
  CASE ok_code.
    WHEN 'BACK'.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT' OR 'CANCEL'.
      LEAVE PROGRAM.

  ENDCASE.
ENDMODULE.
*********************************************************
*PBO of screen 9002.
*********************************************************
MODULE status_9002 OUTPUT.
  SET PF-STATUS 'PF_9002'.
  IF flag = 2.
    SELECT lgnum                                   "fetching data from table LQUA.
           lqnum
           matnr
           werks
           charg
           bestq
           sobkz
           sonum
           lgtyp
           lgpla
           letyp
           meins
           verme
           lenum
           lgort
    FROM lqua
    INTO TABLE it_lqua
    WHERE     lgnum EQ v_lgnum
          AND lgpla EQ v_lgpla
          AND lgtyp EQ v_lgtyp.

    IF it_lqua IS NOT INITIAL.                         "initial check
      SORT it_lqua BY lgnum.

      SELECT werks                                     "fetching data from table zwm_picklist.
             lgort
             lgnum
             lgber
      FROM zwm_picklist
      INTO TABLE it_zwm_picklist
      FOR ALL ENTRIES IN it_lqua
      WHERE werks EQ it_lqua-werks
      AND   lgort EQ it_lqua-lgort
      AND   lgnum EQ it_lqua-lgnum.
    ENDIF.
    flag = 3.
  ENDIF.
******ATC BEGIN OF CHANGE 27.02.2026 ******
  Sort it_zwm_picklist by werks lgort lgnum.
******ATC END OF CHANGE 27.02.2026 ******
  DESCRIBE TABLE it_lqua LINES fill..
  IF flag_move EQ 1. "AND it_lqua1 IS NOT INITIAL.     "initial check
    CLEAR wa_lqua.
    LOOP AT it_lqua INTO wa_lqua.                   "looping it_lqua1.
      wa_ltap_creat-matnr = wa_lqua-matnr.
      wa_ltap_creat-werks = wa_lqua-werks.
      wa_ltap_creat-lgort = wa_lqua-lgort.
      wa_ltap_creat-charg = wa_lqua-charg.
      wa_ltap_creat-anfme = wa_lqua-verme.
      wa_ltap_creat-altme = wa_lqua-meins.
      wa_ltap_creat-vltyp = v_lgtyp.
      wa_ltap_creat-vlpla = v_lgpla.
      wa_ltap_creat-vlenr = wa_lqua-lenum.
      wa_ltap_creat-nltyp = v1_lgtyp.
      wa_ltap_creat-nlber = v_lgber.
      wa_ltap_creat-nlpla = v1_lgpla.
      wa_ltap_creat-nlenr = wa_lqua-lenum.
*********************************************************
*Reading table It_zwm_picklist.
*********************************************************
      READ TABLE it_zwm_picklist INTO wa_zwm_picklist BINARY SEARCH WITH KEY  werks = wa_lqua-werks
                                                                              lgort = wa_lqua-lgort
                                                                              lgnum = wa_lqua-lgnum.

      IF sy-subrc EQ 0.                                         "initial check

        wa_ltap_creat-vlber = wa_zwm_picklist-lgber.

      ENDIF.


      APPEND wa_ltap_creat TO it_ltap_creat.                 "appending data to it_ltap_creat
      flag_ltap_creat = 1.
    ENDLOOP.

  ENDIF.

  IF flag_confirm EQ 0 AND flag_move = 1 AND flag_ltap_creat = 1.
    CALL FUNCTION 'L_TO_CREATE_MULTIPLE'                      "calling FM for TO creation
      EXPORTING
        i_lgnum                = v_lgnum
        i_bwlvs                = '999'
        i_commit_work          = 'X'
        i_bname                = sy-uname
      IMPORTING
        e_tanum                = gv_tanum
      TABLES
        t_ltap_creat           = it_ltap_creat
      EXCEPTIONS
        no_to_created          = 1
        bwlvs_wrong            = 2
        betyp_wrong            = 3
        benum_missing          = 4
        betyp_missing          = 5
        foreign_lock           = 6
        vltyp_wrong            = 7
        vlpla_wrong            = 8
        vltyp_missing          = 9
        nltyp_wrong            = 10
        nlpla_wrong            = 11
        nltyp_missing          = 12
        rltyp_wrong            = 13
        rlpla_wrong            = 14
        rltyp_missing          = 15
        squit_forbidden        = 16
        manual_to_forbidden    = 17
        letyp_wrong            = 18
        vlpla_missing          = 19
        nlpla_missing          = 20
        sobkz_wrong            = 21
        sobkz_missing          = 22
        sonum_missing          = 23
        bestq_wrong            = 24
        lgber_wrong            = 25
        xfeld_wrong            = 26
        date_wrong             = 27
        drukz_wrong            = 28
        ldest_wrong            = 29
        update_without_commit  = 30
        no_authority           = 31
        material_not_found     = 32
        lenum_wrong            = 33
        matnr_missing          = 34
        werks_missing          = 35
        anfme_missing          = 36
        altme_missing          = 37
        lgort_wrong_or_missing = 38
        OTHERS                 = 39.
    IF sy-subrc EQ 0.
      flag_bapi = 1.
    ENDIF.
    CLEAR it_ltap_creat.
***********************************************************
*BDC for confirming created TO.
***********************************************************
    PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'LTAK-TANUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'LTAK-TANUM'
                                  gv_tanum.
    PERFORM bdc_field       USING 'LTAK-LGNUM'
                                  v_lgnum.

    PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'LTAK-LGNUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
    CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.


    CLEAR it_bdcdata.
    CLEAR wa_bdcdata.
  ENDIF.

  IF flag_confirm EQ 0 AND flag_move EQ 1 AND flag_bapi = 1.

    gv_text = 'TO number(s) created are :'.
    CONCATENATE gv_text gv_tanum INTO gv_text SEPARATED BY ' '.
    MESSAGE gv_text TYPE 'I'.                                        "message to display TO no.
    LEAVE LIST-PROCESSING.
    REFRESH : it_lqua,it_lqua1,it_bdcdata.
    CLEAR : p_lgtyps,check,wa_bdcdata,                               "clearing all variables.
    gv_tanum,
    p_lgtypd ,
    v_lgnum ,
    p_lgplas,
    v_lgtyp ,
    v_lgpla ,
    v1_lgtyp ,
    v1_lgpla ,
    v_lgber ,
    p_lgber,
    p_lgnum,
    p_lgplad,
    wa_ltap_creat,
    it_ltap_creat, flag,flag2,check,flag_bapi,flag_confirm,flag_enter,flag_ltap_creat,
    flag_move,flag_select_all,flag_validate,idx,limit,lines,p_num,fill,cnt.
    LEAVE TO SCREEN 0.
  ENDIF.

ENDMODULE.
***********************************************************
*PAI os screen 9002.
***********************************************************
MODULE user_command_9002 INPUT.
  DATA : y_v_index TYPE sy-index.
  DATA : y_lv_d       TYPE f,
         y_lv_div     TYPE i,
         y_curr_p_num TYPE i.
  CASE ok_code.
*********************************************************
*BACK button is pressed.
*********************************************************
    WHEN 'BACK'.
      CLEAR : it_lqua, wa_bdcdata,it_lqua1,      "clearing all variables.
              it_ltap_creat,
              flag,
              flag2,
              flag_bapi,
              flag_confirm,
              flag_enter,
              flag_move,
              flag_select_all,
              it_bdcdata,
              it_zwm_picklist,
              p_lgber,
              p_lgnum,
              p_lgplad,
              p_lgplas,
              p_lgtypd,
              p_lgtyps,
              v_lgnum,
              v_lagp,
              v1_lgpla,
              v1_lgtyp,
              v_lagp1,
              v_lgber,idx,limit,lines,p_num,fill,cnt.

      LEAVE TO SCREEN 0.
*********************************************************
*Exit or cancel is pressed.
*********************************************************
    WHEN 'EXIT' OR 'CANCEL'.
      LEAVE PROGRAM.
    WHEN 'PGDN'.
      line = line + lines.
      limit = fill - lines.
      IF line > limit.
        line = limit.
      ENDIF.

    WHEN 'PGUP'.
      line = line - lines.
      IF line < 0.
        line = 0.
      ENDIF.

*********************************************************
*Move button is pressed.
*********************************************************
    WHEN 'MOVE'.
      flag_move = 1.
      flag_validate = 1.
  ENDCASE.
ENDMODULE.                                    "calling fieldcat method from class object.
