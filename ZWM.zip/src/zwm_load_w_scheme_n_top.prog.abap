*&---------------------------------------------------------------------*
*& Include ZWM_LOAD_WO_SCHEME_N_TOP                          Report ZWM_LOAD_WO_SCHEME_N
*&
*&---------------------------------------------------------------------*
REPORT zwm_load_wo_scheme_n.

DATA: lv_name              TYPE vrm_id,
      lt_scan_type_list    TYPE vrm_values,
      lt_barcode_type_list TYPE vrm_values,
      lt_load_type_list    TYPE vrm_values,
      ls_value             LIKE LINE OF lt_scan_type_list.

DATA: lv_scan_type       TYPE char2,
      lv_obd_no          TYPE string,
      lv_obd_no_str      TYPE string,
      lv_palette_no      TYPE zwm_de_pallet_no,
      lv_temp_palette_no TYPE zwm_de_pallet_no,
      lv_scanned_su      TYPE zwm_de_su_no,
      lv_su_no           TYPE string,
      lv_temp_su_no      TYPE zwm_de_su_no,
      lv_temp_obd_no     TYPE lips-vbeln,
      lv_barcode_type    TYPE char10,
      lv_detail_disp     TYPE boolean,
      lv_flag1           TYPE boolean,
      lv_flag2           TYPE boolean,
      lv_pallet_cursor   TYPE boolean,
      lv_su_cursor       TYPE boolean,
      lv_count           TYPE int4,
      lv_mat_count       TYPE int4,
      lv_msg             TYPE string,
      lv_mat             TYPE matnr,
      lv_mat_code        TYPE matnr,
      lv_mat_code_tmp    TYPE matnr,
      wa_cursor(40),
      lv_obd_flag        TYPE char1,
      lv_sel_mode        TYPE zwm_de_config_value,
      lv_config_name     TYPE zwm_de_config_name,
      lv_config_value    TYPE zwm_de_config_value.

DATA: ls_mat_list     TYPE zwm_st_obd_list1,
      ls_batch_list   TYPE zwm_st_batch_list,
      ls_scanned_list TYPE zwm_st_scan_list,
      ls_load_list    TYPE zwm_st_load_list,
      ls_incomplete_mat_list TYPE zwm_st_load_list.

DATA: lt_mat_list         TYPE zwm_tt_obd_list1,
      lt_mat_list_temp    TYPE zwm_tt_obd_list1,
      lt_batch_list       TYPE zwm_tt_batch_list,
      lt_scanned_list     TYPE zwm_tt_scan_list,
      lt_scanned_list_tmp TYPE zwm_tt_scan_list,
      lt_batch_exp        TYPE zwm_tt_batch_exp,
      lt_load_list        TYPE zwm_tt_load_list,
      lt_incomplete_mat_list TYPE zwm_tt_load_list,
      lt_scan_load        TYPE TABLE OF zwm_scan_load.

DATA: lt_rowindex TYPE lvc_t_row.
DATA: ls_rowindex TYPE lvc_s_row.

DATA: lv_row_selected TYPE lvc_index.
DATA: lv_row_count TYPE lvc_index.


DATA: ls_likp            TYPE likp.


DATA : gv_variant  TYPE disvariant    VALUE sy-repid.
DATA: gr_grid1      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont1 TYPE REF TO cl_gui_custom_container,
      gs_layout1    TYPE lvc_s_layo,
      gt_fcat1      TYPE lvc_t_fcat,
      gt_exclude1   TYPE ui_functions.
DATA: gr_grid2      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont2 TYPE REF TO cl_gui_custom_container,
      gs_layout2    TYPE lvc_s_layo,
      gt_fcat2      TYPE lvc_t_fcat,
      gt_exclude2   TYPE ui_functions.
DATA: gr_grid3      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont3 TYPE REF TO cl_gui_custom_container,
      gs_layout3    TYPE lvc_s_layo,
      gt_fcat3      TYPE lvc_t_fcat,
      gt_exclude3   TYPE ui_functions.
DATA: gr_grid4      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont4 TYPE REF TO cl_gui_custom_container,
      gs_layout4    TYPE lvc_s_layo,
      gt_fcat4      TYPE lvc_t_fcat,
      gt_exclude4   TYPE ui_functions.
DATA: gr_grid5      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont5 TYPE REF TO cl_gui_custom_container,
      gs_layout5    TYPE lvc_s_layo,
      gt_fcat5      TYPE lvc_t_fcat,
      gt_exclude5   TYPE ui_functions.
DATA: gr_grid6      TYPE REF TO cl_gui_alv_grid,
      gr_cust_cont6 TYPE REF TO cl_gui_custom_container,
      gs_layout6    TYPE lvc_s_layo,
      gt_fcat6      TYPE lvc_t_fcat,
      gt_exclude6   TYPE ui_functions.

DATA: lt_palette_map TYPE STANDARD TABLE OF zwm_pallet_map.
DATA: lt_su TYPE STANDARD TABLE OF zwm_su.
DATA: lt_su_tmp TYPE STANDARD TABLE OF zwm_su.
DATA: ls_su TYPE zwm_su.
DATA: ls_mch1 TYPE mch1.
DATA: lt_mch1 TYPE TABLE OF mch1.

DATA: wa_fcat                 TYPE lvc_s_fcat.

FIELD-SYMBOLS: <fs_mat_list>   LIKE LINE OF lt_mat_list,
               <fs_batch_list> LIKE LINE OF lt_batch_list.

"For Save & post

DATA: ls_sloc   TYPE zmm_load_sloc2.

DATA: lt_sloc      TYPE TABLE OF zmm_load_sloc2,
      lt_sloc_temp TYPE TABLE OF zmm_load_sloc2,
      lt_sloc_del  TYPE TABLE OF zmm_load_sloc2,
      lt_sloc_upd  TYPE TABLE OF zmm_load_sloc2,
      lt_load_sloc TYPE TABLE OF zmm_load_sloc2.

DATA: lt_mapping_upd TYPE TABLE OF zwm_pallet_map,
        ls_mapping_log TYPE zwm_mapping_log,
        lv_guid_id     TYPE guid_16.

DATA: ls_lips      TYPE lips,
      ls_lips_tmp  TYPE lips,
      ls_lips_main TYPE lips,
      ls_lips_free TYPE lips,
      ls_lqua      TYPE lqua,
      ls_lqua_su TYPE lqua.
DATA: lt_lips      TYPE TABLE OF lips,
      lt_lips_temp TYPE TABLE OF lips,
      lt_lqua      TYPE TABLE OF lqua.

DATA: lv_no          TYPE posnr_vl,
      lv_num         TYPE i,
      load_no        TYPE string,
      lv_load_no_tmp TYPE zmm_load_sloc2-load_no.

DATA: lv_main_qty TYPE lfimg.
DATA: lv_free_qty TYPE lfimg.

TYPES: BEGIN OF ty_pick,
         werks TYPE werks_d,
         lgort TYPE lgort_d,
         lgnum TYPE lgnum,
         lgtyp TYPE lgtyp,
         lgber TYPE lgber,
       END OF ty_pick.

TYPES: BEGIN OF ty_lein,
         lenum TYPE  lenum,
         lgnum TYPE  lgnum,
         letyp TYPE lvs_letyp,
         lgtyp TYPE lgtyp,
         lgpla TYPE lgpla,
       END OF ty_lein.

TYPES: BEGIN OF ty_str,
         lgort TYPE char4,
       END OF ty_str.

DATA: lv_total_del_qty  TYPE lips-lfimg,
      lv_tanum          TYPE ltak-tanum,
      lv_teilk          TYPE t340d-teilv,
      lv_row            TYPE i,
      lv_su_qty         TYPE menge_d,
      lv_total_qty_ltot TYPE menge_d,
      lv_flag           TYPE c,
      lv_free_found     TYPE c.

DATA: lv_tot_free_qty TYPE menge_d.

DATA: lt_picklist       TYPE TABLE OF ty_pick,
      ls_picklist       TYPE ty_pick,
      lt_load_slocx     TYPE STANDARD TABLE OF zmm_load_sloc2,
      lt_load_slocx_tmp TYPE STANDARD TABLE OF zmm_load_sloc2,
      lt_lein           TYPE TABLE OF ty_lein,
      ls_lein           TYPE ty_lein,
      lt_delit          TYPE l03b_delit_t,
      ls_delit          LIKE LINE OF lt_delit,
      lt_ltak           TYPE STANDARD TABLE OF ltak_vb,
      lt_ltap           TYPE STANDARD TABLE OF  ltap_vb,
      ls_ltap           LIKE LINE OF lt_ltap,
      lt_wmgrp_msg      TYPE STANDARD TABLE OF wmgrp_msg,
      lt_tot_free       TYPE STANDARD TABLE OF zmm_load_sloc2,
      ls_tot_free       TYPE  zmm_load_sloc2,
      lt_mat_sloc       TYPE TABLE OF ty_str.

DATA: lt_messtab TYPE STANDARD TABLE OF bdcmsgcoll,
      ls_messtab TYPE bdcmsgcoll.

DATA: lt_bdcdata TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
      ls_bdcdata TYPE bdcdata.

DATA: ls_scanning_log TYPE zwm_scanning_log.
DATA: lt_scanning_log TYPE TABLE OF zwm_scanning_log.
DATA: lt_scanning_log_tmp TYPE TABLE OF zwm_scanning_log.
FIELD-SYMBOLS: <fs_scanning_log> TYPE zwm_scanning_log.

FIELD-SYMBOLS: <fs_load_slocx> LIKE LINE OF lt_load_slocx.


CLASS lcl_event_handler DEFINITION.
  PUBLIC SECTION.

    METHODS: button_click FOR EVENT button_click OF cl_gui_alv_grid
      IMPORTING es_col_id
                es_row_no.

ENDCLASS.

CLASS lcl_event_handler IMPLEMENTATION.

  METHOD  button_click.
    READ TABLE lt_scanned_list ASSIGNING FIELD-SYMBOL(<fs_scanned_list>) INDEX es_row_no-row_id.
    IF sy-subrc EQ 0.
      IF <fs_scanned_list>-delete_flag EQ 'X'.
        <fs_scanned_list>-delete_flag = ''.
      ELSE.
        <fs_scanned_list>-delete_flag = 'X'.
      ENDIF.
    ENDIF.

    CALL METHOD gr_grid3->refresh_table_display.
  ENDMETHOD.

ENDCLASS.

DATA : gr_event_receiver3     TYPE REF TO lcl_event_handler.
