*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_LOAD_SLOC1..................................*
DATA:  BEGIN OF STATUS_ZMM_LOAD_SLOC1                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_LOAD_SLOC1                .
CONTROLS: TCTRL_ZMM_LOAD_SLOC1
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_LOAD_SLOC1                .
TABLES: ZMM_LOAD_SLOC1                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
