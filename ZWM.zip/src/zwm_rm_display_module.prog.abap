*************************************************************************************
*Object Name              : ZWM_RM_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 06/04/2019.
*************************************************************************************
*Description              : include for module FOR RM DISPLAY.
*************************************************************************************
*********************************************************
*structure definition of lqua.
*********************************************************
MODULE status_9001 OUTPUT.
  SET PF-STATUS 'PF_9001'.
  CASE ok_code.
*********************************************************
*when enter is pressed.
*********************************************************
    "WHEN 'ENTER'.

    IF  flag_enter = 1.
      SPLIT p_scan AT ' ' INTO v_field1 v_field2.
      SHIFT v_field2 LEFT DELETING LEADING space.
      SHIFT v_field1 LEFT DELETING LEADING space.
      SPLIT v_field2 AT ' ' INTO v_field3 v_field4.
      SHIFT v_field3 LEFT DELETING LEADING space.
      SHIFT v_field4 LEFT DELETING LEADING space.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*      SELECT SINGLE lgnum,                    "validating data from lqua
*                    lqnum,
*                    matnr,
*                    charg,
*                    lgtyp
*      FROM lqua
*      INTO @DATA(wa_lqua2)
*      WHERE ( matnr EQ @v_field1
*      OR    matnr EQ @v_field3 )
*      AND   ( lgtyp EQ @p_lgtyp ).

SELECT LGNUM ,
 LQNUM , MATNR , CHARG , LGTYP FROM LQUA INTO @DATA(WA_LQUA2) UP TO 1 ROWS WHERE ( MATNR EQ @V_FIELD1 OR MATNR EQ @V_FIELD3 ) AND ( LGTYP EQ @P_LGTYP )
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


      IF sy-subrc NE 0.
        MESSAGE 'Material storage type combination is not correct'  TYPE 'I' DISPLAY LIKE 'E'.
        flag_enter = 2.
        LEAVE LIST-PROCESSING.
      ENDIF.
      if v_field1 = wa_lqua2-matnr.
        v_field1 = wa_lqua2-matnr.
        v_field4 = v_field4.
        v_field3 = v_field3.
      else.
        v_field3 = v_field4.
        v_field4 = v_field1.
        v_field1 = wa_lqua2-matnr.

     endif.
      SELECT SINGLE lgnum,                          "validating data from lqua
                    lqnum,
                    matnr,
                    charg,
                    lgtyp
      FROM lqua
      INTO @DATA(wa_lqua1)
      WHERE ( charg EQ @v_field4 )
      AND   ( lgtyp EQ @p_lgtyp ).
      IF sy-subrc NE 0.
        MESSAGE 'batch storage type combination  is not correct' TYPE 'I' DISPLAY LIKE 'E'. "error message.
        flag_enter = 2.
        LEAVE LIST-PROCESSING.
      ENDIF.

      IF v_field3 = ' '.
        MESSAGE 'quantity is nill' TYPE 'I' DISPLAY LIKE 'E'. "error message if quanitiy is nill.
        flag_enter = 2.
        LEAVE LIST-PROCESSING.
      ENDIF.
      v_lgtyp = p_lgtyp.
ENDIF.
      IF flag_enter EQ 1.
        CALL SCREEN 9002.
      ENDIF.
  ENDCASE.
ENDMODULE.
*********************************************************
*PBO of screen 9001
*********************************************************
MODULE user_command_9001 INPUT.
  CASE ok_code.
    WHEN 'BACK'.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT'.
      LEAVE PROGRAM.
    when 'ENTER'.
      FLAG_ENTER = 1.

  ENDCASE.
ENDMODULE.
*********************************************************
*PBO of screen 9002
*********************************************************
MODULE status_9002 OUTPUT.
  SET PF-STATUS 'PF_9002'.

  SELECT matnr                               "selecting data from LQUA.
         charg
         lgnum
         lqnum
         bestq
         lgtyp
         lgpla
  FROM lqua
  INTO TABLE it_lqua
  WHERE ( matnr EQ v_field1 )
  "OR    matnr EQ v_field3 )
  AND  ( charg EQ v_field4 )
  "OR    charg EQ v_field1 )
  AND  ( lgtyp EQ p_lgtyp ).
******ATC BEGIN OF CHANGE 27.02.2026 ******
    Sort it_lqua.
******ATC END OF CHANGE 27.02.2026 ******
  IF it_lqua IS NOT INITIAL.
    LOOP AT it_lqua INTO wa_lqua.                      "looping it_lqua .
      CONCATENATE v_lgpla wa_lqua-lgpla INTO v_lgpla SEPARATED BY ' '.
      REPLACE ALL OCCURRENCES OF REGEX '(\<\w+\>) \1' IN v_lgpla WITH '$1' IGNORING CASE. "replacing duplicate bins.
      AT NEW charg.
        v_matnr = wa_lqua-matnr.
        v_charg = wa_lqua-charg.
      ENDAT.
      v_bestq = wa_lqua-bestq.
    ENDLOOP.
    if v_field1 eq v_matnr.
      v_pack = v_field3.
    elseif v_field1 eq v_charg.
      v_pack = v_field4.
    endif.

    SELECT SINGLE matnr,                       "selecting material description
                  spras,
                  maktx
    FROM makt
    INTO @DATA(wa_makt)
    WHERE matnr EQ @v_matnr
    AND   spras EQ @sy-langu.

    v_desc = wa_makt-maktx.

    SELECT SINGLE matnr,                        "selecting data from mchl
                  charg,
                  vfdat,
                  hsdat,
                  lifnr
    FROM mch1
    INTO @DATA(wa_mch1)
    WHERE matnr EQ @v_matnr
    AND   charg EQ @v_charg.
    v_lifnr = wa_mch1-lifnr.
    CONCATENATE wa_mch1-vfdat+6(2) wa_mch1-vfdat+4(2) wa_mch1-vfdat+0(4) INTO v_exp SEPARATED BY '.'.     "concatinating date in DD.MM.YYYY format
    CONCATENATE wa_mch1-hsdat+6(2) wa_mch1-hsdat+4(2) wa_mch1-hsdat+0(4) INTO v_mfd SEPARATED BY '.'.     "concatinating date in DD.MM.YYYY format


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE matnr,                         "selecting data from mchb
*                  werks,
*                  lgort,
*                  charg,
*                  clabs
*    FROM mchb
*    INTO @DATA(wa_mchb)
*    WHERE matnr EQ @v_matnr
*    AND   charg EQ @v_charg.

SELECT MATNR ,
 WERKS , LGORT , CHARG , CLABS FROM MCHB INTO @DATA(WA_MCHB) UP TO 1 ROWS WHERE MATNR EQ @V_MATNR AND CHARG EQ @V_CHARG
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    v_total = wa_mchb-clabs.

    SELECT SINGLE lifnr,                          "selecting data from lfa1.
                  name1
    FROM lfa1
    INTO @DATA(wa_lfa1)
    WHERE lifnr EQ @v_lifnr.

    v_name = wa_lfa1-name1.

    SHIFT v_matnr LEFT DELETING LEADING '0'.
  ENDIF.
ENDMODULE.

MODULE user_command_9002 INPUT.
  CASE ok_code.
*********************************************************
*when back button is pressed.
*********************************************************
    WHEN 'BACK'.                                                       "clearing all variables .
      CLEAR : flag_enter,ok_code,p_lgtyp,p_scan,v_bestq,v_charg,v_desc,v_exp,v_field1,v_field2,v_field3,v_field4,
              v_lgpla,v_lgtyp,v_lifnr,v_matnr,v_mfd,v_name,v_total,wa_lqua,v_pack,wa_lqua1,wa_lqua2.
      clear : wa_mch1,wa_lfa1,wa_mchb,wa_makt.
      REFRESH it_lqua.
     " CALL TRANSACTION 'ZWM_LOAD_N'.
  ENDCASE.


ENDMODULE.
