*&---------------------------------------------------------------------*
*& Report ZWM_SU_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zwm_su_upload.

INCLUDE zwm_su_upload_top.
INCLUDE zwm_su_upload_form.

INITIALIZATION.
  btn_tpl = '@49@ Download Template'.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'DTL'.
      PERFORM download_template.
  ENDCASE.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_flname.
  PERFORM value_request.

START-OF-SELECTION.

PERFORM validations.

PERFORM upload_excel.

PERFORM create_data.
