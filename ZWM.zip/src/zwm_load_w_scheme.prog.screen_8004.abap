PROCESS BEFORE OUTPUT.

  MODULE status_8004.

  LOOP.
    MODULE transp_itab_out_8004.
  ENDLOOP.

PROCESS AFTER INPUT.

  LOOP.
    MODULE transp_itab_in_8004.
  ENDLOOP.

  MODULE user_command_8004.
