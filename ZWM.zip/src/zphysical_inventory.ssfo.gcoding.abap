READ TABLE IT_final ASSIGNING FIELD-SYMBOL(<fs_final>)
INDEX 1.
   gv_wh = <fs_final>-lgnum.
  gv_inv = <fs_final>-ivnum.
  GV_TYP = <fs_final>-lgtyp.
gv_plant = <fs_final>-werks.
  gv_loc = <fs_final>-lgort.





















