*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_W_SCHEME_STATUS_8110
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_8110  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8110 OUTPUT.
  SET PF-STATUS 'ZMM_8110'.
*  SET TITLEBAR 'xxx'.
  fill8110 = cnt110.
ENDMODULE.

*    gv_cnt = gv_cnt + 1.

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8110  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8110 INPUT.
  DATA: lv_cntxx TYPE i,
        lv_date  TYPE datum,
        loadno   TYPE zmm_load_sloc2-load_no,
        lt_loadx TYPE TABLE OF ty_load.
  CLEAR: lv_date, lv_cntxx.
  CASE sy-ucomm.
    WHEN 'BACK'.
      CALL SCREEN 8001.
    WHEN 'SELECT'.
      clear cnt113.
      FREE: lt_loadx[],lt_8005,lw_8005.
      lt_loadx[] = lt_load[].
      DELETE lt_loadx WHERE cnt = abap_false.
      DESCRIBE TABLE lt_loadx LINES lv_cntxx.
      IF lv_cntxx = '1'.
        LOOP AT lt_load INTO lw_load WHERE cnt = 'X'.
          loadno = lw_load-load_no.
          EXIT.
        ENDLOOP.
        lv_date = sy-datum - 5.
        SELECT load_no load_item su_no load_status
         FROM zmm_load_sloc2
         INTO CORRESPONDING FIELDS OF TABLE lt_sloc8110
         WHERE load_no    =  loadno
          AND  entry_date GE lv_date
          AND  load_status = 'I'.
        CLEAR: lv_date.
        LOOP AT lt_sloc8110 INTO lw_sloc8110.
          lw_8005-lenum = lw_sloc8110-su_no .
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
            EXPORTING
              input  = lw_8005-lenum
            IMPORTING
              output = lw_8005-lenum.
          APPEND lw_8005 TO lt_8005.
          CLEAR: lw_8005, lw_sloc8110.
        ENDLOOP.
        DESCRIBE TABLE lt_8005 LINES cnt113.
        condense cnt113.
        cnt5 = cnt113.
        load_no = loadno.
        CALL SCREEN 8005.
      ENDIF.
    WHEN 'NEXTV'.
      fill8110 = fill8110 + 5.
*      line8110 = line8110 + 1.
      line8110 = line8110 + lines8110.
      limit8110 = fill8110 - lines8110.
      IF line8110 > limit8110.
        line8110 = limit8110.
      ENDIF.
    WHEN 'PREVV'.
      line8110 = line8110 - lines8110. "1.
      IF line8110 < 0.
        line8110 = 0.
      ENDIF.
    WHEN OTHERS.
  ENDCASE.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_OUT_8110  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_out_8110 OUTPUT.
*  DATA: lw_8110d TYPE ty_load.
  idx8110 = sy-stepl + line8110.
  READ TABLE lt_load INTO lw_load INDEX idx8110.                     "lw_8110d INDEX idx8110.
*  IF sy-subrc = 0.
*    lw_load = lt_load[ idx8110 ].
*  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_IN_8110  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_in_8110 INPUT.
  lines8110 = sy-loopc.
  idx8110 = sy-stepl + line8110.
  MODIFY lt_load FROM lw_load INDEX idx8110.
ENDMODULE.
