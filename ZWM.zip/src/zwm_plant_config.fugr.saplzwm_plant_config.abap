*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_PLANT_CONFIGTOP.              " Global Declarations
  INCLUDE LZWM_PLANT_CONFIGUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_PLANT_CONFIGF...              " Subroutines
* INCLUDE LZWM_PLANT_CONFIGO...              " PBO-Modules
* INCLUDE LZWM_PLANT_CONFIGI...              " PAI-Modules
* INCLUDE LZWM_PLANT_CONFIGE...              " Events
* INCLUDE LZWM_PLANT_CONFIGP...              " Local class implement.
* INCLUDE LZWM_PLANT_CONFIGT99.              " ABAP Unit tests
  INCLUDE LZWM_PLANT_CONFIGF00                    . " subprograms
  INCLUDE LZWM_PLANT_CONFIGI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
