*&---------------------------------------------------------------------*
*& Report ZWM_SU_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zmm_su_number.

INCLUDE ZMM_SU_NUMBER_TOP.
*INCLUDE zwm_su_upload_top.
INCLUDE ZMM_SU_NUMBER_FORM.
*INCLUDE zwm_su_upload_form.

INITIALIZATION.
  btn_tpl = '@49@ Download Template'.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'DTL'.
      PERFORM download_template.
  ENDCASE.

START-OF-SELECTION.

PERFORM validations.

PERFORM upload_excel.

PERFORM create_data.
PERFORM display_log.
