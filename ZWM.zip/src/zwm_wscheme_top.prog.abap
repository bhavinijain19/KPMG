*&---------------------------------------------------------------------*
*& Include          ZWM_WSCHEME_TOP
*&---------------------------------------------------------------------*
TABLES: zmm_load_sloc2.

TYPES: BEGIN OF lty_final,
         load_no        TYPE zmm_load_sloc2-load_no,
         load_item      TYPE zmm_load_sloc2-load_item,
         su_no          TYPE zmm_load_sloc2-su_no,
         obd_no         TYPE zmm_load_sloc2-obd_no,
         obd_lineitem   TYPE zmm_load_sloc2-obd_lineitem,
         obd_headitem   TYPE zmm_load_sloc2-obd_headitem,
         entry_date     TYPE zmm_load_sloc2-entry_date,
         storage_loc    TYPE zmm_load_sloc2-storage_loc,
         plant          TYPE zmm_load_sloc1-plant,
         matnr          TYPE zmm_load_sloc2-matnr,
         batch_no       TYPE zmm_load_sloc2-batch_no,
         quantity       TYPE zmm_load_sloc2-quantity,
         uom            TYPE zmm_load_sloc2-uom,
         bin_loc        TYPE zmm_load_sloc2-bin_loc,
         load_status    TYPE zmm_load_sloc2-load_status,
         su_qty         TYPE zmm_load_sloc2-su_qty,
         to_create_date TYPE zmm_load_sloc2-to_create_date,
         to_no          TYPE zmm_load_sloc2-to_no,
         free_qty       TYPE zmm_load_sloc2-free_qty,
         err_msg        TYPE zmm_load_sloc2-err_msg,
         maktx          TYPE makt-maktx,
       END OF lty_final.

DATA: lt_final  TYPE TABLE OF lty_final,
      lwa_final TYPE lty_final.

TYPE-POOLS: slis.

DATA: lt_fcat TYPE slis_t_fieldcat_alv,
      ls_fcat TYPE slis_fieldcat_alv.
