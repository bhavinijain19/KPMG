*************************************************************************************
*Object Name              : ZWM_LOAD_DELETE.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 12/05/2019.
*************************************************************************************
*Description              : class declaration and implementaion include.
*************************************************************************************

*********************************************************
*class definition.
*********************************************************

CLASS load_delete DEFINITION.
  PUBLIC SECTION.
    METHODS : validation,
      fetch_data,
      display,
      fieldcat,
      handle_toolbar_set
                  FOR EVENT toolbar OF cl_gui_alv_grid
        IMPORTING e_object
                  e_interactive,
      handle_user_command
                  FOR EVENT user_command OF cl_gui_alv_grid
        IMPORTING e_ucomm.

ENDCLASS.
*********************************************************
*class implementation.
*********************************************************
CLASS load_delete IMPLEMENTATION.
*********************************************************
*method for validating user input.
*********************************************************
  METHOD validation.

    SELECT SINGLE load_no,
                  load_item,
                  su_no
    FROM zmm_load_sloc1
    INTO @DATA(wa_zmm_load_sloc1)
    WHERE load_no = @p_load.

    IF wa_zmm_load_sloc1 IS INITIAL.

      SELECT SINGLE load_no,
                    load_item,
                    su_no
      FROM zmm_load_sloc2
      INTO @DATA(wa_zmm_load_sloc2)
      WHERE load_no = @p_load.

      IF wa_zmm_load_sloc2 IS INITIAL.

        MESSAGE : 'Load No. Doesnot Exist' TYPE 'E'.
      ENDIF.
    ENDIF.

  ENDMETHOD.
*********************************************************
*method to fetching data.
*********************************************************
  METHOD fetch_data.

    SELECT * FROM zmm_load_sloc1
    INTO CORRESPONDING FIELDS OF TABLE it_load
    WHERE load_no EQ p_load.

    IF sy-subrc NE 0.
      SELECT * FROM zmm_load_sloc2
      INTO CORRESPONDING FIELDS OF TABLE it_load
      WHERE load_no EQ p_load.
    ENDIF.

    IF it_load IS NOT INITIAL.

      SELECT    user_id,
                werks
         FROM zwm_uid_plant
         INTO TABLE @DATA(it_zwm_uid_plant)
         FOR ALL ENTRIES IN @it_load
            WHERE user_id EQ @sy-uname
            AND   werks   EQ @it_load-plant.

      SELECT * FROM zwm_plant_config INTO TABLE lt_plant_config FOR ALL ENTRIES IN it_load
        WHERE plant = it_load-plant.

    ENDIF.


    LOOP AT it_load ASSIGNING FIELD-SYMBOL(<fs_load>).

      IF <fs_load> IS ASSIGNED.

        READ TABLE it_zwm_uid_plant ASSIGNING FIELD-SYMBOL(<fs_zwm_uid_plant>) WITH KEY user_id = sy-uname
                                                                                        werks   = <fs_load>-plant.
        IF <fs_zwm_uid_plant> IS ASSIGNED.

          APPEND INITIAL LINE TO it_final ASSIGNING FIELD-SYMBOL(<fs_final>).
          <fs_final>-load_no         = <fs_load>-load_no.
          <fs_final>-load_item       = <fs_load>-load_item.
          <fs_final>-su_no           = <fs_load>-su_no.
          <fs_final>-obd_no          = <fs_load>-obd_no.
          <fs_final>-obd_lineitem    = <fs_load>-obd_lineitem .
          <fs_final>-obd_headitem    = <fs_load>-obd_headitem.
          <fs_final>-entry_date      = <fs_load>-entry_date.
          <fs_final>-storage_loc     = <fs_load>-storage_loc.
          <fs_final>-plant           = <fs_load>-plant.
          <fs_final>-matnr           = <fs_load>-matnr.
          <fs_final>-batch_no        = <fs_load>-batch_no.
          <fs_final>-quantity        = <fs_load>-quantity.
          <fs_final>-uom             = <fs_load>-uom.
          <fs_final>-bin_loc         = <fs_load>-bin_loc.
          <fs_final>-load_status     = <fs_load>-load_status.
          <fs_final>-su_qty          = <fs_load>-su_qty.
          <fs_final>-to_create_date  = <fs_load>-to_create_date .
          <fs_final>-to_no           = <fs_load>-to_no.


        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD handle_toolbar_set.

    CLEAR ty_toolbar.

    ty_toolbar-function = 'DELETE'. "name of btn to catch click
    ty_toolbar-butn_type = 0.
    ty_toolbar-text = 'DELETE'.

    APPEND ty_toolbar TO e_object->mt_toolbar.

  ENDMETHOD.
*********************************************************
*method for preparing field catalog.
*********************************************************
  METHOD fieldcat.
    DATA: ls_fcat TYPE lvc_s_fcat.


    CLEAR ls_fcat.
    ls_fcat-reptext = 'Load Number'.
    ls_fcat-fieldname = 'LOAD_NO'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Load Item'.
    ls_fcat-fieldname = 'LOAD_ITEM'.
    ls_fcat-outputlen  = 6.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Storage Unit Number'.
    ls_fcat-fieldname = 'SU_NO'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Delivery'.
    ls_fcat-fieldname = 'OBD_NO'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'OBD Line Item'.
    ls_fcat-fieldname = 'OBD_LINEITEM'.
    ls_fcat-outputlen  = 6.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'OBD Header Item'.
    ls_fcat-fieldname = 'OBD_HEADITEM'.
    ls_fcat-outputlen  = 6.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Date'.
    ls_fcat-fieldname = 'ENTRY_DATE'.
    ls_fcat-outputlen  = 8.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Storage Location'.
    ls_fcat-fieldname = 'STORAGE_LOC'.
    ls_fcat-outputlen  = 4.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Plant'.
    ls_fcat-fieldname = 'PLANT'.
    ls_fcat-outputlen  = 4.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Material Number'.
    ls_fcat-fieldname = 'MATNR'.
    ls_fcat-outputlen  = 18.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Batch Number'.
    ls_fcat-fieldname = 'BATCH_NO'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Actual quantity delivered (in sales units)'.
    ls_fcat-fieldname = 'QUANTITY'.
    ls_fcat-outputlen  = 13.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Base Unit of Measure'.
    ls_fcat-fieldname = 'UOM'.
    ls_fcat-outputlen  = 3.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Storage Bin'.
    ls_fcat-fieldname = 'BIN_LOC'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Loading Status'.
    ls_fcat-fieldname = 'LOAD_STATUS'.
    ls_fcat-outputlen  = 2.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Available stock'.
    ls_fcat-fieldname = 'SU_QTY'.
    ls_fcat-outputlen  = 13.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Creation Date of Transfer Order'.
    ls_fcat-fieldname = 'TO_CREATE_DATE'.
    ls_fcat-outputlen  = 8.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = 'Transfer Order Number'.
    ls_fcat-fieldname = 'TO_NO'.
    ls_fcat-outputlen  = 10.
    APPEND ls_fcat TO fieldcat.

  ENDMETHOD.
***********************************************************
*method to display alv.
***********************************************************
  METHOD display.

    CALL SCREEN 0101.

  ENDMETHOD.

***********************************************************
*method for handling user command.
***********************************************************
  METHOD handle_user_command.

    DATA: ans(1) TYPE c.
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = 'Warning Message'
        text_question         = 'Do you want to delete?'
        text_button_1         = 'Yes'
        text_button_2         = 'No'
        default_button        = '1'
        display_cancel_button = ''
      IMPORTING
        answer                = ans
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.


    IF ans EQ 1.
      DATA : li_selected_rows TYPE  lvc_t_row,
             lw_sel           TYPE  lvc_s_row.

      CASE e_ucomm.

        WHEN 'DELETE'.

          CALL METHOD alv_grid->get_selected_rows                          "fetching selected rows
            IMPORTING
              et_index_rows = li_selected_rows.

          IF li_selected_rows IS NOT INITIAL.

            LOOP AT li_selected_rows INTO lw_sel.
              "Added by Srimathi - start
              READ TABLE it_load INTO DATA(ls_load) INDEX lw_sel-index."#EC CI_NOORDER
              IF sy-subrc EQ 0.
                READ TABLE lt_plant_config TRANSPORTING NO FIELDS WITH KEY plant = ls_load-plant.
                IF sy-subrc EQ 0.
                  APPEND ls_load TO it_load_tmp.
                ENDIF.
              ENDIF.
              "Added by Srimathi - end
              READ TABLE it_load ASSIGNING FIELD-SYMBOL(<fs_load>) INDEX lw_sel-index. "#EC CI_NOORDER

              IF sy-subrc EQ 0.
                DELETE zmm_load_sloc1 FROM <fs_load>.

                IF sy-subrc NE 0.
                  DELETE zmm_load_sloc2 FROM <fs_load>.
                  DELETE zmm_load_sloc2tp FROM <fs_load>.

                ENDIF.
              ENDIF.
            ENDLOOP.

            "Added by Srimathi - start
            IF it_load_tmp[] IS NOT INITIAL.
              SELECT werks AS plant,
                      palletno AS pallet_no,
                      lenum AS su_no,
                      lgnum AS warehouse_no
                FROM zwm_su
                FOR ALL ENTRIES IN @it_load_tmp
                  WHERE werks = @it_load_tmp-plant
                    AND lenum = @it_load_tmp-su_no
                    AND palletno NE ''
                INTO TABLE @DATA(lt_su).
              IF lt_su IS NOT INITIAL.
                lt_su_upd = VALUE #( FOR ls_su IN lt_su
                                      ( warehouse_type = 'Plant'
                                        warehouse_no   = ls_su-warehouse_no
                                        pallet_no      = ls_su-pallet_no
                                        su_no          = ls_su-su_no )
                                    ).
                IF lt_su_upd[] IS NOT INITIAL.
                  MODIFY zwm_pallet_map  FROM TABLE lt_su_upd.
                ENDIF.
              ENDIF.
            ENDIF.
            "Added by Srimathi - end

            MESSAGE 'Sucessfully Deleted' TYPE 'I'.
            LEAVE TO SCREEN 0.
            CLEAR it_final.
            CLEAR it_load.
          ENDIF.

      ENDCASE.

    ENDIF.
  ENDMETHOD.
ENDCLASS.
***********************************************************
*PBO of screen 0101.
***********************************************************
MODULE status_0101 OUTPUT.
  SET PF-STATUS 'PF_0101'.
  SET TITLEBAR 'T_0101'.


  CREATE OBJECT alv_container                                    "creating object of container.
    EXPORTING
      container_name = 'ALV_CONTAINER'.

  CREATE OBJECT alv_grid                                         "creating object of grid.
    EXPORTING
      i_parent = alv_container.

  obj->fieldcat( ).                                              "calling fieldcat method from class object.

  it_layout-cwidth_opt = abap_true.
  it_layout-zebra = abap_true.
  it_layout-col_opt = abap_true.
  it_layout-box_fname = 'SEL'.
  it_layout-sel_mode = 'A'.


  SET HANDLER obj->handle_toolbar_set FOR alv_grid.              "setting handler for toolbar

  SET HANDLER obj->handle_user_command FOR alv_grid.             "setting toolbar for user command.


  CALL METHOD alv_grid->set_table_for_first_display              "calling method for alv display.
    EXPORTING
      is_layout       = it_layout
    CHANGING
      it_outtab       = it_final
      it_fieldcatalog = fieldcat.
ENDMODULE.

***********************************************************
*PAI of screen 0101.
***********************************************************
MODULE user_command_0101 INPUT.

  CASE sy-ucomm.

    WHEN 'BACK' OR 'CANC'.
      CLEAR it_final.
      CLEAR it_load.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT'.
      CLEAR it_final.
      CLEAR it_load.
      LEAVE PROGRAM.
    WHEN 'DELETE'.
      obj->handle_user_command( ).
  ENDCASE.

ENDMODULE.
