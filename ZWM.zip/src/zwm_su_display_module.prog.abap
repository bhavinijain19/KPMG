*************************************************************************************
*Object Name              : ZWM_SU_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 05/04/2019.
*************************************************************************************
*Description              : ZWM_SU_display_module include..
*************************************************************************************
 MODULE status_9001 OUTPUT.
   SET PF-STATUS 'PF_9001'.

  " CASE ok_code.
*********************************************************
*when enter button is pressed.
*********************************************************
     "WHEN 'ENTER'.
         if flag_enter eq 1.

         SPLIT p_lenum AT ' ' INTO v_matnr v_lenum.                      "spliiting material and su number.
          SHIFT v_lenum LEFT DELETING LEADING space.
         p_lenum = v_lenum.

         CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
           EXPORTING
             input  = v_lenum
           IMPORTING
             output = v_lenum.
*********************************************************
*validating user input.
*********************************************************
         SELECT SINGLE lgnum,
                       lqnum,
                       lenum
         FROM lqua
         INTO @DATA(wa_lqua)
         WHERE lenum EQ @v_lenum.
         IF sy-subrc NE 0.
           MESSAGE 'Enter correct box no' TYPE 'I'.
           LEAVE LIST-PROCESSING.
           flag_enter = 2.

         ENDIF.
         endif.
*********************************************************
*calling screen 9002.
*********************************************************
       if flag_enter eq 1.
          call SCREEN 9002.
       endif.

  " ENDCASE.
 ENDMODULE.
*********************************************************
*PAI for screen 9001.
*********************************************************
 MODULE user_command_9001 INPUT.
   CASE ok_code.
     WHEN 'BACK'.
       LEAVE TO SCREEN 0.
     WHEN 'EXIT'.
       LEAVE PROGRAM.
     when 'ENTER'.
       flag_enter = 1.
   ENDCASE.
 ENDMODULE.
*********************************************************
*PBO for screen 9002.
*********************************************************
 MODULE status_9002 OUTPUT.
   SET PF-STATUS 'PF_9002'.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*   SELECT SINGLE lgnum                                        "selecting data from lqua.
*                 lqnum
*                 matnr
*                 werks
*                 charg
*                 bestq
*                 lgpla
*                 meins
*                 verme
*                 lenum
*   FROM  lqua
*   INTO  wa_lqua1
*   WHERE lenum EQ v_lenum.

SELECT LGNUM
 LQNUM MATNR WERKS CHARG BESTQ LGPLA MEINS VERME LENUM FROM LQUA INTO WA_LQUA1 UP TO 1 ROWS WHERE LENUM EQ V_LENUM
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


   IF sy-subrc EQ 0.                                         "selecting data from makt.
     SELECT SINGLE matnr
                   spras
                   maktx
     FROM makt
     INTO wa_makt
     WHERE matnr EQ wa_lqua1-matnr
     AND   spras eq sy-langu.

     IF sy-subrc EQ 0.

       SELECT SINGLE matnr                                "selectimg data from mchl
                     charg
                     vfdat
                     hsdat
       FROM mch1
       INTO wa_mch1
       WHERE matnr EQ wa_lqua1-matnr
       AND   charg EQ wa_lqua1-charg.

     ENDIF.
   ENDIF.
   CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'           "removing leading zeroes
     EXPORTING
       input         = v_lenum
     IMPORTING
       OUTPUT        = v_lenum.

   CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'           "removing leading zeroes
     EXPORTING
       input         = wa_lqua1-matnr
     IMPORTING
       OUTPUT        = wa_lqua1-matnr.

concatenate wa_mch1-vfdat+6(2) wa_mch1-vfdat+4(2) wa_mch1-vfdat+0(4) into v_vfdat separated by '.'.     "concatinating date in DD.MM.YYYY format
concatenate wa_mch1-hsdat+6(2) wa_mch1-hsdat+4(2) wa_mch1-hsdat+0(4) into v_hsdat separated by '.'.     "concatinating date in DD.MM.YYYY format
v_verme = wa_lqua1-verme.
v1_verme = v_verme.


 ENDMODULE.
*********************************************************
*PAI for 9002 screen.
*********************************************************
 MODULE user_command_9002 INPUT.

  CASE ok_code.
*********************************************************
*when back button is pressed.
*********************************************************
     WHEN 'BACK'.
       CLEAR : flag_enter,p_lenum,v_lenum,v_matnr,wa_lqua1,wa_makt,wa_mch1,v_hsdat,v_vfdat,v_verme,v1_verme,v_matnr.
       "call TRANSACTION 'ZWM_LOAD_N'.
  ENDCASE.
 ENDMODULE.
