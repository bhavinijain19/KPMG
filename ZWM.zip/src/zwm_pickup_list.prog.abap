*************************************************************************************
*Object Name              : ZWM_Pickup_LIST.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 1/04/2019.
*************************************************************************************
*Description              :Smartform Driver program for pickup list.
*************************************************************************************
REPORT ZWM_PICKUP_LIST.

include : ZWM_PICKUP_LIST_top,                "data delcaration include
          ZWM_PICKUP_LIST_scr,                "screen declaration include
          ZWM_PICKUP_LIST_cls.                "class declaration and implementation include.

*********************************************************
*initialization event.
*********************************************************
INITIALIZATION.

  CREATE OBJECT obj.                     "creating object of class

*********************************************************
*at selection screen event.
*********************************************************
AT SELECTION-SCREEN.

  obj->validation( ).                    "calling class method for validating input.

*********************************************************
*start of selection event.
*********************************************************
START-OF-SELECTION.

 obj->fetch_data( ).                    "calling class method to getdata.
 obj->smartform( ).                     "calling smartform.
