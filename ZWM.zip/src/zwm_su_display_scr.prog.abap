*&---------------------------------------------------------------------*
*&  Include           ZWM_HU_DISPLAY_SCR
*&---------------------------------------------------------------------*
*********************************************************
*selection screen declaration
*********************************************************
*selection-SCREEN BEGIN OF SCREEN 9000 as SUBSCREEN.
*
*  PARAMETERS : p_lenum TYPE char25 OBLIGATORY.
*
*SELECTION-SCREEN END OF SCREEN 9000.
