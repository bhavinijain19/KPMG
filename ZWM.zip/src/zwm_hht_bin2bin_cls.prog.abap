*************************************************************************************
*Object Name              : ZWM_HHT_BIN2BIN_CLS.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : PBO,PAI,MOdule iclude
*************************************************************************************

*********************************************************
*class definition.
*********************************************************
MODULE status_9001 OUTPUT.
  SET PF-STATUS 'PF_9001'.
  CASE ok_code.
    WHEN 'BACK'.
      refresh : it_lqua,it_lqua1,it_bdcdata.
      clear wa_bdcdata.
      CLEAR : p_lgtyps,
      gv_tanum,
      p_lgtypd ,
      v_lgnum ,
      v_lgtyp ,
      v_lgpla ,
      p_lgplas,
      v1_lgtyp ,
      v1_lgpla ,
      v_lgber ,
      p_lgber,
      p_lgnum,
      p_lgplad,
      wa_ltap_creat,
      it_ltap_creat.

    WHEN 'ENTER'.

      IF flag_enter EQ 1.
        SELECT SINGLE lgnum lgtyp lgpla
            FROM lagp
            INTO v_lagp
            WHERE lgnum EQ p_lgnum
            AND   lgtyp EQ p_lgtyps
            AND   lgpla EQ p_lgplas.

        IF sy-subrc NE 0.
          flag = 1.
        ENDIF.

        SELECT SINGLE lgtyp
                      lgpla
                      lgber
        FROM lagp
        INTO v_lagp1
        WHERE  lgpla EQ p_lgplad
        AND   lgber  EQ p_lgber.
        IF sy-subrc = 0.
          flag = 2.
          v_lgnum = p_lgnum.
          v_lgpla = p_lgplas.
          v_lgtyp = p_lgtyps.
          v1_lgtyp = p_lgtypd.
          v_lgber = p_lgber.
          v1_lgpla = p_lgplad.
        ENDIF.
        IF sy-subrc NE 0.

          flag2 = 1.
        ENDIF.
      ENDIF.
      IF flag_enter EQ 0.
        p_lgtypd = p_lgtyps.
        flag_enter = 1.
      ENDIF.

  ENDCASE.
  IF flag = 1.
    MESSAGE e000(zbin_to_bin).
  ELSEIF flag2 = 1.
    MESSAGE e001(zbin_to_bin).
  ENDIF.
  IF flag = 2.
    CALL SCREEN 9002.
  ENDIF.


ENDMODULE.
MODULE selection.
  IF check EQ 'X'.
    IF flag_move = 1.
      APPEND wa_lqua TO it_lqua1.
    ENDIF.
  ENDIF.
  clear check.
ENDMODULE.
***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.

MODULE user_command_9001 INPUT.
  CASE ok_code.
    WHEN 'BACK'.
      LEAVE TO SCREEN 0.
    WHEN 'EXIT' OR 'CANCEL'.
      LEAVE PROGRAM.
  ENDCASE.
ENDMODULE.

MODULE status_9002 OUTPUT.
  SET PF-STATUS 'PF_9002'.
  if flag = 2.
  SELECT lgnum                                   "fetching data from table LQUA.
         lqnum
         matnr
         werks
         charg
         bestq
         sobkz
         sonum
         lgtyp
         lgpla
         letyp
         meins
         verme
         lenum
         lgort
  FROM lqua
  INTO TABLE it_lqua
  WHERE     lgnum EQ v_lgnum
        AND lgpla EQ v_lgpla
        AND lgtyp EQ v_lgtyp.

  IF it_lqua IS NOT INITIAL.                         "initial check
    SORT it_lqua BY lgnum.

    SELECT werks                                     "fetching data from table zwm_picklist.
           lgort
           lgnum
           lgber
    FROM zwm_picklist
    INTO TABLE it_zwm_picklist
    FOR ALL ENTRIES IN it_lqua
    WHERE werks EQ it_lqua-werks
    AND   lgort EQ it_lqua-lgort
    AND   lgnum EQ it_lqua-lgnum.
  ENDIF.
  flag = 3.
endif.
  IF flag_move EQ 1 and it_lqua1 is NOT INITIAL.
    CLEAR wa_lqua.
    LOOP AT it_lqua1 INTO wa_lqua.
      wa_ltap_creat-matnr = wa_lqua-matnr.
      wa_ltap_creat-werks = wa_lqua-werks.
      wa_ltap_creat-lgort = wa_lqua-lgort.
      wa_ltap_creat-charg = wa_lqua-charg.
      wa_ltap_creat-anfme = wa_lqua-verme.
      wa_ltap_creat-altme = wa_lqua-meins.
      wa_ltap_creat-vltyp = v_lgtyp.
      wa_ltap_creat-vlpla = v_lgpla.
      wa_ltap_creat-vlenr = wa_lqua-lenum.
      wa_ltap_creat-nltyp = v1_lgtyp.
      wa_ltap_creat-nlber = v_lgber.
      wa_ltap_creat-nlpla = v1_lgpla.
      wa_ltap_creat-nlenr = wa_lqua-lenum.


      READ TABLE it_zwm_picklist INTO wa_zwm_picklist BINARY SEARCH WITH KEY  werks = wa_lqua-werks
                                                                              lgort = wa_lqua-lgort
                                                                              lgnum = wa_lqua-lgnum.

      IF sy-subrc EQ 0.

        wa_ltap_creat-vlber = wa_zwm_picklist-lgber.

      ENDIF.


      APPEND wa_ltap_creat TO it_ltap_creat.                 "appending data to it_ltap_creat
      flag_ltap_creat = 1.
    ENDLOOP.
  ELSEif flag_validate = 1.
    MESSAGE i002(zbin_to_bin).                                "message display if nothing is selected.
    LEAVE LIST-PROCESSING.
    flag_confirm = 1.
endif.

  IF flag_confirm EQ 0 AND flag_move = 1 AND flag_ltap_creat = 1.
    CALL FUNCTION 'L_TO_CREATE_MULTIPLE'                      "calling FM for TO creation
      EXPORTING
        i_lgnum                = v_lgnum
        i_bwlvs                = '999'
        i_commit_work          = 'X'
        i_bname                = sy-uname
      IMPORTING
        e_tanum                = gv_tanum
      TABLES
        t_ltap_creat           = it_ltap_creat
      EXCEPTIONS
        no_to_created          = 1
        bwlvs_wrong            = 2
        betyp_wrong            = 3
        benum_missing          = 4
        betyp_missing          = 5
        foreign_lock           = 6
        vltyp_wrong            = 7
        vlpla_wrong            = 8
        vltyp_missing          = 9
        nltyp_wrong            = 10
        nlpla_wrong            = 11
        nltyp_missing          = 12
        rltyp_wrong            = 13
        rlpla_wrong            = 14
        rltyp_missing          = 15
        squit_forbidden        = 16
        manual_to_forbidden    = 17
        letyp_wrong            = 18
        vlpla_missing          = 19
        nlpla_missing          = 20
        sobkz_wrong            = 21
        sobkz_missing          = 22
        sonum_missing          = 23
        bestq_wrong            = 24
        lgber_wrong            = 25
        xfeld_wrong            = 26
        date_wrong             = 27
        drukz_wrong            = 28
        ldest_wrong            = 29
        update_without_commit  = 30
        no_authority           = 31
        material_not_found     = 32
        lenum_wrong            = 33
        matnr_missing          = 34
        werks_missing          = 35
        anfme_missing          = 36
        altme_missing          = 37
        lgort_wrong_or_missing = 38
        OTHERS                 = 39.
    IF sy-subrc EQ 0.
      flag_bapi = 1.
    ENDIF.
***********************************************************
*BDC for confirming created TO.
***********************************************************
    PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'LTAK-TANUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '/00'.
    PERFORM bdc_field       USING 'LTAK-TANUM'
                                  gv_tanum.
    PERFORM bdc_field       USING 'LTAK-LGNUM'
                                  v_lgnum.

    PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
                                  'LTAK-LGNUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
                                  '=BU'.
    CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.



  ENDIF.

  IF flag_confirm EQ 0 AND flag_move EQ 1 AND flag_bapi = 1.

    gv_text = 'TO number(s) created are :'.
    CONCATENATE gv_text gv_tanum INTO gv_text SEPARATED BY ' '.
    MESSAGE gv_text TYPE 'I'.                                        "message to display TO no.
    LEAVE LIST-PROCESSING.
    refresh : it_lqua,it_lqua1,it_bdcdata.
    CLEAR : p_lgtyps,check,wa_bdcdata,
    gv_tanum,
    p_lgtypd ,
    v_lgnum ,
    p_lgplas,
    v_lgtyp ,
    v_lgpla ,
    v1_lgtyp ,
    v1_lgpla ,
    v_lgber ,
    p_lgber,
    p_lgnum,
    p_lgplad,
    wa_ltap_creat,
    it_ltap_creat, flag,flag2,check,flag_bapi,flag_confirm,flag_enter,flag_ltap_creat,
    flag_move,flag_select_all,flag_validate.
    LEAVE TO SCREEN 0.
  ENDIF.

ENDMODULE.
***********************************************************
*PBO of screen 0101.
***********************************************************
MODULE user_command_9002 INPUT.
  CASE ok_code.
    WHEN 'BACK'.
      CLEAR : it_lqua,
              it_ltap_creat,
              flag,
              flag2,
              flag_bapi,
              flag_confirm,
              flag_enter,
              flag_move,
              flag_select_all,
              it_bdcdata,
              it_zwm_picklist,
              p_lgber,
              p_lgnum,
              p_lgplad,
              p_lgplas,
              p_lgtypd,
              p_lgtyps,
              v_lgnum,
              v_lagp,
              v1_lgpla,
              v1_lgtyp,
              v_lagp1,
              v_lgber.

      LEAVE TO SCREEN 0.
    WHEN 'EXIT' OR 'CANCEL'.
      LEAVE PROGRAM.
    WHEN 'MOVE'.

      flag_move = 1.
      flag_validate = 1.
      "flag_final = 1.

  ENDCASE.
ENDMODULE.                                    "calling fieldcat method from class object.
