*&---------------------------------------------------------------------*
*&  Include           ZPHYSICAL_INVENTORY_TOP
*&---------------------------------------------------------------------*
TABLES:link.
 DATA: no TYPE int4.
 data:flag type i value 0.
  DATA : v_fm_name TYPE    rs38l_fnam.
  DATA:it_final TYPE STANDARD TABLE OF zinventory_str.

  types: begin of ty_lqua,
    lgnum type lqua-lgnum,
      lqnum type lqua-lqnum,
      matnr type lqua-matnr,
      werks type lqua-werks,
      charg type lqua-charg,
      lgtyp type lqua-lgtyp,
      lgpla type lqua-lgpla,
      verme type lqua-verme,
      lgort type lqua-lgort,
      lenum type lqua-lenum,
      meins type lqua-meins,
      end of ty_lqua.


    data:it_lqua type STANDARD TABLE OF ty_lqua.
