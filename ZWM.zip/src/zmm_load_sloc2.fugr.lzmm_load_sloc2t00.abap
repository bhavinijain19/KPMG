*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_LOAD_SLOC2..................................*
DATA:  BEGIN OF STATUS_ZMM_LOAD_SLOC2                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_LOAD_SLOC2                .
CONTROLS: TCTRL_ZMM_LOAD_SLOC2
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_LOAD_SLOC2                .
TABLES: ZMM_LOAD_SLOC2                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
