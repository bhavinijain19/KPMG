*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_N_PBO
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_8000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8000 OUTPUT.

  SET PF-STATUS 'ZWM_W_8000'.

  PERFORM set_dropdown_values.

  PERFORM screen_changes.

  IF lv_sel_mode IS INITIAL.
    SELECT SINGLE value FROM zwm_gen_config INTO lv_sel_mode WHERE name = 'SEL_MODE'.
  ENDIF.

  IF gr_grid1 IS NOT BOUND.

    PERFORM get_layout1.
    PERFORM get_exclude_menu1.
    PERFORM get_fcat1.

    CREATE OBJECT gr_cust_cont1
      EXPORTING
        container_name = 'MATERIAL_LIST'.
    CREATE OBJECT gr_grid1
      EXPORTING
        i_parent = gr_cust_cont1.

    CALL METHOD gr_grid1->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout1
        it_toolbar_excluding = gt_exclude1
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_mat_list
        it_fieldcatalog      = gt_fcat1.
  ELSE.
    CALL METHOD gr_grid1->refresh_table_display.
  ENDIF.

  IF gr_grid2 IS INITIAL AND lv_detail_disp EQ 'X'.

    PERFORM get_layout2.
    PERFORM get_exclude_menu2.
    PERFORM get_fcat2.

    CREATE OBJECT gr_cust_cont2
      EXPORTING
        container_name = 'BATCH_LIST'.
    CREATE OBJECT gr_grid2
      EXPORTING
        i_parent = gr_cust_cont2.

    CALL METHOD gr_grid2->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout2
        it_toolbar_excluding = gt_exclude2
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_batch_list
        it_fieldcatalog      = gt_fcat2.
  ELSEIF lv_detail_disp EQ 'X'.
    CALL METHOD gr_grid2->refresh_table_display.
  ELSEIF gr_cust_cont2 IS NOT INITIAL AND lv_detail_disp EQ ''.
    CALL METHOD gr_cust_cont2->free.
    CLEAR: gr_cust_cont2, gr_grid2.
  ENDIF.

  IF gr_grid3 IS INITIAL AND lv_detail_disp EQ 'X'.

    PERFORM get_layout3.
    PERFORM get_exclude_menu3.
    PERFORM get_fcat3.

    CREATE OBJECT gr_cust_cont3
      EXPORTING
        container_name = 'PALLETTE_SU'.
    CREATE OBJECT gr_grid3
      EXPORTING
        i_parent = gr_cust_cont3.

    CALL METHOD gr_grid3->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout3
        it_toolbar_excluding = gt_exclude3
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_scanned_list
        it_fieldcatalog      = gt_fcat3.

      CREATE OBJECT gr_event_receiver3.
      SET HANDLER gr_event_receiver3->button_click FOR gr_grid3.
  ELSEIF lv_detail_disp = 'X'.
    CALL METHOD gr_grid3->refresh_table_display.
  ELSEIF gr_cust_cont3 IS NOT INITIAL AND lv_detail_disp EQ ''.
    CALL METHOD gr_cust_cont3->free.
    CLEAR: gr_cust_cont3, gr_grid3.
  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8001 OUTPUT.

  IF gr_grid4 IS NOT BOUND.

    PERFORM get_layout4.
    PERFORM get_exclude_menu4.
    PERFORM get_fcat4.

    CREATE OBJECT gr_cust_cont4
      EXPORTING
        container_name = 'CUST_CONT4'.

    CREATE OBJECT gr_grid4
      EXPORTING
        i_parent = gr_cust_cont4.

    CALL METHOD gr_grid4->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout4
        it_toolbar_excluding = gt_exclude4
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_batch_exp
        it_fieldcatalog      = gt_fcat4.
  ELSE.
    CALL METHOD gr_grid4->refresh_table_display.
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8002  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8002 OUTPUT.

  IF gr_grid5 IS NOT BOUND.

    PERFORM get_layout5.
    PERFORM get_exclude_menu5.
    PERFORM get_fcat5.

    CREATE OBJECT gr_cust_cont5
      EXPORTING
        container_name = 'LOADING_LIST'.
    CREATE OBJECT gr_grid5
      EXPORTING
        i_parent = gr_cust_cont5.

    CALL METHOD gr_grid5->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout5
        it_toolbar_excluding = gt_exclude5
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_load_list
        it_fieldcatalog      = gt_fcat5.
  ELSE.
    CALL METHOD gr_grid5->refresh_table_display.
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8003  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8003 OUTPUT.

  IF gr_grid6 IS NOT BOUND.

    PERFORM get_layout6.
    PERFORM get_exclude_menu6.
    PERFORM get_fcat6.

    CREATE OBJECT gr_cust_cont6
      EXPORTING
        container_name = 'INCOMPLETE_MATERIAL'.
    CREATE OBJECT gr_grid6
      EXPORTING
        i_parent = gr_cust_cont6.

    CALL METHOD gr_grid6->set_table_for_first_display
      EXPORTING
        is_variant           = gv_variant
        is_layout            = gs_layout6
        it_toolbar_excluding = gt_exclude6
        i_save               = 'A'
      CHANGING
        it_outtab            = lt_incomplete_mat_list
        it_fieldcatalog      = gt_fcat6.
  ELSE.
    CALL METHOD gr_grid6->refresh_table_display.
  ENDIF.

ENDMODULE.
