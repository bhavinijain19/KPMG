*---------------------------------------------------------------------*
* Report  ZSALES_RETURN                                                   *
*                                                                     *
*---------------------------------------------------------------------*
*---------------------------------------------------------------------*
REPORT zsales_return NO STANDARD PAGE HEADING
                 MESSAGE-ID l1.

*---------------------------------------------------------------------*
*        INCLUDES                                                     *
*---------------------------------------------------------------------*
INCLUDE: z<symbol>,
        zmllvskon.

*---------------------------------------------------------------------*
*        TYPE-POOLS                                                   *
*---------------------------------------------------------------------*
TYPE-POOLS: slis.

*---------------------------------------------------------------------*
*        Konstanten                                                   *
*---------------------------------------------------------------------*

*......Farben..........................................................
TYPES: farbe(3) TYPE c.

CONSTANTS: white  TYPE farbe VALUE 'C20', " weiß, intensified off
           yellow TYPE farbe VALUE 'C30', " gelb, intensified off
           red    TYPE farbe VALUE 'C60', " rot,  intensified off
           green  TYPE farbe VALUE 'C50'. " grün, intensified off
CONSTANTS:                                                  "v_n_825148
  con_verle_intern      TYPE c   VALUE '1', " intern
  con_verle_int_ehe     TYPE c   VALUE '2', " intern + recycling
  con_verle_int_ehe_ext TYPE c VALUE '3', " intern, extern, rec.
  con_verle_int_ext     TYPE c   VALUE '4', " intern, extern
  con_verle_extern      TYPE c   VALUE '5'. " extern
CONSTANTS:
  r_ok                 LIKE  sy-subrc VALUE '0000',
  r_verle_nicht_da     LIKE  sy-subrc VALUE '0042',
  r_extern_verboten    LIKE  sy-subrc VALUE '0043',
  r_zukunft_verboten   LIKE  sy-subrc VALUE '0044',
  r_recycling_verboten LIKE  sy-subrc VALUE '0045',
  r_lenum_verboten     LIKE  sy-subrc VALUE '0046',
  r_nur_externe_lenum  LIKE  sy-subrc VALUE '0047',
  r_kollision_fremd    LIKE  sy-subrc VALUE '0054'.
CONSTANTS:
  r_lvsk_ok(1)              TYPE c VALUE '0',
  r_lvsk_zukunft_eigen(1)   TYPE c VALUE '1',
  r_lvsk_vergangen_eigen(1) TYPE c VALUE '2',
  r_lvsk_zukunft_fremd(1)   TYPE c VALUE '3',
  r_lvsk_vergangen_fremd(1) TYPE c VALUE '4'.
                                                            "^_n_825148

*---------------------------------------------------------------------*
*        DATENBANKTABELLEN                                            *
*---------------------------------------------------------------------*
TABLES: likp,                          " Lieferungskopf
        lips,                          " Lieferungsposition
        vbfa,                          " Belegfluß Lieferung
        vbuk,                          " Kopfstatus Lieferung
        vbup,                          " Positionsstatus Lieferung
        ltap,                          " Transportauftragspositionen
        ltak,                          " Transportauftragsköpfe
        lagp,                          " Lagerplätze
        lein,                          " Lagereinheiten
        lqua,                          " Lagerquants
        t333,                          " LVS-Bewegungsarten
        t302,                          " Lagerbereiche
        t340d,                         " Lagernummerndetails   "n_825148
        rl03t,                         " E/A Felder für TA-Abwicklung
        rldru.                         " Felder zum TA-Druck

*---------------------------------------------------------------------*
*        INTERNE TABELLEN                                             *
*---------------------------------------------------------------------*
DATA: BEGIN OF lief_tab OCCURS 0,      " Lieferungs- und Belegdaten
        vbeln    LIKE lips-vbeln,
        posnr    LIKE lips-posnr,
        wbsta    LIKE vbup-wbsta,
        verursys LIKE likp-verursys,
        lgnum    LIKE lips-lgnum,
        lgtyp    LIKE lips-lgtyp,
        lgpla    LIKE lips-lgpla,
        vbelt    LIKE vbfa-vbeln,
        posnn    LIKE vbfa-posnn,
        lvsta    LIKE vbup-lvsta,                           "n_2251357
        tanum    LIKE ltap-tanum,
        tapos    LIKE ltap-tapos,
        lfimg    LIKE lips-lfimg,
        vrkme    LIKE lips-vrkme,
        rfmng    LIKE vbfa-rfmng,
        komkz    LIKE lips-komkz,
        lgmng    LIKE lips-lgmng,
        meins    LIKE lips-meins.
DATA: /cwm/lfimg    TYPE /cwm/lfimg,
      /cwm/lfime    TYPE /cwm/lfime,
      /cwm/pikmg    TYPE /cwm/pikmg,
      /cwm/pikme    TYPE /cwm/pikme,
      /cwm/xenter   TYPE /cwm/xenter,
      /cwm/xtaenter TYPE /cwm/xtaenter,
      /cwm/kcmeng   TYPE /cwm/kcmeng.
DATA: kzbef LIKE vbfa-kzbef,
      later LIKE ltak-later.           " Späte Lieferfortschreibung
DATA: END OF lief_tab.

* To identify the Transfer order items that are already returned.      v_n_1638123
DATA: BEGIN OF lief_tab_ret OCCURS 0,      " Lieferungs- und Belegdaten
        vbeln    LIKE lips-vbeln,
        posnr    LIKE lips-posnr,
        wbsta    LIKE vbup-wbsta,
        verursys LIKE likp-verursys,
        lgnum    LIKE lips-lgnum,
        lgtyp    LIKE lips-lgtyp,
        lgpla    LIKE lips-lgpla,
        vbelt    LIKE vbfa-vbeln,
        posnn    LIKE vbfa-posnn,
        lvsta    LIKE vbup-lvsta,                           "n_2251357
        tanum    LIKE ltap-tanum,
        tapos    LIKE ltap-tapos,
        lfimg    LIKE lips-lfimg,
        vrkme    LIKE lips-vrkme,
        rfmng    LIKE vbfa-rfmng,
        komkz    LIKE lips-komkz,
        lgmng    LIKE lips-lgmng,
        meins    LIKE lips-meins,
        later    LIKE ltak-later.           " Späte Lieferfortschreibung
DATA: END OF lief_tab_ret.                                         "  ^_n_1638123

DATA: BEGIN OF talf_tab OCCURS 0,      " Transportaufträge zur Lieferung
        lgnum LIKE ltap-lgnum,
        tanum LIKE ltap-tanum,
        tapos LIKE ltap-tapos,
        vltyp LIKE ltap-vltyp,
        vlpla LIKE ltap-vlpla,
        vppos LIKE ltap-vppos,
        vlenr LIKE ltap-vlenr,
        letyp LIKE ltap-letyp,
        homve LIKE ltap-homve,
        pquit LIKE ltap-pquit,
        nlqnr LIKE ltap-nlqnr,
        nistm LIKE ltap-nistm,
        meins LIKE ltap-meins,
        nista LIKE ltap-nista,
        altme LIKE ltap-altme,
        werks LIKE ltap-werks,
        matnr LIKE ltap-matnr,
        lgort LIKE ltap-lgort,
        bestq LIKE ltap-bestq,
        sobkz LIKE ltap-sobkz,
        sonum LIKE ltap-sonum,
        charg LIKE ltap-charg,
        passd LIKE ltap-passd.           " Späte Lieferfortschreibung
DATA: END OF talf_tab.

* To identify the Transfer order items that are already returned.      v_n_1638123
DATA: BEGIN OF talf_tab_ret OCCURS 0,      " Transportaufträge zur Lieferung
        lgnum  LIKE ltap-lgnum,
        tanum  LIKE ltap-tanum,
        tapos  LIKE ltap-tapos,
        nltyp  LIKE ltap-nltyp,
        nlpla  LIKE ltap-nlpla,
        nppos  LIKE ltap-nppos,
        nlenr  LIKE ltap-nlenr,
        letyp  LIKE ltap-letyp,
        homve  LIKE ltap-homve,
        pquit  LIKE ltap-pquit,
        nlqnr  LIKE ltap-nlqnr,
        nsola  LIKE ltap-nsola,
        meins  LIKE ltap-meins,
        nsolm  LIKE ltap-nsolm,
        altme  LIKE ltap-altme,
        werks  LIKE ltap-werks,
        matnr  LIKE ltap-matnr,
        lgort  LIKE ltap-lgort,
        bestq  LIKE ltap-bestq,
        sobkz  LIKE ltap-sobkz,
        sonum  LIKE ltap-sonum,
        charg  LIKE ltap-charg,
        update LIKE con_x,                                  "n_1711593
        passd  LIKE ltap-passd.           " Späte Lieferfortschreibung
DATA: END OF talf_tab_ret.                                  " ^_n_1638123

DATA: BEGIN OF quan_tab OCCURS 0.      " Quants zu Lieferungen
        INCLUDE STRUCTURE lqua.
DATA: resme LIKE lqua-verme.
DATA: END OF quan_tab.

DATA: BEGIN OF itab OCCURS 0.          " Ausgabestruktur für ALV
        INCLUDE STRUCTURE rl034.
DATA: kzbef LIKE vbfa-kzbef,
      maktx1 TYPE makt-maktx.
DATA: END OF itab.

TYPES: BEGIN OF ty_final,
         checkbox    TYPE c,
         vbeln       TYPE vbeln,
         posnr       TYPE posnr,
         lqua_lgtyp  TYPE lgtyp,
         lqua_lgpla  TYPE lgpla,
         vltyp       TYPE ltap_vltyp,
         vlpla_misch TYPE ltap_vlpla,
         matnr       TYPE matnr,
         werks       TYPE werks_d,
         verme       TYPE lqua_verme,
         meins       TYPE meins,
         charg       TYPE charg_d,
       END OF ty_final.

DATA: it_final TYPE STANDARD TABLE OF ty_final,
      wa_final TYPE ty_final.

DATA: hlp_itab LIKE itab OCCURS 0 WITH HEADER LINE.

DATA: BEGIN OF seltab OCCURS 0.        " Tabelle für Auffrischen
        INCLUDE STRUCTURE rsparams.
DATA: END OF seltab.

DATA: ltap_creat LIKE ltap_creat       " Tabelle für L_TO_CREATE_MULT..
        OCCURS 0 WITH HEADER LINE.

DATA: callback LIKE ldbcb              " Tabellen für LDB_PROCESS
        OCCURS 0 WITH HEADER LINE,
      seltab2  LIKE rsparams
        OCCURS 0 WITH HEADER LINE.

DATA: lt_vbfa LIKE vbfa OCCURS 0 WITH HEADER LINE.

DATA: itab_menge LIKE itab OCCURS 0.

DATA: it_vbuk LIKE vbuk OCCURS 0.

DATA: gs_likp LIKE likp.

DATA:                                                     "V_N_1127095
  BEGIN OF gt_rueck_mng OCCURS 0,
    lgnum TYPE lgnum,
    matnr TYPE matnr,
    werks TYPE werks_d,
    bestq TYPE bestq,
    sobkz TYPE sobkz,
    charg TYPE charg_d,
    sonum TYPE lvs_sonum,
    lgtyp TYPE lgtyp,
    lgpla TYPE lgpla,
    lgort TYPE lgort_d,
    verme TYPE menge_d,
    lenum TYPE lenum,                                       "n_2150273
  END OF gt_rueck_mng.

DATA: BEGIN OF itab_vbeln OCCURS 0,
        vbeln TYPE lips-vbeln,
      END OF itab_vbeln.

DATA:
  gf_mngio TYPE xfeld.                                    "^_N_1127095

DATA:
   i_counter TYPE num.                                      "n_1711593
*---------------------------------------------------------------------*
*        HILFSFELDER                                                  *
*---------------------------------------------------------------------*
DATA: menge        LIKE lqua-verme,
      summe        LIKE lqua-verme,
      kommi_menge  LIKE vbfa-rfmng,
      nach_lgtyp   LIKE lqua-lgtyp,
      nach_lgber   LIKE lagp-lgber,
      nach_lgpla   LIKE lqua-lgpla,
      nach_plpos   LIKE lqua-plpos,
      fcode        TYPE sy-ucomm,                          " checkman
      sicht        TYPE c,
      flg_no_mark  TYPE c,
      flg_no_quant TYPE c,
      flg_fehler   TYPE c,
      lv_tabix     LIKE sy-tabix,
      lv_vbeln     LIKE lips-vbeln,
      lv_posnr     LIKE lips-posnr,
      returncode   TYPE c.

DATA: ls_itab_menge LIKE itab,
      lv_menge      LIKE menge,      ls_vbuk       LIKE vbuk.

*........SAVE-Felder...................................................
DATA: sav_sy_repid LIKE sy-repid,
      sav_sy_subrc LIKE sy-subrc,
      sav_vbeln    LIKE likp-vbeln,
      sav_tabix    LIKE sy-tabix,
      hlp_tanum    LIKE ltak-tanum.

DATA: it_bdcdata TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
      wa_bdcdata TYPE bdcdata.
*---------------------------------------------------------------------*
*        DATENDEKLARATIONEN FÜR DEN ALV                               *
*---------------------------------------------------------------------*
DATA:      xheader TYPE slis_t_listheader WITH HEADER LINE,
           variant LIKE disvariant.
*---------------------------------------------------------------------*
*        GI cancelation -> Docubatches                       "1530856 *
*---------------------------------------------------------------------*
DATA: gs_gi_canc TYPE ltap,
      gt_gi_canc TYPE STANDARD TABLE OF ltap.               "1530856


DATA : bwlvs   TYPE t333-bwlvs,
       p_tapos TYPE c,
       p_vbeln TYPE c.

DATA: listv LIKE rl01s-listv.

TYPE-POOLS: slis.

DATA: xevent    TYPE slis_t_event,
      aevent    TYPE slis_alv_event,
      layout    TYPE slis_layout_alv,
      asp_group TYPE slis_sp_group_alv,
      xsp_group TYPE slis_t_sp_group_alv,
      extab     TYPE slis_t_extab WITH HEADER LINE,
      xfield    TYPE slis_t_fieldcat_alv,
      afield    TYPE slis_fieldcat_alv.

TYPES:BEGIN OF ty_makt,
        matnr TYPE makt-matnr,
        maktx TYPE makt-maktx,
      END OF ty_makt.

DATA: it_makt TYPE STANDARD TABLE OF ty_makt,
      wa_makt TYPE ty_makt.

*---------------------------------------------------------------------*
*        INITIALIZATION                                               *
*---------------------------------------------------------------------*
INITIALIZATION.

  SET TITLEBAR '001'.

  PARAMETERS: lgnum LIKE lagp-lgnum OBLIGATORY
                                    VALUE CHECK
                                    MEMORY ID lgn,
              vbeln LIKE likp-vbeln MEMORY ID vl
                                      OBLIGATORY.

  bwlvs = '999'.
  p_tapos = 'X'.


*---------------------------------------------------------------------*
*        START-OF-SELECTION                                           *
*---------------------------------------------------------------------*
START-OF-SELECTION.

*----------------------------------------------------------------------*
*       END-OF-SELECTION                                               *
*----------------------------------------------------------------------*
END-OF-SELECTION.

*  MOVE: 'I'    TO vbeln1-sign,
*        'EQ'   TO vbeln1-option,
*        vbeln  TO vbeln1-low.
*  APPEND vbeln1.

  CLEAR seltab2.
  REFRESH seltab2.

  MOVE: 'DD_VBELN' TO seltab2-selname,
        'S'        TO seltab2-kind.

  MOVE: 'I'   TO seltab2-sign,
        'EQ' TO seltab2-option,
        vbeln    TO seltab2-low.
*        vbeln-high   TO seltab2-high.
  APPEND seltab2.

*........Tabelle callback aufbauen für FB LDB_PROCESS..................
  CLEAR callback.
  REFRESH callback.

  MOVE: 'VBUK'     TO callback-ldbnode,
        'X'        TO callback-get,
        'ZSALES_RETURN' TO callback-cb_prog,
        'GET_VBUK' TO callback-cb_form.
  APPEND callback.

  MOVE: 'LIKP'     TO callback-ldbnode,
        'X'        TO callback-get,
        'ZSALES_RETURN' TO callback-cb_prog,
        'GET_LIKP' TO callback-cb_form.
  APPEND callback.

  MOVE: 'LIPS'     TO callback-ldbnode,
        'X'        TO callback-get,
        'ZSALES_RETURN' TO callback-cb_prog,
        'GET_LIPS' TO callback-cb_form.
  APPEND callback.

  MOVE: 'VBUP'     TO callback-ldbnode,
        'X'        TO callback-get,
        'ZSALES_RETURN' TO callback-cb_prog,
        'GET_VBUP' TO callback-cb_form.
  APPEND callback.

  MOVE: 'VBFA'     TO callback-ldbnode,
        'X'        TO callback-get,
        'ZSALES_RETURN' TO callback-cb_prog,
        'GET_VBFA' TO callback-cb_form.
  APPEND callback.

  CALL FUNCTION 'LDB_PROCESS'
    EXPORTING
      ldbname       = 'VLV'
    TABLES
      callback      = callback
      selections    = seltab2
    EXCEPTIONS
      error_message = 99.
  IF sy-subrc = 99.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

*........Prüfen, ob überhaupt Lieferungen selektiert wurden............
  IF vbeln IS INITIAL. "lief_tab IS INITIAL.
    MESSAGE s092(l1).
*    Zu den eingegebenen Kriterien existieren keine Daten
    LEAVE TO TRANSACTION sy-tcode.
  ENDIF.

*........TA-Positionen zu den Lieferungen lesen........................
  PERFORM talf_tab_fuellen.

*........Quants zu den TA-Positionen lesen.............................
  PERFORM quan_tab_fuellen.

*........ Delete lief_tab when no Transport in talf_tab................
  PERFORM balancing_lief_tab_a_talf_tab.                    "N_1124319

*........Ausgabetabelle für ALV füllen.................................
  PERFORM itab_fuellen.

*  PERFORM define_events_rl034.
*
*  PERFORM define_special_groups_rl034.
*
*  PERFORM define_layout_rl034.

  PERFORM build_fieldcat_rl031.

  PERFORM call_alv_rl034.

*---------------------------------------------------------------------*
*      Form  BALANCING_LIEF_TAB_A_TALFTAB                             *
*---------------------------------------------------------------------*
*      Delete in Internal Table lief_tab all linesfor wich we find    *
*      no entrance in internal table talf_tab.                        *
*---------------------------------------------------------------------*
FORM balancing_lief_tab_a_talf_tab.                     "V_N_1124319

  LOOP AT lief_tab.
    READ TABLE talf_tab WITH KEY lgnum = lief_tab-lgnum
                                 tanum = lief_tab-tanum
                                 tapos = lief_tab-tapos.
    CHECK sy-subrc NE 0.
    DELETE lief_tab.
  ENDLOOP. " lief_tab.
  IF vbeln IS INITIAL.        "lief_tab IS INITIAL.
    MESSAGE s092(l1).
*      Zu den eingegebenen Kriterien existieren keine Daten
    LEAVE TO TRANSACTION sy-tcode.
  ENDIF.

ENDFORM. " balancing_lief_tab_a_talf_tab                 "^_N_1124319

*---------------------------------------------------------------------*
*      Form  TALF_TAB_FUELLEN                                         *
*---------------------------------------------------------------------*
*      Interne Tabelle TALF_TAB mit TA-Positionsdaten füllen          *
*---------------------------------------------------------------------*
FORM talf_tab_fuellen.

  CHECK NOT lief_tab[] IS INITIAL.

  SELECT * FROM ltap FOR ALL ENTRIES IN lief_tab
           WHERE lgnum = lief_tab-lgnum
             AND tanum = lief_tab-tanum
             AND tapos = lief_tab-tapos.

    IF NOT ltap-fhuta IS INITIAL.
      MESSAGE s794(l3) WITH lief_tab-vbeln.
      LEAVE TO TRANSACTION sy-tcode.
    ENDIF.

    MOVE-CORRESPONDING ltap TO talf_tab.

    APPEND talf_tab.

  ENDSELECT.

*........Prüfen, ob überhaupt TA-Positionen selektiert wurden..........
  IF talf_tab IS INITIAL.
    MESSAGE s092(l1).
*    Zu den eingegebenen Kriterien existieren keine Daten
    LEAVE TO TRANSACTION sy-tcode.
  ENDIF.

*........Alle TA's um ltak-later ergänzen (späte Lieferfortschreibung)..

  SELECT * FROM ltak FOR ALL ENTRIES IN lief_tab
           WHERE lgnum = lief_tab-lgnum
           AND tanum   = lief_tab-tanum.

    MOVE ltak-later TO lief_tab-later.

    MODIFY lief_tab TRANSPORTING later
      WHERE lgnum = ltak-lgnum
        AND tanum = ltak-tanum.

  ENDSELECT.

* For transfer order items are already returned      v_n_1638123

  CHECK NOT lief_tab_ret[] IS INITIAL.

  SELECT * FROM ltap FOR ALL ENTRIES IN lief_tab_ret
           WHERE lgnum = lief_tab_ret-lgnum
             AND tanum = lief_tab_ret-tanum
             AND tapos = lief_tab_ret-tapos.

*    IF ltap-nlenr is not initial.                   "v_n_2251357
    MOVE-CORRESPONDING ltap TO talf_tab_ret.
    APPEND talf_tab_ret.
*    endif.                                          "^_n_2251357
  ENDSELECT.                                         "^_n_1638123

ENDFORM.                               " TALF_TAB_FUELLEN
*---------------------------------------------------------------------*
*      Form  QUAN_TAB_FUELLEN                                         *
*---------------------------------------------------------------------*
*      Interne Tabelle QUAN_TAB mit Quantdaten füllen                 *
*---------------------------------------------------------------------*
FORM quan_tab_fuellen.

  CHECK NOT talf_tab[] IS INITIAL.

  SELECT * FROM lqua FOR ALL ENTRIES IN talf_tab
                    WHERE lgnum = talf_tab-lgnum
                      AND lqnum = talf_tab-nlqnr.
    MOVE-CORRESPONDING lqua TO quan_tab.
    MOVE lqua-verme TO quan_tab-resme.
    APPEND quan_tab.

  ENDSELECT.

ENDFORM.                               " QUAN_TAB_FUELLEN

*---------------------------------------------------------------------*
*      Form  ITAB_FUELLEN                                             *
*---------------------------------------------------------------------*
*      Interne Tabelle ITAB mit Daten für ALV füllen                  *
*---------------------------------------------------------------------*
FORM itab_fuellen.

  DATA:  lv_nistm  LIKE  ltap-nistm.                        "n_2207973

  LOOP AT lief_tab.

    CLEAR itab.                                             "n_1127095

    lv_tabix = sy-tabix + 1.

    MOVE: lief_tab-vbelt TO itab-vbfa_vbeln,
          lief_tab-posnn TO itab-posnn,
          lief_tab-rfmng TO itab-rfmng,
          lief_tab-lgmng TO itab-lgmng,
          lief_tab-kzbef TO itab-kzbef.

    READ TABLE talf_tab WITH KEY lgnum = lief_tab-lgnum
                                 tanum = lief_tab-tanum
                                 tapos = lief_tab-tapos.

*...TA-Position nicht vorhanden: Auslagerung LE-verwaltetes Blocklager
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    MOVE: talf_tab-tanum TO itab-ltap_tanum,
          talf_tab-tapos TO itab-ltap_tapos,
          talf_tab-nistm TO itab-nistm,
          talf_tab-nista TO itab-nista,
          talf_tab-altme TO itab-altme,
          talf_tab-vltyp TO itab-vltyp,
          talf_tab-vlpla TO itab-vlpla,
          talf_tab-vppos TO itab-vppos,
          talf_tab-vlenr TO itab-vlenr,
          talf_tab-letyp TO itab-ltap_letyp,
          talf_tab-homve TO itab-homve.

*........Platzposition einmischen......................................
    CALL FUNCTION 'L_PLATZ_POSITION_MISCHEN'
      EXPORTING
        lgpla   = talf_tab-vlpla
        plpos   = talf_tab-vppos
      IMPORTING
        o_lgpla = itab-vlpla_misch
                  EXCEPTIONS
                  overflow.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

*........Quantdaten hinzufügen.........................................
    READ TABLE quan_tab WITH KEY lgnum = talf_tab-lgnum
                                 lqnum = talf_tab-nlqnr.
    sav_sy_subrc = sy-subrc.
    IF sy-subrc NE 0.
*........Quant nicht vorhanden.........................................
      CLEAR quan_tab.
*........Prüfen ob letzter Eintrag für Lieferposition..................
      lv_vbeln = lief_tab-vbeln.
      lv_posnr = lief_tab-posnr.

      READ TABLE lief_tab INDEX lv_tabix TRANSPORTING vbeln posnr.

      IF ( sy-subrc <> 0 )             " letzter Eintrag
       OR ( lief_tab-vbeln <> lv_vbeln ) " andere Lieferung/-position
       OR ( lief_tab-vbeln = lv_vbeln AND lief_tab-posnr <> lv_posnr ).
*........Feldwerte auf aktuellen Index zurückschreiben................
        lief_tab-vbeln = lv_vbeln.
        lief_tab-posnr = lv_posnr.

*........Prüfen ob WA Storno vorliegt..................................
        SORT lt_vbfa BY vbelv ASCENDING
                        erdat DESCENDING
                        erzet DESCENDING.

        READ TABLE lt_vbfa WITH KEY vbelv   = lief_tab-vbeln
                                    posnv   = lief_tab-posnr
                                    vbtyp_n = 'h'.

        IF sy-subrc = 0.
*........Belegfluß enthält Storno WA...................................
          SELECT SINGLE * FROM lqua WHERE lgnum = lief_tab-lgnum
                                      AND lgtyp = lief_tab-lgtyp
                                      AND lgpla = lief_tab-lgpla
                                      AND wenum = lt_vbfa-vbeln
                                      AND matnr = talf_tab-matnr
                                      AND werks = talf_tab-werks
                                      AND lgort = talf_tab-lgort
                                      AND bestq = talf_tab-bestq
                                      AND sobkz = talf_tab-sobkz
                                      AND sonum = talf_tab-sonum
                                      AND charg = talf_tab-charg.

          IF sy-subrc = 0.
            sav_sy_subrc = sy-subrc.
            MOVE-CORRESPONDING lqua TO quan_tab.
            MOVE lqua-verme TO quan_tab-resme.
            talf_tab-nistm = talf_tab-nistm + lv_nistm.     "n_2207973
            lv_nistm = 0.                                   "n_2207973
            flg_no_quant = con_false.
            CLEAR gs_gi_canc.
*           memorize delivery item as GI cancelation; docubatches "v_1530856
            gs_gi_canc-mandt = sy-mandt.
            gs_gi_canc-lgnum = lief_tab-lgnum.
            gs_gi_canc-tanum = itab-ltap_tanum.
            gs_gi_canc-tapos = itab-ltap_tapos.
            gs_gi_canc-vbeln = lqua-vbeln.
            gs_gi_canc-posnr = lqua-posnr.
            gs_gi_canc-matnr = lqua-matnr.
            gs_gi_canc-werks = lqua-werks.
            APPEND gs_gi_canc TO gt_gi_canc.                "^_1530856
          ELSE.
            flg_no_quant = con_true.
          ENDIF.
        ELSE.
          flg_no_quant = con_true.
        ENDIF.
      ELSE.
        flg_no_quant = con_true.
        lv_nistm = lv_nistm + talf_tab-nistm.
      ENDIF.
    ELSE.
      flg_no_quant = con_false.
    ENDIF.

    MOVE-CORRESPONDING quan_tab TO itab.
*........Felder bei Namensungleichheit einzeln kopieren................
    MOVE: quan_tab-lgtyp TO itab-lqua_lgtyp,
          quan_tab-lgpla TO itab-lqua_lgpla,
          quan_tab-skzue TO itab-lqua_skzue,
          quan_tab-skzse TO itab-lqua_skzse,
          quan_tab-skzsa TO itab-lqua_skzsa,
          quan_tab-skzsi TO itab-lqua_skzsi,
          quan_tab-spgru TO itab-lqua_spgru,
          quan_tab-bdatu TO itab-lqua_bdatu,
          quan_tab-bzeit TO itab-lqua_bzeit,
          quan_tab-btanr TO itab-lqua_btanr,
          quan_tab-btaps TO itab-lqua_btaps,
          quan_tab-mgewi TO itab-lqua_mgewi,
          quan_tab-gewei TO itab-lqua_gewei,
          quan_tab-ivnum TO itab-lqua_ivnum,
          quan_tab-ivpos TO itab-lqua_ivpos,
          quan_tab-kober TO itab-lqua_kober.

*........Lagernummer einzeln übertragen................................
    MOVE lief_tab-lgnum TO itab-lgnum.

*........Liefernr. und -position einzeln übertragen....................
    MOVE: lief_tab-vbeln TO itab-vbeln,"-> wg. Namensgleichheit
          lief_tab-posnr TO itab-posnr."-> mit LQUA erst hier

*........Kommimenge ermitteln..........................................
    CLEAR kommi_menge.

    LOOP AT lt_vbfa WHERE vbelv   = itab-vbeln
                      AND posnv   = itab-posnr
                      AND vbtyp_n = 'Q'.

      IF lt_vbfa-plmin = space.
        kommi_menge = kommi_menge + lt_vbfa-rfmng.
      ELSEIF lt_vbfa-plmin = con_minus." Rücklagerung
        kommi_menge = kommi_menge - lt_vbfa-rfmng.
      ENDIF.

    ENDLOOP.

*   ......... Consider the quantity already returned (confirmed/
*   ..........not confirmed) v_n_1638123
*   ..........notes 1638123 / 1711593 / 2251357
    IF talf_tab-vlenr IS NOT INITIAL
    AND talf_tab-homve IS NOT INITIAL.
      i_counter = 0.
      LOOP AT talf_tab_ret
      WHERE nlenr = talf_tab-vlenr
        AND   update <> con_x.
        CHECK i_counter = 0.
        talf_tab-nistm = talf_tab-nistm - talf_tab_ret-nsolm.
        talf_tab_ret-update = con_x.
        MODIFY talf_tab_ret INDEX sy-tabix.
        IF talf_tab-nistm = 0 .
          i_counter = 1.
        ENDIF.
      ENDLOOP.
    ELSE.
      i_counter = 0.
      LOOP AT talf_tab_ret
      WHERE nlpla = talf_tab-vlpla
    AND   update <> con_x.
        CHECK i_counter = 0.
        talf_tab-nistm = talf_tab-nistm - talf_tab_ret-nsolm.
        talf_tab_ret-update = con_x.
        MODIFY talf_tab_ret INDEX sy-tabix.
        IF talf_tab-nistm = 0.
          i_counter = 1.
        ENDIF.
      ENDLOOP.
    ENDIF.

    " If homve SU was used for initial pick however new SU was created for
    " subsequent returns for example.. reuse of SUs are not allowed as
    " per customizing. No SU to SU match required in this case. Check to be
    " continued as per the bin
    IF sy-subrc NE 0.
      i_counter = 0.
      LOOP AT talf_tab_ret
      WHERE nlpla = talf_tab-vlpla
        AND   update <> con_x.
        CHECK i_counter = 0.
        talf_tab-nistm = talf_tab-nistm - talf_tab_ret-nsolm.
        talf_tab_ret-update = con_x.
        MODIFY talf_tab_ret INDEX sy-tabix.
        IF talf_tab-nistm = 0.
          i_counter = 1.
        ENDIF.
      ENDLOOP.
    ENDIF.

*........Kommimenge auf TA-Positionen verteilen........................
    IF quan_tab-resme GE kommi_menge.
      IF talf_tab-nistm GE kommi_menge.
        menge = kommi_menge.
        quan_tab-resme = quan_tab-resme - kommi_menge.
      ELSE.
        menge = talf_tab-nistm.
        quan_tab-resme = quan_tab-resme - talf_tab-nistm.
      ENDIF.
    ELSE.
      IF quan_tab-resme > 0.
        IF talf_tab-nistm LE quan_tab-resme.
          menge = talf_tab-nistm.
          quan_tab-resme = quan_tab-resme - talf_tab-nistm.
        ELSE.
          menge = quan_tab-resme.
          quan_tab-resme = 0.
        ENDIF.
      ELSE.
        menge = 0.
      ENDIF.
    ENDIF.

*....Für Anlieferung-falls Quantmenge höher also die LF-Positionsmenge
    CLEAR: lv_menge.
    LOOP AT itab_menge INTO ls_itab_menge
      WHERE vbeln = itab-vbeln
        AND posnr = itab-posnr.

      lv_menge = lv_menge + ls_itab_menge-verme.
    ENDLOOP.

    IF lief_tab-lgmng =< lv_menge.                          "n_677037
      menge = 0.
    ENDIF.

    MOVE menge TO itab-verme.

    IF sav_sy_subrc EQ 0.
      MODIFY quan_tab INDEX sy-tabix.
    ENDIF.

*........Ikone zur Markierung setzen...................................
    IF talf_tab-pquit = con_x.
*........nur quittierte Positionen können markiert werden..............
*........und Positionen für die eine Lieferung fortgeschrieben wurde...
      MOVE sym_large_square TO itab-ikone.
    ELSE.
*........nicht quittierte Positionen werden 'gesperrt'.................
      MOVE sym_locked TO itab-ikone.
      itab-msgid = 'L3'.
      itab-msgno = '112'. "Transportauftrag & ist nicht quittiert
      itab-msgty = 'E'.
      itab-msgv1 = itab-ltap_tanum.
    ENDIF.

    IF itab-verme LE 0 AND flg_no_quant = con_true
       OR kommi_menge LE 0.
*........Positionen mit verfügbarer Menge le 0 werden 'gesperrt'.......
      MOVE sym_locked TO itab-ikone.
      IF lief_tab-komkz = 'D'.
        itab-msgid = 'L1'.
        itab-msgno = '613'.            "Lean WM...
        itab-msgty = 'E'.
        itab-msgv1 = lief_tab-vbeln.
      ELSE.
        itab-msgid = 'L1'.
        itab-msgno = '604'. "Verfügbare Menge kleiner oder gleich null
        itab-msgty = 'E'.
      ENDIF.
    ENDIF.

    IF NOT itab-kzbef IS INITIAL.
      MOVE sym_locked TO itab-ikone.
      itab-msgid = 'L1'.
      itab-msgno = '618'. " aktive Bestandsfindung!
      itab-msgty = 'E'.
    ENDIF.

*...... Anlieferung - Positionen mit Null-Menge sperren..............
    IF itab-verme =< 0.
      READ TABLE it_vbuk INTO ls_vbuk WITH KEY vbeln = itab-vbeln.
      IF sy-subrc = 0.
        IF ls_vbuk-vbtyp = con_vbtyp_anlief.
          MOVE sym_locked TO itab-ikone.
          itab-msgid = 'L1'.
          itab-msgno = '615'. "Eingeteilte Menge überschreitet die
          itab-msgty = 'E'.   "verfügbare/kommissionierte Menge
        ENDIF.
      ENDIF.
    ENDIF.

*......IF itab-verme is 0 and wm status is "C"           v_n_2251357
    IF itab-verme =< 0 AND lief_tab-lvsta = 'C'.
      MOVE sym_locked TO itab-ikone.
      itab-msgid = 'L1'.
      itab-msgno = '601'. "Eingeteilte Menge überschreitet die
      itab-msgty = 'E'.   "verfügbare/kommissionierte Menge
    ENDIF.                                             "^_n_2251357

    IF talf_tab-passd NE con_x AND
       talf_tab-pquit = con_x  AND
       ( lief_tab-later = con_later_all_to OR
         lief_tab-later = con_later_one_to OR
         lief_tab-later = con_later_always ).               "n_1127095


*........TA-Position zu einer Auslieferung noch nicht fortgeschrieben...
      MOVE sym_locked TO itab-ikone.
      itab-msgid = 'L3'.
      itab-msgno = '562'. " Lieferbeleg wurde noch nicht fortgeschrieben
      itab-msgty = 'E'.
      itab-msgv1 = lief_tab-vbeln.
    ENDIF.

*...... Anlieferung - Positionen mit gebuchtem (Teil) WE sperren.......
    IF lief_tab-verursys IS NOT INITIAL. "decentralized Warehouse system
      IF lief_tab-wbsta = 'B' OR    "partial goods receipt
         lief_tab-wbsta = 'C'.      "goods receipt completed
*........Delivery has already been partially confirmed.............. ..
        MOVE sym_locked TO itab-ikone.
        itab-msgid = 'VL'.
        itab-msgno = '894'. " Teil WE (WE) bereits rückgemeldet
        itab-msgty = 'E'.
        itab-msgv1 = lief_tab-vbeln.
      ENDIF.
    ENDIF.

*........Farbe initialisieren..........................................
    MOVE white TO itab-farbe.

    APPEND itab.
    CLEAR ls_itab_menge.
    MOVE itab TO ls_itab_menge.
    APPEND ls_itab_menge TO itab_menge.
  ENDLOOP.                             " lief_tab

*                                                          "v_n_1127095
* if any of the itab items is locked due to passd = X then lock all
  LOOP AT itab.
*........Bei jeder neuen VBELN, prüfen welche Ikone gesetzt werden muß.
    IF itab-vbeln NE sav_vbeln.
      sav_vbeln = itab-vbeln.
      CLEAR flg_no_mark.
    ENDIF.
*........Für jedes TA-Position der VBELN prüfen, ob sie 'gesperrt' ist.
    IF itab-ikone NE sym_large_square AND
      itab-msgid = 'L3'              AND
      itab-msgno = '562'             AND
      itab-msgty = 'E'.
      itab_vbeln-vbeln = itab-vbeln.
      APPEND itab_vbeln.
      flg_no_mark = con_x.
    ENDIF.
  ENDLOOP.

* in itab-vbeln are all deliveries which should be locked because they are
* not all updated.
  LOOP AT itab_vbeln.
    LOOP AT itab WHERE vbeln = itab_vbeln-vbeln.
      MOVE sym_locked TO itab-ikone.
      itab-msgid = 'L3'.
      itab-msgno = '562'. " Lieferbeleg wurde noch nicht fortgeschrieben
      itab-msgty = 'E'.
      itab-msgv1 = lief_tab-vbeln.
      MODIFY itab TRANSPORTING ikone msgid msgty msgno.
    ENDLOOP.
  ENDLOOP.
*                                                          "^_n_1127095

***********************************Material Description Added********************
  SELECT matnr maktx FROM makt INTO TABLE it_makt
                               FOR ALL ENTRIES IN itab
                               WHERE matnr = itab-matnr.
  LOOP AT itab.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = itab-matnr.
    itab-maktx1 = wa_makt-maktx.
    MODIFY itab TRANSPORTING maktx1.
    CLEAR: wa_makt.
  ENDLOOP.
***********************************Material Description Added********************

*........ITAB sortieren................................................
  SORT itab BY vbeln posnr ltap_tanum ltap_tapos.

ENDFORM.                               " ITAB_FUELLEN

*---------------------------------------------------------------------*
*      Form  DEFINE_EVENTS_RL034                                      *
*---------------------------------------------------------------------*
*      Mögliche Events definieren                                     *
*---------------------------------------------------------------------*
FORM define_events_rl034.

  CALL FUNCTION 'REUSE_ALV_EVENTS_GET'
    EXPORTING
      i_list_type = 0
    IMPORTING
      et_events   = xevent.
*    exceptions
*         list_type_wrong = 1
*         others          = 2.

*........Ereignis TOP-OF-PAGE hinzufügen...............................
  READ TABLE xevent WITH KEY name = slis_ev_top_of_page INTO aevent.

  IF sy-subrc = 0.
    MOVE slis_ev_top_of_page TO aevent-form.
    APPEND aevent TO xevent.
  ENDIF.

*........Ereignis AT-USER_COMMAND hinzufügen...........................
  READ TABLE xevent WITH KEY name = slis_ev_user_command INTO aevent.

  IF sy-subrc = 0.
    MOVE slis_ev_user_command TO aevent-form.
    APPEND aevent TO xevent.
  ENDIF.

ENDFORM.                               " DEFINE_EVENTS_RL034
*---------------------------------------------------------------------*
*      Form  DEFINE_SPECIAL_GROUPS_RL034                              *
*---------------------------------------------------------------------*
*      Special-Groups definieren                                      *
*---------------------------------------------------------------------*
FORM define_special_groups_rl034.

  CLEAR asp_group.
  asp_group-sp_group = 'P'.            " PLATZ-Daten
  asp_group-text = text-001.
  APPEND asp_group TO xsp_group.

  CLEAR asp_group.
  asp_group-sp_group = 'Q'.            " QUANT-Daten
  asp_group-text = text-002.
  APPEND asp_group TO xsp_group.


ENDFORM.                               " DEFINE_SPECIAL_GROUPS_RL034

FORM define_layout_rl034.

*........Gruppenwechsel ermöglichen....................................
  layout-group_change_edit = 'X'.

*........Detailinformationen als Popup.................................
  layout-detail_popup = 'X'.

*........Farbinformation zuweisen......................................
  layout-info_fieldname = 'FARBE'.

*  IF I_REPID = 'RLLQ0200' OR I_REPID = 'RLLI2110'.
*    layout-box_fieldname = 'IKONE'.
*    layout-box_tabname   = 'T_LIST'.
*  ENDIF.

ENDFORM.                               " DEFINE_LAYOUT_RL034

FORM build_fieldcat_rl031.

  REFRESH xfield.

*---------------------------------------------------------------------*
*        1. per Default eingeblendete Felder                          *
*---------------------------------------------------------------------*

*........Ikone/Symbol..................................................
*  CLEAR afield.
*  afield-fieldname = 'CHECKBOX'.
*  afield-checkbox = 'X'.
*  afield-edit = 'X'.
*  afield-seltext_l = 'Checkbox'.
*  APPEND afield TO xfield.
  CLEAR afield.
  afield-fieldname = 'IKONE'.
  afield-checkbox = 'X'.
  afield-edit = 'X'.
  afield-seltext_l = 'Checkbox'.
  APPEND afield TO xfield.
*........Lieferung.....................................................
  CLEAR afield.
  afield-fieldname = 'VBELN'.
*  afield-ref_tabname = 'RL034'.
*  afield-hotspot = 'X'.
  afield-seltext_l = 'Document'.
  APPEND afield TO xfield.
*........Lieferposition................................................
  CLEAR afield.
  afield-fieldname = 'POSNR'.
  afield-seltext_l = 'Item'.
*  afield-ref_tabname = 'RL034'.
  APPEND afield TO xfield.
*........Lagertyp......................................................
  CLEAR afield.
  afield-fieldname = 'LQUA_LGTYP'.
  afield-seltext_l = 'Storage Type'.
*  afield-ref_tabname = 'RL034'.
  APPEND afield TO xfield.
*........Lagerplatz....................................................
  CLEAR afield.
  afield-fieldname = 'LQUA_LGPLA'.
  afield-seltext_l = 'Storage Bin'.
*  afield-ref_tabname = 'RL034'.
*  afield-hotspot = 'X'.
  APPEND afield TO xfield.
*........Vonlagertyp...................................................
  CLEAR afield.
  afield-fieldname = 'VLTYP'.
  afield-seltext_l = 'Source Type'.
*  afield-ref_tabname = 'RL034'.
  APPEND afield TO xfield.
*........Vonlagerplatz.................................................
  CLEAR afield.
  afield-fieldname = 'VLPLA_MISCH'.
  afield-seltext_l = 'Source Bin'.
*  afield-ref_tabname = 'RL034'.
*  afield-hotspot = 'X'.
  APPEND afield TO xfield.
*........Materialnummer................................................
  CLEAR afield.
  afield-fieldname = 'MATNR'.
  afield-seltext_l = 'Material'.
  afield-outputlen = 18.
*  afield-ref_tabname = 'LQUA'.
*  afield-hotspot = 'X'.
  APPEND afield TO xfield.
*........Materialdescription................................................
  CLEAR afield.
  afield-fieldname = 'MAKTX1'.
  afield-seltext_l = 'Material Description'.
  afield-outputlen = 40.
  APPEND afield TO xfield.
*........Werk..........................................................
  CLEAR afield.
  afield-fieldname = 'WERKS'.
  afield-seltext_l = 'Plant'.
*  afield-ref_tabname = 'LQUA'.
  APPEND afield TO xfield.
*........Verfügbarer Bestand...........................................
  CLEAR afield.
  afield-fieldname = 'VERME'.
*  afield-ref_tabname = 'LQUA'.
  afield-qfieldname = 'MEINS'.
  afield-seltext_l = 'Available stock'.
  afield-input = 'X'.
  APPEND afield TO xfield.
*........Basismengeneinheit............................................
  CLEAR afield.
  afield-fieldname = 'MEINS'.
  afield-seltext_l = 'UoM'.
*  afield-ref_tabname = 'LQUA'.
  APPEND afield TO xfield.
*........Chargennummer.................................................
  CLEAR afield.
  afield-fieldname = 'CHARG'.
  afield-seltext_l = 'Batch'.
*  afield-ref_tabname = 'LQUA'.
*  afield-hotspot = 'X'.
  APPEND afield TO xfield.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  pf
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
FORM pf USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'ZSALES'.
ENDFORM.                    "pf

*---------------------------------------------------------------------*
*      Form  CALL_ALV_RL034                                           *
*---------------------------------------------------------------------*
*      ALV aufrufen                                                   *
*---------------------------------------------------------------------*
FORM call_alv_rl034.

  DATA: lv_buffer_active(1) TYPE c.

  CLEAR lv_buffer_active.

  sav_sy_repid = sy-repid.

  LOOP AT itab.
*    MOVE itab-IKONE TO wa_final
    MOVE-CORRESPONDING itab TO wa_final.
    APPEND wa_final TO it_final.
  ENDLOOP.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sav_sy_repid
*     i_callback_program       = i_repid
      i_callback_pf_status_set = 'PF'
      i_callback_user_command  = 'USER_COMMAND'
*     I_STRUCTURE_NAME         =
      is_layout                = layout
      it_fieldcat              = xfield
*     IT_EXCLUDING             =
*     it_special_groups        = xsp_group[]
*     IT_SORT                  =
*     IT_FILTER                =
*     IS_SEL_HIDE              =
*     i_default                = 'X'
*     i_save                   = 'A'
*     is_variant               = variant
*     it_events                = xevent
    TABLES
      t_outtab                 = itab               "it_final
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.

ENDFORM.                               " CALL_ALV_RL034

*---------------------------------------------------------------------*
*      Form  GET_VBUK                                                 *
*---------------------------------------------------------------------*
*      Aktionen die bei GET VBUK ausgeführt werden                    *
*---------------------------------------------------------------------*
FORM get_vbuk USING name     LIKE ldbn-ldbnode "Knotenname
                    p_vbuk   LIKE vbuk " Daten
                    mode     TYPE c    " G(et) oder L(ate)
                    selected TYPE c.   " Knoten gewünscht

*........Ist die Lieferung überhaupt WM-relevant ?.....................
  CHECK p_vbuk-lvstk NE ' '.

*........Ist die Lieferung schon WA gebucht ?..........................

  CHECK p_vbuk-wbstk NE 'C'.

  APPEND p_vbuk TO it_vbuk.

ENDFORM.                               " GET_VBUK

*---------------------------------------------------------------------*
*      Form  GET_LIKP                                                 *
*---------------------------------------------------------------------*
*      Aktionen die bei GET VBUK ausgeführt werden                    *
*---------------------------------------------------------------------*
FORM get_likp USING name     LIKE ldbn-ldbnode "Knotenname
                    p_likp   LIKE likp " Daten
                    mode     TYPE c    " G(et) oder L(ate)
                    selected TYPE c.   " Knoten gewünscht


*........Merke die Lieferung ........................................
*  move-corresponding p_likp to gs_likp.
  gs_likp-verursys = p_likp-verursys.

ENDFORM.                               " GET_LIKP

*---------------------------------------------------------------------*
*      Form  GET_LIPS                                                 *
*---------------------------------------------------------------------*
*      Aktionen, die bei GET LIPS ausgeführt werden                   *
*---------------------------------------------------------------------*
FORM get_lips USING name     LIKE ldbn-ldbnode "Knotenname
                    p_lips   LIKE lips " Daten
                    mode     TYPE c    " G(et) oder L(ate)
                    selected TYPE c.   " Knoten gewünscht


*........Bezieht sich die Lieferposition auf selektierte Lagernummer ?.
* check p_lips-lgnum eq lgnum.

  MOVE-CORRESPONDING p_lips TO lief_tab.

ENDFORM.                               " GET_LIPS
*---------------------------------------------------------------------*
*      Form  GET_VBUP                                                 *
*---------------------------------------------------------------------*
*      Aktionen, die bei GET VBUP ausgeführt werden                   *
*---------------------------------------------------------------------*
FORM get_vbup USING name     LIKE ldbn-ldbnode "Knotenname
                    p_vbup     LIKE vbup " Daten
                    mode     TYPE c    " G(et) oder L(ate)
                    selected TYPE c.   " Knoten gewünscht

*........Ist die Lieferposition überhaupt WM-relevant ?................
  CHECK p_vbup-lvsta NE ' '.

*........merke den WBstatus die Herkunft der Lieferpsoition............
  lief_tab-lvsta = p_vbup-lvsta.
  lief_tab-wbsta = p_vbup-wbsta.
  lief_tab-verursys = gs_likp-verursys.


ENDFORM.                               " GET_VBUP
*---------------------------------------------------------------------*
*      Form  GET_VBFA                                                 *
*---------------------------------------------------------------------*
*      Aktionen, die bei GET VBFA ausgeführt werden                   *
*---------------------------------------------------------------------*
FORM get_vbfa USING name     LIKE ldbn-ldbnode "Knotenname
                    p_vbfa   LIKE vbfa " Daten
                    mode     TYPE c    " G(et) oder L(ate)
                    selected TYPE c.   " Knoten gewünscht

*........Liefer- und Belegdaten in interne Tabelle wegschreiben........

  MOVE-CORRESPONDING p_vbfa TO lt_vbfa.
  APPEND lt_vbfa.

  MOVE: p_vbfa-vbeln TO lief_tab-vbelt,
        p_vbfa-posnn TO lief_tab-posnn,
        p_vbfa-vbeln TO lief_tab-tanum,
        p_vbfa-posnn TO lief_tab-tapos,
        p_vbfa-rfmng TO lief_tab-rfmng,
        p_vbfa-meins TO lief_tab-meins,
        p_vbfa-kzbef TO lief_tab-kzbef.

*........Bezieht sich die Lieferposition auf selektierte Lagernummer ?.
  CHECK lief_tab-lgnum EQ lgnum.
*........Keine bereits rückgelagerten Positionen.......................
*  check p_vbfa-plmin ne con_minus.                     n_1638123
*........Nur Transportaufträge.........................................
  CHECK p_vbfa-vbtyp_n EQ 'Q'.


  IF p_vbfa-plmin NE con_minus.                         "v_n_1638123
    APPEND lief_tab.
* Append into lief_tab_ret for the transfer order items already returned
*(confirmed / not confirmed)
  ELSEIF p_vbfa-plmin EQ con_minus AND
         p_vbfa-rfmng GT 0.
    MOVE-CORRESPONDING lief_tab TO lief_tab_ret.
    APPEND lief_tab_ret.                              "^_n_1638123
  ENDIF.

ENDFORM.                               " GET_VBFA


*--------------------------------------------------  "V_N_1127095  ---*
*      Form  PRUEF_RUECKMNG_LE_AUSLAGMNG                              *
*---------------------------------------------------------------------*
*      Pruefen ob Rücklagerungsmenge kleiner gleich Auslagerungsmenge *
*---------------------------------------------------------------------*
*     <-- E_MNGIO  Menge in Ordnung                                   *
*---------------------------------------------------------------------*
FORM pruef_rueckmng_le_auslagmng USING e_mngio.

  DATA: lf_verme TYPE menge_d.

  e_mngio = 'X'.

  CLEAR gt_rueck_mng. REFRESH gt_rueck_mng.
  LOOP AT itab.
    IF itab-ikone = sym_flash.
      MESSAGE i619(l1).
      CLEAR e_mngio.
      EXIT.
    ENDIF.
    CHECK itab-ikone EQ sym_checkbox.
    CHECK itab-verme GT 0.
    gt_rueck_mng-lgnum = itab-lgnum.
    gt_rueck_mng-matnr = itab-matnr.
    gt_rueck_mng-werks = itab-werks.
    gt_rueck_mng-bestq = itab-bestq.
    gt_rueck_mng-sobkz = itab-sobkz.
    gt_rueck_mng-charg = itab-charg.
    gt_rueck_mng-sonum = itab-sonum.
    gt_rueck_mng-lgtyp = itab-lgtyp.
    gt_rueck_mng-lgpla = itab-lgpla.
    gt_rueck_mng-lgort = itab-lgort.
    gt_rueck_mng-verme = itab-verme.
    gt_rueck_mng-lenum = itab-lenum.                        "n_2150273
    COLLECT gt_rueck_mng.
  ENDLOOP. "  AT ITAB.
  CHECK NOT e_mngio IS INITIAL.
  LOOP AT gt_rueck_mng.
    LOOP AT itab WHERE lgnum EQ gt_rueck_mng-lgnum
                 AND   matnr EQ gt_rueck_mng-matnr
                 AND   werks EQ gt_rueck_mng-werks
                 AND   bestq EQ gt_rueck_mng-bestq
                 AND   sobkz EQ gt_rueck_mng-sobkz
                 AND   charg EQ gt_rueck_mng-charg
                 AND   sonum EQ gt_rueck_mng-sonum
                 AND   lgtyp EQ gt_rueck_mng-lgtyp
                 AND   lgpla EQ gt_rueck_mng-lgpla
                 AND   lgort EQ gt_rueck_mng-lgort
                 AND   lenum EQ gt_rueck_mng-lenum.         "n_2150273
      CHECK itab-ikone EQ sym_checkbox.
      CHECK itab-gesme GT 0.
      IF gt_rueck_mng-verme LE itab-gesme.
        EXIT.
      ENDIF.
      CHECK itab-verme GT 0.
      sy-msgty = 'E'.
      sy-msgid = 'L1'.
      sy-msgno = '615'.
      CLEAR: sy-msgv1, sy-msgv2, sy-msgv3, sy-msgv4.
      PERFORM error_message.
      MODIFY itab TRANSPORTING ikone farbe msgid msgty msgno.
      CLEAR e_mngio.
    ENDLOOP." at itab
    CHECK e_mngio IS INITIAL.
    EXIT.
  ENDLOOP. " at gt_rueck_mng.

ENDFORM. " pruef_rueckmng_le_auslagmng               "^_N_1127095

*---------------------------------------------------------------------*
*      Form  ERROR_MESSAGE                                            *
*---------------------------------------------------------------------*
*      Fehlermeldung aufbereiten                                      *
*---------------------------------------------------------------------*
FORM error_message.

  itab-ikone = sym_flash.
  itab-farbe = red.

  itab-msgid = sy-msgid.
  itab-msgty = sy-msgty.
  itab-msgno = sy-msgno.
  itab-msgv1 = sy-msgv1.
  itab-msgv2 = sy-msgv2.
  itab-msgv3 = sy-msgv3.
  itab-msgv4 = sy-msgv4.

ENDFORM.                               " ERROR_MESSAGE


*---------------------------------------------------------------------*
*      Form  USER_COMMAND                                             *
*---------------------------------------------------------------------*
*      User-Commands abarbeiten                                       *
*---------------------------------------------------------------------*
FORM user_command USING r_ucomm LIKE sy-ucomm
                        l_selfield TYPE slis_selfield.

  CASE r_ucomm.
    WHEN 'POST'.

      DATA : ref_grid TYPE REF TO cl_gui_alv_grid. "new

      IF ref_grid IS INITIAL.
        CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
          IMPORTING
            e_grid = ref_grid.
      ENDIF.

      IF NOT ref_grid IS INITIAL.
        CALL METHOD ref_grid->check_changed_data.
      ENDIF.

      LOOP AT itab WHERE ikone = 'X'.
        itab-ikone = sym_checkbox.
        MODIFY itab.    " TRANSPORTING ikone.
      ENDLOOP.

      READ TABLE itab WITH KEY ikone = sym_checkbox
                      TRANSPORTING NO FIELDS.

      PERFORM pruef_rueckmng_le_auslagmng USING gf_mngio.   "V_N_1127095
      CHECK NOT gf_mngio IS INITIAL.                        "^_N_1127095

      IF p_tapos = con_x.
*........TA-Positionssicht.............................................
        PERFORM einlagern_einzeln USING r_ucomm.
      ENDIF.

      IF hlp_tanum IS NOT INITIAL.
        CLEAR it_bdcdata.
        CLEAR wa_bdcdata.

***********************************************************
*BDC for confirming created TO.
***********************************************************
        PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'LTAK-TANUM'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '/00'.
        PERFORM bdc_field       USING 'LTAK-TANUM'
                                      hlp_tanum.
        PERFORM bdc_field       USING 'LTAK-LGNUM'
                                      lgnum.

        PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
                                      'LTAK-LGNUM'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
                                      '=BU'.
        CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.

        MESSAGE 'Transfer Order for Sales Return Created & Confirmed Successfully.' TYPE 'S'.
        LEAVE PROGRAM.

      ENDIF.

    WHEN 'B'.
      LEAVE TO SCREEN 0.

    WHEN 'E'.
      LEAVE PROGRAM.

  ENDCASE.

ENDFORM.                               " USER_COMMAND

*---------------------------------------------------------------------*
*      Form  EINLAGERN_EINZELN                                        *
*---------------------------------------------------------------------*
*      Einlagern von Einzelpositionen mit L_TO_CREATE_MULTIPLE        *
*---------------------------------------------------------------------*
*      -->P_UCOMM  Fcode                                              *
*---------------------------------------------------------------------*
FORM einlagern_einzeln USING p_ucomm.

*  CASE p_ucomm.
*    WHEN 'EIND'.
**........Einlagern dunkel -> Felder initialisieren.....................
*      CLEAR: nach_lgtyp,
*             nach_lgber,
*             nach_lgpla,
*             nach_plpos.
*    WHEN 'EINH'.
**........Einlagern hell -> Popup senden und Felder übernehmen..........
*      PERFORM popup_senden.
*      IF returncode = 'A'.
*        EXIT.
*      ENDIF.
*  ENDCASE.

  CLEAR sav_vbeln.
*........Loop über alle markierten Einträge............................
  LOOP AT itab WHERE ikone = sym_checkbox.

    IF itab-vbeln NE sav_vbeln.
*........nächste Lieferung.............................................
      sav_vbeln = itab-vbeln.

*........Lieferung sperren.............................................
      CALL FUNCTION 'ENQUEUE_EVVBLKE'
        EXPORTING
          vbeln          = itab-vbeln
        EXCEPTIONS
          foreign_lock   = 2
          system_failure = 3.
      IF sy-subrc <> 0.
*........Fehlermeldung ins Protokoll schreiben.........................
        LOOP AT itab WHERE vbeln = sav_vbeln AND ikone = sym_checkbox.
          PERFORM error_message.
          MODIFY itab TRANSPORTING ikone farbe msgid
                                   msgty msgno msgv1
                                   msgv2 msgv3 msgv4.
        ENDLOOP.

*........nächste Lieferung (falls vorhanden)...........................
        CONTINUE.
      ENDIF.

*........Platz sperren.................................................
*    --> wird zunächst nicht realisiert
*    --> ggf. schaltbar auf Einstiegsbild

*........Lieferungsdaten nachlesen (Kopfebene).........................
*    --> bei Abweichungen wird TA nicht erstellt
      SELECT SINGLE * FROM vbuk WHERE vbeln = sav_vbeln.
      IF vbuk-lvstk EQ ' ' OR vbuk-wbstk EQ 'C' OR sy-subrc NE 0.
        sy-msgid = 'L1'.
        sy-msgno = '609'. " Daten wurden zwischenzeitlich verändert...
        sy-msgty = 'E'.
*........Fehlermeldung ins Protokoll schreiben.........................
        LOOP AT itab WHERE vbeln = sav_vbeln AND ikone = sym_checkbox.
          PERFORM error_message.
          MODIFY itab TRANSPORTING ikone farbe msgid msgty msgno.
        ENDLOOP.
        CONTINUE.
      ENDIF.

*........Daten prüfen und ggf. TA erstellen............................
      PERFORM l_to_create_multiple_1 USING p_ucomm.

*........Spezialverarbeitung TA zurücksetzen...........................
      CALL FUNCTION 'L_TO_RESET_SPECIAL'.

*........Lieferung entsperren..........................................
      CALL FUNCTION 'DEQUEUE_EVVBLKE'
        EXPORTING
          vbeln = itab-vbeln.

    ENDIF.                             " if itab-vbeln ne sav_vbeln

  ENDLOOP. " at itab where ikone = sym_checkbox.

ENDFORM.                               " EINLAGERN_EINZELN

*---------------------------------------------------------------------*
*      Form  L_TO_CREATE_MULTIPLE_1                                   *
*---------------------------------------------------------------------*
*      Datenkontrolle und Aufruf FB L_TO_CREATE_MULTIPLE              *
*---------------------------------------------------------------------*
*      -->P_UCOMM  FCode                                              *
*---------------------------------------------------------------------*
FORM l_to_create_multiple_1 USING p_ucomm.

  DATA:
    lv_itab_index       TYPE sy-tabix.                      "1558821

*........Übergabetabelle für FB und Hilfsfeld initialisieren...........
  CLEAR ltap_creat.
  REFRESH ltap_creat.

  CLEAR hlp_itab.
  REFRESH hlp_itab.

  CLEAR summe.
*........alle markierten Positionen zu dieser Lieferung übernehmen.....
  LOOP AT itab WHERE vbeln = sav_vbeln AND ikone = sym_checkbox.
    lv_itab_index = sy-tabix.                               "1558821
*........Ist eingegebene Menge positiv?................................
    IF itab-verme LE 0.
*........Fehlermeldung ins Protokoll schreiben.........................
      sy-msgid = 'L1'.
      sy-msgno = '614'. " Verarbeitung von Mengen le 0 nicht vorgesehen
      sy-msgty = 'E'.
      PERFORM error_message.
      MODIFY itab TRANSPORTING ikone farbe msgid msgty msgno.
*........nächste Liefer-/TA-Position (falls vorhanden).................
      CONTINUE.
    ENDIF.

*........Lieferungsdaten nachlesen (Positionsebene)....................
*    --> bei Abweichungen wird TA nicht erstellt
    SELECT SINGLE * FROM vbup WHERE vbeln = itab-vbeln
                                AND posnr = itab-posnr.
    IF vbup-lvsta EQ ' ' OR sy-subrc NE 0.
      sy-msgid = 'L1'.
      sy-msgno = '609'. " Daten wurden zwischenzeitlich verändert...
      sy-msgty = 'E'.
*........Fehlermeldung ins Protokoll schreiben.........................
      PERFORM error_message.
      MODIFY itab TRANSPORTING ikone farbe msgid msgty msgno.
*........nächste Liefer-/TA-Position (falls vorhanden).................
      CONTINUE.
    ENDIF.

*........bisher rückzulagernde Summe pro Position berechnen............
    ON CHANGE OF itab-vbeln OR itab-posnr.
      CLEAR summe.
      CLEAR kommi_menge.
*........kommissionierte Menge der Lieferposition ermitteln............
      SELECT * FROM vbfa WHERE vbelv   = itab-vbeln
                           AND posnv   = itab-posnr
                           AND vbtyp_n = 'Q'.

        IF vbfa-plmin = space.
          kommi_menge = kommi_menge + vbfa-rfmng.
        ELSEIF vbfa-plmin = con_minus. " Rücklagerung
          kommi_menge = kommi_menge - vbfa-rfmng.
        ENDIF.

      ENDSELECT.
    ENDON.
    summe = summe + itab-verme.

    SELECT SINGLE * FROM vbfa WHERE vbelv   = itab-vbeln
                                AND posnv   = itab-posnr
                                AND vbeln   = itab-vbfa_vbeln
                                AND posnn   = itab-posnn
                                AND vbtyp_n = 'Q'.
    IF ( vbfa-lgnum <> lgnum )
      OR ( summe > kommi_menge )
      OR ( sy-subrc NE 0 ).
      IF summe > kommi_menge.
        sy-msgid = 'L1'.
        sy-msgno = '615'. " Eingeteilte Menge überschreitet...
        sy-msgty = 'E'.
      ELSE.
        sy-msgid = 'L1'.
        sy-msgno = '609'. " Daten wurden zwischenzeitlich verändert...
        sy-msgty = 'E'.
      ENDIF.
*........Fehlermeldung ins Protokoll schreiben.........................
      PERFORM error_message.
      MODIFY itab TRANSPORTING ikone farbe msgid msgty msgno.
*........nächste Liefer-/TA-Position (falls vorhanden).................
      CONTINUE.
    ENDIF.

*........bei Rücklagern, VON-Daten als NACH-Daten übernehmen...........
    IF p_ucomm = 'POST'.
*........bei Rücklagern pro Position VON-Daten als NACH-Daten nehmen...
      nach_lgtyp = itab-vltyp.
      nach_lgber = itab-lgber.
      nach_lgpla = itab-vlpla.
      nach_plpos = itab-vppos.
    ENDIF.

*........VON- und NACH-Daten in LTAP_CREAT schreiben...................
*    --> LTAP_CREAT enthält nur die Daten der "fehlerfreien" Positionen
    MOVE: itab-werks  TO ltap_creat-werks, " VON-Daten
          itab-lgort  TO ltap_creat-lgort,
          itab-matnr  TO ltap_creat-matnr,
          itab-charg  TO ltap_creat-charg,
          itab-bestq  TO ltap_creat-bestq,
          itab-sobkz  TO ltap_creat-sobkz,
          itab-sonum  TO ltap_creat-sonum,
          itab-verme  TO ltap_creat-anfme,
          itab-meins  TO ltap_creat-altme,
          itab-lqnum  TO ltap_creat-vlqnr,
          itab-lenum  TO ltap_creat-vlenr,
          nach_lgpla  TO ltap_creat-nlpla, " NACH-Daten
          nach_plpos  TO ltap_creat-nppos,
          nach_lgtyp  TO ltap_creat-nltyp,
          nach_lgber  TO ltap_creat-nlber,
          rldru-ldest TO ltap_creat-ldest,
          rl03t-squit TO ltap_creat-squit,
          itab-posnr  TO ltap_creat-posnr. " Lieferposition
*........falls Material aus LE-verw. Lagertyp kam und für die
*........Rücklagerung keine LE-Nr vorgegeben wurde, wird die alte
*........LE-Nr wiederverwendet, falls es sich um eine homogene
*........Vollentnahme handelte
    IF lein-lenum IS INITIAL
      AND lein-letyp IS INITIAL
      AND NOT itab-vlenr IS INITIAL
      AND itab-homve = con_x.
                                                            "v_n_825148
*... also check that old SU numbers can be reused acc. to customizing
      PERFORM lenum_extern USING itab-vlenr sy-subrc.
      IF sy-subrc = 0.
        MOVE itab-vlenr TO ltap_creat-nlenr.
      ELSE.
        CLEAR ltap_creat-nlenr.
      ENDIF.
      MOVE: itab-ltap_letyp TO ltap_creat-letyp.            "^_n_825148

    ELSE.
      MOVE: lein-lenum  TO ltap_creat-nlenr,
            lein-letyp  TO ltap_creat-letyp.

    ENDIF.

    ltap_creat-itab_index = lv_itab_index.                  "1558821
    APPEND ltap_creat.
    MOVE itab TO hlp_itab.
    APPEND hlp_itab.

  ENDLOOP. " where vbeln = sav_vbeln and ikone = sym_checkbox

*........Funktionsbausteine zur TA-Erstellung aufrufen.................
  CALL FUNCTION 'L_TO_SET_SPECIAL'
    EXPORTING
      i_spezi        = con_spezi_b
      i_vbeln        = itab-vbeln
    EXCEPTIONS
      call_forbidden = 1
      input_wrong    = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
*........Fehler........................................................
*    --> alle Positionen in LTAP_CREAT/HLP_ITAB rot färben
    LOOP AT hlp_itab.
      READ TABLE itab WITH KEY vbeln      = hlp_itab-vbeln
                               posnr      = hlp_itab-posnr
                               ltap_tanum = hlp_itab-ltap_tanum
                               ltap_tapos = hlp_itab-ltap_tapos.
      IF sy-subrc = 0.
*........Fehlermeldung ins Protokoll schreiben.........................
        PERFORM error_message.
        MODIFY itab INDEX sy-tabix TRANSPORTING ikone farbe msgid
                                                msgty msgno msgv1
                                                msgv2 msgv3 msgv4.
      ENDIF.
    ENDLOOP.
  ELSE.
    PERFORM docu_batch_buffer_itab                          "1530856
      TABLES itab
             gt_gi_canc.

    CALL FUNCTION 'L_TO_CREATE_MULTIPLE'
      EXPORTING
        i_lgnum       = lgnum
        i_bwlvs       = bwlvs
*       I_BETYP       = ' '
*       I_BENUM       = ' '
*       I_LZNUM       = ' '
        i_nidru       = rldru-proto
        i_drukz       = rldru-drukz
*       I_UPDATE_TASK = ' '
        i_commit_work = 'X'
*       I_BNAME       = SY-UNAME
*       I_KOMPL       = 'X'
*       I_SOLEX       = 0
*       I_PERNR       = 0
*       I_MINWM       = ' '
      IMPORTING
        e_tanum       = hlp_tanum
      TABLES
        t_ltap_creat  = ltap_creat[]
      EXCEPTIONS
        error_message = 99.

    COMMIT WORK AND WAIT.

    IF sy-subrc = 99.
*........Fehler bei der TA-Erstellung aufgetreten......................
*    --> alle Positionen in LTAP_CREAT/HLP_ITAB rot färben
      LOOP AT hlp_itab.
        READ TABLE itab WITH KEY vbeln      = hlp_itab-vbeln
                                 posnr      = hlp_itab-posnr
                                 ltap_tanum = hlp_itab-ltap_tanum
                                 ltap_tapos = hlp_itab-ltap_tapos.
        IF sy-subrc = 0.
*........Fehlermeldung ins Protokoll schreiben.........................
          PERFORM error_message.
          MODIFY itab INDEX sy-tabix TRANSPORTING ikone farbe msgid
                                                  msgty msgno msgv1
                                                  msgv2 msgv3 msgv4.
        ENDIF.
      ENDLOOP.
    ELSE.
*........TA erfolgreich erstellt.......................................
*    --> alle Positionen in LTAP_CREAT/HLP_ITAB grün färben
      LOOP AT hlp_itab.
        READ TABLE itab WITH KEY vbeln      = hlp_itab-vbeln
                                 posnr      = hlp_itab-posnr
                                 ltap_tanum = hlp_itab-ltap_tanum
                                 ltap_tapos = hlp_itab-ltap_tapos.
        IF sy-subrc = 0.
*........TA-Nummer ins Protokoll schreiben.............................
          itab-ikone = sym_check_mark.
          itab-farbe = green.
          itab-tanum = hlp_tanum.
          MODIFY itab INDEX sy-tabix TRANSPORTING ikone farbe tanum
                                                  msgid msgty msgno.
        ENDIF.
      ENDLOOP.
    ENDIF.                             " sy-subrc = 99

*........Enqueuesperren der LUW freigeben..............................
*........(vgl. 0120024545 0001221580 1998 CSS).........................
    CALL FUNCTION 'DEQUEUE_ALL'.

  ENDIF.                               " sy-subrc <> 0
ENDFORM.                               " L_TO_CREATE_MULTIPLE_1

*---------------------------------------------------------------------*
*      Form  DOCU_BATCH_BUFFER_ITAB                           1530856 *
*---------------------------------------------------------------------*
FORM docu_batch_buffer_itab
  TABLES
    it_screen_tab       STRUCTURE itab
    it_gi_canc          STRUCTURE ltap.

  DATA:
    lv_function_name TYPE rs38l_fnam,
    lt_rl034         TYPE STANDARD TABLE OF rl034,
    ls_rl034         TYPE rl034.

  DATA:
    lv_any_active    TYPE xfeld,
    ls_screen_tab    LIKE itab,
    ls_docubatch_com TYPE docubatch_com.

  LOOP AT it_screen_tab INTO ls_screen_tab.                 "1558821
    MOVE-CORRESPONDING ls_screen_tab TO ls_rl034.
    APPEND ls_rl034 TO lt_rl034.

    MOVE-CORRESPONDING ls_screen_tab TO ls_docubatch_com.

* check line about documentary relevance
    CALL FUNCTION 'VBDBDM_ACTIVE_CHECK_DETAIL'
      EXPORTING
        i_matnr            = ls_screen_tab-matnr
        i_werks            = ls_screen_tab-werks
        i_application_id   = '03'
        is_docubatch_com   = ls_docubatch_com
      EXCEPTIONS
        process_not_active = 1
        OTHERS             = 99.
    IF sy-subrc IS NOT INITIAL.
      CONTINUE.
    ENDIF.
    lv_any_active        = 'X'.

  ENDLOOP.

  CHECK lv_any_active = 'X'.

  lv_function_name = 'VBDBDM_CHVW_WM_LT0G_S1'.

  CALL FUNCTION 'FUNCTION_EXISTS'
    EXPORTING
      funcname           = lv_function_name
    EXCEPTIONS
      function_not_exist = 1
      OTHERS             = 2.
  IF sy-subrc = 0.

    CALL FUNCTION lv_function_name "VBDBDM_CHVW_WM_LT0G_S1
      TABLES
        it_rl034   = lt_rl034[]
        it_gi_canc = it_gi_canc[].

  ENDIF.

ENDFORM. " docu_batch_buffer_itab             "1530856

*&---------------------------------------------------------------------*
*&      Form  LENUM_EXTERN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_ITAB_VLENR  text
*      -->P_SY_SUBRC  text
*----------------------------------------------------------------------*
FORM lenum_extern USING VALUE(p_itab_vlenr) CHANGING VALUE(p_sy_subrc).

  DATA: answer(1) TYPE c.

  SELECT SINGLE * FROM t340d
  WHERE lgnum = itab-lgnum.

  IF sy-subrc NE 0.
    MESSAGE e701 WITH itab-lgnum.
  ENDIF.

  p_sy_subrc = r_ok.

  IF t340d-verle IS INITIAL.
    p_sy_subrc = r_verle_nicht_da.
    EXIT.
  ENDIF.

*........Sperren der Lagereinheit.......................................

  CALL FUNCTION 'ENQUEUE_ELLEINE'
    EXPORTING
      lenum          = p_itab_vlenr
    EXCEPTIONS
      foreign_lock   = 1
      system_failure = 2.

  CASE sy-subrc.
    WHEN 1. MESSAGE e276(l3) WITH p_itab_vlenr.
    WHEN 2. MESSAGE e141.
  ENDCASE.

*........Überprüfen der Intervallsituation bzgl. der externen Nummer....

  CALL FUNCTION 'L_LENUM_EXTERNAL_NUMBER_CHECK'
    EXPORTING
      external_number = p_itab_vlenr
      number_range_nr = t340d-nukle
    IMPORTING
      answer          = answer.

  CASE answer.

*........korrekte Nummer außerhalb aller Intervalle.....................

    WHEN r_lvsk_ok.
      IF t340d-verle = con_verle_intern OR
         t340d-verle = con_verle_int_ehe.
        p_sy_subrc = r_extern_verboten.
      ENDIF.

*........Nummer in der Zukunft des eigenen Nummernkreises...............

    WHEN r_lvsk_zukunft_eigen.
      p_sy_subrc = r_zukunft_verboten.

*........Nummer in der Vergangenheit des eigenen Nummernkreises.........

    WHEN r_lvsk_vergangen_eigen.
      IF t340d-verle = con_verle_intern OR
         t340d-verle = con_verle_extern OR
         t340d-verle = con_verle_int_ext.
        p_sy_subrc = r_recycling_verboten.
      ENDIF.

*........Nummer in der Zukunft eines fremden Nummernkreises.............

    WHEN r_lvsk_zukunft_fremd.
      p_sy_subrc = r_kollision_fremd.

*........Nummer in der Vergangenheit eines fremden Nummernkreises.......

    WHEN r_lvsk_vergangen_fremd.
      IF t340d-verle = con_verle_intern OR
         t340d-verle = con_verle_int_ehe.
        p_sy_subrc = r_extern_verboten.
      ENDIF.
  ENDCASE.

ENDFORM.                    " LENUM_EXTERN

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
************************************************************************
**        END OF PROGRAMM                                              *
************************************************************************
