*&---------------------------------------------------------------------*
*& Report ZWM_WSCHEME_REP
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zwm_wscheme_rep.

*Data Declaration
INCLUDE zwm_wscheme_top.

*Selection Screen
INCLUDE zwm_wscheme_s01.

*Implementation
INCLUDE zwm_wscheme_f01.
