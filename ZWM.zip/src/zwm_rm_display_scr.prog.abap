*************************************************************************************
*Object Name              : ZWM_SU_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 06/04/2019.
*************************************************************************************
*Description              : include for selection screen FOR RM DISPLAY.
*************************************************************************************
*********************************************************
*structure definition of lqua.
*********************************************************
*
*selection-SCREEN BEGIN OF SCREEN 9000 as SUBSCREEN.
*
*  PARAMETERS : p_scan  TYPE char40 OBLIGATORY,
*               p_lgtyp type lgtyp OBLIGATORY.
*
*SELECTION-SCREEN END OF SCREEN 9000.
