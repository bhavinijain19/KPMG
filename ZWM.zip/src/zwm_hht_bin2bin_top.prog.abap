*************************************************************************************
*Object Name              : ZWM_HHT_BIN2BIN_top.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Global data declaration
*************************************************************************************
*********************************************************
*Data declaration(variables)
*********************************************************

DATA: flag            TYPE c VALUE 0.
DATA: flag2           TYPE c VALUE 0.
DATA: flag_move       TYPE c VALUE 0.
DATA: flag_select_all TYPE c VALUE 0.
DATA: flag_bapi       TYPE c VALUE 0.
DATA: flag_confirm    TYPE c VALUE 0.
DATA: flag_validate   TYPE c VALUE 0.
DATA: flag_ltap_creat TYPE c VALUE 0.
DATA: flag_enter      TYPE c VALUE 0.
DATA ok_code          TYPE sy-ucomm.
DATA idx              TYPE i.
DATA lines            TYPE i.
DATA line             TYPE i.
DATA cnt              TYPE c LENGTH 3 VALUE '0'.
DATA c                TYPE i.
DATA fill             TYPE i.
DATA p_num            TYPE i.
data limit            TYPE i.
DATA check            TYPE c.

*********************************************************
*structure definition of lqua.
*********************************************************
TYPES : BEGIN OF ty_lqua,

          lgnum TYPE lgnum,
          lqnum TYPE lvs_lqnum,
          matnr TYPE matnr,
          werks TYPE werks_d,
          charg TYPE charg_d,
          bestq TYPE bestq,
          sobkz TYPE sobkz,
          sonum TYPE lvs_sonum,
          lgtyp TYPE lgtyp,
          lgpla TYPE lgpla,
          letyp TYPE lvs_letyp,
          meins TYPE meins,
          verme TYPE lqua_verme,
          lenum TYPE lenum,
          lgort TYPE lgort_d,
          sel   TYPE c,

        END OF ty_lqua.
*********************************************************
*structure definition of zwm_picklist
*********************************************************
TYPES :BEGIN OF ty_zwm_picklist,
         werks TYPE  werks_d,
         lgort TYPE lgort_d,
         lgnum TYPE lgnum,
         lgber TYPE  lgber,
       END OF ty_zwm_picklist.
*********************************************************
*structure definition of lagp
*********************************************************
TYPES:BEGIN OF ty_lagp,
        lgnum TYPE lagp-lgnum,
        lgtyp TYPE lagp-lgtyp,
        lgpla TYPE lagp-lgpla,
      END OF ty_lagp.
DATA:v_lagp TYPE ty_lagp.

TYPES: BEGIN OF ty_lagp1,
         lgtyp TYPE lagp-lgtyp,
         lgpla TYPE lagp-lgpla,
         lgber TYPE lagp-lgber,
       END OF ty_lagp1.

*********************************************************
*Internal tables and work area declaration.
*********************************************************
DATA:  v_lagp1         TYPE ty_lagp1.
DATA : it_lqua         TYPE STANDARD TABLE OF ty_lqua.
DATA : it_lqua1        TYPE STANDARD TABLE OF ty_lqua,
       wa_lqua         TYPE ty_lqua,
       wa_zwm_picklist TYPE ty_zwm_picklist,
       it_zwm_picklist TYPE STANDARD TABLE OF ty_zwm_picklist,
       it_bdcdata      TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
       wa_bdcdata      TYPE bdcdata,                            "bdc internal table declaration.
       it_ltap_creat   TYPE STANDARD TABLE OF ltap_creat,
       wa_ltap_creat   TYPE ltap_creat.

DATA gv_tanum TYPE ltak-tanum.
DATA:v_lgnum  TYPE lgnum,
     v_lgtyp  TYPE lgtyp,
     v_lgpla  TYPE lgpla,
     v1_lgtyp TYPE lgtyp,
     v1_lgpla TYPE lgpla,
     v_lgber  TYPE lgber.


DATA   gv_text TYPE char100.

data : p_lgnum  TYPE lagp-lgnum,
       p_lgtyps TYPE lagp-lgtyp,
       p_lgplas TYPE lagp-lgpla,
       p_lgtypd TYPE lagp-lgtyp,
       p_lgplad TYPE lagp-lgpla,
       p_lgber  TYPE lagp-lgber.
