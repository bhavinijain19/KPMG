*************************************************************************************
*Object Name              : ZWM_LOAD_DELETE_TOP.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 12/05/2019.
*************************************************************************************
*Description              : Data declaration include.
*************************************************************************************
CLASS load_delete DEFINITION DEFERRED.

TYPES: BEGIN OF ty_final,

         load_no        TYPE zmm_load_sloc1-load_no,
         load_item      TYPE zmm_load_sloc1-load_item,
         su_no          TYPE zmm_load_sloc1-su_no,
         obd_no         TYPE zmm_load_sloc1-obd_no,
         obd_lineitem   TYPE zmm_load_sloc1-obd_lineitem,
         obd_headitem   TYPE zmm_load_sloc1-obd_headitem,
         entry_date     TYPE zmm_load_sloc1-entry_date,
         storage_loc    TYPE zmm_load_sloc1-storage_loc,
         plant          TYPE zmm_load_sloc1-plant,
         matnr          TYPE zmm_load_sloc1-matnr,
         batch_no       TYPE zmm_load_sloc1-batch_no,
         quantity       TYPE zmm_load_sloc1-quantity,
         uom            TYPE zmm_load_sloc1-uom,
         bin_loc        TYPE zmm_load_sloc1-bin_loc,
         load_status    TYPE zmm_load_sloc1-load_status,
         su_qty         TYPE zmm_load_sloc1-su_qty,
         to_create_date TYPE zmm_load_sloc1-to_create_date,
         to_no          TYPE zmm_load_sloc1-to_no,

       END OF ty_final.

DATA it_final TYPE STANDARD TABLE OF ty_final.

DATA : alv_container TYPE REF TO cl_gui_custom_container,     "container reference to class.
       alv_grid      TYPE REF TO cl_gui_alv_grid,
       fieldcat      TYPE lvc_t_fcat,                         "internal table for fieldcat.
       ty_toolbar    TYPE stb_button,
       it_layout     TYPE lvc_s_layo.

DATA obj TYPE REF TO load_delete.                               "creating reference of class object.

data: it_load TYPE STANDARD TABLE OF zmm_load_sloc1,
      it_load_tmp TYPE STANDARD TABLE OF zmm_load_sloc1.
DATA: lt_su_upd TYPE TABLE OF zwm_pallet_map,
      lt_plant_config TYPE TABLE OF zwm_plant_config.
