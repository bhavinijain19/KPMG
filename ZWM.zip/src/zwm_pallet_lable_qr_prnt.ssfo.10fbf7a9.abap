*    CLEAR: lv_qty.
*    lv_qty = wa_su_no2-zsu_no - wa_su_no1-zsu_no.
*    lv_qty = lv_qty + 1.
























