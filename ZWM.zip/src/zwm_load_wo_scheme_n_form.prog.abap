*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_N_FORM
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SET_DROPDOWN_VALUES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_dropdown_values .

  "Set Scan Type DropDown
  lv_name = 'LV_SCAN_TYPE'.
  IF lt_scan_type_list IS INITIAL.

    ls_value-key = 'FP'.
    ls_value-text = 'Full Pallet'.
    APPEND ls_value TO lt_scan_type_list.
    CLEAR ls_value.

    ls_value-key = 'PI'.
    ls_value-text = 'Partial Include'.
    APPEND ls_value TO lt_scan_type_list.
    CLEAR ls_value.

    ls_value-key = 'PE'.
    ls_value-text = 'Partial Exclude'.
    APPEND ls_value TO lt_scan_type_list.
    CLEAR ls_value.

    ls_value-key = 'SU'.
    ls_value-text = 'SU(Box)'.
    APPEND ls_value TO lt_scan_type_list.
    CLEAR ls_value.

  ENDIF.

  CALL FUNCTION 'VRM_SET_VALUES'
    EXPORTING
      id     = lv_name
      values = lt_scan_type_list.


  "Set QR/Barcode Type DropDown

  lv_name = 'LV_BARCODE_TYPE'.
  IF lt_barcode_type_list IS INITIAL.

    ls_value-key = 'PA'.
    ls_value-text = 'Scan Pallet'.
    APPEND ls_value TO lt_barcode_type_list.
    CLEAR ls_value.

    ls_value-key = 'SU'.
    ls_value-text = 'Scan SU'.
    APPEND ls_value TO lt_barcode_type_list.
    CLEAR ls_value.

  ENDIF.

  CALL FUNCTION 'VRM_SET_VALUES'
    EXPORTING
      id     = lv_name
      values = lt_barcode_type_list.


  "Set QR/Barcode Type DropDown

  lv_name = 'LV_LOAD_TYPE'.
  IF lt_load_type_list IS INITIAL.

    ls_value-key = 'FL'.
    ls_value-text = 'Full Load'.
    APPEND ls_value TO lt_load_type_list.
    CLEAR ls_value.

    ls_value-key = 'PL'.
    ls_value-text = 'Partial Load'.
    APPEND ls_value TO lt_load_type_list.
    CLEAR ls_value.

  ENDIF.

  CALL FUNCTION 'VRM_SET_VALUES'
    EXPORTING
      id     = lv_name
      values = lt_load_type_list.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout1 .

  gs_layout1-zebra       = 'X'.
  gs_layout1-stylefname = 'FIELD_STYLE'.
  gs_layout1-sel_mode    = lv_sel_mode. "'B'. "To be changed as A
  gs_layout1-cwidth_opt  = 'X'.
  gs_layout1-no_toolbar  = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu1 .

  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude1  = p_lt_exclude.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat1 .

  CLEAR: gt_fcat1.

  wa_fcat-tabname = 'LT_MAT_LIST'.
  wa_fcat-fieldname = 'ITEM_NUMBER'.
  wa_fcat-scrtext_m = 'Item'.
  APPEND wa_fcat TO gt_fcat1.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_MAT_LIST'.
  wa_fcat-fieldname = 'MATERIAL'.
  wa_fcat-scrtext_m = 'Mat Code'.
  APPEND wa_fcat TO gt_fcat1.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_MAT_LIST'.
  wa_fcat-fieldname = 'DESCRIPTION'.
  wa_fcat-scrtext_m = 'Description'.
  APPEND wa_fcat TO gt_fcat1.
  CLEAR: wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout2 .

  gs_layout2-zebra       = 'X'.
  gs_layout2-stylefname = 'FIELD_STYLE'.
  gs_layout2-sel_mode    = 'A'.
  gs_layout2-cwidth_opt  = 'X'.
  gs_layout2-no_toolbar  = 'X'.

* Disabling selection column
  gs_layout2-sel_mode = 'A'.
  gs_layout2-no_rowmark = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat2 .

  CLEAR: gt_fcat2.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'BATCH_NUMBER'.
  wa_fcat-scrtext_m = 'Batch no'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'QTY'.
  wa_fcat-scrtext_m = 'Qty'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'UOM'.
  wa_fcat-scrtext_m = 'uom'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'BIN_NUMBER'.
  wa_fcat-scrtext_m = 'Bin No'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'REQ_BOXES'.
  wa_fcat-scrtext_m = 'Req'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'SCANNED_BOXES'.
  wa_fcat-scrtext_m = 'Scan'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_LIST'.
  wa_fcat-fieldname = 'STATUS'.
  wa_fcat-scrtext_m = 'Status'.
  APPEND wa_fcat TO gt_fcat2.
  CLEAR: wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu2 .
*    .
  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude2  = p_lt_exclude.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU3
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu3 .
*    .
  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude3  = p_lt_exclude.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT3
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout3 .

  gs_layout3-zebra       = 'X'.
  gs_layout3-stylefname = 'FIELD_STYLE'.
  gs_layout3-sel_mode    = 'B'. "To be changed as A
  gs_layout3-cwidth_opt  = 'X'.
  gs_layout3-no_toolbar  = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT3
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat3 .

  CLEAR: gt_fcat3.
  wa_fcat-tabname = 'LT_SCANNED_LIST'.
  wa_fcat-fieldname = 'PALLET_NO'.
  wa_fcat-scrtext_m = 'Pallet No'.
  APPEND wa_fcat TO gt_fcat3.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_SCANNED_LIST'.
  wa_fcat-fieldname = 'SU_NO'.
  wa_fcat-scrtext_m = 'SU No'.
  APPEND wa_fcat TO gt_fcat3.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_SCANNED_LIST'.
  wa_fcat-fieldname = 'DELETE_FLAG'.
  wa_fcat-scrtext_m = 'D'.
  APPEND wa_fcat TO gt_fcat3.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_SCANNED_LIST'.
  wa_fcat-fieldname = 'DELETE_BUTTON'.
  wa_fcat-style = cl_gui_alv_grid=>mc_style_button.
  APPEND wa_fcat TO gt_fcat3.
  CLEAR: wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT4
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout4 .

  gs_layout4-zebra       = 'X'.
  gs_layout4-stylefname = 'FIELD_STYLE'.
  gs_layout4-sel_mode    = 'A'.
  gs_layout4-cwidth_opt  = 'X'.
  gs_layout4-no_toolbar  = 'X'.

* Disabling selection column
  gs_layout4-sel_mode = 'A'.
  gs_layout4-no_rowmark = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU4
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu4 .

  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude4  = p_lt_exclude.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT4
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat4 .

  CLEAR: gt_fcat4.

  wa_fcat-tabname = 'LT_BATCH_EXP'.
  wa_fcat-fieldname = 'MATERIAL'.
  wa_fcat-scrtext_m = 'Material No'.
  APPEND wa_fcat TO gt_fcat4.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_EXP'.
  wa_fcat-fieldname = 'BATCH_NUMBER'.
  wa_fcat-scrtext_m = 'Batch No'.
  APPEND wa_fcat TO gt_fcat4.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_BATCH_EXP'.
  wa_fcat-fieldname = 'EXPIRY_DATE'.
  wa_fcat-scrtext_m = 'Expiry'.
  APPEND wa_fcat TO gt_fcat4.
  CLEAR: wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DETAIL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_detail USING p_row_selected TYPE lvc_index.

  CLEAR: lt_batch_list,lt_scanned_list.
  READ TABLE lt_mat_list INTO ls_mat_list INDEX p_row_selected.
  IF sy-subrc EQ 0.
    lv_mat_code = ls_mat_list-material.
    lv_detail_disp = 'X'.
    lt_batch_list = ls_mat_list-batch_list.
    LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
      APPEND LINES OF ls_batch_list-scanned_list TO lt_scanned_list.
    ENDLOOP.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT5
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout5 .

  gs_layout5-zebra       = 'X'.
  gs_layout5-stylefname = 'FIELD_STYLE'.
  gs_layout5-sel_mode    = lv_sel_mode. "'Bin dev and QA "A in PRD
  gs_layout5-cwidth_opt  = 'X'.
  gs_layout5-no_toolbar  = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU5
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu5 .

  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude5  = p_lt_exclude.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT5
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat5 .

  CLEAR: gt_fcat5.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'ITEM_NO'.
  wa_fcat-scrtext_m = 'Item'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'MATERIAL'.
  wa_fcat-scrtext_m = 'Mat code'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'BATCH_NUMBER'.
  wa_fcat-scrtext_m = 'Batch No'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'REQ_BOXES'.
  wa_fcat-scrtext_m = 'Req'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'SCANNED_BOXES'.
  wa_fcat-scrtext_m = 'Scan'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_LOAD_LIST'.
  wa_fcat-fieldname = 'EXPIRY_DATE'.
  wa_fcat-scrtext_m = 'Expiry'.
  APPEND wa_fcat TO gt_fcat5.
  CLEAR: wa_fcat.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_DYNPRO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_2449   text
*      -->P_2450   text
*----------------------------------------------------------------------*
FORM bdc_dynpro  USING program dynpro.
  CLEAR ls_bdcdata.
  ls_bdcdata-program  = program.
  ls_bdcdata-dynpro   = dynpro.
  ls_bdcdata-dynbegin = abap_true.
  APPEND ls_bdcdata TO lt_bdcdata.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC_FIELD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_2464   text
*      -->P_2465   text
*----------------------------------------------------------------------*
FORM bdc_field  USING    fnam fval.

  CLEAR ls_bdcdata.
  ls_bdcdata-fnam = fnam.
  ls_bdcdata-fval = fval.
  APPEND ls_bdcdata TO lt_bdcdata.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_BIN_NO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_bin_no.

*  CLEAR: lt_scanned_list_tmp.
*  LOOP AT lt_mat_list INTO ls_mat_list.
*    LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
*      APPEND LINES OF ls_batch_list-scanned_list TO lt_scanned_list_tmp.
*    ENDLOOP.
*  ENDLOOP.

  IF lt_scanned_list_tmp[] IS NOT INITIAL.

    SELECT lenum lgnum letyp lgtyp lgpla FROM lein INTO TABLE lt_lein FOR ALL ENTRIES IN lt_scanned_list_tmp
      WHERE lenum = lt_scanned_list_tmp-su_no.
    IF sy-subrc EQ 0.

      LOOP AT lt_mat_list ASSIGNING <fs_mat_list>.
        LOOP AT <fs_mat_list>-batch_list ASSIGNING <fs_batch_list>.
          <fs_batch_list>-bin_number = ''.
          LOOP AT <fs_batch_list>-scanned_list INTO ls_scanned_list.
            READ TABLE lt_lein INTO ls_lein WITH KEY lenum = ls_scanned_list-su_no.
            IF sy-subrc EQ 0 AND <fs_batch_list>-bin_number NS ls_lein-lgpla.
              IF <fs_batch_list>-bin_number IS INITIAL.
                <fs_batch_list>-bin_number = ls_lein-lgpla.
              ELSE.
                CONCATENATE <fs_batch_list>-bin_number ',' INTO <fs_batch_list>-bin_number.
                CONCATENATE <fs_batch_list>-bin_number ls_lein-lgpla INTO <fs_batch_list>-bin_number SEPARATED BY space.
              ENDIF.
            ENDIF.
            CLEAR ls_scanned_list.
          ENDLOOP.
        ENDLOOP.
      ENDLOOP.

    ENDIF.

  ENDIF.

  IF lv_detail_disp EQ 'X'.
    PERFORM get_detail USING lv_row_selected.
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SCREEN_CHANGES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM screen_changes.

  IF lv_obd_flag EQ 'X'.
    LOOP AT SCREEN.
      IF screen-group1 EQ 'G6'.
        screen-input = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ELSE.
    LOOP AT SCREEN.
      IF screen-group1 EQ 'G6'.
        screen-input = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.

  IF lv_detail_disp EQ 'X'.
    LOOP AT SCREEN.
      IF screen-group1 EQ 'G3'.
        screen-invisible = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ELSE.
    LOOP AT SCREEN.
      IF screen-group1 EQ 'G3'.
        screen-invisible = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
  ENDIF.

  LOOP AT SCREEN.
    IF screen-group1 EQ 'G4'. "or screen-group1 EQ 'G7'.
      screen-invisible = 1.
    ELSEIF screen-group1 EQ 'G1'.
      IF lv_scan_type EQ 'SU' OR lv_scan_type EQ ''.
        screen-invisible = 1.
        screen-active = 0.
      ELSE.
        screen-invisible = 0.
        screen-active = 1.
      ENDIF.
    ELSEIF screen-group1 EQ 'G2'.
      IF lv_scan_type EQ 'FP' OR lv_scan_type EQ ''.
        screen-invisible = 1.
        screen-active = 0.
      ELSE.
        screen-invisible = 0.
        screen-active = 1.
      ENDIF.
    ELSEIF screen-group1 EQ 'G7'.
      IF lt_incomplete_mat_list IS NOT INITIAL AND lv_mat_count GE 3.
        screen-invisible = 0.
        screen-active = 1.
      ELSE.
        screen-invisible = 1.
        screen-active = 0.
      ENDIF.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.

  IF sy-ucomm EQ 'SCAN_TYPE_SELECTED'.
    CLEAR: lv_pallet_cursor, lv_su_cursor.
    IF lv_scan_type NE 'SU'.
      lv_pallet_cursor = 'X'.
    ELSE.
      lv_su_cursor = 'X'.
    ENDIF.
  ENDIF.

  IF lv_pallet_cursor EQ 'X'.
    wa_cursor = 'LV_PALETTE_NO'.
    SET CURSOR FIELD wa_cursor.
  ELSEIF lv_su_cursor EQ 'X'.
    wa_cursor = 'LV_SU_NO'.
    SET CURSOR FIELD wa_cursor.
  ENDIF.


*  IF lv_scan_type EQ 'FP'.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G1'.
*        screen-invisible = 0.
*        screen-active = 1.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G2'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G4'.
*        screen-input = 0.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*  ELSEIF lv_scan_type EQ 'SU'.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G2'.
*        screen-invisible = 0.
*        screen-active = 1.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G1'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G4'.
*        screen-input = 0.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*  ELSE.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G4'.
*        screen-input = 1.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*  ENDIF.
*
*  IF lv_barcode_type EQ 'PA'.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G1'.
*        screen-invisible = 0.
*        screen-active = 1.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G2'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*    wa_cursor = 'LV_PALETTE_NO'.
*    SET CURSOR FIELD wa_cursor.
*
*  ELSEIF lv_barcode_type EQ 'SU'.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G1'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G2'.
*        screen-invisible = 0.
*        screen-active = 1.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*    wa_cursor = 'LV_SU_NO'.
*    SET CURSOR FIELD wa_cursor.
*
*  ELSE.
*
*    LOOP AT SCREEN.
*      IF screen-group1 EQ 'G1'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ELSEIF screen-group1 EQ 'G2'.
*        screen-invisible = 1.
*        screen-active = 0.
*        MODIFY SCREEN.
*      ENDIF.
*    ENDLOOP.
*
*  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPDATE_MAPPING
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM update_mapping .

  "Delete unavailable entries
*  LOOP AT lt_sloc_temp INTO DATA(ls_sloc_temp).
*    READ TABLE lt_sloc TRANSPORTING NO FIELDS WITH KEY su_no = ls_sloc_temp-su_no.
*    IF sy-subrc NE 0.
**      DELETE lt_sloc_del WHERE su_no = ls_sloc_temp-su_no.
*      APPEND ls_sloc_temp TO lt_sloc_del.
*    ENDIF.
*    CLEAR: ls_sloc_temp.
*  ENDLOOP.
  lt_sloc_del[] = lt_sloc[].

  IF lt_sloc_del[] IS NOT INITIAL.
    SELECT * FROM zwm_pallet_map INTO TABLE lt_mapping_upd
      FOR ALL ENTRIES IN lt_sloc_del
      WHERE su_no = lt_sloc_del-su_no.
    IF lt_mapping_upd[] IS NOT INITIAL.
      DELETE zwm_pallet_map  FROM TABLE lt_mapping_upd.
      IF sy-subrc EQ 0.
        CALL FUNCTION 'GUID_CREATE'
          IMPORTING
            ev_guid_16 = lv_guid_id.

        IF lv_guid_id IS NOT INITIAL.
          ls_mapping_log-guid_id = lv_guid_id.
          ls_mapping_log-obd = lv_temp_obd_no.
          DESCRIBE TABLE lt_mapping_upd LINES ls_mapping_log-deletion_count.
          ls_mapping_log-application = 'New'.
          IF sy-ucomm = 'SAVE'.
            ls_mapping_log-deletion_spot = 'Without Scheme SAVE(Update Mapping)'.
          ELSE.
            ls_mapping_log-deletion_spot = 'Without Scheme POST(Update Mapping)'.
          ENDIF.
          ls_mapping_log-deleted_by = sy-uname.
          ls_mapping_log-deleted_on = sy-datum.
          ls_mapping_log-deleted_at = sy-timlo.

          IF ls_mapping_log IS NOT INITIAL.
            MODIFY zwm_mapping_log FROM ls_mapping_log.
            CLEAR: ls_mapping_log.
          ENDIF.
          CLEAR: lv_guid_id.
        ENDIF.
      ENDIF.
      CLEAR: lt_mapping_upd, lt_sloc_del.
    ENDIF.
  ENDIF.

  "update newly added entries
  LOOP AT lt_sloc_temp INTO DATA(ls_sloc_upd).
    READ TABLE lt_sloc TRANSPORTING NO FIELDS WITH KEY su_no = ls_sloc_upd-su_no.
    IF sy-subrc NE 0.
      APPEND ls_sloc_upd TO lt_sloc_upd.
    ENDIF.
    CLEAR: ls_sloc_upd.
  ENDLOOP.
  IF lt_sloc_upd[] IS NOT INITIAL.
    SELECT werks AS plant,
            lgnum AS warehouse_no,
            palletno AS pallet_no,
            lenum AS su_no
       FROM zwm_su
       FOR ALL ENTRIES IN @lt_sloc_upd
         WHERE werks = @lt_sloc_upd-plant
           AND lenum = @lt_sloc_upd-su_no
           AND palletno NE ''
       INTO TABLE @DATA(lt_su_upd).
    IF lt_su_upd[] IS NOT INITIAL.
      lt_mapping_upd = VALUE #( FOR ls_su_upd IN lt_su_upd
                                ( warehouse_type = 'Plant'
                                  warehouse_no   = ls_su_upd-warehouse_no
                                  pallet_no      = ls_su_upd-pallet_no
                                  su_no          = ls_su_upd-su_no )
                              ).
      IF lt_mapping_upd[] IS NOT INITIAL.
        MODIFY zwm_pallet_map  FROM TABLE lt_mapping_upd.
*        DELETE zwm_pallet_map  FROM TABLE lt_mapping_upd.
        CLEAR: lt_su_upd, lt_mapping_upd.
      ENDIF.
    ENDIF.
    CLEAR: lt_sloc_upd.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LAYOUT6
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_layout6 .

  gs_layout5-zebra       = 'X'.
  gs_layout5-stylefname = 'FIELD_STYLE'.
  gs_layout5-sel_mode    = lv_sel_mode. "'Bin dev and QA "A in PRD
  gs_layout5-cwidth_opt  = 'X'.
  gs_layout5-no_toolbar  = 'X'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDE_MENU6
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_exclude_menu6 .

  DATA : p_lt_exclude  TYPE ui_functions.

  APPEND cl_gui_alv_grid=>mc_fc_fix_columns TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_append_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_cut TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_move_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO p_lt_exclude.
  APPEND cl_gui_alv_grid=>mc_fc_loc_undo TO p_lt_exclude.

  gt_exclude6  = p_lt_exclude.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_FCAT6
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_fcat6 .

  CLEAR: gt_fcat6.

  wa_fcat-tabname = 'LT_INCOMPLETE_MAT_LIST'.
  wa_fcat-fieldname = 'ITEM_NO'.
  wa_fcat-scrtext_m = 'Item'.
  APPEND wa_fcat TO gt_fcat6.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_INCOMPLETE_MAT_LIST'.
  wa_fcat-fieldname = 'MATERIAL'.
  wa_fcat-scrtext_m = 'Mat code'.
  APPEND wa_fcat TO gt_fcat6.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_INCOMPLETE_MAT_LIST'.
  wa_fcat-fieldname = 'BATCH_NUMBER'.
  wa_fcat-scrtext_m = 'Batch No'.
  APPEND wa_fcat TO gt_fcat6.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_INCOMPLETE_MAT_LIST'.
  wa_fcat-fieldname = 'REQ_BOXES'.
  wa_fcat-scrtext_m = 'Req'.
  APPEND wa_fcat TO gt_fcat6.
  CLEAR: wa_fcat.

  wa_fcat-tabname = 'LT_INCOMPLETE_MAT_LIST'.
  wa_fcat-fieldname = 'SCANNED_BOXES'.
  wa_fcat-scrtext_m = 'Scan'.
  APPEND wa_fcat TO gt_fcat6.
  CLEAR: wa_fcat.

ENDFORM.
