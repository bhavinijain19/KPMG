*************************************************************************************
*Object Name              : ZWM_PUTAWAY_LIST
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : Selection Screen declaration include.
*************************************************************************************

selection-SCREEN  BEGIN OF BLOCK a WITH FRAME TITLE text-001.

  select-OPTIONS : s_tanum FOR v_tanum OBLIGATORY.
  parameters p_nltyp type LTAP_NLTYP OBLIGATORY MATCHCODE OBJECT H_T301.

selection-SCREEN END OF BLOCK a.


AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_tanum-low.

SELECT lgnum tanum FROM ltap INTO TABLE it_ty_help.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'TANUM'
      dynpprog        = sy-cprog
      dynpnr          = sy-dynnr
      value_org       = 'S'
    TABLES
      value_tab       = it_ty_help
      return_tab      = it_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
"display entries after selection from search help
  LOOP AT it_return INTO wa_ty_help.
    s_tanum-low = wa_ty_help-fieldval.
  ENDLOOP.

  AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_tanum-high.

    SELECT lgnum tanum FROM ltap INTO TABLE it_ty_help.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'TANUM'
      dynpprog        = sy-cprog
      dynpnr          = sy-dynnr
      value_org       = 'S'
    TABLES
      value_tab       = it_ty_help
      return_tab      = it_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
"display entries after selection from search help
  LOOP AT it_return INTO wa_ty_help.
    s_tanum-high = wa_ty_help-fieldval.
  ENDLOOP.
