*************************************************************************************
*Object Name              : ZWM_Pickaway_LIST.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : class declaration and implementaion include.
*************************************************************************************
*************************************************************************************
*Description              : class declaration and implementaion include.
*************************************************************************************
CLASS lcl_pickup DEFINITION.
  PUBLIC SECTION.
    METHODS : validation,
      fetch_data,
      smartform.

ENDCLASS.

CLASS lcl_pickup IMPLEMENTATION.
*********************************************************
*method for validating user input.
*********************************************************
  METHOD validation.
    SELECT SINGLE lgnum,
                  tbnum,
                  bdatu
    FROM ltbk
    INTO @DATA(wa_ltbk)
    WHERE lgnum EQ @p_lgnum
    AND   tbnum IN @s_tbnum
    AND   bdatu EQ @p_bdatu.

    IF sy-subrc NE 0.
      MESSAGE e000(zm_pickup_list).
    ENDIF.
  ENDMETHOD.
*********************************************************
*method to fetching data.
*********************************************************
  METHOD fetch_data.

    SELECT lgnum,                                                         "selecting data from ltbk
           tbnum,
           bdatu,
           statu,
           trart
    FROM ltbk
    INTO TABLE @DATA(it_ltbk)
    WHERE lgnum EQ @p_lgnum
    AND   tbnum IN @s_tbnum
    AND   bdatu EQ @p_bdatu
    AND   statu NE 'E'
    AND   trart NE 'E'
    AND   trart NE 'U'.

    IF it_ltbk IS NOT INITIAL.                                             "initial check

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*      SELECT  spras ,
*              lgnum,
*              lnumt
*    FROM    t300t
*    INTO @DATA(wa_t300t)
*    FOR ALL ENTRIES IN @it_ltbk
*    WHERE lgnum EQ  @it_ltbk-lgnum
*    AND   spras EQ  @sy-langu.

SELECT SPRAS ,
 LGNUM ,
 LNUMT
 FROM T300T
 INTO @DATA(WA_T300T)
 FOR ALL ENTRIES IN @IT_LTBK
 WHERE LGNUM EQ @IT_LTBK-LGNUM
 AND SPRAS EQ @SY-LANGU
 ORDER BY PRIMARY KEY .
* End of Quick Fix

      ENDSELECT.
      warehouse = wa_t300t-lgnum.
      desc = wa_t300t-lnumt.


      SELECT lgnum,                                                       "selecting data from ltbk
             tbnum,
             matnr,
             tbpos,
             charg,
             elikz,
             werks,
             menge,
             meins,
             lgort
       FROM ltbp
       INTO TABLE @DATA(it_ltbp)
       FOR ALL ENTRIES IN @it_ltbk
       WHERE lgnum EQ @it_ltbk-lgnum
       AND   tbnum EQ @it_ltbk-tbnum
       AND   elikz EQ @space.

      IF it_ltbp IS NOT INITIAL.                                           "initial check
        DATA(it_ltbp_temp) = it_ltbp.
        SORT it_ltbp_temp BY lgnum tbnum tbpos.
        DELETE ADJACENT DUPLICATES FROM it_ltbp_temp COMPARING lgnum tbnum tbpos.

        SELECT werks,
               lgort,
               lgnum,
               lgtyp
        FROM  zwm_picklist
        INTO TABLE @DATA(it_zwm_picklist)
        FOR ALL ENTRIES IN @it_ltbp_temp
        WHERE werks EQ @it_ltbp_temp-werks
        AND   lgort EQ @it_ltbp_temp-lgort
        AND   lgnum EQ @it_ltbp_temp-lgnum.

        IF it_zwm_picklist IS NOT INITIAL.
          SELECT lgnum,                                                    "selectimg data from lqua
                 matnr,
                 charg,
                 lqnum,
                 werks,
                 lgpla,
                 tbnum,
                 lgort,
                 lgtyp
          FROM lqua
          INTO TABLE @DATA(it_lqua)
          FOR ALL ENTRIES IN @it_ltbp_temp
          WHERE lgnum EQ @it_ltbp_temp-lgnum
          AND   matnr EQ @it_ltbp_temp-matnr
          AND   charg EQ @it_ltbp_temp-charg.

          IF it_lqua IS NOT INITIAL.
            SELECT   matnr,                                                   "selectimg data from makt
                     spras,
                     maktx
               FROM makt
               INTO TABLE @DATA(it_makt)
               FOR ALL ENTRIES IN @it_ltbp_temp
               WHERE matnr EQ @it_ltbp_temp-matnr
               AND spras   EQ @sy-langu.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    SORT it_ltbp BY matnr charg.                                  "sorting it_ltbp
    SORT it_lqua BY matnr charg.                                   "sorting it_lqua
    DATA i TYPE int2 VALUE 0.

    DATA v_lqua_index TYPE sy-tabix.
    DATA gv_menge type menge_d.
    LOOP AT it_ltbp ASSIGNING FIELD-SYMBOL(<fs_ltbp>).                   "looping it_ltbp
      IF <fs_ltbp> IS ASSIGNED.

        "reading it_lqua
*                  READ TABLE it_ltbp ASSIGNING FIELD-SYMBOL(<fs_ltbp>) WITH KEY lgnum = <fs_lqua>-lgnum
*                                                                                matnr = <fs_lqua>-matnr
*                                                                                charg = <fs_lqua>-charg BINARY SEARCH.
   APPEND INITIAL LINE TO it_final ASSIGNING <fs_final>.
 at END OF charg.
         " unassign <fs_final>.
*          APPEND INITIAL LINE TO it_final ASSIGNING <fs_final>.
            IF <fs_final> IS ASSIGNED.
          <fs_final>-lgnum = <fs_ltbp>-lgnum.
          <fs_final>-tbnum = <fs_ltbp>-tbnum.
          SHIFT <fs_ltbp>-matnr LEFT DELETING LEADING '0'.
          <fs_final>-matnr = <fs_ltbp>-matnr.
          <fs_final>-charg = <fs_ltbp>-charg.
          <fs_final>-tbpos = <fs_ltbp>-tbpos.
          <fs_final>-menge = <fs_ltbp>-menge.
          <fs_final>-meins = <fs_ltbp>-meins.
           <fs_final>-bdatu = p_bdatu.
          "<fs_final>-gv_text = gv_text.

*            <fs_final>-sno = i.
*            i = i + 1.
          CLEAR gv_text.
          endif.
 endat.
 endif.
        "  v_ltbp_index = sy-tabix.
        LOOP AT it_lqua ASSIGNING FIELD-SYMBOL(<fs_lqua>) WHERE matnr = <fs_ltbp>-matnr and charg = <fs_ltbp>-charg. "FROM v_lqua_index.
          IF <fs_lqua> IS ASSIGNED.
*            IF <fs_ltbp>-matnr <> <fs_lqua>-matnr AND <fs_ltbp>-charg <> <fs_lqua>-charg.
*              v_lqua_index = sy-tabix.
*              EXIT.
*            ENDIF.

            READ TABLE it_zwm_picklist ASSIGNING FIELD-SYMBOL(<fs_zwm_picklist>) WITH KEY werks = <fs_ltbp>-werks
                                                                                             lgort = <fs_ltbp>-lgort
                                                                                             lgnum = <fs_ltbp>-lgnum
                                                                                             lgtyp = <fs_lqua>-lgtyp.
            IF <fs_zwm_picklist> IS ASSIGNED.
              <fs_final>-lgpla = <fs_lqua>-lgpla.
              CONCATENATE gv_text <fs_lqua>-lgpla INTO gv_text SEPARATED BY ''.
              unassign <fs_zwm_picklist>.
              "deleting duplicate bins
              REPLACE ALL OCCURRENCES OF REGEX '(\<\w+\>) \1' IN gv_text WITH '$1' IGNORING CASE.
              "reading it_makt table
            endif.
            endif.
          endloop.
          at end of charg.
            shift gv_text LEFT DELETING LEADING space.
            <fs_final>-gv_text = gv_text.
            endat.
              READ TABLE it_makt ASSIGNING FIELD-SYMBOL(<fs_makt>) WITH KEY matnr = <fs_ltbp>-matnr
                                                                            spras = sy-langu.
              IF <fs_makt> IS ASSIGNED.
            "unassign <fs_final>.
                at end of charg.
                <fs_final>-maktx = <fs_makt>-maktx.
                ENDAT.
*                CONCATENATE gv_text <fs_lqua>-lgpla INTO gv_text SEPARATED BY ''.
*                "deleting duplicate bins
*                REPLACE ALL OCCURRENCES OF REGEX '(\<\w+\>) \1' IN gv_text WITH '$1' IGNORING CASE.
              ENDIF.
          "  endif.
             " gv_menge = gv_menge + <fs_ltbp>-menge.
           " ENDIF.
         " ENDIF.
              unassign <fs_final>.
        ENDLOOP.
*unassign <fs_final>.
*        APPEND INITIAL LINE TO it_final ASSIGNING <fs_final>.
*        IF <fs_final> IS ASSIGNED.
*          AT END OF charg.
*            <fs_final>-lgnum = <fs_ltbp>-lgnum.
*            <fs_final>-tbnum = <fs_ltbp>-tbnum.
*            SHIFT <fs_ltbp>-matnr LEFT DELETING LEADING '0'.
*            <fs_final>-matnr = <fs_ltbp>-matnr.
*            <fs_final>-charg = <fs_ltbp>-charg.
*            <fs_final>-tbpos = <fs_ltbp>-tbpos.
*            <fs_final>-menge = <fs_ltbp>-menge.
*            <fs_final>-meins = <fs_ltbp>-meins.
*            <fs_final>-lgpla = <fs_lqua>-lgpla.
*            <fs_final>-maktx = <fs_makt>-maktx.
*            <fs_final>-bdatu = p_bdatu.
        "at END OF charg.
            "<fs_final>-gv_text = gv_text.
*            <fs_final>-sno = i.
*            i = i + 1.
*            CLEAR gv_text.
*            clear gv_menge.
*         "ENDAT.
*        "ENDIF.
*        "endif.
**                        endif.
*      ENDIF.
*    ENDLOOP.

    DELETE it_final WHERE lgnum IS INITIAL.
      SORT it_final BY tbnum tbpos.
    data line type int4.
    describe TABLE it_final LINES line.
    UNASSIGN <fs_final>.
    do line TIMES.
      i = i + 1.
   read TABLE it_final ASSIGNING <fs_final> INDEX i.
   if <fs_final> is ASSIGNED.
      <fs_final>-sno = i.
   endif.
    enddo.

  ENDMETHOD.
*********************************************************
*method for calling smartform.
*********************************************************
  METHOD smartform.

    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname           = 'ZSF_PICKUP_LIST'
      IMPORTING
        fm_name            = var
      EXCEPTIONS
        no_form            = 1
        no_function_module = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.


    CALL FUNCTION var
      EXPORTING
        it_final         = it_final
        warehouse        = warehouse
        desc             = desc
        p_bdatu          = p_bdatu
      EXCEPTIONS
        formatting_error = 1
        internal_error   = 2
        send_error       = 3
        user_canceled    = 4
        OTHERS           = 5.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDMETHOD.
ENDCLASS.
