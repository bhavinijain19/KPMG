*************************************************************************************
*Object Name              : ZWM_STO.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 24/03/2019.
*************************************************************************************
*Description              :Report for posting TO with reference to TR.
*************************************************************************************
REPORT zwm_sto.



*********************************************************
*includes declaration.
*********************************************************
INCLUDE : zwm_sto_top,         "data declaration.
          zwm_sto_scr,         "include for screen declaration.
          zwm_sto_cls.         "include for class declaration and implementation.

*********************************************************
*initialization event.
*********************************************************
INITIALIZATION.

  CREATE OBJECT obj.           "creating object of class

*********************************************************
*at selection screen event.
*********************************************************
AT SELECTION-SCREEN.

  obj->validation( ).          "calling class method for validating input.

*********************************************************
*start of selection event.
*********************************************************
START-OF-SELECTION.

  obj->fetch_data( ).          "calling class method to getdata.
  obj->display( ).             "calling method for displaying data.
