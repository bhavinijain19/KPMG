PROGRAM zwm_first_screen.

INCLUDE zwm_first_screen_top.

MODULE status_9001 OUTPUT.
  SET PF-STATUS 'PF_9001'.
ENDMODULE.

MODULE user_command_9001 INPUT.

  DATA: lv_ip        TYPE ni_ipv4addr,
        lv_port      TYPE char10,
        lv_url(1000) TYPE c.

  DATA: icm_data  TYPE TABLE OF /sdf/icm_data_struc WITH HEADER LINE,
        list_ipv6 TYPE TABLE OF msxxlist_v6 WITH HEADER LINE.

  DATA : ls_user_config TYPE zwm_user_config.

  FREE: lv_ip, lv_port, lv_url, icm_data, list_ipv6.

********Get IP Address********

  CALL FUNCTION 'TH_SERVER_LIST'
    TABLES
      list_ipv6 = list_ipv6.

  READ TABLE list_ipv6 INDEX 1.
  lv_ip = list_ipv6-hostaddr_v4_str.

********Get IP Address********

********Get Port********

  CALL FUNCTION '/SDF/GET_ICM_VIRT_HOST_DATA'
    TABLES
      icm_data = icm_data.

  READ TABLE icm_data INDEX 1.
  lv_port = icm_data-port.

********Get Port********

********Refresh********
  gs_url-name = 'FIRST_SCREEN'.

  CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_load1?sap-system-login-basic_auth=X&sap-client='
              sy-mandt '&sap-language=EN' INTO gs_url-url.

  APPEND gs_url.
********Refresh********

  SELECT SINGLE active_flag FROM zwm_user_config INTO @DATA(lv_flag) WHERE user_name = @sy-uname.

  CASE ok_code.
    WHEN 'LOAD'.
      FREE: lv_url.

      IF lv_flag EQ 'X'.
        CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_load_wo_n?sap-system-login-basic_auth=X&sap-client='
                    sy-mandt '&sap-language=EN' INTO lv_url.
      ELSE.
        CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_load1?sap-system-login-basic_auth=X&sap-client='
                    sy-mandt '&sap-language=EN' INTO lv_url.
      ENDIF.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'LOAD1'.
      FREE: lv_url.
      IF lv_flag EQ 'X'.
        CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_load_w_n?sap-system-login-basic_auth=X&sap-client='
                    sy-mandt '&sap-language=EN' INTO lv_url.
      ELSE.
        CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_load2?sap-system-login-basic_auth=X&sap-client='
                    sy-mandt '&sap-language=EN' INTO lv_url.
      ENDIF.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'BIN'.
      FREE: lv_url.
      CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_hht_bin2bi?sap-system-login-basic_auth=X&sap-client='
            sy-mandt '&sap-language=EN' INTO lv_url.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'RM'.
      FREE: lv_url.
      CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_rm_display?sap-system-login-basic_auth=X&sap-client='
            sy-mandt '&sap-language=EN' INTO lv_url.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'SU'.
      FREE: lv_url.
      CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_su_display?sap-system-login-basic_auth=X&sap-client='
            sy-mandt '&sap-language=EN' INTO lv_url.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'CONF'.
      FREE: lv_url.
      CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zwm_rm_cnf?sap-system-login-basic_auth=X&sap-client='
            sy-mandt '&sap-language=EN' INTO lv_url.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    WHEN 'RM1'.
      FREE: lv_url.
      CONCATENATE 'http://' lv_ip ':' lv_port '/sap/bc/gui/sap/its/zrm_good_issue?sap-system-login-basic_auth=X&sap-client='
            sy-mandt '&sap-language=EN' INTO lv_url.

      CALL FUNCTION 'CALL_BROWSER'
        EXPORTING
          url                    = lv_url
*         WINDOW_NAME            = ' '
          new_window             = 'X'
*         BROWSER_TYPE           =
*         CONTEXTSTRING          =
        EXCEPTIONS
          frontend_not_supported = 1
          frontend_error         = 2
          prog_not_found         = 3
          no_batch               = 4
          unspecified_error      = 5
          OTHERS                 = 6.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

  ENDCASE.

ENDMODULE.
