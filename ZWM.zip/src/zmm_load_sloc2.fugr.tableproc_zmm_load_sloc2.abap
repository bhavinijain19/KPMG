*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_LOAD_SLOC2
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_LOAD_SLOC2      .

  PERFORM TABLEPROC.

ENDFUNCTION.
