*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZWM_PLANT_CONFIG................................*
DATA:  BEGIN OF STATUS_ZWM_PLANT_CONFIG              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZWM_PLANT_CONFIG              .
CONTROLS: TCTRL_ZWM_PLANT_CONFIG
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZWM_PLANT_CONFIG              .
TABLES: ZWM_PLANT_CONFIG               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
