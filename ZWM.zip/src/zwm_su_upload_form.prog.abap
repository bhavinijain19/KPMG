*&---------------------------------------------------------------------*
*& Include          ZWM_SU_UPLOAD_FORM
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form download_template
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM download_template.
  DATA: lv_filename  TYPE string,
        lt_file_data TYPE TABLE OF string,
        lv_header    TYPE string,
        lv_fname     TYPE string,
        lv_path      TYPE string,
        lv_fpath     TYPE string,
        lv_action    TYPE i.

  " Add your specific field list here
  DATA(lv_tab) = cl_abap_char_utilities=>horizontal_tab.

  lv_header = |Client{ lv_tab }Order{ lv_tab }Storage Unit{ lv_tab }TO Number{ lv_tab }Warehouse No.{ lv_tab }| &&
              |Material{ lv_tab }Batch{ lv_tab }Plant{ lv_tab }Target Quantity{ lv_tab }| &&
              |Base Unit{ lv_tab }Base Unit{ lv_tab }Creation Date{ lv_tab }Creation time{ lv_tab }| &&
              |User{ lv_tab }Current Date{ lv_tab }Print indicator{ lv_tab }Current Date{ lv_tab }| &&
              |Time{ lv_tab }User{ lv_tab }Re Print indicator{ lv_tab }Current Date{ lv_tab }| &&
              |Time{ lv_tab }User{ lv_tab }FGS indicator{ lv_tab }Pallet Number{ lv_tab }| &&
              |Target Quantity{ lv_tab }Pallet Print indicat{ lv_tab }Current Date{ lv_tab }Time{ lv_tab }| &&
              |User{ lv_tab }Current Date{ lv_tab }Time{ lv_tab }User{ lv_tab }| &&
              |Pallet Re Print indi{ lv_tab }Current Date{ lv_tab }Time{ lv_tab }User{ lv_tab }| &&
              |Pallet indicator{ lv_tab }L Type{ lv_tab }P Type{ lv_tab }Deletion flag{ lv_tab }| &&
              |SU Count{ lv_tab }Order Type{ lv_tab }Lot number{ lv_tab }Pallet range{ lv_tab }|.

  APPEND lv_header TO lt_file_data.


  " Open Save Dialog
  lv_filename = |Upload_ZWM_SU_Template_{ sy-datum }_{ sy-uzeit }|.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'Save Template As'
      default_extension = 'XLS'
      default_file_name = lv_filename  " Sets 'BP_Template' as the default
      initial_directory = 'C:\'
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fpath
      user_action       = lv_action.

  CHECK lv_action = cl_gui_frontend_services=>action_ok.

  " Download Header only (empty data table)
  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename              = lv_fpath
      filetype              = 'DAT'
      write_field_separator = 'X' " Ensures Excel columns align
    TABLES
      data_tab              = lt_file_data.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form VALUE_REQUEST
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM value_request.
  CALL FUNCTION 'F4_FILENAME'
    EXPORTING
      program_name = sy-cprog
    IMPORTING
      file_name    = p_flname.
ENDFORM.
FORM validations .
  IF p_flname IS INITIAL.
    MESSAGE 'FILE NAME' TYPE 'S'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form UPLOAD_EXCEL
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM upload_excel.
  DATA: lv_fname   TYPE string.

  lv_fname = p_flname.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  PERFORM convert_data.
ENDFORM.
FORM convert_data .
  DATA: lv_xstring    TYPE xstring,
        lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
        lv_docname    TYPE string,
        lt_worksheets TYPE STANDARD TABLE OF string,
        lv_worksheet  TYPE string,
        lv_lines      TYPE i,
        lo_data       TYPE REF TO data.

  FIELD-SYMBOLS: <lt_data_bin>  TYPE STANDARD TABLE,
                 <ls_data_bin>  TYPE any,
                 <lv_value_bin> TYPE any,
                 <lv_value>     TYPE any.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  TRY.
      CREATE OBJECT lo_excel
        EXPORTING
          document_name = lv_docname
          xdocument     = lv_xstring.

      IF lo_excel IS NOT INITIAL.
        lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
          IMPORTING
            worksheet_names = lt_worksheets ).
      ENDIF.

      DESCRIBE TABLE lt_worksheets LINES lv_lines.

      IF lt_worksheets[] IS NOT INITIAL.
        READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
        lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
        ASSIGN lo_data->* TO <lt_data_bin>.
      ENDIF.

      IF <lt_data_bin> IS ASSIGNED.
        LOOP AT <lt_data_bin> ASSIGNING <ls_data_bin> FROM 2.
          CLEAR: wa_file.
          DO.
            ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data_bin> TO <lv_value_bin>.
            IF sy-subrc EQ 0.

              ASSIGN COMPONENT sy-index OF STRUCTURE wa_file TO <lv_value>.

              IF sy-subrc EQ 0.
                <lv_value> = <lv_value_bin>.
              ENDIF.
            ELSE.
              EXIT.
            ENDIF.
          ENDDO.
          IF wa_file IS NOT INITIAL.
            APPEND wa_file TO it_file.
          ENDIF.
        ENDLOOP.
      ENDIF.
    CATCH cx_fdt_excel_core.
      MESSAGE 'Excel processing error' TYPE 'E'.
  ENDTRY.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form create_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM create_data .
  IF it_file IS NOT INITIAL.
    MODIFY zwm_su FROM TABLE it_file.
    IF sy-subrc = 0.
      COMMIT WORK.
      MESSAGE |{ sy-dbcnt } records updated in ZWM_SU successfully.| TYPE 'S'.
    ELSE.
      ROLLBACK WORK.
      MESSAGE 'Database update failed.' TYPE 'E'.
    ENDIF.
  ELSE.
    MESSAGE 'No data found in Excel file.' TYPE 'I'.
  ENDIF.
ENDFORM.
