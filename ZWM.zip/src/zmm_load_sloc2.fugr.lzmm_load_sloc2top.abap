FUNCTION-POOL ZMM_LOAD_SLOC2             MESSAGE-ID SV.

* INCLUDE LZMM_LOAD_SLOC2D...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_LOAD_SLOC2T00                      . "view rel. data dcl.
