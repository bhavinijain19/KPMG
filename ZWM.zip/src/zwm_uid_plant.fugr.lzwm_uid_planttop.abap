FUNCTION-POOL ZWM_UID_PLANT              MESSAGE-ID SV.

* INCLUDE LZWM_UID_PLANTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZWM_UID_PLANTT00                       . "view rel. data dcl.
