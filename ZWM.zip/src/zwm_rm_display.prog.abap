*************************************************************************************
*Object Name              : ZWM_RM_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 06/04/2019.
*************************************************************************************
*Description              : PROGRAM FOR RM DISPLAY.
*************************************************************************************
PROGRAM zwm_rm_display.

INCLUDE : zwm_rm_display_top,
          zwm_rm_display_scr,
          zwm_rm_display_module.


*********************************************************
*Start of selection event.
*********************************************************
start-OF-SELECTION.
*********************************************************
*calling screen 9001.
*********************************************************
call SCREEN 9001.
