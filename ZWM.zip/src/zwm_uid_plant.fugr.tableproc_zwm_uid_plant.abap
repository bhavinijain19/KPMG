*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZWM_UID_PLANT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZWM_UID_PLANT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
