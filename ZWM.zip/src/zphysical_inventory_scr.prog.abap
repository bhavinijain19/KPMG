*&---------------------------------------------------------------------*
*&  Include           ZPHYSICAL_INVENTORY_SCR
*&---------------------------------------------------------------------*
selection-SCREEN begin of block b with frame title text-001.
  parameters:p_lgnum type link-lgnum,
             p_ivnum type link-ivnum,
             p_matnr type lqua-matnr.
selection-screen end of block b.
