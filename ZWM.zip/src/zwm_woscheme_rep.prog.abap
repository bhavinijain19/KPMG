*&---------------------------------------------------------------------*
*& Report ZWM_WOSCHEME_REP
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zwm_woscheme_rep.

*Data Declaration
INCLUDE zwm_woscheme_top.

*Selection Screen
INCLUDE zwm_woscheme_s01.

*Implementation
INCLUDE zwm_woscheme_f01.
