*************************************************************************************
*Object Name              : ZWM_Pickup_LIST
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : Data declaration include.
*************************************************************************************
CLASS lcl_pickup DEFINITION DEFERRED.

DATA obj        TYPE REF TO lcl_pickup.                                "creating reference of class object.
DATA v_tbnum    TYPE tbnum.
DATA gv_text    TYPE char200.
DATA it_final   TYPE STANDARD TABLE OF zswm_pickup.                    "internal table declaration.
DATA :warehouse TYPE lgnum,                                            "variable to store warehouse no.
      desc      TYPE lvs_lnumt.                                        "variable to store warehouse description.
DATA var        TYPE rs38l_fnam.                                       "variabler to store smartform FM name.



FIELD-SYMBOLS <fs_final> TYPE zswm_pickup.                             "field synmol delclaration.
