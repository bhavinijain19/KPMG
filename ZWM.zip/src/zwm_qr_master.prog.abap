*&---------------------------------------------------------------------*
*& Report ZWM_SU_UPLOAD
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zwm_qr_master.

INCLUDE ZWM_QR_MASTER_TOP.
*INCLUDE ZWM_QR_LOYAL_TOP.
*INCLUDE ZMM_SU_NUMBER_TOP.
*INCLUDE zwm_su_upload_top.
INCLUDE ZWM_QR_MASTER_FORM.
*INCLUDE ZWM_QR_LOYAL_FORM.
*INCLUDE ZMM_SU_NUMBER_FORM.
*INCLUDE zwm_su_upload_form.

INITIALIZATION.
  btn_tpl = '@49@ Download Template'.

AT SELECTION-SCREEN.
  CASE sy-ucomm.
    WHEN 'DTL'.
      PERFORM download_template.
  ENDCASE.

START-OF-SELECTION.

PERFORM validations.

PERFORM upload_excel.

PERFORM create_data.
PERFORM display_log.
