FUNCTION zwm_fm_scan_load_get.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_LOAD_NO) TYPE  ZLOAD_NO OPTIONAL
*"     VALUE(IV_OBD_NO) TYPE  VBELN_VL OPTIONAL
*"  EXPORTING
*"     VALUE(EV_MSG) TYPE  STRING
*"  CHANGING
*"     VALUE(LT_MAT_LIST) TYPE  ZWM_TT_OBD_LIST1 OPTIONAL
*"----------------------------------------------------------------------

  DATA: ls_scanned_list TYPE zwm_st_scan_list.

  SELECT * FROM zwm_scan_load INTO TABLE @DATA(lt_scan_load)
    WHERE obd = @iv_obd_no
      AND load_no = @iv_load_no.
  IF sy-subrc EQ 0.

    LOOP AT lt_scan_load INTO DATA(ls_scan_load).
      READ TABLE lt_mat_list ASSIGNING FIELD-SYMBOL(<fs_mat_list>)
        WITH KEY material = ls_scan_load-material
                 item_number = ls_scan_load-item_number.
      IF sy-subrc EQ 0.
        READ TABLE <fs_mat_list>-batch_list ASSIGNING FIELD-SYMBOL(<fs_batch_list>)
          WITH KEY batch_number = ls_scan_load-batch_no.
        IF sy-subrc EQ 0.
          READ TABLE <fs_batch_list>-scanned_list TRANSPORTING NO FIELDS WITH KEY pallet_no = ls_scan_load-pallet_no
                                                                                  su_no = ls_scan_load-su_no.
          IF sy-subrc NE 0.
            ls_scanned_list-pallet_no = ls_scan_load-pallet_no.
            ls_scanned_list-su_no     = ls_scan_load-su_no.

            APPEND ls_scanned_list TO <fs_batch_list>-scanned_list.
            CLEAR: ls_scanned_list.

            <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes + 1.
            IF <fs_batch_list>-req_boxes eq <fs_batch_list>-scanned_boxes.
              <fs_batch_list>-status = 'C'.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.

  ELSE.
    ev_msg = 'Load No. not available for this OBD'.

  ENDIF.



ENDFUNCTION.
