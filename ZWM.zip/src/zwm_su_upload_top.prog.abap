*&---------------------------------------------------------------------*
*& Include          ZWM_SU_UPLOAD_TOP
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_log.
         INCLUDE TYPE zwm_su. " Automatically adds all fields from ty_file
TYPES:   msgty   TYPE bapi_mtype,   " Status: S (Success), E (Error)
         message TYPE bapi_msg,     " The actual error/success text
       END OF ty_log.

DATA: gt_raw     TYPE solix_tab,
      gv_bin_len TYPE i.

DATA: it_file TYPE TABLE OF zwm_su,
      wa_file TYPE zwm_su,
      t_log   TYPE TABLE OF ty_log,
      w_log   TYPE ty_log,
      t_error TYPE TABLE OF zwm_su.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-100.
  PARAMETERS:p_flname TYPE localfile .                        "FILE PATH
SELECTION-SCREEN END OF BLOCK b1.
SELECTION-SCREEN: BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-101.
  " Defining the button on the selection screen
  SELECTION-SCREEN PUSHBUTTON /2(25) btn_tpl USER-COMMAND dtl.
SELECTION-SCREEN: END OF BLOCK b2.
