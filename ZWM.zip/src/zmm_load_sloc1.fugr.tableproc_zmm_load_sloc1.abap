*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_LOAD_SLOC1
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_LOAD_SLOC1      .

  PERFORM TABLEPROC.

ENDFUNCTION.
