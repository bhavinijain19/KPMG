*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_LOAD_SLOC2TOP.                " Global Declarations
  INCLUDE LZMM_LOAD_SLOC2UXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_LOAD_SLOC2F...                " Subroutines
* INCLUDE LZMM_LOAD_SLOC2O...                " PBO-Modules
* INCLUDE LZMM_LOAD_SLOC2I...                " PAI-Modules
* INCLUDE LZMM_LOAD_SLOC2E...                " Events
* INCLUDE LZMM_LOAD_SLOC2P...                " Local class implement.
* INCLUDE LZMM_LOAD_SLOC2T99.                " ABAP Unit tests
  INCLUDE LZMM_LOAD_SLOC2F00                      . " subprograms
  INCLUDE LZMM_LOAD_SLOC2I00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
