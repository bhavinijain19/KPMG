*************************************************************************************
*Object Name              : ZWM_HHT_BIN2BIN_SCR.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Selection Screen declaration
*************************************************************************************

*SELECTION-SCREEN BEGIN OF screen 9011 as subscreen.
*
*PARAMETERS : p_lgnum  TYPE lagp-lgnum OBLIGATORY MATCHCODE OBJECT h_t300,
*             p_lgtyps TYPE lagp-lgtyp OBLIGATORY MATCHCODE OBJECT h_t301,
*             p_lgplas TYPE lagp-lgpla  OBLIGATORY MATCHCODE OBJECT l_lagp.
*
*PARAMETERS : p_lgtypd TYPE lagp-lgtyp OBLIGATORY MATCHCODE OBJECT h_t301,
*             p_lgplad TYPE lagp-lgpla MATCHCODE OBJECT lag1,
*             p_lgber  TYPE lagp-lgber OBLIGATORY MATCHCODE OBJECT h_t302.
*
*SELECTION-SCREEN END OF screen 9011.

*at SELECTION-SCREEN OUTPUT.
*
*   LOOP AT SCREEN.                                              "for making LGTYPD parameter field uneditable.
*    IF screen-name = 'P_LGTYPD'.
*      screen-input = 0.
*      MODIFY SCREEN.
*    ENDIF.
*  ENDLOOP.
