*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_UID_PLANTTOP.                 " Global Declarations
  INCLUDE LZWM_UID_PLANTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_UID_PLANTF...                 " Subroutines
* INCLUDE LZWM_UID_PLANTO...                 " PBO-Modules
* INCLUDE LZWM_UID_PLANTI...                 " PAI-Modules
* INCLUDE LZWM_UID_PLANTE...                 " Events
* INCLUDE LZWM_UID_PLANTP...                 " Local class implement.
* INCLUDE LZWM_UID_PLANTT99.                 " ABAP Unit tests
  INCLUDE LZWM_UID_PLANTF00                       . " subprograms
  INCLUDE LZWM_UID_PLANTI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
