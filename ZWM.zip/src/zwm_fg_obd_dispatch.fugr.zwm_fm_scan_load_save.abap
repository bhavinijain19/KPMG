FUNCTION zwm_fm_scan_load_save.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_OBD_NO) TYPE  VBELN_VL OPTIONAL
*"     VALUE(IV_WITH_SCHEME) TYPE  CHAR1 OPTIONAL
*"     VALUE(IT_MAT_LIST) TYPE  ZWM_TT_OBD_LIST1 OPTIONAL
*"     VALUE(IV_LOAD_NO) TYPE  ZLOAD_NO OPTIONAL
*"  EXPORTING
*"     VALUE(ET_SCAN_LOAD) TYPE  ZWM_TT_SCAN_LOAD
*"----------------------------------------------------------------------

  DATA: ls_scan_load TYPE zwm_scan_load.

  DATA: lv_count TYPE i.

  REFRESH: et_scan_load.
  LOOP AT it_mat_list INTO DATA(ls_mat_list).
    LOOP AT ls_mat_list-batch_list INTO DATA(ls_batch_list).
      CLEAR: lv_count.
      LOOP AT ls_batch_list-scanned_list INTO DATA(ls_scanned_list).
        lv_count = lv_count + 1.
        ls_scan_load-load_no      = iv_load_no.
        ls_scan_load-obd          = iv_obd_no.
        ls_scan_load-item_number  = ls_mat_list-item_number.
        ls_scan_load-material     = ls_mat_list-material.
        ls_scan_load-batch_no     = ls_batch_list-batch_number.
        ls_scan_load-tot_su_count = ls_batch_list-req_boxes.
        ls_scan_load-su_no        = ls_scanned_list-su_no.
        ls_scan_load-pallet_no    = ls_scanned_list-pallet_no.
        ls_scan_load-su_count     = lv_count.
        ls_scan_load-with_scheme  = iv_with_scheme.
        ls_scan_load-created_on   = sy-datum.
        ls_scan_load-created_at   = sy-timlo.
        ls_scan_load-created_by   = sy-uname.

        APPEND ls_scan_load TO et_scan_load.
        CLEAR:ls_scan_load.
      ENDLOOP.
    ENDLOOP.
  ENDLOOP.

  SELECT * FROM zwm_scan_load INTO TABLE @DATA(lt_scan_load)
    WHERE obd = @iv_obd_no
      AND load_no = @iv_load_no.
  IF sy-subrc EQ 0.
    DELETE zwm_scan_load FROM TABLE lt_scan_load.
  ENDIF.

  Modify zwm_scan_load FROM TABLE et_scan_load.
  IF sy-subrc ne 0.
    CLEAR: et_scan_load.
  ENDIF.

ENDFUNCTION.
