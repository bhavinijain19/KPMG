*************************************************************************************
*Object Name              : ZWM_PUTAWAY_LIST.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : class declaration and implementaion include.
*************************************************************************************
 CLASS lcl_putaway DEFINITION.
   PUBLIC SECTION.
     METHODS :  validation,                                            "method for validation
       fetch_data,                                            "method for fetching data
       smartform.                                             "method for calling smartform.
 ENDCLASS.


 CLASS lcl_putaway IMPLEMENTATION.
*********************************************************
*method for validating user input.
*********************************************************
   METHOD validation.

     SELECT SINGLE lgnum,
                   tanum
     FROM ltak
     INTO @DATA(wa_ltak)
     WHERE tanum IN @s_tanum.

     IF sy-subrc NE 0.
*       MESSAGE e000(zwm_putaway_list).
       MESSAGE TEXT-002 TYPE 'E'.
     ENDIF.

   ENDMETHOD.
*********************************************************
*method to fetching data.
*********************************************************
   METHOD fetch_data.

     SELECT lgnum                                              "fetching data from ltak table
            tanum
            trart
            bdatu
            kquit
     FROM ltak
     INTO TABLE it_ltak
     WHERE tanum IN s_tanum
     AND   trart EQ 'E'.
     "AND   kquit EQ 'X'.
     IF it_ltak IS NOT INITIAL.                                "initial check.

       SELECT lgnum                                            "fetching data from ltap.
              tanum
              tapos
              matnr
              werks
              charg
              meins
              nlpla
              nlenr
              nltyp
       FROM ltap
       INTO CORRESPONDING FIELDS OF TABLE it_ltap
       FOR ALL ENTRIES IN it_ltak
       WHERE tanum EQ it_ltak-tanum
       AND nltyp EQ p_nltyp.
       IF it_ltap IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*         SELECT  spras ,
*                 lgnum,
*                 lnumt
*       FROM    t300t
*       INTO @DATA(wa_t300t)
*       FOR ALL ENTRIES IN @it_ltap
*       WHERE lgnum EQ  @it_ltap-lgnum
*       AND   spras EQ  @sy-langu.

SELECT SPRAS ,
 LGNUM ,
 LNUMT
 FROM T300T
 INTO @DATA(WA_T300T)
 FOR ALL ENTRIES IN @IT_LTAP
 WHERE LGNUM EQ @IT_LTAP-LGNUM
 AND SPRAS EQ @SY-LANGU
 ORDER BY PRIMARY KEY .
* End of Quick Fix

         ENDSELECT.
         warehouse = wa_t300t-lgnum.
         desc = wa_t300t-lnumt.

         IF it_ltap IS NOT INITIAL.                              "initial check
           DATA(it_ltap_temp) = it_ltap.
           SORT it_ltap_temp BY lgnum tanum tapos.               "sorting it_ltap_temp
           DELETE ADJACENT DUPLICATES FROM it_ltap_temp COMPARING lgnum tanum tapos.
           SELECT matnr
                  spras
                  maktx
           FROM makt
           INTO TABLE it_makt
           FOR ALL ENTRIES IN it_ltap_temp
           WHERE matnr EQ it_ltap_temp-matnr
           AND   spras EQ sy-langu.

           SORT it_makt BY matnr.                                "sorting it_makt
           IF it_makt IS NOT INITIAL.                            "initial check

             DATA i TYPE char3 VALUE 1.
             DATA flag_nlenr TYPE c VALUE 0.
             LOOP AT it_ltap_temp ASSIGNING  <fs_ltap>.          "looping it_ltap
               IF <fs_ltap> IS ASSIGNED.
                 READ TABLE it_ltak ASSIGNING <fs_ltak> WITH KEY tanum = <fs_ltap>-tanum.   "reading it_ltak

                 IF <fs_ltak> IS ASSIGNED.
                   READ TABLE it_makt ASSIGNING <fs_makt> BINARY SEARCH WITH KEY matnr = <fs_ltap>-matnr "reading it_makt
                                                                                  spras = sy-langu.
                   IF <fs_makt> IS ASSIGNED.
                     APPEND INITIAL LINE TO it_final ASSIGNING <fs_final>.
                     IF <fs_final> IS ASSIGNED.
                       SHIFT <fs_ltap>-nlenr LEFT DELETING LEADING '0'.         "deleting leading zeroes.
                       DATA(nlenr1) = <fs_ltap>-nlenr.
                       AT NEW nlpla.
                         CONCATENATE gv_text nlenr1 INTO gv_text SEPARATED BY ''. "concatening gv_text
                         flag_nlenr = 1.
                       ENDAT.
                       IF flag_nlenr = 1.
                          flag_nlenr = 0.
                       ELSE.
                         nlenr1 = <fs_ltap>-nlenr+6(4).
                         CONCATENATE gv_text nlenr1 INTO gv_text SEPARATED BY ''.
                       ENDIF.

                       AT END OF nlpla.

                         <fs_final>-date = <fs_ltak>-bdatu.
                         <fs_final>-maktx = <fs_makt>-maktx.                      "filling final itab.
                         <fs_final>-lgnum = <fs_ltap>-lgnum.
                         <fs_final>-charg = <fs_ltap>-charg.
                         <fs_final>-tanum = <fs_ltap>-tanum.
                         <fs_final>-tapos = <fs_ltap>-tapos.
                         <fs_final>-matnr = <fs_ltap>-matnr.
                         <fs_final>-werks = <fs_ltap>-werks.
                         <fs_final>-meins = <fs_ltap>-meins.
                         <fs_final>-nlpla = <fs_ltap>-nlpla.
                         <fs_final>-nlenr = nlenr1.
                         <fs_final>-gv_text = gv_text.
                         <fs_final>-sno     = i.
                         i = i + 1.
                         CLEAR gv_text.


                       ENDAT.

                     ENDIF.
                   ENDIF.
                 ENDIF.

               ENDIF.
             ENDLOOP.
           ENDIF.
           DELETE ADJACENT DUPLICATES FROM it_final COMPARING tanum matnr charg nlpla. "deleting adjacent duplicates.
           DELETE it_final WHERE tanum IS INITIAL.

         ENDIF.
       ENDIF.
     ENDIF.
   ENDMETHOD.
*********************************************************
*method for calling smartform.
*********************************************************
   METHOD smartform.

     CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
       EXPORTING
         formname           = 'ZSF_PUTAWAY_LIST'
       IMPORTING
         fm_name            = var
       EXCEPTIONS
         no_form            = 1
         no_function_module = 2
         OTHERS             = 3.
     IF sy-subrc <> 0.
* Implement suitable error handling here
     ENDIF.

     CALL FUNCTION var
       EXPORTING
         it_final         = it_final
         warehouse        = warehouse
         desc             = desc
       EXCEPTIONS
         formatting_error = 1
         internal_error   = 2
         send_error       = 3
         user_canceled    = 4
         OTHERS           = 5.
     IF sy-subrc <> 0.
* Implement suitable error handling here
     ENDIF.


   ENDMETHOD.
 ENDCLASS.
