*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_INITIAL_TOP
*&---------------------------------------------------------------------*
*******Types Declaration.

TYPES:BEGIN OF ty_lqua,
        mandt TYPE mandt,
        lenum TYPE lenum,
        matnr TYPE matnr,
        werks TYPE werks_d,
        charg TYPE charg_d,
        lgpla TYPE lgpla,
        meins TYPE meins,
        verme TYPE lqua_verme,
        lgort TYPE lgort_d,
      END OF ty_lqua,

      BEGIN OF ty_mch1,
        matnr TYPE  matnr,
        charg TYPE charg_d,
        hsdat TYPE hsdat,
      END OF ty_mch1,

      BEGIN OF ty_makt,
        matnr TYPE matnr,
        maktx TYPE maktx,
      END OF ty_makt.

*        ***************Data Declaration*******************

DATA : it_lqua            TYPE STANDARD TABLE OF ty_lqua,
       wa_lqua            TYPE ty_lqua,
       it_makt            TYPE STANDARD TABLE OF ty_makt,
       wa_makt            TYPE ty_makt,
       it_mch1            TYPE STANDARD TABLE OF ty_mch1,
       wa_mch1            TYPE ty_mch1,
       it_final           TYPE STANDARD TABLE OF zsu_label_initial,
       wa_final           TYPE zsu_label_initial,
       v_form_name        TYPE rs38l_fnam,
       control_parameters TYPE ssfctrlop,
       w_cnt              TYPE i,
       w_cnt2             TYPE i,
       gv_ymcha           TYPE mcha,
       gv_classname       TYPE klah-class,
       it_clbatch         TYPE STANDARD TABLE OF clbatch,
       wa_clbatch         TYPE clbatch.

DATA: v_lenum TYPE lqua-lenum.
*********** Added by Carina Jose on 30/08/2022
CONSTANTS: c_uom TYPE rvari_vnam VALUE 'Z_LABEL_UOM'.
DATA : v_uom(03).
