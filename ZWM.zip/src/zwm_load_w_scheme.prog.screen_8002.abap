PROCESS BEFORE OUTPUT.

  MODULE status_8002.

  LOOP.
    MODULE transp_itab_out_8002.
  ENDLOOP.

PROCESS AFTER INPUT.

  LOOP.
    MODULE transp_itab_in_8002.
  ENDLOOP.

  MODULE user_command_8002.
