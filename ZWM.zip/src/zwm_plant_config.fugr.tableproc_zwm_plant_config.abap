*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZWM_PLANT_CONFIG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZWM_PLANT_CONFIG    .

  PERFORM TABLEPROC.

ENDFUNCTION.
