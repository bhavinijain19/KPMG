*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_N_PAI
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8000 INPUT.

  IF sy-ucomm EQ 'SCAN_TYPE_SELECTED'.
    CLEAR: lv_barcode_type, lv_palette_no, lv_su_no.
*    IF lv_scan_type EQ 'FP'.
*      lv_barcode_type = 'PA'.
*      CLEAR: lv_palette_no.
*    ELSEIF lv_scan_type EQ 'SU'.
*      lv_barcode_type = 'SU'.
*    ENDIF.
*  ELSEIF sy-ucomm EQ 'BARCODE_TYPE_SELECT'.
*    IF lv_barcode_type EQ 'PA'.
*      CLEAR: lv_palette_no.
*    ELSEIF lv_barcode_type EQ 'SU'.
*      CLEAR: lv_su_no.
*    ENDIF.
  ENDIF.

  IF sy-ucomm EQ 'ENTER'.

    IF lv_obd_no NE lv_obd_no_str. "IS NOT INITIAL.

      CLEAR: lt_mat_list, lt_batch_list, lv_obd_flag, lt_scanned_list_tmp.

      lv_temp_obd_no = lv_obd_no.
      lv_obd_no_str = lv_obd_no.

      lv_temp_obd_no = |{ lv_temp_obd_no ALPHA = IN }|.

      SELECT SINGLE * FROM likp INTO ls_likp WHERE vbeln = lv_temp_obd_no.
      IF sy-subrc NE 0.
        MESSAGE 'Invalid OBD.' TYPE 'E'.
        EXIT.
      ELSE.
        AUTHORITY-CHECK OBJECT 'ZWM_PLNT'
          ID 'ACTVT' FIELD '02'
          ID 'WERKS' FIELD ls_likp-vstel.
        IF sy-subrc NE 0.
          CLEAR: lv_msg.
          lv_msg = | Not authorized for OBD in plant | && ls_likp-vstel.
          MESSAGE lv_msg TYPE 'E'.
          EXIT.
        ENDIF.
        "check for non WM material
        IF ls_likp-vstel IS NOT INITIAL.
          CLEAR: lv_config_name, lv_config_value.
          CONCATENATE 'MAT_SLOC_' ls_likp-vstel INTO lv_config_name.

          SELECT SINGLE value FROM zwm_gen_config INTO lv_config_value WHERE name = lv_config_name.
          IF sy-subrc EQ 0.
            SPLIT lv_config_value AT ',' INTO TABLE lt_mat_sloc.
          ENDIF.
        ENDIF.
      ENDIF.

**BOC - Saurabh Saumya - VBUK is obsolete in HANA
*      SELECT COUNT(*) FROM vbuk WHERE vbeln =  lv_temp_obd_no                      "Commneted
*                                  AND lvstk = 'C'."#EC CI_DB_OPERATION_OK[2198647]

      SELECT COUNT(*) FROM likp WHERE vbeln =  lv_temp_obd_no     "Added - LIKP replaced VBUK
                                  AND lvstk = 'C'.
**EOC - Saurabh Saumya

      IF sy-subrc = 0.
        MESSAGE 'Delivery already processed/Inprocess.' TYPE 'E'.
        EXIT.
      ENDIF.

      SELECT COUNT(*) FROM zmm_load_sloc1 WHERE obd_no = lv_temp_obd_no
                                         AND load_status = 'W'.     "'I' AND obd_headitem = lin_item
      IF sy-subrc = 0.
        MESSAGE 'Delivery already processed/Inprocess.' TYPE 'E'.
      ENDIF.

      SELECT COUNT(*) FROM lips WHERE vbeln = lv_temp_obd_no
                                  AND uecha = ' '
                                  AND uepvw = 'B'.
      IF sy-subrc = 0.
        MESSAGE 'This OBD is for with scheme.' TYPE 'I'.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ZWM_FM_OBD_GET_LIST'
        IMPORTING
          et_list      = lt_mat_list_temp
          et_batch_exp = lt_batch_exp
        CHANGING
          obd_num      = lv_temp_obd_no
          load_no      = lv_load_no_tmp.

      IF lv_load_no_tmp IS NOT INITIAL.
        load_no = lv_load_no_tmp.
      ENDIF.

      IF lt_batch_exp[] IS NOT INITIAL.
        lv_obd_flag = 'X'.
        CALL SCREEN 8001.
      ELSEIF lt_mat_list[] IS INITIAL.
        lv_obd_flag = 'X'.
        lt_mat_list[] = lt_mat_list_temp[].

        LOOP AT lt_mat_list INTO ls_mat_list.
          LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
            APPEND LINES OF ls_batch_list-scanned_list TO lt_scanned_list_tmp.
          ENDLOOP.
        ENDLOOP.
        PERFORM get_bin_no.
      ENDIF.

    ELSEIF lv_palette_no IS NOT INITIAL AND lv_palette_no NE lv_temp_palette_no.
      lv_temp_palette_no = lv_palette_no.

      IF lv_palette_no IS NOT INITIAL.

        CLEAR: lv_flag1, lv_flag2, lv_su_cursor, lv_pallet_cursor.

        SELECT COUNT(*) FROM zwm_su WHERE palletno = lv_palette_no.
        IF sy-subrc NE 0.
          lv_pallet_cursor = 'X'.
          MESSAGE 'Invalid Pallet.' TYPE 'E'.
          EXIT.
        ENDIF.

        IF lv_scan_type EQ 'FP' OR lv_scan_type EQ 'PE'.

          SELECT * FROM zwm_pallet_map INTO TABLE lt_palette_map WHERE pallet_no = lv_palette_no.
          IF sy-subrc EQ 0.

            SELECT lenum FROM lein INTO TABLE @DATA(lt_lein_valid) FOR ALL ENTRIES IN @lt_palette_map
              WHERE lenum = @lt_palette_map-su_no.
            IF sy-subrc NE 0.
              lv_pallet_cursor = 'X'.
              MESSAGE 'Storage Unit Doesnot exist' TYPE 'I'.
              RETURN.
            ELSE.
              LOOP AT lt_palette_map INTO DATA(ls_pallet_map).
                READ TABLE lt_lein_valid TRANSPORTING NO FIELDS WITH KEY lenum = ls_pallet_map-su_no.
                IF sy-subrc NE 0.
                  DELETE lt_palette_map WHERE su_no = ls_pallet_map-su_no.
                ENDIF.
                CLEAR: ls_pallet_map.
              ENDLOOP.
            ENDIF.

            SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_palette_map
              WHERE palletno = lv_palette_no
              AND lenum = lt_palette_map-su_no.
            IF sy-subrc EQ 0.
              lt_su_tmp[] = lt_su[].
              SORT lt_su_tmp BY matnr.
              DELETE ADJACENT DUPLICATES FROM lt_su_tmp COMPARING matnr.
              LOOP AT lt_su_tmp INTO DATA(ls_su_tmp).
                READ TABLE lt_mat_list INTO ls_mat_list WITH KEY material = ls_su_tmp-matnr.
                IF sy-subrc EQ 0.
                  IF lv_scan_type EQ 'FP'.
                    lv_detail_disp = 'X'.
                    lv_row_selected = sy-tabix.
                  ENDIF.
                  READ TABLE ls_mat_list-batch_list INTO ls_batch_list WITH KEY batch_number = ls_su_tmp-charg
                                                                                status = 'C'.
                  IF sy-subrc EQ 0.
                    lv_pallet_cursor = 'X'.
                    MESSAGE 'Scanning has been completed for the line item.' TYPE 'E'.
                    RETURN.
                  ENDIF.
                ENDIF.
              ENDLOOP.
              LOOP AT lt_mat_list ASSIGNING <fs_mat_list>.
                LOOP AT <fs_mat_list>-batch_list ASSIGNING <fs_batch_list>.
                  LOOP AT lt_su INTO ls_su WHERE matnr = <fs_mat_list>-material
                                             AND charg = <fs_batch_list>-batch_number.
                    READ TABLE lt_scanned_list_tmp TRANSPORTING NO FIELDS WITH KEY su_no = ls_su-lenum.
                    IF sy-subrc EQ 0.
                      lv_flag2 = 'X'.
                      CONTINUE.
                    ENDIF.
                    lv_flag1 = 'X'.
*                    lv_count = lv_count + 1.
                    ls_scanned_list-pallet_no = ls_su-palletno.
                    ls_scanned_list-su_no     = ls_su-lenum.
                    ls_scanned_list-delete_button     = 'D'.
                    <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes + 1.
                    lv_count = <fs_batch_list>-scanned_boxes.
                    IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
                      <fs_batch_list>-status = 'C'.
                    ELSE.
                      <fs_batch_list>-status = ''.
                    ENDIF.
                    APPEND ls_scanned_list TO <fs_batch_list>-scanned_list.
                    APPEND ls_scanned_list TO lt_scanned_list_tmp.
                    CLEAR ls_scanned_list.
                  ENDLOOP.
                ENDLOOP.
              ENDLOOP.
              PERFORM get_bin_no. "USING lt_mat_list lt_lein.
*              IF lv_detail_disp EQ 'X'.
*                PERFORM get_detail USING lv_row_selected.
*              ENDIF.
              IF lv_flag1 EQ ''.
                IF lv_flag2 EQ 'X'.
                  lv_pallet_cursor = 'X'.
                  MESSAGE 'Pallet Scanned already.' TYPE 'E'.
                  EXIT.
                ENDIF.
                lv_pallet_cursor = 'X'.
                MESSAGE 'Scanned boxes materials not present in this OBD.' TYPE 'E'.
                EXIT.
              ELSEIF lv_scan_type EQ 'FP'.
                CLEAR lv_msg.
                MOVE lv_count TO lv_msg.
                lv_pallet_cursor = 'X'.
                CONCATENATE lv_msg 'no. of boxes scanned.' INTO lv_msg SEPARATED BY space.
                CLEAR: lv_count, lv_palette_no.
                MESSAGE lv_msg TYPE 'S'.
              ELSE.
                lv_su_cursor = 'X'.
                CLEAR lv_count.
              ENDIF.
            ELSE.
              lv_pallet_cursor = 'X'.
              MESSAGE 'No SU mapped with this Palette.' TYPE 'E'.
              EXIT.
            ENDIF.
          ELSE.
            lv_pallet_cursor = 'X'.
            MESSAGE 'No SU mapped with this Palette.' TYPE 'E'.
            EXIT.
          ENDIF.
        ELSE.
          lv_su_cursor = 'X'.
        ENDIF.
      ENDIF.

    ELSEIF ( lv_temp_su_no IS INITIAL AND lv_su_no IS NOT INITIAL ) OR lv_su_no NS lv_temp_su_no.

      SPLIT lv_su_no AT space INTO lv_mat lv_scanned_su.

      lv_temp_su_no = lv_scanned_su.

      IF lv_scanned_su IS NOT INITIAL.

        CLEAR: lv_pallet_cursor, lv_su_cursor.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = lv_scanned_su "lv_scanned_su
          IMPORTING
            output = lv_scanned_su.

        IF lv_scan_type EQ 'PI' OR lv_scan_type EQ 'SU'.

          READ TABLE lt_scanned_list_tmp TRANSPORTING NO FIELDS WITH KEY su_no = lv_scanned_su.
          IF sy-subrc EQ 0.
            CLEAR: lv_su_no.
            lv_su_cursor = 'X'.
            MESSAGE 'SU scanned already.' TYPE 'E'.
            EXIT.
          ENDIF.

          SELECT COUNT(*) FROM lein WHERE lenum = lv_scanned_su.
          IF sy-subrc NE 0.
            CLEAR: lv_su_no.
            lv_su_cursor = 'X'.
            MESSAGE 'Storage Unit Doesnot exist' TYPE 'I'.
            RETURN.
          ENDIF.

          CLEAR: lt_batch_exp, ls_lqua_su.
          IF lv_scan_type EQ 'PI'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*            SELECT SINGLE * FROM zwm_su INTO ls_su WHERE palletno = lv_palette_no
*                                                     AND lenum = lv_scanned_su.

SELECT * FROM ZWM_SU INTO LS_SU UP TO 1 ROWS WHERE PALLETNO = LV_PALETTE_NO
 AND LENUM = LV_SCANNED_SU
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix

          ELSEIF lv_scan_type EQ 'SU'.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*            SELECT SINGLE * FROM zwm_su INTO ls_su WHERE lenum = lv_scanned_su.

SELECT * FROM ZWM_SU INTO LS_SU UP TO 1 ROWS WHERE LENUM = LV_SCANNED_SU
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

            IF sy-subrc NE 0. "Changed to consider SU from old process | 05.12.2024

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*              SELECT SINGLE * FROM lqua INTO ls_lqua_su WHERE lenum = lv_scanned_su.

SELECT * FROM LQUA INTO LS_LQUA_SU UP TO 1 ROWS WHERE LENUM = LV_SCANNED_SU
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

            ENDIF.
          ENDIF.

          "Changed to consider SU from old process | 05.12.2024
          IF ls_lqua_su IS NOT INITIAL.
            READ TABLE lt_mat_list ASSIGNING <fs_mat_list> WITH KEY material = ls_lqua_su-matnr.
            IF sy-subrc NE 0.
              CLEAR: lv_su_no.
              lv_su_cursor = 'X'.
              MESSAGE 'Wrong Material Selected.' TYPE 'I'.
              EXIT.
            ELSE.
              READ TABLE <fs_mat_list>-batch_list ASSIGNING <fs_batch_list> WITH KEY batch_number = ls_lqua_su-charg.
              IF sy-subrc NE 0.
                CLEAR: lv_su_no.
                lv_su_cursor = 'X'.
                MESSAGE 'Wrong Batch Selected.' TYPE 'I'.
                EXIT.
              ELSE.
                IF <fs_batch_list>-status EQ 'C'.
                  CLEAR: lv_su_no.
                  lv_su_cursor = 'X'.
                  MESSAGE 'Scanning has been completed for the line item.' TYPE 'E'.
                  EXIT.
                  EXIT.
                ELSE.
                  <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes + 1.
                  lv_count = <fs_batch_list>-scanned_boxes.
                  IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
                    <fs_batch_list>-status = 'C'.
                  ELSE.
                    <fs_batch_list>-status = ''.
                  ENDIF.
                  ls_scanned_list-su_no = lv_scanned_su.
                  ls_scanned_list-delete_button = 'D'.
                  APPEND ls_scanned_list TO <fs_batch_list>-scanned_list.
                  APPEND ls_scanned_list TO lt_scanned_list_tmp.
                  PERFORM get_bin_no.
                  CLEAR ls_scanned_list.

                  CLEAR: lv_msg.
                  MOVE lv_count TO lv_msg.
                  lv_su_cursor = 'X'.
                  CONCATENATE lv_msg 'no. of boxes scanned.' INTO lv_msg SEPARATED BY space.
                  CLEAR: lv_count.
                  MESSAGE lv_msg TYPE 'S'.
                ENDIF.

                CLEAR: ls_batch_list.
              ENDIF.
              CLEAR: ls_mat_list.
            ENDIF.

          ELSEIF ls_su IS NOT INITIAL.

            READ TABLE lt_mat_list INTO ls_mat_list WITH KEY material = ls_su-matnr.
            IF sy-subrc EQ 0.
              READ TABLE ls_mat_list-batch_list INTO ls_batch_list WITH KEY batch_number = ls_su-charg.
              IF sy-subrc NE 0.
                CLEAR: lv_su_no.
                lv_su_cursor = 'X'.
                MESSAGE 'Scanned boxes materials not present in this OBD.' TYPE 'E'.
                EXIT.
              ENDIF.
            ELSE.
              CLEAR: lv_su_no.
              lv_su_cursor = 'X'.
              MESSAGE 'Scanned boxes materials not present in this OBD.' TYPE 'E'.
              EXIT.
            ENDIF.

            READ TABLE lt_mat_list ASSIGNING <fs_mat_list> WITH KEY material = ls_su-matnr.
            IF sy-subrc EQ 0.
              lv_detail_disp = 'X'.
              lv_row_selected = sy-tabix.
              READ TABLE <fs_mat_list>-batch_list ASSIGNING <fs_batch_list> WITH KEY batch_number = ls_su-charg.
              IF sy-subrc = 0.
                IF <fs_batch_list>-status EQ 'C'.
                  CLEAR: lv_su_no.
                  lv_su_cursor = 'X'.
                  MESSAGE 'Scanning has been completed for the line item.' TYPE 'E'.
                ELSE.
                  <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes + 1.
                  lv_count = <fs_batch_list>-scanned_boxes.
                  IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
                    <fs_batch_list>-status = 'C'.
                  ELSE.
                    <fs_batch_list>-status = ''.
                  ENDIF.
                  IF lv_scan_type EQ 'PI'.
                    ls_scanned_list-pallet_no = lv_palette_no.
                  ELSEIF lv_scan_type EQ 'SU'.
                    ls_scanned_list-pallet_no = ls_su-palletno.
                  ENDIF.
                  ls_scanned_list-su_no = lv_scanned_su.
                  ls_scanned_list-delete_button = 'D'.
                  APPEND ls_scanned_list TO <fs_batch_list>-scanned_list.
                  APPEND ls_scanned_list TO lt_scanned_list_tmp.
                  PERFORM get_bin_no.
                  CLEAR ls_scanned_list.

                  CLEAR: lv_msg.
                  MOVE lv_count TO lv_msg.
                  lv_su_cursor = 'X'.
                  CONCATENATE lv_msg 'no. of boxes scanned.' INTO lv_msg SEPARATED BY space.
                  CLEAR: lv_count.
                  MESSAGE lv_msg TYPE 'S'.
                ENDIF.
              ENDIF.
            ENDIF.

          ELSE.
            CLEAR: lv_su_no.
            lv_su_cursor = 'X'.
            MESSAGE 'Invalid SU.' TYPE 'E'.
            EXIT.
          ENDIF.

        ELSEIF lv_scan_type EQ 'PE'.

          READ TABLE lt_scanned_list_tmp TRANSPORTING NO FIELDS WITH KEY su_no = lv_scanned_su.
          IF sy-subrc NE 0.
            CLEAR: lv_su_no.
            lv_su_cursor = 'X'.
            MESSAGE 'Invalid SU.' TYPE 'E'.
            EXIT.
          ENDIF.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*          SELECT SINGLE * FROM zwm_su INTO ls_su WHERE lenum = lv_scanned_su.

SELECT * FROM ZWM_SU INTO LS_SU UP TO 1 ROWS WHERE LENUM = LV_SCANNED_SU
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

          LOOP AT lt_mat_list ASSIGNING <fs_mat_list> WHERE material = ls_su-matnr.
            lv_detail_disp = 'X'.
            lv_row_selected = sy-tabix.
            READ TABLE <fs_mat_list>-batch_list ASSIGNING <fs_batch_list> WITH KEY batch_number = ls_su-charg.
            IF sy-subrc EQ 0.
              IF <fs_batch_list>-status EQ 'C'.
                CLEAR: lv_su_no.
                lv_su_cursor = 'X'.
                MESSAGE 'Scanning has been completed for the line item.' TYPE 'E'.
              ELSE.
                DELETE <fs_batch_list>-scanned_list WHERE su_no = lv_scanned_su.
                IF sy-subrc = 0.
                  <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes - 1.
                  lv_count = <fs_batch_list>-scanned_boxes.
                  IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
                    <fs_batch_list>-status = 'C'.
                  ELSE.
                    <fs_batch_list>-status = ''.
                  ENDIF.
                  DELETE lt_scanned_list WHERE su_no = lv_scanned_su.
                  DELETE lt_scanned_list_tmp WHERE su_no = lv_scanned_su.

                  CLEAR: lv_msg.
                  MOVE lv_count TO lv_msg.
                  CONCATENATE lv_msg 'no. of boxes scanned.' INTO lv_msg SEPARATED BY space.
                  CLEAR: lv_count.
                  lv_su_cursor = 'X'.
                  MESSAGE lv_msg TYPE 'S'.
                  EXIT.
                ENDIF.
              ENDIF.
            ELSE.
              CLEAR: lv_su_no.
              lv_su_cursor = 'X'.
              MESSAGE 'Invalid SU.' TYPE 'E'.
              EXIT.
            ENDIF.

          ENDLOOP.

        ENDIF.

        PERFORM get_bin_no.
*        IF lv_detail_disp EQ 'X'.
*          PERFORM get_detail USING lv_row_selected.
*        ENDIF.

      ENDIF.

      FREE: lv_su_no.
*      IF lv_scan_type NE 'FP'.
*        wa_cursor = 'LV_SU_NO'.
*        SET CURSOR FIELD wa_cursor.
*      ENDIF.

    ELSEIF lv_mat_code NE lv_mat_code_tmp.

      lv_mat_code_tmp = lv_mat_code.

      IF lv_mat_code_tmp IS NOT INITIAL.

        READ TABLE lt_mat_list INTO ls_mat_list WITH KEY item_number = lv_mat_code_tmp.
        IF sy-subrc EQ 0.
          lv_detail_disp = 'X'.
          lv_row_selected = sy-tabix.
          PERFORM get_detail USING lv_row_selected.
        ELSE.
          READ TABLE lt_mat_list INTO ls_mat_list WITH KEY material = lv_mat_code_tmp.
          IF sy-subrc EQ 0.
            lv_detail_disp = 'X'.
            lv_row_selected = sy-tabix.
            PERFORM get_detail USING lv_row_selected.
          ELSE.
            lv_detail_disp = ''.
            CLEAR: lv_mat_code.
            MESSAGE 'Scanned material was not found in the OBD.' TYPE 'E'.
            EXIT.
          ENDIF.
        ENDIF.

      ENDIF.
    ENDIF.

  ELSEIF sy-ucomm EQ 'POST'.

    REFRESH: lt_load_list[], lt_incomplete_mat_list[].
    CLEAR: lv_msg, lv_mat_count.

    SELECT * FROM mch1 INTO TABLE lt_mch1 FOR ALL ENTRIES IN lt_mat_list WHERE matnr = lt_mat_list-material.

    LOOP AT lt_mat_list INTO ls_mat_list.
      LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
        IF ls_batch_list-req_boxes NE ls_batch_list-scanned_boxes.  "GT -> NE to be changed
          IF lv_msg IS INITIAL.
            lv_msg = 'No. of scanned boxes not matching with the no. of required boxes for material: '.
            CONCATENATE lv_msg ls_mat_list-material INTO lv_msg SEPARATED BY space.
            lv_mat_count = 1.
          ELSE.
            IF ls_mat_list-material NS lv_msg AND lv_mat_count LT 3.
              lv_mat_count = lv_mat_count + 1.
              CONCATENATE lv_msg ',' INTO lv_msg.
              CONCATENATE lv_msg ls_mat_list-material INTO lv_msg SEPARATED BY space.
            ENDIF.
          ENDIF.
          ls_incomplete_mat_list-item_no = ls_mat_list-item_number.
          ls_incomplete_mat_list-material = ls_mat_list-material.
          ls_incomplete_mat_list-batch_number = ls_batch_list-batch_number.
          ls_incomplete_mat_list-req_boxes = ls_batch_list-req_boxes.
          ls_incomplete_mat_list-scanned_boxes = ls_batch_list-scanned_boxes.
          APPEND ls_incomplete_mat_list TO lt_incomplete_mat_list.
          CLEAR: ls_incomplete_mat_list.
        ELSE.
          ls_load_list-item_no = ls_mat_list-item_number.
          ls_load_list-material = ls_mat_list-material.
          ls_load_list-batch_number = ls_batch_list-batch_number.
          ls_load_list-req_boxes = ls_batch_list-req_boxes.
          ls_load_list-scanned_boxes = ls_batch_list-scanned_boxes.
          READ TABLE lt_mch1 INTO ls_mch1 WITH KEY matnr = ls_mat_list-material
                                                   charg = ls_batch_list-batch_number.
          IF sy-subrc EQ 0.
            ls_load_list-expiry_date = ls_mch1-vfdat.
          ENDIF.
          ls_load_list-scanned_list[] = ls_batch_list-scanned_list[].
          APPEND ls_load_list TO lt_load_list.
          CLEAR: ls_load_list.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    IF lv_msg IS NOT INITIAL.
      MESSAGE lv_msg TYPE 'E'.
      EXIT.
    ELSE.
      CLEAR: lv_mat_count.
      """ADDED BY AKSHAY DT.10.07.2025
***      DATA:answer.
***      DATA:lv_chk_days TYPE i.
***      DATA: lv_self_exp_msg(255) TYPE c.
***      CLEAR:answer,lv_self_exp_msg.
***      SELECT SINGLE  low FROM tvarvc INTO @DATA(lv_days) WHERE name = 'ZWM_SELF_LIFE' AND type = 'P'.
***      IF lv_days IS NOT INITIAL.
***        LOOP AT lt_load_list INTO ls_load_list.
***          CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
***            EXPORTING
***              begda = sy-datum
***              endda = ls_load_list-expiry_date
***            IMPORTING
***              days  = lv_chk_days.
***          IF lv_chk_days LT lv_days.
***            CONCATENATE '"The batch expiry date is less than' lv_days 'days. Do you want to proceed with posting?"' INTO lv_self_exp_msg SEPARATED BY space.
***          ELSEIF lv_chk_days LT 1.
***            lv_self_exp_msg  = '"Batch Already Expire Do you want to proceed with posting?"'.
***          ENDIF.
***          CLEAR:ls_load_list.
***        ENDLOOP.
***
***        IF lv_self_exp_msg IS NOT INITIAL.
***
***          CALL FUNCTION 'POPUP_TO_CONFIRM'
***            EXPORTING
***              titlebar       = 'Self life Notification'
***              text_question  = lv_self_exp_msg "'"The batch expiry date is less than 90 days. Do you want to proceed with posting?"'
***              text_button_1  = 'YES'
***              text_button_2  = 'NO'
***              default_button = '1'
****             display_cancel_button = 'X'
***            IMPORTING
***              answer         = answer
***            EXCEPTIONS
***              text_not_found = 1
***              OTHERS         = 2.
***          IF sy-subrc <> 0.
***            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
***                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
***          ENDIF.
***
***          IF answer = '1'.
***            CALL SCREEN 8002.
***          ELSE.
***            MESSAGE 'Transaction Cancel' TYPE 'E'.
***            EXIT.
***          ENDIF.
***        ELSE.
***          CALL SCREEN 8002.
***        ENDIF.
***      ELSE.
***        CALL SCREEN 8002.
***      ENDIF.
      """""EOC AKSHAY DT.10.07.2025
      CALL SCREEN 8002. "STARTING AT 5 5. """commented by akshay dt.10.07.2025
    ENDIF.

  ELSEIF sy-ucomm EQ 'DETAIL'.

    CALL METHOD gr_grid1->get_selected_rows
      IMPORTING
        et_index_rows = lt_rowindex.

    IF lv_mat_code IS INITIAL.

      DESCRIBE TABLE lt_rowindex LINES lv_row_count.
      IF lv_row_count > 1.
        MESSAGE 'Please select single line item to display detail.' TYPE 'E'.
        EXIT.
      ENDIF.

    ENDIF.

    READ TABLE lt_rowindex INTO ls_rowindex INDEX 1.
    IF sy-subrc EQ 0.
      lv_row_selected = ls_rowindex-index.
      PERFORM get_detail USING lv_row_selected.
    ELSE.
      IF lv_mat_code IS NOT INITIAL.
        READ TABLE lt_mat_list INTO ls_mat_list WITH KEY material = lv_mat_code_tmp.
        IF sy-subrc EQ 0.
          lv_detail_disp = 'X'.
          lv_row_selected = sy-tabix.
          PERFORM get_detail USING lv_row_selected.
        ELSE.
          MESSAGE 'Scanned material was not found in the OBD.' TYPE 'E'.
          EXIT.
        ENDIF.
      ELSE.
        MESSAGE 'Please select a line item.' TYPE 'E'.
        EXIT.
      ENDIF.
    ENDIF.

  ELSEIF sy-ucomm EQ 'SAVE'.

    CLEAR: lv_msg, ls_sloc.
    REFRESH: lt_sloc.

    IF load_no IS INITIAL.
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING
          nr_range_nr             = '01'
          object                  = 'ZMM_LOAD'
        IMPORTING
          number                  = lv_num
        EXCEPTIONS
          interval_not_found      = 1
          number_range_not_intern = 2
          object_not_found        = 3
          quantity_is_0           = 4
          quantity_is_not_1       = 5
          interval_overflow       = 6
          buffer_overflow         = 7
          OTHERS                  = 8.
      IF sy-subrc EQ 0.
        load_no = lv_num.
      ENDIF.
    ENDIF.
    lv_load_no_tmp = load_no.

    SELECT * FROM lips INTO TABLE lt_lips WHERE vbeln = lv_temp_obd_no.
    IF sy-subrc EQ 0.
      IF lt_mat_sloc[] IS NOT INITIAL AND lt_lips[] IS NOT INITIAL.
        LOOP AT lt_mat_sloc INTO DATA(ls_mat_sloc).
          DELETE lt_lips WHERE lgort = ls_mat_sloc-lgort.
          CLEAR: ls_mat_sloc.
        ENDLOOP.
      ENDIF.
    ENDIF.

    IF lt_lips[] IS NOT INITIAL.
      SELECT matnr aumng FROM mvke INTO CORRESPONDING FIELDS OF TABLE lt_mvke
         FOR ALL ENTRIES IN lt_lips
         WHERE matnr = lt_lips-matnr
         AND vkorg = ls_likp-vkorg.
    ENDIF.

    SELECT * FROM lqua INTO TABLE lt_lqua FOR ALL ENTRIES IN lt_mat_list
      WHERE matnr = lt_mat_list-material.
    IF sy-subrc EQ 0.
      CLEAR: lv_no.
      SORT lt_lqua ASCENDING.

      LOOP AT lt_mat_list INTO ls_mat_list.
        LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
*          READ TABLE lt_lips INTO ls_lips WITH KEY matnr = ls_mat_list-material
*                                                   charg = ls_batch_list-batch_number.
*          LOOP AT ls_batch_list-scanned_list INTO ls_scanned_list.
*            READ TABLE lt_lqua INTO ls_lqua WITH KEY lenum = ls_scanned_list-su_no.
*
*            lv_no = lv_no + 1.
*            ls_sloc-load_no       = lv_load_no_tmp.
*            ls_sloc-load_item     = lv_no.
*            ls_sloc-su_no         = ls_scanned_list-su_no.
*            ls_sloc-obd_no        = lv_temp_obd_no.
*            ls_sloc-obd_lineitem  = ls_lips-posnr.
*            ls_sloc-obd_headitem  = ls_mat_list-item_number.
*            ls_sloc-entry_date    = sy-datum.
*            ls_sloc-storage_loc   = ls_lqua-lgort.
*            ls_sloc-matnr         = ls_lips-matnr.
*            ls_sloc-batch_no      = ls_batch_list-batch_number.
*            ls_sloc-quantity      = ls_lips-lfimg.
*            ls_sloc-uom           = ls_lips-meins.
*            ls_sloc-bin_loc       = ls_lqua-lgpla.
*            ls_sloc-load_status   = 'I'.
*            ls_sloc-plant         = ls_lqua-werks.
*            ls_sloc-su_qty        = ls_lqua-verme.
*            APPEND ls_sloc TO lt_sloc.
*            CLEAR: ls_sloc.
*          ENDLOOP.

          lt_scanned_list_temp[] = ls_batch_list-scanned_list[].
          READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_mat_list-material.

          LOOP AT lt_lips INTO ls_lips WHERE matnr = ls_mat_list-material
                                         AND charg = ls_batch_list-batch_number.

            CLEAR: lv_cnt, lv_req_su.
            IF ls_mvke-aumng IS NOT INITIAL.
              lv_req_su = ls_lips-lfimg / ls_mvke-aumng.
            ENDIF.

            LOOP AT lt_scanned_list_temp INTO ls_scanned_list.
              READ TABLE lt_lqua INTO ls_lqua WITH KEY lenum = ls_scanned_list-su_no.

              lv_no = lv_no + 1.
              lv_cnt = lv_cnt + 1.
              ls_sloc-load_no       = lv_load_no_tmp.
              ls_sloc-load_item     = lv_no.
              ls_sloc-su_no         = ls_scanned_list-su_no.
              ls_sloc-obd_no        = lv_temp_obd_no.
              ls_sloc-obd_lineitem  = ls_lips-posnr.
              ls_sloc-obd_headitem  = ls_lips-vgpos.
*              ls_sloc-obd_headitem  = ls_mat_list-item_number.
              ls_sloc-entry_date    = sy-datum.
              ls_sloc-storage_loc   = ls_lqua-lgort.
              ls_sloc-matnr         = ls_lips-matnr.
              ls_sloc-batch_no      = ls_lqua-charg.
              ls_sloc-quantity      = ls_lips-lfimg.
              ls_sloc-uom           = ls_lips-meins.
              ls_sloc-bin_loc       = ls_lqua-lgpla.
              ls_sloc-load_status   = 'I'.
              ls_sloc-plant         = ls_lqua-werks.
              ls_sloc-su_qty        = ls_lqua-verme.
              APPEND ls_sloc TO lt_sloc.
              CLEAR: ls_sloc.

              DELETE lt_scanned_list_temp WHERE su_no = ls_scanned_list-su_no.
              IF lv_cnt EQ lv_req_su.
                EXIT.
              ENDIF.
            ENDLOOP.

          ENDLOOP.

          CLEAR: lt_scanned_list_temp[], ls_mvke.
        ENDLOOP.
      ENDLOOP.

    ENDIF.

    IF lt_sloc[] IS NOT INITIAL.
      SELECT * FROM zmm_load_sloc1 INTO TABLE lt_sloc_temp
        FOR ALL ENTRIES IN lt_sloc
        WHERE obd_no = lt_sloc-obd_no
          AND load_status = 'I'.
      IF sy-subrc EQ 0.
        DELETE zmm_load_sloc1 FROM TABLE lt_sloc_temp.

        CLEAR: lt_sloc_temp.
      ENDIF.

      MODIFY zmm_load_sloc1 FROM TABLE lt_sloc.
      IF sy-subrc EQ 0.
        CONCATENATE 'Saved with Load No.' lv_load_no_tmp INTO lv_msg SEPARATED BY space.
        MESSAGE lv_msg TYPE 'S'.
      ENDIF.

      PERFORM update_mapping.
    ENDIF.

  ELSEIF sy-ucomm EQ 'LOAD'.

    IF load_no IS INITIAL.
      MESSAGE 'Please enter the Load No.' TYPE 'E'.
      EXIT.
    ELSE.
      lv_load_no_tmp = load_no.

      CLEAR: lv_msg.

      SELECT * FROM zmm_load_sloc1 INTO TABLE lt_sloc WHERE load_no = lv_load_no_tmp.
      IF sy-subrc EQ 0.

        CALL FUNCTION 'ZWM_FM_OBD_GET_LIST'
          IMPORTING
            et_list      = lt_mat_list_temp
            et_batch_exp = lt_batch_exp
          CHANGING
            load_no      = lv_load_no_tmp
            obd_num      = lv_temp_obd_no.

        IF lv_temp_obd_no IS NOT INITIAL.
          lv_obd_no = lv_temp_obd_no.
          lv_obd_no_str = lv_temp_obd_no.
        ENDIF.

        IF lt_batch_exp[] IS NOT INITIAL.
          lv_obd_flag = 'X'.
          CALL SCREEN 8001.
        ELSEIF lt_mat_list[] IS INITIAL.
          lv_obd_flag = 'X'.
          lt_mat_list[] = lt_mat_list_temp[].

          LOOP AT lt_mat_list INTO ls_mat_list.
            LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
              APPEND LINES OF ls_batch_list-scanned_list TO lt_scanned_list_tmp.
            ENDLOOP.
          ENDLOOP.
        ENDIF.
      ELSE.
        lv_msg = 'Load No not found'.
      ENDIF.

      IF lv_msg IS NOT INITIAL.
        MESSAGE lv_msg TYPE 'E'.
      ELSE.
        PERFORM get_bin_no.
*        PERFORM get_detail USING lv_row_selected.
      ENDIF.
    ENDIF.

  ELSEIF sy-ucomm EQ 'ERROR'.
    CALL SCREEN 8003.
  ENDIF.

  IF sy-ucomm EQ 'OBD_DELETE'.
    lv_detail_disp = ''.
    CLEAR: lv_obd_no, lv_palette_no, lv_su_no, lv_scanned_su, lv_temp_obd_no, lv_temp_palette_no, lv_temp_su_no,
           load_no, lv_load_no_tmp, lv_obd_flag, lv_scan_type, lv_barcode_type, lv_mat_code_tmp,
           lv_mat_code, lv_detail_disp, lv_row_selected, lv_obd_no_str.
    REFRESH: lt_mat_list_temp, lt_mat_list, lt_batch_list, lt_scanned_list, lt_batch_exp, lt_scanned_list_tmp,
             lt_mat_sloc.
  ELSEIF sy-ucomm EQ 'PALETTE_DELETE'.

    LOOP AT lt_mat_list ASSIGNING <fs_mat_list>.
      LOOP AT <fs_mat_list>-batch_list ASSIGNING <fs_batch_list>.
        READ TABLE <fs_batch_list>-scanned_list TRANSPORTING NO FIELDS WITH KEY pallet_no = lv_palette_no.
        IF sy-subrc = 0.
          DELETE <fs_batch_list>-scanned_list WHERE pallet_no = lv_palette_no.
          DELETE lt_scanned_list_tmp WHERE pallet_no = lv_palette_no.
        ENDIF.
        DESCRIBE TABLE <fs_batch_list>-scanned_list LINES <fs_batch_list>-scanned_boxes.
      ENDLOOP.
    ENDLOOP.
    PERFORM get_bin_no.
    CLEAR: lv_palette_no, lv_su_no, lv_scanned_su, lv_temp_palette_no, lv_temp_su_no.
    REFRESH: lt_scanned_list.

*    IF lv_detail_disp EQ 'X'.
*      PERFORM get_detail USING lv_row_selected.
*    ENDIF.
  ELSEIF sy-ucomm EQ 'SU_DELETE'.

    LOOP AT lt_mat_list ASSIGNING <fs_mat_list>.
      LOOP AT <fs_mat_list>-batch_list ASSIGNING <fs_batch_list>.
        DELETE <fs_batch_list>-scanned_list WHERE su_no = lv_scanned_su.
        IF sy-subrc EQ 0.
          DELETE lt_scanned_list_tmp WHERE su_no = lv_scanned_su.
          <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes - 1.
          IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
            <fs_batch_list>-status = 'C'.
          ELSE.
            <fs_batch_list>-status = ''.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    PERFORM get_bin_no.

    CLEAR: lv_su_no, lv_scanned_su.
*    IF lv_detail_disp EQ 'X'.
*      PERFORM get_detail USING lv_row_selected.
*    ENDIF.

  ELSEIF sy-ucomm EQ 'DELETE'.

    LOOP AT lt_scanned_list INTO ls_scanned_list WHERE delete_flag = 'X'.

      LOOP AT lt_mat_list ASSIGNING <fs_mat_list>.
        LOOP AT <fs_mat_list>-batch_list ASSIGNING <fs_batch_list>.
          READ TABLE <fs_batch_list>-scanned_list TRANSPORTING NO FIELDS WITH KEY su_no = ls_scanned_list-su_no.
*          pallet_no = ls_scanned_list-pallet_no
          IF sy-subrc EQ 0.
            DELETE <fs_batch_list>-scanned_list WHERE su_no = ls_scanned_list-su_no. "pallet_no = ls_scanned_list-pallet_no
            <fs_batch_list>-scanned_boxes = <fs_batch_list>-scanned_boxes - 1.
            IF <fs_batch_list>-scanned_boxes EQ <fs_batch_list>-req_boxes.
              <fs_batch_list>-status = 'C'.
            ELSE.
              <fs_batch_list>-status = ''.
            ENDIF.
            DELETE lt_scanned_list WHERE su_no = ls_scanned_list-su_no. "pallet_no = ls_scanned_list-pallet_no
            DELETE lt_scanned_list_tmp WHERE su_no = ls_scanned_list-su_no. "pallet_no = ls_scanned_list-pallet_no
          ENDIF.
        ENDLOOP.
      ENDLOOP.
      CLEAR: ls_scanned_list.
    ENDLOOP.

    PERFORM get_bin_no.

*    IF lv_detail_disp EQ 'X'.
*      PERFORM get_detail USING lv_row_selected.
*    ENDIF.

  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8001 INPUT.

  IF sy-ucomm EQ 'LOAD'.

    IF lt_mat_list IS INITIAL.
      lt_mat_list[] = lt_mat_list_temp[].

      LOOP AT lt_mat_list INTO ls_mat_list.
        LOOP AT ls_mat_list-batch_list INTO ls_batch_list.
          APPEND LINES OF ls_batch_list-scanned_list TO lt_scanned_list_tmp.
        ENDLOOP.
      ENDLOOP.

      PERFORM get_bin_no.
*      IF lv_detail_disp EQ 'X'.
*        PERFORM get_detail USING lv_row_selected.
*      ENDIF.
    ENDIF.

    LEAVE TO SCREEN 8000.

  ELSEIF sy-ucomm EQ 'CANCEL'.
    CLEAR: lv_obd_no, lv_temp_obd_no, lv_obd_no_str.

    LEAVE TO SCREEN 8000.

  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8002  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8002 INPUT.

  CLEAR: lt_sloc.

  IF sy-ucomm EQ 'DELETE'.
    DATA: ans(1) TYPE c.

    CALL METHOD gr_grid5->get_selected_rows
      IMPORTING
        et_index_rows = lt_rowindex.

    READ TABLE lt_rowindex INTO ls_rowindex INDEX 1.
    IF sy-subrc EQ 0.
      READ TABLE lt_load_list INTO ls_load_list INDEX ls_rowindex-index.
      IF sy-subrc EQ 0.
        DELETE lt_load_list INDEX ls_rowindex-index.
      ENDIF.
    ENDIF.

  ELSEIF sy-ucomm EQ 'POST'.

    IF lv_load_no_tmp IS INITIAL.
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING
          nr_range_nr             = '01'
          object                  = 'ZMM_LOAD'
        IMPORTING
          number                  = lv_num
        EXCEPTIONS
          interval_not_found      = 1
          number_range_not_intern = 2
          object_not_found        = 3
          quantity_is_0           = 4
          quantity_is_not_1       = 5
          interval_overflow       = 6
          buffer_overflow         = 7
          OTHERS                  = 8.

      load_no = lv_num.
      lv_load_no_tmp = lv_num.
    ENDIF.

    IF lv_load_no_tmp IS NOT INITIAL.

      SELECT * FROM lips INTO TABLE lt_lips WHERE vbeln = lv_temp_obd_no.
      IF sy-subrc EQ 0.
        IF lt_mat_sloc[] IS NOT INITIAL AND lt_lips[] IS NOT INITIAL.
          LOOP AT lt_mat_sloc INTO DATA(ls_mat_sloc1).
            DELETE lt_lips WHERE lgort = ls_mat_sloc1-lgort.
            CLEAR: ls_mat_sloc1.
          ENDLOOP.
        ENDIF.
        lt_lips_temp[] = lt_lips[].
      ENDIF.

      IF lt_lips[] IS NOT INITIAL.
        SELECT matnr aumng FROM mvke INTO CORRESPONDING FIELDS OF TABLE lt_mvke
           FOR ALL ENTRIES IN lt_lips
           WHERE matnr = lt_lips-matnr
           AND vkorg = ls_likp-vkorg.
      ENDIF.

      IF lt_load_list IS NOT INITIAL.
        SELECT * FROM lqua INTO TABLE lt_lqua FOR ALL ENTRIES IN lt_load_list
            WHERE charg = lt_load_list-batch_number
              AND matnr = lt_load_list-material.
      ENDIF.
      IF lt_lqua IS NOT INITIAL.
        CLEAR: lv_no.
        SORT lt_lqua ASCENDING.
        LOOP AT lt_load_list INTO ls_load_list.
*          READ TABLE lt_lips INTO ls_lips WITH KEY matnr = ls_load_list-material
*                                                   charg = ls_load_list-batch_number.
          lt_scanned_list_temp[] = ls_load_list-scanned_list[].
          READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_load_list-material.

          LOOP AT lt_lips INTO ls_lips WHERE matnr = ls_load_list-material
                                         AND charg = ls_load_list-batch_number.

            CLEAR: lv_cnt, lv_req_su.
            IF ls_mvke-aumng IS NOT INITIAL.
              lv_req_su = ls_lips-lfimg / ls_mvke-aumng.
            ENDIF.

            LOOP AT lt_scanned_list_temp INTO ls_scanned_list.
              READ TABLE lt_lqua INTO ls_lqua WITH KEY lenum = ls_scanned_list-su_no.

              lv_no = lv_no + 1.
              lv_cnt = lv_cnt + 1.
              ls_sloc-load_no       = lv_load_no_tmp.
              ls_sloc-load_item     = lv_no.
              ls_sloc-su_no         = ls_scanned_list-su_no.
              ls_sloc-obd_no        = lv_temp_obd_no.
              ls_sloc-obd_lineitem  = ls_lips-posnr.
*              ls_sloc-obd_headitem  = ls_load_list-item_no.
              ls_sloc-obd_headitem  = ls_lips-vgpos.
              ls_sloc-entry_date    = sy-datum.
              ls_sloc-storage_loc   = ls_lqua-lgort.
              ls_sloc-matnr         = ls_lips-matnr.
              ls_sloc-batch_no      = ls_lqua-charg.
              ls_sloc-quantity      = ls_lips-lfimg.
              ls_sloc-uom           = ls_lips-meins.
              ls_sloc-bin_loc       = ls_lqua-lgpla.
              ls_sloc-load_status   = 'I'.
              ls_sloc-plant         = ls_lqua-werks.
              ls_sloc-su_qty        = ls_lqua-verme.
              APPEND ls_sloc TO lt_sloc.
              CLEAR: ls_sloc.

              DELETE lt_scanned_list_temp WHERE su_no = ls_scanned_list-su_no.
              IF lv_cnt EQ lv_req_su.
                EXIT.
              ENDIF.
            ENDLOOP.

          ENDLOOP.

          CLEAR: lt_scanned_list_temp[].

*          LOOP AT ls_load_list-scanned_list INTO ls_scanned_list.
*            READ TABLE lt_lqua INTO ls_lqua WITH KEY lenum = ls_scanned_list-su_no.
*
*            lv_no = lv_no + 1.
*            ls_sloc-load_no       = lv_load_no_tmp.
*            ls_sloc-load_item     = lv_no.
*            ls_sloc-su_no         = ls_scanned_list-su_no.
*            ls_sloc-obd_no        = lv_temp_obd_no.
*            ls_sloc-obd_lineitem  = ls_lips-posnr.
*            ls_sloc-obd_headitem  = ls_load_list-item_no.
*            ls_sloc-entry_date    = sy-datum.
*            ls_sloc-storage_loc   = ls_lqua-lgort.
*            ls_sloc-matnr         = ls_lips-matnr.
*            ls_sloc-batch_no      = ls_lqua-charg.
*            ls_sloc-quantity      = ls_lips-lfimg.
*            ls_sloc-uom           = ls_lips-meins.
*            ls_sloc-bin_loc       = ls_lqua-lgpla.
*            ls_sloc-load_status   = 'I'.
*            ls_sloc-plant         = ls_lqua-werks.
*            ls_sloc-su_qty        = ls_lqua-verme.
*            APPEND ls_sloc TO lt_sloc.
*            CLEAR: ls_sloc.
*          ENDLOOP.
        ENDLOOP.

      ENDIF.

    ENDIF.

    IF lt_sloc[] IS NOT INITIAL.

      SELECT * FROM zmm_load_sloc1 INTO TABLE lt_sloc_temp
        FOR ALL ENTRIES IN lt_sloc
        WHERE obd_no = lt_sloc-obd_no
          AND load_status = 'I'.
      IF sy-subrc EQ 0.
        DELETE zmm_load_sloc1 FROM TABLE lt_sloc_temp.

        CLEAR: lt_sloc_temp.
      ENDIF.

      MODIFY zmm_load_sloc1 FROM TABLE lt_sloc.

      PERFORM update_mapping.

      SELECT * FROM zmm_load_sloc INTO TABLE lt_load_db WHERE load_no = lv_load_no_tmp.
      IF sy-subrc = 0.
        LOOP AT lt_load_db ASSIGNING FIELD-SYMBOL(<fs_load_db>).
          DELETE zmm_load_sloc FROM <fs_load_db>.
          <fs_load_db>-load_item = sy-tabix.
        ENDLOOP.
        DELETE zmm_load_sloc FROM TABLE lt_sloc.
        MODIFY zmm_load_sloc FROM TABLE lt_load_db.
      ENDIF.
    ENDIF.

    IF lv_load_no_tmp IS NOT INITIAL.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = lv_load_no_tmp
        IMPORTING
          output = lv_load_no_tmp.

      CLEAR: lt_load_sloc.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*      SELECT * FROM zmm_load_sloc1 INTO TABLE lt_load_sloc
*        WHERE load_no = lv_load_no_tmp
*          AND load_status IN ('I', 'W')
*          AND to_no = ' '.

SELECT * FROM zmm_load_sloc1 INTO TABLE lt_load_sloc
        WHERE load_no = lv_load_no_tmp
          AND load_status IN ('I', 'W')
          AND to_no = ' ' ORDER BY PRIMARY KEY .

* End of Quick Fix

      IF sy-subrc EQ 0.
        SELECT lenum lgnum letyp lgtyp lgpla FROM lein INTO TABLE lt_lein
          FOR ALL ENTRIES IN lt_load_sloc
          WHERE lenum = lt_load_sloc-su_no.

        SELECT werks lgort lgnum lgtyp lgber FROM zwm_picklist INTO TABLE lt_picklist
          FOR ALL ENTRIES IN lt_load_sloc
          WHERE werks = lt_load_sloc-plant.

        SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_load_sloc
          WHERE lenum = lt_load_sloc-su_no.

        lt_load_slocx[] = lt_load_sloc[].
        DELETE ADJACENT DUPLICATES FROM lt_load_sloc COMPARING load_no.

        SORT: lt_load_sloc BY load_no,
              lt_load_slocx BY load_no.
      ENDIF.

      CLEAR: lv_su_qty, lt_delit, lt_ltap, lv_row.
      LOOP AT lt_load_slocx ASSIGNING <fs_load_slocx>.

        ls_scanning_log-obd_no = <fs_load_slocx>-obd_no.
        ls_scanning_log-with_scheme = ''.
        ls_scanning_log-load_no = <fs_load_slocx>-load_no.

        READ TABLE lt_picklist INTO ls_picklist WITH KEY werks = <fs_load_slocx>-plant.
        IF sy-subrc EQ 0.
          ls_scanning_log-storage_section = ls_picklist-lgber.
        ENDIF.

        ls_delit-posnr = <fs_load_slocx>-obd_lineitem.
        ls_delit-anfme = <fs_load_slocx>-su_qty.
        ls_delit-altme = <fs_load_slocx>-uom.
        ls_delit-charg = <fs_load_slocx>-batch_no.

        READ TABLE lt_lein INTO ls_lein WITH KEY lenum = <fs_load_slocx>-su_no.
        IF sy-subrc EQ 0.
          ls_delit-letyp  =  ls_lein-letyp.
          ls_delit-vltyp  =  ls_lein-lgtyp.

          ls_ltap-letyp  =  ls_lein-letyp.
          ls_ltap-lgnum  =  ls_lein-lgnum.
          ls_ltap-vlber  =  ls_picklist-lgber.
          ls_ltap-posnr = <fs_load_slocx>-obd_lineitem.

          ls_scanning_log-su_type = ls_lein-letyp.
          ls_scanning_log-storage_type = ls_lein-lgtyp.
        ENDIF.
        ls_delit-vlpla = <fs_load_slocx>-bin_loc.
        ls_delit-vlber  = ls_picklist-lgber.
        UNPACK <fs_load_slocx>-su_no TO ls_delit-vlenr.
        APPEND ls_delit TO lt_delit.

        lv_row = lv_row + 1.
        ls_ltap-tapos = lv_row.
        ls_ltap-altme = <fs_load_slocx>-uom.
        ls_ltap-charg = <fs_load_slocx>-batch_no.
        ls_ltap-vltyp = ls_lein-lgtyp.
        ls_ltap-letyp = ls_lein-letyp.
        ls_ltap-vlpla = <fs_load_slocx>-bin_loc.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = <fs_load_slocx>-su_no
          IMPORTING
            output = <fs_load_slocx>-su_no.

        ls_ltap-matnr = <fs_load_slocx>-matnr.
        ls_ltap-sonum = <fs_load_slocx>-su_no.
        ls_ltap-nista = <fs_load_slocx>-su_qty.
        APPEND ls_ltap TO lt_ltap.

        lv_su_qty = lv_su_qty + <fs_load_slocx>-su_qty.

        ls_scanning_log-row_count   = lv_row.
        ls_scanning_log-to_status   = 'InProgress'.
        ls_scanning_log-status      = 'InProgress'.
        ls_scanning_log-created_by  = sy-uname.
        ls_scanning_log-created_on  = sy-datum.
        ls_scanning_log-created_at  = sy-timlo.
        ls_scanning_log-warehoue_no = ls_picklist-lgnum.

        CLEAR:ls_su.
        READ TABLE lt_su INTO ls_su WITH KEY lenum = <fs_load_slocx>-su_no.
        IF sy-subrc EQ 0.
          ls_scanning_log-palette_no = ls_su-palletno.
        ENDIF.
        ls_scanning_log-su_no         = <fs_load_slocx>-su_no.
        ls_scanning_log-su_qty        = <fs_load_slocx>-su_qty.
        ls_scanning_log-storage_loc   = <fs_load_slocx>-storage_loc.
        ls_scanning_log-storage_bin   = <fs_load_slocx>-bin_loc.
        ls_scanning_log-batch         = <fs_load_slocx>-batch_no.
        ls_scanning_log-material      = <fs_load_slocx>-matnr.
        ls_scanning_log-head_item_no  = <fs_load_slocx>-obd_headitem.
        ls_scanning_log-line_item_no  = <fs_load_slocx>-obd_lineitem.
        ls_scanning_log-quantity      = <fs_load_slocx>-quantity.
        ls_scanning_log-uom           = <fs_load_slocx>-uom.

        APPEND ls_scanning_log TO lt_scanning_log.
        CLEAR: ls_scanning_log.

      ENDLOOP.

      CLEAR lt_load_slocx_tmp.
      lt_load_slocx_tmp[] = lt_load_slocx[].
      SORT lt_load_slocx_tmp BY matnr batch_no.
      DELETE ADJACENT DUPLICATES FROM lt_load_slocx_tmp COMPARING matnr batch_no.

      CLEAR: lv_total_del_qty.
      LOOP AT lt_load_slocx ASSIGNING FIELD-SYMBOL(<fs_load_slocx_temp>).
        IF <fs_load_slocx_temp> IS ASSIGNED.
          lv_total_del_qty = lv_total_del_qty + <fs_load_slocx_temp>-quantity.
        ENDIF.
      ENDLOOP.

      CLEAR: lv_total_qty_ltot.

*      SELECT * FROM lips INTO CORRESPONDING FIELDS OF TABLE lt_lips
*        WHERE vbeln = lv_temp_obd_no.
*      IF sy-subrc = 0.
*        IF lt_mat_sloc[] IS NOT INITIAL AND lt_lips[] IS NOT INITIAL.
*          LOOP AT lt_mat_sloc INTO DATA(ls_mat_sloc).
*            DELETE lt_lips WHERE lgort = ls_mat_sloc-lgort.
*          ENDLOOP.
*        ENDIF.
*        LOOP AT lt_lips INTO ls_lips.
*          lv_total_qty_ltot  = lv_total_qty_ltot + ls_lips-lfimg.
*        ENDLOOP.
*      ENDIF.
      LOOP AT lt_lips_temp INTO ls_lips.
        lv_total_qty_ltot  = lv_total_qty_ltot + ls_lips-lfimg.
        CLEAR: ls_lips.
      ENDLOOP.

      CLEAR: lv_flag.
      IF lv_su_qty NE lv_total_qty_ltot.
        lv_flag  = 'X'.
        UPDATE zmm_load_sloc1 SET
        err_msg   = 'Del Qty didnt Match with total SU Qty.'
        load_status    = 'I'
        WHERE load_no = lv_load_no_tmp.
        MESSAGE 'Delivery quantity not equal to box qty.' TYPE 'E'.
        EXIT.
      ENDIF.

      IF lt_ltap IS NOT INITIAL AND lv_flag IS INITIAL.
        CALL FUNCTION 'L_TO_CREATE_DN'
          EXPORTING
            i_lgnum                    = ls_picklist-lgnum
            i_vbeln                    = lv_temp_obd_no
            i_commit_work              = 'X'
            i_bname                    = sy-uname
            i_solex                    = lv_total_del_qty
            it_delit                   = lt_delit
          IMPORTING
            e_tanum                    = lv_tanum
            e_teilk                    = lv_teilk
          TABLES
            t_ltak                     = lt_ltak
            t_ltap_vb                  = lt_ltap
            t_wmgrp_msg                = lt_wmgrp_msg
          EXCEPTIONS
            foreign_lock               = 1
            dn_completed               = 2
            partial_delivery_forbidden = 3
            xfeld_wrong                = 4
            ldest_wrong                = 5
            drukz_wrong                = 6
            dn_wrong                   = 7
            squit_forbidden            = 8
            no_to_created              = 9
            teilk_wrong                = 10
            update_without_commit      = 11
            no_authority               = 12
            no_picking_allowed         = 13
            dn_hu_not_choosable        = 14
            input_error                = 15
            OTHERS                     = 16.
        IF sy-subrc = 0.
          lv_flag = 'X'.
          CLEAR: ls_ltap.

          LOOP AT lt_scanning_log ASSIGNING <fs_scanning_log>.
            <fs_scanning_log>-transfer_order = lv_tanum.
            <fs_scanning_log>-to_status = 'Created'.
            <fs_scanning_log>-tot_delv_qty = lv_total_del_qty.
          ENDLOOP.

          SELECT * FROM zwm_scanning_log INTO TABLE lt_scanning_log_tmp WHERE obd_no = lv_temp_obd_no.
          IF sy-subrc EQ 0.
            DELETE zwm_scanning_log FROM TABLE lt_scanning_log_tmp.
          ENDIF.

          MODIFY zwm_scanning_log FROM TABLE lt_scanning_log.

        ELSE.
          CLEAR: lv_msg.
          CALL FUNCTION 'FORMAT_MESSAGE'
            EXPORTING
              id        = sy-msgid
              lang      = '-D'
              no        = sy-msgno
              v1        = sy-msgv1
              v2        = sy-msgv2
              v3        = sy-msgv3
              v4        = sy-msgv4
            IMPORTING
              msg       = lv_msg
            EXCEPTIONS
              not_found = 1
              OTHERS    = 2.
          CLEAR lv_flag.

          UPDATE zmm_load_sloc1 SET
            err_msg        = lv_msg
            to_create_date = sy-datum
            load_status    = 'I'
            WHERE load_no = lv_load_no_tmp.

          LOOP AT lt_scanning_log ASSIGNING <fs_scanning_log>.
            <fs_scanning_log>-tot_delv_qty = lv_total_del_qty.
            <fs_scanning_log>-status = 'Error'.
            <fs_scanning_log>-error_msg = lv_msg.
          ENDLOOP.

          SELECT * FROM zwm_scanning_log INTO TABLE lt_scanning_log_tmp WHERE obd_no = lv_temp_obd_no.
          IF sy-subrc EQ 0.
            DELETE zwm_scanning_log FROM TABLE lt_scanning_log_tmp.
          ENDIF.

          MODIFY zwm_scanning_log FROM TABLE lt_scanning_log.

          MESSAGE lv_msg TYPE 'E'.
          EXIT.
        ENDIF.

        CLEAR:lt_messtab.
        IF ls_picklist-lgnum IS NOT INITIAL AND lv_flag = 'X' AND lv_tanum IS NOT INITIAL.

          PERFORM bdc_dynpro      USING 'SAPML03T'   '0111'.
          PERFORM bdc_field       USING 'BDC_CURSOR' 'LTAK-TANUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE' '/00'.
          PERFORM bdc_field       USING 'LTAK-TANUM' lv_tanum.
          PERFORM bdc_field       USING 'LTAK-LGNUM' ls_picklist-lgnum.

          PERFORM bdc_dynpro      USING 'SAPML03T'   '0113'.
          PERFORM bdc_field       USING 'BDC_CURSOR' 'LTAK-LGNUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE' '=BU'.

          CALL TRANSACTION 'LT12' USING lt_bdcdata
                 MESSAGES INTO lt_messtab MODE 'N' UPDATE 'S'.

          CLEAR lt_bdcdata.
          CLEAR ls_bdcdata.


          CLEAR:ls_messtab,lv_msg.
          READ TABLE lt_messtab INTO ls_messtab WITH KEY msgtyp = 'E' .
          IF sy-subrc = 0.
            CALL FUNCTION 'FORMAT_MESSAGE'
              EXPORTING
                id        = ls_messtab-msgid
                lang      = '-D'
                no        = ls_messtab-msgnr
                v1        = ls_messtab-msgv1
                v2        = ls_messtab-msgv2
                v3        = ls_messtab-msgv3
                v4        = ls_messtab-msgv4
              IMPORTING
                msg       = lv_msg
              EXCEPTIONS
                not_found = 1
                OTHERS    = 2.

            UPDATE zmm_load_sloc1 SET
             err_msg        = lv_msg
             to_create_date = sy-datum
             load_status    = 'I'
             WHERE load_no = lv_load_no_tmp.

            LOOP AT lt_scanning_log ASSIGNING <fs_scanning_log>.
              <fs_scanning_log>-status = 'Error'.
              <fs_scanning_log>-error_msg = lv_msg.
            ENDLOOP.

            SELECT * FROM zwm_scanning_log INTO TABLE lt_scanning_log_tmp WHERE obd_no = lv_temp_obd_no.
            IF sy-subrc EQ 0.
              DELETE zwm_scanning_log FROM TABLE lt_scanning_log_tmp.
            ENDIF.

            MODIFY zwm_scanning_log FROM TABLE lt_scanning_log.

            MESSAGE lv_msg TYPE 'E'.
            EXIT.
          ELSE.
            CLEAR: lv_msg.
            UPDATE zmm_load_sloc1 SET to_no = lv_tanum
            err_msg        = ' '
            to_create_date = sy-datum
            load_status    = 'C'
            WHERE load_no = lv_load_no_tmp.

            LOOP AT lt_scanning_log ASSIGNING <fs_scanning_log>.
              <fs_scanning_log>-to_status = 'Confirmed'.
            ENDLOOP.

            SELECT * FROM zwm_scanning_log INTO TABLE lt_scanning_log_tmp WHERE obd_no = lv_temp_obd_no.
            IF sy-subrc EQ 0.
              DELETE zwm_scanning_log FROM TABLE lt_scanning_log_tmp.
            ENDIF.

            MODIFY zwm_scanning_log FROM TABLE lt_scanning_log.


            LOOP AT lt_load_list INTO ls_load_list.
              APPEND LINES OF ls_load_list-scanned_list TO lt_scanned_list.
            ENDLOOP.

            IF lt_scanned_list[] IS NOT INITIAL.
              SELECT * FROM zwm_pallet_map INTO TABLE lt_palette_map FOR ALL ENTRIES IN lt_scanned_list
                WHERE pallet_no = lt_scanned_list-pallet_no
                  AND su_no     = lt_scanned_list-su_no.
              IF sy-subrc EQ 0.
                DELETE zwm_pallet_map FROM TABLE lt_palette_map.
                IF sy-subrc EQ 0.
                  CALL FUNCTION 'GUID_CREATE'
                    IMPORTING
                      ev_guid_16 = lv_guid_id.

                  IF lv_guid_id IS NOT INITIAL.
                    ls_mapping_log-guid_id = lv_guid_id.
                    ls_mapping_log-obd = lv_temp_obd_no.
                    DESCRIBE TABLE lt_palette_map LINES ls_mapping_log-deletion_count.
                    ls_mapping_log-application = 'New'.
                    ls_mapping_log-deletion_spot = 'Without Scheme TO Confirmation'.
                    ls_mapping_log-deleted_by = sy-uname.
                    ls_mapping_log-deleted_on = sy-datum.
                    ls_mapping_log-deleted_at = sy-timlo.

                    IF ls_mapping_log IS NOT INITIAL.
                      MODIFY zwm_mapping_log FROM ls_mapping_log.
                      CLEAR: ls_mapping_log.
                    ENDIF.
                    CLEAR: lv_guid_id.
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDIF.

            FREE:lt_delit[],lt_bdcdata.
            CONCATENATE 'TO created and confirmed with no' lv_tanum INTO lv_msg SEPARATED BY space.
            MESSAGE lv_msg TYPE 'S'.
            lv_detail_disp = ''.
            CLEAR: lv_obd_no, lv_palette_no, lv_su_no, lv_scanned_su, lv_temp_obd_no, lv_temp_palette_no, lv_temp_su_no,
                   lv_barcode_type, lv_scan_type, lv_detail_disp, lv_row_selected, lv_obd_no_str, load_no, lv_mat_code,
                   lv_obd_flag.
            REFRESH: lt_mat_list_temp, lt_mat_list, lt_batch_list, lt_scanned_list, lt_batch_exp, lt_scanned_list_tmp,
                     lt_mat_sloc.
            CALL SCREEN 8000.
          ENDIF.
          CLEAR lv_tanum.

        ENDIF.
      ENDIF.
    ENDIF.

  ELSEIF sy-ucomm EQ 'CANCEL'.
    LEAVE TO SCREEN 8000.
  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8003  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8003 INPUT.

  IF sy-ucomm EQ 'BACK'.
    CLEAR: lv_mat_count.
    LEAVE TO SCREEN 8000.
  ENDIF.

ENDMODULE.
