FUNCTION-POOL ZWM_PLANT_CONFIG           MESSAGE-ID SV.

* INCLUDE LZWM_PLANT_CONFIGD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZWM_PLANT_CONFIGT00                    . "view rel. data dcl.
