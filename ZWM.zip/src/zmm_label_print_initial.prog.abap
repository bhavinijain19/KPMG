*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Rajni
*&  Functional Consultant   :    Sachin Padwal and Vikas Pasalkar
*&  Requirement             :    Label Print for initial Stock Uploa(2*4)
*&  Revieved By             :
*&  Request                 :    DEVK912643
*&---------------------------------------------------------------------*
*& Report  ZMM_LABEL_PRINT_INITIAL
*&---------------------------------------------------------------------*
REPORT zmm_label_print_initial.
*&---------------------------------------------------------------------*
*&                INCLUDES
*&---------------------------------------------------------------------*
TABLES : zmm_su_number,makt.
INCLUDE zmm_label_print_initial_top.
INCLUDE zmm_label_print_initial_scr.
*&---------------------------------------------------------------------*
*&                start-of-selection
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CLEAR : it_lqua,it_makt,it_mch1.
  "select header data from LQUA
  SELECT mandt
      lenum
      matnr
      werks
      charg
      lgpla
      meins
      verme
      lgort
       FROM lqua
        INTO TABLE it_lqua
      WHERE lenum IN s_zsu_no.

  IF sy-subrc EQ 0.
    SORT it_lqua BY lenum.
  ENDIF.
  IF it_lqua IS NOT INITIAL.
    "select date from MCHL
    SELECT matnr
         charg
         hsdat
         FROM mch1
         INTO TABLE it_mch1
         FOR ALL ENTRIES IN it_lqua
         WHERE matnr EQ it_lqua-matnr AND
    charg EQ it_lqua-charg.

    IF sy-subrc EQ 0.
      SORT it_mch1 BY matnr charg.
    ENDIF.
    "select description from MAKT
    SELECT matnr
           maktx
           FROM makt
           INTO TABLE it_makt
           FOR ALL ENTRIES IN it_lqua
    WHERE matnr EQ it_lqua-matnr AND spras = 'EN'.

    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.
  ENDIF.

  CLEAR it_final.
  CLEAR wa_final.
  CLEAR : v_uom.
  SELECT SINGLE low
    INTO v_uom
    FROM tvarvc
    WHERE name = c_uom .


  LOOP AT it_lqua INTO wa_lqua.
    wa_final-lenum = wa_lqua-lenum.
    wa_final-verme = wa_lqua-verme.
    wa_final-meins = wa_lqua-meins .
    wa_final-matnr = wa_lqua-matnr .
    wa_final-charg = wa_lqua-charg.
    wa_final-lgpla = wa_lqua-lgpla.
    wa_final-lenum = wa_lqua-lenum.  "Added by Deepthi C
******    Added by Carina Jose on 30/08/2022
    IF wa_final-meins = 'EA'.
      wa_final-meins = v_uom.
    ENDIF.
******    End of changes by Carina Jose on 30/08/2022

    CALL FUNCTION 'VB_BATCH_GET_DETAIL'
      EXPORTING
        matnr              = wa_lqua-matnr
        charg              = wa_lqua-charg
        werks              = wa_lqua-werks
        get_classification = 'X'
      IMPORTING
        ymcha              = gv_ymcha
        classname          = gv_classname
      TABLES
        char_of_batch      = it_clbatch
      EXCEPTIONS
        no_material        = 1
        no_batch           = 2
        no_plant           = 3
        material_not_found = 4
        plant_not_found    = 5
        no_authority       = 6
        batch_not_exist    = 7
        lock_on_batch      = 8
        OTHERS             = 9.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
    CLEAR wa_clbatch.
    IF gv_classname = 'BATCH_EXP'.
      READ TABLE it_clbatch INTO wa_clbatch WITH KEY atnam = 'MFGD_DATE_PRINT'.
      IF sy-subrc EQ 0.
        REPLACE ALL OCCURRENCES OF '.' IN wa_clbatch-atwtb WITH space.
        CONDENSE wa_clbatch-atwtb.
        CONCATENATE wa_clbatch-atwtb+4(4) wa_clbatch-atwtb+2(2) wa_clbatch-atwtb+0(2) INTO wa_final-hsdat.
      ENDIF.
    ENDIF.

    IF wa_clbatch-atwtb IS INITIAL.
      CLEAR wa_mch1.
      READ TABLE it_mch1 INTO wa_mch1 WITH KEY matnr = wa_lqua-matnr
                                               charg = wa_lqua-charg BINARY SEARCH.

      IF sy-subrc EQ 0.
        wa_final-hsdat = wa_mch1-hsdat.
      ENDIF.
    ENDIF.

    CLEAR wa_makt.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-maktx = wa_makt-maktx.
    ENDIF.

    APPEND wa_final TO it_final.
    CLEAR wa_final.
  ENDLOOP.
****Added changes to print label with batch or without batch by Carina Jose on 24.07.2019
  IF p_rad1  = 'X'.
    "FM to call smartform with Batch
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname           = 'ZLABEL_PRINT_INITIALBATCH'
      IMPORTING
        fm_name            = v_form_name
      EXCEPTIONS
        no_form            = 1
        no_function_module = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ELSEIF p_rad2 = 'X'.
    "FM to call smartform without Batch
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname           = 'ZLABEL_PRINT_INITIAL'
      IMPORTING
        fm_name            = v_form_name
      EXCEPTIONS
        no_form            = 1
        no_function_module = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.
****End of changes by Carina Jose on 24.07.2019

"Commented By BP
*  SELECT SINGLE * FROM usr05
*    INTO @DATA(ls_usr05) WHERE bname EQ @sy-uname
*                           AND parid EQ 'ZRE_PRINT'
*                           AND parva EQ @abap_true.
*   IF sy-subrc IS NOT INITIAL AND it_final IS NOT INITIAL.
*    SELECT * FROM zwm_su
*     INTO TABLE @DATA(it_su)
*      FOR ALL ENTRIES IN @it_final
*       WHERE lenum  = @it_final-lenum
*         AND pprint = @abap_true.
*      IF sy-subrc IS INITIAL.
*       MESSAGE 'No authorization for re-printing the labels' TYPE 'S' DISPLAY LIKE 'E'.
*       EXIT.
*      ENDIF.
*   ENDIF.

  "loop for all the entries to print all entries.
  IF it_final IS NOT INITIAL.
    DESCRIBE TABLE it_final LINES w_cnt.

    LOOP AT it_final INTO wa_final.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = wa_final
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
*      IF sy-ucomm EQ 'PRNT'.  "Commented By BP
*        SELECT SINGLE * FROM zwm_su
*          INTO @DATA(ls_su) WHERE lenum = @wa_final-lenum.
*        IF sy-subrc EQ 0.
*          IF ls_su-pprint EQ abap_true.
*            IF ls_usr05-parva EQ abap_true.
*              ls_su-re_print = abap_true.
*              ls_su-re_pdate = sy-datum.
*              ls_su-re_ptime = sy-uzeit.
*              ls_su-re_uname = sy-uname.
*              MODIFY zwm_su FROM ls_su.
*            ENDIF.
*          ELSEIF ls_su-pprint EQ abap_false.
*            ls_su-pprint = abap_true.
*            ls_su-pdate  = sy-datum.
*            ls_su-ptime  = sy-uzeit.
*            ls_su-puname = sy-uname.
*            MODIFY zwm_su FROM ls_su.
*          ENDIF.
*        ENDIF.
*      ENDIF.
    ENDLOOP.
  ENDIF.
