*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Rajni (ID 135402)
*&  Functional Consultant   :    Sachin Padwal and Vikas Pasalkar
*&  Requirement             :    Physical Inventory Stock Check
*&  Revieved By             :    Dhaval
*&  Request                 :    DEVK913819
*&---------------------------------------------------------------------*
*& Report  ZPHYSICAL_INVENTORY
*&---------------------------------------------------------------------*
REPORT zphysical_inventory.
INCLUDE: zphysical_inventory_top,
         zphysical_inventory_scr.
*&---------------------------------------------------------------------*
*&      at selection-screen
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.
  SELECT SINGLE * FROM link INTO @DATA(wa) WHERE lgnum = @p_lgnum
                                         AND ivnum = @p_ivnum
  AND ivakt = 'X'.
  IF sy-subrc <> 0.
    MESSAGE:'Inventory Document is not activated' TYPE 'E'.
  ENDIF.
  if p_matnr is not initial.
  select single lgnum, matnr from lqua into @data(wa1) where lgnum = @p_lgnum and matnr = @p_matnr.
    If sy-subrc <> 0.
      message:'material not available in warehouse' type 'E'.
      endif.
      endif.
*&---------------------------------------------------------------------*
*&            start-of-selection
*&---------------------------------------------------------------------*
START-OF-SELECTION.
  SELECT SINGLE * FROM link INTO @DATA(wa_link) WHERE lgnum = @p_lgnum
                                         AND ivnum = @p_ivnum
  AND ivakt = 'X'.
  SELECT * FROM linp INTO TABLE @DATA(it_linp) WHERE lgnum = @p_lgnum
  AND ivnum = @p_ivnum.
  IF sy-subrc = 0 AND it_linp IS NOT INITIAL.
    if p_matnr is not initial.
      SELECT lgnum lqnum matnr werks charg lgtyp lgpla verme lgort lenum meins FROM lqua
                                                       INTO TABLE it_lqua
                                                       FOR ALL ENTRIES IN it_linp
                                                       WHERE lgpla = it_linp-lgpla
                                                       AND lgnum = p_lgnum and matnr = p_matnr.
        else.
    SELECT lgnum lqnum matnr werks charg lgtyp lgpla verme lgort lenum meins FROM lqua
                                                       INTO Table it_lqua
                                                       FOR ALL ENTRIES IN it_linp
                                                       WHERE lgpla = it_linp-lgpla
                                                       AND lgnum = p_lgnum.
      endif.
    IF sy-subrc = 0 AND it_lqua IS NOT INITIAL.
      flag = 1.
      SORT it_lqua.
      DATA(it_lqua_temp) = it_lqua.
      DELETE ADJACENT DUPLICATES FROM it_lqua_temp COMPARING matnr.
      SELECT matnr, spras, maktx FROM makt INTO TABLE @data(it_makt)
                                                       FOR ALL ENTRIES IN @it_lqua_temp
                                                       WHERE matnr = @it_lqua_temp-matnr
                                                       AND spras = @sy-langu.
    ENDIF.
  ENDIF.

*fill the final table
if flag = 1.
  LOOP AT it_lqua ASSIGNING FIELD-SYMBOL(<fs_lqua>).
    no = no + 1.
    APPEND INITIAL LINE TO it_final ASSIGNING FIELD-SYMBOL(<fs_final>).
    IF <fs_lqua> IS ASSIGNED.
      <fs_final>-serial_no = no.
      <fs_final>-lgnum = <fs_lqua>-lgnum.
      <fs_final>-lqnum = <fs_lqua>-lqnum.
      <fs_final>-matnr = <fs_lqua>-matnr.
      <fs_final>-werks = <fs_lqua>-werks.
      <fs_final>-charg = <fs_lqua>-charg.
      <fs_final>-lgtyp = <fs_lqua>-lgtyp.
      <fs_final>-lgpla = <fs_lqua>-lgpla.
      <fs_final>-verme = <fs_lqua>-verme.
      <fs_final>-lgort = <fs_lqua>-lgort.
      <fs_final>-lenum = <fs_lqua>-lenum.
      <fs_final>-meins = <fs_lqua>-meins.
*unassign <fs_makt>.
      READ TABLE it_makt ASSIGNING FIELD-SYMBOL(<fs_makt>) WITH KEY matnr = <fs_lqua>-matnr.
      IF <fs_makt> IS ASSIGNED.
        <fs_final>-maktx = <fs_makt>-maktx.
      ENDIF.
      READ TABLE it_linp ASSIGNING FIELD-SYMBOL(<fs_linp>) WITH KEY lgnum = <fs_lqua>-lgnum.
      IF <fs_lqua> IS ASSIGNED.
        <fs_final>-ivnum = <fs_linp>-ivnum.
      ENDIF.
    ENDIF.
  ENDLOOP.

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
      formname           = 'ZPHYSICAL_INVENTORY'
    IMPORTING
      fm_name            = v_fm_name
    EXCEPTIONS
      no_form            = 1
      no_function_module = 2
      OTHERS             = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
  CALL FUNCTION v_fm_name                             "'/1BCDWB/SF00000290'
* EXPORTING
*   ARCHIVE_INDEX              =
*   ARCHIVE_INDEX_TAB          =
*   ARCHIVE_PARAMETERS         =
*   CONTROL_PARAMETERS         =
*   MAIL_APPL_OBJ              =
*   MAIL_RECIPIENT             =
*   MAIL_SENDER                =
*   OUTPUT_OPTIONS             =
*   USER_SETTINGS              = 'X'
    TABLES
      it_final         = it_final
    EXCEPTIONS
      formatting_error = 1
      internal_error   = 2
      send_error       = 3
      user_canceled    = 4
      OTHERS           = 5.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.
  flag = 0.
  ENDIF.
