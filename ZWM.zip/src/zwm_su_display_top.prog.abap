*************************************************************************************
*Object Name              : ZWM_SU_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 05/04/2019.
*************************************************************************************
*Description              : include for top FOR SU DISPLAY.
*************************************************************************************
*********************************************************
*structure definition of lqua.
*********************************************************

TYPES : BEGIN OF ty_lqua,
          lgnum TYPE lgnum,
          lqnum TYPE lvs_lqnum,
          matnr TYPE matnr,
          werks TYPE werks_d,
          charg TYPE charg_d,
          bestq TYPE bestq,
          lgpla TYPE lgpla,
          meins TYPE meins,
          verme TYPE lqua_verme,
          lenum TYPE lenum,
        END OF ty_lqua.
*********************************************************
*structure definition of makt.
*********************************************************
TYPES : BEGIN OF ty_makt,
          matnr TYPE matnr,
          spras TYPE spras,
          maktx TYPE maktx,
        END OF ty_makt.
*********************************************************
*structure definition of mchl.
*********************************************************
TYPES : BEGIN OF ty_mch1,
          matnr TYPE matnr,
          charg TYPE charg_d,
          vfdat TYPE vfdat,
          hsdat TYPE hsdat,
        END OF ty_mch1.
*********************************************************
*Global Data Declaration
*********************************************************
DATA : wa_lqua1 TYPE ty_lqua,
       wa_makt  TYPE ty_makt,
       wa_mch1  TYPE ty_mch1,
       v_vfdat  TYPE char10,
       v_hsdat  TYPE char10,
       v_verme  TYPE int4,
       v1_verme TYPE string.

DATA ok_code TYPE sy-ucomm.
DATA v_lenum TYPE lenum.
DATA v_matnr TYPE matnr.
DATA flag_enter TYPE c VALUE 0.
DATA: p_lenum TYPE char25.
