*break-point.
*zqty = wa_final-vsolm.
*CONCATENATE gv_space wa_final-matnr into gv_string.
*gv_frac = wa_final-vsolm MOD 1.
 gv_frac = wa_final-vsolm.
  shift gv_frac LEFT up to '.'.
  shift gv_frac LEFT by 1 places.
gv_whole = wa_final-vsolm DIV 1.
CONCATENATE gv_whole gv_frac into number SEPARATED BY '.' .















