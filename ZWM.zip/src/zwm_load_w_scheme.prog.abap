*&---------------------------------------------------------------------*
*& Report  ZWM_LOAD_W_SCHEME
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zwm_load_w_scheme.

INCLUDE zwm_load_w_scheme_top.
INCLUDE zwm_load_w_scheme_8o01.
INCLUDE zwm_load_w_scheme_status_8o02.
INCLUDE zwm_load_w_scheme_status_8o04.
INCLUDE zwm_load_w_scheme_status_8o05.
INCLUDE zwm_load_w_scheme_status_8110.

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8000 INPUT.
  CASE sy-ucomm.
    WHEN 'LOAD1'.
      CALL SCREEN 8001.
  ENDCASE.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8000 OUTPUT.
  SET PF-STATUS 'ZMM_8000'.
  LOOP AT SCREEN.
    IF screen-name = 'UNLOAD'.
      screen-invisible = '1'.
      MODIFY SCREEN.
      EXIT.
    ENDIF.
  ENDLOOP.
  lwr_status-sign = 'I'.
  lwr_status-option = 'EQ'.
  lwr_status-low = '0010'.
  APPEND lwr_status TO lr_status.
  lwr_status-low = '0050'.
  APPEND lwr_status TO lr_status.
  lwr_status-low = '0060'.
  APPEND lwr_status TO lr_status.
*  SET TITLEBAR 'xxx'.
ENDMODULE.
