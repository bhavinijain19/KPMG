*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZWM_UID_PLANT...................................*
DATA:  BEGIN OF STATUS_ZWM_UID_PLANT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZWM_UID_PLANT                 .
CONTROLS: TCTRL_ZWM_UID_PLANT
            TYPE TABLEVIEW USING SCREEN '9002'.
*.........table declarations:.................................*
TABLES: *ZWM_UID_PLANT                 .
TABLES: ZWM_UID_PLANT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
