*************************************************************************************
*Object Name              : ZWM_Pickup_LIST
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : Selection Screen declaration include.
*************************************************************************************

selection-SCREEN  BEGIN OF BLOCK a WITH FRAME TITLE text-001.

   parameters p_lgnum type lgnum OBLIGATORY MATCHCODE OBJECT H_T300.
   select-OPTIONS : s_tbnum FOR v_tbnum OBLIGATORY.
   parameters p_bdatu type LTBK_BDATU OBLIGATORY.

selection-SCREEN END OF BLOCK a.
