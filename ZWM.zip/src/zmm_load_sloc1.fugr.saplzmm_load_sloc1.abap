*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_LOAD_SLOC1TOP.                " Global Declarations
  INCLUDE LZMM_LOAD_SLOC1UXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_LOAD_SLOC1F...                " Subroutines
* INCLUDE LZMM_LOAD_SLOC1O...                " PBO-Modules
* INCLUDE LZMM_LOAD_SLOC1I...                " PAI-Modules
* INCLUDE LZMM_LOAD_SLOC1E...                " Events
* INCLUDE LZMM_LOAD_SLOC1P...                " Local class implement.
* INCLUDE LZMM_LOAD_SLOC1T99.                " ABAP Unit tests
  INCLUDE LZMM_LOAD_SLOC1F00                      . " subprograms
  INCLUDE LZMM_LOAD_SLOC1I00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
