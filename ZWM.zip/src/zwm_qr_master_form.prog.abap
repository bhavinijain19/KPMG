*&---------------------------------------------------------------------*
*& Include          ZWM_SU_UPLOAD_FORM
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form download_template
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM download_template.
  DATA: lv_filename  TYPE string,
        lt_file_data TYPE TABLE OF string,
        lv_header    TYPE string,
        lv_fname     TYPE string,
        lv_path      TYPE string,
        lv_fpath     TYPE string,
        lv_action    TYPE i.

  " Add your specific field list here
  DATA(lv_tab) = cl_abap_char_utilities=>horizontal_tab.


  lv_header = |Count{ lv_tab }Inward Master Box No{ lv_tab }QR Code No{ lv_tab }Material Number{ lv_tab }| &&
             |Created Date{ lv_tab }Created Time{ lv_tab }Created By{ lv_tab }Quantity{ lv_tab }| &&
             |Scan Status{ lv_tab }Cancel/Delete Status{ lv_tab }Last Changed Date{ lv_tab }Last Changed Time{ lv_tab }| &&
             |Last Changed By{ lv_tab }Deleted Date{ lv_tab }Deleted Time{ lv_tab }Deleted By{ lv_tab }| &&
             |MRP Value{ lv_tab }MRP Value 2{ lv_tab }UOM{ lv_tab }Count|.

  APPEND lv_header TO lt_file_data.

  " Open Save Dialog
  lv_filename = |Upload_ZSD_QR_MASTER_{ sy-datum }_{ sy-uzeit }|.
  DATA: lv_mask TYPE string VALUE 'xlsx file (*.xlsx)|*.xlsx'.
  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'Save Template As'
      default_extension = 'xlsx'
      default_file_name = lv_filename  " Sets 'BP_Template' as the default
      initial_directory = 'C:\'
      file_filter       = lv_mask
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fpath
      user_action       = lv_action.

  CHECK lv_action = cl_gui_frontend_services=>action_ok.

*  " Download Header only (empty data table)
*  CALL FUNCTION 'GUI_DOWNLOAD'
*    EXPORTING
*      filename              = lv_fpath
*      filetype              = 'DAT'
*      write_field_separator = 'X' " Ensures Excel columns align
*    TABLES
*      data_tab              = lt_file_data.

  DATA: lv_length     TYPE i,
        lt_xml_stream TYPE xml_rawdata,
        lv_xml        TYPE xstring.
  DATA: lt_file TYPE TABLE OF zsd_qr_master.

  "lv_filename = |{ gv_path }{ gv_filename }|.
  TRY.
      cl_salv_table=>factory(
        IMPORTING
          r_salv_table = DATA(lo_alv)
        CHANGING
          t_table      = lt_file ).

      DATA(lo_columns) = lo_alv->get_columns( ).

*      TRY.
*          lo_columns->get_column( 'MANDT' )->set_visible( abap_false ).
*        CATCH cx_salv_not_found.
*          " Column not present – do nothing
*      ENDTRY.


      LOOP AT lo_columns->get( ) ASSIGNING FIELD-SYMBOL(<c>).
        DATA(lo_col) = <c>-r_column.
        DATA(lv_field) = lo_col->get_columnname( ).

        " Clear default texts
        lo_col->set_short_text( '' ).
        lo_col->set_medium_text( '' ).

        CASE lv_field.

          WHEN 'ZCOUNT'.
            lo_col->set_long_text( 'Count' ).

          WHEN 'ZBOXQR'.
            lo_col->set_long_text( 'Inward Master Box No' ).

          WHEN 'QRNUM'.
            lo_col->set_long_text( 'QR Code No' ).

          WHEN 'MATNR'.
            lo_col->set_long_text( 'Material Number' ).

          WHEN 'DATES'.
            lo_col->set_long_text( 'Created Date' ).

          WHEN 'TIMES'.
            lo_col->set_long_text( 'Created Time' ).

          WHEN 'USERS'.
            lo_col->set_long_text( 'Created By' ).

          WHEN 'QTY'.
            lo_col->set_long_text( 'Quantity' ).

          WHEN 'SCAN'.
            lo_col->set_long_text( 'Scan Status' ).

          WHEN 'CANCEL'.
            lo_col->set_long_text( 'Cancel/Delete Status' ).

          WHEN 'CDATES'.
            lo_col->set_long_text( 'Last Changed Date' ).

          WHEN 'CTIMES'.
            lo_col->set_long_text( 'Last Changed Time' ).

          WHEN 'CUSERS'.
            lo_col->set_long_text( 'Last Changed By' ).

          WHEN 'DDATES'.
            lo_col->set_long_text( 'Deleted Date' ).

          WHEN 'DTIMES'.
            lo_col->set_long_text( 'Deleted Time' ).

          WHEN 'DUSERS'.
            lo_col->set_long_text( 'Deleted By' ).

          WHEN 'ZMRP1'.
            lo_col->set_long_text( 'MRP Value' ).

          WHEN 'ZMRP2'.
            lo_col->set_long_text( 'MRP Value 2' ).

          WHEN 'ZUOM'.
            lo_col->set_long_text( 'UOM' ).

          WHEN 'COUNTS'.
            lo_col->set_long_text( 'Count' ).

        ENDCASE.
      ENDLOOP.


      lo_alv->to_xml(
        EXPORTING
          xml_type = if_salv_bs_xml=>c_type_xlsx
        RECEIVING
          xml      = lv_xml ).

    CATCH cx_salv_error INTO DATA(lo_ex).
      DATA(lv_error) = lo_ex->get_text( ).
  ENDTRY.
  CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
    EXPORTING
      buffer        = lv_xml
    IMPORTING
      output_length = lv_length
    TABLES
      binary_tab    = lt_xml_stream.

  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      bin_filesize            = lv_length
      filetype                = 'BIN'
      filename                = lv_filename
    CHANGING
      data_tab                = lt_xml_stream
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc IS NOT INITIAL.

  ENDIF.

ENDFORM.
FORM validations .
  IF p_flname IS INITIAL.
    MESSAGE 'FILE NAME' TYPE 'S'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form UPLOAD_EXCEL
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM upload_excel.
  DATA: lv_fname   TYPE string.

  lv_fname = p_flname.

  CALL FUNCTION 'GUI_UPLOAD'
    EXPORTING
      filename                = lv_fname
      filetype                = 'BIN'
    IMPORTING
      filelength              = gv_bin_len
    TABLES
      data_tab                = gt_raw
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.

  PERFORM convert_data.
ENDFORM.
FORM convert_data .
  DATA: lv_xstring    TYPE xstring,
        lo_excel      TYPE REF TO cl_fdt_xl_spreadsheet,
        lv_docname    TYPE string,
        lt_worksheets TYPE STANDARD TABLE OF string,
        lv_worksheet  TYPE string,
        lv_lines      TYPE i,
        lo_data       TYPE REF TO data.

  FIELD-SYMBOLS: <lt_data_bin>  TYPE STANDARD TABLE,
                 <ls_data_bin>  TYPE any,
                 <lv_value_bin> TYPE any,
                 <lv_value>     TYPE any.

  CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
    EXPORTING
      input_length = gv_bin_len
    IMPORTING
      buffer       = lv_xstring
    TABLES
      binary_tab   = gt_raw
    EXCEPTIONS
      failed       = 1
      OTHERS       = 2.

  TRY.
      CREATE OBJECT lo_excel
        EXPORTING
          document_name = lv_docname
          xdocument     = lv_xstring.

      IF lo_excel IS NOT INITIAL.
        lo_excel->if_fdt_doc_spreadsheet~get_worksheet_names(
          IMPORTING
            worksheet_names = lt_worksheets ).
      ENDIF.

      DESCRIBE TABLE lt_worksheets LINES lv_lines.

      IF lt_worksheets[] IS NOT INITIAL.
        READ TABLE lt_worksheets INTO lv_worksheet INDEX lv_lines.
        lo_data = lo_excel->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_worksheet ).
        ASSIGN lo_data->* TO <lt_data_bin>.
      ENDIF.

      IF <lt_data_bin> IS ASSIGNED.
        LOOP AT <lt_data_bin> ASSIGNING <ls_data_bin> FROM 2.
          CLEAR: wa_file.
          DO.
            ASSIGN COMPONENT sy-index OF STRUCTURE <ls_data_bin> TO <lv_value_bin>.
            IF sy-subrc EQ 0.
              lv_index = sy-index + 1.
              ASSIGN COMPONENT sy-index OF STRUCTURE wa_file TO <lv_value>.
              IF sy-subrc EQ 0.
*                IF lv_index = 16.
*                  SPLIT <lv_value_bin> AT '-' INTO DATA(lv_yyyy) DATA(lv_mm) DATA(lv_dd)  .
*                  DATA(lv_output) = lv_yyyy && lv_mm && lv_dd.
*                  <lv_value> = lv_output.
*                ELSE.
                <lv_value> = <lv_value_bin>.
*                ENDIF.
              ENDIF.
            ELSE.
              EXIT.
            ENDIF.
          ENDDO.
          IF wa_file IS NOT INITIAL.
            APPEND wa_file TO it_file.
          ENDIF.
        ENDLOOP.
      ENDIF.
    CATCH cx_fdt_excel_core.
      MESSAGE 'Excel processing error' TYPE 'E'.
  ENDTRY.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form create_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM create_data .
  IF it_file IS NOT INITIAL.
    MODIFY zsd_qr_MASTER FROM TABLE it_file.
    IF sy-subrc = 0.
      COMMIT WORK.
      " MESSAGE |{ sy-dbcnt } records updated in ZWM_SU successfully.| TYPE 'S'.
      gs_log-status  = 'S'.
      gs_log-message = | { sy-dbcnt } records updated in QR MASTER successfully.|.
    ELSE.
      ROLLBACK WORK.
      gs_log-status  = 'E'.
      gs_log-message = |Records updated in QR MASTER is not successfully.|.
    ENDIF.
    APPEND gs_log TO gt_log.
  ELSE.
    MESSAGE 'No data found in Excel file.' TYPE 'I'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form display_log
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM display_log .


  DATA lo_alv TYPE REF TO cl_salv_table.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_log ).

      " Functions, layout, stripe
      lo_alv->get_functions( )->set_all( abap_true ).

      lo_alv->get_display_settings( )->set_striped_pattern( abap_true ).
      lo_alv->get_columns( )->set_optimize( abap_true ).

      " Set nice headers
      DATA(lo_cols) = lo_alv->get_columns( ).

      lo_cols->get_column( 'STATUS' )->set_long_text( 'Status' ).
      lo_cols->get_column( 'MESSAGE' )->set_long_text( 'Message' ).

      lo_alv->display( ).

    CATCH cx_salv_msg INTO DATA(lx).
      MESSAGE lx->get_text( ) TYPE 'E'.
  ENDTRY.


ENDFORM.
