PROCESS BEFORE OUTPUT.

  MODULE status_8005.

  LOOP AT lt_8005 INTO lw_8005 CURSOR l_step_loop_pos.
    MODULE transp_itab_out_8005.
  ENDLOOP.

PROCESS AFTER INPUT.

  LOOP.
    MODULE transp_itab_in_8005.
  ENDLOOP.

  MODULE user_command_8005.
