*************************************************************************************
*Object Name              : ZWM_LOAD_DELETE.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 12/05/2019.
*************************************************************************************
*Description              : Report for Load No Deletion.
*************************************************************************************
REPORT ZWM_LOAD_DELETE.

include : ZWM_LOAD_DELETE_top,         "data declaration.
          ZWM_LOAD_DELETE_scr,         "include for screen declaration.
          ZWM_LOAD_DELETE_cls.         "include for class declaration and implementation.


*********************************************************
*initialization event.
*********************************************************
INITIALIZATION.

CREATE OBJECT obj.                     "creating object of class

*********************************************************
*at selection screen event.
*********************************************************
AT SELECTION-SCREEN.

obj->validation( ).                    "calling class method for validating input.


*********************************************************
*start of selection event.
*********************************************************
START-OF-SELECTION.

obj->fetch_data( ).                    "calling class method to getdata.
obj->display( ).                       "calling method for displaying data.
