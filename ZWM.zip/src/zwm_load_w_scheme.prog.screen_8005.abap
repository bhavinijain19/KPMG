PROCESS BEFORE OUTPUT.

  MODULE status_8005.

  LOOP.
    MODULE transp_itab_out_8005.
  ENDLOOP.

PROCESS AFTER INPUT.

  LOOP.
    MODULE transp_itab_in_8005.
  ENDLOOP.

  MODULE user_command_8005.
