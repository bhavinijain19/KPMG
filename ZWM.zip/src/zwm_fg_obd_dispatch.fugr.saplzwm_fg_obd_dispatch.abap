*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_FG_OBD_DISPATCHTOP.           " Global Data
  INCLUDE LZWM_FG_OBD_DISPATCHUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_FG_OBD_DISPATCHF...           " Subroutines
* INCLUDE LZWM_FG_OBD_DISPATCHO...           " PBO-Modules
* INCLUDE LZWM_FG_OBD_DISPATCHI...           " PAI-Modules
* INCLUDE LZWM_FG_OBD_DISPATCHE...           " Events
* INCLUDE LZWM_FG_OBD_DISPATCHP...           " Local class implement.
* INCLUDE LZWM_FG_OBD_DISPATCHT99.           " ABAP Unit tests
