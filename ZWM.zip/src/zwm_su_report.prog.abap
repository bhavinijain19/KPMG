*&---------------------------------------------------------------------*
*& Report  ZWM_SU_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zwm_su_report.
TABLES: zwm_su.

TYPES: BEGIN OF ty_su,
         index    TYPE i,
         matnr    TYPE zwm_su-matnr,
         maktx    TYPE makt-maktx,
         charg    TYPE zwm_su-charg,
         su_qty   TYPE zwm_su-su_qty,
         werks    TYPE zwm_su-werks,
         aufnr    TYPE zwm_su-aufnr,
         palletno TYPE zwm_su-palletno,
         lenum    TYPE zwm_su-lenum,
         su_from  TYPE zwm_su-lenum,
         su_to    TYPE zwm_su-lenum,
******  Added by khushbu parmar on 16.10.2024
         rueck    TYPE co_rueck, "Completion confirmation number for the operation
         gmnga    TYPE ru_gmnga,  "Previously confirmed yield in order unit of measure
         prueflos TYPE qplos,   "Inspection Lot Number
         losmenge TYPE qlosmenge,  "Inspection Lot Quantity
         del_flg  TYPE string, "Deletion flag
         lgort    TYPE lqua-lgort,
         LGPLA    TYPE lqua-LGPLA,
         budat    TYPE afru-budat,
         "Changes Completed
       END OF ty_su.

DATA: gt_pallet TYPE TABLE OF ty_su,
      gs_pallet TYPE ty_su,
      lt_su     TYPE TABLE OF zwm_su,
      ls_su     TYPE zwm_su,
      gt_fcat   TYPE slis_t_fieldcat_alv,
      gs_fcat   TYPE slis_fieldcat_alv,
      gs_layout TYPE slis_layout_alv,
      gv_flag   TYPE c,
      gv_qty    TYPE zwm_su-pal_qty,
      su_index  TYPE i,
      lv_index  TYPE i.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS: s_aufnr FOR zwm_su-aufnr,
                s_matnr FOR zwm_su-matnr,
                s_charg FOR zwm_su-charg,
                s_lenum FOR zwm_su-lenum,
                s_werks FOR zwm_su-werks,
                s_palno FOR zwm_su-palletno.

SELECTION-SCREEN END OF BLOCK b1.

START-OF-SELECTION.
  PERFORM get_data.
  PERFORM fill_cat.
  PERFORM display_data.

FORM get_data.
  SELECT *
    FROM zwm_su
    WHERE aufnr IN @s_aufnr
      AND matnr IN @s_matnr
      AND charg IN @s_charg
      AND lenum IN @s_lenum
      AND werks IN @s_werks
      AND palletno IN @s_palno
    INTO TABLE @lt_su.
  IF lt_su IS NOT INITIAL.
    SELECT matnr, maktx FROM makt
      FOR ALL ENTRIES IN @lt_su
      WHERE matnr = @lt_su-matnr
      INTO TABLE @DATA(lt_makt).
  ELSE.
    MESSAGE 'Please check input' TYPE 'E'.
  ENDIF.

****Added by Khushbu Parmar on 10.16.2024
  IF lt_su IS NOT INITIAL.
    SELECT aufnr,
           rueck,
           gmnga,
           budat
      FROM afru
      INTO TABLE @DATA(gt_afru)
      FOR ALL ENTRIES IN @lt_su
      WHERE aufnr EQ @lt_su-aufnr.
*      %_HINTS ORACLE 'INDEX("AFRU" "AFRU~ZAU")' .


    SELECT aufnr,
           prueflos,
           losmenge
      FROM  qals
      INTO TABLE @DATA(gt_qals)
      FOR ALL ENTRIES IN @lt_su
      WHERE aufnr EQ @lt_su-aufnr.


    SELECT aufnr,
         del_flg
      FROM zwm_su
      INTO TABLE @DATA(gt_zwm_su)
      FOR ALL ENTRIES IN @lt_su
      WHERE aufnr EQ @lt_su-aufnr.

    SELECT lenum,
           lgort,
           lgpla
      FROM lqua
      INTO TABLE @DATA(gt_lqua)
      FOR ALL ENTRIES IN @lt_su
      WHERE lgnum = @lt_su-lgnum
       and  matnr = @lt_su-matnr
       and  charg = @lt_su-charg
      and lenum = @lt_su-lenum.
  ENDIF.
****************Changes Completed
  LOOP AT lt_su INTO ls_su.
    MOVE-CORRESPONDING ls_su TO gs_pallet.

****************Added by Khushbu Parmar on 16.10.2024
    READ TABLE gt_afru INTO DATA(gs_afru) WITH KEY aufnr = ls_su-aufnr.
    IF sy-subrc EQ 0.
      gs_pallet-rueck = gs_afru-rueck.
      gs_pallet-gmnga = gs_afru-gmnga.
      gs_pallet-budat = gs_afru-budat.
    ENDIF.

    READ TABLE gt_qals INTO DATA(gs_qals) WITH KEY aufnr = ls_su-aufnr.
    IF sy-subrc EQ 0.
      gs_pallet-prueflos = gs_qals-prueflos.
      gs_pallet-losmenge = gs_qals-losmenge.
    ENDIF.

    READ TABLE gt_zwm_su INTO DATA(gs_zwm_su) WITH KEY aufnr = ls_su-aufnr.
    IF sy-subrc EQ 0.
      gs_pallet-del_flg = gs_zwm_su-del_flg .
    ENDIF.

    READ TABLE gt_lqua INTO DATA(gs_lqua) WITH KEY lenum = ls_su-lenum.
    IF sy-subrc = 0.
      gs_pallet-lgort = gs_lqua-lgort.
      gs_pallet-LGPLA = gs_lqua-LGPLA.
    ENDIF.
**************Changes Completed
    APPEND gs_pallet TO gt_pallet.
    CLEAR gs_pallet.
  ENDLOOP.

  DATA(gt_pallet_tmp) = gt_pallet.
  REFRESH:gt_pallet.
  SORT gt_pallet_tmp BY palletno lenum.
  LOOP AT gt_pallet_tmp INTO DATA(ls).
    READ TABLE lt_makt INTO DATA(ls_makt) WITH KEY matnr = ls-matnr.
    gs_pallet = ls.
    gs_pallet-maktx = ls_makt-maktx.
    IF gv_flag EQ abap_false.
      DATA(su_from) = ls-lenum.
    ENDIF.
    gv_flag = abap_true.
    gv_qty  = gv_qty + 1.
    AT END OF palletno.
      su_index = su_index + 1.
      gs_pallet-index = su_index.
      gs_pallet-su_qty = gs_pallet-su_qty * gv_qty.
      gs_pallet-su_from = su_from.
      gs_pallet-su_to = gs_pallet-lenum.
      APPEND gs_pallet TO gt_pallet.
      CLEAR: gv_flag, gv_qty, gs_pallet.
    ENDAT.
  ENDLOOP.

ENDFORM.

FORM fill_cat.
  PERFORM fill_fcat USING 'index    ' 'GT_PALLET' 'Sr. No.'.
  PERFORM fill_fcat USING 'matnr    ' 'GT_PALLET' 'Material Code'.
  PERFORM fill_fcat USING 'maktx    ' 'GT_PALLET' 'Description'.
  PERFORM fill_fcat USING 'charg    ' 'GT_PALLET' 'Batch No'.
  PERFORM fill_fcat USING 'su_qty   ' 'GT_PALLET' 'Qty'.
  PERFORM fill_fcat USING 'werks    ' 'GT_PALLET' 'Plant'.
  PERFORM fill_fcat USING 'aufnr    ' 'GT_PALLET' 'Prod. Order No'.
  PERFORM fill_fcat USING 'budat  ' 'GT_PALLET' 'Prod Order Date'.
  PERFORM fill_fcat USING 'palletno ' 'GT_PALLET' 'Pallet No'.
  PERFORM fill_fcat USING 'su_from  ' 'GT_PALLET' 'SU From'.
  PERFORM fill_fcat USING 'su_to    ' 'GT_PALLET' 'SU To'.
  PERFORM fill_fcat USING 'rueck    ' 'GT_PALLET' 'Confirmation'.
  PERFORM fill_fcat USING 'gmnga    ' 'GT_PALLET' 'Yield confirmed'.
  PERFORM fill_fcat USING 'prueflos ' 'GT_PALLET' 'Insp. Lot'.
  PERFORM fill_fcat USING 'losmenge ' 'GT_PALLET' 'Insp. Lot Qty'.
  PERFORM fill_fcat USING 'del_flg  ' 'GT_PALLET' 'Deletion Flag'.
  PERFORM fill_fcat USING 'lgort  ' 'GT_PALLET' 'Storage Location'.
  PERFORM fill_fcat USING 'lgpla  ' 'GT_PALLET' 'Bin Location'.




ENDFORM.

FORM fill_fcat USING VALUE(fieldname)
                     VALUE(tabname)
                     VALUE(seltext).
  lv_index = lv_index + 1.
  gs_fcat-col_pos = lv_index.
  gs_fcat-fieldname = fieldname.
  gs_fcat-seltext_m = seltext.
  gs_fcat-tabname = tabname.
  APPEND gs_fcat TO gt_fcat.
  CLEAR gs_fcat.
  .

ENDFORM.

FORM display_data.
  gs_layout-colwidth_optimize = 'X'.
  gs_layout-zebra = 'X'.
  IF gt_pallet IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program = sy-cprog
*       i_callback_pf_status_set = 'PF_STATUS_SET'
*       i_callback_user_command  = 'USER_COMMAND'
*       i_callback_top_of_page   = 'TOP_OF_PAGE'
        is_layout          = gs_layout
        it_fieldcat        = gt_fcat
      TABLES
        t_outtab           = gt_pallet
      EXCEPTIONS
        program_error      = 1
        OTHERS             = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

  ENDIF.
ENDFORM.
