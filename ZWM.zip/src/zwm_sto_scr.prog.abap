*************************************************************************************
*Object Name              : ZWM_STO.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 24/03/2019.
*************************************************************************************
*Description              : Selection Screen declaration include.
*************************************************************************************

*********************************************************
*selection screen declaration.
*********************************************************
SELECTION-SCREEN BEGIN OF BLOCK a WITH FRAME TITLE text-001.

PARAMETERS : p_matdoc TYPE   mblnr    OBLIGATORY,
             p_year   TYPE   mjahr    OBLIGATORY,
             p_tr     TYPE   tbnum,
             p_out    TYPE   vbeln_vl OBLIGATORY.

SELECTION-SCREEN END OF BLOCK a.


*********************************************************
*at selection screen output event.
*********************************************************

AT SELECTION-SCREEN OUTPUT.

set HOLD DATA OFF.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*  SELECT SINGLE tbnum,
*                mblnr,                                         "for getting TR on enter command
*                mjahr
*  FROM ltbk
*  INTO @DATA(wa_ltbk)
*  WHERE mblnr EQ @p_matdoc
*  AND mjahr EQ @p_year.

SELECT TBNUM ,
 MBLNR , MJAHR FROM LTBK INTO @DATA(WA_LTBK) UP TO 1 ROWS WHERE MBLNR EQ @P_MATDOC AND MJAHR EQ @P_YEAR
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


  p_tr = wa_ltbk-tbnum.

  LOOP AT SCREEN.                                              "for making TR parameter field uneditable.
    IF screen-name = 'P_TR'.
      screen-input = 0.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.
