*&---------------------------------------------------------------------*
*& Report  ZWM_MAPPING_UPDATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zwm_mapping_update.

TYPES: BEGIN OF ty_su,
         plant        TYPE werks_d,
         pallet_no    TYPE char18,
         su_no        TYPE lenum,
         warehouse_no TYPE lgnum,
       END OF ty_su.

TYPES: BEGIN OF ty_su_consumed,
         su_no TYPE lenum,
         plant TYPE werks_d,
       END OF ty_su_consumed.


DATA: lt_su_upd TYPE TABLE OF zwm_pallet_map.
DATA: it_return TYPE TABLE OF ddshretval.
DATA: lt_plant TYPE TABLE OF zwm_plant_config.

DATA: lv_plant TYPE zwm_plant_config-plant.
DATA: lv_date TYPE zwm_su-bdatu.

DATA: lv_bj_max_count TYPE zwm_de_config_value,
      lv_flag         TYPE zwm_de_config_value,
      lv_lines        TYPE i,
      lv_loop         TYPE i,
      lv_mod          TYPE i,
      lv_line_from    TYPE i,
      lv_line_to      TYPE i.

DATA: lt_su_sub       TYPE TABLE OF ty_su,
      lt_su_consumed  TYPE TABLE OF ty_su_consumed,
      lt_su_consumed1 TYPE TABLE OF ty_su_consumed,
      lt_su_consumed2 TYPE TABLE OF ty_su_consumed.

SELECTION-SCREEN BEGIN OF BLOCK b1.
SELECT-OPTIONS: s_plant FOR lv_plant NO INTERVALS.
SELECT-OPTIONS: s_date FOR lv_date.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_plant-low.

  SELECT plant FROM zwm_plant_config INTO TABLE @DATA(lt_plant_dd).
  IF sy-subrc = 0.
    SORT lt_plant_dd.
  ENDIF.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'PLANT'
      value_org       = 'S'
    TABLES
      value_tab       = lt_plant_dd
      return_tab      = it_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.

  LOOP AT it_return ASSIGNING FIELD-SYMBOL(<lw_ret>).
    s_plant = <lw_ret>-fieldval.
  ENDLOOP.



START-OF-SELECTION.

  SELECT SINGLE value FROM zwm_gen_config INTO lv_flag WHERE name = 'ZWM_LOAD_F'.

  SELECT SINGLE value FROM zwm_gen_config INTO lv_bj_max_count WHERE name = 'ZWM_BJ_MAX'.
  IF sy-subrc NE 0.
    lv_bj_max_count = 5000.
  ENDIF.

  IF s_plant IS NOT INITIAL.
    SELECT * FROM zwm_plant_config INTO TABLE lt_plant WHERE plant IN s_plant.
  ELSE.
    SELECT * FROM zwm_plant_config INTO TABLE lt_plant.
  ENDIF.

  IF lt_plant[] IS NOT INITIAL.
    SELECT werks AS plant,
           palletno AS pallet_no,
           lenum AS su_no,
           lgnum AS warehouse_no
      FROM zwm_su
      FOR ALL ENTRIES IN @lt_plant
        WHERE werks = @lt_plant-plant
          AND palletno NE ''
          AND bdatu IN @s_date
      INTO TABLE @DATA(lt_su).

    IF lt_su[] IS NOT INITIAL.
      SELECT pallet_no,
             su_no
        FROM zwm_pallet_map
*        FOR ALL ENTRIES IN @lt_su
*          WHERE pallet_no = @lt_su-pallet_no
*            AND su_no = @lt_su-su_no
        INTO TABLE @DATA(lt_pallet_map).

      IF lt_pallet_map[] IS NOT INITIAL.
        LOOP AT lt_pallet_map INTO DATA(ls_pallet_map).
          DELETE lt_su WHERE pallet_no = ls_pallet_map-pallet_no
                          AND su_no = ls_pallet_map-su_no.
        ENDLOOP.
      ENDIF.
    ENDIF.

    IF lt_su[] IS NOT INITIAL.
      SELECT lenum FROM lein INTO TABLE @DATA(lt_lein) FOR ALL ENTRIES IN @lt_su
              WHERE lenum = @lt_su-su_no.
      IF sy-subrc EQ 0.
        LOOP AT lt_su INTO DATA(ls_su).
          READ TABLE lt_lein TRANSPORTING NO FIELDS WITH KEY lenum = ls_su-su_no.
          IF sy-subrc NE 0.
            DELETE lt_su WHERE su_no = ls_su-su_no.
          ENDIF.
          CLEAR: ls_su.
        ENDLOOP.
      ENDIF.
    ENDIF.

    IF lt_su[] IS NOT INITIAL AND lv_flag IS INITIAL.
      DESCRIBE TABLE lt_su LINES lv_lines.

      lv_loop = lv_lines DIV lv_bj_max_count.
      lv_mod = lv_lines MOD lv_bj_max_count.
      IF lv_mod > 0.
        lv_loop = lv_loop + 1.
      ENDIF.
      lv_line_from = 1.
      IF lv_lines < lv_bj_max_count.
        lv_line_to = lv_lines.
      ELSE.
        lv_line_to = lv_bj_max_count.
      ENDIF.

      DO lv_loop TIMES.
        CLEAR: lt_su_sub.
        APPEND LINES OF lt_su FROM lv_line_from TO lv_line_to TO lt_su_sub.
        IF lt_su_sub IS NOT INITIAL.

          SELECT su_no
                 plant
            FROM zmm_load_sloc1
            INTO CORRESPONDING FIELDS OF TABLE lt_su_consumed1
            FOR ALL ENTRIES IN lt_su_sub
              WHERE su_no = lt_su_sub-su_no
                AND plant = lt_su_sub-plant.
          IF sy-subrc = 0.
*            APPEND LINES OF lt_su_consumed1 TO lt_su_consumed.
            LOOP AT lt_su_consumed1 INTO DATA(ls_su_consumed1).
              DELETE lt_su_sub WHERE plant = ls_su_consumed1-plant
                                 AND su_no = ls_su_consumed1-su_no.
            ENDLOOP.
            CLEAR: lt_su_consumed1.
          ENDIF.

          SELECT su_no
                 plant
            FROM zmm_load_sloc2
            INTO CORRESPONDING FIELDS OF TABLE lt_su_consumed2
            FOR ALL ENTRIES IN lt_su_sub
              WHERE su_no = lt_su_sub-su_no
                AND plant = lt_su_sub-plant.
          IF sy-subrc = 0.
*            APPEND LINES OF lt_su_consumed2 TO lt_su_consumed.
            LOOP AT lt_su_consumed2 INTO DATA(ls_su_consumed2).
              DELETE lt_su_sub WHERE plant = ls_su_consumed2-plant
                                 AND su_no = ls_su_consumed2-su_no.
            ENDLOOP.
            CLEAR: lt_su_consumed2.
          ENDIF.
        ENDIF.

        IF lt_su_sub[] IS NOT INITIAL.
          lt_su_upd = VALUE #( FOR ls_su_upd IN lt_su_sub
                                ( warehouse_type = 'Plant'
                                  warehouse_no   = ls_su_upd-warehouse_no
                                  pallet_no      = ls_su_upd-pallet_no
                                  su_no          = ls_su_upd-su_no )
                              ).
        ENDIF.

        IF lt_su_upd[] IS NOT INITIAL.
          MODIFY zwm_pallet_map  FROM TABLE lt_su_upd.

          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.

          CLEAR: lt_su_upd.
        ENDIF.

        lv_line_from = lv_line_to + 1.
        lv_line_to = lv_line_to + lv_bj_max_count.
        IF lv_line_to > lv_lines.
          lv_line_to = lv_lines.
        ENDIF.
      ENDDO.

*      IF lt_su_consumed[] IS NOT INITIAL.
*        LOOP AT lt_su_consumed INTO DATA(ls_su_consumed).
*          DELETE lt_su WHERE plant = ls_su_consumed-plant
*                          AND su_no = ls_su_consumed-su_no.
*        ENDLOOP.
*      ENDIF.
    ENDIF.

*    IF lt_su[] IS NOT INITIAL.
*      lt_su_upd = VALUE #( FOR ls_su_upd IN lt_su
*                            ( warehouse_type = 'Plant'
*                              warehouse_no   = ls_su_upd-warehouse_no
*                              pallet_no      = ls_su_upd-pallet_no
*                              su_no          = ls_su_upd-su_no )
*                          ).
*    ENDIF.
*
*    IF lt_su_upd[] IS NOT INITIAL.
*      MODIFY zwm_pallet_map  FROM TABLE lt_su_upd.
*      IF sy-subrc EQ 0 AND sy-batch IS INITIAL.
*        MESSAGE 'Mapping Updated successfully' TYPE 'S'.
*      ELSEIF sy-batch IS INITIAL.
*        MESSAGE 'Error in updation' TYPE 'E'.
*      ENDIF.
*    ELSEIF sy-batch IS INITIAL.
*      MESSAGE 'No record selected or Mapping updated already' TYPE 'S' DISPLAY LIKE 'W'.
*    ENDIF.
  ENDIF.
