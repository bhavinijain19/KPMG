FUNCTION-POOL ZMM_LOAD_SLOC1             MESSAGE-ID SV.

* INCLUDE LZMM_LOAD_SLOC1D...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_LOAD_SLOC1T00                      . "view rel. data dcl.
