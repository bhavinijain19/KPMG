*************************************************************************************
*Object Name              : ZWM_PUTAWAY_LIST
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 01/04/2019.
*************************************************************************************
*Description              : Data declaration include.
*************************************************************************************
CLASS lcl_putaway DEFINITION DEFERRED.

*********************************************************
*ltap structure declaration.
*********************************************************
TYPES : BEGIN OF ty_ltap,
          lgnum TYPE lgnum,
          tanum TYPE tanum,
          matnr TYPE matnr,
          charg TYPE charg_d,
          nlpla TYPE ltap_nlpla,
          tapos TYPE tapos,
          werks TYPE werks_d,
          meins TYPE meins,
          nlenr TYPE ltap_nlenr,
          nltyp TYPE ltap_nltyp,
        END OF ty_ltap.
*********************************************************
*makt structure declaration.
*********************************************************
TYPES :  BEGIN OF ty_makt,
           matnr TYPE matnr,
           spras TYPE spras,
           maktx TYPE maktx,
         END OF ty_makt.
*********************************************************
*ltak structure declaration.
*********************************************************
TYPES : BEGIN OF ty_ltak,
          lgnum TYPE lgnum,
          tanum TYPE tanum,
          trart TYPE lvs_trart,
          bdatu TYPE ltak_bdatu,
          kquit TYPE ltak_kquit,
        END OF ty_ltak.
*********************************************************
* structure declaration for F4 on tanum
*********************************************************
TYPES: BEGIN OF ty_help,
           lgnum TYPE ltap-lgnum,
           tanum TYPE ltap-tanum,
         END OF ty_help.

DATA it_ltap TYPE STANDARD TABLE OF ty_ltap.                   "internal table declaration of ty_ltap
DATA it_makt TYPE STANDARD TABLE OF ty_makt.                   "internal table declaration of ty_makt
DATA it_final TYPE STANDARD TABLE OF zswm_putaway.             "internal table declaration of zswm_putaway.
DATA it_ltak TYPE STANDARD TABLE OF ty_ltak.                   "internal table declaration of ty_ltak.
DATA v_tanum TYPE tanum.
DATA obj     TYPE REF TO lcl_putaway.                               "creating reference of class object.
DATA gv_text TYPE char200.
DATA:it_ty_help TYPE TABLE OF ty_help,                       "variables for custom F4 on tanum.
     it_return  TYPE TABLE OF ddshretval,
     wa_ty_help TYPE ddshretval.
data :warehouse TYPE lgnum,
      desc      type LVS_LNUMT.


DATA var TYPE rs38l_fnam.                                       "variabler to store smartform FM name.
*********************************************************
*field symbols declaration.
*********************************************************
FIELD-SYMBOLS : <fs_ltap>  TYPE ty_ltap,
                <fs_final> TYPE zswm_putaway,
                <fs_makt>  TYPE ty_makt,
                <fs_ltak>  TYPE ty_ltak.
