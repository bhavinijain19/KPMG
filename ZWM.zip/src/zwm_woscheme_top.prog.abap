*&---------------------------------------------------------------------*
*& Include          ZWM_WOSCHEME_TOP
*&---------------------------------------------------------------------*
TABLES: zmm_load_sloc1.

TYPES: BEGIN OF lty_final,
         load_no        TYPE zmm_load_sloc1-load_no,
         load_item      TYPE zmm_load_sloc1-load_item,
         su_no          TYPE zmm_load_sloc1-su_no,
         obd_no         TYPE zmm_load_sloc1-obd_no,
         obd_lineitem   TYPE zmm_load_sloc1-obd_lineitem,
         obd_headitem   TYPE zmm_load_sloc1-obd_headitem,
         entry_date     TYPE zmm_load_sloc1-entry_date,
         storage_loc    TYPE zmm_load_sloc1-storage_loc,
         plant          TYPE zmm_load_sloc1-plant,
         matnr          TYPE zmm_load_sloc1-matnr,
         batch_no       TYPE zmm_load_sloc1-batch_no,
         quantity       TYPE zmm_load_sloc1-quantity,
         uom            TYPE zmm_load_sloc1-uom,
         bin_loc        TYPE zmm_load_sloc1-bin_loc,
         load_status    TYPE zmm_load_sloc1-load_status,
         su_qty         TYPE zmm_load_sloc1-su_qty,
         to_create_date TYPE zmm_load_sloc1-to_create_date,
         to_no          TYPE zmm_load_sloc1-to_no,
         err_msg        TYPE zmm_load_sloc1-err_msg,
         maktx          TYPE makt-maktx,
       END OF lty_final.

DATA: lt_final  TYPE TABLE OF lty_final,
      lwa_final TYPE lty_final.

TYPE-POOLS: slis.

DATA: lt_fcat TYPE slis_t_fieldcat_alv,
      ls_fcat TYPE slis_fieldcat_alv.
