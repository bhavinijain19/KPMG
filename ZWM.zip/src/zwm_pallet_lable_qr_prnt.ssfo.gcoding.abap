*CLEAR: lv_qty.

SELECT SINGLE erdat FROM aufk INTO lv_date
  WHERE aufnr = lv_aufnr.























