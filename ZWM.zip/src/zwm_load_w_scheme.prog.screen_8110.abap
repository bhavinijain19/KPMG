PROCESS BEFORE OUTPUT.

  MODULE status_8110.

  LOOP.
    MODULE transp_itab_out_8110.
  ENDLOOP.

PROCESS AFTER INPUT.

  LOOP.
    MODULE transp_itab_in_8110.
  ENDLOOP.

  MODULE user_command_8110.
