*&---------------------------------------------------------------------*
*& Report  ZWM_LOAD_WO_SCHEME_N
*&
*&---------------------------------------------------------------------*
*& Dispatch process change for Load w/o scheme
*& Author: Srimathi
*& Date: 30.07.2024
*& TR: DEVK944530
*&---------------------------------------------------------------------*
*REPORT ZWM_LOAD_W_SCHEME_N.


INCLUDE ZWM_LOAD_W_SCHEME_N_TOP.
*INCLUDE zwm_load_wo_scheme_n_top                .    " global Data

INCLUDE ZWM_LOAD_W_SCHEME_N_FORM.
* INCLUDE ZWM_LOAD_WO_SCHEME_N_FORM                .  " FORM-Routines
INCLUDE ZWM_LOAD_W_SCHEME_N_PBO.
* INCLUDE ZWM_LOAD_WO_SCHEME_N_PBO                .  " PBO-Modules
INCLUDE ZWM_LOAD_W_SCHEME_N_PAI.
* INCLUDE ZWM_LOAD_WO_SCHEME_N_PAI                .  " PAI-Modules
