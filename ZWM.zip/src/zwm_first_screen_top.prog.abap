*&---------------------------------------------------------------------*
*&  Include           ZWM_FIRST_SCREEN_TOP
*&---------------------------------------------------------------------*

TYPES: BEGIN OF ty_url,
         name(80),
         url      TYPE string,
       END   OF ty_url.

DATA gs_url TYPE TABLE OF ty_url WITH HEADER LINE.

DATA ok_code TYPE sy-ucomm.
