*************************************************************************************
*Object Name              : ZWM_LOAD_DELETE_SCR.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 12/05/2019.
*************************************************************************************
*Description              : Selection Screen declaration include.
*************************************************************************************

SELECTION-SCREEN BEGIN OF BLOCK a WITH FRAME TITLE TEXT-001.

PARAMETERS : p_load  TYPE ZLOAD_NO OBLIGATORY.

SELECTION-SCREEN END OF BLOCK a.
