*************************************************************************************
*Object Name              : ZWM_STO.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 24/03/2019.
*************************************************************************************
*Description              : Data declaration include.
*************************************************************************************
CLASS transfer_order DEFINITION DEFERRED.                          "making class definition deferred.

DATA obj TYPE REF TO transfer_order.                               "creating reference of class object.

*********************************************************
*final structure declaration.
*********************************************************
TYPES : BEGIN OF ty_final,
          tr_no        TYPE tbnum,
          line_item    TYPE tbpos,
          material     TYPE matnr,
          batch        TYPE charg_d,
          storage_unit TYPE lvs_letyp,
          uom          TYPE meins,
          maktx        type maktx,
          tr_qty       TYPE ltbp_menge,
          su_number    TYPE ltap_vlenr,
          su_quantity  TYPE ltap_nsolm,
          plant        TYPE werks_d,
          storage_loc  TYPE lgort_d,
          checkbox     TYPE c,
          bins         TYPE lgpla,

        END OF ty_final.

*********************************************************
*zwm_picklist structure declaration.
*********************************************************
TYPES :BEGIN OF ty_zwm_picklist,
         werks TYPE  werks_d,
         lgort TYPE lgort_d,
         lgnum TYPE lgnum,
         lgtyp TYPE lgtyp,
         lgber TYPE  lgber,
       END OF ty_zwm_picklist.

*********************************************************
*table ltbk structure declaration.
*********************************************************
TYPES : BEGIN OF ty_ltbk,
          tbnum TYPE tbnum,
          statu TYPE ltbk_statu,
        END OF ty_ltbk.

*********************************************************
*table lqua structure declaration.
*********************************************************
TYPES:BEGIN OF ty_lqua,
        lgnum TYPE lgnum,
        lqnum TYPE lvs_lqnum,
        lgpla TYPE lgpla,
      END OF ty_lqua.

*********************************************************
*table lagp structure declaration.
*********************************************************
 types : BEGIN OF ty_lagp,
                lgnum TYPE lgnum,
                lgtyp TYPE lgtyp,
                lgpla TYPE lgpla,
          END OF ty_lagp.
*********************************************************
*Global data declaration.
*********************************************************
DATA :  wa_lqua        TYPE ty_lqua,                            "Work area declaration for type lqua
        it_final       TYPE STANDARD TABLE OF ty_final,         "Final Internal table declaration of type ty_final
        it_final1      TYPE STANDARD TABLE OF ty_final,         "Copy of Final Internal table declaration of type ty_final
        wa_final       TYPE ty_final,                           "Work area declaration for type ty_final
        wa_final1      TYPE ty_final,                           "Copy of Work area declaration for type ty_final
        alv_container  TYPE REF TO cl_gui_custom_container,     "container reference to class.
        alv_grid       TYPE REF TO cl_gui_alv_grid,             "grid  reference to class.
        ok_code        TYPE sy-ucomm,                           "ok code of type sy-ucomm
        fieldcat       TYPE lvc_t_fcat,                         "internal table for fieldcat.
        it_layout      TYPE lvc_s_layo,                         "internal table for fieldcat layout
        gv_text        TYPE char100,                            "text variable declaration.
        ty_toolbar     TYPE stb_button,                         "toolbar structure declaration .
        it_ltap_vb     TYPE STANDARD TABLE OF ltap_vb,          "internal table for ltap_vb.
        wa_ltap_vb     TYPE ltap_vb,                            "work area of ltap_vb.
        it_bdcdata     TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
        wa_bdcdata     TYPE bdcdata,                            "bdc internal table declaration.
        it_ltbk        TYPE STANDARD TABLE OF ty_ltbk,          "internal table declaration of type ty_ltbk.
        flag_refresh   TYPE c VALUE 0.

 DATA p_tr_old TYPE tbnum.
 DATA p_tr_new TYPE tbnum.
