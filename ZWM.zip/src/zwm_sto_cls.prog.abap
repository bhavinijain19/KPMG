*************************************************************************************
*Object Name              : ZWM_STO.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 24/03/2019.
*************************************************************************************
*Description              : class declaration and implementaion include.
*************************************************************************************

*********************************************************
*class definition.
*********************************************************
CLASS transfer_order DEFINITION.
  PUBLIC SECTION.
    METHODS :fetch_data,
      fieldcat,
      display,
      validation,
      handle_toolbar_set
                    FOR EVENT toolbar OF cl_gui_alv_grid
        IMPORTING e_object
                    e_interactive,
      handle_user_command
                    FOR EVENT user_command OF cl_gui_alv_grid
        IMPORTING e_ucomm.
ENDCLASS.

*********************************************************
*class implementation.
*********************************************************
CLASS transfer_order IMPLEMENTATION.
*********************************************************
*method for validating user input.
*********************************************************
  METHOD validation.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE mblnr, mjahr, zeile ,bwart, vbeln_im FROM mseg
*      INTO @DATA(wa_mseg)
*      WHERE mblnr EQ @p_matdoc
*      AND mjahr EQ @p_year
*      AND bwart EQ '101'.

SELECT MBLNR , MJAHR , ZEILE , BWART , VBELN_IM FROM MSEG
 INTO @DATA(WA_MSEG) UP TO 1 ROWS WHERE MBLNR EQ @P_MATDOC AND MJAHR EQ @P_YEAR AND BWART EQ '101'
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    IF sy-subrc NE 0.
      CLEAR p_tr.
      MESSAGE e003(zwm_sto).
      CLEAR p_tr.
    ENDIF.

    IF wa_mseg-vbeln_im NE p_out.
      CLEAR p_tr.
      MESSAGE e004(zwm_sto).

    ENDIF.

    IF flag_refresh EQ 0.
      p_tr_new = p_tr.
      p_tr_old =  p_tr_new.
      flag_refresh = 1.
    ELSE.
      p_tr_old = p_tr_new.
      p_tr_new = p_tr.
    ENDIF.

    IF p_tr_new EQ p_tr_old.
      SELECT tbnum statu FROM ltbk
        INTO TABLE it_ltbk
        WHERE tbnum EQ p_tr AND statu EQ text-003.
    ENDIF.

    IF p_tr_new NE p_tr_old.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*      SELECT SINGLE tbnum,
*                mblnr,                                         "for getting TR on enter command
*                mjahr
*  FROM ltbk
*  INTO @DATA(wa_ltbk)
*  WHERE mblnr EQ @p_matdoc
*  AND mjahr EQ @p_year.

SELECT TBNUM ,
 MBLNR , MJAHR FROM LTBK INTO @DATA(WA_LTBK) UP TO 1 ROWS WHERE MBLNR EQ @P_MATDOC AND MJAHR EQ @P_YEAR
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


      p_tr = wa_ltbk-tbnum.
    ENDIF.
    SELECT tbnum statu FROM ltbk
     INTO TABLE it_ltbk
     WHERE tbnum EQ p_tr AND statu EQ text-003.
    IF sy-subrc EQ 0.
      CLEAR p_tr.
      MESSAGE e005(zwm_sto).

    ENDIF.

  ENDMETHOD.
*********************************************************
*method to fetching data.
*********************************************************
  METHOD fetch_data.


    SELECT lgnum,                                     "fetchng data from ltbp table on the basis of TR no.
           tbnum,
           tbpos,
           matnr,
           werks,
           charg,
           menge,
           meins,
           lgort
      FROM ltbp
      INTO TABLE @DATA(it_ltbp)
      WHERE tbnum EQ @p_tr.


    IF it_ltbp IS NOT INITIAL.                        "initial check.
      DATA(it_ltbp_temp) = it_ltbp.
      SORT it_ltbp_temp BY lgnum tbnum tbpos.
      DELETE ADJACENT DUPLICATES FROM it_ltbp_temp COMPARING lgnum tbnum tbpos.
      SELECT matnr,
             spras,
             maktx
      FROM makt
      INTO TABLE @DATA(it_makt)
      FOR ALL ENTRIES IN @it_ltbp_temp
      WHERE matnr EQ @it_ltbp_temp-matnr
      AND   spras EQ @sy-langu.

      IF it_makt IS NOT INITIAL.
*******************        added 21.03.2023 for faster process
        select lgnum,
               tanum
         FROM ltak
          INTO TABLE @DATA(it_ltak)
          WHERE vbeln EQ @p_out.
********************************    ened 21.03.2023
if it_ltak is not INITIAL.
        SELECT lgnum,
               tanum,
               posnr,                                  "fetchng data from ltap table on the basis of outbound delivery no.
               matnr,
               werks,
               charg,
               letyp,
               nsolm,
               vlenr,
               vbeln,
               tapos
          FROM ltap
          INTO TABLE @DATA(it_ltap)
          FOR ALL ENTRIES IN @it_ltak
          where lgnum EQ @it_ltak-lgnum
          and   tanum EQ @it_ltak-tanum.
 endif.


     IF it_ltap IS NOT INITIAL.
          SELECT mblnr,
                 mjahr,
                 matnr,
                 charg,
                 tbnum,
                 tbpos,
                 menge,
                 vbeln_im,
                 vbelp_im
                 FROM mseg
            INTO TABLE @DATA(it_mseg)
            FOR ALL ENTRIES IN @it_ltbp
            WHERE mblnr = @p_matdoc AND mjahr = @p_year AND tbpos = @it_ltbp-tbpos AND menge = @it_ltbp-menge.


          SORT it_ltap BY matnr charg.
          SORT it_ltbp BY matnr charg.                             "sorting it_ltbp.
          SORT it_mseg BY matnr charg.                             "sorting it_mseg.
          SORT it_makt BY matnr.

*********************************************************
*populating data to final internal table.
*********************************************************

          LOOP AT  it_ltap ASSIGNING FIELD-SYMBOL(<fs_ltap>) WHERE vbeln EQ p_out.

            IF <fs_ltap> IS ASSIGNED.
              APPEND INITIAL LINE TO it_final ASSIGNING FIELD-SYMBOL(<fs_final>).

              <fs_final>-su_number  = <fs_ltap>-vlenr.
              <fs_final>-su_quantity = <fs_ltap>-nsolm.
              <fs_final>-storage_unit = <fs_ltap>-letyp.
              READ TABLE it_mseg ASSIGNING FIELD-SYMBOL(<fs_mseg>) WITH KEY  vbelp_im = <fs_ltap>-posnr.
              IF <fs_mseg> IS ASSIGNED.
                READ TABLE it_ltbp ASSIGNING FIELD-SYMBOL(<fs_ltbp>) WITH KEY matnr = <fs_ltap>-matnr
                                                                              charg = <fs_ltap>-charg
                                                                              tbpos = <fs_mseg>-tbpos
                                                                              tbnum = <fs_mseg>-tbnum.

                IF <fs_ltbp> IS ASSIGNED.
                  READ TABLE it_makt ASSIGNING FIELD-SYMBOL(<fs_makt>) WITH KEY matnr = <fs_ltbp>-matnr spras = sy-langu.
                  IF <fs_makt> IS ASSIGNED.
                    <fs_final>-tr_no        =   p_tr.
                    <fs_final>-material     =  <fs_ltbp>-matnr.
                    <fs_final>-line_item    =  <fs_ltbp>-tbpos.
                    <fs_final>-batch        =  <fs_ltbp>-charg.
                    <fs_final>-uom          =  <fs_ltbp>-meins.
                    <fs_final>-plant        =  <fs_ltbp>-werks.
                    <fs_final>-storage_loc  =  <fs_ltbp>-lgort.
                    <fs_final>-tr_qty       =  <fs_mseg>-menge.
                    <fs_final>-maktx        =  <fs_makt>-maktx.
                    UNASSIGN <fs_mseg>.
                    UNASSIGN <fs_makt>.
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.

*********************************************************
*code for deleting used Su numbers.
*********************************************************

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT SINGLE                                                          "selecting data from  ltbk.
*                  lgnum,
*                  tbnum FROM ltbk
*                  INTO  @DATA(wa_ltbk)
*                  WHERE tbnum EQ @p_tr.

SELECT
 LGNUM , TBNUM FROM LTBK INTO @DATA(WA_LTBK) UP TO 1 ROWS WHERE TBNUM EQ @P_TR
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


    DATA(wr_no) = wa_ltbk-lgnum.

    IF wa_ltbk IS NOT INITIAL.                                              "initial check

      SELECT lgnum,
             lqnum,
             lenum FROM lqua                                                "selectimg data from lqua.
       INTO TABLE @DATA(it_lqua)
       FOR ALL ENTRIES IN @it_final
       WHERE lgnum   EQ @wr_no
       AND   lenum   EQ @it_final-su_number.


      IF sy-subrc EQ 0.                                                      "initial check.

        CLEAR wa_final.
        LOOP AT it_final INTO wa_final.
          READ TABLE it_lqua INTO wa_lqua WITH KEY lenum = wa_final-su_number.
          IF sy-subrc = 0.

            DELETE TABLE it_final FROM wa_final.                             "deleting used su_numbers from final table.

          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
    CLEAR wa_final.
    SORT it_final BY line_item.                                                        "clearing wa_final.
    LOOP AT it_final INTO wa_final.
      "making copy of final table.
      AT NEW tr_qty.                                                         "at new statement.
        wa_final1-tr_no        =  wa_final-tr_no.
        wa_final1-line_item    =  wa_final-line_item.
*        SHIFT wa_final-material LEFT DELETING LEADING '0'.
        wa_final1-material     =  wa_final-material.
        wa_final1-batch        =  wa_final-batch.
        wa_final1-storage_unit =  wa_final-storage_unit.
        wa_final1-uom          =  wa_final-uom .
        wa_final1-tr_qty       =  wa_final-tr_qty.
        wa_final1-maktx        =  wa_final-maktx.
      ENDAT.
*      SHIFT wa_final-su_number LEFT DELETING LEADING '0'.
      wa_final1-su_number      =  wa_final-su_number .
      wa_final1-su_quantity    =  wa_final-su_quantity.

      wa_final1-plant          =  wa_final-plant.
      wa_final1-storage_loc    =  wa_final-storage_loc.
      wa_final1-checkbox       = 'X'.
      APPEND wa_final1 TO it_final1.                                          "moving data to it_final1.
      CLEAR wa_final1.
    ENDLOOP.

  ENDMETHOD.

*********************************************************
*method for preparing field catalog.
*********************************************************
  METHOD fieldcat.

    DATA: ls_fcat TYPE lvc_s_fcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-007.
    ls_fcat-fieldname = text-008.
    ls_fcat-outputlen  = text-056.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-010.
    ls_fcat-fieldname = text-011.
    ls_fcat-outputlen  = text-009.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-050.
    ls_fcat-fieldname = text-051.
    ls_fcat-outputlen  = text-052.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-012.
    ls_fcat-fieldname = text-013.
    ls_fcat-outputlen  = text-053.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-014.
    ls_fcat-fieldname = text-015.
    ls_fcat-outputlen  = text-054.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-016.
    ls_fcat-fieldname = text-017.
    ls_fcat-outputlen  = text-018.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-019.
    ls_fcat-fieldname = text-020.
    ls_fcat-outputlen  = text-018.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-021.
    ls_fcat-fieldname = text-022.
    ls_fcat-outputlen  = text-055.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-024.
    ls_fcat-fieldname = text-025.
    ls_fcat-outputlen  = text-009.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-026.
    ls_fcat-fieldname = text-027.
    ls_fcat-outputlen  = text-028.
    ls_fcat-checkbox = abap_true.
    ls_fcat-edit = abap_true.
    APPEND ls_fcat TO fieldcat.

    CLEAR ls_fcat.
    ls_fcat-reptext = text-029.
    ls_fcat-fieldname = text-030.
    ls_fcat-outputlen  = text-009.
    ls_fcat-edit = abap_true.
    APPEND ls_fcat TO fieldcat.

  ENDMETHOD.
***********************************************************
*method to display alv.
***********************************************************
  METHOD display.

    CALL SCREEN 0101.

  ENDMETHOD.
***********************************************************
*method to handle toolbar.
***********************************************************
  METHOD handle_toolbar_set.

    CLEAR ty_toolbar.

    ty_toolbar-function = text-004. "name of btn to catch click
    ty_toolbar-butn_type = 0.
    ty_toolbar-text = text-300.

    APPEND ty_toolbar TO e_object->mt_toolbar.

  ENDMETHOD.
***********************************************************
*method for handling user command.
***********************************************************
  METHOD handle_user_command.
    CASE e_ucomm.
      WHEN 'POST'.
        DATA:  wa_final        TYPE ty_final,
               wa_zwm_picklist TYPE ty_zwm_picklist,
               wa_trite        TYPE  l03b_trite,
               it_trite        TYPE STANDARD TABLE OF l03b_trite,
               sum             TYPE menge_d VALUE 0,
               material1       TYPE matnr,
               line_item1      TYPE tbpos,
               flag            TYPE n VALUE 0,
               gv_tanum        TYPE ltak-tanum,
               gv_teilv        TYPE t340d-teilv,
               flag1           TYPE i VALUE 0,
               it_lagp         TYPE STANDARD TABLE OF ty_lagp,
               wa_lagp         TYPE ty_lagp,
               flag_check      TYPE n VALUE 0,
               flag_check1     TYPE n VALUE 0.
        gv_text = text-005.

        CALL METHOD alv_grid->check_changed_data. "calling method for getting user input on alv.

        CLEAR wa_final1.
        READ TABLE it_final1 INTO wa_final1 WITH KEY checkbox = abap_true.
        IF sy-subrc EQ 0.
          DATA(it_final_temp) = it_final.
          SORT it_final_temp BY tr_no.                                          "sorting t_final_temp.
          DELETE ADJACENT DUPLICATES FROM it_final_temp COMPARING tr_no.        "removing duplicates from it_final_temp.
          SELECT     werks,
                     lgort,
                     lgnum,
                     lgtyp,
                     lgber
                     FROM zwm_picklist
                     INTO TABLE @DATA(it_zwm_picklist)
                     FOR ALL ENTRIES IN @it_final_temp
                     WHERE werks EQ @it_final_temp-plant
                     AND lgort EQ   @it_final_temp-storage_loc.

          SELECT lgnum
                 lgtyp
                 lgpla
          FROM lagp
          INTO TABLE it_lagp
          FOR ALL ENTRIES IN it_zwm_picklist
          WHERE lgnum EQ it_zwm_picklist-lgnum
          AND   lgtyp EQ it_zwm_picklist-lgtyp.

          CLEAR wa_final.                                                        "clearing work areas.
          CLEAR wa_final1.
          LOOP AT it_final INTO wa_final .
*            shift wa_final-su_number LEFT DELETING LEADING '0'.
            READ TABLE it_final1 INTO wa_final1 WITH KEY su_number = wa_final-su_number
                                                         checkbox = abap_true.    "reading It_final1 at checkbox.
            IF sy-subrc EQ 0 .
              wa_final-checkbox = 'X'.
              wa_final-bins = wa_final1-bins.


              IF wa_final-bins IS INITIAL AND flag_check1 EQ 0.
                MESSAGE i002(zwm_sto) DISPLAY LIKE 'I'.
                LEAVE LIST-PROCESSING.
                flag1 = 1.
                flag_check1 = 1.
              ENDIF.


              IF ( material1 = wa_final-material AND line_item1 = wa_final-line_item ) OR flag = 0.
                sum = sum + wa_final-su_quantity.
                material1 = wa_final-material.
                line_item1 = wa_final-line_item.
                flag = 1.
              ELSE.
                sum = 0.
                sum = sum + wa_final-su_quantity.
                material1 = wa_final-material.
                line_item1 = wa_final-line_item.
              ENDIF.

              IF wa_final-bins IS NOT INITIAL.                                        "initial check
                READ TABLE it_lagp INTO wa_lagp WITH KEY lgpla = wa_final-bins.        "checking whether bin entered is right or not.
                IF sy-subrc NE 0 AND flag_check1 EQ 0.
                  MESSAGE i000(zwm_sto) DISPLAY LIKE 'I' WITH wa_final-bins.
                  LEAVE LIST-PROCESSING.
                  flag1 = 1.
                  flag_check1 = 1.
                ENDIF.
              ENDIF.
              IF flag1 EQ 0.
                wa_trite-tbpos   = wa_final-line_item.                                "populating wa_trite.
                wa_trite-anfme   = wa_final-su_quantity.
                wa_trite-altme   = wa_final-uom.
                wa_trite-charg   = wa_final-batch.
                wa_trite-letyp   = wa_final-storage_unit.
                wa_trite-nlenr   = wa_final-su_number.

                wa_ltap_vb-matnr = wa_final-material.                             "populating wa_ltap_vb.
                wa_ltap_vb-werks = wa_final-plant.
                wa_ltap_vb-charg = wa_final-batch.
                wa_ltap_vb-vlpla = wa_final-bins.
                wa_ltap_vb-nlenr = wa_final-su_number.

                "reading table it_zwm_picklist.
                READ TABLE it_zwm_picklist INTO wa_zwm_picklist WITH KEY werks = wa_final-plant
                                                                         lgort = wa_final-storage_loc.

                IF sy-subrc EQ 0.

                  wa_trite-nltyp = wa_zwm_picklist-lgtyp.                         "populating wa_trite.
                  wa_trite-nlber = wa_zwm_picklist-lgber.
                  wa_trite-vltyp = wa_zwm_picklist-lgtyp.
                  wa_trite-vlber = wa_zwm_picklist-lgber.

                ENDIF.
                wa_trite-nlpla = wa_final-bins.

                APPEND wa_trite TO it_trite.                                      "appending data to it_trite.
                APPEND wa_ltap_vb TO it_ltap_vb.                                  "appending data to it_ltap_vb.
              ENDIF.
            ENDIF.
            AT END OF tr_qty.
              IF sum NE wa_final-tr_qty AND sum NE 0 AND flag_check1 EQ 0.

                MESSAGE i001(zwm_sto) DISPLAY LIKE 'I'.
                LEAVE LIST-PROCESSING.
                flag1 = 1.
                flag_check1 = 1.
                CLEAR sum.
              ENDIF.
            ENDAT.
          ENDLOOP.

        ELSE.
          MESSAGE : i006(zwm_sto) DISPLAY LIKE 'E'.
          LEAVE LIST-PROCESSING.
          flag_check = 1.
        ENDIF.
***********************************************************
*calling FM to create TO from TR.
***********************************************************
        IF flag1 = 0 AND flag_check NE 1.
          CALL FUNCTION 'L_TO_CREATE_TR'
            EXPORTING
              i_lgnum                        = wa_zwm_picklist-lgnum
              i_tbnum                        = p_tr
              i_commit_work                  = 'X'
              i_bname                        = sy-uname
              i_solex                        = wa_final-su_quantity
              it_trite                       = it_trite
            IMPORTING
              e_tanum                        = gv_tanum
              e_teilk                        = gv_teilv
            TABLES
              t_ltap_vb                      = it_ltap_vb
            EXCEPTIONS
              foreign_lock                   = 1
              qm_relevant                    = 2
              tr_completed                   = 3
              xfeld_wrong                    = 4
              ldest_wrong                    = 5
              drukz_wrong                    = 6
              tr_wrong                       = 7
              squit_forbidden                = 8
              no_to_created                  = 9
              update_without_commit          = 10
              no_authority                   = 11
              preallocated_stock             = 12
              partial_transfer_req_forbidden = 13
              input_error                    = 14
              OTHERS                         = 15.


***********************************************************
*BDC for confirming created TO.
***********************************************************
          PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                                        'LTAK-TANUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '/00'.
          PERFORM bdc_field       USING 'LTAK-TANUM'
                                         gv_tanum.
          PERFORM bdc_field       USING 'LTAK-LGNUM'
                                         wa_zwm_picklist-lgnum.

          PERFORM bdc_dynpro      USING 'SAPML03T' '0114'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=QU'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                                        '=BU'.

          CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.


        ENDIF.


    ENDCASE.
    IF flag1 EQ 0 AND flag_check NE 1.
      CONCATENATE gv_text gv_tanum gv_teilv INTO gv_text SEPARATED BY ' '.
      MESSAGE gv_text TYPE 'I'.
      REFRESH : it_bdcdata,it_final,it_final1,it_ltbk.
      FREE : gv_text,p_tr,p_matdoc,p_out,p_year,wa_bdcdata,wa_final,wa_final1,wa_lqua,wa_ltap_vb.
      LEAVE TO SCREEN 0.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
***********************************************************
*PBO of screen 0101.
***********************************************************
MODULE status_0101 OUTPUT.
  SET PF-STATUS 'PF_0101'.
  SET TITLEBAR  'T_0101'.


  CREATE OBJECT alv_container                                    "creating object of container.
    EXPORTING
      container_name = 'ALV_CONTAINER'.

  CREATE OBJECT alv_grid                                         "creating object of grid.
    EXPORTING
      i_parent = alv_container.

  obj->fieldcat( ).                                              "calling fieldcat method from class object.

  it_layout-cwidth_opt = abap_true.
  it_layout-zebra = abap_true.
  it_layout-col_opt = abap_true.

  SET HANDLER obj->handle_toolbar_set FOR alv_grid.              "setting handler for toolbar

  SET HANDLER obj->handle_user_command FOR alv_grid.             "setting toolbar for user command.


  CALL METHOD alv_grid->set_table_for_first_display              "calling method for alv display.
    CHANGING
      it_outtab       = it_final1
      it_fieldcatalog = fieldcat.



ENDMODULE.
***********************************************************
*PAI of screen 0101.
***********************************************************
MODULE user_command_0101 INPUT.

  CASE sy-ucomm.

    WHEN 'BACK1' OR 'CANC'.

      REFRESH : it_bdcdata,it_final,it_final1,it_ltbk.
      FREE : gv_text,p_tr,p_matdoc,p_out,p_year,wa_bdcdata,wa_final,wa_final1,wa_lqua,wa_ltap_vb.

      LEAVE TO SCREEN 0.
    WHEN 'EXIT'.
      LEAVE PROGRAM.
    WHEN 'POST'.
      obj->handle_user_command( ).
  ENDCASE.
ENDMODULE.
