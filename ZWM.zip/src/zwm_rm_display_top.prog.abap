*************************************************************************************
*Object Name              : ZWM_RM_DISPLAY.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 06/04/2019.
*************************************************************************************
*Description              : include for top FOR RM DISPLAY.
*************************************************************************************
*********************************************************
*global data declaration
*********************************************************

DATA ok_code TYPE sy-ucomm.
data : v_field1 TYPE char18,
       v_field2 TYPE string,
       v_field3 TYPE char18,
       v_field4 TYPE char10.
data flag_enter TYPE c VALUE 0.
data v_lgtyp    TYPE lgtyp.
data v_lgpla    type char200.
data v_matnr    type matnr.
data v_charg    type charg_d.
data v_desc     type maktx.
data v_mfd      type char10.
data v_exp      type char10.
data v_total    type string.
data v_name     type NAME1_GP.
data v_bestq    type bestq.
data v_lifnr    type lifnr.
data v_pack     type string.
*********************************************************
*structure definition of lqua.
*********************************************************
types : BEGIN OF ty_lqua,
        matnr TYPE matnr,
        charg TYPE charg_d,
        lgnum type lgnum,
        lqnum type lvs_lqnum,
        bestq TYPE string,
        lgtyp TYPE lgtyp,
        lgpla TYPE lgpla,
        END OF ty_lqua.

data : it_lqua TYPE STANDARD TABLE OF ty_lqua,     "declaring it_lqua of type ty_lqua
       wa_lqua TYPE  ty_lqua.                      "declaring wa_lqua.
data : p_scan  TYPE char40,
       p_lgtyp type lgtyp .
