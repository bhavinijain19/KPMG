*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_STATUS_8O02
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_8002  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8002 OUTPUT.
  SET PF-STATUS 'ZMM_8002'.
  fill802 = cnt.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8002  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8002 INPUT.
  TABLES: lips.
  DATA: lv_num     TYPE i,
        lv_cnt     TYPE i,
        lv_venum   TYPE vepo-venum,
        lw_mchb    TYPE mchb,
        lv_lgort02 TYPE lgort_d.

  FREE : lv_num,lv_cnt.
  CASE sy-ucomm.
    WHEN 'BACK'.
      CLEAR: cnt, lgort, lt_8002[], lw_8002, exidv8002, lw_lips-matnr.
      FREE: obd_no,lin_item,lt_8002[].
      LEAVE TO SCREEN 0.
*      CALL SCREEN 8001.
    WHEN 'ENTER'.
      FREE : lt_8002[], lw_8002, cnt,lv_total_qty.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = obd_no
        IMPORTING
          output = obd_no.
      SELECT COUNT(*) FROM vbuk WHERE vbeln =  obd_no
                                  AND lvstk = 'C'. "#EC CI_DB_OPERATION_OK[2198647]
      IF sy-subrc = 0.
        MESSAGE 'Delivery already processed/Inprocess.' TYPE 'E'.
        EXIT.
      ENDIF.

      SELECT COUNT(*) FROM zmm_load_sloc1 WHERE obd_no = obd_no
                                         AND obd_headitem = lin_item
                                         AND load_status = 'W'.     "'I'
      IF sy-subrc = 0.
        MESSAGE 'Delivery already processed/Inprocess.' TYPE 'E'.
      ENDIF.

*************Validation for free scheme
      SELECT SINGLE * FROM lips WHERE vbeln = obd_no
                                  AND uepos = lin_item
                                  AND uecha = ' '
                                  AND uepvw = 'B'.
      IF sy-subrc = 0.
        MESSAGE 'This OBD is for with scheme.' TYPE 'I'.
        RETURN.
      ENDIF.
*************Validation for free scheme

      SELECT vbeln posnr matnr lgort charg
        lfimg meins  uepos lgpla uecha uepvw FROM lips
        INTO TABLE lt_lips_tmp "lt_lips
        WHERE vbeln = obd_no.

      lt_lips = lt_lips_tmp.
      DELETE lt_lips WHERE uecha <> lin_item.

      READ TABLE lt_lips INTO lw_lips INDEX 1. "#EC CI_NOORDER
      LOOP AT lt_lips INTO lw_lips.
        lw_8002-batch_no = lw_lips-charg.
        lw_8002-qty      = lw_lips-lfimg.
        lw_8002-uom      = lw_lips-meins.
        " total_del_qty = total_del_qty + lw_lips-lfimg.
        READ TABLE lt_lips_tmp INTO lw_lips_tmp WITH KEY
                                      uepos = lin_item
                                      uepvw = 'B'.
        IF sy-subrc = 0.
          READ TABLE lt_lips_tmp INTO lw_lips_tmp1 WITH KEY
                                  uecha = lw_lips_tmp-posnr.
          IF sy-subrc = 0.
          ENDIF.
        ENDIF.
        APPEND lw_8002 TO lt_8002.

        cnt = cnt + 1.
      ENDLOOP.
      IF it_free_qty IS NOT INITIAL.
        p_status = 'X'.
      ELSE.
        p_status = ' '.
      ENDIF.
    WHEN 'NEXTV'.
*      line802 = line802 + 1.
      line802 = line802 + lines802.
      limit802 = fill802 - lines802.
      IF line802 > limit802.
        line802 = limit802.
      ENDIF.
    WHEN 'PREVV'.
      line802 = line802 - lines802. "1.
      IF line802 < 0.
        line802 = 0.
      ENDIF.
    WHEN 'NEXT'.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = obd_no
        IMPORTING
          output = obd_no.
      SELECT SINGLE vbeln FROM lips INTO @DATA(v_vbeln)
          WHERE vbeln = @obd_no
         AND posnr = @lin_item .
      IF sy-subrc <> 0.
*        CALL SCREEN 8004.
*      ELSE.
        MESSAGE 'Enter Correct Delivery No Details' TYPE 'I'.
        RETURN.
      ENDIF.
      CLEAR: load_no.

      CLEAR lt_sloc8110.
      SELECT load_no load_item su_no obd_no obd_lineitem  obd_headitem  matnr batch_no
           su_no quantity  su_qty FROM zmm_load_sloc1
           INTO CORRESPONDING FIELDS OF TABLE lt_sloc8110
           WHERE obd_no = obd_no
               AND obd_headitem = lin_item
                  AND load_status IN ( 'I' , 'C' ).
      IF sy-subrc = 0.
        READ TABLE lt_sloc8110 TRANSPORTING NO FIELDS WITH KEY load_status = 'C'.
        IF sy-subrc = 0.
          MESSAGE 'Delivery already processed/Inprocess.' TYPE 'I'.
          EXIT.
        ENDIF.
      ENDIF.
      CLEAR cnt113.
      LOOP AT lt_sloc8110 INTO lw_sloc8110.
        lw_8005-lenum = lw_sloc8110-su_no .
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = lw_8005-lenum
          IMPORTING
            output = lw_8005-lenum.

        IF sy-subrc = 0.
          load_no = lw_sloc8110-load_no." loadno.
        ENDIF.

        APPEND lw_8005 TO lt_8005.
        CLEAR: lw_8005, lw_sloc8110.
        DESCRIBE TABLE lt_8005 LINES cnt113.
        CONDENSE cnt113.
        cnt5 = cnt113.
      ENDLOOP.
      IF load_no IS NOT INITIAL.
        CALL SCREEN 8005.
      ELSE.
        CALL SCREEN 8004.
      ENDIF.

  ENDCASE.
ENDMODULE.

*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_OUT_8002  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_out_8002 OUTPUT.
*  DATA: lw_8002d TYPE ty_batch.
  idx802 = sy-stepl + line802.
  READ TABLE lt_8002 INTO lw_8002 INDEX idx802.
*  IF sy-subrc = 0.
*    lw_8002 = lt_8002[ idx802 ].
*  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_IN_8002  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_in_8002 INPUT.
  lines802 = sy-loopc.
  idx802 = sy-stepl + line802.
  MODIFY lt_8002 FROM lw_8002 INDEX idx802.
ENDMODULE.
