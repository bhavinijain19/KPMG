*************************************************************************************
*Object Name              : ZWM_PUTAWAY_LIST.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 1/04/2019.
*************************************************************************************
*Description              :Smartform Driver program for pick away list.
*************************************************************************************
REPORT ZWM_PUTAWAY_LIST.

include : ZWM_PUTAWAY_LIST_top,
          ZWM_PUTAWAY_LIST_scr,
          ZWM_PUTAWAY_LIST_cls.

*********************************************************
*initialization event.
*********************************************************
INITIALIZATION.

  CREATE OBJECT obj.                     "creating object of class

*********************************************************
*at selection screen event.
*********************************************************
AT SELECTION-SCREEN.

  obj->validation( ).                    "calling class method for validating input.

*********************************************************
*start of selection event.
*********************************************************
START-OF-SELECTION.

 obj->fetch_data( ).                    "calling class method to getdata.
 obj->smartform( ).                     "calling smartform.
