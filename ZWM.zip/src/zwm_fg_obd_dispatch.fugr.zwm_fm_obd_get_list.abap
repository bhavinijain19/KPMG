FUNCTION zwm_fm_obd_get_list.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_OBD_NUMMBER) TYPE  VBELN_VL OPTIONAL
*"     VALUE(IV_SCHEME) TYPE  CHAR1 OPTIONAL
*"     VALUE(IV_LOAD_NO) TYPE  ZLOAD_NO OPTIONAL
*"  EXPORTING
*"     REFERENCE(ET_LIST) TYPE  ZWM_TT_OBD_LIST1
*"     REFERENCE(ET_BATCH_EXP) TYPE  ZWM_TT_BATCH_EXP
*"  CHANGING
*"     VALUE(OBD_NUM) TYPE  VBELN_VL OPTIONAL
*"     VALUE(LOAD_NO) TYPE  ZLOAD_NO OPTIONAL
*"----------------------------------------------------------------------

  TYPES: BEGIN OF ty_lips,
           vgpos TYPE vgpos,
           matnr TYPE matnr,
           uepvw TYPE uepvw,
           arktx TYPE arktx,
           charg TYPE charg_d,
           lfimg TYPE lfimg,
           cmpnt TYPE cmpnt,
           meins TYPE meins,
           lgpla TYPE	lgpla,
           uepos TYPE uepos,
           pstyv TYPE pstyv_vl,
           lgort TYPE lgort_d,
         END OF ty_lips.

  TYPES: BEGIN OF ty_mvke,
           matnr TYPE matnr,
           aumng TYPE minau,
         END OF ty_mvke.

  TYPES: BEGIN OF ty_str,
           lgort TYPE char4,
         END OF ty_str.

  DATA: ls_list         TYPE zwm_st_obd_list1,
        lt_list         TYPE TABLE OF zwm_st_obd_list1,
        lt_lips         TYPE TABLE OF ty_lips,
        ls_lips_grp     TYPE ty_lips,
        ls_lips_sub     TYPE ty_lips,
        ls_lips         TYPE ty_lips,
        lv_vkorg        TYPE vkorg,
        lv_vstel        TYPE vstel,
        lt_mvke         TYPE TABLE OF ty_mvke,
        ls_mvke         TYPE ty_mvke,
        ls_batch_list   TYPE zwm_st_batch_list,
        ls_scanned_list TYPE zwm_st_scan_list,
        lt_ltap         TYPE TABLE OF ltap,
        ls_ltap         TYPE ltap,
        lt_mch1         TYPE TABLE OF mch1,
        ls_mch1         TYPE mch1,
        ls_batch_exp    TYPE zwm_st_batch_exp,
        lt_load_sloc1   TYPE TABLE OF zmm_load_sloc1,
        lt_load_sloc2   TYPE TABLE OF zmm_load_sloc2,
        ls_load_sloc1   TYPE zmm_load_sloc1,
        ls_load_sloc2   TYPE zmm_load_sloc2,
        lt_su           TYPE TABLE OF zwm_su,
        ls_su           TYPE zwm_su,
        lt_mat_sloc     TYPE TABLE OF ty_str.

  DATA: lv_str1         TYPE string,
        lv_str2         TYPE string,
        lv_config_name  TYPE zwm_de_config_name,
        lv_config_value TYPE zwm_de_config_value,
        lv_qty          TYPE lips-lfimg.

  FIELD-SYMBOLS: <fs_batch_list> TYPE zwm_st_batch_list.

  DATA: lv_date TYPE sy-datum.

  lv_date = sy-datum.
  lv_date = lv_date + 7.

  lv_qty = ls_batch_list-qty + ceil( ls_lips_sub-lfimg ).

  "Fetch OBD from Load No
  IF load_no IS NOT INITIAL.
    IF iv_scheme EQ 'X'.
      SELECT * FROM zmm_load_sloc2 INTO TABLE lt_load_sloc2 WHERE load_no = load_no.
      IF sy-subrc EQ 0.
        SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_load_sloc2
          WHERE lenum = lt_load_sloc2-su_no.

        READ TABLE lt_load_sloc2 INTO ls_load_sloc2 INDEX 1.
        IF sy-subrc EQ 0.
          obd_num = ls_load_sloc2-obd_no.
        ENDIF.
      ENDIF.
    ELSE.
      SELECT * FROM zmm_load_sloc1 INTO TABLE lt_load_sloc1 WHERE load_no = load_no.
      IF sy-subrc EQ 0.
        SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_load_sloc1
          WHERE lenum = lt_load_sloc1-su_no.

        READ TABLE lt_load_sloc1 INTO ls_load_sloc1 INDEX 1.
        IF sy-subrc EQ 0.
          obd_num = ls_load_sloc1-obd_no.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

  SELECT vgpos matnr uepvw arktx charg lfimg cmpnt meins lgpla pstyv lgort
    FROM lips
    INTO CORRESPONDING FIELDS OF TABLE lt_lips
    WHERE vbeln = obd_num
    AND lfimg GT 0.
    "AND lvsta = 'A'. "Added by BP

  SELECT SINGLE vkorg vstel
    FROM likp
    INTO (lv_vkorg,lv_vstel)
    WHERE vbeln = obd_num.

  "check for non WM material
  IF lv_vstel IS NOT INITIAL.
    CONCATENATE 'MAT_SLOC_' lv_vstel INTO lv_config_name.

    SELECT SINGLE value FROM zwm_gen_config INTO lv_config_value WHERE name = lv_config_name.
    IF sy-subrc EQ 0.
      SPLIT lv_config_value AT ',' INTO TABLE lt_mat_sloc.
    ENDIF.
  ENDIF.

  IF lt_mat_sloc[] IS NOT INITIAL AND lt_lips[] IS NOT INITIAL.
    LOOP AT lt_mat_sloc INTO DATA(ls_mat_sloc).
      DELETE lt_lips WHERE lgort = ls_mat_sloc-lgort.
    ENDLOOP.
  ENDIF.

  IF lt_lips IS NOT INITIAL.


    "Fetch Load num from OBD
    IF load_no IS INITIAL.
      IF iv_scheme EQ 'X'.
        SELECT * FROM zmm_load_sloc2 INTO TABLE lt_load_sloc2 WHERE obd_no = obd_num
                                                                AND load_status = 'I'.
        IF sy-subrc EQ 0.
          SORT lt_load_sloc2 DESCENDING BY load_no.
          READ TABLE lt_load_sloc2 INTO ls_load_sloc2 INDEX 1.
          IF sy-subrc EQ 0.
            load_no = ls_load_sloc2-load_no.
            DELETE lt_load_sloc2 WHERE load_no NE ls_load_sloc2-load_no.
          ENDIF.
          SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_load_sloc2
            WHERE lenum = lt_load_sloc2-su_no.
        ENDIF.
      ELSE.
        SELECT * FROM zmm_load_sloc1 INTO TABLE lt_load_sloc1 WHERE obd_no = obd_num
                                                                AND load_status = 'I'.
        IF sy-subrc EQ 0.
          SORT lt_load_sloc1 DESCENDING BY load_no.
          READ TABLE lt_load_sloc1 INTO ls_load_sloc1 INDEX 1.
          IF sy-subrc EQ 0.
            load_no = ls_load_sloc1-load_no.
            DELETE lt_load_sloc1 WHERE load_no NE ls_load_sloc1-load_no.
          ENDIF.
          SELECT * FROM zwm_su INTO TABLE lt_su FOR ALL ENTRIES IN lt_load_sloc1
            WHERE lenum = lt_load_sloc1-su_no.
        ENDIF.
      ENDIF.

    ENDIF.

    SELECT matnr aumng
      FROM mvke
      INTO CORRESPONDING FIELDS OF TABLE lt_mvke
      FOR ALL ENTRIES IN lt_lips
      WHERE matnr = lt_lips-matnr
      AND vkorg = lv_vkorg.

    SELECT * FROM mch1 INTO TABLE lt_mch1
      FOR ALL ENTRIES IN lt_lips
      WHERE matnr = lt_lips-matnr
        AND charg = lt_lips-charg.

  ENDIF.

  IF iv_scheme EQ 'X'.
    LOOP AT lt_lips INTO ls_lips_grp GROUP BY ( matnr = ls_lips_grp-matnr ).
      ls_list-item_number = ls_lips_grp-vgpos.
      ls_list-material    = ls_lips_grp-matnr.
      ls_list-description = ls_lips_grp-arktx.

      LOOP AT GROUP ls_lips_grp INTO ls_lips_sub.
        IF ls_lips_sub-uepvw EQ 'B' OR ls_lips_sub-pstyv EQ 'TANN' OR ls_lips_sub-cmpnt NE 'X'.
          READ TABLE ls_list-batch_list ASSIGNING <fs_batch_list> WITH KEY batch_number = ls_lips_sub-charg.
          IF sy-subrc EQ 0.
            lv_qty = <fs_batch_list>-qty + ceil( ls_lips_sub-lfimg ).

            lv_str1 = <fs_batch_list>-qty.
            lv_str2 = ceil( ls_lips_sub-lfimg ).
            CONDENSE lv_str2.
            CONCATENATE lv_str1 '+' lv_str2 INTO lv_str1.
            CONDENSE lv_str1 NO-GAPS.
            <fs_batch_list>-qty = lv_str1.

            READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_lips_sub-matnr.
            IF sy-subrc EQ 0 AND ls_mvke-aumng IS NOT INITIAL.
*              <fs_batch_list>-req_boxes = <fs_batch_list>-req_boxes + ceil( ls_lips_sub-lfimg / ls_mvke-aumng ).
              <fs_batch_list>-req_boxes = ceil( lv_qty / ls_mvke-aumng ).
              IF <fs_batch_list>-req_boxes EQ <fs_batch_list>-scanned_boxes.
                <fs_batch_list>-status = 'C'.
              ELSE.
                <fs_batch_list>-status = ''.
              ENDIF.
            ENDIF.
          ENDIF.
        ELSE.
          ls_batch_list-batch_number = ls_lips_sub-charg.
          READ TABLE lt_mch1 INTO ls_mch1 WITH KEY matnr = ls_lips_sub-matnr
                                                   charg = ls_lips_sub-charg.
          IF sy-subrc EQ 0.
            IF ls_mch1-vfdat LE lv_date. "OR ls_mch1-vfdat GT lv_date.
              ls_batch_exp-material     = ls_mch1-matnr.
              ls_batch_exp-batch_number = ls_mch1-charg.
              ls_batch_exp-expiry_date  = ls_mch1-vfdat.
              APPEND ls_batch_exp TO et_batch_exp.
              CLEAR: ls_batch_exp.
            ENDIF.
          ENDIF.
*          READ TABLE lt_ltap INTO ls_ltap WITH KEY charg = ls_lips_sub-charg.
*          IF sy-subrc EQ 0.
*            ls_batch_list-bin_number = ls_ltap-charg.
*          ENDIF.
*          ls_batch_list-bin_number   = ls_lips_sub-lgpla.
          ls_batch_list-qty          = ceil( ls_lips_sub-lfimg ).
          CONDENSE ls_batch_list-qty.
          ls_batch_list-uom          = ls_lips_sub-meins.

          READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_lips_sub-matnr.
          IF sy-subrc EQ 0.
            ls_batch_list-req_boxes = ceil( ls_lips_sub-lfimg / ls_mvke-aumng ).
          ENDIF.

          IF lt_load_sloc2 IS NOT INITIAL.
            LOOP AT lt_load_sloc2 INTO ls_load_sloc2 WHERE matnr = ls_lips_grp-matnr
                                                       AND batch_no = ls_lips_sub-charg.

              READ TABLE ls_batch_list-scanned_list TRANSPORTING NO FIELDS WITH KEY su_no = ls_load_sloc2-su_no.
              IF sy-subrc NE 0.
                READ TABLE lt_su INTO ls_su WITH KEY lenum = ls_load_sloc2-su_no.
                IF sy-subrc EQ 0.
                  ls_scanned_list-pallet_no = ls_su-palletno.
                ENDIF.
                ls_scanned_list-su_no     = ls_load_sloc2-su_no.
                ls_scanned_list-delete_button     = 'D'.
                ls_batch_list-scanned_boxes = ls_batch_list-scanned_boxes + 1.
                IF ls_batch_list-scanned_boxes EQ ls_batch_list-req_boxes.
                  ls_batch_list-status = 'C'.
                ELSE.
                  ls_batch_list-status = ''.
                ENDIF.

                APPEND ls_scanned_list TO ls_batch_list-scanned_list.
                CLEAR: ls_scanned_list.
              ENDIF.
            ENDLOOP.
          ENDIF.

          APPEND ls_batch_list TO ls_list-batch_list.
          CLEAR ls_batch_list.
        ENDIF.
      ENDLOOP.

      APPEND ls_list TO et_list.
      CLEAR: ls_list.
    ENDLOOP.

  ELSE.
*    LOOP AT lt_lips INTO ls_lips_grp GROUP BY ( vgpos = ls_lips_grp-vgpos
*                                                matnr = ls_lips_grp-matnr ).
    LOOP AT lt_lips INTO ls_lips_grp GROUP BY ( matnr = ls_lips_grp-matnr ).
      ls_list-item_number = ls_lips_grp-vgpos.
      ls_list-material    = ls_lips_grp-matnr.
      ls_list-description = ls_lips_grp-arktx.

      LOOP AT GROUP ls_lips_grp INTO ls_lips_sub.
        READ TABLE ls_list-batch_list ASSIGNING <fs_batch_list> WITH KEY batch_number = ls_lips_sub-charg.
        IF sy-subrc EQ 0.
          <fs_batch_list>-qty = ceil( <fs_batch_list>-qty + ls_lips_sub-lfimg ).

          READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_lips_sub-matnr.
          IF sy-subrc EQ 0 AND ls_mvke-aumng IS NOT INITIAL.
            <fs_batch_list>-req_boxes = <fs_batch_list>-req_boxes + ceil( ls_lips_sub-lfimg / ls_mvke-aumng ).
            IF <fs_batch_list>-req_boxes EQ <fs_batch_list>-scanned_boxes.
              <fs_batch_list>-status = 'C'.
            ELSE.
              <fs_batch_list>-status = ''.
            ENDIF.
          ENDIF.
        ELSE.
          ls_batch_list-batch_number = ls_lips_sub-charg.
          READ TABLE lt_mch1 INTO ls_mch1 WITH KEY matnr = ls_lips_sub-matnr
                                                   charg = ls_lips_sub-charg.
          IF sy-subrc EQ 0.
            IF ls_mch1-vfdat LE lv_date. "OR ls_mch1-vfdat GT lv_date.
              ls_batch_exp-material     = ls_mch1-matnr.
              ls_batch_exp-batch_number = ls_mch1-charg.
              ls_batch_exp-expiry_date  = ls_mch1-vfdat.
              APPEND ls_batch_exp TO et_batch_exp.
              CLEAR: ls_batch_exp.
            ENDIF.
          ENDIF.
*        READ TABLE lt_ltap INTO ls_ltap WITH KEY charg = ls_lips_sub-charg.
*        IF sy-subrc EQ 0.
*          ls_batch_list-bin_number = ls_ltap-charg.
*        ENDIF.
*        ls_batch_list-bin_number   = ls_lips_sub-lgpla.
          ls_batch_list-qty          = ceil( ls_lips_sub-lfimg ).
          CONDENSE ls_batch_list-qty.
          ls_batch_list-uom          = ls_lips_sub-meins.

          READ TABLE lt_mvke INTO ls_mvke WITH KEY matnr = ls_lips_sub-matnr.
          IF sy-subrc EQ 0 AND ls_mvke-aumng IS NOT INITIAL.
            ls_batch_list-req_boxes = ceil( ls_lips_sub-lfimg / ls_mvke-aumng ).
          ENDIF.

          IF lt_load_sloc1 IS NOT INITIAL.
            LOOP AT lt_load_sloc1 INTO ls_load_sloc1 WHERE matnr = ls_lips_grp-matnr
                                                       AND batch_no = ls_lips_sub-charg.
              READ TABLE lt_su INTO ls_su WITH KEY lenum = ls_load_sloc1-su_no.
              IF sy-subrc EQ 0.
                ls_scanned_list-pallet_no = ls_su-palletno.
              ENDIF.
              ls_scanned_list-su_no     = ls_load_sloc1-su_no.
              ls_scanned_list-delete_button     = 'D'.
              ls_batch_list-scanned_boxes = ls_batch_list-scanned_boxes + 1.
              IF ls_batch_list-scanned_boxes EQ ls_batch_list-req_boxes.
                ls_batch_list-status = 'C'.
              ENDIF.

              APPEND ls_scanned_list TO ls_batch_list-scanned_list.
              CLEAR: ls_scanned_list.
            ENDLOOP.
          ENDIF.

          APPEND ls_batch_list TO ls_list-batch_list.
          CLEAR ls_batch_list.

        ENDIF.
      ENDLOOP.

      APPEND ls_list TO et_list.
      CLEAR: ls_list.
    ENDLOOP.

  ENDIF.


ENDFUNCTION.
