*&---------------------------------------------------------------------*
*&  Include           ZWM_LOAD_WO_SCHEME_STATUS_8O05
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8005  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8005 INPUT.
  DATA: lv_total_qty1 TYPE menge_d,
**********Added as per zmm_load
        lv_amt        TYPE menge_d,
**********Added as per zmm_load
        lt_8005x_tmp  TYPE TABLE OF ty_sloc,
        lw_8005x_tmp  TYPE ty_sloc,
        lw_lqua_tmp1  TYPE lqua.

  CASE sy-ucomm.
    WHEN 'BACK'.
      FREE: lt_8005,cnt5,load_no.
      CLEAR: lw_lips-matnr,wa_lqua.
      "FREE: lt_8004,it_lqua.
      FREE: obd_no,lin_item,gw_lenum,barcode_scan,cnt,barcode_scan1,cnt5.
      CLEAR : lw_lips,lw_sloc8005.
      LEAVE TO SCREEN 8000.
*      CALL SCREEN 8000.

    WHEN 'NEXTV'.
      line805 = line805 + lines805.
      limit805 = fill805 - lines805.
      IF line805 > limit805.
        line805 = limit805.
      ENDIF.
    WHEN 'PREVV'.
      line805 = line805 - lines805. "1.
      IF line805 < 0.
        line805 = 0.
      ENDIF.
    WHEN 'ENTER'.
*      FREE: it_lqua.
      IF load_no IS NOT INITIAL AND su_no IS INITIAL.
        FREE : lw_8005, cnt5,lv_total_qty1,lt_8005,lv_total_qty,lt_sloc.
        SELECT obd_no obd_lineitem  obd_headitem  matnr batch_no
           su_no quantity  su_qty FROM zmm_load_sloc1
          INTO TABLE lt_sloc
          WHERE load_no = load_no.
        IF sy-subrc = 0 AND lt_sloc IS NOT INITIAL.

          SELECT vbeln posnr matnr lgort charg
          lfimg meins  uepos lgpla uecha uepvw FROM lips
          INTO TABLE lt_lips
            FOR ALL ENTRIES IN lt_sloc
          WHERE vbeln = lt_sloc-obd_no.
*          and uecha = obd_lineitem-posnr.
          IF sy-subrc = 0.

          ENDIF.

          LOOP AT lt_sloc INTO lw_sloc.
            lw_8005-lenum = lw_sloc-lenum.
            lw_8005-su_qty = lw_sloc-su_qty.
            lw_8005-charg  = lw_sloc-charg.
            lw_8005-matnr  = lw_sloc-matnr.

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
              EXPORTING
                input  = lw_8005-lenum
              IMPORTING
                output = lw_8005-lenum.
            APPEND lw_8005 TO lt_8005.
            CLEAR: lw_8005,lw_sloc.
            cnt5 = cnt5 + 1.
          ENDLOOP.

          lt_8005x_tmp =  lt_8005x.
          SORT lt_8005x_tmp BY lenum.
          DELETE ADJACENT DUPLICATES FROM lt_8005x_tmp COMPARING lenum.

          LOOP AT lt_8005x_tmp INTO lw_8005x_tmp.
            READ TABLE lt_8005 WITH KEY lenum = lw_8005x_tmp-lenum TRANSPORTING NO FIELDS.
            IF sy-subrc <> 0.

              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = lw_8005x_tmp-lenum
                IMPORTING
                  output = lw_8005x_tmp-lenum.

              APPEND lw_8005x_tmp TO lt_8005.
              cnt5 = cnt5 + 1.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
      IF barcode_scan1 IS NOT INITIAL.
        FREE: amt,su_no, lv_total_qty,lw_lips,wa_lqua.
        SPLIT barcode_scan1 AT space INTO lv_mat su_no.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = lv_mat
          IMPORTING
            output = lv_mat.

        IF lv_mat IS INITIAL.
*          SET CURSOR FIELD 'BARCODE_SCAN1'.
*          CLEAR: barcode_scan1.
          MESSAGE 'Material is blank' TYPE 'I'.
          RETURN.
        ENDIF.
        READ TABLE lt_8005 INTO lw_8005 WITH KEY lenum = su_no.
        IF sy-subrc NE 0.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = su_no
            IMPORTING
              output = su_no.

          SELECT SINGLE lenum  FROM lein
                           INTO @DATA(v_lein1)
                     WHERE lenum = @su_no.
          IF sy-subrc <> 0.
*            SET CURSOR FIELD 'BARCODE_SCAN1'.
*            CLEAR: barcode_scan1.
            MESSAGE 'Storage Unit Doesnot exist' TYPE 'I'.
            RETURN.
          ENDIF.
          CLEAR : lw_lqua_tmp1.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*          SELECT SINGLE * FROM lqua INTO lw_lqua_tmp1 WHERE matnr = lv_mat
*                                       AND lenum = su_no.

SELECT * FROM LQUA INTO LW_LQUA_TMP1 UP TO 1 ROWS WHERE MATNR = LV_MAT
 AND LENUM = SU_NO
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix

          IF sy-subrc = 0.
            SELECT COUNT(*) FROM lqua "FOR ALL ENTRIES IN lt_8005
            WHERE charg = lw_lqua_tmp1-charg " lt_8005-charg
            AND lenum = su_no.
            IF sy-subrc NE 0.
              SET CURSOR FIELD 'BARCODE_SCAN1'.
              CLEAR: barcode_scan1.
              MESSAGE 'Wrong Batch Selected.' TYPE 'I'.
            ELSE.
              SELECT matnr charg lgtyp lgpla verme lenum lgort vfdat FROM lqua
              APPENDING TABLE it_lqua WHERE lenum = su_no.
              IF sy-subrc = 0.
                SORT it_lqua BY charg matnr lenum ASCENDING.
                DELETE ADJACENT DUPLICATES FROM it_lqua COMPARING charg matnr lenum .
                CLEAR: wa_lqua_tmp.

                READ TABLE it_lqua INTO wa_lqua_tmp
                WITH KEY lenum = su_no.

*                LOOP AT it_lqua INTO wa_lqua WHERE charg = wa_lqua_tmp-charg.

                LOOP AT lt_lips INTO lw_lips  WHERE matnr =  lv_mat "wa_lqua-matnr
                                              AND   charg = wa_lqua_tmp-charg.
                  amt =  amt + lw_lips-lfimg.
                ENDLOOP.
                CLEAR: lv_total_qty1,lv_total_qty.
                LOOP AT lt_sloc INTO lw_sloc WHERE matnr =  lv_mat
                                                 AND charg = wa_lqua_tmp-charg
                                                 AND obd_lineitem = lw_lips-posnr.
                  lv_total_qty1 =  lv_total_qty1 + lw_sloc-su_qty.
                  obd_no = lw_sloc-obd_no.
                ENDLOOP.

                CLEAR: wa_lqua.
                LOOP AT it_lqua INTO wa_lqua WHERE matnr =  lv_mat
                                             AND charg = wa_lqua_tmp-charg.
                  READ TABLE lt_sloc INTO lw_sloc WITH KEY lenum = wa_lqua-lenum
                                                           matnr =  lv_mat
                                                           charg = wa_lqua_tmp-charg.
                  IF sy-subrc <> 0.
                    lv_total_qty =  lv_total_qty + wa_lqua-verme.
                  ENDIF.
                ENDLOOP.

                lv_total_qty1 = lv_total_qty1 + lv_total_qty.

                gv_obd_no = obd_no.

                CLEAR : lw_8005,wa_lqua.
*                SORT lt_8002 BY batch_no ASCENDING.
*                READ TABLE lt_8002 INTO lw_8002
*                WITH KEY batch_no = wa_lqua-charg BINARY SEARCH.
                IF lv_total_qty1 LE amt  ."lw_8002-qty. " changes done on 13.04.2019.
                  """"""""""""""""""added by akshay dt.11.08.2025
*                  DATA:answer.
*                  DATA:lv_chk_days TYPE i.
*                  DATA: lv_self_exp_msg(255) TYPE c.
                  CLEAR:answer,lv_self_exp_msg.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*                  SELECT SINGLE  low FROM tvarvc INTO lv_days WHERE name = 'ZWM_SELF_LIFE' AND type = 'P'.

SELECT LOW FROM TVARVC INTO LV_DAYS UP TO 1 ROWS WHERE NAME = 'ZWM_SELF_LIFE' AND TYPE = 'P'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

                  IF lv_days IS NOT INITIAL.
                    CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
                      EXPORTING
                        begda = sy-datum
                        endda = wa_lqua_tmp-vfdat
                      IMPORTING
                        days  = lv_chk_days.
                    IF lv_chk_days LT lv_days.
                      CONCATENATE '"The batch expiry date is less than' lv_days 'days. Do you want to proceed with posting?"' INTO lv_self_exp_msg SEPARATED BY space.
                    ENDIF.

                    IF lv_self_exp_msg IS NOT INITIAL.

                      CALL FUNCTION 'POPUP_TO_CONFIRM'
                        EXPORTING
                          titlebar       = 'Self life Notification'
                          text_question  = lv_self_exp_msg "'"The batch expiry date is less than 90 days. Do you want to proceed with posting?"'
                          text_button_1  = 'YES'
                          text_button_2  = 'NO'
                          default_button = '1'
*                         display_cancel_button = 'X'
                        IMPORTING
                          answer         = answer
                        EXCEPTIONS
                          text_not_found = 1
                          OTHERS         = 2.
                      IF sy-subrc <> 0.
                        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
                      ENDIF.

                      IF answer = '1'.
                        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                          EXPORTING
                            input  = su_no
                          IMPORTING
                            output = su_no.
                        lw_8005-charg = wa_lqua_tmp-charg ."wa_lqua-charg.
                        lw_8005-lenum = su_no.
                        lw_8005-matnr  = lv_mat.
                        lw_8005-qty   = wa_lqua_tmp-verme ."wa_lqua-verme.
                        APPEND lw_8005 TO lt_8005.
                        APPEND lw_8005 TO lt_8005x.

                        CLEAR : lw_8005, su_no.
                        cnt5 = cnt5 + 1.
                      ELSE.
                        MESSAGE 'Transaction Cancel' TYPE 'I'.
                      ENDIF.
                    ELSE.
                      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                        EXPORTING
                          input  = su_no
                        IMPORTING
                          output = su_no.
                      lw_8005-charg = wa_lqua_tmp-charg ."wa_lqua-charg.
                      lw_8005-lenum = su_no.
                      lw_8005-matnr  = lv_mat.
                      lw_8005-qty   = wa_lqua_tmp-verme ."wa_lqua-verme.
                      APPEND lw_8005 TO lt_8005.
                      APPEND lw_8005 TO lt_8005x.

                      CLEAR : lw_8005, su_no.
                      cnt5 = cnt5 + 1.
                    ENDIF.
                  ELSE.
                    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                      EXPORTING
                        input  = su_no
                      IMPORTING
                        output = su_no.
                    lw_8005-charg = wa_lqua_tmp-charg ."wa_lqua-charg.
                    lw_8005-lenum = su_no.
                    lw_8005-matnr  = lv_mat.
                    lw_8005-qty   = wa_lqua_tmp-verme ."wa_lqua-verme.
                    APPEND lw_8005 TO lt_8005.
                    APPEND lw_8005 TO lt_8005x.

                    CLEAR : lw_8005, su_no.
                    cnt5 = cnt5 + 1.
                  ENDIF.
                  """""end co changes dt.11.08.2025


                  """""commented by akshay dt.11.08.2025
*                  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
*                    EXPORTING
*                      input  = su_no
*                    IMPORTING
*                      output = su_no.
*                  lw_8005-charg = wa_lqua_tmp-charg ."wa_lqua-charg.
*                  lw_8005-lenum = su_no.
*                  lw_8005-matnr  = lv_mat.
*                  lw_8005-qty   = wa_lqua_tmp-verme ."wa_lqua-verme.
*                  APPEND lw_8005 TO lt_8005.
*                  APPEND lw_8005 TO lt_8005x.
*
*                  CLEAR : lw_8005, su_no.
*                  cnt5 = cnt5 + 1.
                  """end of comment dt.11.08.2025
                ELSE.
*                  DELETE lt_8005x WHERE lenum =  su_no.
*                  DELETE it_lqua WHERE lenum =  su_no.
                  FREE: su_no.
*                    SET CURSOR FIELD 'BARCODE_SCAN1'.
*                    CLEAR: barcode_scan1.
                  CONCATENATE 'Quantity exceeded for batch '  wa_lqua_tmp-charg INTO lv_msg SEPARATED BY space.
                  MESSAGE lv_msg TYPE 'I'.
                  RETURN.
                ENDIF.
              ENDIF.
            ENDIF.
          ELSE.
            FREE:su_no.
*              SET CURSOR FIELD 'BARCODE_SCAN1'.
*              CLEAR: barcode_scan1.
            MESSAGE 'Wrong Material Selected.' TYPE 'I'.
          ENDIF.
        ELSE.
*          SET CURSOR FIELD 'BARCODE_SCAN1'.
*          CLEAR: barcode_scan1.
          MESSAGE 'SU no. already selected.' TYPE 'I'.
        ENDIF.
      ENDIF.
      FREE: barcode_scan1.
    WHEN 'SAVE'.
      CLEAR: lt_sloc8005.
      IF lt_8005x[] IS NOT INITIAL.
        FREE:no,lw_zmm_load.
        SELECT load_no load_item obd_no obd_headitem FROM zmm_load_sloc1
        INTO TABLE lt_zmm_load
        WHERE load_no = load_no.
        DESCRIBE TABLE lt_zmm_load LINES no.

        READ TABLE lt_zmm_load INTO lw_zmm_load INDEX 1. "#EC CI_NOORDER
        IF sy-subrc = 0.
          IF lin_item = '000000' AND lw_zmm_load-obd_item IS NOT INITIAL.
            lin_item = lw_zmm_load-obd_item.
          ENDIF.
          SELECT vbeln posnr matnr lgort charg
          lfimg meins uepos lgpla uecha uepvw FROM lips
          INTO CORRESPONDING FIELDS OF TABLE lt_lips
          WHERE vbeln = lw_zmm_load-obd_no
          AND uecha = lw_zmm_load-obd_item.

          IF lt_8005 IS NOT INITIAL.
            SELECT matnr werks charg lenum verme lgpla lgort
             FROM lqua INTO TABLE lt_lqua
             FOR ALL ENTRIES IN lt_8005
              WHERE "werks = lt_8005-werks
                matnr  = lt_8005-matnr.
          ENDIF.
          IF sy-subrc = 0 .
*           READ TABLE lt_lips INTO lw_lips INDEX 1.
            LOOP AT lt_8005x INTO lw_8005x.
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                EXPORTING
                  input  = lw_8005x-lenum
                IMPORTING
                  output = lw_8005x-lenum.
              CLEAR : lw_lqua.
              READ TABLE lt_lqua INTO lw_lqua
              WITH KEY lenum = lw_8005x-lenum.
              IF sy-subrc = 0.
                READ TABLE lt_lips INTO lw_lips WITH KEY matnr = lw_lqua-matnr
                                                         charg = lw_lqua-charg
                                                         lgort = lw_lqua-lgort.
                IF sy-subrc = 0.

                  IF gv_obd_no IS INITIAL.
                    gv_obd_no = lw_lips-vbeln.
                    lin_item = lw_lips-uecha.
                  ENDIF.
                ENDIF.
              ENDIF.
              no = no + 1.
              lw_sloc8005-load_no       = load_no.
              lw_sloc8005-load_item     = no.
              lw_sloc8005-su_no         = lw_8005x-lenum.
              lw_sloc8005-obd_no        = gv_obd_no."obd_no.
              lw_sloc8005-obd_lineitem  = lw_lips-posnr.
              lw_sloc8005-obd_headitem  = lin_item.
              lw_sloc8005-entry_date    = sy-datum.
              lw_sloc8005-storage_loc   = lw_lqua-lgort.
              lw_sloc8005-matnr         = lw_lips-matnr.
              lw_sloc8005-batch_no      = lw_lqua-charg.
              lw_sloc8005-quantity      = lw_lips-lfimg.
              lw_sloc8005-uom           = lw_lips-meins.
              lw_sloc8005-bin_loc       = lw_lqua-lgpla.
              lw_sloc8005-load_status   = 'I'.
              lw_sloc8005-plant         = lw_lqua-werks.
              lw_sloc8005-su_qty        = lw_lqua-verme.
              APPEND lw_sloc8005 TO lt_sloc8005.

              CLEAR: lw_sloc8005,lw_8005,lw_lqua,obd_no.
            ENDLOOP.

            MODIFY zmm_load_sloc1 FROM TABLE lt_sloc8005.
            COMMIT WORK AND WAIT.

            "Added by Srimathi - start
            IF sy-subrc = 0 AND lt_sloc8005[] IS NOT INITIAL.
              SELECT werks AS plant,
                      palletno AS pallet_no,
                      lenum AS su_no,
                      lgnum AS warehouse_no
                 FROM zwm_su
                 FOR ALL ENTRIES IN @lt_sloc8005
                   WHERE werks = @lt_sloc8005-plant
                     AND lenum = @lt_sloc8005-su_no
                     AND palletno NE ''
                 INTO TABLE @DATA(lt_su_upd8005).
              IF lt_su_upd8005[] IS NOT INITIAL.
                lt_mapping_upd = VALUE #( FOR ls_su_upd8005 IN lt_su_upd8005
                                          ( warehouse_type = 'Plant'
                                            warehouse_no   = ls_su_upd8005-warehouse_no
                                            pallet_no      = ls_su_upd8005-pallet_no
                                            su_no          = ls_su_upd8005-su_no )
                                        ).
                IF lt_mapping_upd[] IS NOT INITIAL.
*                  MODIFY zwm_pallet_map  FROM TABLE lt_mapping_upd.
                  DELETE zwm_pallet_map  FROM TABLE lt_mapping_upd.
                  IF sy-subrc EQ 0.
                    CALL FUNCTION 'GUID_CREATE'
                      IMPORTING
                        ev_guid_16 = lv_guid_id.

                    IF lv_guid_id IS NOT INITIAL.
                      ls_mapping_log-guid_id = lv_guid_id.
                      ls_mapping_log-obd = obd_no.
                      DESCRIBE TABLE lt_mapping_upd LINES ls_mapping_log-deletion_count.
                      ls_mapping_log-application = 'Old'.
                      ls_mapping_log-deletion_spot = 'Without Scheme Load Save 8005'.
                      ls_mapping_log-deleted_by = sy-uname.
                      ls_mapping_log-deleted_on = sy-datum.
                      ls_mapping_log-deleted_at = sy-timlo.

                      IF ls_mapping_log IS NOT INITIAL.
                        MODIFY zwm_mapping_log FROM ls_mapping_log.
                        CLEAR: ls_mapping_log.
                      ENDIF.
                      CLEAR: lv_guid_id.
                    ENDIF.
                  ENDIF.
                  CLEAR: lt_su_upd8005, lt_mapping_upd.
                ENDIF.
              ENDIF.
            ENDIF.
            "Added by Srimathi - end

***********Added as per zmm_load*********
            SELECT * FROM zmm_load_sloc INTO TABLE @DATA(it_load_db) WHERE load_no = @load_no.
            IF sy-subrc = 0.
              LOOP AT it_load_db ASSIGNING FIELD-SYMBOL(<fs_load_db>).
                DELETE zmm_load_sloc FROM <fs_load_db>." WHERE LOAD_NO = LOAD_NO.
                <fs_load_db>-load_item = sy-tabix.
              ENDLOOP.
              DELETE zmm_load_sloc FROM TABLE lt_sloc8005." WHERE LOAD_NO = LOAD_NO.
              MODIFY zmm_load_sloc FROM TABLE it_load_db.
              COMMIT WORK AND WAIT.
            ENDIF.
***********Added as per zmm_load*********

*            CLEAR:lt_sloc8005.
            MESSAGE 'Data Saved Sucessfully' TYPE 'S'.
          ENDIF.
        ENDIF.
        FREE: lt_8005x[].
      ENDIF.
    WHEN 'DELETE'.
      DATA: lt_del TYPE TABLE OF zmm_load_sloc1,
            lw_del TYPE zmm_load_sloc1.
      DATA: ans(1) TYPE c.
********Popup to confirm Start

      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          titlebar              = 'Warning Message'
          text_question         = 'Do you want to delete?'
          text_button_1         = 'Yes'
          text_button_2         = 'No'
          default_button        = '1'
          display_cancel_button = ''
        IMPORTING
          answer                = ans
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.

********Popup to confirm End
      IF  ans = 1.
        IF lt_8005[] IS NOT INITIAL.
          FREE : lt_del.
          SELECT * FROM zmm_load_sloc1
            INTO TABLE lt_del
            WHERE load_no = load_no.
          IF sy-subrc = 0.

          ENDIF.
          DATA : lv_tabix.
          CLEAR:lv_tabix.
          CLEAR cnt5.
          LOOP AT lt_8005 INTO lw_8005 WHERE cnt22 = 'X'.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = lw_8005-lenum
              IMPORTING
                output = lw_8005-lenum.
            CLEAR: lw_del.
            READ TABLE lt_del INTO lw_del WITH KEY su_no = lw_8005-lenum.
            IF sy-subrc = 0.
              DELETE zmm_load_sloc1 FROM lw_del.
              COMMIT WORK.

              "Added by Srimathi - start
              IF sy-subrc = 0 AND lw_del IS NOT INITIAL.
                SELECT werks AS plant,
                        palletno AS pallet_no,
                        lenum AS su_no,
                        lgnum AS warehouse_no
                   FROM zwm_su
                   INTO TABLE @DATA(lt_su_del8005)
                     WHERE werks = @lw_del-plant
                       AND lenum = @lw_del-su_no
                       AND palletno NE ''.
                IF lt_su_del8005[] IS NOT INITIAL.
                  lt_mapping_upd = VALUE #( FOR ls_su_del8005 IN lt_su_del8005
                                            ( warehouse_type = 'Plant'
                                              warehouse_no   = ls_su_del8005-warehouse_no
                                              pallet_no      = ls_su_del8005-pallet_no
                                              su_no          = ls_su_del8005-su_no )
                                          ).
                  IF lt_mapping_upd[] IS NOT INITIAL.
                    MODIFY zwm_pallet_map  FROM TABLE lt_mapping_upd.
*                  DELETE zwm_pallet_map  FROM TABLE lt_mapping_upd.
                    CLEAR: lt_su_upd8005, lt_mapping_upd.
                  ENDIF.
                ENDIF.
              ENDIF.
              "Added by Srimathi - end

              lv_tabix = 'X'.
            ELSE.
              CLEAR: lv_tabix.
            ENDIF.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
              EXPORTING
                input  = lw_8005-lenum
              IMPORTING
                output = lw_8005-lenum.
            DELETE  lt_8005x WHERE lenum = lw_8005-lenum.
            DELETE  lt_lqua WHERE lenum = lw_8005-lenum.
          ENDLOOP.
          DELETE lt_8005 WHERE cnt22 = abap_true.
          DESCRIBE TABLE lt_8005 LINES cnt5.
          CONDENSE cnt5.

******** Added as per zmm_load*****

          CLEAR lw_8005.
          LOOP AT lt_8005 ASSIGNING FIELD-SYMBOL(<fs_8005>).
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = <fs_8005>-lenum
              IMPORTING
                output = <fs_8005>-lenum.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*            SELECT SINGLE matnr,charg,lgtyp,lgpla,verme ,lenum ,lgort FROM lqua
*                         INTO  @DATA(lw_lqua_db)
*                      WHERE lenum = @<fs_8005>-lenum.

SELECT MATNR , CHARG , LGTYP , LGPLA , VERME , LENUM , LGORT FROM LQUA
 INTO @DATA(LW_LQUA_DB) UP TO 1 ROWS WHERE LENUM = @<FS_8005>-LENUM
 ORDER BY PRIMARY KEY .
 ENDSELECT.
* End of Quick Fix


            IF sy-subrc = 0.
              <fs_8005>-matnr = lw_lqua_db-matnr.
              <fs_8005>-charg = lw_lqua_db-charg.
              <fs_8005>-qty = lw_lqua_db-verme.
              <fs_8005>-su_qty = ' '.
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = <fs_8005>-lenum
                IMPORTING
                  output = <fs_8005>-lenum.
            ENDIF.
          ENDLOOP.

******** Added as per zmm_load*****

          IF lv_tabix  = 'X'.
            MESSAGE 'Record Deleted successfully' TYPE 'S'.
          ENDIF.
        ENDIF.
        CLEAR: lw_8005.
      ENDIF.
    WHEN 'POST'.

      IF lt_8005x[] IS INITIAL.
        PERFORM create_tu.

        FREE: obd_no,lin_item,lt_8002,lw_8002,gw_lenum,lt_8004,lw_8004,su_cnt,barcode_scan,cnt,lw_lips-matnr,
        lt_8005,lw_8005,lv_total_qty_ltot.
        CLEAR: su_cnt,lw_lips-matnr,lw_8004,wa_lqua,lw_lips, barcode_scan1, barcode_scan.
        FREE: lt_8004,it_lqua,lt_lips.
        LEAVE TO SCREEN 8000.
      ELSE.
        MESSAGE 'Please save added SU number.' TYPE 'I'.
      ENDIF.
*      ELSE.
*        MESSAGE 'Total Quantity does not match with SU quantity.' TYPE 'I'.
*      ENDIF.
  ENDCASE.
ENDMODULE.

*&---------------------------------------------------------------------*
*&      Module  STATUS_8005  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8005 OUTPUT.
  SET PF-STATUS 'ZMM_8005'.
*  SET TITLEBAR 'xxx'.
  fill805 = cnt5.

  LOOP AT SCREEN.
    IF screen-name = 'DELETE'.
      screen-input = '0'.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.
*  IF l_step_loop_pos IS INITIAL OR l_step_loop_pos > fill805.
*    l_step_loop_pos = 1.
*  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_OUT  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_out_8005 OUTPUT.
*  DATA: lw_8005d TYPE ty_pallety.
  idx805 = sy-stepl + line805.
  READ TABLE lt_8005 INTO lw_8005 INDEX idx805.
*  IF sy-subrc = 0.
*    lw_8005 = lt_8005[ idx805 ].
*  ENDIF.
ENDMODULE.
MODULE transp_itab_in_8005 INPUT.
  lines805 = sy-loopc.
  idx805 = sy-stepl + line805.
*  READ TABLE lt_8005 INTO lw_8005 INDEX idx805.
*  IF sy-subrc = 0.
  "MODIFY lt_8005 FROM lw_8005 INDEX cnt5.   "idx805.
*  ENDIF.
*  CLEAR: lw_8005.
ENDMODULE.

FORM create_tu.
  TABLES: ltak.
  TYPES: BEGIN OF ty_pick,
           werks TYPE werks_d,
           lgort TYPE lgort_d,
           lgnum TYPE lgnum,
           lgtyp TYPE lgtyp,
           lgber TYPE lgber,
         END OF ty_pick,

         BEGIN OF ty_lein,
           lenum TYPE  lenum,
           lgnum TYPE  lgnum,
           letyp TYPE lvs_letyp,
           lgtyp TYPE lgtyp,
           lgpla TYPE lgpla,
         END OF ty_lein.

  DATA lw_qty TYPE zmm_load_sloc1.
  DATA: it_load_sloc      TYPE STANDARD TABLE OF zmm_load_sloc1,
        wa_load_sloc      TYPE zmm_load_sloc1,
        it_load_slocx     TYPE STANDARD TABLE OF zmm_load_sloc1,
        it_load_slocx_tmp TYPE STANDARD TABLE OF zmm_load_sloc1,
        wa_load_slocx     TYPE zmm_load_sloc1,
        it_picklist       TYPE STANDARD TABLE OF ty_pick,
        wa_picklist       TYPE ty_pick,
        it_lein           TYPE STANDARD TABLE OF ty_lein,
        wa_lein           TYPE ty_lein.

  DATA: it_delit     TYPE l03b_delit_t,
        wa_delit     LIKE LINE OF it_delit,
        it_ltak      TYPE STANDARD TABLE OF ltak_vb,
        it_wmgrp_msg TYPE STANDARD TABLE OF wmgrp_msg,
        it_ltap      TYPE STANDARD TABLE OF  ltap_vb , "ltap_conf,
        it_ltap_temp TYPE STANDARD TABLE OF  ltap_vb , "ltap_conf,
        wa_ltap_temp TYPE ltap_vb,
        lw_ltap1_tmp TYPE  ltap_vb,
        lv_flag      TYPE c,
        lv_flag_ex   TYPE c,
        wa_ltap      LIKE LINE OF it_ltap.


  DATA :gv_text TYPE char100,
        v_tanum TYPE char10.
  FIELD-SYMBOLS: <lfs_load_sloc>  LIKE LINE OF it_load_sloc,
                 <lfs_load_slocx> LIKE LINE OF it_load_slocx.

  DATA: lv_tanum TYPE ltak-tanum,
        lv_teilk TYPE t340d-teilv,
        flag     TYPE c,
        lv_tabix TYPE i,
        row      TYPE i,
        lv_vbeln TYPE vbeln,
        lv_msg   TYPE string.
  CONSTANTS load_status TYPE c VALUE 'W'.
  DATA :it_ltap_conf  TYPE STANDARD TABLE OF ltap_conf,
        lw_ltap1_tmp1 TYPE ltap_conf.
  DATA su_qty TYPE menge_d.
  DATA total_del_qty TYPE lips-lfimg.

  gv_text = 'TO created and confirmed with no'.

  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = load_no
    IMPORTING
      output = load_no.

  CLEAR:it_load_sloc, it_picklist.

  IF load_no IS NOT INITIAL.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*    SELECT * FROM zmm_load_sloc1 INTO TABLE it_load_sloc
*    WHERE load_no = load_no
*    AND   load_status IN ('I', 'W')
*    AND to_no       = ' '.

SELECT * FROM zmm_load_sloc1 INTO TABLE it_load_sloc
    WHERE load_no = load_no
    AND   load_status IN ('I', 'W')
    AND to_no       = ' ' ORDER BY PRIMARY KEY .

* End of Quick Fix


  ENDIF.

  CLEAR lw_qty.
  READ TABLE it_load_sloc INTO lw_qty INDEX 1. "#EC CI_NOORDER

  IF sy-subrc = 0 AND it_load_sloc IS NOT INITIAL.
    SELECT werks lgort lgnum lgtyp lgber FROM zwm_picklist
                                         INTO TABLE it_picklist
                                         FOR ALL ENTRIES IN it_load_sloc
                                         WHERE werks = it_load_sloc-plant.

    IF it_load_sloc IS NOT INITIAL.
      SELECT lenum lgnum letyp lgtyp lgpla FROM lein
                                     INTO TABLE it_lein
                                     FOR ALL ENTRIES IN it_load_sloc
                                     WHERE lenum = it_load_sloc-su_no.

      it_load_slocx = it_load_sloc.
      DELETE ADJACENT DUPLICATES FROM it_load_sloc COMPARING load_no.
    ENDIF.


    SORT: it_load_sloc BY load_no,
          it_load_slocx BY load_no.

    CLEAR: lv_vbeln.
    LOOP AT it_load_slocx  ASSIGNING <lfs_load_slocx>.
      IF sy-tabix = 1.
        lv_vbeln = <lfs_load_slocx>-obd_no.
      ENDIF.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <lfs_load_slocx>-su_no
        IMPORTING
          output = <lfs_load_slocx>-su_no.

      su_qty = su_qty + <lfs_load_slocx>-su_qty.

      READ TABLE it_picklist INTO wa_picklist
      WITH KEY werks = <lfs_load_slocx>-plant.


      READ TABLE it_lein INTO wa_lein
      WITH KEY lenum = <lfs_load_slocx>-su_no.
      IF sy-subrc = 0.
        wa_ltap-letyp  =  wa_lein-letyp.
        wa_ltap-lgnum  =  wa_lein-lgnum.
        wa_ltap-vlber  =  wa_picklist-lgber.
        wa_ltap-posnr = <lfs_load_slocx>-obd_lineitem.
      ENDIF.
      wa_delit-posnr = <lfs_load_slocx>-obd_lineitem.
      wa_delit-anfme = <lfs_load_slocx>-su_qty.
      wa_delit-altme = <lfs_load_slocx>-uom.
      wa_delit-charg = <lfs_load_slocx>-batch_no.

      wa_delit-letyp  =  wa_lein-letyp.
      wa_delit-vltyp =  wa_lein-lgtyp.
      wa_delit-vlpla = <lfs_load_slocx>-bin_loc.
      wa_delit-vlber  = wa_picklist-lgber.
*      wa_delit-vlenr = <lfs_load_slocx>-su_no.
      UNPACK <lfs_load_slocx>-su_no TO wa_delit-vlenr.
      APPEND wa_delit TO it_delit.
      row = row + 1.
      wa_ltap-tapos = row.
      wa_ltap-altme = <lfs_load_slocx>-uom.
      wa_ltap-charg = <lfs_load_slocx>-batch_no.

      wa_ltap-vltyp =  wa_lein-lgtyp.
      wa_ltap-letyp = wa_lein-letyp.
      wa_ltap-vlpla = <lfs_load_slocx>-bin_loc.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = <lfs_load_slocx>-su_no
        IMPORTING
          output = <lfs_load_slocx>-su_no.
      wa_ltap-matnr  = <lfs_load_slocx>-matnr.
      wa_ltap-sonum = <lfs_load_slocx>-su_no.
      wa_ltap-nista = <lfs_load_slocx>-su_qty.
      APPEND wa_ltap TO it_ltap.

    ENDLOOP.

    CLEAR it_load_slocx_tmp.
    it_load_slocx_tmp = it_load_slocx.
    SORT it_load_slocx_tmp BY matnr batch_no.
    IF p_status = ' '.
      DELETE ADJACENT DUPLICATES FROM it_load_slocx_tmp COMPARING matnr batch_no.
    ENDIF.
    LOOP AT it_load_slocx_tmp ASSIGNING FIELD-SYMBOL(<fs_ltap_temp>).

      IF <fs_ltap_temp> IS ASSIGNED.
        total_del_qty = total_del_qty + <fs_ltap_temp>-quantity.
      ENDIF.

    ENDLOOP.
    CLEAR: lv_flag.
    CLEAR :lv_total_qty_ltot.
************Code commented as per zmm_load
    SELECT vbeln posnr lfimg uecha FROM lips INTO CORRESPONDING FIELDS OF TABLE lt_lips
      WHERE  vbeln = lv_vbeln
      AND uecha =  lw_qty-obd_headitem.
    IF sy-subrc = 0.
      LOOP AT lt_lips INTO lw_lips. " WHERE uecha = lw_qty-obd_headitem.
        lv_total_qty_ltot  = lv_total_qty_ltot + lw_lips-lfimg.
      ENDLOOP.
    ENDIF.
************Code commented as per zmm_load
************Code added as per zmm_load
*    lv_total_qty_ltot  = total_del_qty.
************Code added as per zmm_load
    IF su_qty NE lv_total_qty_ltot. "total_del_qty.
      lv_flag  = 'X'.
      UPDATE zmm_load_sloc1 SET
      err_msg   = 'Del Qty didnt Match with total SU Qty.'
      load_status    = 'I'
      WHERE load_no = load_no.
      COMMIT WORK AND WAIT.
*      SET CURSOR FIELD 'BARCODE_SCAN1'.
*      CLEAR: barcode_scan1.
      MESSAGE 'Delivery quantity not equal to box qty.' TYPE 'E'.
    ENDIF.

    """"""""""""""""""added by akshay dt.16.07.2025

***    DATA:answer.
***    DATA:lv_chk_days TYPE i.
***    DATA: lv_self_exp_msg(255) TYPE c.
***    CLEAR:answer,lv_self_exp_msg,lv_flag_ex.
***    SELECT SINGLE  low FROM tvarvc INTO @DATA(lv_days) WHERE name = 'ZWM_SELF_LIFE' AND type = 'P'.
***    IF lv_days IS NOT INITIAL.
***      LOOP AT it_ltap INTO wa_ltap_temp.
***        CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
***          EXPORTING
***            begda = sy-datum
***            endda = wa_ltap_temp-vfdat
***          IMPORTING
***            days  = lv_chk_days.
***        IF lv_chk_days LT lv_days.
***          CONCATENATE '"The batch expiry date is less than' lv_days 'days. Do you want to proceed with posting?"' INTO lv_self_exp_msg SEPARATED BY space.
***        ENDIF.
***        CLEAR: wa_ltap_temp.
***      ENDLOOP.
***
***      IF lv_self_exp_msg IS NOT INITIAL.
***
***        CALL FUNCTION 'POPUP_TO_CONFIRM'
***          EXPORTING
***            titlebar       = 'Self life Notification'
***            text_question  = lv_self_exp_msg "'"The batch expiry date is less than 90 days. Do you want to proceed with posting?"'
***            text_button_1  = 'YES'
***            text_button_2  = 'NO'
***            default_button = '1'
****           display_cancel_button = 'X'
***          IMPORTING
***            answer         = answer
***          EXCEPTIONS
***            text_not_found = 1
***            OTHERS         = 2.
***        IF sy-subrc <> 0.
***          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
***                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
***        ENDIF.
***
***        IF answer = '1'.
***          lv_flag_ex = abap_true.
***        ELSE.
***          MESSAGE 'Transaction Cancel' TYPE 'I'.
***        ENDIF.
***      ELSE.
***        lv_flag_ex = abap_true.
***      ENDIF.
***    ELSE.
***      lv_flag_ex = abap_true.
***    ENDIF.

    """"""""""""""""""eoc dt.16.07.2025

    IF it_ltap IS NOT INITIAL AND lv_flag IS INITIAL."""commented by akshay dt.16.07.2025
*    IF ( it_ltap IS NOT INITIAL AND lv_flag IS INITIAL AND lv_flag_ex IS NOT INITIAL )."""added by akshay dt.16.07.2025
      CALL FUNCTION 'L_TO_CREATE_DN'
        EXPORTING
          i_lgnum                    = wa_picklist-lgnum
          i_vbeln                    = lv_vbeln "<lfs_load_slocx>-obd_no
          i_commit_work              = 'X'
          i_bname                    = sy-uname
          i_solex                    = total_del_qty
          it_delit                   = it_delit
        IMPORTING
          e_tanum                    = lv_tanum
          e_teilk                    = lv_teilk
        TABLES
          t_ltak                     = it_ltak
          t_ltap_vb                  = it_ltap
          t_wmgrp_msg                = it_wmgrp_msg
        EXCEPTIONS
          foreign_lock               = 1
          dn_completed               = 2
          partial_delivery_forbidden = 3
          xfeld_wrong                = 4
          ldest_wrong                = 5
          drukz_wrong                = 6
          dn_wrong                   = 7
          squit_forbidden            = 8
          no_to_created              = 9
          teilk_wrong                = 10
          update_without_commit      = 11
          no_authority               = 12
          no_picking_allowed         = 13
          dn_hu_not_choosable        = 14
          input_error                = 15
          OTHERS                     = 16.
      IF sy-subrc = 0.
        flag = 'X'.
        CLEAR: wa_ltap.
      ELSE.
        CLEAR: lv_msg.
        CALL FUNCTION 'FORMAT_MESSAGE'
          EXPORTING
            id        = sy-msgid
            lang      = '-D'
            no        = sy-msgno
            v1        = sy-msgv1
            v2        = sy-msgv2
            v3        = sy-msgv3
            v4        = sy-msgv4
          IMPORTING
            msg       = lv_msg
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
        CLEAR flag.

        UPDATE zmm_load_sloc1 SET
          err_msg        = lv_msg
          to_create_date = sy-datum
          load_status    = 'I'
          WHERE load_no = load_no.
*        SET CURSOR FIELD 'BARCODE_SCAN1'.
*        CLEAR: barcode_scan1.
        MESSAGE lv_msg TYPE 'E'.
      ENDIF.

***********************************************************
*BDC for confirming created TO.
***********************************************************
      CLEAR:lt_messtab.
      IF wa_picklist-lgnum IS NOT INITIAL AND flag = 'X' AND lv_tanum IS NOT INITIAL.
        PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
              'LTAK-TANUM'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
              '/00'.
        PERFORM bdc_field       USING 'LTAK-TANUM'
                                        lv_tanum.
        PERFORM bdc_field       USING 'LTAK-LGNUM'
                                       wa_picklist-lgnum.

        PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
        PERFORM bdc_field       USING 'BDC_CURSOR'
              'LTAK-LGNUM'.
        PERFORM bdc_field       USING 'BDC_OKCODE'
              '=BU'.
        CALL TRANSACTION 'LT12' USING it_bdcdata
               MESSAGES INTO lt_messtab MODE 'N' UPDATE 'S'.

        CLEAR it_bdcdata.
        CLEAR wa_bdcdata.
*        CALL FUNCTION 'L_TO_CONFIRM'
*          EXPORTING
*            i_lgnum     = wa_picklist-lgnum
*            i_tanum     = lv_tanum
*            i_qname     = sy-uname
**           i_commit_work = 'X'
*          TABLES
*            t_ltap_conf = it_ltap_conf.

        CLEAR:lw_messtab,lv_msg.
        READ TABLE lt_messtab INTO lw_messtab WITH KEY msgtyp = 'E' .
        IF sy-subrc = 0.
          CALL FUNCTION 'FORMAT_MESSAGE'
            EXPORTING
              id        = lw_messtab-msgid
              lang      = '-D'
              no        = lw_messtab-msgnr
              v1        = lw_messtab-msgv1
              v2        = lw_messtab-msgv2
              v3        = lw_messtab-msgv3
              v4        = lw_messtab-msgv4
            IMPORTING
              msg       = lv_msg
            EXCEPTIONS
              not_found = 1
              OTHERS    = 2.

          UPDATE zmm_load_sloc1 SET "to_no          = lv_tanum
           err_msg        = lv_msg
           to_create_date = sy-datum
           load_status    = 'I'
           WHERE load_no = load_no.
          COMMIT WORK AND WAIT.
*          SET CURSOR FIELD 'BARCODE_SCAN1'.
*          CLEAR: barcode_scan1.
          MESSAGE lv_msg TYPE 'E'.
        ELSE.
          UPDATE zmm_load_sloc1 SET to_no = lv_tanum
          err_msg        = ' '
          to_create_date = sy-datum
          load_status    = 'C'
          WHERE load_no = load_no.

*          DO 60 TIMES.
*
*          SELECT SINGLE LTAP WHERE
*
*          ENDDO.
          COMMIT WORK AND WAIT.
          FREE:it_delit[],it_bdcdata.
          CONCATENATE gv_text lv_tanum INTO gv_text SEPARATED BY space.
          MESSAGE gv_text TYPE 'S'.
        ENDIF.
        CLEAR lv_tanum.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.

FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
