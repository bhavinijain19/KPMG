*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_INITIAL_SCR
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_zsu_no FOR v_lenum OBLIGATORY.
PARAMETERS : p_print TYPE lvs_lhmng1.
****Added changes for radio button of batch or without batch by Carina Jose on 25.07.2019
PARAMETERS : p_rad1 RADIOBUTTON GROUP rd1 DEFAULT 'X',
             p_rad2 RADIOBUTTON GROUP rd1 .
****End of changes by Carina Jose on 25.07.2019
SELECTION-SCREEN END OF BLOCK b1.

"calculate the number of labels to be printed
AT SELECTION-SCREEN ON p_print.
  if s_zsu_no-high IS NOT INITIAL.
  p_print = ( s_zsu_no-high -  s_zsu_no-low ) + 1.
  elseif s_zsu_no-high IS INITIAL .
   s_zsu_no-low  = 0.
   p_print = ( s_zsu_no-high -  s_zsu_no-low ) + 1.
    ENDIF.

"display the number of labels on selection screen
AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-name = 'P_PRINT'.
      screen-input = 0.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.
