**&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Khushbu Garg
*&  Functional Consultant   :    Sachin
*&  Requirement             :    For Picklist Slip Generation
*&  Revieved By             :    Sneha
*&  Request                 :    DEVK912110
*&---------------------------------------------------------------------*
*& Report  ZWM_PICKLIST
*&
*&---------------------------------------------------------------------*
REPORT zwm_picklist.
INCLUDE zwm_picklist_top.
*----------------------------------------------------------------------*
* A. NACHRICHT (ALLGEMEIN)                                             *
*----------------------------------------------------------------------*

FORM entry USING return_code LIKE sy-subrc
                 us_screen   TYPE c.

  CLEAR retcode.
  xscreen = us_screen.
  PERFORM processing USING us_screen.
  IF retcode NE 0.
    return_code = 1.
  ELSE.
    return_code = 0.
  ENDIF.
  CLEAR : wa_header, wa_headerf ,wa_item,wa_final.
  CLEAR : wa_xvbplp,v_venum,v_finbox,v_id,v_matnr,v_maktx,v_lfimg,v_meins,v_vbelv,v_fm_name,
  v_kunnr,v_adrnr,v_vbeln,shipto_address,v_region,v_country,v_werks,plant_address,v_first,v_last,flag,v_venum.
  REFRESH : it_header, it_headerf ,it_item,it_final.

  PERFORM header_get_data.

ENDFORM.


FORM processing USING proc_screen.
  PERFORM get_data.
ENDFORM.

FORM get_data.
  CLEAR vbco3.                                              "N_457174
  vbco3-vbeln = nast-objky.
  vbco3-spras = nast-spras.
  vbco3-kunde = nast-parnr.
  vbco3-parvw = nast-parvw.
  CALL FUNCTION 'SD_PACKING_PRINT_VIEW'
    EXPORTING
      comwa     = vbco3
    IMPORTING
      vbpla_wa  = vbpla
    TABLES
      vbplk_tab = xvbplk
      vbplp_tab = xvbplp
      vbpls_tab = xvbpls
    EXCEPTIONS
      OTHERS    = 01.

ENDFORM.

*&---------------------------------------------------------------------*
*&      FORM  HEADER_GET_DATA
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM header_get_data .
*  BREAK-POINT.
  READ TABLE xvbplp INTO wa_xvbplp INDEX 1.
  MOVE wa_xvbplp-vbeln TO p_vbeln.
  p_vbeln = wa_xvbplp-vbeln.

  SELECT SINGLE wadat_ist FROM likp INTO v_dt WHERE vbeln = p_vbeln .
  IF v_dt IS INITIAL.
    SELECT SINGLE erdat FROM likp INTO v_dt WHERE vbeln = p_vbeln .
  ENDIF.
  CONCATENATE v_dt+6(2) '-' v_dt+4(2) '-' v_dt+0(4) INTO wa_headerf-deldate.
  CLEAR v_dt.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE vgbel FROM lips INTO v_vgbel WHERE vbeln = p_vbeln.

SELECT VGBEL FROM LIPS INTO V_VGBEL UP TO 1 ROWS WHERE VBELN = P_VBELN
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix

  SELECT SINGLE bstkd FROM vbkd INTO v_bstkd WHERE vbeln = v_vgbel.
*  WA_HEADERF-BSTKD = V_BSTKD.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE werks FROM lips INTO v_werks WHERE vbeln = p_vbeln.

SELECT WERKS FROM LIPS INTO V_WERKS UP TO 1 ROWS WHERE VBELN = P_VBELN
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


  wa_headerf-vbeln = p_vbeln.
  SELECT vepo~posnr vepo~vemng vepo~venum vepo~vbeln vepo~matnr makt~maktx
         FROM vepo INNER JOIN makt ON vepo~matnr = makt~matnr AND makt~spras = 'EN'
         INTO TABLE it_vepo WHERE vepo~vbeln = p_vbeln.
  IF NOT it_vepo IS INITIAL.
    SELECT vbeln posnr lfimg meins brgew arktx matnr charg lgort vgpos uecha lgnum FROM lips INTO TABLE it_lips FOR ALL ENTRIES IN it_vepo "MOD1
           WHERE vbeln = it_vepo-vbeln AND posnr = it_vepo-posnr.
  ELSE.
    SELECT vbeln posnr lfimg meins brgew arktx matnr charg lgort vgpos uecha lgnum FROM lips INTO TABLE it_lips WHERE vbeln = p_vbeln. "MOD1
  ENDIF.

*Changed by srimathi
  IF it_lips[] IS NOT INITIAL.

*    SELECT * FROM ltap INTO TABLE lt_ltap
*      FOR ALL ENTRIES IN it_lips
*      WHERE werks = v_werks
*        AND vbeln = p_vbeln
*        AND lgnum = it_lips-lgnum
*        AND vorga = 'LF'.

    SELECT * FROM mlgn INTO TABLE lt_mlgn
      FOR ALL ENTRIES IN it_lips
      WHERE matnr = it_lips-matnr
        AND lgnum = it_lips-lgnum.

  ENDIF.
*Changed by srimathi

****************  manufacture date
  REFRESH it_mcha.
  SELECT matnr charg hsdat FROM mch1 INTO TABLE it_mcha FOR ALL ENTRIES IN it_lips
         WHERE matnr = it_lips-matnr
         AND   charg = it_lips-charg.

*************

*  *    MOD1
  REFRESH it_zwm_picklist.
  SELECT werks lgort lgnum lgtyp lgber FROM zwm_picklist INTO TABLE it_zwm_picklist FOR ALL ENTRIES IN it_lips WHERE werks = v_werks
                                                                                                                     AND lgort = it_lips-lgort.
  REFRESH it_lqua.
  IF it_zwm_picklist[] IS NOT INITIAL.
    SELECT lgnum matnr werks charg lgtyp lgpla verme lgort lenum FROM lqua INTO TABLE it_lqua FOR ALL ENTRIES IN it_zwm_picklist WHERE lgnum = it_zwm_picklist-lgnum AND
                                                                                                               werks = v_werks AND
                                                                                                               lgtyp = it_zwm_picklist-lgtyp AND
                                                                                                               verme > 0 AND
                                                                                                               lgort = it_zwm_picklist-lgort.
    IF sy-subrc EQ 0.
      SORT it_lqua BY lgpla lgort.
    ENDIF.
  ENDIF.
  "delete ADJACENT DUPLICATES FROM it_lqua COMPARING lgpla lgort. MOD1

*      *    MOD1

  IF NOT it_vepo IS INITIAL.
    LOOP AT it_vepo INTO wa_vepo.
      MOVE-CORRESPONDING wa_vepo TO wa_item.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE vbelv FROM vbfa INTO wa_item-vbelv WHERE vbeln = wa_vepo-vbeln.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*SELECT VBELV FROM VBFA INTO WA_ITEM-VBELV UP TO 1 ROWS WHERE VBELN = WA_VEPO-VBELN
* ORDER BY PRIMARY KEY .
 SELECT  PRECEDINGDOCUMENT AS VBELV FROM I_SDDOCUMENTMULTILEVELPROCFLOW
INTO @WA_ITEM-VBELV  UP  TO  1  ROWS  WHERE SUBSEQUENTDOCUMENT =
@WA_VEPO-VBELN ORDER BY PRIMARY KEY.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
 ENDSELECT.

* End of Quick Fix

      SELECT SINGLE exidv FROM vekp INTO wa_item-exidv WHERE venum = wa_vepo-venum.
      READ TABLE it_lips INTO wa_lips WITH KEY vbeln = wa_vepo-vbeln posnr = wa_vepo-posnr.
      wa_item-lfimg = wa_lips-lfimg.
      wa_item-meins = wa_lips-meins.
      wa_item-uecha = wa_lips-uecha.
      wa_item-vgpos = wa_lips-vgpos.
      wa_item-lgnum = wa_lips-lgnum.  "added by srimathi
      wa_item-brgew = wa_lips-brgew. " Added for gross weight by Carina Jose on 08.10.2020
      READ TABLE it_mcha INTO wa_mcha WITH KEY matnr = wa_lips-matnr charg = wa_lips-charg.
      IF sy-subrc = 0.
        wa_item-hsdat = wa_mcha-hsdat.
      ENDIF.
      APPEND wa_item TO it_item.
      CLEAR : wa_item,wa_lips,wa_vepo,wa_mcha.
    ENDLOOP.
  ELSE.
    LOOP AT it_lips INTO wa_lips.
      wa_item-posnr = wa_lips-posnr.
      wa_item-vbeln = wa_lips-vbeln.
      wa_item-matnr = wa_lips-matnr.
      wa_item-maktx = wa_lips-arktx.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE vbelv FROM vbfa INTO wa_item-vbelv WHERE vbeln = wa_lips-vbeln.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*SELECT VBELV FROM VBFA INTO WA_ITEM-VBELV UP TO 1 ROWS WHERE VBELN = WA_LIPS-VBELN
* ORDER BY PRIMARY KEY .
 SELECT  PRECEDINGDOCUMENT AS VBELV FROM I_SDDOCUMENTMULTILEVELPROCFLOW
INTO @WA_ITEM-VBELV  UP  TO  1  ROWS  WHERE SUBSEQUENTDOCUMENT =
@WA_LIPS-VBELN ORDER BY PRIMARY KEY.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
 ENDSELECT.

* End of Quick Fix

      wa_item-lfimg = wa_lips-lfimg.
      wa_item-meins = wa_lips-meins.
      wa_item-charg = wa_lips-charg.
      wa_item-lgort = wa_lips-lgort. "MOD1
      wa_item-uecha = wa_lips-uecha.
      wa_item-vgpos = wa_lips-vgpos.
      wa_item-lgnum = wa_lips-lgnum.
      wa_item-brgew = wa_lips-brgew. " Added for gross weight by Carina Jose on 08.10.2020
      READ TABLE it_mcha INTO wa_mcha WITH KEY matnr = wa_lips-matnr charg = wa_lips-charg.
      IF sy-subrc = 0.
        wa_item-hsdat = wa_mcha-hsdat.
      ENDIF.
      APPEND wa_item TO it_item.
      CLEAR wa_item.
      CLEAR: wa_lips,wa_mcha.
    ENDLOOP.
  ENDIF.
  DELETE it_item WHERE lfimg = '0.000'.
  SORT it_item BY posnr vemng DESCENDING.

" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  SELECT SINGLE likp~vbeln likp~kunnr kna1~adrnr likp~vkorg adrc~name1 adrc~street adrc~house_num1 adrc~house_num2 adrc~str_suppl1 adrc~str_suppl2 adrc~str_suppl3
*                adrc~city1 adrc~city2 adrc~post_code1 adrc~region adrc~country  likp~anzpk adrc~tel_number
*
*                j_1imocust~j_1iexcd j_1imocust~j_1iexrg j_1imocust~j_1iexdi j_1imocust~j_1icstno lips~vgbel "#EC CI_USAGE_OK[2877717]
*
*                FROM likp LEFT OUTER JOIN kna1 ON likp~kunnr = kna1~kunnr
*                INNER JOIN adrc ON kna1~adrnr = adrc~addrnumber
**                INNER JOIN adrct ON kna1~adrnr = adrct~addrnumber adrct~remark v_remarks,
*                INNER JOIN j_1imocust ON likp~kunnr = j_1imocust~kunnr
*                LEFT OUTER JOIN lips ON likp~vbeln = lips~vbeln AND lips~pstyv NE 'HUPM'
*                INTO (v_vbeln,v_kunnr,v_adrnr,v_vkorg,wa_header-shipto_name1,wa_header-shipto_street,wa_header-shipto_house_num1,wa_header-shipto_house_num2,
*                      wa_header-shipto_str_suppl1,wa_header-shipto_str_suppl2,wa_header-shipto_str_suppl3,wa_header-shipto_city1,wa_header-shipto_city2,
*                      wa_header-shipto_post_code1,wa_header-shipto_region,wa_header-shipto_country,wa_headerf-total_box,wa_headerf-telno,
*                      wa_headerf-shipto_ecc,wa_headerf-shipto_range,wa_headerf-shipto_div,wa_headerf-shipto_cst,wa_headerf-salesord)
*                WHERE likp~vbeln = p_vbeln.

  SELECT SINGLE likp~vbeln likp~kunnr kna1~adrnr likp~vkorg adrc~name1 adrc~street adrc~house_num1 adrc~house_num2 adrc~str_suppl1 adrc~str_suppl2 adrc~str_suppl3
                adrc~city1 adrc~city2 adrc~post_code1 adrc~region adrc~country  likp~anzpk adrc~tel_number

                kna1~j_1iexcd kna1~j_1iexrg kna1~j_1iexdi kna1~j_1icstno lips~vgbel "#EC CI_USAGE_OK[2877717]

                FROM likp LEFT OUTER JOIN kna1 ON likp~kunnr = kna1~kunnr
                INNER JOIN adrc ON kna1~adrnr = adrc~addrnumber
*                INNER JOIN adrct ON kna1~adrnr = adrct~addrnumber adrct~remark v_remarks,
                INNER JOIN kna1 AS kna11 ON likp~kunnr = kna11~kunnr
                LEFT OUTER JOIN lips ON likp~vbeln = lips~vbeln AND lips~pstyv NE 'HUPM'
                INTO (v_vbeln,v_kunnr,v_adrnr,v_vkorg,wa_header-shipto_name1,wa_header-shipto_street,wa_header-shipto_house_num1,wa_header-shipto_house_num2,
                      wa_header-shipto_str_suppl1,wa_header-shipto_str_suppl2,wa_header-shipto_str_suppl3,wa_header-shipto_city1,wa_header-shipto_city2,
                      wa_header-shipto_post_code1,wa_header-shipto_region,wa_header-shipto_country,wa_headerf-total_box,wa_headerf-telno,
                      wa_headerf-shipto_ecc,wa_headerf-shipto_range,wa_headerf-shipto_div,wa_headerf-shipto_cst,wa_headerf-salesord)
                WHERE likp~vbeln = p_vbeln.
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  SHIFT wa_headerf-total_box LEFT DELETING LEADING '0'.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE kunnr FROM vbpa INTO v_kunnr1 WHERE vbeln = p_vbeln AND parvw = 'AG'.

SELECT KUNNR FROM VBPA INTO V_KUNNR1 UP TO 1 ROWS WHERE VBELN = P_VBELN AND PARVW = 'AG'
 ORDER BY PRIMARY KEY .
 ENDSELECT.

* End of Quick Fix


****Ravin: 12.06.2017
  IF v_kunnr1 IS NOT INITIAL.
    SELECT SINGLE adrct~remark FROM kna1
      INNER JOIN adrct ON kna1~adrnr = adrct~addrnumber
      INTO v_remarks WHERE kunnr = v_kunnr1.
  ELSE.
    IF v_adrnr IS NOT INITIAL.
      SELECT SINGLE remark FROM adrct INTO v_remarks WHERE addrnumber = v_adrnr.
    ENDIF.
  ENDIF.
  CLEAR : v_vbeln,v_adrnr.
********
  v_kunnr2 = v_kunnr1.
  IF v_kunnr = v_kunnr1.
  ELSE.
    SELECT SINGLE kna1~adrnr adrc~name1 adrc~street adrc~house_num1 adrc~house_num2 adrc~str_suppl1 adrc~str_suppl2 adrc~str_suppl3
                  adrc~city1 adrc~city2 adrc~post_code1 adrc~region adrc~country "adrct~remark
                  FROM kna1 INNER JOIN adrc ON kna1~adrnr = adrc~addrnumber
*                            INNER JOIN adrct ON kna1~adrnr = adrct~addrnumber  , wa_header-remarks
                    INTO (v_adrnr,wa_header-soldto_name1,wa_header-soldto_street,wa_header-soldto_house_num1,wa_header-soldto_house_num2,
                        wa_header-soldto_str_suppl1,wa_header-soldto_str_suppl2,wa_header-soldto_str_suppl3,wa_header-soldto_city1,wa_header-soldto_city2,
                        wa_header-soldto_post_code1,wa_header-soldto_region,wa_header-soldto_country)
                  WHERE kna1~kunnr = v_kunnr1.
  ENDIF.
  CLEAR : v_vbeln,v_kunnr,v_adrnr,v_kunnr1.

  SELECT SINGLE t001w~adrnr adrc~name1 adrc~street adrc~house_num1 adrc~house_num2 adrc~str_suppl1 adrc~str_suppl2
                adrc~str_suppl3 adrc~city1 adrc~city2 adrc~post_code1 adrc~region adrc~country adrc~tel_number adrc~fax_number
                FROM t001w INNER JOIN adrc ON t001w~adrnr = adrc~addrnumber
                INTO (v_adrnr,wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
                wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
                wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country,wa_headerf-plant_tel,wa_headerf-plant_fax)
                WHERE t001w~werks = v_werks.
*  SELECT MATNR SCMNG FROM MVKE INTO TABLE IT_MVKE FOR ALL ENTRIES IN IT_ITEM WHERE MATNR = IT_ITEM-MATNR AND VKORG = V_VKORG.
  SELECT matnr aumng FROM mvke INTO TABLE it_mvke FOR ALL ENTRIES IN it_item WHERE matnr = it_item-matnr AND vkorg = v_vkorg.

  CLEAR : v_vbeln,v_kunnr,v_adrnr.

  plant_address = wa_header-plant_street.
  soldto_address = wa_header-soldto_street.

*------------------------------------------------------------------------------------*
* shipto address
*------------------------------------------------------------------------------------*
  IF NOT wa_header-shipto_street IS INITIAL.
    CONCATENATE shipto_address ',' wa_header-shipto_street INTO shipto_address.
  ENDIF.
  IF NOT wa_header-shipto_house_num1 IS INITIAL.
    CONCATENATE shipto_address ', ' wa_header-shipto_house_num1 INTO shipto_address.
  ENDIF.
  IF NOT wa_header-shipto_house_num2 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_house_num2 INTO shipto_address.
  ENDIF.
  IF NOT wa_header-shipto_str_suppl1 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_str_suppl1 INTO shipto_address.
  ENDIF.
  IF NOT wa_header-shipto_str_suppl2 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_str_suppl2 INTO shipto_address.
  ENDIF.
  IF NOT wa_header-shipto_str_suppl3 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_str_suppl3 INTO shipto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-shipto_city1 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_city1 INTO shipto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-shipto_city2 IS INITIAL.
    CONCATENATE space shipto_address ', ' wa_header-shipto_city2 INTO shipto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-shipto_post_code1 IS INITIAL.
    CONCATENATE space shipto_address '-' wa_header-shipto_post_code1 INTO shipto_address.
  ENDIF.

  SELECT SINGLE bezei FROM t005u INTO wa_headerf-shipto_state WHERE bland EQ wa_header-shipto_region AND land1 = wa_header-shipto_country AND spras = 'EN'.
  SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-shipto_country AND spras = 'EN'.

  IF NOT wa_headerf-shipto_state IS INITIAL AND NOT v_country IS INITIAL.
    CONCATENATE wa_headerf-shipto_state ' , ' v_country INTO wa_headerf-shipto_state SEPARATED BY space.
  ELSEIF NOT wa_headerf-shipto_state IS INITIAL AND v_country IS INITIAL.
    wa_headerf-shipto_state = wa_headerf-shipto_state.
  ELSE.
    wa_headerf-shipto_state = v_country.
  ENDIF.
  CLEAR: v_region , v_country.
  IF shipto_address+0(1) = ','.
    shipto_address = shipto_address+1(198).
  ENDIF.

*------------------------------------------------------------------------------------*
* soldto address
*------------------------------------------------------------------------------------*
  IF NOT wa_header-soldto_house_num1 IS INITIAL.
    CONCATENATE soldto_address ',' wa_header-soldto_house_num1 INTO soldto_address.
  ENDIF.
  IF NOT wa_header-soldto_house_num2 IS INITIAL.
    CONCATENATE  soldto_address ', ' wa_header-soldto_house_num2 INTO soldto_address.
  ENDIF.
  IF NOT wa_header-soldto_str_suppl1 IS INITIAL.
    CONCATENATE space soldto_address ', ' wa_header-soldto_str_suppl1 INTO soldto_address.
  ENDIF.
  IF NOT wa_header-soldto_str_suppl2 IS INITIAL.
    CONCATENATE space soldto_address ', ' wa_header-soldto_str_suppl2 INTO soldto_address.
  ENDIF.
  IF NOT wa_header-soldto_str_suppl3 IS INITIAL.
    CONCATENATE space soldto_address ', ' wa_header-soldto_str_suppl3 INTO soldto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-soldto_city1 IS INITIAL.
    CONCATENATE space soldto_address ', ' wa_header-soldto_city1 INTO soldto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-soldto_city2 IS INITIAL.
    CONCATENATE space soldto_address ', ' wa_header-soldto_city2 INTO soldto_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-soldto_post_code1 IS INITIAL.
    CONCATENATE space soldto_address '-' wa_header-soldto_post_code1 INTO soldto_address.
  ENDIF.

  SELECT SINGLE bezei FROM t005u INTO wa_headerf-soldto_state WHERE bland EQ wa_header-soldto_region AND land1 = wa_header-soldto_country AND spras = 'EN'.
  SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-soldto_country AND spras = 'EN'.

  IF NOT wa_headerf-soldto_state IS INITIAL AND NOT v_country IS INITIAL.
    CONCATENATE wa_headerf-soldto_state ' , ' v_country INTO wa_headerf-soldto_state SEPARATED BY space.
  ELSEIF NOT wa_headerf-soldto_state IS INITIAL AND v_country IS INITIAL.
    wa_headerf-soldto_state = wa_headerf-soldto_state.
  ELSE.
    wa_headerf-soldto_state = v_country.
  ENDIF.
  CLEAR: v_region , v_country.
  IF soldto_address+0(1) = ','.
    soldto_address = soldto_address+1(198).
  ENDIF.

*------------------------------------------------------------------------------------*
* plant address
*------------------------------------------------------------------------------------*
  IF NOT wa_header-plant_house_num1 IS INITIAL.
    CONCATENATE plant_address ',' wa_header-plant_house_num1 INTO plant_address.
  ENDIF.
  IF NOT wa_header-plant_house_num2 IS INITIAL.
    CONCATENATE plant_address ',' wa_header-plant_house_num2 INTO plant_address.
  ENDIF.
  IF NOT wa_header-plant_str_suppl1 IS INITIAL.
    CONCATENATE space plant_address ',' wa_header-plant_str_suppl1 INTO plant_address .
  ENDIF.
  IF NOT wa_header-plant_str_suppl2 IS INITIAL.
    CONCATENATE space plant_address ',' wa_header-plant_str_suppl2 INTO plant_address .
  ENDIF.
  IF NOT wa_header-plant_str_suppl3 IS INITIAL.
    CONCATENATE space plant_address ',' wa_header-plant_str_suppl3 INTO plant_address .
  ENDIF.
  IF NOT wa_header-plant_city1 IS INITIAL.
    CONCATENATE space plant_address ',' wa_header-plant_city1 INTO plant_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-plant_city2 IS INITIAL.
    CONCATENATE space plant_address ',' wa_header-plant_city2 INTO plant_address SEPARATED BY space.
  ENDIF.
  IF NOT wa_header-plant_post_code1 IS INITIAL.
    CONCATENATE space plant_address '-' wa_header-plant_post_code1 INTO plant_address.
  ENDIF.
  CONCATENATE wa_header-plant_city1 wa_header-plant_city2 INTO wa_headerf-plant_city SEPARATED BY ' , '.

  SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland EQ wa_header-plant_region AND land1 = wa_header-plant_country AND spras = 'EN'.
  SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = 'EN'.

  IF NOT v_region IS INITIAL.
    CONCATENATE plant_address ',' v_region INTO plant_address SEPARATED BY space.
  ENDIF.
  IF NOT v_country IS INITIAL.
    CONCATENATE plant_address ',' v_country INTO plant_address SEPARATED BY space.
  ENDIF.
  CLEAR: v_region , v_country.
  IF plant_address+0(1) = ','.
    plant_address = plant_address+1(198).
  ENDIF.

  wa_headerf-shipto_address =  shipto_address.
  wa_headerf-plant_address =  plant_address.
  wa_headerf-shipto_name =  wa_header-shipto_name1.
  wa_headerf-plant_name =  wa_header-plant_name1.
  wa_headerf-soldto_name = wa_header-soldto_name1.
  wa_headerf-soldto_address = soldto_address.
*  v_remarks = wa_header-remarks.
  IF wa_header-shipto_city1 NE ''.
    CONCATENATE wa_headerf-shipto_name '-' wa_header-shipto_city1 INTO wa_headerf-shipto_name SEPARATED BY space.
  ELSE.
    CONCATENATE wa_headerf-shipto_name '-' wa_header-shipto_city2 INTO wa_headerf-shipto_name SEPARATED BY space.
  ENDIF.
  CONCATENATE wa_header-shipto_city1 wa_header-shipto_city2 INTO wa_headerf-shipto_city SEPARATED BY ' , '.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE vbeln FROM vbfa INTO v_billdoc WHERE vbelv = p_vbeln AND vbtyp_v = 'J' AND vbtyp_n = 'U'.

" " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*SELECT VBELN FROM VBFA INTO V_BILLDOC UP TO 1 ROWS WHERE VBELV = P_VBELN AND VBTYP_V = 'J' AND VBTYP_N = 'U'
* ORDER BY PRIMARY KEY .
 SELECT  SUBSEQUENTDOCUMENT AS VBELN FROM
I_SDDOCUMENTMULTILEVELPROCFLOW INTO @V_BILLDOC  UP  TO  1  ROWS
WHERE PRECEDINGDOCUMENT = @P_VBELN AND PRECEDINGDOCUMENTCATEGORY = 'J'
AND SUBSEQUENTDOCUMENTCATEGORY = 'U' ORDER BY PRIMARY KEY.
" " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
 ENDSELECT.

* End of Quick Fix

  SELECT SINGLE fkart FROM vbrk INTO v_fkart WHERE vbeln = v_billdoc.
  IF v_fkart = 'ZEX1'.
    EXPORT p_vbeln TO MEMORY ID 'Pack_Slip'.
    SUBMIT zexp_packslip.
  ELSE.
    PERFORM item_get_data.
    PERFORM ssf_display.
  ENDIF.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      FORM  ITEM_GET_DATA
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM item_get_data .
*BREAK-POINT.
  it_item1 = it_item.
  SORT it_item1 BY exidv.
  DELETE ADJACENT DUPLICATES FROM it_item1.
  LOOP AT it_item1 INTO wa_item1.
    v_exidv = wa_item1-exidv.
    AT FIRST.
      wa_headerf-from = v_exidv.
      SHIFT wa_headerf-from LEFT DELETING LEADING '0'.
    ENDAT.
    AT LAST.
      wa_headerf-to = v_exidv.
      SHIFT wa_headerf-to LEFT DELETING LEADING '0'.
    ENDAT.
    CLEAR : wa_item1,v_exidv.
  ENDLOOP.

  IF NOT it_vepo IS INITIAL.
    LOOP AT it_item INTO wa_item.
      v_kyi = wa_item-vemng.
      v_ky = v_kyi.
      CONDENSE v_ky NO-GAPS.
      CONCATENATE wa_item-vbeln wa_item-posnr v_ky INTO wa_item-key.
      CONDENSE wa_item-key NO-GAPS.
      MODIFY it_item FROM wa_item TRANSPORTING key.
      CLEAR : wa_item,v_ky,v_kyi.
    ENDLOOP.

    SORT it_item BY venum.
    DATA v_uecha1 TYPE char6.
    LOOP AT it_item INTO wa_item.
      v_id = v_id + 1.   "commented on 29-04-19
      wa_final-id = v_id. "  commented on 29-04-19
      SHIFT wa_item-exidv LEFT DELETING LEADING '0'.
      wa_final-fullbox = wa_item-exidv.
*      IF  v_werks CP '4*'. "++Comented by Archna Gupta on 24.03.2026
      IF  v_werks CP '2*'.   "Added By Archna Gupta on 24.03.2026
        wa_final-fullboxqty = wa_item-vemng.
      ELSE.
        wa_final-totloosebox = wa_item-vemng.
      ENDIF.
      SELECT SINGLE bismt FROM mara INTO wa_final-bismt WHERE matnr = wa_item-matnr.
*        wa_final-posnr = wa_item-posnr.   "changed by rajni
      wa_final-matnr = wa_item-matnr.
      wa_final-maktx = wa_item-maktx.
      wa_final-brgew = wa_item-brgew. " Added for Gross Weight by Carina Jose on 08.10.2020
      wa_final-hsdat = wa_item-hsdat. "added for manufacture date 07.09.2021
*      IF  v_werks CP '4*'.            "++Comented by Archna Gupta on 24.03.2026
         IF  v_werks CP '2*'.          "Added By Archna Gupta on 24.03.2026
        wa_final-lfimg = wa_item-lfimg.
*      ELSEIF  v_werks CP '7*'.        "++Comented by Archna Gupta on 24.03.2026
         ELSEIF  v_werks CP '4*'.      "Added By Archna Gupta on 24.03.2026
        wa_final-lfimg = wa_item-lfimg.
      ELSE.
*        wa_final-totfullbox = wa_item-lfimg.
*        wa_final-lfimg = wa_item-lfimg.
****Ravin: 12.06.2017
        wa_final-totfullbox = wa_item-lfimg.


*      SHIFT v_totqty LEFT DELETING LEADING '0'.
      ENDIF.
      wa_final-meins = wa_item-meins.
      wa_final-vbelv = wa_item-vbelv.
      v_uecha1 = wa_item-uecha.
      "v_item  = wa_item-vgpos.
      SHIFT v_uecha1 LEFT DELETING LEADING '0'.                 "changes done on 12.04.2019
      IF v_uecha1 IS NOT INITIAL.
        wa_final-uecha = v_uecha1.
      ENDIF.
      SHIFT wa_final-vgpos LEFT DELETING LEADING '0'.
      IF wa_final-vgpos IS NOT INITIAL.
        wa_final-vgpos = wa_item-vgpos.
      ENDIF.



      APPEND wa_final TO it_final.
      CLEAR : wa_item,wa_final,flag,flag1.
    ENDLOOP.
    CLEAR :v_venum,v_vemng.", v_id,.
  ELSE.
    DATA v_uecha TYPE char6.             "changes done on 12.04.2019

    LOOP AT it_item INTO wa_item.
      v_id = v_id + 1.    "commented on 29-04-19
      wa_final-id = v_id.  "        commented on 29-04-19     "changed by rajni

      SELECT SINGLE bismt FROM mara INTO wa_final-bismt WHERE matnr = wa_item-matnr.
      CLEAR wa_mvke.

      READ TABLE it_mvke INTO wa_mvke WITH KEY matnr = wa_item-matnr.
*      IF NOT WA_MVKE-SCMNG IS INITIAL. "13.04.2015
      IF NOT wa_mvke-aumng IS INITIAL.
*        WA_FINAL-TOTQTY = WA_MVKE-SCMNG.
        wa_final-totqty = wa_mvke-aumng. "++Comented by archna gupta on 10.03.2026
*         wa_final-totqty = wa_final-totqty + wa_item-lfimg.
*        WA_FINAL-TOTBOX = WA_ITEM-LFIMG / WA_MVKE-SCMNG.
        wa_final-totbox = wa_item-lfimg / wa_mvke-aumng.
      ENDIF.
      wa_headerf-totbox = wa_headerf-totbox + wa_final-totbox.
      "Added by srimathi
      READ TABLE lt_mlgn INTO ls_mlgn WITH KEY matnr = wa_item-matnr
                                               lgnum = wa_item-lgnum.
      IF sy-subrc EQ 0.
*        READ TABLE lt_article ASSIGNING <fs_article> WITH KEY type = ls_mlgn-lety1.
*        IF <fs_article> IS ASSIGNED.
*          <fs_article>-qnty = <fs_article>-qnty + wa_final-totbox.
*        ELSE.
*          ls_article-type = ls_mlgn-lety1.
*          ls_article-qnty = wa_final-totbox.
**          MODIFY lt_article FROM ls_article.
*          APPEND ls_article TO lt_article.
*          CLEAR: ls_article.
*        ENDIF.
        IF ls_mlgn-lety1 EQ 'BOX'.
          wa_headerf-box = wa_headerf-box + wa_final-totbox.
        ELSEIF ls_mlgn-lety1 EQ 'DRM'.
          wa_headerf-drum = wa_headerf-drum + wa_final-totbox.
        ELSEIF ls_mlgn-lety1 EQ 'CAN'.
          wa_headerf-bucket = wa_headerf-bucket + wa_final-totbox.
        ENDIF.
      ENDIF.
      "Added by srimathi
      wa_final-matnr = wa_item-matnr.
      wa_final-maktx = wa_item-maktx.
      wa_final-brgew = wa_item-brgew. " Added for Gross Weight by Carina Jose on 08.10.2020
      wa_final-hsdat = wa_item-hsdat. "added for manufacture date 07.09.2021
      v_uecha = wa_item-uecha.
      "SHIFT wa_final-vgpos LEFT DELETING LEADING '0'.
      wa_final-vgpos = wa_item-vgpos.
      SHIFT v_uecha LEFT DELETING LEADING '0'.                 "changes done on 12.04.2019
      IF v_uecha IS NOT INITIAL.
        wa_final-uecha = v_uecha.
      ENDIF.
      SHIFT wa_final-vgpos LEFT DELETING LEADING '0'.
      IF wa_final-vgpos IS NOT INITIAL.
        wa_final-vgpos = wa_item-vgpos.
      ENDIF.
*      IF  v_werks CP '4*'.     "Comented by Archna Gupta on 24.03.2026
          IF  v_werks CP '2*'.  "Added By Archna Gupta on 24.03.2026
        wa_final-lfimg = wa_item-lfimg.
*      ELSEIF v_werks CP '7*'.  "Comented by Archna Gupta on 24.03.2026
           ELSEIF v_werks CP '4*'.  "Added By Archna Gupta on 24.03.2026
        wa_final-lfimg = wa_item-lfimg.
      ELSE.
***Ravin: 12.06.2017
        wa_final-totfullbox = wa_final-totqty.
*        wa_final-lfimg = wa_item-lfimg.
        wa_final-fullboxqty = wa_item-lfimg.


*      SHIFT v_totqty LEFT DELETING LEADING '0'.
      ENDIF.
*      wa_final-lfimg = wa_item-lfimg.
      wa_final-meins = wa_item-meins.
      wa_final-vbelv = wa_item-vbelv.
      wa_final-charg = wa_item-charg.
"Added by UDAYABAP03 on 30.03.2026
     wa_final-lfimg = wa_item-lfimg.
     wa_final-fullboxqty = wa_item-lfimg.
"Added by UDAYABAP03 on 30.03.2026
*      CLEAR wa_mvke.
*      MOD1

      "--------------------------Start | Dispatch Process change | by Srimathi | 03.09.2024----------------------$
*      CLEAR lv_lgpla.
*      LOOP AT it_lqua INTO wa_lqua WHERE werks = v_werks AND
**       READ TABLE it_lqua INTO wa_lqua with key  werks = v_werks
*                                                 lgort = wa_item-lgort AND
*                                                 charg = wa_final-charg AND
*                                                 matnr = wa_final-matnr . "MOD1
*        IF wa_lqua-verme LE 0.
*          CONTINUE.
*        ELSE.
*          SELECT lgnum matnr werks charg lgtyp lgpla verme lgort lenum FROM lqua
*                                                                 INTO TABLE it_lqua_temp
*                                                                 WHERE lgtyp = wa_lqua-lgtyp
*                                                                   AND charg = wa_lqua-charg
*                                                                   AND matnr = wa_lqua-matnr
*                                                                   AND werks = v_werks.
*          LOOP AT it_lqua_temp INTO wa_lqua_temp.
*            lv_tot = lv_tot + wa_lqua_temp-verme.
*          ENDLOOP.
*          IF wa_final-lgpla IS NOT INITIAL.
*            IF lv_lgpla NE wa_lqua-lgpla .
*              ls_verme = lv_tot.
*              CONDENSE ls_verme.
*              CONCATENATE wa_lqua-lgpla '(' ls_verme ')' INTO ls_lgpla.
*              CONCATENATE  wa_final-lgpla ls_lgpla INTO wa_final-lgpla SEPARATED BY ',' .
***              CONCATENATE  wa_final-lgpla wa_lqua-lgpla INTO wa_final-lgpla SEPARATED BY ',' .
*              lv_lgpla =  wa_lqua-lgpla .
*            ENDIF.
*          ELSE.
*            ls_verme = lv_tot.
*            CONDENSE ls_verme.
*            CONCATENATE wa_lqua-lgpla '(' ls_verme ')' INTO ls_lgpla.
*            wa_final-lgpla = ls_lgpla.                                               "wa_lqua-lgpla .
*            lv_lgpla =  wa_lqua-lgpla .
*          ENDIF.
*        ENDIF.
*        CLEAR: ls_lgpla,ls_verme,lv_tot,wa_lqua_temp,lv_tot_bin_qty.
*      ENDLOOP.


      CLEAR lv_lgpla.
      LOOP AT it_lqua INTO wa_lqua WHERE werks = v_werks AND
                                         lgort = wa_item-lgort AND
                                         charg = wa_final-charg AND
                                         matnr = wa_final-matnr GROUP BY ( lgpla = wa_lqua-lgpla ).
        LOOP AT GROUP wa_lqua INTO wa_lqua_temp.
          IF wa_lqua_temp-lenum IS NOT INITIAL.
            lv_tot = lv_tot + 1.
          ENDIF.
        ENDLOOP.
        IF wa_final-lgpla IS INITIAL.
          ls_verme = lv_tot.
          CONDENSE ls_verme.
          CONCATENATE wa_lqua-lgpla '(' ls_verme ')' INTO ls_lgpla.
          wa_final-lgpla = ls_lgpla.
        ELSE.
          ls_verme = lv_tot.
          CONDENSE ls_verme.
          CONCATENATE wa_lqua-lgpla '(' ls_verme ')' INTO ls_lgpla.
          CONCATENATE  wa_final-lgpla ls_lgpla INTO wa_final-lgpla SEPARATED BY ',' .
        ENDIF.
        CLEAR: lv_tot, ls_verme, ls_lgpla.
      ENDLOOP.
      "---------------------------End | Dispatch Process change | by Srimathi | 03.09.2024-----------------------$
*        MOD1
      APPEND wa_final TO it_final.
      CLEAR : wa_final,wa_item.
    ENDLOOP.
*    CLEAR v_id.
  ENDIF.

*  IF lt_article[] IS NOT INITIAL.
*    DATA: lv_article_qnty   TYPE i,
*          lv_article_qnty_s TYPE string.
*    LOOP AT lt_article INTO DATA(ls_article_grp) GROUP BY ( type = ls_article_grp-type ).
*      LOOP AT GROUP ls_article_grp INTO ls_article.
*        lv_article_qnty = lv_article_qnty + ls_article-qnty.
*      ENDLOOP.
*      IF wa_headerf-article IS INITIAL.
*        lv_article_qnty_s = lv_article_qnty.
*        CONCATENATE lv_article_qnty_s ls_article_grp-type INTO wa_headerf-article SEPARATED BY space.
*      ELSE.
*        lv_article_qnty_s = lv_article_qnty.
*        CONCATENATE wa_headerf-article ',' INTO wa_headerf-article.
*        CONCATENATE wa_headerf-article lv_article_qnty_s ls_article_grp-type INTO wa_headerf-article SEPARATED BY space.
*      ENDIF.
*      CLEAR: lv_article_qnty_s, lv_article_qnty.
*    ENDLOOP.
*    refresh: lt_article[].
*  ENDIF.

  DATA : lines TYPE STANDARD TABLE OF tline.
  DATA : wa_lines TYPE tline.
  DATA : v_vbeln(70).
  CLEAR v_vbeln.
  v_vbeln = p_vbeln.

  CALL FUNCTION 'READ_TEXT'
    EXPORTING
      client                  = sy-mandt
      id                      = 'Z001'
      language                = sy-langu
      name                    = v_vbeln
      object                  = 'VBBK'
    TABLES
      lines                   = lines
    EXCEPTIONS
      id                      = 1
      language                = 2
      name                    = 3
      not_found               = 4
      object                  = 5
      reference_check         = 6
      wrong_access_to_archive = 7
      OTHERS                  = 8.
  IF sy-subrc EQ 0.
    LOOP AT lines INTO wa_lines.
      IF NOT wa_headerf-transporter IS INITIAL.
        CONCATENATE wa_headerf-transporter ' , ' wa_lines-tdline INTO wa_headerf-transporter.
      ELSE.
        CONCATENATE '' wa_lines-tdline INTO wa_headerf-transporter.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " ITEM_GET_DATA
*&---------------------------------------------------------------------*
*&      FORM  SSF_DISPLAY
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
*  -->  P1        TEXT
*  <--  P2        TEXT
*----------------------------------------------------------------------*
FORM ssf_display .


  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
      formname           = 'ZWM_PICKLIST1'
    IMPORTING
      fm_name            = v_fm_name
    EXCEPTIONS
      no_form            = 1
      no_function_module = 2
      OTHERS             = 3.

  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  SORT it_final BY matnr uecha.
  CLEAR: wa_final,v_id.
  LOOP AT it_final INTO wa_final.
    v_id = v_id + 1.
    wa_final-id = v_id.
    MODIFY it_final FROM wa_final TRANSPORTING id.
  ENDLOOP.
  CLEAR v_id.
  CALL FUNCTION v_fm_name
    EXPORTING
      wa_header        = wa_headerf
      v_bstkd          = v_bstkd
      v_kunnr2         = v_kunnr2
      v_remarks        = v_remarks
    TABLES
      it_final         = it_final
    EXCEPTIONS
      formatting_error = 1
      internal_error   = 2
      send_error       = 3
      user_canceled    = 4
      OTHERS           = 5.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " SSF_DISPLAY
