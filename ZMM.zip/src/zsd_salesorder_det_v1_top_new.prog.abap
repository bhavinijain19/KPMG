*&---------------------------------------------------------------------*
*&  Include           ZSD_SALESORDER_DETAIL_V1_TOP
*&---------------------------------------------------------------------*
DATA: gv_werks TYPE werks_d,
      gv_vbeln TYPE vbeln_va,
      gv_erdat TYPE erdat,
      gv_vkorg TYPE vkorg,
      gv_vtweg TYPE vtweg,
      gv_spart TYPE spart,
      gv_vkbur TYPE vkbur,
      gv_matnr TYPE matnr,
      gv_matkl TYPE matkl,
      gv_auart TYPE auart,
      gv_kunnr TYPE kunnr.

*&---------------------------------------------------------------------*
*& Selection Screen
*&---------------------------------------------------------------------*
SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS : s_werks FOR gv_werks.
  SELECT-OPTIONS : s_vbeln FOR gv_vbeln.
  SELECT-OPTIONS : s_date  FOR gv_erdat.
  SELECT-OPTIONS : s_vkorg FOR gv_vkorg.
  SELECT-OPTIONS : s_vtweg FOR gv_vtweg.
  SELECT-OPTIONS : s_spart FOR gv_spart.
  SELECT-OPTIONS : s_vkbur FOR gv_vkbur.
  SELECT-OPTIONS : s_matnr FOR gv_matnr.
  SELECT-OPTIONS : s_matkl FOR gv_matkl.
  SELECT-OPTIONS : s_auart FOR gv_auart.
  SELECT-OPTIONS : s_kunnr FOR gv_kunnr.
SELECTION-SCREEN : END OF BLOCK a1.

SELECTION-SCREEN : BEGIN OF BLOCK a2 WITH FRAME TITLE TEXT-002.
  PARAMETERS : v_all RADIOBUTTON GROUP rad1.
  PARAMETERS : v_com RADIOBUTTON GROUP rad1.
  PARAMETERS : v_par RADIOBUTTON GROUP rad1.
  PARAMETERS : v_rem RADIOBUTTON GROUP rad1.
  PARAMETERS : v_it AS CHECKBOX.
SELECTION-SCREEN : END OF BLOCK a2.
*&---------------------------------------------------------------------*



*&---------------------------------------------------------------------*
*&      Decleration
*&---------------------------------------------------------------------*

*TYPES : BEGIN OF t_vbap,
*          vbeln     TYPE vbap-vbeln,
*          posnr     TYPE vbap-posnr,
*          matnr     TYPE vbap-matnr,
*          arktx     TYPE vbap-arktx,
*          matkl     TYPE vbap-matkl,
*          mvgr1     TYPE vbap-mvgr1,
*          kondm     TYPE vbap-kondm,
*          netwr     TYPE vbap-netwr,
*          waerk     TYPE vbap-waerk,
*          kwmeng    TYPE vbap-kwmeng,
*          kbmeng    TYPE vbap-kbmeng,
*          vrkme     TYPE vbap-vrkme,
*          werks     TYPE vbap-werks,
*          erdat     TYPE vbak-erdat,
*          erzet     TYPE vbak-erzet,
*          abgru     TYPE vbap-abgru,
*          vkorg     TYPE vbak-vkorg,
*          vtweg     TYPE vbak-vtweg,
*          spart     TYPE vbak-spart,
*          vkbur     TYPE vbak-vkbur,
*          kunnr     TYPE vbak-kunnr,
*          lifsk     TYPE vbak-lifsk,
*          auart     TYPE vbak-auart,
*          aedat     TYPE vbak-aedat,
*          zzname    TYPE vbak-zzname,
*          zztcode   TYPE vbak-zztcode,        " Added by Gokul 30.05.2023
*          zzsydate  TYPE vbak-zzsydate,       " Added by Gokul 30.05.2023
*          zzsy_time TYPE vbak-zzsy_time,      " Added by Gokul 30.05.2023
*          bukrs_vf  TYPE vbak-bukrs_vf, " Added by Carina Jose on 08/07/2021
*          mvgr4     TYPE vbap-mvgr4,
*          knumv     TYPE vbak-knumv,
*          prctr     TYPE vbap-prctr,
*        END OF t_vbap.
*DATA : wa_vbap TYPE t_vbap.
*DATA : it_vbap TYPE STANDARD TABLE OF t_vbap.
*
*TYPES : BEGIN OF t_vbfa,
*          vbelv TYPE vbfa-vbelv,
*          posnv TYPE vbfa-posnv,
*          vbeln TYPE vbfa-vbeln,
*        END OF t_vbfa.
*DATA : wa_vbfa TYPE t_vbfa.
*DATA : it_vbfa TYPE STANDARD TABLE OF t_vbfa.
*
*TYPES : BEGIN OF ty_vbuk,
*          vbeln TYPE vbuk-vbeln,
*          cmgst TYPE vbuk-cmgst,
*        END OF ty_vbuk.
*DATA: it_vbuk TYPE STANDARD TABLE OF ty_vbuk,
*      wa_vbuk TYPE ty_vbuk.
*
*TYPES : BEGIN OF t_lips,
**          dvbeln TYPE lips-vbeln,
*          dvgbel      TYPE lips-vgbel,
*          dvgpos      TYPE lips-vgpos,
*          dvbeln(200),
*          dposnr      TYPE lips-posnr,
*          dlfimg      TYPE lips-lfimg,
*          dmeins      TYPE lips-meins,
*          dmatnr      TYPE lips-matnr,
*          derdat      TYPE likp-erdat,
*          derzet      TYPE likp-erzet,
*          wadat_ist   TYPE likp-wadat_ist,
*        END OF t_lips.
*
*DATA : wa_lips TYPE t_lips.
*DATA : it_lips TYPE STANDARD TABLE OF t_lips.
*
*TYPES :BEGIN OF t_vbup,
*         vbeln TYPE vbup-vbeln,
*         posnr TYPE vbup-posnr,
*         wbsta TYPE vbup-wbsta,
*         fksta TYPE vbup-fksta,
*       END OF t_vbup.
*DATA : wa_vbup TYPE t_vbup.
*DATA : it_vbup TYPE STANDARD TABLE OF t_vbup.
*
*
*DATA: v_dlfimg TYPE lips-lfimg.
*DATA: v_dlfimg1 TYPE lips-lfimg.
*DATA: v_dvbeln(200).
*DATA: v_dvbeln1(200).
*DATA: v_dmeins TYPE lips-meins.
*DATA: v_derdat TYPE lips-erdat.
*DATA: v_derzet TYPE lips-erzet.
*
*TYPES : BEGIN OF t_mard,
*          matnr TYPE mard-matnr,
*          werks TYPE mard-werks,
*          lgort TYPE mard-lgort,
*          labst TYPE mard-labst,
*        END OF t_mard.
*DATA : wa_mard TYPE t_mard.
*DATA : it_mard TYPE STANDARD TABLE OF t_mard.
*
TYPES : BEGIN OF t_stock,
          matnr TYPE mard-matnr,
          werks TYPE vbrp-werks,
          qty   TYPE mard-labst,
          qty_r TYPE mard-labst,
        END OF t_stock.
*DATA : wa_stock TYPE t_stock.
*DATA : it_stock TYPE STANDARD TABLE OF t_stock.
*
*TYPES : BEGIN OF t_kna1,
*          kunnr TYPE kna1-kunnr,
*          name1 TYPE kna1-name1,
*          regio TYPE kna1-regio,
*          bbbnr TYPE kna1-bbbnr,  "Added by Carina Jose 08/07/2021
*          bbsnr TYPE kna1-bbsnr,  "Added by Carina Jose 08/07/2021
*        END OF t_kna1.
*
*DATA : wa_kna1 TYPE t_kna1,
*       it_kna1 TYPE STANDARD TABLE OF t_kna1.
*
***************** 30.07.2021
*TYPES : BEGIN OF ty_knkk,
*          kunnr TYPE knkk-kunnr,
*          klimk TYPE knkk-klimk,
*          skfor TYPE knkk-skfor,
*        END OF ty_knkk.
*DATA: it_knkk TYPE STANDARD TABLE OF ty_knkk,
*      wa_knkk TYPE ty_knkk.
*
*TYPES: BEGIN OF ty_knvv,
*         kunnr TYPE knvv-kunnr,
*         vkorg TYPE knvv-vkorg, "added by Carina Jose on 17.11.2021
*         zterm TYPE knvv-zterm,
*         vkgrp TYPE knvv-vkgrp,
*         bzirk TYPE knvv-bzirk,
*       END OF ty_knvv.
*DATA: it_knvv TYPE STANDARD TABLE OF ty_knvv,
*      wa_knvv TYPE ty_knvv.
*
*DATA: it_t171t TYPE STANDARD TABLE OF t171t,
*      wa_t171t TYPE t171t.
*DATA: it_tvgrt TYPE STANDARD TABLE OF tvgrt,
*      wa_tvgrt TYPE tvgrt.
*
*TYPES: BEGIN OF ty_tvarvc1,
*         sign TYPE tvarv_sign,
*         opti TYPE tvarv_opti,
*         low  TYPE tvarv_val,
*         high TYPE tvarv_val,
*       END OF ty_tvarvc1.
*
*DATA: lt_acc_key1  TYPE STANDARD TABLE OF ty_tvarvc1.
*DATA: lwa_acc_key1 TYPE ty_tvarvc1.
*
CONSTANTS : c_credit_user   TYPE rvari_vnam VALUE 'ZSD_CREDIT_LIMIT_SO',
            c_credit_user_s TYPE rsscr_kind VALUE 'S'.
***********
*
*TYPES : BEGIN OF t_t178t,
*          kondm TYPE t178t-kondm,
*          vtext TYPE t178t-vtext,
*        END OF t_t178t.
*
*DATA : wa_t178t TYPE t_t178t,
*       it_t178t TYPE STANDARD TABLE OF t_t178t.
*
*TYPES : BEGIN OF t_tvm1t,
*          mvgr1 TYPE tvm1t-mvgr1,
*          bezei TYPE tvm1t-bezei,
*          spras TYPE tvm1t-spras,
*        END OF t_tvm1t.
*
*DATA : wa_tvm1t TYPE t_tvm1t,
*       it_tvm1t TYPE STANDARD TABLE OF t_tvm1t.
*
*TYPES : BEGIN OF t_tvm4t,
*          mvgr4 TYPE tvm1t-mvgr1,
*          bezei TYPE tvm1t-bezei,
*          spras TYPE tvm1t-spras,
*        END OF t_tvm4t.
*
*DATA : wa_tvm4t TYPE t_tvm4t,
*       it_tvm4t TYPE STANDARD TABLE OF t_tvm4t.
*
*TYPES : BEGIN OF t_tvakt,
*          spras TYPE tvakt-spras,
*          auart TYPE tvakt-auart,
*          bezei TYPE tvakt-bezei,
*        END OF t_tvakt.
*
*DATA : wa_tvakt TYPE t_tvakt,
*       it_tvakt TYPE STANDARD TABLE OF t_tvakt.
*
*
*DATA : wa_tvagt TYPE tvagt,
*       it_tvagt TYPE STANDARD TABLE OF tvagt.
*
*DATA : it_tvkbt TYPE STANDARD TABLE OF tvkbt,
*       wa_tvkbt TYPE tvkbt.
*
*DATA: it_t005u TYPE STANDARD TABLE OF t005u,
*      wa_t005u TYPE t005u.


TYPES : BEGIN OF t_final,
          vbeln           TYPE vbap-vbeln,
          posnr           TYPE vbap-posnr,
          matnr           TYPE vbap-matnr,
          arktx           TYPE vbap-arktx,
          matkl           TYPE vbap-matkl,
          vtext           TYPE t178t-vtext,
*          mvgr1     TYPE vbap-mvgr1,
          bezei           TYPE tvm1t-bezei,
          netwr           TYPE vbap-netwr,
          netwr1          TYPE vbap-netwr,
          delnetwr        TYPE vbap-netwr,
          pginetwr        TYPE vbap-netwr,
          invnetwr        TYPE vbap-netwr,
          pgival          TYPE vbap-netwr,
          ordvalu         TYPE vbap-netwr,
          ordvalu1        TYPE vbap-netwr,
          waerk           TYPE vbap-waerk,
          kwmeng          TYPE vbap-kwmeng,
          kbmeng          TYPE vbap-kbmeng,
          vrkme           TYPE vbap-vrkme,
          werks           TYPE vbap-werks,
          erdat           TYPE vbak-erdat,
          erzet           TYPE vbak-erzet,
          vkorg           TYPE vbak-vkorg,
          vtweg           TYPE vbak-vtweg,
          spart           TYPE vbak-spart,
          vkbur           TYPE vbak-vkbur,
          kunnr           TYPE vbak-kunnr,
          zztcode         TYPE vbak-zztcode,            " Added by Gokul 30.05.2023
          zzsydate        TYPE vbak-zzsydate,           " Added by Gokul 30.05.2023
          zzsy_time       TYPE vbak-zzsy_time,          " Added by Gokul 30.05.2023
          zzname          TYPE vbak-zzname,              "Added by raj on 14.06.2023
          name1           TYPE kna1-name1,
*          dvbeln    TYPE lips-vbeln,
          dvbeln(200),
          dlfimg          TYPE lips-lfimg,
          dlfimg1         TYPE lips-lfimg,
          invquan         TYPE lips-lfimg,
          dmeins          TYPE lips-meins,
          derdat          TYPE likp-erdat,
          derzet          TYPE likp-erzet,
          wadat_ist       TYPE likp-wadat_ist,
          remqty          TYPE lips-lfimg,
          stock           TYPE mard-labst,
          stock_r         TYPE mard-labst,
          bezei1          TYPE tvm1t-bezei,
          bezei4          TYPE tvm4t-bezei,
          text1(15),
          lights(1)       TYPE c,
          line_color(4)   TYPE c,
          shtpa           TYPE kunwe,
          shtpd           TYPE char80,
          bstkd           TYPE bstkd,
          bstdk           TYPE bstdk,
          aumng           TYPE mvke-aumng,
          noofb           TYPE wrbtr,
          noofb1          TYPE wrbtr,
          grswt           TYPE brgew,
          4bezei          TYPE tvagt-bezei, "tvagt-bezei,
*          4bezei(40),
          abgru           TYPE tvagt-abgru,
          headernote1(40) TYPE c,
          chandt          TYPE vbap-aedat,
          desc            TYPE t001w-name1,
          knumv           TYPE vbak-knumv,
          kurrf           TYPE vbkd-kurrf,
          fixed_disamt    TYPE vbap-netwr,
          spl_disamt      TYPE vbap-netwr,
          jocg            TYPE vbap-netwr,
          josg            TYPE vbap-netwr,
          joig            TYPE vbap-netwr,
          zicg            TYPE vbap-netwr,
          zfcg            TYPE vbap-netwr,
          zisg            TYPE vbap-netwr,
          zfsg            TYPE vbap-netwr,
          ziig            TYPE vbap-netwr,
          zfig            TYPE vbap-netwr,
          ymnd            TYPE vbap-netwr, "Added by raj on 05.06.2023
          zins            TYPE vbap-netwr,
          zfrt            TYPE vbap-netwr,
          gsttotal        TYPE vbap-netwr,

          discper         TYPE konv-kbetr,
          mdiscper        TYPE konv-kbetr,
          mandisper       TYPE konv-kbetr, "Added by Raj on 05.06.2023
          soffice(30),
          regio(20),
          kvgr1           TYPE kvgr1, "Added by Bhaumik|02.04.26|DEVK900996
          kvgr2           TYPE kvgr2, "Added by Bhaumik|02.04.26|DEVK900996
          prctr           TYPE vbap-prctr,

***********   Added changes by Carina Jose on 08/07/2021
          zone            TYPE zsd_zone-name,
          szone           TYPE zsd_zone-sname,
          lcategory1      TYPE zsd_custemp_assg-lcategory,
          lname1          TYPE zsd_custemp_assg-lname,
          lcategory2      TYPE zsd_custemp_assg-lcategory,
          lname2          TYPE zsd_custemp_assg-lname,
          lcategory3      TYPE zsd_custemp_assg-lcategory,
          lname3          TYPE zsd_custemp_assg-lname,
          lcategory4      TYPE zsd_custemp_assg-lcategory,
          lname4          TYPE zsd_custemp_assg-lname,
          lcategory5      TYPE zsd_custemp_assg-lcategory,
          lname5          TYPE zsd_custemp_assg-lname,
          lcategory6      TYPE zsd_custemp_assg-lcategory,
          lname6          TYPE zsd_custemp_assg-lname,
***********   End of changes on 08/07/2021


***************** Added changes by Carina Jose on 01/09/2021
          clcategory1     TYPE zsd_custemp_assg-lcategory,
          clname1         TYPE zsd_custemp_assg-lname,
          clcategory2     TYPE zsd_custemp_assg-lcategory,
          clname2         TYPE zsd_custemp_assg-lname,
          clcategory3     TYPE zsd_custemp_assg-lcategory,
          clname3         TYPE zsd_custemp_assg-lname,
          clcategory4     TYPE zsd_custemp_assg-lcategory,
          clname4         TYPE zsd_custemp_assg-lname,
          clcategory5     TYPE zsd_custemp_assg-lcategory,
          clname5         TYPE zsd_custemp_assg-lname,
          clcategory6     TYPE zsd_custemp_assg-lcategory,
          clname6         TYPE zsd_custemp_assg-lname,
*****************  End of changes on 01/09/2021

**********************  added by parth 30/07/2021
          klimk           TYPE knkk-klimk,
          skfor           TYPE knkk-skfor,
          limit           TYPE knkk-skfor,
          zterm           TYPE knvv-zterm,
          itext(10),
**************************************  20.01.2021
          vkgrp           TYPE knvv-vkgrp,
          bztxt           TYPE t171t-bztxt,
          bzirk           TYPE knvv-bzirk,
          vkgrp_txt       TYPE tvgrt-bezei,
*************
          inco1           TYPE vbkd-inco1, " Added by Carina Jose on 25.02.2022
          inco2           TYPE vbkd-inco2, " Added by Carina Jose on 25.02.2022
          josgp           TYPE konv-kbetr,
          joigp           TYPE konv-kbetr,
          ztcs            TYPE vbap-netwr, "Added by Raj on 27.10.2023

**   Start added by Archna Gupta on 06.03.2026
          zz1_lid_1_sdh   TYPE vbak-zz1_lid_1_sdh,
          zz1_l1_d_sdh    TYPE vbak-zz1_l1_d_sdh,

          zz1_lid_2_sdh   TYPE vbak-zz1_lid_2_sdh,
          zz1_l2_d_sdh    TYPE vbak-zz1_l2_d_sdh,

          zz1_lid_3_sdh   TYPE vbak-zz1_lid_3_sdh,
          zz1_l3_d_sdh    TYPE vbak-zz1_l3_d_sdh,

          zz1_lid_4_sdh   TYPE vbak-zz1_lid_4_sdh,
          zz1_l4_d_sdh    TYPE vbak-zz1_l4_d_sdh,

          zz1_lid_5_sdh   TYPE vbak-zz1_lid_5_sdh,
          zz1_l5_d_sdh    TYPE vbak-zz1_l5_d_sdh,

          zz1_lid_6_sdh   TYPE vbak-zz1_lid_6_sdh,
          zz1_l6_d_sdh    TYPE vbak-zz1_l6_d_sdh,

          zz1_lid_7_sdh   TYPE vbak-zz1_lid_7_sdh,
          zz1_l7_d_sdh    TYPE vbak-zz1_l7_d_sdh,

          zz1_gid_1_sdh   TYPE vbak-zz1_gid_1_sdh,
          zz1_g1_d_sdh    TYPE vbak-zz1_g1_d_sdh,

          zz1_gid_2_sdh   TYPE vbak-zz1_gid_2_sdh,
          zz1_g2_d_sdh    TYPE vbak-zz1_g2_d_sdh,

          zz1_gid_3_sdh   TYPE vbak-zz1_gid_3_sdh,
          zz1_g3_d_sdh    TYPE vbak-zz1_g3_d_sdh,

          zz1_gid_4_sdh   TYPE vbak-zz1_gid_4_sdh,
          zz1_g4_d_sdh    TYPE vbak-zz1_g4_d_sdh,

          zz1_gid_5_sdh   TYPE vbak-zz1_gid_5_sdh,
          zz1_g5_d_sdh    TYPE vbak-zz1_g5_d_sdh,

          zz1_gid_6_sdh   TYPE vbak-zz1_gid_6_sdh,
          zz1_g6_d_sdh    TYPE vbak-zz1_g6_d_sdh,

          zz1_gid_7_sdh   TYPE vbak-zz1_gid_7_sdh,
          zz1_g7_d_sdh    TYPE vbak-zz1_g7_d_sdh,
**  End of change By Archna Gupta on 06.03.2026
        END OF t_final.

*DATA:v_invquan       TYPE lips-lfimg.
*
*TYPES: BEGIN OF ty_t001w,
*         werks TYPE werks_d,
*       END OF ty_t001w.
*DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w,
*       wa_t001w TYPE ty_t001w.
*
*TYPES : BEGIN OF gi_konv,
*          knumv LIKE konv-knumv,                   " NUMBER OF THE DOCUMENT CONDITION
*          kposn LIKE konv-kposn,                   " CONDITION ITEM NUMBER
*          kschl LIKE konv-kschl,                   " CONDITION TYPE
*          krech LIKE konv-krech,                   " CALCULATION TYPE FOR CONDITION
*          kbetr LIKE konv-kbetr,                   " RATE (CONDITION AMOUNT OR PERCENTAGE)
*          waers LIKE konv-waers,                   " CURRENCY KEY
*          kstat LIKE konv-kstat,                   " CONDITION IS USED FOR STATISTICS
*          kwert LIKE konv-kwert,                   " CONDITION VALUE
*          mwsk1 TYPE konv-mwsk1,
*        END OF gi_konv.
*DATA : it_konv TYPE STANDARD TABLE OF gi_konv,
*       wa_konv TYPE gi_konv.

DATA : wa_final TYPE t_final,
       it_final TYPE STANDARD TABLE OF t_final.
*       lt_vbpa  TYPE STANDARD TABLE OF vbpa,
*       lt_vbkd  TYPE STANDARD TABLE OF vbkd,
*       lt_kna1  TYPE STANDARD TABLE OF kna1,
*       lt_mvke  TYPE STANDARD TABLE OF mvke,
*       lt_mara  TYPE STANDARD TABLE OF mara,
*       lwa_mara TYPE mara,
*       lwa_kna1 TYPE kna1,
*       lwa_mvke TYPE mvke,
*       lwa_vbkd TYPE vbkd,
*       lwa_vbpa TYPE vbpa.

DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv.
*       lv_grswt  TYPE brgew.

*DATA:v_vbeln TYPE thead-tdname.
*DATA:it_line TYPE TABLE OF tline,
*     wa_line TYPE tline.
*
*TYPES: BEGIN OF ty_tvarvc,
*         sign TYPE tvarv_sign,
*         opti TYPE tvarv_opti,
*         low  TYPE tvarv_val,
*         high TYPE tvarv_val,
*       END OF ty_tvarvc.
*
******* Added by Carina Jose on 04.12.2020
*DATA: para TYPE tpara-paramid VALUE 'ZREX',
*      prog TYPE xuvalue.
******* End of changes by Carina Jose on 04.12.2020
*
************* Added by Carina Jose on 08/07/2021
*DATA: it_zone TYPE STANDARD TABLE OF zsd_zone,
*      wa_zone TYPE zsd_zone.
*TYPES : BEGIN OF ty_custemp,
*          kunnr     TYPE zsd_custemp_assg-kunnr,
*          lcategory TYPE zsd_custemp_assg-lcategory,
*          lid       TYPE zsd_custemp_assg-lid,
*          startval  TYPE  zsd_custemp_assg-startval,
*          endval    TYPE  zsd_custemp_assg-endval,
*          lname     TYPE zsd_custemp_assg-lname,
*        END OF ty_custemp.
*DATA : it_custemp  TYPE STANDARD TABLE OF ty_custemp,
*       wa_custemp  TYPE ty_custemp,
*       it_custemp1 TYPE STANDARD TABLE OF ty_custemp,
*       wa_custemp1 TYPE ty_custemp.
************* End of changes on 08/07/2021
*
********************* 03.08.2021
*TYPES: BEGIN OF t_balance,
*         sp_gl_ind  TYPE umskz,
*         currency   TYPE waers,
*         db_cr_ind  TYPE shkzg,
*         t_curr_bal TYPE bapisalfw,
*         loc_currcy TYPE  hwaer,
*         lc_bal     TYPE bapisalhw,
*       END OF t_balance.
*DATA : it_balance TYPE STANDARD TABLE OF t_balance,
*       wa_balance TYPE t_balance.
*
*******************
*
*DATA: lt_acc_key  TYPE STANDARD TABLE OF ty_tvarvc.
*DATA: lwa_acc_key TYPE ty_tvarvc.
CONSTANTS : c_var_user  TYPE rvari_vnam VALUE 'ZSD_STORAGE_LOC',
            c_type_user TYPE rsscr_kind VALUE 'S'.
*
*DATA : lv_desc TYPE t001w-name1.
*DATA: v_gsttotal TYPE vbap-netwr.
*DATA : v_matkl(300).

DATA : ls_hierarchy TYPE zst_hierarchy_flat.
