*&---------------------------------------------------------------------*
*&  Include           ZMM_SU_NUMBER_LIST_REP_SCR
*&---------------------------------------------------------------------*

SELECTION-SCREEN BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.

SELECT-OPTIONS: s_num   FOR zmm_su_number-zsu_no,
                s_matnr FOR zmm_su_number-matnr,
                s_werks FOR zmm_su_number-werks OBLIGATORY,
                s_charg FOR zmm_su_number-charg,
                s_aufnr FOR zmm_su_number-aufnr,
                s_dispo FOR zmm_su_number-dispo,
                s_budat FOR zmm_su_number-budat.

SELECTION-SCREEN END OF BLOCK a1.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-002.

PARAMETERS: p_layout TYPE slis_vari.

SELECTION-SCREEN END OF BLOCK b1.
