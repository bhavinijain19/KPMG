*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_TOP
*&---------------------------------------------------------------------*
*******Types Declaration.

TYPES : BEGIN OF ty_zmm_su_number,
          mandt	     TYPE mandt,
          zsu_no     TYPE zsu_no,
          aufnr	     TYPE aufnr,
          matnr	     TYPE matnr,
          werks	     TYPE werks_d,
          lgort	     TYPE lgort_d,
          charg	     TYPE charg_d,
          zbatch_stk TYPE menge_d, "int4,  "changes made on 12.04.2019
          meins	     TYPE meins,
          lhmg1	     TYPE lvs_lhmng1,
          lety1	     TYPE lvs_letyp1,
          lhme1	     TYPE lhmeh1,
          lgpla      TYPE lgpla,
        END OF ty_zmm_su_number,

        BEGIN OF ty_mch1,
          matnr TYPE  matnr,
          charg TYPE charg_d,
          hsdat TYPE hsdat,
        END OF ty_mch1,

        BEGIN OF ty_makt,
          matnr TYPE matnr,
          maktx TYPE maktx,
        END OF ty_makt,

        BEGIN OF ty_final,
          zsu_no     TYPE zsu_no,
          matnr      TYPE  matnr,
          charg      TYPE charg_d,
          zbatch_stk TYPE zlvs_lhmng12,
          uom        TYPE lhmeh1,
          hsdat      TYPE hsdat,
          maktx      TYPE maktx,
          lgpla      TYPE lgpla,

        END OF ty_final ,

        BEGIN OF ty_zsu_no,
          zsu_no TYPE zsu_no,
        END OF ty_zsu_no .

*        ***************Data Declaration*******************

*********** Added by Carina Jose on 05/01/2022
CONSTANTS: c_uom TYPE rvari_vnam VALUE 'Z_LABEL_UOM'.
DATA : v_uom(03).
DATA : v_region TYPE t005u-bezei.
DATA : v_country TYPE t005t-landx50.
TYPES : BEGIN OF t_header,
          plant_name1(40),
          plant_street(60),
          plant_house_num1(10),
          plant_house_num2(10),
          plant_str_suppl1(40),
          plant_str_suppl2(40),
          plant_str_suppl3(40),
          plant_city1(40),
          plant_city2(40),
          plant_post_code1(10),
          plant_region(10),
          plant_country(10),
        END OF t_header.
DATA : wa_header TYPE t_header.
DATA : it_header TYPE STANDARD TABLE OF t_header.
TYPES : BEGIN OF ty_addr,
          street_address1(200),
          street_address2(200),
          street_address3(200),
          street_address4(200),
          city_address1(200),
          state_address1(200),
        END OF ty_addr.
DATA : it_address TYPE STANDARD TABLE OF ty_addr,
       wa_address TYPE ty_addr.

TYPES: BEGIN OF ty_t001w,
         werks TYPE werks_d,
       END OF ty_t001w.

DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w,
       wa_t001w TYPE ty_t001w.

DATA : v_plant_name(40).
********** End of changes by Carina Jose on 05/01/2022

DATA : it_zmm_su_number   TYPE STANDARD TABLE OF ty_zmm_su_number,
       it_zsu_no          TYPE STANDARD TABLE OF ty_zsu_no,
       wa_zsu_no          TYPE ty_zsu_no,
       wa_zmm_su_number   TYPE ty_zmm_su_number,
       it_makt            TYPE STANDARD TABLE OF ty_makt,
       wa_makt            TYPE ty_makt,
       it_mch1            TYPE STANDARD TABLE OF ty_mch1,
       wa_mch1            TYPE ty_mch1,
       it_final           TYPE STANDARD TABLE OF ty_final,
       wa_final           TYPE ty_final,
       v_form_name        TYPE rs38l_fnam,
       control_parameters TYPE ssfctrlop,
       w_cnt              TYPE i,
       w_cnt2             TYPE i,
       gv_ymcha           TYPE mcha,
       gv_classname       TYPE klah-class,
       it_clbatch         TYPE STANDARD TABLE OF clbatch,
       wa_clbatch         TYPE clbatch.

data : count type i, "Added by Raj on 08.01.2024
      lv_no type i.  "Added by Raj on 08.01.2024

data : lv_mtart type mara-mtart."Added by Raj on 17.06.2024
