*&---------------------------------------------------------------------*
*& Report  ZTEST12134
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

REPORT  zbapi_miro                              .
TABLES: ekko,ekbe,ekpo,lfa1,ekbz,t000,vbak,zobd_mminv.

TYPES: BEGIN OF ty_ekbz,
         xblnr TYPE  xblnr,
         ebeln TYPE  ebeln,
         ebelp TYPE  ebelp,
         vgabe TYPE  vgabe,
         gjahr TYPE  gjahr,
         belnr TYPE  belnr_d,
         buzei TYPE  buzei,
         bewtp TYPE  bewtp,
         budat TYPE  budat,
         menge TYPE  menge_d,
         dmbtr TYPE  dmbtr,
         wrbtr TYPE  wrbtr,
         waers TYPE  waers,
         shkzg TYPE  shkzg,
         lifnr TYPE  lifnr,
         bwtar TYPE  bwtar_d,
         kschl TYPE  kschl,
         ind   TYPE char1,
       END OF ty_ekbz.

TYPES: BEGIN OF ty_item,
         lifnr            TYPE  lifnr,
         po_number        TYPE  bstnr,
*         po_item1(20), "ADDE BY PARTH 13/11/2019
         po_item          TYPE  ebelp,
         invoice_doc_item TYPE  rblgp,
         tax_code         TYPE  mwskz_mrm,
         item_amount      TYPE  bapiwrbtr,
         quantity         TYPE  menge_d,
         po_unit          TYPE  bstme,
         cond_type        TYPE  kschl,
         inv_itm_origin   TYPE inv_itm_origin,
*          xblnr   TYPE xblnr,"ADDE BY PARTH 13/11/2019
         ind              TYPE char1,
       END OF ty_item.

DATA: itemdata         LIKE bapi_incinv_create_item OCCURS 0 WITH HEADER LINE,
      headerdata       LIKE bapi_incinv_create_header OCCURS 0 WITH HEADER LINE,
      return           LIKE bapiret2 OCCURS 0 WITH HEADER LINE,
      bapi_retn_info   LIKE bapiret2 OCCURS 0 WITH HEADER LINE,
      doc_no           LIKE bapi_incinv_fld-inv_doc_no,
      fisc_year        LIKE bapi_incinv_fld-fisc_year,
      i_accountingdata LIKE bapi_incinv_create_account OCCURS 0 WITH HEADER LINE,
      i_tax            LIKE bapi_incinv_create_tax OCCURS 0 WITH HEADER LINE,
      i_wit            LIKE bapi_incinv_create_withtax OCCURS 0 WITH HEADER LINE,
      lt_ekbz_final    TYPE STANDARD TABLE OF ty_ekbz,
      lt_item          TYPE STANDARD TABLE OF ty_item,
      lwa_item         TYPE ty_item,
      lwa_ekbz_final   TYPE ty_ekbz.

DATA:error_flag.
DATA: item_data LIKE ek08bn OCCURS 0 WITH HEADER LINE.
*DATA: lt_item LIKE ek08bn OCCURS 0 WITH HEADER LINE.
DATA: BEGIN OF  itab OCCURS 0,
        p_order LIKE ekpo-ebeln,
        p_item  LIKE ekpo-ebelp,
        p_ctype LIKE konv-kschl,
        p_lifnr LIKE lfa1-lifnr,
      END OF itab.
DATA: order(10)  TYPE n,
      vendor(10) TYPE n.
DATA: lv_frbnr TYPE ek08b-frbnr,
      lv_xblnr TYPE ek08b-xblnr,
      lv_kursf TYPE bkpf-kursf,
      lv_waers TYPE bkpf-waers,
      lv_wwert TYPE bkpf-wwert,
      lv_qty   TYPE menge_d,
      lv_amt   TYPE bapiwrbtr.

DATA: BEGIN OF it_doc OCCURS 0,
        doc_no  LIKE bapi_incinv_fld-inv_doc_no,
        p_order LIKE  ekko-ebeln,
        awkey   LIKE bkpf-awkey,
        fidc    TYPE belnr_d,
        with    TYPE wt_withcd,
      END OF it_doc.


TYPES: BEGIN OF ty_disp,
         po_no TYPE ebeln,
         po_it TYPE ebelp,
       END OF ty_disp.

DATA: fn1 TYPE string,
      l .

DATA: lt_ekko      TYPE STANDARD TABLE OF ekko,
      lt_ekbe      TYPE STANDARD TABLE OF ekbe,
      lt_ekpo      TYPE STANDARD TABLE OF ekpo,
      lt_ekbz      TYPE STANDARD TABLE OF ekbz,
      lt_mseg      TYPE STANDARD TABLE OF mseg,
      lt_vbrk      TYPE STANDARD TABLE OF vbrk,
      lt_vbrp      TYPE STANDARD TABLE OF vbrp,
      lt_likp      TYPE STANDARD TABLE OF likp,
      lt_lips      TYPE STANDARD TABLE OF lips,
      lwa_likp     TYPE STANDARD TABLE OF likp,
      lt_xek08bn   TYPE STANDARD TABLE OF ek08bn,
      lt_disp      TYPE STANDARD TABLE OF ty_disp,
      lt_bkpf      TYPE STANDARD TABLE OF bkpf,
      lt_lfbw      TYPE STANDARD TABLE OF lfbw,
      lwa_lfbw     TYPE lfbw,
      lwa_bkpf     TYPE bkpf,
      lw_disp      TYPE ty_disp,
      lwa_xek08bn  TYPE ek08bn,
      lwa_lips     TYPE lips,
      lwa_ekko     TYPE ekko,
      lwa_ekpo     TYPE ekpo,
      lwa_ekbz     TYPE ekbz,
      lwa_ekbe     TYPE ekbe,
      lwa_mseg     TYPE mseg,
      lwa_vbrk     TYPE vbrk,
      lwa_vbrp     TYPE vbrp,
*      p_year(4)    TYPE c, COMMENT BY PARTH 12.01.2016
      p_year1(4)   TYPE c, "ADDED BY PARTH 12.01.2016
      lv_count(6)  TYPE n,
      lv_count1(2) TYPE n,
      lv_dmbtr     TYPE dmbtr,
      lv_gstpar    TYPE rbkp-gst_part,              "add RP
      lv_plcsup    TYPE  rbkp-plc_sup.             "add RP.
DATA: v_zterm      TYPE lfb1-zterm."Added by Raj on 25.04.2024
*****" Added for auth. at company level by Carina Jose on 06.03.2020
TYPES: BEGIN OF ty_t001,
         bukrs TYPE bukrs,
       END OF ty_t001.
DATA : gt_t001 TYPE STANDARD TABLE OF ty_t001,
       wa_t001 TYPE ty_t001.
" ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*DATA: it_bplace TYPE STANDARD TABLE OF j_1bbranch,
*      wa_bplace TYPE j_1bbranch.
DATA: it_bplace TYPE STANDARD TABLE OF p_businessplace,
      wa_bplace TYPE p_businessplace.
" ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*****" Added for auth. at company level by Carina Jose on 06.03.2020
DATA: i_bukrs  TYPE rbkp_v-bukrs,
      i_lifnr  TYPE  rbkp_v-lifnr,
      i_waers  TYPE rbkp_v-waers,
      i_refdoc TYPE rbkp_v-xblnr,
      i_bldat  TYPE rbkp_v-bldat,
      i_dmbtr  TYPE rbkp_v-rmwwr,
      i_xrech  TYPE rbkp_v-xrech,
      v_line   TYPE sy-tabix,
      lv_cnt   TYPE sy-tabix.
CONSTANTS : lc_v3 TYPE periv VALUE 'V3'.

DATA: st_date    TYPE sy-datum,  " current year start date
      lst_date   TYPE sy-datum, "last year start date
      en_date    TYPE sy-datum,  "current year end date
      len_date   TYPE sy-datum,  "last year end date
      lv_date    TYPE sy-datum,
      lv_valid   TYPE sy-datum,
      lv_year(4) TYPE c,
      fy_year(4) TYPE c.
*      wa_tvarvc  TYPE tvarvc.
DATA : lv_msg TYPE string.
DATA: low_date(10),
      high_date(10),
      d_ind(4).

DATA: lv_fy(4)  TYPE c,
      lv_fiscal TYPE gjahr.
DATA: lv_firstd TYPE sy-datum,
      lv_lastd  TYPE sy-datum.
DATA: lv_value TYPE tvarvc.
DATA: lt_value TYPE TABLE OF tvarvc.
DATA:llt_tvar TYPE TABLE OF tvarvc.


*======================================================================*
*                     SELECTION SCREEN                                 *
*======================================================================*
*SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
*SELECT-OPTIONS   : s_xblnr FOR vbak-vbeln OBLIGATORY.
*PARAMETERS       : p_dmbtr  TYPE bapi_rmwwr OBLIGATORY,
*                   p_dmbtr1 TYPE bapi_rmwwr OBLIGATORY, "added by parth 28/06/2019
*                   p_lifnr  TYPE lifnr OBLIGATORY,
*                   p_year   TYPE gjahr OBLIGATORY,
*                   p_refdoc TYPE xblnr OBLIGATORY,
*                   p_datum  TYPE datum DEFAULT sy-datum,
*                   p_bldat  TYPE datum DEFAULT sy-datum,
*                   p_bukrs  TYPE bukrs OBLIGATORY DEFAULT '1000',
*                   p_txcod  TYPE ekpo-mwskz OBLIGATORY,
*                   p_bupla  TYPE bseg-bupla OBLIGATORY,
**                   p_secco  TYPE bseg-secco OBLIGATORY,
*                   p_text   TYPE sgtxt,
*                   p_simu   TYPE xsimu AS CHECKBOX DEFAULT 'X'.
*SELECTION-SCREEN : END OF BLOCK b1.

"""""""""""""""""""SQUIRREL

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(15) TEXT-002 FOR FIELD s_xblnr .
    SELECT-OPTIONS   : s_xblnr FOR vbak-vbeln OBLIGATORY.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-000 FOR FIELD s_xblnr .
    PARAMETERS : p_dmbtr  TYPE bapi_rmwwr OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-001 FOR FIELD t_name1 .
    PARAMETERS: t_name1 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-003 FOR FIELD s_xblnr .
    PARAMETERS : p_dmbtr1  TYPE bapi_rmwwr OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-004 FOR FIELD t_name2 .
    PARAMETERS: t_name2 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-005 FOR FIELD s_xblnr .
    PARAMETERS : p_lifnr  TYPE lifnr OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-006 FOR FIELD t_name3 .
    PARAMETERS: t_name3 TYPE lines.

  SELECTION-SCREEN END OF LINE.


  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-007 FOR FIELD s_xblnr .
    PARAMETERS : p_year  TYPE gjahr OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-008 FOR FIELD t_name4 .
    PARAMETERS: t_name4 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-009 FOR FIELD s_xblnr .
    PARAMETERS : p_refdoc  TYPE xblnr OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-010 FOR FIELD t_name5 .
    PARAMETERS: t_name5 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-011 FOR FIELD s_xblnr .
    PARAMETERS : p_datum  TYPE datum DEFAULT sy-datum.

    SELECTION-SCREEN COMMENT 58(12) TEXT-012 FOR FIELD t_name6 .
    PARAMETERS: t_name6 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-013 FOR FIELD s_xblnr .
    PARAMETERS : p_bldat  TYPE datum DEFAULT sy-datum.

    SELECTION-SCREEN COMMENT 58(12) TEXT-014 FOR FIELD t_name7 .
    PARAMETERS: t_name7 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-015 FOR FIELD s_xblnr .
    PARAMETERS : p_bukrs  TYPE bukrs OBLIGATORY DEFAULT '1000'.

    SELECTION-SCREEN COMMENT 58(12) TEXT-016 FOR FIELD t_name8 .
    PARAMETERS: t_name8 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-017 FOR FIELD s_xblnr .
    PARAMETERS : p_txcod  TYPE ekpo-mwskz OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-018 FOR FIELD t_name9 .
    PARAMETERS: t_name9 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-019 FOR FIELD s_xblnr .
    PARAMETERS : p_bupla  TYPE bseg-bupla OBLIGATORY.

    SELECTION-SCREEN COMMENT 58(12) TEXT-020 FOR FIELD t_name10 .
    PARAMETERS: t_name10 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-021 FOR FIELD s_xblnr .
    PARAMETERS : p_text  TYPE sgtxt OBLIGATORY.

*SELECTION-SCREEN COMMENT 65(10) text-022 FOR FIELD t_name10 .
*PARAMETERS: t_name11 TYPE lines.

  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(18) TEXT-023 FOR FIELD s_xblnr .
    PARAMETERS   : p_simu TYPE xsimu AS CHECKBOX DEFAULT 'X' .
*PARAMETERS   : p_simu TYPE xsimu NO-DISPLAY. "AS CHECKBOX DEFAULT 'X' .
  SELECTION-SCREEN END OF LINE.

  PARAMETERS: p_blart TYPE blart DEFAULT 'RE'.

SELECTION-SCREEN : END OF BLOCK b1.


"Adding Start by Rahul Vasita on 19.06.2024 12:22:59

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_blart.
  DATA: gt_return  TYPE TABLE OF ddshretval,
        gwa_return TYPE ddshretval.
  SELECT blart,
         ltext
    FROM t003t
  INTO TABLE @DATA(lt_blart)
  WHERE spras = @sy-langu.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'BLART'
      value_org       = 'S'
    TABLES
      value_tab       = lt_blart
      return_tab      = gt_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.

  READ TABLE gt_return INTO gwa_return INDEX 1.
  IF sy-subrc = 0.
    p_blart = gwa_return-fieldval.
  ENDIF.
  "Adding End by Rahul Vasita on 19.06.2024 12:22:59

AT SELECTION-SCREEN ON p_refdoc.
  IF p_refdoc IS NOT INITIAL.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT *
*    FROM tvarvc
*     INTO TABLE llt_tvar   "Table for tvarvc
*    WHERE name  = 'ZFI_REFERENCE' .

    SELECT *
        FROM tvarvc
         INTO TABLE llt_tvar   "Table for tvarvc
        WHERE name  = 'ZFI_REFERENCE' ORDER BY PRIMARY KEY .

* End of Quick Fix



    READ TABLE llt_tvar INTO DATA(lw_tvar) INDEX 1.
    IF sy-subrc = 0.
      IF  p_refdoc CA CONV string( lw_tvar-low ) .
*    IF p_refdoc CA ':;_`~!@#$%^&*()+=|\]}{["?.>,<' OR p_refdoc CA |'|.
        MESSAGE 'Only - and / characters allowed' TYPE 'E' .
      ENDIF.
    ENDIF.
  ENDIF.

AT SELECTION-SCREEN OUTPUT.

  LOOP AT SCREEN.
    IF screen-name = 'T_NAME1'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME2'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME3'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME4'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME5'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME6'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME7'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME8'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME9'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME10'.
      screen-input = 0.
      MODIFY SCREEN.
    ELSEIF screen-name = 'T_NAME11'.
      screen-input = 0.
      MODIFY SCREEN.

    ELSEIF screen-name = 'P_LIFNR'.
      IF  p_lifnr IS NOT INITIAL.
        CLEAR: t_name1,t_name2,t_name3,t_name4,t_name5,t_name6,t_name7,t_name8,t_name9,t_name10.
*          T_NAME1 = 'Name1'.
        SELECT SINGLE * FROM lfa1 INTO @DATA(ls_lfa1) WHERE lifnr = @p_lifnr.
        IF ls_lfa1 IS NOT INITIAL.
          t_name1 = ls_lfa1-name1.
          t_name8 = ls_lfa1-stcd3.
          t_name6 = ls_lfa1-telf1.
          CONCATENATE ls_lfa1-pstlz ls_lfa1-ort01 ls_lfa1-ort02 INTO t_name4  SEPARATED BY space.
          t_name5 = ls_lfa1-regio.

*          t_name10 = ls_lfa1-regio.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*          SELECT SINGLE * FROM adrc INTO @DATA(ls_adrc) WHERE addrnumber = @ls_lfa1-adrnr.

          SELECT * FROM adrc INTO @DATA(ls_adrc) UP TO 1 ROWS WHERE addrnumber = @ls_lfa1-adrnr
           ORDER BY PRIMARY KEY .
          ENDSELECT.

* End of Quick Fix

          t_name2 = ls_adrc-str_suppl1.
          t_name3 = ls_adrc-str_suppl2.
        ENDIF.

        " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*        SELECT SINGLE j_1ipanno FROM j_1imovend INTO @DATA(ls_panno) WHERE lifnr = @p_lifnr.
        SELECT SINGLE j_1ipanno FROM lfa1 INTO @DATA(ls_panno) WHERE lifnr = @p_lifnr.
        " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

        t_name7 = ls_panno.

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*        SELECT * FROM lfbw INTO TABLE @DATA(lt_lfbw) WHERE lifnr = @p_lifnr  AND bukrs = @p_bukrs.

        SELECT * FROM lfbw INTO TABLE @DATA(lt_lfbw) WHERE lifnr = @p_lifnr AND bukrs = @p_bukrs
         ORDER BY PRIMARY KEY .

* End of Quick Fix


        LOOP AT lt_lfbw INTO DATA(ls_lfbw) FROM 1 TO 2.
          IF sy-tabix = 1.
            CONCATENATE ls_lfbw-witht ls_lfbw-wt_withcd ls_lfbw-wt_subjct ls_lfbw-qsrec INTO t_name9 SEPARATED BY space.
          ELSEIF sy-tabix = 2.
            CONCATENATE ls_lfbw-witht ls_lfbw-wt_withcd ls_lfbw-wt_subjct ls_lfbw-qsrec INTO t_name10 SEPARATED BY space.
          ENDIF.
        ENDLOOP.
        CLEAR: ls_lfa1,ls_adrc,ls_panno,ls_lfbw. REFRESH: lt_lfbw.
      ELSE.
        CLEAR: t_name1,t_name2,t_name3,t_name4,t_name5,t_name6,t_name7,t_name8,t_name9,t_name10.
      ENDIF.
    ENDIF.

  ENDLOOP.


  """""""""""""""""""""



*INITIALIZATION.

*  CALL FUNCTION 'GM_GET_FISCAL_YEAR'
*    EXPORTING
*      i_date                     = p_datum
*      i_fyv                      = lc_v3
*    IMPORTING
*      e_fy                       = p_year
*    EXCEPTIONS
*      fiscal_year_does_not_exist = 1
*      not_defined_for_date       = 2
*      OTHERS                     = 3.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.


START-OF-SELECTION.
  """"""""Begin of pankaj k on 14.03.2024
  IF p_bldat IS NOT INITIAL.
    IF p_bldat GT sy-datum.
      MESSAGE 'Please do not enter future date for Document date' TYPE 'E' DISPLAY LIKE 'E'.
    ENDIF.
  ENDIF.
*  Get fiscal year
  CALL FUNCTION 'GM_GET_FISCAL_YEAR'
    EXPORTING
      i_date = p_bldat
      i_fyv  = 'V3'
    IMPORTING
      e_fy   = lv_fy.

  IF lv_fy IS NOT INITIAL.
    lv_fiscal = lv_fy.

*   Get first and last date for fiscal year
    CALL FUNCTION 'FIRST_AND_LAST_DAY_IN_YEAR_GET'
      EXPORTING
        i_gjahr        = lv_fiscal
        i_periv        = 'V3'
      IMPORTING
        e_first_day    = lv_firstd
        e_last_day     = lv_lastd
      EXCEPTIONS
        input_false    = 1
        t009_notfound  = 2
        t009b_notfound = 3
        OTHERS         = 4.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    DATA(lv_postyear) = lv_fy + 1.
    DATA: lv_post_date TYPE char10,
          lv_postyear1 TYPE char4.

    DATA: lv_limit_date TYPE sy-datum.

    lv_postyear1 = lv_postyear.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT  * FROM tvarvc INTO TABLE lt_value WHERE name = 'Z_DOC DATE_VALIDATE'.

    SELECT  * FROM tvarvc INTO TABLE lt_value WHERE name = 'Z_DOC DATE_VALIDATE' ORDER BY PRIMARY KEY .

* End of Quick Fix

    READ TABLE lt_value INTO DATA(wa_value) INDEX 1.
    lv_value = wa_value-low.

    CONCATENATE lv_postyear1 lv_value INTO lv_post_date.
    CONDENSE lv_post_date NO-GAPS.
*    CONCATENATE lv_postyear1 '10' '31' INTO lv_post_date.
    lv_limit_date = lv_post_date.

    IF  p_datum NOT BETWEEN lv_firstd AND lv_limit_date.
      MESSAGE 'Document date is not in valid period' TYPE 'E'.
    ENDIF.
  ENDIF.
  """""""""""""End of pankaj k

  PERFORM authorization_check.  " Added for auth. at company level by Carina Jose on 06.03.2020

* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT * FROM ekbz
*           INTO TABLE lt_ekbz
*           WHERE gjahr = p_year
**             AND vgabe = '6'
*             AND bewtp = 'F'
*  AND xblnr IN s_xblnr.

  SELECT * FROM ekbz
             INTO TABLE lt_ekbz
             WHERE gjahr = p_year
*             AND vgabe = '6'
               AND bewtp = 'F'
    AND xblnr IN s_xblnr ORDER BY PRIMARY KEY .

* End of Quick Fix


  IF lt_ekbz[] IS NOT INITIAL.
    LOOP AT lt_ekbz INTO lwa_ekbz.
      lv_dmbtr = lv_dmbtr + lwa_ekbz-dmbtr.
    ENDLOOP.
    SELECT * FROM ekpo
             INTO TABLE lt_ekpo
             FOR ALL ENTRIES IN lt_ekbz
             WHERE ebeln = lt_ekbz-ebeln
    AND ebelp = lt_ekbz-ebelp.
    IF lt_ekpo[] IS NOT INITIAL.
      SELECT * FROM ekko
               INTO TABLE lt_ekko
                FOR ALL ENTRIES IN lt_ekpo
      WHERE ebeln = lt_ekpo-ebeln.
    ENDIF.
    LOOP AT lt_ekko INTO lwa_ekko.
      i_bukrs       = p_bukrs.
      i_lifnr       = p_lifnr.
      i_waers       = lwa_ekko-waers.
      i_refdoc      = p_refdoc.
      i_bldat       = p_bldat.
      i_dmbtr       = p_dmbtr.
      i_xrech       = 'X'.


      CALL FUNCTION 'MRM_DUPLICATE_INVOICE_CHECK'
        EXPORTING
          i_bukrs                = i_bukrs
          i_lifnr                = i_lifnr
          i_waers                = i_waers
          i_xblnr                = i_refdoc
          i_bldat                = i_bldat
          i_rmwwr                = i_dmbtr
          i_xrech                = i_xrech
*         I_BELNR                =
*         I_BLART                =
*         I_PREPAY_AWKEY         =
        EXCEPTIONS
          invoice_already_exists = 1
          OTHERS                 = 2.
      IF sy-subrc = 0.
*        MESSAGE 'Invoice Already Exists' TYPE 'E'.
      ENDIF.
    ENDLOOP.
  ELSE.
    MESSAGE 'Data Doesnot Exist' TYPE 'E'.
  ENDIF.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT * FROM lfbw
*       INTO TABLE lt_lfbw
*       WHERE lifnr = p_lifnr
*  AND bukrs  = p_bukrs.

  SELECT * FROM lfbw
         INTO TABLE lt_lfbw
         WHERE lifnr = p_lifnr
    AND bukrs  = p_bukrs ORDER BY PRIMARY KEY .

* End of Quick Fix

  "Start of add by RP
  SELECT lifnr regio
     FROM lfa1
  INTO  (lv_gstpar, lv_plcsup)
  WHERE lifnr = p_lifnr.
  ENDSELECT.
  "End of add by RP

*************************Begin of changes Added by Raj on 25.04.2024*****************************

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE zterm FROM lfb1 INTO v_zterm WHERE lifnr = p_lifnr.

  SELECT zterm FROM lfb1 INTO v_zterm UP TO 1 ROWS WHERE lifnr = p_lifnr
   ORDER BY PRIMARY KEY .
  ENDSELECT.

* End of Quick Fix

*************************End of changes Added by Raj on 25.04.2024*******************************
  READ TABLE lt_ekbz INTO lwa_ekbz INDEX 1.
  IF sy-subrc EQ 0.
***************    Header Data
    headerdata-invoice_ind    = 'X'.
*    headerdata-doc_type       = 'RE'. "Comment by Rahul Vasita on 19.06.2024 12:21:33
    headerdata-doc_type       = p_blart. "Added by Rahul Vasita on 19.06.2024 12:21:33
    headerdata-doc_date       = p_bldat.
    headerdata-pstng_date     = p_datum.
    headerdata-ref_doc_no     = p_refdoc."lwa_ekbz-ebeln.
    headerdata-comp_code      = p_bukrs.
    headerdata-diff_inv       = p_lifnr.
    headerdata-currency       = lwa_ekbz-waers.
*    headerdata-gross_amount   = p_dmbtr."comment by parth 28/06/2019
    headerdata-gross_amount   = p_dmbtr1. "added by parth 28/06/2019
    headerdata-bline_date     = sy-datum.
    headerdata-del_costs_taxc = p_txcod.
    headerdata-calc_tax_ind   = 'X'.
    headerdata-simulation     = p_simu. " For Simulation
    headerdata-item_text      = p_text.
    headerdata-business_place = p_bupla.
*    headerdata-zzsecco        = p_secco. "comment by parth 05.02.2021
    headerdata-zzsecco        = p_bupla. "add by parth 05.02.2021
    headerdata-zzgst_part        = lv_gstpar.               "add RP
    headerdata-zzplc_sup        = lv_plcsup.                "add RP
    headerdata-pmnttrms         = v_zterm."Added by Raj on 25.04.2024
    APPEND headerdata.
*    CLEAR headerdata.
  ENDIF.

  SORT lt_ekbz_final[] BY xblnr.



  LOOP AT lt_ekbz INTO lwa_ekbz.
    CALL FUNCTION 'ME_READ_COND_INVOICE'
      EXPORTING
        i_ebeln        = lwa_ekbz-ebeln
        i_ebelp        = lwa_ekbz-ebelp
        i_lifnr        = lwa_ekbz-lifnr "p_lifnr
      TABLES
        xek08bn        = lt_xek08bn
      EXCEPTIONS
        enqueue_failed = 1
        OTHERS         = 2.
    IF sy-subrc = 0.
      CLEAR : lwa_xek08bn.
      READ TABLE lt_xek08bn INTO lwa_xek08bn WITH KEY ebeln = lwa_ekbz-ebeln ebelp = lwa_ekbz-ebelp.
      IF sy-subrc EQ 0.
        IF lwa_xek08bn-remng GE lwa_xek08bn-wemng.
          itemdata-inv_itm_origin = 'X'.

*          CONTINUE.
        ENDIF.
      ENDIF.
    ENDIF.
    lv_count = lv_count + 1 .
    lv_count1 = lv_count1 + 1 .
    itemdata-invoice_doc_item = lv_count .
    lwa_item-invoice_doc_item = lv_count .
    itemdata-po_number        = lwa_ekbz-ebeln.
    lwa_item-po_number        = lwa_ekbz-ebeln.
    itemdata-po_item          = lwa_ekbz-ebelp.
    lwa_item-po_item          = lwa_ekbz-ebelp.
    itemdata-tax_code         = p_txcod.
    lwa_item-tax_code         = p_txcod.

    itemdata-item_amount      = ( p_dmbtr * lwa_ekbz-dmbtr ) / lv_dmbtr .

    lwa_item-item_amount      = ( p_dmbtr * lwa_ekbz-dmbtr ) / lv_dmbtr .
    itemdata-quantity         = lwa_ekbz-menge.
    lwa_item-quantity         = lwa_ekbz-menge.
*    lwa_item-xblnr            = lwa_ekbz-xblnr.

    itemdata-ref_doc          = '80078577'.

    READ TABLE lt_ekpo INTO lwa_ekpo WITH KEY ebeln = lwa_ekbz-ebeln ebelp = lwa_ekbz-ebelp.
    IF sy-subrc EQ 0.
      itemdata-po_unit        = lwa_ekpo-meins.
      itemdata-po_pr_uom      = lwa_ekpo-meins."added by JKT on 30.06.2020
      lwa_item-po_unit        = lwa_ekpo-meins.
    ENDIF.
    itemdata-cond_type  = lwa_ekbz-kschl.
    lwa_item-cond_type  = lwa_ekbz-kschl.
    APPEND itemdata.

    lwa_item-lifnr = lwa_ekbz-lifnr.
    lwa_item-inv_itm_origin = itemdata-inv_itm_origin.
    APPEND lwa_item TO lt_item.
    CLEAR : lwa_item, itemdata.
  ENDLOOP.

  LOOP AT itemdata WHERE inv_itm_origin = 'X'.
    lw_disp-po_no = itemdata-po_number.
    lw_disp-po_it = itemdata-po_item.
    APPEND lw_disp TO lt_disp.
    CLEAR : lw_disp.
  ENDLOOP.
  SORT lt_disp[] BY po_no po_it.
  DELETE ADJACENT DUPLICATES FROM lt_disp COMPARING ALL FIELDS.
  IF lt_disp IS NOT INITIAL.
    LOOP AT lt_disp INTO lw_disp.
      WRITE:/ 'Deliveries already processed for this PO' , lw_disp-po_no , lw_disp-po_it.
    ENDLOOP.
    LOOP AT lt_lfbw INTO lwa_lfbw.
      WRITE :/ 'Withholding Tax Code' , lwa_lfbw-witht.
    ENDLOOP.


  ELSE.
    DELETE itemdata[] WHERE inv_itm_origin = 'X'.
    DELETE lt_item[] WHERE inv_itm_origin = 'X'.
*    loop at lt_item into lwa_item.
*      CONCATENATE lwa_item-po_item lwa_item-xblnr into lwa_item-po_item1.
*      MODIFY lt_item from lwa_item TRANSPORTING po_item1.
*    endloop.
    SORT lt_item[] BY lifnr po_number po_item.
    LOOP AT lt_item INTO lwa_item.
      lv_amt = lv_amt + lwa_item-item_amount.
      lv_qty = lv_qty + lwa_item-quantity.

      AT END OF po_item.
        lwa_item-item_amount = lv_amt.
        lwa_item-quantity    = lv_qty.
        lwa_item-ind         = 'X'.
        MODIFY lt_item FROM lwa_item TRANSPORTING item_amount quantity ind.
        CLEAR : lv_amt,lv_qty.
      ENDAT.
    ENDLOOP.
    DELETE lt_item WHERE ind NE 'X'.
    REFRESH : itemdata[].
    LOOP AT lt_item INTO lwa_item.
      MOVE-CORRESPONDING lwa_item TO itemdata.
      APPEND itemdata.
      CLEAR : itemdata.
    ENDLOOP.
    CLEAR : lv_count.
    LOOP AT itemdata.
      lv_count = lv_count + 1 .
*    lv_count1 = lv_count1 + 1 .
      itemdata-invoice_doc_item = lv_count .
      MODIFY itemdata TRANSPORTING invoice_doc_item.
    ENDLOOP.
*    IF itemdata[] IS INITIAL.
*      MESSAGE 'Document Already Processed' TYPE 'E'.
*    ELSE.


    "Adding Start by Rahul Vasita on 17.06.2024 10:53:53 " GST Validations T-APLITSS00034
    PERFORM check_gst_validations.
    "Adding End by Rahul Vasita on 17.06.2024 10:53:53 "GST Validations T-APLITSS00034

    PERFORM bapi_create.
*    ENDIF.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  BAPI_CREATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bapi_create .
*  i_tax-tax_code = 'V0'.
*  i_tax-tax_amount = '0'.
*  APPEND i_tax.


  LOOP AT lt_lfbw INTO lwa_lfbw.
    i_wit-split_key   = '000001'.
    i_wit-wi_tax_type = lwa_lfbw-witht.
    i_wit-wi_tax_code = lwa_lfbw-wt_withcd.
*  i_wit-wi_tax_base =
*  i_wit-wi_tax_amt  =
*  i_wit-wi_tax_withheld_amt =
    APPEND i_wit.
  ENDLOOP.

*  i_tax-tax_code = p_txcod.
*  i_tax-tax_amount = p_dmbtr.
*  APPEND i_tax.

*  fisc_year = p_year.

  " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
  CALL FUNCTION 'BAPI_INCOMINGINVOICE_CREATE' "#EC CI_USAGE_OK[2438131]
    " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  CALL FUNCTION 'BAPI_INCOMINGINVOICE_PARK' "comment not working as per requirment 22.02.2023
    EXPORTING
      headerdata       = headerdata
    IMPORTING
      invoicedocnumber = doc_no
      fiscalyear       = fisc_year
*     fiscalyear       = '2016'
*     fiscalyear       = P_YEAR
    TABLES
      itemdata         = itemdata[]
      accountingdata   = i_accountingdata
      taxdata          = i_tax
      withtaxdata      = i_wit
      return           = return.


  IF sy-subrc <>  0.
    MESSAGE e999(re) WITH  'Problem occured'.
  ELSE.
    LOOP AT return.
      IF NOT return IS INITIAL.
        CLEAR bapi_retn_info.
        MOVE-CORRESPONDING return TO bapi_retn_info.
        IF return-type = 'A' OR return-type = 'E'.
          error_flag = 'X'.
        ENDIF.
        APPEND bapi_retn_info.
      ENDIF.
    ENDLOOP.
    IF error_flag = 'X'.
      LOOP AT bapi_retn_info.
        WRITE :/ bapi_retn_info-type,bapi_retn_info-message.
      ENDLOOP.
*      MESSAGE e999(re) WITH  'Problem occured'.
*      ROLLBACK WORK.
    ELSE.
*      Return Table from BAPI call is empty
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait   = 'X'
        IMPORTING
          return = return.
*      BREAK-POINT.
      LOOP AT lt_ekbz INTO lwa_ekbz.
        zobd_mminv-budat   =  p_datum.
        zobd_mminv-vbeln   =  lwa_ekbz-xblnr.
        zobd_mminv-belnr   =  doc_no.
        zobd_mminv-gjahr   =  fisc_year.
        zobd_mminv-cancel  =  ''.
        zobd_mminv-erdat  =  sy-datum.
        zobd_mminv-ertim  =  sy-uzeit.
        MODIFY zobd_mminv.
      ENDLOOP.
    ENDIF.
  ENDIF.
*  WRITE:/ 'Document no :', doc_no.
  it_doc-doc_no = doc_no.
*  it_doc-p_order = itab-p_order.
  APPEND it_doc.

  CALL FUNCTION 'GM_GET_FISCAL_YEAR'
    EXPORTING
      i_date                     = p_datum
      i_fyv                      = lc_v3
    IMPORTING
      e_fy                       = p_year1
    EXCEPTIONS
      fiscal_year_does_not_exist = 1
      not_defined_for_date       = 2
      OTHERS                     = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

*  CLEAR it_doc.
  LOOP AT it_doc.
*    CONCATENATE it_doc-doc_no p_year INTO it_doc-awkey." COMMENT BY PARTH FOR FISCAL YEAR
    CONCATENATE it_doc-doc_no p_year1 INTO it_doc-awkey." ADDED BY PARTH
    MODIFY it_doc TRANSPORTING awkey.
  ENDLOOP.

  IF it_doc[] IS NOT INITIAL.
    SELECT * FROM bkpf
             INTO TABLE lt_bkpf
             FOR ALL ENTRIES IN it_doc
    WHERE awkey = it_doc-awkey.
    LOOP AT it_doc.
      READ TABLE lt_bkpf INTO lwa_bkpf WITH KEY awkey = it_doc-awkey.
      IF sy-subrc EQ 0.
        it_doc-fidc = lwa_bkpf-belnr.
        MODIFY it_doc TRANSPORTING fidc.
      ENDIF.
    ENDLOOP.
  ENDIF.

  DESCRIBE TABLE lt_lfbw LINES v_line.
  LOOP AT it_doc.
    IF it_doc-doc_no = ' '.
      IF lt_lfbw[] IS NOT INITIAL.
        DO v_line TIMES.
          lv_cnt = lv_cnt + 1.
          CLEAR : lwa_lfbw.
          READ TABLE lt_lfbw INTO lwa_lfbw INDEX lv_cnt.
*          it_doc-with = lwa_lfbw-witht.
          WRITE :/ 'Withholding Tax Code' , lwa_lfbw-witht.
        ENDDO.
      ENDIF.


      WRITE:/ 'Program Run in Simulation Mode - No Errors' , it_doc-p_order.
    ELSE.
      WRITE:/ 'MM Document No:' , it_doc-doc_no.", 'p.order:' , it_doc-p_order.
      WRITE:/ 'FI Document No:' , it_doc-fidc.
    ENDIF.
  ENDLOOP.
ENDFORM.                    " BAPI_CREATE
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT bukrs FROM t001 INTO TABLE gt_t001 WHERE bukrs = p_bukrs.
  LOOP AT gt_t001 INTO wa_t001.
    AUTHORITY-CHECK OBJECT 'F_BKPF_BUK'
    ID 'BUKRS' FIELD wa_t001-bukrs
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorized for the company code' TYPE 'E' .
    ENDIF.
  ENDLOOP.

  " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*  SELECT * FROM j_1bbranch INTO TABLE it_bplace WHERE bukrs = p_bukrs.
  SELECT * FROM p_businessplace INTO TABLE @it_bplace WHERE bukrs = @p_bukrs.
  " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

  READ TABLE it_bplace INTO wa_bplace WITH KEY branch = p_bupla.

  IF sy-subrc <> 0.
    MESSAGE 'Please enter correct business place' TYPE 'E'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_GST_VALIDATIONS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_gst_validations .
  DATA : lv_vregio       TYPE lfa1-regio,
         lv_lifnr1       TYPE lfa1-lifnr,
         lv_region       TYPE csks-regio,
         " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*         lv_adrnr        TYPE j_1bbranch-adrnr,
         lv_adrnr        TYPE p_businessplace-adrnr,
         " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
         lv_bupla_region TYPE csks-regio,
         lv_ktokk        TYPE lfa1-ktokk.
  CLEAR lv_lifnr1.
*  lv_lifnr1 = VALUE #( it_accit[ koart = 'K' ]-lifnr OPTIONAL ).
  lv_lifnr1 = p_lifnr.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*  SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_gstswitch) WHERE name = 'ZFI_GSTIN_EN_SWITCH' AND type = 'P'.

  SELECT name , low FROM tvarvc INTO @DATA(ls_gstswitch) UP TO 1 ROWS WHERE name = 'ZFI_GSTIN_EN_SWITCH' AND type = 'P'
   ORDER BY PRIMARY KEY .
  ENDSELECT.

* End of Quick Fix

  IF ls_gstswitch-low = abap_true.
    SELECT SINGLE ktokk FROM lfa1 INTO lv_ktokk WHERE lifnr = lv_lifnr1.
    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_ktokk) WHERE name = 'ZFI_GSTIN_EN_KTOKK' AND type = 'S' AND low = @lv_ktokk. "Added by Rahul Vasita on 18.07.2024 15:29:39
**      IF lv_ktokk <> 'ZCEM'. "Comment by Rahul Vasita on 18.07.2024 15:29:46
    IF sy-subrc <> 0. "Added by Rahul Vasita on 18.07.2024 15:29:58
      SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_import) WHERE name = 'ZFI_GSTIN_IMPORT' AND type = 'S' AND low = @lv_ktokk.
      IF sy-subrc = 0.
        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_endetail) WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = @sy-tcode.
        IF ls_endetail IS NOT INITIAL.
*          LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '. "Comment by Rahul Vasita on 17.06.2024 10:58:13
          SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_imtax) WHERE name = 'ZFI_GSTIN_IMPORT_TX' AND type = 'S' AND low = @p_txcod.
          IF sy-subrc <> 0.
            MESSAGE e007(zrcm_gst_en).
          ENDIF."End of LS_IMTAX
*          CLEAR wa_accit. "Comment by Rahul Vasita on 17.06.2024 11:23:42
*          ENDLOOP. "Comment by Rahul Vasita on 17.06.2024 10:58:16
        ENDIF."IF ls_endetail IS NOT INITIAL.
      ELSE.
        CLEAR : ls_endetail.
        SELECT SINGLE name  low FROM tvarvc INTO ls_endetail WHERE name = 'ZFI_GSTIN_TCODE' AND type = 'S' AND low = sy-tcode.
        IF ls_endetail IS NOT INITIAL.
          SELECT SINGLE * FROM zfi_gstin_exl INTO @DATA(ls_splifnr) WHERE lifnr = @lv_lifnr1.
          IF sy-subrc <> 0.
*            LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '. "Comment by Rahul Vasita on 17.06.2024 10:58:04
            " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*            SELECT SINGLE lifnr , ven_class FROM j_1imovend INTO @DATA(ls_j_1imovend) WHERE lifnr = @lv_lifnr1. "#EC CI_USAGE_OK[2877717]
            SELECT SINGLE lifnr , ven_class FROM lfa1 INTO @DATA(ls_j_1imovend) WHERE lifnr = @lv_lifnr1. "#EC CI_USAGE_OK[2877717]
            " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
            IF ls_j_1imovend-ven_class = '0'.
              SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_excep) WHERE name = 'ZFI_GSTIN_P1_V2_EX' AND type = 'S' AND low = @p_txcod.
              IF sy-subrc <> 0.
                "Comment Start by Rahul Vasita on 17.06.2024 11:34:57
                IF headerdata-doc_type = 'RM'.
                  SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v2) WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = @p_txcod.
                  IF sy-subrc <> 0.
                    "Error Message for Validation No 2
                    MESSAGE e000(zrcm_gst_en)." WITH p_txcod.
                  ELSE.
                    "If Doc. Type is RM Starts

                    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v3) WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = @p_txcod.
                    IF sy-subrc <> 0.
                      "Error Message for Validation No 3
                      MESSAGE e001(zrcm_gst_en)." WITH p_txcod.
                    ELSE.
                      "Validation Code 6 Starts
                      CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                      SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                        SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = headerdata-business_place.

                      " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*SELECT ADRNR FROM J_1BBRANCH INTO LV_ADRNR UP TO 1 ROWS WHERE BRANCH = HEADERDATA-BUSINESS_PLACE
* ORDER BY PRIMARY KEY .
* ENDSELECT.
                      SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @headerdata-business_place
                       ORDER BY PRIMARY KEY .
                      ENDSELECT.
                      " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
* End of Quick Fix

                      IF lv_adrnr IS NOT INITIAL.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                          SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.

                        SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr
                         ORDER BY PRIMARY KEY .
                        ENDSELECT.

* End of Quick Fix

                      ENDIF.
                      IF lv_region <> lv_bupla_region.
                        "IGST Code ZFI_GSTIN_P1_IGST
                        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v6) WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = @p_txcod.
                        IF sy-subrc <> 0.
                          "Error Only IGST Allowed
                          MESSAGE e003(zrcm_gst_en)." WITH p_txcod.
*                    ELSE. "Comment by Rahul Vasita on 25.05.2024 15:33:14
                        ENDIF."ls_p1v6
                      ELSE.
                        "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                        SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_p1v7) WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = @p_txcod.
                        IF sy-subrc <> 0.
                          "Error Only C/S GST Allowed
                          MESSAGE e002(zrcm_gst_en)." WITH p_txcod.
                        ENDIF."ls_p1v7
                      ENDIF."IF lv_region <> lv_bupla_region.
                      "Validation Code 6 Ends
                    ENDIF."ls_p1v3
                    "If Doc. Type is RM Ends
                  ENDIF."sy-subrc <> 0.
                  CLEAR : ls_p1v2.
                ELSE.
                  MESSAGE e004(zrcm_gst_en).
                ENDIF."IF headerdata-doc_type = 'RM'.
                "Comment End by Rahul Vasita on 17.06.2024 11:34:57
              ENDIF."ls_excep
            ELSE.""IF ls_j_1imovend-ven_class = '0'.
              CLEAR: ls_splifnr.
              SELECT SINGLE * FROM zfi_gstin_inc INTO ls_splifnr WHERE lifnr = lv_lifnr1.
              IF sy-subrc = 0.
                "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
                IF headerdata-doc_type = 'RM'.
                  SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = p_txcod.
                  IF sy-subrc <> 0.
                    "Error Message for Validation No 2
                    MESSAGE e000(zrcm_gst_en)." WITH wa_accit-mwskz.
                  ELSE.
                    "If Doc. Type is RM Starts
                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = p_txcod.
                    IF sy-subrc <> 0.
                      "Error Message for Validation No 3
                      MESSAGE e001(zrcm_gst_en)." WITH wa_accit-mwskz.
                    ELSE.
                      "Validation Code 6 Starts
                      CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                      SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                        SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = headerdata-business_place.

                      " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*SELECT ADRNR FROM J_1BBRANCH INTO LV_ADRNR UP TO 1 ROWS WHERE BRANCH = HEADERDATA-BUSINESS_PLACE
* ORDER BY PRIMARY KEY .
* ENDSELECT.
                      SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @headerdata-business_place
                       ORDER BY PRIMARY KEY .
                      ENDSELECT.
                      " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
* End of Quick Fix

                      IF lv_adrnr IS NOT INITIAL.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                          SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.

                        SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr
                         ORDER BY PRIMARY KEY .
                        ENDSELECT.

* End of Quick Fix

                      ENDIF.
                      IF lv_region <> lv_bupla_region.
                        "IGST Code ZFI_GSTIN_P1_IGST
                        SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = p_txcod.
                        IF sy-subrc <> 0.
                          "Error Only IGST Allowed
                          MESSAGE e003(zrcm_gst_en).
                        ENDIF."ls_p1v6
                      ELSE.
                        "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                        SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = p_txcod.
                        IF sy-subrc <> 0.
                          "Error Only C/S GST Allowed
                          MESSAGE e002(zrcm_gst_en).
                        ENDIF."ls_p1v7
                      ENDIF."IF lv_region <> lv_bupla_region.
                      "Validation Code 6 Ends
                    ENDIF."ls_p1v3
                    "If Doc. Type is RM Ends
                  ENDIF."sy-subrc <> 0.
                  CLEAR : ls_p1v2.
                ELSE.
                  MESSAGE e004(zrcm_gst_en).
                ENDIF."IF wa_accit-blart = 'RM'.
                "Includes Vendor Maintained in Table ZFI_GSTIN_INC So All Validations will be checked with same as Vendor Classification 0(ZERO).
              ELSE.
                IF headerdata-doc_type = 'RM'.
                  MESSAGE e005(zrcm_gst_en).
                ELSE.
                  SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = p_txcod.
                  IF sy-subrc = 0.
                    MESSAGE e006(zrcm_gst_en).
                  ELSE.
*                      GST PHASE 2 STARTS
                    "Validation Code 6 Starts
                    CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                    SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                      SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = headerdata-business_place.

                    " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*SELECT ADRNR FROM J_1BBRANCH INTO LV_ADRNR UP TO 1 ROWS WHERE BRANCH = HEADERDATA-BUSINESS_PLACE
* ORDER BY PRIMARY KEY .
* ENDSELECT.
                    SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @headerdata-business_place
                     ORDER BY PRIMARY KEY .
                    ENDSELECT.
                    " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
* End of Quick Fix

                    IF lv_adrnr IS NOT INITIAL.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                        SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.

                      SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr
                       ORDER BY PRIMARY KEY .
                      ENDSELECT.

* End of Quick Fix

                    ENDIF.
                    CLEAR: ls_p1v6 , ls_p1v7.
                    IF lv_region <> lv_bupla_region.
                      "IGST Code ZFI_GSTIN_P1_IGST
                      SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P2_IGST' AND type = 'S' AND low = p_txcod.
                      IF sy-subrc <> 0.
                        "Error Only IGST Allowed
                        MESSAGE e003(zrcm_gst_en)." WITH wa_accit-mwskz.
                      ENDIF."ls_p1v6
                    ELSE.
                      "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                      SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P2_C/S GST' AND type = 'S' AND low = p_txcod.
                      IF sy-subrc <> 0.
                        "Error Only C/S GST Allowed
                        MESSAGE e002(zrcm_gst_en)." WITH wa_accit-mwskz.
                      ENDIF."ls_p1v7
                    ENDIF."IF lv_region <> lv_bupla_region.
                    "Validation Code 6 Ends
*                      GST PHASE 2 ENDS
                  ENDIF."End of V2 TAX CODE
                ENDIF."wa_accit-blart = 'RM'.
              ENDIF."ENd of Include Vendor
            ENDIF."IF ls_j_1imovend-ven_class = '0'.
            CLEAR : ls_j_1imovend.
*            ENDLOOP. "Comment by Rahul Vasita on 17.06.2024 10:57:53
          ELSE.
*            LOOP AT it_accit INTO wa_accit WHERE koart <> 'K' AND xauto = ' '. "Comment by Rahul Vasita on 17.06.2024 10:57:42
            IF headerdata-doc_type = 'RM'.
              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V2' AND type = 'S' AND low = p_txcod.
              IF sy-subrc <> 0.
                "Error Message for Validation No 2
                MESSAGE e000(zrcm_gst_en)." WITH p_txcod.
              ELSE.
                SELECT SINGLE name  low FROM tvarvc INTO ls_p1v3 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = p_txcod.
                IF sy-subrc <> 0.
                  "Error Message for Validation No 3
                  MESSAGE e001(zrcm_gst_en)." WITH p_txcod.
                ELSE.
                  "Validation Code 6 Starts
                  CLEAR : lv_region , lv_adrnr , lv_bupla_region.
                  SELECT SINGLE regio FROM lfa1 INTO lv_region WHERE lifnr = lv_lifnr1.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                    SELECT SINGLE adrnr FROM j_1bbranch INTO lv_adrnr WHERE branch = headerdata-business_place.

                  " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
*SELECT ADRNR FROM J_1BBRANCH INTO LV_ADRNR UP TO 1 ROWS WHERE BRANCH = HEADERDATA-BUSINESS_PLACE
* ORDER BY PRIMARY KEY .
* ENDSELECT.
                  SELECT adrnr FROM p_businessplace INTO @lv_adrnr UP TO 1 ROWS WHERE branch = @headerdata-business_place
                   ORDER BY PRIMARY KEY .
                  ENDSELECT.
                  " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
* End of Quick Fix

                  IF lv_adrnr IS NOT INITIAL.

* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*                      SELECT SINGLE region FROM adrc INTO lv_bupla_region WHERE addrnumber = lv_adrnr.

                    SELECT region FROM adrc INTO lv_bupla_region UP TO 1 ROWS WHERE addrnumber = lv_adrnr
                     ORDER BY PRIMARY KEY .
                    ENDSELECT.

* End of Quick Fix

                  ENDIF.
                  IF lv_region <> lv_bupla_region.
                    "IGST Code ZFI_GSTIN_P1_IGST
                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v6 WHERE name = 'ZFI_GSTIN_P1_IGST' AND type = 'S' AND low = p_txcod.
                    IF sy-subrc <> 0.
                      "Error Only IGST Allowed
                      MESSAGE e003(zrcm_gst_en)." WITH p_txcod.
                    ENDIF."ls_p1v6
                  ELSE.
                    "CGST Code & SGST Code ZFI_GSTIN_P1_C/S GST
                    SELECT SINGLE name  low FROM tvarvc INTO ls_p1v7 WHERE name = 'ZFI_GSTIN_P1_C/S GST' AND type = 'S' AND low = p_txcod.
                    IF sy-subrc <> 0.
                      "Error Only C/S GST Allowed
                      MESSAGE e002(zrcm_gst_en)." WITH p_txcod.
                    ENDIF."ls_p1v7
                  ENDIF."IF lv_region <> lv_bupla_region.
                  "Validation Code 6 Ends
                ENDIF."ls_p1v3
                "If Doc. Type is RM Ends
              ENDIF."sy-subrc <> 0.
              CLEAR : ls_p1v2.
            ELSE.
              SELECT SINGLE name  low FROM tvarvc INTO ls_p1v2 WHERE name = 'ZFI_GSTIN_P1_V3' AND type = 'S' AND low = p_txcod.
              IF sy-subrc = 0.
                MESSAGE e006(zrcm_gst_en).
              ENDIF."ls_p1v2
            ENDIF."IF headerdata-doc_type = 'RM'.
*            ENDLOOP. "Comment by Rahul Vasita on 17.06.2024 10:57:32
          ENDIF."LS_SPLIFNR
        ENDIF."IF ls_endetail IS NOT INITIAL.
        CLEAR : ls_endetail.
      ENDIF."END OF IMPORT ACC. GRP.
    ENDIF."IF lv_ktokk <> 'ZCEM'.
  ENDIF."IF ls_gstswitch-low = abap_true.
*  ct_accit = it_accit. "Comment by Rahul Vasita on 17.06.2024 10:57:19
  CLEAR ls_gstswitch.
ENDFORM.
