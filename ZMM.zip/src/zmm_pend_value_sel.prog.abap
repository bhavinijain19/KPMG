

*&---------------------------------------------------------------------*
*&  Include           ZMM_RGP_REPORT_SEL
*&---------------------------------------------------------------------*

SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-001. "

TABLES : ekko,ekpo,esll,asmd.
SELECT-OPTIONS : s_ebeln FOR ekko-ebeln,
                 s_bedat FOR ekko-bedat OBLIGATORY,
                 s_werks FOR ekpo-werks OBLIGATORY,
                 s_srvpos FOR esll-srvpos,
                 s_lifnr for ekko-lifnr,
                 s_maktl for asmd-matkl,
               s_knttp for   EKPO-KNTTP.
SELECTION-SCREEN : END OF BLOCK a1.

SELECTION-SCREEN : BEGIN OF BLOCK b1 WITH FRAME TITLE text-002.
PARAMETERS: rad1 RADIOBUTTON GROUP r1 USER-COMMAND abc,
            rad2 RADIOBUTTON GROUP r1.
SELECTION-SCREEN : END OF BLOCK b1.

SELECTION-SCREEN : BEGIN OF BLOCK c1 WITH FRAME TITLE text-003.
PARAMETERS : p_menge type ZMENGE_F4.
SELECTION-SCREEN : END OF BLOCK c1.


PARAMETERS: variant LIKE disvariant-variant.

INITIALIZATION."
  gx_variant-report = sy-repid.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR variant.
*********************
*  **-- Display all existing variants
  g_variant-report = sy-repid.
* Utilizing the name of the report, this function module will search for a list of
* variants and will fetch the selected one into the parameter field for variants
  CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
    EXPORTING
      is_variant = g_variant
      i_save     = g_save
    IMPORTING
      e_exit     = g_exit
      es_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.



  IF sy-subrc = 2.
    MESSAGE ID sy-msgid TYPE 'S'      NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
    IF g_exit = space.
      variant = gx_variant-variant.
    ENDIF.
  ENDIF.
