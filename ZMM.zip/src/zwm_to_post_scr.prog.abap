*&---------------------------------------------------------------------*
*&  Include           ZWM_TO_POST_SCR
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS : p_lgnum TYPE lgnum OBLIGATORY,
             p_tbnum TYPE tbnum OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_lgnum.
  PERFORM p_lgnum.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_tbnum.
  PERFORM p_tbnum.

  at SELECTION-SCREEN OUTPUT.

    if execute eq 1.
      execute = 0.
    clear : p_lgnum,p_tbnum.
    endif.
