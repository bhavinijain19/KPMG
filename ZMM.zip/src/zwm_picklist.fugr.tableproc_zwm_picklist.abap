*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZWM_PICKLIST
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZWM_PICKLIST        .

  PERFORM TABLEPROC.

ENDFUNCTION.
