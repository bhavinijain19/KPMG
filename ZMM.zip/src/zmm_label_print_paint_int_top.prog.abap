*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_TOP
*&---------------------------------------------------------------------*
*******Types Declaration.

TYPES : BEGIN OF ty_zmm_su_number,
          mandt	     TYPE mandt,
          zsu_no     TYPE zsu_no,
          aufnr	     TYPE aufnr,
          matnr	     TYPE matnr,
          werks	     TYPE werks_d,
          lgort	     TYPE lgort_d,
          charg	     TYPE charg_d,
          zbatch_stk TYPE menge_d, "int4,  "changes made on 12.04.2019
          meins	     TYPE meins,
          lhmg1	     TYPE lvs_lhmng1,
          lety1	     TYPE lvs_letyp1,
          lhme1	     TYPE lhmeh1,
          lgpla      TYPE lgpla,
        END OF ty_zmm_su_number,







        BEGIN OF ty_mch1,
          matnr TYPE  matnr,
          charg TYPE charg_d,
          hsdat TYPE hsdat,
        END OF ty_mch1,

        BEGIN OF ty_makt,
          matnr TYPE matnr,
          maktx TYPE maktx,
        END OF ty_makt,

        BEGIN OF ty_mara,                       "Added by Raj Kumar 4806  on 06.02.2023
          matnr TYPE mara-matnr,
          groes TYPE mara-groes,
        END OF ty_mara,

        BEGIN OF ty_a999,                       "Added by Raj Kumar 4806 on 07.02.2023
          kschl TYPE a999-kschl,
          vkorg TYPE a999-vkorg,
          matnr TYPE a999-matnr,
          datbi TYPE a999-datbi,
          datab TYPE a999-datab,
          knumh TYPE a999-knumh,

        END OF ty_a999,

        BEGIN OF ty_a906,                       "Added by Raj Kumar 4806 on 07.02.2023
          kschl TYPE a906-kschl,
          vkorg TYPE a906-vkorg,
          pltyp TYPE a906-pltyp,
          matnr TYPE a906-matnr,
          datbi TYPE a906-datbi,
          datab TYPE a906-datab,
          knumh TYPE a906-knumh,
        END OF ty_a906,

        BEGIN OF ty_konp,                      "Added by Raj Kumar 4806 on 07.02.2023
          knumh TYPE konp-knumh,
          kbetr TYPE konp-kbetr,
          kmein TYPE konp-kmein,
        END OF ty_konp,
        "Added by Raj Kumar 4806 on 07.02.2023
        BEGIN OF ty_konp1,
          knumh1 TYPE konp-knumh,
          kbetr1 TYPE konp-kbetr,
          kmein1 TYPE konp-kmein,
        END OF ty_konp1,
        "Added by Raj Kumar 4806 on 08.02.2023
        BEGIN OF ty_t001k,
          bwkey TYPE t001k-bwkey,
          bukrs TYPE t001-bukrs,
        END OF ty_t001k,

        BEGIN OF ty_t001,
          bukrs TYPE t001-bukrs,
          adrnr TYPE t001-adrnr,
        END  OF ty_t001,

        BEGIN OF ty_adr6,
          addrnumber TYPE adr6-addrnumber,
          smtp_addr  TYPE adr6-smtp_addr,
        END OF ty_adr6,

        BEGIN OF ty_marm,
          matnr    TYPE marm-matnr,
          meinh    TYPE marm-meinh,
          umrez    TYPE marm-umrez,
          umren    TYPE marm-umren,
          umren1   TYPE marm-umren,
          v_conve2 TYPE marm-umren,
        END OF ty_marm,

        BEGIN OF ty_total,
          total TYPE marm-umren,
        END OF ty_total,

        BEGIN OF ty_vconve,
          v_conve TYPE marm-umren,
        END OF ty_vconve,
        BEGIN OF ty_mvke,
          matnr TYPE mvke-matnr,
          mvgr5 TYPE mvke-mvgr5,
        END OF ty_mvke,

        BEGIN OF ty_mlgn,
          matnr TYPE mlgn-matnr,
          lhmg1 TYPE mlgn-lhmg1,
        END OF ty_mlgn,

        BEGIN OF ty_final,
          zsu_no     TYPE zsu_no,
          matnr      TYPE  matnr,
          charg      TYPE charg_d,
          zbatch_stk TYPE zlvs_lhmng12,
          uom        TYPE lhmeh1,
          hsdat      TYPE hsdat,
          maktx      TYPE maktx,
          lgpla      TYPE lgpla,
          groes      TYPE mara-groes,
          kbetr      TYPE konp-kbetr,
          kbetr1     TYPE konp-kbetr,
          kmein      TYPE konp-kmein,
          kmein1     TYPE konp-kmein,
          total      TYPE marm-umren,
          meinh      TYPE marm-meinh,
*          umren1     TYPE marm-umren, " comment 10.04.2023
          umren1     TYPE kbetr, " add 10.04.2023
          mvgr5      TYPE mvke-mvgr5,
*          v_conve2   TYPE marm-umren,
          v_conve2   TYPE kbetr,
          kbetr_mrp  TYPE konp-kbetr,
        END OF ty_final ,

        BEGIN OF ty_zsu_no,
          zsu_no TYPE zsu_no,
        END OF ty_zsu_no,

        BEGIN OF ty_lqua,
          mandt TYPE mandt,
          lenum TYPE lenum,
          matnr TYPE matnr,
          werks TYPE werks_d,
          charg TYPE charg_d,
          lgpla TYPE lgpla,
          meins TYPE meins,
          verme TYPE lqua_verme,
          lgort TYPE lgort_d,
        END OF ty_lqua.
DATA : it_lqua  TYPE STANDARD TABLE OF ty_lqua,
       wa_lqua  TYPE ty_lqua,
       it_lqua1 TYPE STANDARD TABLE OF ty_lqua.

DATA: i_mrp TYPE j_1itaxvar-j_1itaxam1.
DATA: o_mrp TYPE j_1itaxvar-j_1itaxam1.


*        ***************Data Declaration*******************

*********** Added by Carina Jose on 05/01/2022
*
DATA : kbetr_mrp TYPE konp-kbetr.
DATA: s_rv TYPE meinh.
DATA : s_rv1 TYPE vkorg.
RANGES : gc_rv FOR s_rv.
RANGES :gc_rv1 FOR s_rv1.
CONSTANTS: c_uom TYPE rvari_vnam VALUE 'Z_LABEL_UNIT'.
DATA : v_uom(03).
DATA : v_region TYPE t005u-bezei.
DATA : v_country TYPE t005t-landx50.
TYPES : BEGIN OF t_header,
          plant_name1(40),
          plant_street(60),
          plant_house_num1(10),
          plant_house_num2(10),
          plant_str_suppl1(40),
          plant_str_suppl2(40),
          plant_str_suppl3(40),
          plant_city1(40),
          plant_city2(40),
          plant_post_code1(10),
          plant_region(10),
          plant_country(10),
*          plant_tel_number(10),
          plant_tel_number(30),
          plant_fax_number(10),
        END OF t_header.
DATA : wa_header TYPE t_header.
DATA : it_header TYPE STANDARD TABLE OF t_header.
*DATA v_conve1  TYPE marm-umren."
DATA v_conve1  TYPE kbetr." Added 10.04.2023

CONSTANTS : c_var_name TYPE rvari_vnam VALUE 'Z_LABEL_UNIT'.
CONSTANTS : c_var_name1 TYPE rvari_vnam VALUE 'Z_LABEL_SORG'.


TYPES : BEGIN OF ty_addr,
          street_address1(200),
          street_address2(200),
          street_address3(200),
          street_address4(200),
          city_address1(200),
          state_address1(200),
        END OF ty_addr.



TYPES: BEGIN OF ty_tvarvc,
         sign   TYPE tvarv_sign,
         option TYPE tvarv_opti,
         low    TYPE rvari_val_255,
         high   TYPE rvari_val_255,
       END OF ty_tvarvc.


DATA : it_address TYPE STANDARD TABLE OF ty_addr,
       wa_address TYPE ty_addr.

DATA : v_plant_name(40).
********** End of changes by Carina Jose on 05/01/2022

DATA : it_zmm_su_number   TYPE STANDARD TABLE OF ty_zmm_su_number,
       it_zsu_no          TYPE STANDARD TABLE OF ty_zsu_no,
       wa_zsu_no          TYPE ty_zsu_no,
       wa_zmm_su_number   TYPE ty_zmm_su_number,
       it_makt            TYPE STANDARD TABLE OF ty_makt,
       wa_makt            TYPE ty_makt,
       it_mara            TYPE STANDARD TABLE OF ty_mara,
       wa_mara            TYPE ty_mara,
       it_a999            TYPE STANDARD TABLE OF ty_a999,
       wa_a999            TYPE ty_a999,
       it_a906            TYPE STANDARD TABLE OF ty_a906,
       wa_a906            TYPE ty_a906,
       it_konp            TYPE STANDARD TABLE OF ty_konp,
       wa_konp            TYPE ty_konp,

       it_mch1            TYPE STANDARD TABLE OF ty_mch1,
       wa_mch1            TYPE ty_mch1,

       it_mlgn            TYPE  STANDARD TABLE OF ty_mlgn,
       wa_mlgn            TYPE ty_mlgn,


       it_konp1           TYPE STANDARD TABLE OF ty_konp1,
       wa_konp1           TYPE ty_konp1,

       it_t001k           TYPE STANDARD TABLE OF ty_t001k,
       wa_t001k           TYPE ty_t001k,

       it_t001            TYPE STANDARD TABLE OF ty_t001,
       wa_t001            TYPE ty_t001,

       it_adr6            TYPE STANDARD TABLE OF ty_adr6,
       wa_adr6            TYPE ty_adr6,

       it_marm            TYPE STANDARD TABLE OF ty_marm,
       wa_marm            TYPE ty_marm,

       it_mvke            TYPE STANDARD TABLE OF ty_mvke,
       wa_mvke            TYPE ty_mvke,

       it_tvarvc          TYPE STANDARD TABLE OF ty_tvarvc,
       wa_tvarvc          TYPE ty_tvarvc,

       it_tvarvc1         TYPE STANDARD TABLE OF ty_tvarvc,
       wa_tvarvc1         TYPE ty_tvarvc,



       it_final           TYPE STANDARD TABLE OF ty_final,
       wa_final           TYPE ty_final,
       v_form_name        TYPE rs38l_fnam,
       control_parameters TYPE ssfctrlop,
       w_cnt              TYPE i,
       w_cnt2             TYPE i,
       gv_ymcha           TYPE mcha,
       gv_classname       TYPE klah-class,
       it_clbatch         TYPE STANDARD TABLE OF clbatch,
       wa_clbatch         TYPE clbatch.
