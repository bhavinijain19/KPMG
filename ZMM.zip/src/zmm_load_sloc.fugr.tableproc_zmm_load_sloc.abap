*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_LOAD_SLOC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_LOAD_SLOC       .

  PERFORM TABLEPROC.

ENDFUNCTION.
