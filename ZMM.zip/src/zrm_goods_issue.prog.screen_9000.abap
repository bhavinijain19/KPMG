PROCESS BEFORE OUTPUT.
  MODULE status_9000.
  LOOP ."at gt_ltbp INTO wa_ltbp CURSOR c FROM n1 to n2 .
    MODULE  transp_itab_out_9000.
  ENDLOOP.
*
PROCESS AFTER INPUT.
*GET CURSOR FIELD name .
  MODULE cursor_data.
  MODULE user_command_9000.
  LOOP .
    MODULE transp_itab_in_9000.
  ENDLOOP.
