

.


SELECT SINGLE LTX FROM T247

   INTO @data(MONTH_NAME)

   WHERE SPRAS = @SY-LANGU

   AND MNR = @wa_final-hsdat+4(2).

CONCATENATE MONTH_NAME  wa_final-hsdat+0(4)

    INTO V_DATE1 SEPARATED BY SPACE.




















