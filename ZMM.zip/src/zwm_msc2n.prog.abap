report ZWM_MSC2N.
TYPES: BEGIN OF ty_MSC2N,
       MATNR(18),
       CHARG(10),
       WERKS(04),
       LGORT(04),
       END OF TY_MSC2N.

DATA :it_type TYPE truxs_t_text_data.
DATA : file_name TYPE string.
DATA : it_data TYPE STANDARD TABLE OF ty_MSC2N WITH HEADER LINE,
       wa_data TYPE ty_MSC2N.

DATA:wa_bdc TYPE bdcdata,
     it_bdc TYPE TABLE OF bdcdata.

DATA:wa_msg TYPE bdcmsgcoll,
     it_msg TYPE TABLE OF bdcmsgcoll.

TYPES : BEGIN OF ty_error,
          sno          TYPE i,
*          efield(200),
          message(100) TYPE c,
        END OF ty_error.
DATA: wa_error TYPE ty_error,
      it_error TYPE STANDARD TABLE OF ty_error.
TYPES : BEGIN OF ty_header,
          text(20),
        END OF ty_header.
TYPES :  BEGIN OF t_message   ,
           lifnr   TYPE char10  , " Customer Number
           status  TYPE char4   , " Light Indicator
           type    TYPE char4   , " Error Type
           message TYPE char255 , " Message Description
         END OF t_message    .

DATA :  it_header TYPE STANDARD TABLE OF ty_header,
        wa_header TYPE ty_header.
DATA: i_field     TYPE slis_t_fieldcat_alv,
      it_fieldcat TYPE slis_t_fieldcat_alv WITH HEADER LINE,
      i_message   TYPE STANDARD TABLE OF t_message.

DATA:count  TYPE i.

FIELD-SYMBOLS :
  <x_message> TYPE t_message,
  <x_field>   TYPE slis_fieldcat_alv,
  <x_bdcdata> TYPE bdcdata,
  <x_msg>     TYPE bdcmsgcoll.

CONSTANTS:
  c_x    TYPE char1 VALUE 'X',
  c_e    TYPE char1 VALUE 'E',
  c_i    TYPE char1 VALUE 'I',
  c_s    TYPE char1 VALUE 'S',
  c_l    TYPE char1 VALUE 'L',
  c_a    TYPE char1 VALUE 'A',
  c_n    TYPE char1 VALUE 'N',
  c_xls  TYPE char4 VALUE '.XLS',
*  c_xd01 TYPE char4 VALUE 'XD01',
  c_en   TYPE char2 VALUE 'EN'.

DATA: gv_sno(02),
      gv_fname(60).
DATA: cursor TYPE i.

*&---------------------------------------------- SELECTION SCREEN -------------------------------------------------------------&*
SELECTION-SCREEN: BEGIN OF BLOCK a1 WITH FRAME TITLE text-000.
PARAMETERS:p_file  TYPE rlgrap-filename OBLIGATORY,
*           p_file1 TYPE rlgrap-filename OBLIGATORY, " Download FileName
           p_mode  LIKE ctu_params-dismode DEFAULT 'A'.         " Mode .
SELECTION-SCREEN:END OF BLOCK a1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  CALL FUNCTION 'WS_FILENAME_GET'
    EXPORTING
      def_filename     = space
      def_path         = space
      mask             = ',*.*,*.*.'
      mode             = space
      title            = space
    IMPORTING
      filename         = p_file
*     RC               =
    EXCEPTIONS
      inv_winsys       = 1
      no_batch         = 2
      selection_cancel = 3
      selection_error  = 4
      OTHERS           = 5.
  IF sy-subrc <> 0 AND sy-subrc <> 3.
    MESSAGE e102(yb) WITH 'Error Selecting File'(007).
  ENDIF.
*
*AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file1.
*  PERFORM f4_help1.

START-OF-SELECTION.
  PERFORM upload.
  PERFORM authorization_check.
  PERFORM bdc.
*  PERFORM field_catalog.
*  PERFORM append_header.
*  PERFORM alv_display.          " Display Return Message In ALV




*&---------------------------------------------------------------------*
*&      Form  UPLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload .

   file_name  = p_file.
  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
*     I_FIELD_SEPERATOR    =
      i_line_header        = 'X'
      i_tab_raw_data       = it_type
      i_filename           = p_file
    TABLES
      i_tab_converted_data = it_data
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BDC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM bdc .

 LOOP AT IT_DATA INTO WA_DATA.



perform bdc_dynpro      using 'SAPLCHRG' '1000'.
perform bdc_field       using 'BDC_OKCODE'
                              '=CLAS'.
perform bdc_field       using 'BDC_CURSOR'
                              'DFBATCH-MATNR'.
perform bdc_field       using 'DFBATCH-MATNR'
                               WA_DATA-MATNR." 'M003602005'.
perform bdc_field       using 'DFBATCH-CHARG'
                              WA_DATA-CHARG."'S2106800'.
perform bdc_field       using 'DFBATCH-WERKS'
                              WA_DATA-WERKS."'4000'.
perform bdc_field       using 'DFBATCH-LGORT'
                              WA_DATA-LGORT."'FG01'.
perform bdc_dynpro      using 'SAPLCHRG' '1000'.
perform bdc_field       using 'BDC_OKCODE'
                              '=CLCR'.
perform bdc_field       using 'BDC_CURSOR'
                              'DFBATCH-MATNR'.
perform bdc_dynpro      using 'SAPLCHRG' '1000'.
perform bdc_field       using 'BDC_OKCODE'
                              '=SAVE'.
perform bdc_field       using 'BDC_CURSOR'
                              'RCTMS-MWERT(04)'.
*perform bdc_transaction using 'MSC2N'.

CALL TRANSACTION 'MSC2N' USING it_bdc MODE p_mode UPDATE 'S' MESSAGES INTO it_msg.
*  PERFORM bdc_transaction USING 'KO01'.

*   IF  it_msg IS NOT INITIAL.
*      PERFORM populate_error.
*    ENDIF.

  REFRESH it_bdc.
  CLEAR : wa_data.
ENDLOOP.

*perform close_group.

ENDFORM.
FORM bdc_dynpro USING program screen.

  wa_bdc-program = program.
  wa_bdc-dynpro = screen.
  wa_bdc-dynbegin = 'X'.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
FORM bdc_field USING field value.

  wa_bdc-fnam = field.
  wa_bdc-fval = value.
  APPEND wa_bdc TO it_bdc.
  CLEAR:wa_bdc.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .

   LOOP AT it_data INTO wa_data.
    AUTHORITY-CHECK OBJECT 'ZMSC2N_WRK'
        ID 'WERKS' FIELD wa_data-werks
        ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_data-werks.
    ENDIF.
    CLEAR : wa_data.
   ENDLOOP.
ENDFORM.
