*&---------------------------------------------------------------------*
*&  Include           ZMM_RGP_REPORT_MAIN
*&---------------------------------------------------------------------*
"




START-OF-SELECTION.

  PERFORM auth_check.
  PERFORM get_data.
  PERFORM build_fcat.
  PERFORM display_alv.

FORM get_data.

*  DATA : v_graph TYPE icon_int.
*  DATA : v_id TYPE icon-id.
*
*  SELECT SINGLE id internal FROM icon INTO  ( v_id ,v_graph ) WHERE internal = 'ICON_GRAPHICS'.

  IF it_ekko IS NOT INITIAL.
    SELECT ebeln ebelp werks packno netwr fplnr loekz matnr txz01 menge netpr knttp FROM ekpo INTO CORRESPONDING FIELDS OF  TABLE it_ekpo_st FOR ALL ENTRIES IN it_ekko
       WHERE ebeln = it_ekko-ebeln  AND werks IN s_werks AND knttp IN s_knttp." AND pstyp = '9'.
  ENDIF.

  IF it_ekpo1 IS NOT INITIAL.


    SELECT fplnr fpltr fakwr afdat FROM fplt INTO CORRESPONDING FIELDS OF TABLE it_fplt_inv
      FOR ALL ENTRIES IN it_ekpo1 WHERE fplnr = it_ekpo1-fplnr.
*      if it_fplt_inv is not INITIAL.
*        sort it_fplt_inv by afdat.
*        endif.

*    LOOP AT it_ekpo1 INTO wa_ekpo1.
*      LOOP AT it_fplt_inv INTO wa_fplt_inv WHERE fplnr = wa_ekpo1-fplnr.
*        MOVE-CORRESPONDING wa_fplt_inv TO wa_fplt_inv1.
*        APPEND wa_fplt_inv1 TO it_fplt_inv1.
*      ENDLOOP.
*      CLEAR wa_ekpo1.
*      SORT it_fplt_inv1 BY afdat.
*    ENDLOOP.

    REFRESH it_ekbe_inv.

    SELECT ebeln ebelp zekkn belnr wrbtr refwr  cpudt cputm FROM ekbe
       INTO CORRESPONDING FIELDS OF  TABLE it_ekbe_inv
       FOR ALL ENTRIES IN it_ekpo1 WHERE ebeln = it_ekpo1-ebeln AND ebelp = it_ekpo1-ebelp .


*    SORT it_fplt_inv BY afdat.


******************************Sequence************
    LOOP AT it_ekpo1 INTO wa_ekpo1.
      LOOP AT it_fplt_inv  INTO wa_fplt_inv WHERE fplnr = wa_ekpo1-fplnr.
        IF wa_fplt_inv-fplnr = wa_ekpo1-fplnr.
          wa_fplt_temp-fplnr  = wa_fplt_inv-fplnr.
          wa_fplt_temp-fpltr  = wa_fplt_inv-fpltr.
          wa_fplt_temp-fakwr  = wa_fplt_inv-fakwr.
          wa_fplt_temp-afdat  = wa_fplt_inv-afdat.

          APPEND wa_fplt_temp TO it_fplt_temp.
        ELSE.
          IF wa_fplt_temp-fplnr NE wa_ekpo1-fplnr.
*            SORT it_fplt_temp BY afdat.
*            APPEND LINES OF it_fplt_temp TO it_fplt_inv.
*            REFRESH it_fplt_temp.

          ENDIF.
          CLEAR wa_fplt_inv-fplnr.
        ENDIF.
      ENDLOOP.

      SORT it_fplt_temp BY afdat.
      APPEND LINES OF it_fplt_temp TO it_fplt_new.
      REFRESH it_fplt_temp.

      CLEAR :wa_ekpo1.
    ENDLOOP.


*****************************Sequence***************


*    DATA : v_indi TYPE i.
*    v_indi = 0.
*    LOOP AT it_ekpo1 INTO wa_ekpo1.
*      LOOP AT it_fplt_inv  INTO wa_fplt_inv WHERE fplnr = wa_ekpo1-fplnr.
*        wa_fplt_inv-fpltr = wa_ekpo1-ebelp.
*        wa_fplt_inv-ebeln = wa_ekpo1-ebeln.
*        MODIFY it_fplt_inv  FROM wa_fplt_inv TRANSPORTING fpltr ebeln.
*      ENDLOOP.
*      CLEAR :wa_ekpo1.
*    ENDLOOP.
*  ENDIF.


    DATA : v_indi TYPE i.
    v_indi = 0.
    LOOP AT it_ekpo1 INTO wa_ekpo1.
      LOOP AT it_fplt_new INTO wa_fplt_new WHERE fplnr = wa_ekpo1-fplnr.
        wa_fplt_new-fpltr = wa_ekpo1-ebelp.
        wa_fplt_new-ebeln = wa_ekpo1-ebeln.
        MODIFY it_fplt_new  FROM wa_fplt_new TRANSPORTING fpltr ebeln.
      ENDLOOP.
      CLEAR :wa_ekpo1.
    ENDLOOP.
  ENDIF.






*  SORT it_fplt_inv BY fplnr.


*  IF it_ekpo1 IS NOT INITIAL.
*    LOOP AT it_ekpo1 INTO wa_ekpo1.
*      LOOP AT it_fplt_inv  INTO wa_fplt_inv WHERE fplnr = wa_ekpo1-fplnr AND fpltr = wa_ekpo1-ebelp.
*        v_indi = v_indi + 1.
*        wa_fplt_inv-index1 = v_indi.
*        MODIFY it_fplt_inv  FROM wa_fplt_inv TRANSPORTING index1.
*
*      ENDLOOP.
*      CLEAR :wa_ekpo1,v_indi.
*    ENDLOOP.
*  ENDIF.


  IF it_ekpo1 IS NOT INITIAL.
    LOOP AT it_ekpo1 INTO wa_ekpo1.
      LOOP AT it_fplt_new  INTO wa_fplt_new WHERE fplnr = wa_ekpo1-fplnr AND fpltr = wa_ekpo1-ebelp.
        v_indi = v_indi + 1.
        wa_fplt_new-index1 = v_indi.
        MODIFY it_fplt_new  FROM wa_fplt_new TRANSPORTING index1.

      ENDLOOP.
      CLEAR :wa_ekpo1,v_indi.
    ENDLOOP.
  ENDIF.








*  LOOP AT it_fplt_inv  INTO wa_fplt_inv ."WHERE fplnr = wa_ekpo1-fplnr AND fpltr = wa_ekpo1-ebelp.
*    v_indi = v_indi + 1.
*    wa_fplt_inv-index1 = v_indi.
*    MODIFY it_fplt_inv  FROM wa_fplt_inv TRANSPORTING index1.
*  ENDLOOP.




  IF rad2 = 'X'.
    IF it_ekpo1 IS NOT INITIAL.
      SELECT  belnr ebeln ebelp wrbtr FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg
        FOR ALL ENTRIES IN it_ekpo1 WHERE ebeln = it_ekpo1-ebeln AND ebelp = it_ekpo1-ebelp.

      IF it_rseg IS NOT INITIAL.
        SELECT belnr stblg budat FROM rbkp INTO CORRESPONDING FIELDS OF TABLE it_rbkp FOR ALL ENTRIES IN it_rseg
          WHERE belnr = it_rseg-belnr.
      ENDIF.
    ENDIF.
  ENDIF.


  IF it_ekpo1 IS NOT INITIAL.
    SELECT matnr maktx FROM makt INTO TABLE it_makt1 FOR ALL ENTRIES IN it_ekpo1 WHERE matnr = it_ekpo1-matnr.
  ENDIF.

  IF it_ekpo IS NOT INITIAL.


*    SELECT ebeln bedat lifnr FROM ekko INTO CORRESPONDING FIELDS OF TABLE it_ekko
*       FOR ALL ENTRIES IN it_ekpo WHERE ebeln = it_ekpo-ebeln AND bedat IN s_bedat.

    SELECT matnr maktx FROM makt INTO TABLE it_makt FOR ALL ENTRIES IN it_ekpo WHERE matnr = it_ekpo-matnr.



    SELECT fplnr fpltr fakwr FROM fplt INTO CORRESPONDING FIELDS OF TABLE it_fplt
      FOR ALL ENTRIES IN it_ekpo WHERE fplnr = it_ekpo-fplnr.

*    IF rad2 = 'X'.
*      SELECT  belnr ebeln ebelp wrbtr FROM rseg INTO CORRESPONDING FIELDS OF TABLE it_rseg
*        FOR ALL ENTRIES IN it_ekpo WHERE ebeln = it_ekpo-ebeln AND ebelp = it_ekpo-ebelp.
*    ENDIF.



    SELECT ebeln ebelp packno FROM essr INTO CORRESPONDING FIELDS OF TABLE it_essr
      FOR ALL ENTRIES IN it_ekpo WHERE ebeln = it_ekpo-ebeln AND ebelp = it_ekpo-ebelp.

  ENDIF.

  IF it_essr IS NOT INITIAL.

    SELECT packno sub_packno extrow FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllsr
       FOR ALL ENTRIES IN it_essr WHERE packno = it_essr-packno.
  ENDIF.
  IF it_esllsr IS NOT INITIAL.
    SELECT packno sub_packno introw extrow menge tbtwr pln_packno pln_introw FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllmg
      FOR ALL ENTRIES IN it_esllsr WHERE packno = it_esllsr-sub_packno.

    SELECT packno sub_packno introw extrow menge tbtwr pln_packno pln_introw act_menge FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllpln
FOR ALL ENTRIES IN it_esllmg WHERE packno = it_esllmg-pln_packno AND introw = it_esllmg-pln_introw.

  ENDIF.

  IF it_ekpo IS NOT INITIAL.

    SELECT packno sub_packno FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllpa
       FOR ALL ENTRIES IN it_ekpo WHERE packno = it_ekpo-packno.

  ENDIF.


  IF it_esllpa IS NOT INITIAL.
    SELECT packno sub_packno extrow menge FROM esll INTO CORRESPONDING FIELDS OF TABLE it_extrow
      FOR ALL ENTRIES IN it_esllpa WHERE packno = it_esllpa-sub_packno.
  ENDIF.

  IF it_esllpa IS NOT INITIAL.
    SELECT packno extrow sub_packno srvpos FROM esll INTO CORRESPONDING FIELDS OF TABLE it_srvpos
      FOR ALL ENTRIES IN it_esllpa WHERE packno = it_esllpa-sub_packno.

  ENDIF.

  IF it_srvpos IS NOT INITIAL.
    SELECT asnum matkl FROM asmd INTO TABLE it_asmd FOR ALL ENTRIES IN it_srvpos WHERE asnum = it_srvpos-srvpos AND matkl IN s_maktl.
    SELECT asnum asktx FROM asmdt INTO TABLE it_asmdt FOR ALL ENTRIES IN it_srvpos  WHERE asnum = it_srvpos-srvpos.
  ENDIF.


  IF it_ekko IS NOT INITIAL.

    SELECT lifnr name1 FROM lfa1 INTO CORRESPONDING FIELDS OF TABLE it_lfa1 FOR ALL ENTRIES IN it_ekko WHERE lifnr = it_ekko-lifnr.

    SELECT ebeln ebelp belnr bewtp FROM ekbe INTO CORRESPONDING FIELDS OF TABLE it_ekbe FOR ALL ENTRIES IN it_ekko WHERE ebeln = it_ekko-ebeln.

    SELECT ebeln ebelp belnr bewtp FROM ekbe INTO CORRESPONDING FIELDS OF TABLE it_ekbe_temp FOR ALL ENTRIES IN it_ekko WHERE ebeln = it_ekko-ebeln AND bewtp EQ 'E'.
  ENDIF.


  IF it_esllpa IS NOT INITIAL.

    SELECT  packno sub_packno netwr introw extrow srvpos tbtwr pln_introw FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllsu
      FOR ALL ENTRIES IN it_esllpa WHERE packno = it_esllpa-sub_packno AND srvpos IN s_srvpos.

  ENDIF.

  IF it_ekpo1 IS NOT INITIAL.
    SELECT packno sub_packno FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllrd
   FOR ALL ENTRIES IN it_ekpo1 WHERE packno = it_ekpo1-packno.
  ENDIF.

  IF it_esllrd IS NOT INITIAL.
    SELECT  packno sub_packno netwr introw extrow srvpos tbtwr FROM esll INTO CORRESPONDING FIELDS OF TABLE it_esllsurd
       FOR ALL ENTRIES IN it_esllrd WHERE packno = it_esllrd-sub_packno AND srvpos IN s_srvpos.
  ENDIF.



  IF it_esllrd IS NOT INITIAL.

    SELECT packno sub_packno srvpos FROM esll INTO CORRESPONDING FIELDS OF TABLE it_srvposrd
     FOR ALL ENTRIES IN it_esllrd WHERE packno = it_esllrd-sub_packno.

  ENDIF.

  IF it_srvposrd IS NOT INITIAL.
    SELECT asnum matkl FROM asmd INTO TABLE it_asmdrd FOR ALL ENTRIES IN it_srvposrd WHERE asnum = it_srvposrd-srvpos AND matkl IN s_maktl.
  ENDIF.


*******Deletion records or reverse POs*******
*  SORT it_ekbe_inv BY ebeln ebelp.

*  LOOP AT it_rbkp INTO wa_rbkp.
*    LOOP AT it_ekbe_inv INTO wa_ekbe_inv WHERE belnr = wa_rbkp-belnr AND cpudt = wa_rbkp-budat.
*      IF wa_rbkp-stblg IS INITIAL.
*        MOVE-CORRESPONDING wa_ekbe_inv TO wa_ekbe_inv1.
*        APPEND wa_ekbe_inv1 TO it_ekbe_inv1.
*      ENDIF.
*    ENDLOOP.
*    CLEAR  :wa_rbkp,wa_ekbe_inv.
*  ENDLOOP.

***********21.11.2023***********
  LOOP AT it_rbkp INTO wa_rbkp.
    IF wa_rbkp-stblg IS NOT  INITIAL.
      DELETE it_ekbe_inv WHERE belnr = wa_rbkp-stblg.
    ENDIF.
  ENDLOOP.

  it_ekbe_inv1[] = it_ekbe_inv.


  LOOP AT it_ekpo1 INTO wa_ekpo1.
    LOOP AT it_ekbe_inv1 INTO wa_ekbe_inv1 WHERE ebeln = wa_ekpo1-ebeln AND ebelp = wa_ekpo1-ebelp.
      v_indi = v_indi + 1.
      wa_ekbe_inv1-index1 = v_indi.
      MODIFY it_ekbe_inv1  FROM wa_ekbe_inv1 TRANSPORTING  index1.
    ENDLOOP.
    CLEAR : wa_ekbe_inv1,v_indi,wa_ekpo1.
  ENDLOOP.


  SORT it_ekpo BY ebeln ebelp.
  SORT it_essr BY ebeln ebelp.
  SORT it_esllmg BY extrow.

*summation of received Quantity *********
  DATA : lv_amt TYPE esll-menge.  "summation of received Quantity *********
  DATA : lv_key TYPE string.

*  LOOP AT it_essr INTO wa_essr.
*    READ TABLE it_esllsr INTO wa_esllsr WITH KEY packno = wa_essr-packno.
*    LOOP AT it_esllmg INTO wa_esllmg WHERE packno = wa_esllsr-sub_packno.
*      SHIFT wa_essr-ebelp LEFT DELETING LEADING '0'.
*      SHIFT wa_esllmg-extrow LEFT DELETING LEADING '0'.
*      CONCATENATE wa_essr-ebeln wa_essr-ebelp wa_esllmg-extrow INTO lv_key.
*      wa_esllmg-lv_key = lv_key.
*      MODIFY  it_esllmg FROM   wa_esllmg TRANSPORTING lv_key.
*      CLEAR :lv_key,wa_esllmg.
*    ENDLOOP.
*    CLEAR : wa_essr,wa_esllsr.
*  ENDLOOP.
*
*  SORT it_esllmg BY lv_key.
*  LOOP AT it_esllmg INTO wa_esllmg.
*    lv_amt = lv_amt + wa_esllmg-menge.
*    AT END OF lv_key.
*      wa_esllmg-lv_amt = lv_amt.
*      MODIFY  it_esllmg FROM   wa_esllmg TRANSPORTING lv_amt.
*      CLEAR lv_amt.
*    ENDAT.
*    clear wa_esllmg.
*  ENDLOOP.
*
*
*  SORT it_esllmg ASCENDING by lv_key packno .

****summation of received Quantity***********
  SELECT ebeln ebelp zekkn belnr wrbtr refwr  cpudt cputm  bewtp   bekkn menge packno introw FROM ekbe
         INTO CORRESPONDING FIELDS OF  TABLE it_ekbe_rec
         FOR ALL ENTRIES IN it_ekpo WHERE ebeln = it_ekpo-ebeln AND ebelp = it_ekpo-ebelp AND bewtp = 'E'.


  LOOP AT it_ekbe_rec INTO wa_ekbe_rec.
    SHIFT wa_ekbe_rec-ebelp LEFT DELETING LEADING '0'.
    SHIFT wa_ekbe_rec-bekkn LEFT DELETING LEADING '0'.

    CONCATENATE wa_ekbe_rec-ebeln wa_ekbe_rec-ebelp wa_ekbe_rec-packno wa_ekbe_rec-bekkn wa_ekbe_rec-introw  INTO lv_key.
    CONCATENATE wa_ekbe_rec-bekkn '0' INTO  wa_ekbe_rec-bekkn.
    wa_ekbe_rec-lv_key = lv_key.
    MODIFY  it_ekbe_rec FROM   wa_ekbe_rec TRANSPORTING lv_key bekkn.
    CLEAR: wa_ekbe_rec,lv_key.
  ENDLOOP.
*
  SORT it_ekbe_rec BY lv_key.
  LOOP AT it_ekbe_rec INTO wa_ekbe_rec.
    lv_amt = lv_amt + wa_ekbe_rec-menge.
    AT END OF lv_key.
      wa_ekbe_rec-lv_amt = lv_amt.
      MODIFY  it_ekbe_rec FROM  wa_ekbe_rec TRANSPORTING lv_amt.
      CLEAR :lv_amt,wa_ekbe_rec.
    ENDAT.
    CLEAR: wa_ekbe_rec,lv_key.
  ENDLOOP.

*  sort it_ekbe_Rec .


*  LOOP AT it_ekpo INTO wa_ekpo.
*    LOOP AT it_ekbe_Rec INTO wa_ekbe_rec where ebeln = wa_ekpo-ebeln and ebeln = wa_ekpo-ebeln.
*      wa_ekpo-lv_packno = wa_ekbe_rec-packno.
*      MODIFY it_ekpo FROM wa_ekpo TRANSPORTING lv_packno.
*    ENDLOOP.
*  ENDLOOP.


  DELETE it_esllsr WHERE sub_packno = '0'.
  DELETE it_essr WHERE packno = '0'.

  DELETE it_ekbe_rec WHERE lv_amt = '0'.
  SORT it_ekbe_rec .

  IF rad1 = 'X'.

    LOOP AT it_esllsu INTO wa_esllsu.




      READ TABLE it_esllpa INTO wa_esllpa WITH KEY sub_packno = wa_esllsu-packno.

      READ TABLE it_ekpo INTO wa_ekpo WITH KEY packno = wa_esllpa-packno.

      IF wa_ekpo IS NOT INITIAL.
        wa_final-ebeln = wa_ekpo-ebeln.
        wa_final-ebelp  = wa_ekpo-ebelp.
        wa_final-werks = wa_ekpo-werks.
        wa_final-loekz = wa_ekpo-loekz.
      ENDIF.

      READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekpo-ebeln.
      IF wa_ekko IS NOT INITIAL.
        wa_final-bedat = wa_ekko-bedat.
*        wa_final-lifnr = wa_ekko-lifnr.

        IF wa_ekko-lifnr IS NOT INITIAL.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
            EXPORTING
              input  = wa_ekko-lifnr
            IMPORTING
              output = wa_final-lifnr.
        ENDIF.


        wa_final-waers = wa_ekko-waers.
      ENDIF.
      READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
      IF wa_lfa1 IS NOT INITIAL.
        wa_final-name1 = wa_lfa1-name1.
      ENDIF.

      IF wa_ekpo IS NOT INITIAL.
        READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekpo-ebeln.
        wa_final-bewtp = wa_ekbe-bewtp.

        IF wa_ekbe-bewtp IS NOT INITIAL.

          wa_final-v_graph = alv_icon.
        ENDIF.


        READ TABLE it_essr INTO wa_essr WITH KEY ebeln = wa_ekpo-ebeln ebelp = wa_ekpo-ebelp.

        READ TABLE it_esllsr INTO wa_esllsr WITH KEY packno = wa_essr-packno.


        READ TABLE it_esllpa INTO wa_esllpa WITH KEY packno = wa_ekpo-packno.
      ENDIF.

      IF wa_esllpa IS NOT INITIAL.
        READ TABLE it_extrow INTO wa_extrow WITH KEY packno = wa_esllpa-sub_packno extrow = wa_esllsu-extrow.
        IF wa_extrow IS NOT INITIAL.
          wa_final-extrow = wa_extrow-extrow.
          wa_final-menge = wa_extrow-menge.
        ENDIF.
        READ TABLE it_srvpos INTO wa_srvpos WITH KEY packno = wa_esllpa-sub_packno extrow = wa_esllsu-extrow.
        IF wa_srvpos IS NOT INITIAL.
          wa_final-srvpos = wa_srvpos-srvpos.
        ENDIF.
      ENDIF.

*      READ TABLE it_esllmg INTO wa_esllmg WITH KEY  pln_introw = wa_esllsu-introw  PLN_packno = wa_esllsu-packno.
*      IF wa_esllmg IS NOT INITIAL.
*        wa_final-erfmg = wa_esllmg-menge.
*      ENDIF.
**    READ TABLE it_ekbe_temp INTO wa_ekbe_temp WITH KEY ebeln = wa_ekpo-ebeln.

      READ TABLE it_esllpln INTO wa_esllpln WITH KEY introw = wa_esllsu-introw  packno = wa_esllsu-packno extrow = wa_extrow-extrow.
      IF sy-subrc = 0.
        wa_final-erfmg = wa_esllpln-act_menge.
      ENDIF.


*      READ TABLE it_ekbe_rec INTO wa_ekbe_rec WITH KEY  packno = wa_esllsr-sub_packno." ebeln = wa_ekpo-ebeln  ebelp = wa_ekpo-ebelp packno = wa_esllsr-packno ."bekkn = wa_extrow-extrow.
*      IF wa_ekbe_rec IS NOT INITIAL.
*        wa_final-erfmg = wa_ekbe_rec-lv_amt.
*      ENDIF.



      IF wa_srvpos IS NOT INITIAL.
        READ TABLE it_asmdt INTO wa_asmdt WITH KEY asnum = wa_srvpos-srvpos.
        IF wa_asmdt IS NOT INITIAL.
          wa_final-asktx = wa_asmdt-asktx.
        ENDIF.
        READ TABLE it_asmd INTO wa_asmd WITH KEY asnum = wa_srvpos-srvpos.
        IF wa_asmd IS NOT INITIAL.
          wa_final-matkl = wa_asmd-matkl.
        ENDIF.
      ENDIF.

*      wa_final-still_qty  = wa_extrow-menge - wa_esllmg-menge.

      wa_final-still_qty  = wa_extrow-menge - wa_esllpln-act_menge.
*      READ TABLE it_esllsu INTO wa_esllsu WITH KEY packno = wa_esllpa-sub_packno.
*
*      IF wa_esllsu IS NOT INITIAL.
      wa_final-tbtwr = wa_esllsu-tbtwr.
*      ENDIF.

      wa_final-rec_qty = wa_esllsu-tbtwr * wa_esllpln-act_menge.
      wa_final-net_value =  wa_esllsu-tbtwr * wa_extrow-menge.


      READ TABLE it_fplt INTO wa_fplt WITH KEY fplnr = wa_ekpo-fplnr fpltr = wa_ekpo-ebelp.
      IF sy-subrc = 0.
        wa_final-fakwr = wa_fplt-fakwr.
        wa_final-fplnr = wa_fplt-fplnr.

      ENDIF.

      wa_final-pend_value =  ( wa_final-net_value - wa_final-rec_qty ).

*      wa_final-elikz = wa_ekpo-elikz. "Added by Rahul Vasita on 04.04.2024 18:00:47

      if wa_ekpo-elikz = 'X'.
        clear :  wa_final-pend_value,wa_final-still_qty.
        endif.


      IF p_menge = 'Z101'.
          wa_final-elikz = wa_ekpo-elikz. "Added by Rahul Vasita on 04.04.2024 18:00:47
        IF wa_ekpo-elikz = 'X' OR ( wa_final-menge = wa_final-erfmg ).
          APPEND wa_final TO it_final.
        ENDIF.
      ELSEIF p_menge = 'Z102'.
          wa_final-elikz = wa_ekpo-elikz. "Added by Rahul Vasita on 04.04.2024 18:00:47
        IF wa_ekpo-elikz is INITIAL and ( wa_final-menge <> wa_final-erfmg ).
          APPEND wa_final TO it_final.
        ENDIF.
      ELSE.
        APPEND wa_final TO it_final. "Added by Rahul Vasita on 04.04.2024 17:00:42
*      ELSEIF p_menge = 'Z104'.
*        DELETE it_final WHERE wrbtr LE 0.
*      ELSEIF p_menge = 'Z103'.
*        DELETE it_final WHERE wrbtr > 0.
      ENDIF.

*      APPEND wa_final TO it_final. "Comment by Rahul Vasita on 04.04.2024 16:57:39
      CLEAR : wa_ekpo,wa_final,wa_ekko,wa_lfa1,wa_ekbe,wa_mseg,wa_esllsu,wa_asmd,
                 wa_asmdt,wa_srvpos,wa_extrow,wa_esllpa,v_fakwr,wa_fplt,wa_rseg,wa_essr,wa_esllmg,wa_esllsr,wa_ekbe_rec,wa_esllsr,wa_esllpln.

    ENDLOOP.

*    IF p_menge = 'Z101'.
*      DELETE it_final WHERE erfmg LE 0.
*    ELSEIF p_menge = 'Z102'.
*      DELETE it_final WHERE erfmg > 0.
*    ENDIF.


  ELSE.

    DATA : v_ind TYPE i.
    v_ind = 0.


    IF it_ekbe_inv1 IS NOT INITIAL.
      SORT it_ekbe_inv1 BY belnr.
    ENDIF.
*    LOOP AT it_ekpo1 INTO wa_ekpo1.
    IF it_fplt_inv IS NOT INITIAL.
*      SORT it_fplt_inv BY afdat.
    ENDIF.

    LOOP AT it_fplt_new INTO wa_fplt_new.

      v_ind = v_ind + 1.

*      wa_final-wrbtr = wa_ekbe_inv-refwr.

      IF wa_fplt_inv IS NOT INITIAL.
        wa_final-fakwr = wa_fplt_new-fakwr.
      ENDIF.

      READ TABLE it_ekpo1 INTO wa_ekpo1 WITH KEY fplnr = wa_fplt_new-fplnr ebelp = wa_fplt_new-fpltr.

      READ TABLE it_ekpo_st INTO wa_ekpo_st WITH KEY ebeln = wa_ekpo1-ebeln ebelp = wa_ekpo1-ebelp.

      READ TABLE it_makt1 INTO wa_makt1 WITH KEY matnr = wa_ekpo1-matnr.
      IF wa_ekpo_st-txz01 IS NOT INITIAL.
        wa_final-asktx = wa_ekpo_st-txz01.
      ELSE.
        wa_final-asktx = wa_makt-maktx.
      ENDIF.

      READ TABLE it_esllpa INTO wa_esllpa WITH KEY packno = wa_ekpo1-packno.

      READ TABLE it_esllsu INTO wa_esllsu WITH KEY packno = wa_esllpa-sub_packno.


      IF wa_ekpo1 IS NOT INITIAL.
        wa_final-ebeln = wa_ekpo1-ebeln.
        wa_final-ebelp  = wa_ekpo1-ebelp.
        wa_final-werks = wa_ekpo1-werks.
        wa_final-loekz = wa_ekpo1-loekz.
        wa_final-srvpos = wa_ekpo1-matnr.
        wa_final-menge = wa_ekpo1-menge.
        wa_final-tbtwr = wa_ekpo1-netpr.
      ENDIF.
      READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekpo1-ebeln.
      IF wa_ekko IS NOT INITIAL.
        wa_final-bedat = wa_ekko-bedat.
*          wa_final-lifnr = wa_ekko-lifnr.

        IF wa_ekko-lifnr IS NOT INITIAL.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
            EXPORTING
              input  = wa_ekko-lifnr
            IMPORTING
              output = wa_final-lifnr.
        ENDIF.
        wa_final-waers = wa_ekko-waers.
      ENDIF.

      READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
      IF wa_lfa1 IS NOT INITIAL.
        wa_final-name1 = wa_lfa1-name1.
      ENDIF.

      IF wa_ekpo IS NOT INITIAL.
        READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekpo1-ebeln.
        IF sy-subrc = 0.
          wa_final-v_graph = alv_icon.
        ENDIF.

        READ TABLE it_essr INTO wa_essr WITH KEY ebeln = wa_ekpo1-ebeln ebelp = wa_ekpo1-ebelp.

        READ TABLE it_esllsr INTO wa_esllsr WITH KEY packno = wa_essr-packno.


        READ TABLE it_esllpa INTO wa_esllpa WITH KEY packno = wa_ekpo1-packno.
      ENDIF.

      IF wa_esllpa IS NOT INITIAL.
        READ TABLE it_extrow INTO wa_extrow WITH KEY packno = wa_esllpa-sub_packno extrow = wa_esllsu-extrow.
        IF wa_extrow IS NOT INITIAL.
          wa_final-extrow = wa_extrow-extrow.
        ENDIF.
        READ TABLE it_srvpos INTO wa_srvpos WITH KEY packno = wa_esllpa-sub_packno.

      ENDIF.

      READ TABLE it_esllmg INTO wa_esllmg WITH KEY packno = wa_esllsr-sub_packno extrow = wa_extrow-extrow.

      IF wa_esllmg IS NOT INITIAL.
        wa_final-erfmg = wa_esllmg-menge.
      ENDIF.
      IF wa_srvpos IS NOT INITIAL.
        READ TABLE it_asmdt INTO wa_asmdt WITH KEY asnum = wa_srvpos-srvpos.

        READ TABLE it_asmd INTO wa_asmd WITH KEY asnum = wa_srvpos-srvpos.
*        wa_final-matkl = wa_asmd-matkl.
      ENDIF.

      wa_final-still_qty  = wa_extrow-menge - wa_esllmg-menge.
      READ TABLE it_esllsu INTO wa_esllsu WITH KEY packno = wa_esllpa-sub_packno.

      IF wa_esllsu IS NOT INITIAL.
*        wa_final-tbtwr = wa_esllsu-tbtwr.
      ENDIF.

      wa_final-rec_qty = wa_esllsu-tbtwr * wa_esllmg-menge.
      wa_final-net_value =  wa_ekpo1-netwr.
*      wa_final-pend_value =  ( wa_final-net_value - wa_final-rec_qty ).

* **************Invoice based amount*********************
*
*      READ TABLE it_fplt INTO wa_fplt WITH KEY fplnr = wa_ekpo1-fplnr fpltr = wa_ekpo1-ebelp.
*      IF sy-subrc = 0.
*        wa_final-fakwr = wa_fplt-fakwr.
*        wa_final-fplnr = wa_fplt-fplnr.
*
*      ENDIF.

      READ TABLE it_rseg INTO wa_rseg WITH KEY ebeln = wa_ekpo1 ebelp = wa_ekpo1-ebelp." belnr = wa_ekpo1-belnr.
      IF sy-subrc = 0.
*        wa_final-wrbtr = wa_rseg-wrbtr.
      ENDIF.

      READ TABLE it_rbkp INTO wa_rbkp WITH KEY belnr = wa_rseg-belnr.
*      wa_final-stblg = wa_rbkp-stblg.


      READ TABLE it_esllrd INTO wa_esllrd WITH KEY packno = wa_ekpo1-packno.
*      READ TABLE it_esllsurd INTO wa_esllsurd WITH KEY packno = wa_esllrd-packno.
      READ TABLE it_srvposrd INTO wa_srvposrd WITH KEY packno = wa_esllrd-sub_packno.
      READ TABLE it_asmdrd INTO wa_asmdrd WITH KEY asnum = wa_srvposrd-srvpos.
      IF wa_asmdrd IS NOT INITIAL.
        wa_final-matkl = wa_asmdrd-matkl.
      ELSE.
        wa_final-matkl = wa_ekpo1-matkl.
      ENDIF.
*      wa_final-pend_value =  ( wa_fplt_inv-fakwr - wa_rseg-wrbtr ).

      READ TABLE it_ekbe_inv1 INTO wa_ekbe_inv1 WITH KEY ebeln = wa_ekpo1-ebeln ebelp = wa_ekpo1-ebelp index1 = wa_fplt_new-index1 ."belnr = wa_rbkp-belnr ."cpudt = wa_rbkp-budat.
      IF wa_ekbe_inv1 IS NOT INITIAL.
        wa_final-wrbtr = wa_ekbe_inv1-refwr.
*        wa_final-wrbtr = wa_ekbe_inv1-wrbtr.
      ENDIF.
      wa_final-pend_value =  ( wa_fplt_new-fakwr - wa_ekbe_inv1-refwr ).

*      IF wa_final-pend_value IS NOT INITIAL.
*        IF  wa_final-pend_value < 0.
*          wa_final-pend_value = wa_final-pend_value * -1.
*        ENDIF.
*      ENDIF.
* wa_final-pend_value =  ( wa_fplt_inv-fakwr - wa_ekbe_inv1-wrbtr ).
      wa_final-erekz = wa_ekpo1-erekz. "Added by Rahul Vasita on 04.04.2024 18:00:47
      IF wa_final-erekz = abap_true.
        CLEAR wa_final-pend_value .
      ENDIF.

      APPEND wa_final TO it_final.
      CLEAR : wa_ekpo-ebeln,wa_ekpo1,wa_final,wa_ekko,wa_lfa1,wa_ekbe,wa_mseg,wa_esllsu,wa_asmd,v_wrbtr,v_fakwr,
                 wa_asmdt,wa_srvpos,wa_extrow,wa_esllpa,v_fakwr,wa_fplt,wa_rseg,wa_essr,wa_esllmg,wa_esllsr,wa_ekbe_inv1,wa_fplt_new.
    ENDLOOP.

*    IF p_menge = 'Z103'.
*      DELETE it_final WHERE WRBTR LE 0.
*    ELSEIF p_menge = 'Z104'.
*      DELETE it_final WHERE WRBTR > 0.
*    ENDIF.

  ENDIF.

  IF p_menge = 'Z101' AND  rad2 = 'X'.
    MESSAGE 'Please check before enter the values' TYPE 'E'.
  ELSEIF p_menge = 'Z102' AND rad2 = 'X'.
    MESSAGE 'Please check before enter the values' TYPE 'E'.
  ELSEIF p_menge = 'Z103' AND  rad1 = 'X'.
    MESSAGE 'Please check before enter the values' TYPE 'E'.
  ELSEIF p_menge = 'Z104' AND  rad1 = 'X'.
    MESSAGE 'Please check before enter the values' TYPE 'E'.
  ENDIF.


*  IF p_menge = 'Z101'.
*    DELETE it_final WHERE erfmg LE 0.
*  ELSEIF p_menge = 'Z102'.
*    DELETE it_final WHERE erfmg > 0.
*  ELSEIF p_menge = 'Z103'.
*    DELETE it_final WHERE wrbtr LE 0.
*  ELSEIF p_menge = 'Z104'.
*    DELETE it_final WHERE wrbtr > 0.
*  ENDIF.


*  IF p_menge = 'Z101'.                "COMMENTED BY RAJ ON 11.04.2024
*    DELETE it_final WHERE erfmg LE 0.
*  ELSEIF p_menge = 'Z102'.
*    DELETE it_final WHERE erfmg > 0.
  IF p_menge = 'Z104'.
    DELETE it_final WHERE wrbtr LE 0.
  ELSEIF p_menge = 'Z103'.
    DELETE it_final WHERE wrbtr > 0.
  ENDIF.




*  SORT it_final BY  extrow ASCENDING
*  SORT it_final BY  extrow DESCENDING.
  .
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTH_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM auth_check .
*
  SELECT ebeln bedat lifnr waers FROM ekko INTO CORRESPONDING FIELDS OF TABLE it_ekko
         WHERE ebeln IN s_ebeln AND bedat IN s_bedat AND bstyp = 'F' AND lifnr IN s_lifnr.

  IF it_ekko IS INITIAL.
    MESSAGE 'Data does not exist' TYPE 'E'.
  ENDIF.

  IF it_ekko IS NOT INITIAL.
    SELECT ebeln ebelp werks packno netwr fplnr loekz matnr txz01 menge netpr matkl elikz erekz  knttp FROM ekpo INTO CORRESPONDING FIELDS OF  TABLE it_ekpo FOR ALL ENTRIES IN it_ekko
       WHERE ebeln = it_ekko-ebeln  AND werks IN s_werks AND matkl IN s_maktl AND knttp IN s_knttp.
  ENDIF.
  it_ekpo1[] = it_ekpo[].

  IF it_ekpo IS NOT INITIAL.
    DELETE it_ekpo WHERE fplnr IS NOT INITIAL.
  ENDIF.

  IF it_ekpo1 IS NOT INITIAL.
    DELETE it_ekpo1 WHERE fplnr IS INITIAL.
  ENDIF.

  IF rad1 = 'X'.
    IF it_ekpo IS NOT INITIAL.
      LOOP AT it_ekpo INTO wa_ekpo.
        AUTHORITY-CHECK OBJECT 'ZMM_IN_WRK'
         ID 'WERKS' FIELD wa_ekpo-werks
         ID 'ACTVT' FIELD '03'.
        IF sy-subrc <> 0.
          MESSAGE e049(zsd) WITH wa_ekpo-werks.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.

  IF rad2 = 'X'.
    IF it_ekpo1 IS NOT INITIAL.
      LOOP AT it_ekpo1 INTO wa_ekpo1.
        AUTHORITY-CHECK OBJECT 'ZMM_IN_WRK'
         ID 'WERKS' FIELD wa_ekpo1-werks
         ID 'ACTVT' FIELD '03'.
        IF sy-subrc <> 0.
          MESSAGE e049(zsd) WITH wa_ekpo1-werks.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_FCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_fcat .

*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'V_GRAPH'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PO History'.
*  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '6'. wa_fcat-hotspot = 'X'.wa_fcat-icon = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EBELN'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PO.Number'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EBELP'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PO.Line item'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '3'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EXTROW'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Line Number'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '4'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  ENDIF.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'V_GRAPH'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PO History'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '6'. wa_fcat-hotspot = 'X'.wa_fcat-icon = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  ENDIF.
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WERKS'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Plant'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '4'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BEDAT'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Doc. Date'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LIFNR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Vendor'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'NAME1'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Vendor Name'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '30'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'NAME1'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Vendor Name'.
*  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '35'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'SRVPOS'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Activity Number'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  ENDIF.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'ASKTX'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Short Text'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '40'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MATKL'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Material Group'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BEWTP'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PO History'.
*  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MENGE'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Order Quantity'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  IF rad1 = 'X'.

    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'ERFMG'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Received Quantity'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  ENDIF.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'STILL_QTY'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Still To delivered(qty)'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  ENDIF.
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'TBTWR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Net Price'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'NET_VALUE'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Net Order Value'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'REC_QTY'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Rec. Qty Value'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  ENDIF.

  IF rad1 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'PEND_VALUE'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Pending Order Value'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  ENDIF.
  IF rad2 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'FAKWR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Inv. Planning Amount'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WRBTR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Inv. Booked Amount'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  ENDIF.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WAERS'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Currency'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  IF rad2 = 'X'.
    wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'PEND_VALUE'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Pending Invoice Value'.
    wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  ENDIF.

if rad1 = 'X'  or p_menge = 'Z101' or p_menge = 'Z102'.
  "Adding Start by Rahul Vasita on 04.04.2024 18:01:56
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'ELIKZ'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Delivery Comp.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = ''. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  "Adding End by Rahul Vasita on 04.04.2024 18:01:56
  endif.

  if rad2 = 'X'.
     wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EREKZ'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Final Inv. Indic.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = ''. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
 endif.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv .

  IF it_final IS NOT INITIAL.
*    SORT it_final BY  ebeln ebelp extrow.
*    SORT it_final BY  ebeln ebelp extrow.
    DELETE it_final WHERE loekz = 'L'.
    DELETE it_final WHERE stblg IS NOT INITIAL.
  ENDIF.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-repid
      i_callback_top_of_page = 'TOP_PAGE'
*     i_callback_user_command = 'INTERACTIVE'
      i_save                 = 'A'
      is_layout              = wa_layout
      it_fieldcat            = it_fcat
    TABLES
      t_outtab               = it_final
    EXCEPTIONS
      program_error          = 1
      OTHERS                 = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
ENDFORM.


FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).

  IF rad1 = 'X'.

    wa_header-typ = 'H'.
*  IF v_all = 'X'.
    wa_header-info = 'Service Order with Description'.
  ENDIF.


  IF rad2 = 'X'.

    wa_header-typ = 'H'.
*  IF v_all = 'X'.
    wa_header-info = 'Service order with inv plan'.
  ENDIF.


*  ELSEIF v_com = 'X'.
*    wa_header-info = 'Completed Sales Orders'.
*  ELSEIF v_par = 'X'.
*    wa_header-info = 'Partially Completed Sales Orders'.
*  ELSEIF v_rem = 'X'.
*    wa_header-info = 'Remaining Sales Orders'.
*  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
*  IF NOT s_date-high IS INITIAL.
*    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
*    CONCATENATE s_date-high+6(2) '-' s_date-high+4(2) '-' s_date-high+0(4) INTO v_highdate.
*    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
*  ELSE.
*    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
*    LOOP AT s_date.
*      IF NOT wa_header-info IS INITIAL.
*        IF NOT s_date-low IS INITIAL.
*          CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
*        ENDIF.
*      ELSE.
*        CONCATENATE 'Date :- ' v_lowdate INTO wa_header-info SEPARATED BY space.

*    CONCATENATE sy-datum

  DATA : v_date TYPE char10.


  CALL FUNCTION 'CONVERSION_EXIT_PDATE_OUTPUT'
    EXPORTING
      input  = sy-datum
    IMPORTING
      output = v_date.

  CONCATENATE 'Date :- ' v_date INTO wa_header-info SEPARATED BY space.

*      ENDIF.
*    ENDLOOP.
*  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CLEAR : v_lowdate,v_highdate.

*  wa_header-typ = 'S'.
*  IF NOT s_werks-high IS INITIAL.
*    CONCATENATE 'Plant :- ' s_werks-low  ' TO ' s_werks-high INTO wa_header-info SEPARATED BY space.
*  ELSE.
*    LOOP AT s_werks.
*      IF NOT wa_header-info IS INITIAL.
*        IF NOT s_werks-low IS INITIAL.
*          CONCATENATE wa_header-info ',' s_werks-low INTO wa_header-info.
*        ENDIF.
*      ELSE.
*        CONCATENATE 'Plant :- ' s_werks-low INTO wa_header-info SEPARATED BY space.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*  APPEND wa_header TO it_header.
*  CLEAR wa_header.

**** Added by Carina Jose on 06/07/2022
*  wa_header-typ = 'S'.
*  IF  v_matkl IS NOT INITIAL.
*    CONCATENATE 'No authorization for material groups :' v_matkl INTO wa_header-info.
*    APPEND wa_header TO it_header.
*    CLEAR: wa_header, v_matkl.
*  ENDIF.
****** End of changes by Carina Jose on 06/07/2022


  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'  "Uncommented by Raj on 12.07.2023
    EXPORTING
      it_list_commentary = it_header.
*     i_logo             = 'ASTRAL_2020'.
*      i_logo             = 'LOGO_K'.


ENDFORM.
