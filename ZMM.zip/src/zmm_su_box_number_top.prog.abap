
*&---------------------------------------------------------------------*
*&  Include           ZMM_SU_BOX_NUMBER_TOP
*&---------------------------------------------------------------------*
*******Types Declaration.

TYPES :  BEGIN OF ty_mhcb,
           matnr TYPE  matnr,
           werks TYPE werks_d,
           lgort TYPE lgort_d,
           charg TYPE charg_d,
           clabs TYPE  labst,
           cumlm TYPE umlmd,
           cinsm TYPE insme,
           ceinm TYPE  einme,
           cretm TYPE  retme,
         END OF ty_mhcb,

         BEGIN OF ty_afpo,
           aufnr TYPE aufnr,
           amein TYPE co_aufme,
           matnr TYPE afpo-matnr,
           pgmng TYPE afpo-pgmng,
           lgort TYPE lgort_d,
           dwerk TYPE  werks_d,
           charg TYPE  charg_d,
         END OF ty_afpo,

         BEGIN OF ty_final,
           mandt       TYPE mandt,
           zsu_no      TYPE zsu_no,
           aufnr       TYPE aufnr,
           matnr       TYPE matnr,
           werks       TYPE werks_d,
           lgort       TYPE lgort_d,
           charg       TYPE charg_d,
           zbatch_stk  TYPE menge_d , "int4,
           meins       TYPE meins,
           lhmg1       TYPE lvs_lhmng1,
           lety1       TYPE lvs_letyp1,
           lhme1       TYPE lhmeh1,
           lgpla       TYPE lgpla,
           zlhmg1      TYPE lvs_lhmng1,
           dispo       TYPE co_dispo,
           budat       TYPE budat,
           confirm_qty TYPE menge_d,
         END OF ty_final,

         BEGIN OF ty_zmm_su_number,
           mandt  TYPE  mandt,
           zsu_no TYPE zsu_no,
         END OF ty_zmm_su_number,

         BEGIN OF ty_aufm,
           bwart TYPE bwart,
           menge TYPE	menge_d,
           aufnr TYPE	aufnr,
         END OF ty_aufm ,

         BEGIN OF ty_zwm_picklist,
           werks TYPE werks_d,
           lgort TYPE lgort_d,
           lgnum TYPE lgnum,
           lgtyp TYPE lgtyp,
           lgber TYPE lgber,
         END OF ty_zwm_picklist,

         BEGIN OF ty_lagp,
           lgnum TYPE	lgnum,
           lgtyp TYPE lgtyp,
           lgpla TYPE lgpla,
           lgber TYPE lgber,
         END OF ty_lagp,

         BEGIN OF ty_check,
           zsu_no	     TYPE zsu_no,
           aufnr       TYPE aufnr,
           matnr       TYPE matnr,
           werks       TYPE werks_d,
           lgort       TYPE lgort_d,
           charg       TYPE charg_d,
           zbatch_stk	 TYPE menge_d,
           zlhmg1      TYPE  lvs_lhmng1,
           confirm_qty TYPE menge_d,
         END OF ty_check.

TYPES: BEGIN OF ty_t001w,
         werks TYPE werks_d,
       END OF ty_t001w.

*        ***************Data Declaration*******************
DATA : it_afpo          TYPE STANDARD TABLE OF ty_afpo,
       wa_afpo          TYPE ty_afpo,
       it_aufm          TYPE STANDARD TABLE OF ty_aufm,
       wa_aufm          TYPE ty_aufm,
       it_final         TYPE STANDARD TABLE OF ty_final,
       wa_final         TYPE ty_final,
       it_mhcb          TYPE STANDARD TABLE OF ty_mhcb,
       wa_mhcb          TYPE ty_mhcb,
       it_zmm_su_number TYPE STANDARD TABLE OF ty_zmm_su_number,
       wa_zmm_su_number TYPE ty_zmm_su_number,
       it_zwm_picklist  TYPE STANDARD TABLE OF ty_zwm_picklist,
       wa_zwm_picklist  TYPE ty_zwm_picklist,
       it_lagp          TYPE STANDARD TABLE OF ty_lagp,
       wa_lagp          TYPE ty_lagp,
       it_check         TYPE STANDARD TABLE OF ty_check,
       wa_check         TYPE ty_check.

*        ***************Global Variable Declaration*******************

DATA: gwa_dynpfields TYPE dynpread,
      gv_matnr       TYPE matnr,
      gv_aufnr       TYPE aufnr,
      gv_menge       TYPE aufm-menge,
      gv_menge1      TYPE aufm-menge,
      gv_menge2      TYPE aufm-menge,
      gv_text        TYPE char100,
      gv_text1       TYPE char100,
      gv_text2       TYPE char100,
      gv_zsu_no      TYPE zsu_no,
      gv_meins       TYPE mara-meins,
      gv_meins1      TYPE mara-meins,
      gv_maktx       TYPE makt-maktx,
      gv_lety1       TYPE mlgn-lety1,
      gv_lhme1       TYPE mlgn-lhme1,
      gv_lhmg1       TYPE mlgn-lhmg1,
      gv1_lhmg1      TYPE mlgn-lhmg1,
      gv_zlhmg1      TYPE mlgn-lhmg1,
      gv_stock       TYPE  char20, " i , " added chnages on 12.04.2019
      gv_stock1      TYPE  char20, "i, " added chnages on 12.04.2019
      gv_amein       TYPE afpo-amein,
      gv_plant       TYPE afpo-dwerk,
      gv_plant1      TYPE afpo-dwerk,
      gv_pgmng       TYPE afpo-pgmng,
      gv_lgort       TYPE afpo-lgort,
      gv_lgort1      TYPE afpo-lgort,
      gv_charg       TYPE mchb-charg,
      gv_charg1      TYPE mchb-charg,
      gv_bukrs       TYPE t001k-bukrs, " Company code add 03.01.2022
*      gv_snro        TYPE zwm_snro_box-nrrangenr, " Company code add 03.01.2022
      gt_dynpfields  TYPE TABLE OF dynpread,
      gv_count       TYPE i VALUE '0',
      gv_p_no        TYPE i,
      gv_p_no1       TYPE i,
      gv_p1_no       TYPE i,
      gv_no_label    TYPE i,
      gv_last        TYPE i,
      gv_sum         TYPE mlgn-lhmg1,
      gv_gamng       TYPE gamng,
      gv_num         TYPE zsu_no, " i, " Changes done on 12.04.2019
      gv_amt         TYPE char17,
      gc             TYPE char10,
      gv_m             TYPE char10,
      gv_dispo       TYPE afko-dispo.
DATA v_charg TYPE mchb-charg.
DATA v_matnr TYPE matnr.

DATA : gt_t001w TYPE STANDARD TABLE OF ty_t001w,
       wa_t001w TYPE ty_t001w.

DATA: executed TYPE n.
DATA difference TYPE menge_d.
DATA gv_amt1 TYPE menge_d.
