*&---------------------------------------------------------------------*
*& Include          ZMM_SU_BOX_NUMBER_SCR
*&---------------------------------------------------------------------*

SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-001.

PARAMETERS : rad1     RADIOBUTTON GROUP r1,
             rad2     RADIOBUTTON GROUP r1,
             rad3     RADIOBUTTON GROUP r1,  "" Added by Ranjan 24.09.2025

             p_matnr1 TYPE mchb-matnr MODIF ID sc3,
             p_maktx1 TYPE makt-maktx MODIF ID sc2,
             p1_charg TYPE mchb-charg MODIF ID sc4,
             p1_dwerk TYPE afpo-dwerk MODIF ID sc3,
             p1_lgort TYPE afpo-lgort MODIF ID sc3,
             p_lgpla  TYPE lagp-lgpla MODIF ID sc2,
             p1_stock TYPE i MODIF ID sc4,
             p1_lhmg1 TYPE i MODIF ID sc4,
             p1_no    TYPE i MODIF ID sc4,
             p1_meins TYPE mara-meins MODIF ID sc2,
             p1_lety1 TYPE mlgn-lety1 MODIF ID sc2,
             p1_lhme1 TYPE mlgn-lhme1 MODIF ID sc2,
*
             p_aufnr  TYPE afko-aufnr MODIF ID sc1,
             p_matnr  TYPE afpo-matnr MODIF ID sc1,
             p_maktx  TYPE makt-maktx MODIF ID sc1,
             p_charg  TYPE afpo-charg MODIF ID sc1,
             p_dwerk  TYPE afpo-dwerk MODIF ID sc1,
             p_prdqty TYPE aufm-menge MODIF ID sc1,
             p_lhmg1  TYPE mlgn-lhmg1 MODIF ID sc1,
             p_no     TYPE i MODIF ID sc1,
             p_amein  TYPE afpo-amein MODIF ID sc1,
             p_logrt  TYPE afpo-lgort MODIF ID sc1,
             p_pgmng  TYPE afpo-pgmng MODIF ID sc1,
             p_lety1  TYPE mlgn-lety1 MODIF ID sc1,
             p_lhme1  TYPE mlgn-lhme1 MODIF ID sc1.
SELECTION-SCREEN END OF BLOCK b1.

*&---------------------------------------------------------------------*
*&                At-Selection-Screen-Output
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.
  IF executed = 1.
    executed = 0.
    CLEAR :
    p_matnr1,
    p_maktx1,
    p1_charg,
    p1_dwerk,
    p1_lgort,
    p_lgpla ,
    p1_stock,
    p1_lhmg1,
    p1_no   ,
    p1_meins,
    p1_lety1,
    p1_lhme1,
    p_aufnr,
    p_matnr ,
    p_maktx,
    p_charg ,
    p_dwerk ,
    p_prdqty,
    p_lhmg1 ,
    p_no    ,
    p_amein ,
    p_logrt ,
    p_pgmng ,
    p_lety1 ,
    p_lhme1.

  ENDIF.


  SET HOLD DATA OFF.
  IF rad2 = 'X'.
    LOOP AT SCREEN.
      IF screen-name = 'P_MAKTX1' OR screen-name = 'P1_MEINS' OR screen-name = 'P1_LETY1' OR screen-name = 'P1_LHME1'.
        screen-input = 0.
      ELSEIF screen-group1 = 'SC1'. "name = 'P_AUFNR' or screen-name = 'P_MATNR' OR SCREEN-NAME = 'P_MAKTX' OR SCREEN-NAME = 'P_CHARG' OR SCREEN-NAME = 'P_DWERK'
*        OR SCREEN-NAME = 'P_LHMG1'.
        screen-active = 0.
*screen-invisible = 1.
      ELSEIF screen-group1 = 'SC3'.
        screen-required = 0.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ELSE.
    LOOP AT SCREEN.
      IF screen-group1 = 'SC2' OR screen-group1 = 'SC3' OR screen-group1 = 'SC4'.
        screen-active = 0.
      ELSEIF screen-name = 'P_MATNR' OR screen-name = 'P_MAKTX' OR screen-name = 'P_CHARG' OR screen-name = 'P_DWERK'
        OR screen-name = 'P_LETY1' OR screen-name = 'P_LHME1' OR screen-name = 'P_LOGRT' OR screen-name = 'P_AMEIN' OR screen-name = 'P_PGMNG'."OR SCREEN-NAME = '"screen-group1 = 'SC1'.
        screen-input = 0.
      ELSEIF screen-name = 'P_AUFNR' OR screen-name = 'P_NO' OR screen-name = 'P_PRDQTY'.
        screen-required = 0.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ENDIF.


AT SELECTION-SCREEN ON p_maktx1.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P_MATNR1'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_matnr.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
 WITH KEY fieldname = 'P_MATNR1'.
  IF sy-subrc = 0.
    gv_matnr = gwa_dynpfields-fieldvalue.

    CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
      EXPORTING
        input  = gv_matnr
      IMPORTING
        output = gv_matnr
*     EXCEPTIONS
*       LENGTH_ERROR       = 1
*       OTHERS = 2
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

  ENDIF.

  CLEAR gv_maktx.
  SELECT SINGLE maktx FROM makt
         INTO gv_maktx
         WHERE matnr = gv_matnr.
  p_maktx1 = gv_maktx.

  CLEAR gv_meins.
  SELECT SINGLE meins FROM mara
      INTO gv_meins
      WHERE matnr = gv_matnr.
  p1_meins = gv_meins.

  CLEAR : gv_lety1,gv_lhme1, gv1_lhmg1.

  SELECT SINGLE lety1
                lhme1
                lhmg1
                FROM mlgn
                INTO  ( gv_lety1,gv_lhme1, gv1_lhmg1 )
                WHERE matnr = gv_matnr.

  p1_lety1 = gv_lety1.
  p1_lhme1 = gv_lhme1.
  p1_lhmg1 = gv1_lhmg1.

AT SELECTION-SCREEN ON  p1_stock.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P1_CHARG'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_charg1.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P1_CHARG'.
  IF sy-subrc = 0.
    gv_charg1 = gwa_dynpfields-fieldvalue.
  ENDIF.

  REFRESH gt_dynpfields.
  CLEAR  gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P1_LGORT'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_lgort1.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P1_LGORT'.
  IF sy-subrc = 0.
    gv_lgort1 = gwa_dynpfields-fieldvalue.
  ENDIF.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P1_DWERK'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_plant1.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P1_DWERK'.
  IF sy-subrc = 0.
    gv_plant1 = gwa_dynpfields-fieldvalue.
  ENDIF.

  CLEAR it_mhcb.


  SELECT matnr
         werks
         lgort
         charg
         clabs
         cumlm
         cinsm
         ceinm
         cretm
    FROM mchb
    INTO TABLE it_mhcb
    WHERE matnr = gv_matnr AND werks = gv_plant1 AND lgort = gv_lgort1 AND charg = gv_charg1.


  CLEAR: gv_stock,
         wa_mhcb,
         gv_stock1.

  READ TABLE it_mhcb INTO wa_mhcb WITH KEY matnr = gv_matnr.
  IF sy-subrc EQ 0 AND wa_mhcb-lgort = gv_lgort1 AND wa_mhcb-werks = gv_plant1 AND wa_mhcb-charg = gv_charg1.
    gv_stock = wa_mhcb-clabs + wa_mhcb-cumlm + wa_mhcb-cinsm + wa_mhcb-ceinm + wa_mhcb-cretm.
  ENDIF.
  CONDENSE gv_stock.

  gv_stock1 = gv_stock.
  p1_stock = gv_stock.


AT SELECTION-SCREEN ON p1_no.

  CLEAR gv_p1_no.
  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P1_STOCK'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR : gv_amt.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P1_STOCK'.
  IF sy-subrc = 0.
    gv_amt = gwa_dynpfields-fieldvalue.
  ENDIF.
  REPLACE ALL OCCURRENCES OF ',' IN gv_amt WITH space.
  CONDENSE gv_amt NO-GAPS.
  gv_stock = gv_amt.

  IF gv_amt IS NOT INITIAL.

    CLEAR it_check.

    SELECT matnr
           werks
           lgort
           charg
           zlhmg1
            FROM zmm_su_number
           INTO CORRESPONDING FIELDS OF TABLE it_check
           WHERE aufnr = ' ' AND
                 matnr =  gv_matnr AND
                 werks = gv_plant1 AND
                 lgort = gv_lgort1 AND
                 charg = gv_charg1.
    IF sy-subrc EQ 0 .
      SORT it_check BY zlhmg1 ASCENDING.
      CLEAR wa_check.
      READ TABLE it_check INTO wa_check INDEX 1.
      IF sy-subrc EQ 0.
        gv_zlhmg1 = wa_check-zlhmg1.
        CLEAR gc.
        IF gv_amt > gv_zlhmg1.
          gc = gv_zlhmg1.
          CONCATENATE 'Only Quantity' gc 'can be processed' INTO gv_text1 SEPARATED BY space.
          MESSAGE gv_text1 TYPE 'E'.
        ENDIF.
      ENDIF.


    ENDIF.

    p1_stock = gv_stock.
  ENDIF.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P1_LHMG1'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START
    " SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR : gv1_lhmg1, gv_amt.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P1_LHMG1'.
  IF sy-subrc = 0.
    gv_amt = gwa_dynpfields-fieldvalue.
  ENDIF.
  REPLACE ALL OCCURRENCES OF ',' IN gv_amt WITH space.
  CONDENSE gv_amt NO-GAPS.
  gv1_lhmg1 = gv_amt.
  IF gv1_lhmg1 > 0.
    gv_p1_no = ceil( gv_stock / gv1_lhmg1 ).
    p1_no = gv_p1_no.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_lgpla.
  PERFORM p_lgpla_f4.

AT SELECTION-SCREEN ON p_matnr.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P_AUFNR'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_aufnr.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
 WITH KEY fieldname = 'P_AUFNR'.
  IF sy-subrc = 0.
    gv_aufnr = gwa_dynpfields-fieldvalue.

""Start of changes by Ranjan 24.09.2025
      IF rad3 = 'X'.
         DATA: lv_objnr TYPE jcds-objnr.
    DATA: lv_status TYPE jcds-stat.
    DATA: lv_count TYPE i.

    SELECT SINGLE objnr FROM aufk INTO lv_objnr WHERE aufnr = p_aufnr.
    IF sy-subrc = 0.
      SELECT COUNT(*) FROM jcds INTO lv_count WHERE objnr = lv_objnr AND stat = 'I0002' AND inact = space.
      IF lv_count = 0.
        MESSAGE 'Production Order is not released. Bar code cannot be generated.' TYPE 'E'.
      ENDIF.
*    ELSE.
*      MESSAGE 'Production Order not found' TYPE 'E'.
    ENDIF.
    ENDIF.

    ""End of changes by Ranjan 24.09.2025

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = gv_aufnr
      IMPORTING
        output = gv_aufnr.

    CLEAR it_afpo.
    IF gv_aufnr IS NOT INITIAL.
      SELECT  aufnr
              amein
              matnr
              pgmng
              lgort
              dwerk
              charg
              FROM afpo
              INTO  TABLE it_afpo
              WHERE aufnr = gv_aufnr.
    ENDIF.
    CLEAR wa_afpo.

    READ TABLE it_afpo INTO wa_afpo WITH KEY aufnr = gv_aufnr.
    IF sy-subrc EQ 0.
      gv_matnr = wa_afpo-matnr.

      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input  = gv_matnr
        IMPORTING
          output = gv_matnr
*     EXCEPTIONS
*         LENGTH_ERROR       = 1
*         OTHERS = 2
        .
      p_matnr = gv_matnr.
    ENDIF.

    CLEAR gv_meins1.
    SELECT SINGLE meins FROM mara
        INTO gv_meins1
        WHERE matnr = gv_matnr.

    CLEAR gv_maktx.
    SELECT SINGLE maktx FROM makt
             INTO gv_maktx
             WHERE matnr = gv_matnr.

    p_maktx = gv_maktx.

    gv_charg = wa_afpo-charg.

    DATA : lv_charg TYPE aufm-charg.

    SELECT SINGLE charg
           FROM aufm
           INTO lv_charg
           WHERE matnr = gv_matnr AND aufnr = gv_aufnr.

    IF sy-subrc EQ 0 .
      IF gv_charg = lv_charg.
        p_charg = gv_charg.
      ELSE.
        MESSAGE 'Wrong batch'  TYPE 'E'.
      ENDIF.
    ENDIF.

    gv_plant =  wa_afpo-dwerk.
    p_dwerk = gv_plant.

    gv_amein = wa_afpo-amein.
    p_amein = gv_amein.

    gv_lgort =  wa_afpo-lgort.
    p_logrt = gv_lgort.

    CLEAR : gv_gamng,
            gv_dispo.

    SELECT SINGLE gamng dispo FROM afko
             INTO ( gv_gamng , gv_dispo )
             WHERE aufnr = gv_aufnr.

    p_pgmng = gv_gamng.

    CLEAR : gv_lety1, gv_lhmg1, gv_lhme1.

    SELECT SINGLE lety1
                  lhmg1
                  lhme1
                  FROM mlgn
                  INTO ( gv_lety1 ,gv_lhmg1, gv_lhme1 )
                  WHERE matnr = gv_matnr.

    p_lety1 = gv_lety1.
    p_lhme1 = gv_lhme1.
    p_lhmg1 = gv_lhmg1.
  ENDIF.

  PERFORM authorisation.

AT SELECTION-SCREEN ON p_prdqty.

  CLEAR : it_aufm,
          gv_menge.

  SELECT bwart
       menge
       aufnr
       FROM aufm
       INTO TABLE it_aufm
       WHERE aufnr = gv_aufnr AND
             ( bwart = '101' OR bwart = '102' ).
  CLEAR wa_aufm.
  LOOP AT it_aufm INTO wa_aufm WHERE aufnr = gv_aufnr.
    IF wa_aufm-bwart = '101'.
      gv_menge = gv_menge + wa_aufm-menge.
    ELSEIF wa_aufm-bwart = '102'.
      gv_menge = gv_menge - wa_aufm-menge.
    ENDIF.
    CLEAR wa_aufm.
  ENDLOOP.

  p_prdqty = gv_menge.

AT SELECTION-SCREEN ON p_no.

  CLEAR p_no.
  REFRESH gt_dynpfields.
  CLEAR  gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P_PRDQTY'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_amt.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
 WITH KEY fieldname = 'P_PRDQTY'.
  IF sy-subrc = 0.
    gv_amt = gwa_dynpfields-fieldvalue.
  ENDIF.
  REPLACE ALL OCCURRENCES OF ',' IN gv_amt WITH space.
  CONDENSE gv_amt NO-GAPS.
  gv_menge1 = gv_amt.

  IF gv_menge1 IS NOT INITIAL.
    CLEAR it_check.
    SELECT zsu_no
           aufnr
           matnr
           werks
           lgort
           charg
           zbatch_stk
           zlhmg1
      confirm_qty
            FROM zmm_su_number
           INTO TABLE it_check
           WHERE aufnr = gv_aufnr AND
                 matnr =  gv_matnr AND
                 werks = gv_plant AND
                 lgort = gv_lgort AND
                 charg = gv_charg.


    IF sy-subrc EQ 0 .
      SORT it_check BY zsu_no DESCENDING.
      CLEAR wa_check.
      READ TABLE it_check INTO wa_check INDEX 1.
      IF sy-subrc EQ 0 AND wa_check-confirm_qty = gv_menge.
        difference = ( gv_menge - wa_check-confirm_qty ) + ( wa_check-zlhmg1 - gv_amt ).
**      difference = gv_menge - wa_check-zbatch_stk.
        gv_zlhmg1 = wa_check-zlhmg1.
*      CLEAR gc.
*      if gv_amt > difference.
        "gc = wa_check-zlhmg1." + gv_zlhmg1.
        CONDENSE gc NO-GAPS.
        gv_amt1 = gv_amt.
        IF wa_check-zlhmg1 < gv_amt1.
          gc = wa_check-zlhmg1.
          CONCATENATE 'Only Quantity' gc 'can be processed' INTO gv_text1 SEPARATED BY space.
          MESSAGE gv_text1 TYPE 'E'.
        ENDIF.
**      READ TABLE it_check INTO wa_check INDEX 1.
**      if sy-subrc eq 0.
**      gv_zlhmg1 = wa_check-zlhmg1.
**      CLEAR gc.
**      IF gv_menge1 > gv_zlhmg1.
**        gc = gv_zlhmg1.
**        CONCATENATE 'Only Quantity' gc 'can be processed' INTO gv_text1 SEPARATED BY space.
**        MESSAGE gv_text1 TYPE 'E'.
**      ENDIF.
      ELSEIF sy-subrc EQ 0 AND wa_check-confirm_qty <> gv_menge.
        difference = ( gv_menge - wa_check-confirm_qty ) +  wa_check-zlhmg1." - gv_amt ).
**      difference = gv_menge - wa_check-zbatch_stk.
        gv_zlhmg1 = wa_check-zlhmg1.
*      CLEAR gc.
*      if gv_amt > difference.
        "gc = wa_check-zlhmg1." + gv_zlhmg1.
        CONDENSE gc NO-GAPS.
        gv_amt1 = gv_amt.
        IF difference < gv_amt1.
          gc = difference.
          CONCATENATE 'Only Quantity' gc 'can be processed' INTO gv_text1 SEPARATED BY space.
          MESSAGE gv_text1 TYPE 'E'.
        ENDIF.
      ENDIF.

    ELSE.
      difference = p_prdqty - gv_amt.
    ENDIF.

******************************  Production quantity not enter more then production order
    if gv_menge1 > gv_menge .
     gv_m = gv_menge1.
    CONCATENATE 'Enter Quantity'  gv_m 'is More then production order Quantity' INTO gv_text2 SEPARATED BY space.
          MESSAGE gv_text2 TYPE 'E'.
    endif.
*******************

    p_prdqty = gv_menge1.
  ENDIF.

  REFRESH gt_dynpfields.
  CLEAR  gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P_LHMG1'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*         EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR: gv_lhmg1, gv_amt.
  CLEAR gwa_dynpfields.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
 WITH KEY fieldname = 'P_LHMG1'.
  IF sy-subrc = 0.
    gv_amt = gwa_dynpfields-fieldvalue.
  ENDIF.
  REPLACE ALL OCCURRENCES OF ',' IN gv_amt WITH space.
  CONDENSE gv_amt NO-GAPS.
  gv_lhmg1 = gv_amt.

  IF gv_lhmg1 IS NOT INITIAL.
    p_lhmg1 = gv_lhmg1.
  ENDIF.

  IF gv_lhmg1 > 0.
    CLEAR gv_p_no.
    gv_p_no = ceil( gv_menge1 / gv_lhmg1 ).
    p_no = gv_p_no.
  ENDIF.
*&---------------------------------------------------------------------*
*&      Form  AUTHORISATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorisation .

  SELECT werks FROM t001w INTO TABLE gt_t001w WHERE werks EQ p_dwerk.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'ZSBOX_WERK'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.

ENDFORM.
