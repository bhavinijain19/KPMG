*************************************************************************************
*Object Name              : ZRM_GOODS_ISSUE.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Module pool to Scan RM boxes and post , confirm TO for
*                           the same.
*************************************************************************************
PROGRAM zrm_goods_issue.
INCLUDE zi_goods_issue_top.             "data declaration.

INCLUDE zrm_goods_issue_status_forms.
*********************************************************
*Start of Selection event.
*********************************************************
START-OF-SELECTION.

INCLUDE zrm_goods_issue_itabo01_9001.
