*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Khushbu Garg
*&  Functional Consultant   :    Sachin
*&  Requirement             :    TO Generation Program
*&  Revieved By             :    Sneha Sharma
*&  Request                 :    DEVK912071
*&---------------------------------------------------------------------*
*& Report  ZWM_TO_POST
*&
*&---------------------------------------------------------------------*
REPORT zwm_to_post.

INCLUDE zwm_to_post_top.
INCLUDE zwm_to_post_scr.

initialization.
execute = 1.

START-OF-SELECTION.
*CLEAR it_ltbk.
*
*  SELECT lgnum
*          tbnum
*          statu
*          trart
*          mblnr
*          FROM ltbk
*          INTO TABLE it_ltbk
*          WHERE lgnum = p_lgnum AND
*                tbnum = p_tbnum AND
*                ( statu = 'T' OR statu = ' ' ).
*
*  IF sy-subrc EQ 0.
*    SORT it_ltbk BY lgnum .
*  ENDIF.
*
*  CLEAR it_ltbp.
*
*  SELECT lgnum
*        tbnum
*        tbpos
*        elikz
*        matnr
*        werks
*        charg
*        menge
*        meins
*        tamen
*        mbpos
*        lgort
*        FROM ltbp
*        INTO TABLE it_ltbp
*        WHERE lgnum = p_lgnum AND
*              tbnum = p_tbnum AND
*              elikz = ' '.
*
*  IF sy-subrc EQ 0.
*    SORT it_ltbp BY lgnum tbnum.
*  ENDIF.
*
*  IF it_ltbp IS NOT INITIAL.
*
*    CLEAR it_zwm_picklist.
*
*    SELECT werks
*           lgort
*           lgnum
*           lgtyp
*           lgber
*           FROM zwm_picklist
*           INTO TABLE it_zwm_picklist
*           FOR ALL ENTRIES IN it_ltbp
*           WHERE lgnum = p_lgnum AND
*                 werks = it_ltbp-werks AND
*                 lgort = it_ltbp-lgort .
*
*    IF sy-subrc EQ 0.
*      SORT it_zwm_picklist BY werks.
*    ENDIF.
*
*    CLEAR it_makt.
*
*    SELECT matnr
*           maktx
*           FROM makt
*           INTO TABLE it_makt
*           FOR ALL ENTRIES IN it_ltbp
*           WHERE matnr = it_ltbp-matnr.
*
*    IF sy-subrc EQ 0.
*      SORT it_makt BY matnr.
*    ENDIF.
*
*  ENDIF.
*
*  CLEAR it_lagp.
*
*  SELECT lgnum
*         lgtyp
*         lgpla
*         FROM lagp
*         INTO TABLE it_lagp
*     FOR ALL ENTRIES IN it_zwm_picklist
*         WHERE lgnum = p_lgnum AND lgpla NE 'SCHROTT' and lgtyp = it_zwm_picklist-lgtyp.
*
*  IF sy-subrc EQ 0.
*    SORT it_lagp BY lgnum.
*  ENDIF.
*
*  IF it_lagp IS NOT INITIAL.
*    CLEAR it_lein.
*
*    SELECT lenum
*           lgnum
*           lgtyp
*           FROM lein
*           INTO TABLE it_lein
*           FOR ALL ENTRIES IN it_lagp
*           WHERE lgnum = p_lgnum  AND
*                 lgtyp = it_lagp-lgtyp.
*
*    IF sy-subrc EQ 0.
*      SORT it_lein BY lenum.
*    ENDIF.
*  ENDIF.
*
**  clear it_zmm_su_number.
*
**  SELECT zsu_no
**         lhmg1
**         lety1
**         FROM zmm_su_number
**         INTO TABLE it_zmm_su_number.
***         FOR ALL ENTRIES IN it_lein
***         WHERE zsu_no = it_lein-lenum+0(10).
**
**  IF sy-subrc EQ 0.
**    SORT  it_zmm_su_number BY zsu_no.
**  ENDIF.
*
*  CLEAR wa_ltbp.
*







  CLEAR it_ltbk.
  SELECT lgnum
          tbnum
          statu
          trart
          mblnr
          FROM ltbk
          INTO TABLE it_ltbk
          WHERE lgnum = p_lgnum AND
                tbnum = p_tbnum AND
                ( statu = 'T' OR statu = ' ' ).
  IF sy-subrc EQ 0.
    SORT it_ltbk BY lgnum .
  ENDIF.
  CLEAR it_ltbp.
  SELECT lgnum
        tbnum
        tbpos
        elikz
        matnr
        werks
        charg
        menge
        meins
        tamen
        mbpos
        lgort
        FROM ltbp
        INTO TABLE it_ltbp
        WHERE lgnum = p_lgnum AND
              tbnum = p_tbnum AND
              elikz = ' '.
  IF sy-subrc EQ 0.
    SORT it_ltbp BY lgnum tbnum.
  ENDIF.
  IF it_ltbp IS NOT INITIAL.
*    CLEAR it_makt.
    SELECT matnr
           maktx
           FROM makt
           INTO TABLE it_makt
           FOR ALL ENTRIES IN it_ltbp
           WHERE matnr = it_ltbp-matnr.
    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.

    DATA it_ltbp_temp TYPE STANDARD TABLE OF ty_ltbp.
    it_ltbp_temp = it_ltbp.
    SORT it_ltbp_temp BY lgnum tbnum tbpos.
    DELETE ADJACENT DUPLICATES FROM it_ltbp_temp COMPARING lgnum tbnum tbpos.
    SELECT
     matnr lgnum lety1
      FROM mlgn
      INTO TABLE it_mlgn
      FOR ALL ENTRIES IN it_ltbp_temp
      WHERE matnr EQ it_ltbp_temp-matnr
      AND   lgnum EQ p_lgnum.

*    CLEAR it_zwm_picklist.
    SELECT werks
           lgort
           lgnum
           lgtyp
           lgber
           FROM zwm_picklist
           INTO TABLE it_zwm_picklist
           FOR ALL ENTRIES IN it_ltbp
           WHERE lgnum = p_lgnum AND
                 werks = it_ltbp-werks AND
                 lgort = it_ltbp-lgort .
    IF sy-subrc EQ 0.
      SORT it_zwm_picklist BY werks.
      SELECT lgnum
      lgtyp
      lgpla
       kzler
      FROM lagp
      INTO TABLE it_lagp
     FOR ALL ENTRIES IN it_zwm_picklist
      WHERE ( lgnum = p_lgnum AND lgpla NE 'SCHROTT' AND lgtyp = it_zwm_picklist-lgtyp )
        AND    ( kzler = space OR kzler = 'X' ) .
      IF sy-subrc EQ 0.
        SORT it_lagp BY lgnum.
        IF it_lagp IS NOT INITIAL.
*          CLEAR it_lein.
          SELECT lenum
                 lgnum
                 lgtyp
                 FROM lein
                 INTO TABLE it_lein
                 FOR ALL ENTRIES IN it_lagp
                 WHERE lgnum = p_lgnum  AND
                       lgtyp = it_lagp-lgtyp.
          IF sy-subrc EQ 0.
            SORT it_lein BY lenum.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

  CLEAR wa_ltbp.
  LOOP AT it_ltbp INTO wa_ltbp WHERE lgnum = p_lgnum AND
                                             tbnum = p_tbnum .


    wa_final-tbpos = wa_ltbp-tbpos.
    wa_final-matnr = wa_ltbp-matnr.
    wa_final-mbpos = wa_ltbp-mbpos.
    wa_final-werks = wa_ltbp-werks.
    wa_final-lgort = wa_ltbp-lgort.
    wa_final-charg = wa_ltbp-charg.
    wa_final-meins =  wa_ltbp-meins.
    wa_final-menge = wa_ltbp-menge.
    wa_final-tamen = wa_ltbp-menge - wa_ltbp-tamen.

    READ TABLE it_mlgn INTO wa_mlgn WITH KEY matnr = wa_ltbp-matnr lgnum = p_lgnum.
    IF sy-subrc EQ 0.
      wa_final-lety1 = wa_mlgn-lety1.
    ENDIF.

    CLEAR wa_makt.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_ltbp-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-maktx = wa_makt-maktx.
    ENDIF.

    CLEAR wa_ltbk.
    READ TABLE it_ltbk INTO wa_ltbk WITH KEY lgnum = p_lgnum
                                             tbnum = p_tbnum BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-tbnum = wa_ltbk-tbnum.
      wa_final-mblnr = wa_ltbk-mblnr.
      wa_final-trart = wa_ltbk-trart.
    ENDIF.
*clear wa_zwm_picklist.
* READ TABLE it_zwm_picklist INTO wa_zwm_picklist WITH KEY werks = wa_ltbp-werks
*                                                                     lgnum = p_lgnum.
* if sy-subrc = 0.
*    CLEAR wa_lagp.
*    read table it_lagp into wa_lagp with key lgnum = p_lgnum lgtyp = wa_zwm_picklist-lgtyp.
*    if sy-subrc = 0.
*      wa_final-lgpla = wa_lagp-lgpla.
*      endif.
*      endif.

    wa_final-zsu_no = '0'.
    wa_final-zsu_no1 = '0'.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = wa_final-zsu_no
      IMPORTING
        output = wa_final-zsu_no.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = wa_final-zsu_no1
      IMPORTING
        output = wa_final-zsu_no1.

    APPEND wa_final TO it_final.
    CLEAR wa_final.
  ENDLOOP.

  PERFORM build_alv.
  PERFORM alv_report_layout.
  PERFORM set_pf_status USING rt_extab .
  PERFORM frm_usercommand USING r_ucomm rs_selfield.
  PERFORM display_alv.

**&      Form  P_LGNUM
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
FORM p_lgnum .

  CLEAR p_lgnum.
  CLEAR it_t300t.

  SELECT lgnum
         lnumt
         FROM t300t
         INTO TABLE it_t300t
         WHERE spras = 'EN'.


  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
*     DDIC_STRUCTURE  = ' '
      retfield        = 'LGNUM'
*     PVALKEY         = ' '
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'P_LGNUM'
*     STEPL           = 0
*     WINDOW_TITLE    =
*     VALUE           = ' '
      value_org       = 'S'
*     MULTIPLE_CHOICE = ' '
*     DISPLAY         = ' '
*     CALLBACK_PROGRAM       = ' '
*     CALLBACK_FORM   = ' '
*     CALLBACK_METHOD =
*     MARK_TAB        =
* IMPORTING
*     USER_RESET      =
    TABLES
      value_tab       = it_t300t
*     FIELD_TAB       =
*     RETURN_TAB      =
*     DYNPFLD_MAPPING =
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  P_TBNUM
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
FORM p_tbnum .

  CLEAR p_tbnum.

  REFRESH gt_dynpfields.
  CLEAR gwa_dynpfields.
  gwa_dynpfields-fieldname = 'P_LGNUM'.
  APPEND gwa_dynpfields TO gt_dynpfields.

  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
*     TRANSLATE_TO_UPPER                   = ' '
*     REQUEST    = ' '
*     PERFORM_CONVERSION_EXITS             = ' '
*     PERFORM_INPUT_CONVERSION             = ' '
*     DETERMINE_LOOP_INDEX                 = ' '
*     START_SEARCH_IN_CURRENT_SCREEN       = ' '
*     START_SEARCH_IN_MAIN_SCREEN          = ' '
*     START_SEARCH_IN_STACKED_SCREEN       = ' '
*     START_SEARCH_ON_SCR_STACKPOS         = ' '
*     SEARCH_OWN_SUBSCREENS_FIRST          = ' '
*     SEARCHPATH_OF_SUBSCREEN_AREAS        = ' '
    TABLES
      dynpfields = gt_dynpfields
*   EXCEPTIONS
*     INVALID_ABAPWORKAREA                 = 1
*     INVALID_DYNPROFIELD                  = 2
*     INVALID_DYNPRONAME                   = 3
*     INVALID_DYNPRONUMMER                 = 4
*     INVALID_REQUEST                      = 5
*     NO_FIELDDESCRIPTION                  = 6
*     INVALID_PARAMETER                    = 7
*     UNDEFIND_ERROR                       = 8
*     DOUBLE_CONVERSION                    = 9
*     STEPL_NOT_FOUND                      = 10
*     OTHERS     = 11
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CLEAR gv_lbnum.
  READ TABLE gt_dynpfields INTO gwa_dynpfields
  WITH KEY fieldname = 'P_LGNUM'.
  IF sy-subrc = 0.
    gv_lbnum = gwa_dynpfields-fieldvalue.
  ENDIF.

  CLEAR it_ltbk1.

  SELECT lgnum
         tbnum
         FROM ltbk
         INTO  TABLE it_ltbk1
         WHERE lgnum = gv_lbnum AND
                ( statu = 'T' OR statu = ' ' ).

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
*     DDIC_STRUCTURE  = ' '
      retfield        = 'TBNUM'
*     PVALKEY         = ' '
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'P_TBNUM'
*     STEPL           = 0
*     WINDOW_TITLE    =
*     VALUE           = ' '
      value_org       = 'S'
*     MULTIPLE_CHOICE = ' '
*     DISPLAY         = ' '
*     CALLBACK_PROGRAM       = ' '
*     CALLBACK_FORM   = ' '
*     CALLBACK_METHOD =
*     MARK_TAB        =
*   IMPORTING
*     USER_RESET      =
    TABLES
      value_tab       = it_ltbk1
*     FIELD_TAB       =
*     RETURN_TAB      =
*     DYNPFLD_MAPPING =
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_alv .

  FREE it_fldcat[].
  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'CHECKBOX'.
  <fs_fldcat>-coltext   = text-016."TR Number
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-checkbox = 'X'.
  <fs_fldcat>-icon = 'X'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TBNUM'.
  <fs_fldcat>-coltext   = text-001."TR Number
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TBPOS'.
  <fs_fldcat>-coltext   = text-002. "Line Item
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TRART'.
  <fs_fldcat>-coltext   = text-003."Ship Type
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MATNR'.
  <fs_fldcat>-coltext   = text-004."Material Code
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MAKTX'.
  <fs_fldcat>-coltext   = text-005."Material Description
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MBLNR'.
  <fs_fldcat>-coltext   = text-006."Material Doc
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MBPOS'.
  <fs_fldcat>-coltext   = text-007."Material Doc Line Item
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'WERKS'.
  <fs_fldcat>-coltext   = text-008."Plant
  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'T001W'.
  <fs_fldcat>-ref_field = 'WERKS'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'LGORT'.
  <fs_fldcat>-coltext   = text-009."Receiving Storage Location
  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'T001L'.
  <fs_fldcat>-ref_field = 'LGORT'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'CHARG'.
  <fs_fldcat>-coltext   = text-010."Batch Number
  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MENGE'.
  <fs_fldcat>-coltext   = text-011."TR Quantity
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'MEINS'.
  <fs_fldcat>-coltext   = text-012."UoM
  <fs_fldcat>-tabname     = 'IT_FINAL'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'TAMEN'.
  <fs_fldcat>-coltext   = text-014."Open Quantity
  <fs_fldcat>-tabname     = 'IT_FINAL'.

*  UNASSIGN <fs_fldcat>.
*  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
*  <fs_fldcat>-fieldname   = 'TAMEN1'.
*  <fs_fldcat>-coltext   = text-015."Selected Quantity
*  <fs_fldcat>-tabname     = 'IT_FINAL'.
*  <fs_fldcat>-edit = 'X'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'LGPLA'.
  <fs_fldcat>-coltext   = text-013."Bin Location
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-ref_table = 'LAGP'.
  <fs_fldcat>-ref_field = 'LGPLA'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'ZSU_NO'.
  <fs_fldcat>-coltext   = text-017."From
  <fs_fldcat>-outputlen = '10'.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'ZMM_SU_NUMBER'.
  <fs_fldcat>-ref_field = 'ZSU_NO'.

  UNASSIGN <fs_fldcat>.
  APPEND INITIAL LINE TO it_fldcat ASSIGNING <fs_fldcat>.
  <fs_fldcat>-fieldname   = 'ZSU_NO1'.
  <fs_fldcat>-coltext   = text-018."To
  <fs_fldcat>-outputlen = '10'.
  <fs_fldcat>-tabname     = 'IT_FINAL'.
  <fs_fldcat>-edit = 'X'.
  <fs_fldcat>-f4availabl = 'X'.
  <fs_fldcat>-ref_table = 'ZMM_SU_NUMBER'.
  <fs_fldcat>-ref_field = 'ZSU_NO'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv .
  IF it_final IS NOT INITIAL.

    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
      EXPORTING
*       I_INTERFACE_CHECK        = ' '
*       I_BYPASSING_BUFFER       =
*       I_BUFFER_ACTIVE          =
        i_callback_program       = sy-repid
        i_callback_pf_status_set = 'SET_PF_STATUS'
        i_callback_user_command  = 'FRM_USERCOMMAND'
*       I_CALLBACK_TOP_OF_PAGE   = ' '
*       I_CALLBACK_HTML_TOP_OF_PAGE       = ' '
*       I_CALLBACK_HTML_END_OF_LIST       = ' '
*       I_STRUCTURE_NAME         =
*       I_BACKGROUND_ID          = ' '
*       I_GRID_TITLE             =
*       I_GRID_SETTINGS          =
        is_layout_lvc            = it_layout
        it_fieldcat_lvc          = it_fldcat[]
*       IT_EXCLUDING             =
*       IT_SPECIAL_GROUPS_LVC    =
*       IT_SORT_LVC              =
*       IT_FILTER_LVC            =
*       IT_HYPERLINK             =
*       IS_SEL_HIDE              =
*       I_DEFAULT                = 'X'
        i_save                   = 'A'
*       IS_VARIANT               =
*       IT_EVENTS                =
*       IT_EVENT_EXIT            =
*       IS_PRINT_LVC             =
**       IS_REPREP_ID_LVC   =
*       I_SCREEN_START_COLUMN    = 0
*       I_SCREEN_START_LINE      = 0
*       I_SCREEN_END_COLUMN      = 0
*       I_SCREEN_END_LINE        = 0
*       I_HTML_HEIGHT_TOP        =
*       I_HTML_HEIGHT_END        =
*       IT_ALV_GRAPHICS          =
*       IT_EXCEPT_QINFO_LVC      =
*       IR_SALV_FULLSCREEN_ADAPTER        =
*                      IMPORTING
*       E_EXIT_CAUSED_BY_CALLER  =
*       ES_EXIT_CAUSED_BY_USER   =
      TABLES
        t_outtab                 = it_final[]
      EXCEPTIONS
        program_error            = 1
        OTHERS                   = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  TO_POST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  ALV_REPORT_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM alv_report_layout .

  it_layout-cwidth_opt = 'X'.
  it_layout-zebra = 'X'.
  it_layout-col_opt = 'X'.

ENDFORM.

FORM set_pf_status USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'ZSTANDARD'.

ENDFORM.

FORM frm_usercommand USING r_ucomm LIKE sy-ucomm
                           rs_selfield TYPE slis_selfield.
  CLEAR : flag_no,flag, counter.
  CASE r_ucomm.

    WHEN 'POST'.

      DATA: gd_repid LIKE sy-repid, "Exists
            ref_grid TYPE REF TO cl_gui_alv_grid.

      IF ref_grid IS INITIAL.
        CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
          IMPORTING
            e_grid = ref_grid.
      ENDIF.
      IF NOT ref_grid IS INITIAL.
        CALL METHOD ref_grid->check_changed_data .
      ENDIF.
************Checking the line item Start******
      gv_text = 'TO Numbers generated are '.
      gv_text1 = 'SU Numbers already used in line item '.
      gv_text2 = 'storage bin not found'.
      gv_text3 = 'Selected Quantity cannot be more than Open Quantity for item '.
      gv_text5 = 'Wrong SU entered'.
      CLEAR: it_zmm_su_number_temp,wa_final.
      LOOP AT it_final INTO wa_final WHERE checkbox = 'X'.
        CLEAR: s_number, s_number[],s_num1,s_num1[].
************************************storage bin validation***********
        IF wa_final-lgpla IS INITIAL.
          MESSAGE:'Storage bin cannot be empty ' TYPE 'E'.
          EXIT.
        ELSE.
          READ TABLE it_lagp INTO wa_lagp WITH KEY lgpla = wa_final-lgpla.
          IF wa_lagp IS INITIAL.
            CONCATENATE wa_final-lgpla gv_text2  INTO gv_text2 SEPARATED BY space.
            MESSAGE gv_text2 TYPE 'E'.
            return.
          ENDIF.
        ENDIF.
*************************************************************************
        IF wa_final-zsu_no IS INITIAL OR wa_final-zsu_no1 IS INITIAL.
          MESSAGE:'Please enter box number' TYPE 'E'.
          exit.
        ELSE.
          s_number-sign = 'I'.
          s_number-option = 'BT'.
          s_number-low = wa_final-zsu_no.
          s_number-high = wa_final-zsu_no1.
          APPEND s_number.

          SELECT zsu_no matnr werks charg lhmg1 lety1 FROM zmm_su_number
                                    INTO TABLE it_zmm_su_number
                                    WHERE matnr = wa_final-matnr
                                      AND werks = wa_final-werks
                                      AND charg = wa_final-charg
                                      AND zsu_no IN s_number.
          IF sy-subrc <> 0.
             flag_no = 'X'.
              CONCATENATE gv_text5 wa_final-tbpos INTO gv_text5 SEPARATED BY space.
*              exit.
            else.
            s_num1-sign = 'I'.
            s_num1-option = 'BT'.
            s_num1-low = s_number-low.
            s_num1-high = s_number-high.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = s_num1-low
              IMPORTING
                output = s_num1-low.

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = s_num1-high
              IMPORTING
                output = s_num1-high.
            APPEND s_num1.
            SELECT lenum lgnum FROM lein
                            INTO TABLE it_lein
                             WHERE lenum IN s_num1.
            IF sy-subrc = 0.
              flag = 'X'.
              CONCATENATE gv_text1 wa_final-tbpos INTO gv_text1 SEPARATED BY space.
*              exit.
            ELSE.
            ENDIF.
          ENDIF.
********************************checking duplicacy of SU Number********************************************************
          IF  counter = 1.
            it_zmm_su_number_temp = it_zmm_su_number.
          ELSE.
            LOOP AT it_zmm_su_number INTO wa_zmm_su_number.
              READ TABLE it_zmm_su_number_temp INTO wa_zmm_su_number_temp WITH KEY wa_zmm_su_number-zsu_no.
              IF wa_zmm_su_number_temp IS INITIAL.
                APPEND wa_zmm_su_number TO it_zmm_su_number_temp.
              ELSE.
                MESSAGE:'You have entered duplicate SU Numbers' TYPE 'E'.
                EXIT.
              ENDIF.
            ENDLOOP.
          ENDIF.
          counter = counter + 1.
********************************checking duplicacy of SU Number****************************************************
        ENDIF.
      ENDLOOP.
************Checking the line item End******
       IF flag_no = 'X'.
        MESSAGE gv_text5 TYPE 'E' DISPLAY LIKE 'I'.
        EXIT.
        endif.
      IF flag = 'X'.
        MESSAGE gv_text1 TYPE 'E' DISPLAY LIKE 'I'.
        EXIT.


***************************QTY CHECK******************************************************************
        CLEAR: flag_sum.
        LOOP AT it_final INTO wa_final  WHERE checkbox = 'X'.
          CLEAR:lhmg_sum,gv_zsu_no,it_zmm_su_number.
          SELECT zsu_no matnr werks charg lhmg1 lety1 FROM zmm_su_number INTO TABLE it_zmm_su_number
                     FOR ALL ENTRIES IN it_final WHERE ( zsu_no = it_final-zsu_no OR zsu_no = it_final-zsu_no1 )
                             AND matnr = it_final-matnr AND charg = it_final-charg AND werks = wa_final-werks.
          IF sy-subrc EQ 0.
            SORT  it_zmm_su_number BY zsu_no.
          ENDIF.
          gv_zsu_no = wa_final-zsu_no1 + 1.
          IF wa_final-zsu_no > wa_final-zsu_no1.
            gv_text4 =  'Lower limit cannot be greater than upper limit for SU Number'.
            CONCATENATE gv_text4 wa_final-tbpos INTO gv_text4 SEPARATED BY space.
            MESSAGE gv_text4 TYPE 'E'.
            EXIT.
          ENDIF.

          WHILE ( wa_final-zsu_no NE gv_zsu_no  ).
            READ TABLE it_zmm_su_number INTO wa_zmm_su_number WITH KEY zsu_no = wa_final-zsu_no matnr = wa_final-matnr
                                                                        charg = wa_final-charg werks = wa_final-werks.
            IF sy-subrc EQ 0.
              lhmg_sum = lhmg_sum + wa_zmm_su_number-lhmg1.
            ELSE.
              SELECT SINGLE zsu_no matnr werks charg lhmg1 INTO wa_zmm_su_number FROM zmm_su_number
                                          WHERE zsu_no = wa_final-zsu_no AND matnr = wa_final-matnr
                                          AND charg = wa_final-charg AND werks = wa_final-werks.
              IF sy-subrc EQ 0.
                lhmg_sum = lhmg_sum + wa_zmm_su_number-lhmg1.
              ENDIF.
            ENDIF.
            wa_final-zsu_no =  wa_final-zsu_no + 1.
          ENDWHILE.
          IF lhmg_sum > wa_final-tamen.
            CONCATENATE gv_text3 wa_final-tbpos INTO gv_text3 SEPARATED BY space.
            flag_sum = 1.
          ENDIF.
        ENDLOOP.
        IF flag_sum = 1.
          MESSAGE:gv_text3 TYPE 'E'.
          EXIT.
        ENDIF.
*******************************QTY CHECK******************************************************************************



      ELSE."perform TO creation
        CLEAR:wa_final,it_lein,it_zmm_su_number,gv_zsu_no.
        LOOP AT it_final INTO wa_final  WHERE checkbox = 'X'.
          CLEAR:lhmg_sum,it_trite,gv_zsu_no.
          SELECT zsu_no
                 matnr
                 werks
                 charg
                 lhmg1
                 lety1
                 FROM zmm_su_number
                 INTO TABLE it_zmm_su_number
                 FOR ALL ENTRIES IN it_final
                 WHERE ( zsu_no = it_final-zsu_no OR zsu_no = it_final-zsu_no1 )
                 AND matnr = it_final-matnr AND charg = it_final-charg AND werks = wa_final-werks.
          IF sy-subrc EQ 0.
            SORT  it_zmm_su_number BY zsu_no.
          ENDIF.

          gv_zsu_no = wa_final-zsu_no1 + 1.

          IF wa_final-zsu_no > wa_final-zsu_no1.
            MESSAGE 'Lower limit cannot be greater than upper limit for SU Number' TYPE 'E'.
          ENDIF.

          gv_typ = wa_final-zsu_no.
          gv_typ1 = wa_final-zsu_no1.

          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = gv_typ
            IMPORTING
              output = gv_typ.

          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = gv_typ1
            IMPORTING
              output = gv_typ1.

          WHILE ( wa_final-zsu_no NE gv_zsu_no  ).
            wa_trite-tbpos = wa_final-tbpos.
            wa_trite-altme = wa_final-meins.
            wa_trite-charg = wa_final-charg.

            CLEAR wa_zwm_picklist.
            READ TABLE it_zwm_picklist INTO wa_zwm_picklist WITH KEY werks = wa_final-werks
                                                                     lgort = wa_final-lgort
                                                                     lgnum = p_lgnum.
            IF sy-subrc EQ 0.
              wa_trite-nltyp = wa_zwm_picklist-lgtyp.
              wa_trite-nlber = wa_zwm_picklist-lgber .
              wa_trite-vltyp = wa_zwm_picklist-lgtyp.
              wa_trite-vlber = wa_zwm_picklist-lgber .
            ENDIF.
            wa_trite-nlpla = wa_final-lgpla.
            gv_typ = wa_final-zsu_no.

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = gv_typ
              IMPORTING
                output = gv_typ.

            wa_trite-nlenr = gv_typ.
            wa_ltap_vb-matnr = wa_final-matnr.
            wa_ltap_vb-werks = wa_final-werks.
            wa_ltap_vb-charg = wa_final-charg.
            wa_ltap_vb-vlpla = wa_final-lgpla.
            wa_ltap_vb-nlenr = gv_typ.

            CLEAR wa_zmm_su_number.
            READ TABLE it_zmm_su_number INTO wa_zmm_su_number WITH KEY zsu_no = wa_final-zsu_no
                                                                        matnr = wa_final-matnr
                                                                        charg = wa_final-charg
                                                                        werks = wa_final-werks.
            IF sy-subrc EQ 0.
              SELECT SINGLE lenum lgnum FROM lein INTO wa_lein WHERE lenum = wa_zmm_su_number-zsu_no.
              IF sy-subrc <> 0.
                wa_trite-letyp = wa_final-lety1 ."'BOX'.
                wa_ltap_vb-vistm = wa_zmm_su_number-lhmg1.  "wa_final-tamen1.
                wa_ltap_vb-nista = wa_zmm_su_number-lhmg1. "wa_final-tamen1.
                wa_ltap_vb-nistm = wa_zmm_su_number-lhmg1. "wa_final-tamen1.
                wa_trite-anfme = wa_zmm_su_number-lhmg1.
                wa_ltap_conf-nista = wa_zmm_su_number-lhmg1.
*                lhmg_sum = lhmg_sum + wa_zmm_su_number-lhmg1.
              ENDIF.
            ELSE.
              SELECT SINGLE zsu_no matnr werks charg lhmg1
                     INTO wa_zmm_su_number
                     FROM zmm_su_number
                     WHERE zsu_no = wa_final-zsu_no AND matnr = wa_final-matnr AND charg = wa_final-charg AND werks = wa_final-werks.
              IF sy-subrc EQ 0.
                SELECT SINGLE lenum lgnum FROM lein INTO wa_lein WHERE lenum = wa_zmm_su_number-zsu_no.
                IF sy-subrc <> 0.
                  wa_trite-letyp = wa_final-lety1 ."'BOX'.
                  wa_ltap_vb-vistm = wa_zmm_su_number-lhmg1.  "wa_final-tamen1.
                  wa_ltap_vb-nista = wa_zmm_su_number-lhmg1. "wa_final-tamen1.
                  wa_ltap_vb-nistm = wa_zmm_su_number-lhmg1. "wa_final-tamen1.
                  wa_trite-anfme = wa_zmm_su_number-lhmg1.
                  wa_ltap_conf-nista = wa_zmm_su_number-lhmg1.
                ENDIF.
              ENDIF.
            ENDIF.

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = wa_final-zsu_no
              IMPORTING
                output = wa_final-zsu_no.

            row = row + 1.
            wa_ltap_conf-tapos = row.
            wa_ltap_conf-altme = wa_final-meins.
            wa_ltap_conf-charg = wa_final-charg.
            wa_ltap_conf-sonum = wa_final-zsu_no.
            APPEND wa_ltap_conf TO it_ltap_conf.

            APPEND wa_trite TO it_trite.
            CLEAR wa_trite.
            wa_final-zsu_no =  wa_final-zsu_no + 1.
          ENDWHILE.

          CALL FUNCTION 'L_TO_CREATE_TR'
            EXPORTING
              i_lgnum                        = p_lgnum  "'WS1' "
              i_tbnum                        = p_tbnum "'1000000015'
              i_commit_work                  = 'X'
              i_bname                        = sy-uname
              i_solex                        = wa_zmm_su_number-lhmg1 "wa_final-tamen1 "'10' "
              it_trite                       = it_trite
            IMPORTING
              e_tanum                        = gv_tanum
              e_teilk                        = gv_teilv
            TABLES
              t_ltak                         = it_ltak
              t_ltap_vb                      = it_ltap_vb
*             T_WMGRP_MSG                    =
            EXCEPTIONS
              foreign_lock                   = 1
              qm_relevant                    = 2
              tr_completed                   = 3
              xfeld_wrong                    = 4
              ldest_wrong                    = 5
              drukz_wrong                    = 6
              tr_wrong                       = 7
              squit_forbidden                = 8
              no_to_created                  = 9
              update_without_commit          = 10
              no_authority                   = 11
              preallocated_stock             = 12
              partial_transfer_req_forbidden = 13
              input_error                    = 14
              OTHERS                         = 15.

          IF sy-subrc = 0.
            CLEAR wa_ltap_conf.
            wa_ltap_conf-tanum = gv_tanum.
            MODIFY it_ltap_conf FROM  wa_ltap_conf TRANSPORTING tanum WHERE altme = wa_final-meins.
***********************************************************
*BDC for confirming created TO.
***********************************************************
            PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
            PERFORM bdc_field       USING 'BDC_CURSOR'
                                          'LTAK-TANUM'.
            PERFORM bdc_field       USING 'BDC_OKCODE'
                                          '/00'.
            PERFORM bdc_field       USING 'LTAK-TANUM'
                                           gv_tanum.
            PERFORM bdc_field       USING 'LTAK-LGNUM'
                                           p_lgnum.

            PERFORM bdc_dynpro      USING 'SAPML03T' '0114'.
            PERFORM bdc_field       USING 'BDC_OKCODE'
                                          '=QU'.
            PERFORM bdc_field       USING 'BDC_OKCODE'
                                          '=BU'.

            CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.

            CONCATENATE gv_text gv_tanum INTO gv_text SEPARATED BY space.
          ENDIF.
          CLEAR:wa_final,wa_ltap_vb,wa_ltap_conf,wa_trite.
          FREE: it_ltap_conf,it_ltap_vb,it_trite,it_ltak,it_bdcdata.
        ENDLOOP.

      ENDIF.

    WHEN 'ADD'.
      IF ref_grid IS INITIAL.
        CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
          IMPORTING
            e_grid = ref_grid.
      ENDIF.
      IF NOT ref_grid IS INITIAL.
        CALL METHOD ref_grid->check_changed_data .
      ENDIF.
      LOOP AT it_final INTO wa_final  WHERE checkbox = 'X'.
        MOVE-CORRESPONDING wa_final TO wa_copy.
        wa_copy-checkbox = ' '.
        APPEND wa_copy TO it_final.
        CLEAR wa_copy.
      ENDLOOP.
      SORT it_final BY tbpos ASCENDING.
      PERFORM display_alv.

  ENDCASE.
  if gv_tanum is NOT INITIAL.
  MESSAGE gv_text TYPE 'I' DISPLAY LIKE 'S'.
  clear : it_final,it_ltbp,it_ltap_conf,it_ltak,gv_text,gv_text1,gv_text3,gv_text4,it_mlgn,wa_final,wa_copy,
          wa_lein,wa_ltbk,wa_ltbk1,wa_ltap_vb,wa_ltbp,wa_makt,wa_trite,wa_lagp.
  leave to SCREEN 0.
  endif.
*  LEAVE LIST-PROCESSING.
ENDFORM.

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
