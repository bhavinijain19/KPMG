*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_LOAD_SLOCTOP.                 " Global Declarations
  INCLUDE LZMM_LOAD_SLOCUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_LOAD_SLOCF...                 " Subroutines
* INCLUDE LZMM_LOAD_SLOCO...                 " PBO-Modules
* INCLUDE LZMM_LOAD_SLOCI...                 " PAI-Modules
* INCLUDE LZMM_LOAD_SLOCE...                 " Events
* INCLUDE LZMM_LOAD_SLOCP...                 " Local class implement.
* INCLUDE LZMM_LOAD_SLOCT99.                 " ABAP Unit tests
  INCLUDE LZMM_LOAD_SLOCF00                       . " subprograms
  INCLUDE LZMM_LOAD_SLOCI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
