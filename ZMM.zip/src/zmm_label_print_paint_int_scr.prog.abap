*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_SCR
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_lenum FOR lqua-lenum OBLIGATORY.
PARAMETERS :  p_werks TYPE lqua-werks OBLIGATORY,
              p_print TYPE lvs_lhmng1.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF  BLOCK b2 WITH FRAME TITLE text-002.
PARAMETERS: rad1 RADIOBUTTON GROUP r1 USER-COMMAND abc,
            rad2 RADIOBUTTON GROUP r1,
            rad3 radiobutton group r1,
            rad4 radiobutton group r1.
SELECTION-SCREEN END OF BLOCK b2.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_lenum-low.
  PERFORM zsu_nof4help.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_lenum-high.
  PERFORM zsu_nof4help.


AT SELECTION-SCREEN ON p_print.
  IF s_lenum-high IS NOT INITIAL.
    p_print = ( s_lenum-high -  s_lenum-low ) + 1.
  ELSEIF s_lenum-high IS INITIAL .
    s_lenum-low  = 0.
    p_print = ( s_lenum-high -  s_lenum-low ) + 1.
  ENDIF.

AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-name = 'P_PRINT'.
      screen-input = 0.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.
