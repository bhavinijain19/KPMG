*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZWM_PICKLISTTOP.                  " Global Data
  INCLUDE LZWM_PICKLISTUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZWM_PICKLISTF...                  " Subroutines
* INCLUDE LZWM_PICKLISTO...                  " PBO-Modules
* INCLUDE LZWM_PICKLISTI...                  " PAI-Modules
* INCLUDE LZWM_PICKLISTE...                  " Events
* INCLUDE LZWM_PICKLISTP...                  " Local class implement.
* INCLUDE LZWM_PICKLISTT99.                  " ABAP Unit tests
  INCLUDE LZWM_PICKLISTF00                        . " subprograms
  INCLUDE LZWM_PICKLISTI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
