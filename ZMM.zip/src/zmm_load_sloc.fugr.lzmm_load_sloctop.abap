FUNCTION-POOL ZMM_LOAD_SLOC              MESSAGE-ID SV.

* INCLUDE LZMM_LOAD_SLOCD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_LOAD_SLOCT00                       . "view rel. data dcl.
