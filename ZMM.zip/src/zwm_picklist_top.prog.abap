*&---------------------------------------------------------------------*
*&  Include           ZWM_PICKLIST_TOP
*&---------------------------------------------------------------------*
DATA : p_vbeln TYPE likp-vbeln.

TYPES : BEGIN OF t_vepo,
          posnr TYPE vepo-posnr,
          vemng TYPE vepo-vemng,
          venum TYPE vepo-venum,
          vbeln TYPE vepo-vbeln,
          matnr TYPE vepo-matnr,
          maktx TYPE makt-maktx,
        END OF t_vepo.
DATA : wa_vepo TYPE t_vepo.
DATA : it_vepo TYPE STANDARD TABLE OF t_vepo.

TYPES : BEGIN OF t_lips,
          vbeln TYPE vepo-vbeln,
          posnr TYPE vepo-posnr,
          lfimg TYPE lips-lfimg,
          meins TYPE lips-meins,
          brgew TYPE lips-brgew, "Added for Gross Weight by Carina Jose on 08.10.2020
          arktx TYPE lips-arktx,
          matnr TYPE lips-matnr,
          charg TYPE lips-charg,
          lgort TYPE lips-lgort, "MOD1
          vgpos TYPE vgpos,
          uecha TYPE uecha,           "chnages made on 12.04.2019
          lgnum TYPE lips-lgnum,      "Added by Srimathi
        END OF t_lips.
DATA : wa_lips TYPE t_lips.
DATA : it_lips TYPE STANDARD TABLE OF t_lips.

TYPES : BEGIN OF t_item,
          posnr   TYPE vepo-posnr,
          vemng   TYPE vepo-vemng,
          key(70),
          venum   TYPE vepo-venum,
          vbeln   TYPE vepo-vbeln,
          matnr   TYPE vepo-matnr,
          maktx   TYPE makt-maktx,
          vbelv   TYPE vbfa-vbelv,
          lfimg   TYPE lips-lfimg,
          meins   TYPE lips-meins,
          exidv   TYPE vekp-exidv,
          charg   TYPE lips-charg,
          lgort   TYPE lips-lgort, "MOD1
          uecha   TYPE uecha,
          vgpos   TYPE vgpos,
          brgew   TYPE lips-brgew, "Added for Gross Weight by Carina Jose on 08.10.2020
          hsdat   TYPE mcha-hsdat,
          lgnum   TYPE lips-lgnum, "added by srimathi
        END OF t_item.
DATA : wa_item TYPE t_item.
DATA : it_item TYPE STANDARD TABLE OF t_item.
DATA : wa_item1 TYPE t_item.
DATA : it_item1 TYPE STANDARD TABLE OF t_item.

TYPES: BEGIN OF ty_article,
         type TYPE lvs_letyp1,
         qnty TYPE lfimg,
       END OF ty_article.

DATA: ls_article TYPE ty_article,
      lt_article TYPE STANDARD TABLE OF ty_article.

FIELD-SYMBOLS: <fs_article> LIKE LINE OF lt_article.

*******************
TYPES: BEGIN OF ty_mcha,
         matnr TYPE mcha-matnr,
         charg TYPE mcha-charg,
         hsdat TYPE mcha-hsdat,
       END OF ty_mcha.
DATA: it_mcha TYPE STANDARD TABLE OF ty_mcha,
      wa_mcha TYPE ty_mcha.
*********

TYPES : BEGIN OF t_mvke,
          matnr TYPE vepo-matnr,
*          SCMNG TYPE MVKE-SCMNG,
          aumng TYPE mvke-aumng,
        END OF t_mvke.
DATA : wa_mvke TYPE t_mvke.
DATA : it_mvke TYPE STANDARD TABLE OF t_mvke.

TYPES : BEGIN OF t_header,
          from                  TYPE vepo-venum,
          to                    TYPE vepo-venum,
          shipto_name1(40),
          shipto_street(60),
          shipto_house_num1(10),
          shipto_house_num2(10),
          shipto_str_suppl1(40),
          shipto_str_suppl2(40),
          shipto_str_suppl3(40),
          shipto_city1(40),
          shipto_city2(40),
          shipto_post_code1(10),
          shipto_region(10),
          shipto_country(10),
          plant_name1(40),
          plant_street(60),
          plant_house_num1(10),
          plant_house_num2(10),
          plant_str_suppl1(40),
          plant_str_suppl2(40),
          plant_str_suppl3(40),
          plant_city1(40),
          plant_city2(40),
          plant_post_code1(10),
          plant_region(10),
          plant_country(10),
          soldto_name1(40),
          soldto_street(60),
          soldto_house_num1(10),
          soldto_house_num2(10),
          soldto_str_suppl1(40),
          soldto_str_suppl2(40),
          soldto_str_suppl3(40),
          soldto_city1(40),
          soldto_city2(40),
          soldto_post_code1(10),
          soldto_region(10),
          soldto_country(10),
*          remarks(200),
        END OF t_header.
DATA : wa_header TYPE t_header.
DATA : it_header TYPE STANDARD TABLE OF t_header.

TYPES : BEGIN OF t_headerf,
          vbeln               TYPE likp-vbeln,
          from                TYPE vekp-exidv,
          to                  TYPE vekp-exidv,
          shipto_address(200),
          plant_address(200),
          shipto_name(80),
          plant_name(40),
          shipto_state(80),
          plant_tel(30),
          plant_fax(30),
          total_box           TYPE likp-anzpk,
          plant_city(40),
          transporter(70),
          shipto_city(40),
          telno               TYPE adrc-tel_number,
          shipto_ecc(40),
          shipto_range(40),
          shipto_div(40),
          shipto_cst(40),
          salesord            TYPE lips-vgbel,
          soldto_name(80),
          soldto_state(80),
          soldto_address(200),
          deldate(10),
          totbox              TYPE lfimg,
          article(30),                                         "added by srimathi
          box(30),                                         "added by srimathi
          drum(30),                                         "added by srimathi
          bucket(30),                                         "added by srimathi
        END OF t_headerf.
DATA : wa_headerf TYPE t_headerf.
*DATA : wa_headerf TYPE zwa_pickslipheader.   "Changed on 17.02.2026
DATA : it_headerf TYPE STANDARD TABLE OF t_headerf.
*DATA : it_headerf TYPE STANDARD TABLE OF zwa_pickslipheader.  "Changed on 17.02.2026

TYPES : BEGIN OF t_final,
          id           TYPE int1, "
*          posnr type posnr_vl,
          matnr        TYPE matnr,
          maktx        TYPE maktx,
          vemng        TYPE vemng,
*          LFIMG        TYPE I,
          lfimg        TYPE lfimg,
          meins        TYPE meins,
          vbelv        TYPE vbelv,
          fullbox(50),
          loosebox(50),
          fullboxqty   TYPE i,
          looseboxqty  TYPE i,
          totboxes     TYPE i,
          totfullbox   TYPE i,
          totloosebox  TYPE i,
          totbox       TYPE lfimg,
          totqty       TYPE scmng,
          bismt        TYPE mara-bismt,
          charg        TYPE lips-charg,
*          lgpla(500)   TYPE  c,
          lgpla        TYPE  char200,
          uecha        TYPE  char6,
          vgpos        TYPE   char6,
          brgew        TYPE lips-brgew, "Added for Gross Weight by Carina Jose on 08.10.2020
          hsdat        TYPE mcha-hsdat,
        END OF t_final.

*MOD1
TYPES : BEGIN OF ty_lqua,
          lgnum	TYPE lgnum,
          matnr	TYPE matnr,
          werks	TYPE werks_d,
          charg	TYPE charg_d,
          lgtyp	TYPE lgtyp,
          lgpla	TYPE lgpla,
          verme	TYPE lqua_verme,
          lgort	TYPE lgort_d,
          lenum TYPE lenum,   "Added by Srimathi
        END OF ty_lqua,

        BEGIN OF ty_zwm_picklist,
          werks TYPE  werks_d,
          lgort	TYPE lgort_d,
          lgnum	TYPE lgnum,
          lgtyp	TYPE lgtyp,
          lgber	TYPE lgber,
        END OF ty_zwm_picklist.



DATA : it_lqua         TYPE STANDARD TABLE OF ty_lqua,
       wa_lqua         TYPE ty_lqua,
       it_lqua_temp    TYPE STANDARD TABLE OF ty_lqua,
       wa_lqua_temp    TYPE ty_lqua,
       it_zwm_picklist TYPE STANDARD TABLE OF ty_zwm_picklist,
       wa_zwm_picklist TYPE ty_zwm_picklist,
       lt_ltap         TYPE STANDARD TABLE OF ltap,
       lt_mlgn         TYPE STANDARD TABLE OF mlgn,
       ls_ltap         TYPE ltap,
       ls_mlgn         TYPE mlgn.
*MOD1
DATA : wa_final TYPE t_final.
*DATA : wa_final TYPE zwm_picklist1.  "Changed on 17.02.2026 UDAYABAP03
DATA : it_final TYPE STANDARD TABLE OF t_final.
*DATA : it_final TYPE STANDARD TABLE OF zwm_picklist1.  "Changed on 17.02.2026 UDAYABAP03

DATA : wa_xvbplp TYPE vbplp.
DATA : v_venum TYPE vepo-venum.
DATA : v_exidv TYPE vekp-exidv.
DATA : v_vemng TYPE vepo-vemng.
DATA : v_finbox TYPE vepo-vemng.
DATA : v_id TYPE i.
DATA : v_totbox TYPE i.
DATA : v_first TYPE venum.
DATA : v_last TYPE venum.
DATA : flag TYPE i.
DATA : flag1 TYPE i.
DATA : v_matnr TYPE vepo-matnr.
DATA : v_maktx TYPE vepo-matnr.
DATA : v_lfimg TYPE lfimg.
DATA : v_meins TYPE meins.
DATA : v_vbelv TYPE vbelv.
DATA : v_fm_name TYPE    rs38l_fnam.
DATA : v_kunnr TYPE vbrk-kunrg.
DATA : v_kunnr1 TYPE vbrk-kunrg.
DATA : v_kunnr2 TYPE vbrk-kunrg.
DATA : v_adrnr TYPE kna1-adrnr.
DATA : v_vbeln TYPE vbrk-vbeln.
DATA : shipto_address(200).
DATA : soldto_address(200).
DATA : v_remarks(50).
DATA : v_totqty(10) TYPE n.
DATA : v_stdqty(10) TYPE n.
DATA : v_region TYPE t005u-bezei.
DATA : v_country TYPE t005t-landx50.
DATA : v_werks TYPE vbrp-werks,
       v_lgort TYPE lips-lgort. "MOD1
DATA : v_vgbel TYPE lips-vgbel.
DATA : v_bstkd TYPE vbkd-bstkd.
DATA : plant_address(200).
DATA : v_totboxes TYPE i.
DATA : v_vkorg TYPE likp-vkorg.
DATA : v_dt TYPE datum.
DATA : v_ky(15).
DATA : v_kyi TYPE i.
DATA : v_billdoc TYPE vbfa-vbeln.
DATA : v_fkart TYPE vbrk-fkart.
DATA: tot_qty TYPE int4.

INCLUDE rvadtabl.

TABLES: vbuk,
        vbco3,
        vbpla,
        vbplk,
        vbplp,
        vbpls.

DATA: BEGIN OF xvbplk OCCURS 10.
        INCLUDE STRUCTURE vbplk.
DATA: END OF xvbplk.

DATA: BEGIN OF xvbplp OCCURS 50.
        INCLUDE STRUCTURE vbplp.
DATA: END OF xvbplp.

DATA: BEGIN OF xvbpls OCCURS 10.
        INCLUDE STRUCTURE vbpls.
DATA: END OF xvbpls.

DATA: retcode LIKE sy-subrc.
DATA: xscreen(1) TYPE c.
DATA : lv_lgpla TYPE lqua-lgpla. "MOD1
DATA: ls_lgpla       TYPE char200,
      ls_verme(10)   TYPE c,
      lv_tot         TYPE lqua-verme,
      lv_tot_bin_qty TYPE lqua-verme.
