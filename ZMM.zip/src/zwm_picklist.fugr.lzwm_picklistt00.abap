*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZWM_PICKLIST....................................*
DATA:  BEGIN OF STATUS_ZWM_PICKLIST                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZWM_PICKLIST                  .
CONTROLS: TCTRL_ZWM_PICKLIST
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZWM_PICKLIST                  .
TABLES: ZWM_PICKLIST                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
