*&---------------------------------------------------------------------*
*&  Include           ZMM_ASSET_MAS_REPORT_SEL
*&---------------------------------------------------------------------*

data :  v_anln1 type ANLA-ANLN1,
       v_ebeln type ekko-ebeln,
       v_bedat type ekko-bedat,
       v_bukrs type t001-bukrs,
       v_werks type t001w-werks.

SELECTION-SCREEN : BEGIN OF BLOCK a1 WITH FRAME TITLE text-001.
SELECT-OPTIONS:s_bukrs FOR v_bukrs OBLIGATORY NO INTERVALS NO-EXTENSION MODIF ID co.
SELECT-OPTIONS:s_werks FOR v_werks OBLIGATORY NO INTERVALS NO-EXTENSION MODIF ID co.
SELECT-OPTIONS : s_anln1 for v_anln1 OBLIGATORY,
                 s_ebeln for v_ebeln no INTERVALS,
                 s_bedat for v_bedat.
  SELECTION-SCREEN : end OF BLOCK a1 .
PARAMETERS: variant LIKE disvariant-variant.


INITIALIZATION.
  gx_variant-report = sy-repid.
  CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save     = g_save
    CHANGING
      cs_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.
  IF sy-subrc = 0.
    variant = gx_variant-variant.
  ENDIF.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR variant.
*********************
*  **-- Display all existing variants
  g_variant-report = sy-repid.
* Utilizing the name of the report, this function module will search for a list of
* variants and will fetch the selected one into the parameter field for variants
  CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
    EXPORTING
      is_variant = g_variant
      i_save     = g_save
    IMPORTING
      e_exit     = g_exit
      es_variant = gx_variant
    EXCEPTIONS
      not_found  = 2.



  IF sy-subrc = 2.
    MESSAGE ID sy-msgid TYPE 'S'      NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
    IF g_exit = space.
      variant = gx_variant-variant.
    ENDIF.
  ENDIF.

  AT SELECTION-SCREEN.

    IF s_bukrs-low = '*'.
      MESSAGE 'Enter valid company code.' TYPE 'E'.
    ENDIF.
