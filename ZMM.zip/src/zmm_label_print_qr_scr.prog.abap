*&---------------------------------------------------------------------*
*&  Include           ZMM_LABEL_PRINT_QR_SCR
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF  BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS : s_zsu_no FOR zmm_su_number-zsu_no OBLIGATORY.
PARAMETERS :  P_WERKS TYPE zmm_su_number-werks OBLIGATORY,
              p_print TYPE lvs_lhmng1.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_zsu_no-low.
  PERFORM zsu_nof4help.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR s_zsu_no-high.
  PERFORM zsu_nof4help.


AT SELECTION-SCREEN ON p_print.
  if s_zsu_no-high IS NOT INITIAL.
  p_print = ( s_zsu_no-high -  s_zsu_no-low ) + 1.
  elseif s_zsu_no-high IS INITIAL .
   s_zsu_no-low  = 0.
   p_print = ( s_zsu_no-high -  s_zsu_no-low ) + 1.
    ENDIF.

AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-name = 'P_PRINT'.
      screen-input = 0.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.
