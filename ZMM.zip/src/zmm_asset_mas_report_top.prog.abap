*&---------------------------------------------------------------------*
*&  Include           ZMM_ASSET_MAS_REPORT_TOP
*&---------------------------------------------------------------------*
TYPES:BEGIN OF ty_rseg,
        belnr TYPE rseg-belnr,
        gjahr TYPE rseg-gjahr,
        ebeln TYPE rseg-ebeln,
        ebelp TYPE rseg-ebelp,
      END OF ty_rseg.
*PARAMETERS: variant LIKE disvariant-variant.
DATA : g_save      TYPE c VALUE 'X',
       g_variant   TYPE disvariant,
       g_variant1  TYPE disvariant,
       gx_variant  TYPE disvariant,
       gx_variant1 TYPE disvariant,
       g_exit      TYPE c,
       t_event     TYPE slis_t_event WITH HEADER LINE.


DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv,
       lv_grswt  TYPE brgew.

DATA: it_rseg_w TYPE TABLE OF ty_rseg,
      wa_rseg_w TYPE ty_rseg.

TYPES : BEGIN OF ty_final,
          anln1    TYPE anla-anln1,
          txt50    TYPE anla-txt50,
          posnr    TYPE char50,
          post1    TYPE prps-post1,
**  banfn TYPE ebkn-banfn,
**  bnfpo TYPE ebkn-bnfpo,
**  badat TYPE eban-badat,
          ebeln    TYPE ekpo-ebeln,
          ebelp    TYPE ekpo-ebelp,
          bedat    TYPE ekko-bedat,
          lifnr    TYPE lfa1-lifnr,
          name1    TYPE lfa1-name1,
          waers    TYPE ekko-waers,
          werks    TYPE ekpo-werks,
          matnr    TYPE ekpo-matnr,
          maktx    TYPE makt-maktx,
          po_qty   TYPE ekpo-menge,
          po_val   TYPE ekpo-netwr,
          inv_qty  TYPE ekpo-menge,
          inv_val  TYPE ekbe-wrbtr,
          pend_val TYPE ekbe-wrbtr,
          loekz    TYPE ekpo-loekz,
          elikz    TYPE ekpo-elikz,
          erekz    TYPE erekz,
**  werks type ekpo-werks,
**  knttp type ekpo-knttp,
**  VRTKZ type ekpo-VRTKZ,
**  pstyp type ekpo-pstyp,"Respective PO is Service or Material PO
          knumv    TYPE konv-knumv,   """ADDED BY AKSHAY DT.07.05.2025
          lifnr_n  TYPE konv-lifnr, """ADDED BY AKSHAY DT.07.05.2025
          kwert    TYPE konv-kwert,   """ADDED BY AKSHAY DT.07.05.2025
          wrbtr    TYPE rseg-wrbtr,   """ADDED BY AKSHAY DT.07.05.2025
          lifnr_f  TYPE lfa1-lifnr,   """ADDED BY AKSHAY DT.07.05.2025
          name1_f  TYPE lfa1-name1,   """ADDED BY AKSHAY DT.07.05.2025
*          wrbtr_n  TYPE konv-kwert,   """ADDED BY AKSHAY DT.07.05.2025

        END OF ty_final.

DATA : v_amt TYPE ekbe-wrbtr.

DATA : wa_final TYPE ty_final,
       it_final TYPE STANDARD TABLE OF ty_final.

DATA : wa_final1 TYPE ty_final,
       it_final1 TYPE STANDARD TABLE OF ty_final.

DATA: lv_str TYPE string.

TYPES : BEGIN OF ty_ekbes,
          lv_str TYPE string,
          ebeln  TYPE ekbe-ebeln,
          ebelp  TYPE ekbe-ebelp,
          zekkn  TYPE ekbe-zekkn,
          vgabe  TYPE ekbe-vgabe,
          menge  TYPE ekbe-menge,
          wrbtr  TYPE ekbe-wrbtr,

        END OF ty_ekbes.

DATA : it_ekbes TYPE STANDARD TABLE OF ty_ekbes,
       wa_ekbes TYPE ty_ekbes.

TYPES : BEGIN OF ty_temp,
          lblni TYPE ekpo-packno,
          ebeln TYPE ekpo-ebeln,
        END OF ty_temp.

DATA : it_temp TYPE STANDARD TABLE OF ty_temp,
       wa_temp TYPE ty_temp.



TYPES : BEGIN OF ty_eskn,
          ebeln  TYPE ekpo-ebeln,
          ebelp  TYPE ekpo-ebelp,
          packno TYPE ekpo-packno,
          zekkn  TYPE eskn-zekkn,
        END OF ty_eskn.

DATA : it_eskn TYPE STANDARD TABLE OF ty_eskn,
       wa_eskn TYPE ty_eskn.

DATA : it_eskn_temp TYPE STANDARD TABLE OF ty_eskn,
       wa_eskn_temp TYPE ty_eskn.

DATA: lr_anln1  TYPE RANGE OF anln1,
      lsr_anln1 LIKE LINE OF lr_anln1.

DATA: lr_ps_pnr  TYPE RANGE OF ps_psp_pnr,
      lsr_ps_pnr LIKE LINE OF lr_ps_pnr.
