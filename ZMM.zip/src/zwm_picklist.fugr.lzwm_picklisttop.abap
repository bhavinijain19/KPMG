FUNCTION-POOL ZWM_PICKLIST               MESSAGE-ID SV.

* INCLUDE LZWM_PICKLISTD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZWM_PICKLISTT00                        . "view rel. data dcl.
