*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Mayank Gupta
*&  Functional Consultant   :    Hemangi Joshi
*&  Requirement             :    SU Number List Report
*&  Reviewed By             :    Parth Shukla
*&  Request                 :    DEVK931329
*&---------------------------------------------------------------------*
*& Report  ZMM_SU_NUMBER_LIST_REP
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zmm_su_number_list_rep.

INCLUDE zmm_su_number_list_rep_top.

INCLUDE zmm_su_number_list_rep_scr.

INCLUDE zmm_su_number_list_rep_main.

INCLUDE zmm_su_number_list_rep_form.
