*&---------------------------------------------------------------------*
*&  Include           ZMM_SU_NUMBER_LIST_REP_MAIN
*&---------------------------------------------------------------------*

START-OF-SELECTION.

  PERFORM authorization.
  PERFORM get_data.
  PERFORM process_data.
  PERFORM fill_listheader.
  PERFORM fill_layout.
  PERFORM field_catalogue.
  PERFORM display_data.

END-OF-SELECTION.
