*----------------------------------------------------------------------*
***INCLUDE ZSD_SALESORDER_DETAIL_V1_F01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM authorization_check .

*  SELECT werks FROM t001w INTO TABLE @DATA(lt_t001w)
*    WHERE werks IN @s_werks.
*
*  LOOP AT lt_t001w INTO DATA(wa_t001w).
*    AUTHORITY-CHECK OBJECT 'M_MATE_WRK'
*    ID 'WERKS' FIELD wa_t001w-werks
*    ID 'ACTVT' FIELD '03'.
*    IF sy-subrc <> 0.
*      MESSAGE e007(zsd) WITH wa_t001w-werks.
*    ENDIF.
*  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_data .

  DATA: lv_date  TYPE begda,
        " ATC Correction for S4 HANA ** BEGIN OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
        rt_erdat TYPE fip_t_aedat_range.      "#EC CI_USAGE_OK[2368747]
  " ATC Correction for S4 HANA ** END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
  DATA: v_dlfimg TYPE lips-lfimg.
  DATA: v_dlfimg1 TYPE lips-lfimg.
  DATA: v_invquan TYPE lips-lfimg.
  DATA: v_dvbeln1(200).
  DATA : wa_final TYPE t_final.
  DATA : v_price TYPE vbap-netwr.
  DATA: v_gsttotal TYPE vbap-netwr.

  IF v_it IS INITIAL.
    rt_erdat[] = s_date[].
  ELSE.

    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = sy-datum
        days      = '10'
        months    = '00'
        signum    = '-'
        years     = '00'
      IMPORTING
        calc_date = lv_date.

    rt_erdat = VALUE #( ( sign = 'I'
                          option = 'BT'
                          low = sy-datum
                          high = lv_date ) ).
  ENDIF.
**  Start change by Archna Gupta on 10.03.2026
*  SELECT vbeln,
*         zz1_lid_1_sdh,
*         zz1_lid_2_sdh,
*         zz1_lid_3_sdh,
*         zz1_lid_4_sdh,
*         zz1_lid_5_sdh,
*         zz1_lid_6_sdh,
*         zz1_lid_7_sdh,
*         zz1_gid_1_sdh,
*         zz1_gid_2_sdh,
*         zz1_gid_3_sdh,
*         zz1_gid_4_sdh,
*         zz1_gid_5_sdh,
*         zz1_gid_6_sdh,
*         zz1_gid_7_sdh,
*         zz1_l1_d_sdh,
*         zz1_l2_d_sdh,
*         zz1_l3_d_sdh,
*         zz1_l4_d_sdh,
*         zz1_l5_d_sdh,
*         zz1_l6_d_sdh,
*         zz1_l7_d_sdh,
*         zz1_g1_d_sdh,
*         zz1_g2_d_sdh,
*         zz1_g3_d_sdh,
*         zz1_g4_d_sdh,
*         zz1_g5_d_sdh,
*         zz1_g6_d_sdh,
*         zz1_g7_d_sdh
*         FROM vbak
*         INTO TABLE @DATA(it_vbak)
*         WHERE vbeln IN @s_vbeln.
***    Ended by Archna Gupta on 10.03.2026

  SELECT a~vbeln AS vbeln_a, a~erdat, a~erzet, a~auart, a~lifsk, a~vkorg,
     a~vtweg, a~spart, a~vkbur, a~knumv, a~kunnr, a~aedat, a~bukrs_vf,
     a~zzname, a~zztcode, a~zzsydate, a~zzsy_time,
     b~vbeln AS vbeln_b, b~posnr, b~matnr, b~matkl, b~arktx, b~abgru,
     b~netwr, b~waerk, b~kwmeng, b~kbmeng, b~vrkme, b~werks, b~kondm, b~prctr,
     b~mvgr1, b~mvgr4
   FROM vbak AS a  INNER JOIN vbap AS b
    ON a~vbeln = b~vbeln
    INTO TABLE @DATA(it_vbap)
   WHERE a~erdat IN @rt_erdat
     AND a~vkorg IN @s_vkorg
     AND a~vtweg IN @s_vtweg
     AND a~spart IN @s_spart
     AND a~kunnr IN @s_kunnr
     AND a~vkbur IN @s_vkbur
     AND b~werks IN @s_werks
     AND b~vbeln IN @s_vbeln
     AND b~matnr IN @s_matnr
     AND b~matkl IN @s_matkl
     AND b~matnr IS NOT NULL
     AND vbtyp = 'C'.

  IF sy-subrc NE 0.
    MESSAGE 'NO ORDER EXISTS FOR THIS SELECTION' TYPE 'S'
    DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.



********************Authorisation Object on Sales Office*******************

  IF it_vbap IS NOT INITIAL.
    LOOP AT it_vbap INTO DATA(wa_vbap_a).
      AUTHORITY-CHECK OBJECT 'ZSD_IN_SLF'
       ID 'VKBUR' FIELD wa_vbap_a-vkbur
       ID 'ACTVT' FIELD '03'.
      IF sy-subrc <> 0.
        MESSAGE e029(zfi) WITH wa_vbap_a-vkbur.
      ENDIF.
    ENDLOOP.
  ENDIF.

******************Authorisation Object on Sales Office*********************

  SELECT * FROM zsd_zone INTO TABLE @DATA(it_zone).

  IF it_vbap IS NOT INITIAL.
    SORT it_vbap BY kunnr.
    DATA(lt_vbap) = it_vbap[].
    DELETE ADJACENT DUPLICATES FROM lt_vbap COMPARING kunnr.
    IF lt_vbap IS NOT INITIAL.
      SELECT kunnr, lcategory, lid, startval, endval, lname
      INTO TABLE @DATA(it_custemp)
      FROM zsd_custemp_assg
        FOR ALL ENTRIES IN @lt_vbap
        WHERE kunnr = @lt_vbap-kunnr
        AND   startval <= @lt_vbap-erdat
        AND   endval >= @lt_vbap-erdat.

      SELECT kunnr, lcategory, lid, startval, endval, lname
        INTO TABLE @DATA(it_custemp1)
        FROM zsd_custemp_assg
          FOR ALL ENTRIES IN @lt_vbap
          WHERE kunnr = @lt_vbap-kunnr
          AND   startval <= @sy-datum
          AND   endval >= @sy-datum.

      SELECT kunnr, name1, regio, bbbnr, bbsnr,
             zz1_posid1_cus,zz1_geo1_cus  "++Added By Archna Gupta on 18.03.2026
         FROM kna1 INTO TABLE @DATA(it_kna1)
         FOR ALL ENTRIES IN @lt_vbap
         WHERE kunnr = @lt_vbap-kunnr.

      SELECT vbeln,erdat,vkorg,vtweg,netwr,spart,vkgrp,vkbur,kunnr,zzdate,
             zz1_lid_1_sdh,zz1_l1_d_sdh,zz1_lid_2_sdh,zz1_l2_d_sdh,zz1_lid_3_sdh, zz1_l3_d_sdh,zz1_lid_4_sdh, zz1_l4_d_sdh, ""Added by archna Gupta on 17.03.2026
             zz1_lid_5_sdh,zz1_l5_d_sdh,zz1_lid_6_sdh,zz1_l6_d_sdh, zz1_lid_7_sdh,zz1_l7_d_sdh,zz1_gid_1_sdh,zz1_g1_d_sdh,
             zz1_gid_2_sdh,zz1_g2_d_sdh,zz1_gid_3_sdh,zz1_g3_d_sdh,zz1_gid_4_sdh,zz1_g4_d_sdh,zz1_gid_5_sdh,zz1_g5_d_sdh,zz1_gid_6_sdh,
             zz1_g6_d_sdh,zz1_gid_7_sdh,zz1_g7_d_sdh ""Ended by Archna Gupta on 17.03.2026
        FROM vbak INTO TABLE @DATA(it_heir)                  "Sales Order Details
        FOR ALL ENTRIES IN @lt_vbap WHERE vbeln = @lt_vbap-vbeln_a.

    ENDIF.
  ENDIF.
  IF it_kna1[] IS NOT INITIAL.
    SELECT kunnr, klimk, skfor FROM knkk
      INTO TABLE @DATA(it_knkk)
      FOR ALL ENTRIES IN @it_kna1 WHERE kunnr = @it_kna1-kunnr.

    SELECT kunnr, vkorg,spart, zterm, vkgrp, bzirk, kvgr1, kvgr2 "Added by Bhaumik|02.04.26|DEVK900996
      FROM knvv INTO TABLE @DATA(it_knvv)
      FOR ALL ENTRIES IN @it_kna1 WHERE kunnr = @it_kna1-kunnr.

    SELECT * FROM t005u INTO TABLE @DATA(it_t005u)
         FOR ALL ENTRIES IN @it_kna1
         WHERE bland = @it_kna1-regio AND spras = @sy-langu "'EN'
         AND land1 = 'IN'.
  ENDIF.

  IF it_vbap IS NOT INITIAL.
    SORT it_vbap BY vbeln_a posnr.
    SELECT vbelv, posnv, vbeln FROM vbfa INTO TABLE @DATA(it_vbfa)
      FOR ALL ENTRIES IN @it_vbap
      WHERE vbelv = @it_vbap-vbeln_a
        AND posnv = @it_vbap-posnr
        AND vbtyp_n = 'J'
        AND vbtyp_v = 'C'.


* Quick Fix Replace VBUK table access with the access of compatibility view V_VBUK_S4
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT vbeln, cmgst FROM vbuk INTO TABLE @DATA(it_vbuk)
*      FOR ALL ENTRIES IN @it_vbap
*      WHERE vbeln = @it_vbap-vbeln_a.

    SELECT FROM v_vbuk_s4 FIELDS vbeln , cmgst FOR ALL ENTRIES IN @it_vbap WHERE vbeln = @it_vbap-vbeln_a INTO TABLE @DATA(it_vbuk) .
* End of Quick Fix


    SELECT matnr, werks, lgort, labst FROM mard INTO TABLE @DATA(it_mard)
      FOR ALL ENTRIES IN @it_vbap
      WHERE matnr = @it_vbap-matnr AND werks = @it_vbap-werks.

    SORT it_mard BY matnr werks lgort.
    DELETE ADJACENT DUPLICATES FROM it_mard COMPARING matnr werks lgort.

    SELECT kondm, vtext FROM t178t INTO TABLE @DATA(it_t178t)
      FOR ALL ENTRIES IN @it_vbap
      WHERE kondm = @it_vbap-kondm.

    SORT it_t178t BY kondm.
    DELETE ADJACENT DUPLICATES FROM it_t178t COMPARING kondm.

    SELECT mvgr1, bezei, spras FROM tvm1t INTO TABLE @DATA(it_tvm1t)
       FOR ALL ENTRIES IN @it_vbap
        WHERE  mvgr1 = @it_vbap-mvgr1 AND spras = @sy-langu. "'EN'.

    SELECT mvgr4, bezei, spras FROM tvm4t INTO TABLE @DATA(it_tvm4t)
    FOR ALL ENTRIES IN @it_vbap
      WHERE  mvgr4 = @it_vbap-mvgr4 AND spras = @sy-langu."'EN'.


    SELECT spras, auart, bezei FROM tvakt INTO TABLE @DATA(it_tvakt)
      FOR ALL ENTRIES IN @it_vbap
      WHERE  auart = @it_vbap-auart AND spras = @sy-langu. "'EN'.

    SELECT * FROM tvagt INTO TABLE @DATA(it_tvagt)
      FOR ALL ENTRIES IN @it_vbap
      WHERE abgru = @it_vbap-abgru AND spras = @sy-langu. "'EN'.

    SELECT * FROM tvkbt INTO TABLE @DATA(it_tvkbt)
       FOR ALL ENTRIES IN @it_vbap
      WHERE vkbur = @it_vbap-vkbur AND spras = @sy-langu. "'EN'.

  ENDIF.

  SELECT sign, opti, low, high
    INTO TABLE @DATA(lt_acc_key)
    FROM tvarvc
    WHERE name = @c_var_user AND
          type = @c_type_user.

  IF it_knvv IS NOT INITIAL.
**    Start Added By Archna Gupta on 18.03.2026
    SELECT  *
       FROM zsd_hierarchy_tb  INTO TABLE  @DATA(lt_hierarchy_tab) FOR ALL ENTRIES IN @it_knvv
       WHERE div = @it_knvv-spart
       AND cust_grp = @it_knvv-kvgr1.
**       Ended by Archna Gupta on 18.03.2026

    SELECT spras, bzirk, bztxt
        INTO TABLE @DATA(it_t171t)
        FROM t171t
        FOR ALL ENTRIES IN @it_knvv
        WHERE spras = @sy-langu
        AND   bzirk = @it_knvv-bzirk.

    SELECT spras, vkgrp, bezei
      INTO TABLE @DATA(it_tvgrt)
      FROM tvgrt
      FOR ALL ENTRIES IN @it_knvv
      WHERE spras = @sy-langu
      AND   vkgrp = @it_knvv-vkgrp.
  ENDIF.

  DATA : wa_stock TYPE t_stock.
  DATA : it_stock TYPE STANDARD TABLE OF t_stock.

  LOOP AT it_mard INTO DATA(wa_mard).

    wa_stock-werks = wa_mard-werks.
    wa_stock-matnr = wa_mard-matnr.
    wa_stock-qty = wa_mard-labst.

    READ TABLE lt_acc_key INTO DATA(lwa_acc_key)
     WITH KEY low = wa_mard-lgort.
    IF sy-subrc <> 0.
      wa_stock-qty_r = wa_mard-labst.
    ENDIF.

    COLLECT wa_stock INTO it_stock.
    CLEAR: wa_stock,wa_mard.
  ENDLOOP.

  IF NOT it_vbfa IS INITIAL.
    SELECT a~vbeln AS vbeln_a, a~erdat, a~erzet, a~wadat_ist,
      b~vbeln, b~posnr, b~matnr, b~lfimg, b~meins, b~vgbel, b~vgpos
      FROM likp AS a INNER JOIN lips AS b
       ON a~vbeln = b~vbeln INTO TABLE @DATA(it_lips)
       FOR ALL ENTRIES IN @it_vbfa
      WHERE b~vbeln = @it_vbfa-vbeln.


* Quick Fix Replace VBUP table access with access of table LIPS
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT vbeln, posnr, wbsta, fksta
*       FROM vbup INTO TABLE @DATA(it_vbup)
*       FOR ALL ENTRIES IN @it_vbfa
*        WHERE vbeln = @it_vbfa-vbeln.

    SELECT vbeln, posnr, wbsta, fksta
           FROM lips INTO TABLE @DATA(it_vbup)
           FOR ALL ENTRIES IN @it_vbfa
            WHERE vbeln = @it_vbfa-vbeln.

* End of Quick Fix

  ENDIF.

  DATA:v_wadat TYPE likp-wadat_ist.

  SORT it_vbap BY vbeln_a posnr.
  SORT it_lips BY vgbel vgpos.
  SORT it_custemp BY kunnr.
  SORT it_custemp1 BY kunnr.
**  Start added by archna Gupta on 06.03.2026
*  loop at it_vbak into data(wa_vbak).
*    clear: wa_final.
*    wa_final-
* **   Ended by archna Gupta on 06.03.2026











  LOOP AT it_vbap INTO DATA(wa_vbap).

    MOVE-CORRESPONDING wa_vbap TO wa_final.
    wa_final-vbeln = wa_vbap-vbeln_a.
*    Start Added By Archna Gupta on 18.03.2026.
    LOOP AT it_knvv INTO DATA(wa_knvv) WHERE kunnr = wa_vbap-kunnr.
      wa_final-spart = wa_knvv-spart.
      wa_final-kvgr1 = wa_knvv-kvgr1.

      READ TABLE it_heir INTO DATA(ls_heir) WITH KEY vbeln = wa_vbap-vbeln_a.
      IF sy-subrc = 0.
        CLEAR ls_hierarchy.
        CALL FUNCTION 'ZSALES_HIERARCHY'
          EXPORTING
            iv_kunnr     = wa_knvv-kunnr
            iv_div       = wa_knvv-spart
            iv_cust_grp  = wa_knvv-kvgr1
*           IV_GEO_CODE  =
*           IV_POS_ID    =
          IMPORTING
            es_hierarchy = ls_hierarchy.

        IF ls_hierarchy IS NOT INITIAL.
          MOVE-CORRESPONDING ls_hierarchy TO wa_final.
        ENDIF.
      ENDIF.


**        READ TABLE lt_hierarchy_tab INTO DATA(ls_hierarchy_tab) WITH KEY  geo_code = wa_kna1-zz1_geo1_cus
**                                                                   position_id = wa_kna1-zz1_posid1_cus
**                                                                    div = wa_knvv-spart         "
**                                                                    cust_grp =  wa_knvv-kvgr1.
**        IF sy-subrc = 0.
**          CASE ls_hierarchy_tab-geo_level .
**            WHEN  'G7' .
**              wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G6'.
**              wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G5'.
**              wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G4'.
**              wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G3'.
**              wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN 'G2'.
**              wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN 'G1'.
**              wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN OTHERS.
**          ENDCASE.
**          READ TABLE lt_hierarchy_tab
**                     INTO DATA(ls_hierarchy_tab_6)
**                     WITH  KEY  geo_level = ls_hierarchy_tab-parent_geo_level
**                         div = wa_knvv-spart
**                         cust_grp = wa_knvv-kvgr1.
**          IF sy-subrc = 0.
**            CASE ls_hierarchy_tab_6-geo_level .
**              WHEN  'G7' .
**                wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                  wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G6'.
**                wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                  wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G5'.
**                wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                  wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G4'.
**
**                wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                  wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G3'.
**                wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                  wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**
**              WHEN 'G2'.
**                wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                  wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G1'.
**                wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                  wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**
**              WHEN OTHERS.
**            ENDCASE.
**            READ TABLE lt_hierarchy_tab
**             INTO DATA(ls_hierarchy_tab_5)
**              WITH  KEY  geo_level = ls_hierarchy_tab_6-parent_geo_level
**                  div = wa_knvv-spart
**                  cust_grp = wa_knvv-kvgr1.
**            IF sy-subrc = 0.
**              CASE ls_hierarchy_tab_5-geo_level .
**                WHEN  'G7' .
**
**                  wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                    wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G6'.
**                  wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                    wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G5'.
**                  wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                    wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G4'.
**
**                  wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                    wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G3'.
**                  wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                    wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G2'.
**                  wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                    wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G1'.
**                  wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                    wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN OTHERS.
**              ENDCASE.
***          STEP4
**              READ TABLE lt_hierarchy_tab
**                 INTO DATA(ls_hierarchy_tab_4)
**                 WITH  KEY  geo_level = ls_hierarchy_tab_5-parent_geo_level
**                     div = wa_knvv-spart
**                     cust_grp = wa_knvv-kvgr1.
**              IF sy-subrc = 0.
**
**                CASE ls_hierarchy_tab_4-geo_level .
**                  WHEN  'G7' .
**
**                    wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                      wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G6'.
**                    wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                      wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G5'.
**                    wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                      wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G4'.
**
**                    wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                      wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G3'.
**                    wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                      wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G2'.
**                    wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                      wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G1'.
**                    wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                      wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**
**                  WHEN OTHERS.
**                ENDCASE.
**
***            step 3
**                READ TABLE lt_hierarchy_tab
**                   INTO DATA(ls_hierarchy_tab_3)
**                   WITH  KEY  geo_level = ls_hierarchy_tab_4-parent_geo_level
**                       div = wa_knvv-spart
**                       cust_grp = wa_knvv-kvgr1.
**                IF sy-subrc = 0.
**                  CASE ls_hierarchy_tab_3-geo_level .
**                    WHEN  'G7' .
**
**                      wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                        wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G6'.
**                      wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                        wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G5'.
**                      wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                        wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G4'.
**
**                      wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                        wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G3'.
**                      wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                        wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G2'.
**                      wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                        wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G1'.
**                      wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                        wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**
**                    WHEN OTHERS.
**                  ENDCASE.
**
***              step 2
**                  READ TABLE lt_hierarchy_tab
**                     INTO DATA(ls_hierarchy_tab_2)
**                     WITH  KEY  geo_level = ls_hierarchy_tab_3-parent_geo_level
**                         div = wa_knvv-spart
**                         cust_grp = wa_knvv-kvgr1.
**                  IF sy-subrc = 0.
**
**                    CASE ls_hierarchy_tab_2-geo_level .
**                      WHEN  'G7' .
**
**                        wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                          wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G6'.
**                        wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                          wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G5'.
**                        wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                          wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G4'.
**
**                        wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                          wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G3'.
**                        wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                          wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G2'.
**                        wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                          wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G1'.
**                        wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                          wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN OTHERS.
**                    ENDCASE.
***                step 1
**                    READ TABLE lt_hierarchy_tab
**                INTO DATA(ls_hierarchy_tab_1)
**                 WITH  KEY  geo_level = ls_hierarchy_tab_2-parent_geo_level
**                     div = wa_knvv-spart
**                     cust_grp = wa_knvv-kvgr1.
**                    IF sy-subrc = 0.
**
**                      CASE ls_hierarchy_tab_1-geo_level .
**                        WHEN  'G7' .
**
**                          wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                            wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G6'.
**                          wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                            wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G5'.
**                          wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                            wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G4'.
**
**                          wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                            wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G3'.
**                          wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                            wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G2'.
**                          wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                            wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G1'.
**                          wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**
**                          IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                            wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**
**                        WHEN OTHERS.
**                      ENDCASE.
**                    ENDIF.
**                  ENDIF.
**                ENDIF.
**              ENDIF.
**            ENDIF.
**          ENDIF.
**        ENDIF.
**      ENDIF.
      "ENDIF.
    ENDLOOP.
**    Ended By archna Gupta on 18.03.2026.

    READ TABLE it_lips INTO DATA(lwa_lips)
      WITH KEY vgbel = wa_vbap-vbeln_a
               vgpos = wa_vbap-posnr
      BINARY SEARCH.
    IF sy-subrc = 0.

      DATA(lv_index) = sy-tabix.
      LOOP AT it_lips INTO DATA(wa_lips)
        FROM lv_index.

        IF wa_vbap-vbeln_a <> wa_lips-vgbel OR
           wa_vbap-posnr <> wa_lips-vgpos.

          CLEAR: lv_index.
          lv_index = sy-tabix - 1.
          READ TABLE it_lips INTO wa_lips INDEX lv_index.
          IF sy-subrc = 0.

            wa_final-dlfimg =  v_dlfimg.
            wa_final-dlfimg1 = v_dlfimg1.
            wa_final-invquan = v_invquan.
            wa_final-dmeins = wa_lips-meins.
            wa_final-derdat = wa_lips-erdat.
            wa_final-dvbeln = v_dvbeln1.
            wa_final-derzet = wa_lips-erzet.
            wa_final-wadat_ist = wa_lips-wadat_ist.

            wa_final-remqty = wa_vbap-kbmeng - ( v_dlfimg + v_dlfimg1 ).

            IF wa_vbap-kbmeng IS NOT INITIAL.
              wa_final-ordvalu = ( wa_vbap-netwr / wa_vbap-kbmeng ) * wa_final-remqty.
            ENDIF.
          ENDIF.
          EXIT.
        ENDIF.

        READ TABLE it_vbup INTO DATA(wa_vbup)
         WITH KEY vbeln = wa_lips-vbeln
                  posnr = wa_lips-posnr.
        IF sy-subrc = 0.
          IF wa_vbup-wbsta = 'C'.
            IF wa_vbup-fksta = 'C' OR wa_vbup-fksta = 'B'.
              v_dlfimg = v_dlfimg + wa_lips-lfimg.
              wa_lips-lfimg = v_dlfimg.
            ELSEIF wa_vbup-fksta = 'A'.
              v_invquan = v_invquan + wa_lips-lfimg.             "Invoice Remaining PGI Done
              wa_lips-lfimg = v_invquan.
            ENDIF.
          ELSE.
            v_dlfimg1 = v_dlfimg1 + wa_lips-lfimg.
            wa_lips-lfimg = v_dlfimg1.
          ENDIF.
        ENDIF.

        IF v_dvbeln1 IS INITIAL.
          v_dvbeln1 = wa_lips-vbeln.
        ELSE.
          CONCATENATE v_dvbeln1 ',' wa_lips-vbeln INTO v_dvbeln1.
        ENDIF.
        CONDENSE v_dvbeln1.
      ENDLOOP.
    ENDIF.
    TRY .
        IF it_kna1[ kunnr = wa_vbap-kunnr ]-bbsnr IS NOT INITIAL.
          TRY .
              wa_final-zone = it_zone[ bukrs = wa_vbap-bukrs_vf
                                     zzone = it_kna1[ kunnr = wa_vbap-kunnr ]-bbbnr ]-name.
            CATCH cx_sy_itab_line_not_found.
              wa_final-zone = 'wrongly maintain'.
          ENDTRY.

          TRY .
              wa_final-szone = it_zone[ bukrs = wa_vbap-bukrs_vf
                                        zzone = it_kna1[ kunnr = wa_vbap-kunnr ]-bbbnr
                                        szone = it_kna1[ kunnr = wa_vbap-kunnr ]-bbsnr ]-sname.
            CATCH cx_sy_itab_line_not_found.
              wa_final-szone = 'wrongly maintain'.
          ENDTRY.
        ENDIF.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-klimk = it_knkk[ kunnr = wa_vbap-kunnr ]-klimk.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-zterm = it_knvv[ kunnr = it_kna1[ kunnr = wa_vbap-kunnr ]-kunnr
                                  ]-zterm.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-bzirk = it_knvv[ kunnr = it_kna1[ kunnr = wa_vbap-kunnr ]-kunnr
                                     ]-bzirk.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    "BOC by Bhaumik|02.04.26|DEVK900996
    TRY .
        wa_final-kvgr1 = it_knvv[ kunnr = it_kna1[ kunnr = wa_vbap-kunnr ]-kunnr
                                    ]-kvgr1.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-kvgr2 = it_knvv[ kunnr = it_kna1[ kunnr = wa_vbap-kunnr ]-kunnr
                                    ]-kvgr2.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
    "EOC by Bhaumik|02.04.26|DEVK900996


    TRY .
        wa_final-bztxt  = it_t171t[ bzirk = it_knvv[ kunnr =  wa_vbap-kunnr ]-bzirk ]-bztxt.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-vkgrp_txt  = it_tvgrt[ vkgrp = wa_final-vkgrp ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-vtext = it_t178t[ kondm = wa_vbap-kondm ]-vtext.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-name1 = it_kna1[ kunnr = wa_vbap-kunnr ]-name1.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-regio = it_t005u[ bland = it_kna1[ kunnr = wa_vbap-kunnr ]-regio ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-bezei = it_tvm1t[ mvgr1 = wa_vbap-mvgr1 ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-bezei4 = it_tvm4t[ mvgr4 = wa_vbap-mvgr4 ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-bezei1 = it_tvakt[ auart = wa_vbap-auart ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
    TRY .

      CATCH cx_sy_itab_line_not_found.

    ENDTRY.
    TRY .
        wa_final-soffice =  it_tvkbt[ vkbur = wa_vbap-vkbur ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    wa_final-remqty = wa_vbap-kwmeng - ( v_dlfimg + v_dlfimg1 ).

    IF wa_vbap-kwmeng IS NOT INITIAL.
      wa_final-ordvalu = ( wa_vbap-netwr / wa_vbap-kwmeng ) * wa_final-remqty.
    ENDIF.

    wa_final-dlfimg =  v_dlfimg.
    wa_final-dlfimg1 = v_dlfimg1.
    wa_final-invquan = v_invquan.
    wa_final-dmeins = wa_lips-meins.
    wa_final-derdat = wa_lips-erdat.
    wa_final-dvbeln = v_dvbeln1.
    wa_final-derzet = wa_lips-erzet.
    wa_final-wadat_ist = wa_lips-wadat_ist.

    TRY .
        wa_final-4bezei = it_tvagt[ abgru = wa_vbap-abgru ]-bezei.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-abgru  = it_tvagt[ abgru = wa_vbap-abgru ]-abgru.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-stock = it_stock[ matnr = wa_vbap-matnr  werks = wa_vbap-werks ]-qty.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        wa_final-stock_r = it_stock[ matnr = wa_vbap-matnr  werks = wa_vbap-werks ]-qty_r.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        DATA(wa_vbuk) = it_vbuk[ vbeln = wa_vbap-vbeln_a ].
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.


    IF wa_vbap-lifsk IS INITIAL
      AND wa_vbuk-cmgst <> 'B'
      AND wa_vbuk-cmgst <> 'C'
      AND wa_vbap-zzname IS NOT INITIAL .

      IF  wa_vbap-zztcode IS NOT INITIAL
        AND wa_vbap-zzsydate IS NOT INITIAL
        AND wa_vbap-zzsy_time IS NOT INITIAL
        AND wa_vbap-zzname IS NOT INITIAL.

        wa_final-zztcode   = wa_vbap-zztcode.
        wa_final-zzsydate  = wa_vbap-zzsydate.
        wa_final-zzsy_time = wa_vbap-zzsy_time.
        wa_final-zzname = wa_vbap-zzname.
      ENDIF.
      wa_final-text1 = 'AUTHORIZED'.
    ELSE.
      wa_final-text1 = 'UNAUTHORIZED'.
      wa_final-zztcode   = ' '.
      wa_final-zzsydate  = ' '.
      wa_final-zzsy_time = ' '.
      CLEAR: wa_vbap-zztcode,wa_vbap-zzsy_time,wa_vbap-zzsydate,wa_vbap-zzname.
    ENDIF.

    IF wa_vbap-zzname IS NOT INITIAL.
      wa_final-chandt = wa_vbap-aedat.
    ENDIF.

    READ TABLE it_custemp INTO DATA(wa_custemp)
      WITH KEY kunnr = wa_vbap-kunnr
      BINARY SEARCH.
    IF sy-subrc = 0.
      lv_index = sy-tabix.
      LOOP AT it_custemp INTO wa_custemp FROM lv_index." WHERE kunnr = wa_vbap-kunnr.
        IF wa_custemp-kunnr <> wa_vbap-kunnr.
          EXIT.
        ENDIF.
        IF wa_custemp-startval <= wa_vbap-erdat
           AND wa_custemp-endval >= wa_vbap-erdat.
          CASE wa_custemp-lcategory.
            WHEN 'L1'.
              wa_final-lcategory1 = wa_custemp-lcategory.
              wa_final-lname1     = wa_custemp-lname.
            WHEN 'L2'.
              wa_final-lcategory2 = wa_custemp-lcategory.
              wa_final-lname2     = wa_custemp-lname.
            WHEN 'L3'.
              wa_final-lcategory3 = wa_custemp-lcategory.
              wa_final-lname3     = wa_custemp-lname.
            WHEN 'L4'.
              wa_final-lcategory4 = wa_custemp-lcategory.
              wa_final-lname4     = wa_custemp-lname.
            WHEN 'L5'.
              wa_final-lcategory5 = wa_custemp-lcategory.
              wa_final-lname5     = wa_custemp-lname.
            WHEN 'L6'.
              wa_final-lcategory6 = wa_custemp-lcategory.
              wa_final-lname6     = wa_custemp-lname.
          ENDCASE.
        ENDIF.
        CLEAR: wa_custemp.
      ENDLOOP.
    ENDIF.

    READ TABLE it_custemp1 INTO DATA(wa_custemp1)
      WITH KEY kunnr = wa_vbap-kunnr
      BINARY SEARCH.
    IF sy-subrc = 0.
      lv_index = sy-tabix.
      LOOP AT it_custemp1 INTO wa_custemp1 FROM lv_index." WHERE kunnr = wa_vbap-kunnr.
        IF wa_custemp1-kunnr <> wa_vbap-kunnr.
          EXIT.
        ENDIF.
        IF wa_custemp1-startval <= sy-datum
           AND wa_custemp1-endval >= sy-datum.
          CASE wa_custemp1-lcategory.
            WHEN 'L1'.
              wa_final-clcategory1 = wa_custemp1-lcategory.
              wa_final-clname1     = wa_custemp1-lname.
            WHEN 'L2'.
              wa_final-clcategory2 = wa_custemp1-lcategory.
              wa_final-clname2     = wa_custemp1-lname.
            WHEN 'L3'.
              wa_final-clcategory3 = wa_custemp1-lcategory.
              wa_final-clname3     = wa_custemp1-lname.
            WHEN 'L4'.
              wa_final-clcategory4 = wa_custemp1-lcategory.
              wa_final-clname4     = wa_custemp1-lname.
            WHEN 'L5'.
              wa_final-clcategory5 = wa_custemp1-lcategory.
              wa_final-clname5     = wa_custemp1-lname.
            WHEN 'L6'.
              wa_final-clcategory6 = wa_custemp1-lcategory.
              wa_final-clname6     = wa_custemp1-lname.
          ENDCASE.
          CLEAR: wa_custemp1.
        ENDIF.
      ENDLOOP.
    ENDIF.
    """"""""""""""""""""""""""""""""""""''Archna Gupta on 06.03.2026
*    loop at it_kna1 INTO data(wa_kna1).
***    READ TABLE it_kna1 INTO DATA(wa_kna1) WITH KEY kunnr = wa_vbap-kunnr.
***    IF sy-subrc = 0.
**      READ TABLE it_knvv INTO DATA(wa_knvv) WITH KEY kunnr = wa_kna1-kunnr.
**      IF sy-subrc = 0.
**        READ TABLE lt_hierarchy_tab INTO DATA(ls_hierarchy_tab) WITH KEY  geo_code = wa_kna1-zz1_geo1_cus
**                                                                   position_id = wa_kna1-zz1_posid1_cus
**                                                                    div = wa_knvv-spart         "
**                                                                    cust_grp = wa_knvv-kvgr1.
**        IF sy-subrc = 0.
**          CASE ls_hierarchy_tab-geo_level .
**            WHEN  'G7' .
**              wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G6'.
**              wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G5'.
**              wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G4'.
**              wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**
**            WHEN 'G3'.
**              wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN 'G2'.
**              wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN 'G1'.
**              wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab-geo_code."is_vbak-zz1_gid_7_sdh.
**              wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab-position_id. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab-geo_desc. "is_vbak-zz1_lid_7_sdh.
**              wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab-posid_desc. "is_vbak-zz1_lid_7_sdh.
**              IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab-dummy_val.
**              ENDIF.
**            WHEN OTHERS.
**          ENDCASE.
**          READ TABLE lt_hierarchy_tab
**                     INTO DATA(ls_hierarchy_tab_6)
**                     WITH  KEY  geo_level = ls_hierarchy_tab-parent_geo_level
**                         div = wa_knvv-spart
**                         cust_grp = wa_knvv-kvgr1.
**          IF sy-subrc = 0.
**            CASE ls_hierarchy_tab_6-geo_level .
**              WHEN  'G7' .
**                wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                  wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G6'.
**                wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                  wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G5'.
**                wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                  wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G4'.
**
**                wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                  wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G3'.
**                wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                  wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**
**              WHEN 'G2'.
**                wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                  wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**              WHEN 'G1'.
**                wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_6-geo_code."is_vbak-zz1_gid_7_sdh.
**                wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_6-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_6-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_6-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                  wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_6-dummy_val.
**                ENDIF.
**
**              WHEN OTHERS.
**            ENDCASE.
**            READ TABLE lt_hierarchy_tab
**             INTO DATA(ls_hierarchy_tab_5)
**              WITH  KEY  geo_level = ls_hierarchy_tab_6-parent_geo_level
**                  div = wa_knvv-spart
**                  cust_grp = wa_knvv-kvgr1.
**            IF sy-subrc = 0.
**              CASE ls_hierarchy_tab_5-geo_level .
**                WHEN  'G7' .
**
**                  wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                    wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G6'.
**                  wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                    wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G5'.
**                  wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                    wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G4'.
**
**                  wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                    wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G3'.
**                  wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                    wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G2'.
**                  wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                    wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN 'G1'.
**                  wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_5-geo_code."is_vbak-zz1_gid_7_sdh.
**                  wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_5-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                  wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_5-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                  wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_5-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                  IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                    wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_5-dummy_val.
**                  ENDIF.
**                WHEN OTHERS.
**              ENDCASE.
***          STEP4
**              READ TABLE lt_hierarchy_tab
**                 INTO DATA(ls_hierarchy_tab_4)
**                 WITH  KEY  geo_level = ls_hierarchy_tab_5-parent_geo_level
**                     div = wa_knvv-spart
**                     cust_grp = wa_knvv-kvgr1.
**              IF sy-subrc = 0.
**
**                CASE ls_hierarchy_tab_4-geo_level .
**                  WHEN  'G7' .
**
**                    wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                      wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G6'.
**                    wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                      wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G5'.
**                    wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                      wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G4'.
**
**                    wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                      wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G3'.
**                    wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                      wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G2'.
**                    wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                      wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**                  WHEN 'G1'.
**                    wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_4-geo_code."is_vbak-zz1_gid_7_sdh.
**                    wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_4-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                    wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_4-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                    wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_4-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                    IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                      wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_4-dummy_val.
**                    ENDIF.
**
**                  WHEN OTHERS.
**                ENDCASE.
**
***            step 3
**                READ TABLE lt_hierarchy_tab
**                   INTO DATA(ls_hierarchy_tab_3)
**                   WITH  KEY  geo_level = ls_hierarchy_tab_4-parent_geo_level
**                       div = wa_knvv-spart
**                       cust_grp = wa_knvv-kvgr1.
**                IF sy-subrc = 0.
**                  CASE ls_hierarchy_tab_3-geo_level .
**                    WHEN  'G7' .
**
**                      wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                        wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G6'.
**                      wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                        wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G5'.
**                      wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                        wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G4'.
**
**                      wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                        wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G3'.
**                      wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                        wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G2'.
**                      wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                        wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**                    WHEN 'G1'.
**                      wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_3-geo_code."is_vbak-zz1_gid_7_sdh.
**                      wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_3-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                      wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_3-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                      wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_3-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                      IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                        wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_3-dummy_val.
**                      ENDIF.
**
**                    WHEN OTHERS.
**                  ENDCASE.
**
***              step 2
**                  READ TABLE lt_hierarchy_tab
**                     INTO DATA(ls_hierarchy_tab_2)
**                     WITH  KEY  geo_level = ls_hierarchy_tab_3-parent_geo_level
**                         div = wa_knvv-spart
**                         cust_grp = wa_knvv-kvgr1.
**                  IF sy-subrc = 0.
**
**                    CASE ls_hierarchy_tab_2-geo_level .
**                      WHEN  'G7' .
**
**                        wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                          wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G6'.
**                        wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                          wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G5'.
**                        wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                          wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G4'.
**
**                        wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                          wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G3'.
**                        wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                          wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G2'.
**                        wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                          wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN 'G1'.
**                        wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_2-geo_code."is_vbak-zz1_gid_7_sdh.
**                        wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_2-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                        wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_2-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                        wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_2-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                        IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                          wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_2-dummy_val.
**                        ENDIF.
**                      WHEN OTHERS.
**                    ENDCASE.
***                step 1
**                    READ TABLE lt_hierarchy_tab
**                INTO DATA(ls_hierarchy_tab_1)
**                 WITH  KEY  geo_level = ls_hierarchy_tab_2-parent_geo_level
**                     div = wa_knvv-spart
**                     cust_grp = wa_knvv-kvgr1.
**                    IF sy-subrc = 0.
**
**                      CASE ls_hierarchy_tab_1-geo_level .
**                        WHEN  'G7' .
**
**                          wa_final-zz1_gid_7_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g7_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l7_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_7_sdh IS INITIAL .
**                            wa_final-zz1_lid_7_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G6'.
**                          wa_final-zz1_gid_6_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g6_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l6_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_6_sdh IS INITIAL .
**                            wa_final-zz1_lid_6_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G5'.
**                          wa_final-zz1_gid_5_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g5_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l5_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_5_sdh IS INITIAL .
**                            wa_final-zz1_lid_5_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G4'.
**
**                          wa_final-zz1_gid_4_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g4_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l4_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_4_sdh IS INITIAL .
**                            wa_final-zz1_lid_4_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G3'.
**                          wa_final-zz1_gid_3_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g3_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l3_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_3_sdh IS INITIAL .
**                            wa_final-zz1_lid_3_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G2'.
**                          wa_final-zz1_gid_2_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**
**                          wa_final-zz1_g2_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l2_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**                          IF wa_final-zz1_lid_2_sdh IS INITIAL .
**                            wa_final-zz1_lid_2_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**                        WHEN 'G1'.
**                          wa_final-zz1_gid_1_sdh    =  ls_hierarchy_tab_1-geo_code."is_vbak-zz1_gid_7_sdh.
**                          wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_1-position_id. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_g1_d_sdh    = ls_hierarchy_tab_1-geo_desc. "is_vbak-zz1_lid_7_sdh.
**                          wa_final-zz1_l1_d_sdh    = ls_hierarchy_tab_1-posid_desc. "is_vbak-zz1_lid_7_sdh.
**
**                          IF wa_final-zz1_lid_1_sdh IS INITIAL .
**                            wa_final-zz1_lid_1_sdh    = ls_hierarchy_tab_1-dummy_val.
**                          ENDIF.
**
**                        WHEN OTHERS.
**                      ENDCASE.
**                    ENDIF.
**                  ENDIF.
**                ENDIF.
**              ENDIF.
**            ENDIF.
**          ENDIF.
**        ENDIF.
**      ENDIF.
**    "ENDIF.
*    endloop.
**     ended By Archna Gupta on 18.03.2026




*    LOOP AT it_vbak INTO DATA(wa_vbak).
*      READ TABLE it_vbak INTO wa_vbak WITH KEY vbeln = wa_vbak.
*      IF sy-subrc = 0.
*        wa_final-zz1_lid_1_sdh   =   wa_vbak-zz1_lid_1_sdh.
*        wa_final-zz1_l1_d_sdh    =   wa_vbak-zz1_l1_d_sdh.
*        wa_final-zz1_lid_2_sdh   =   wa_vbak-zz1_lid_2_sdh.
*        wa_final-zz1_l2_d_sdh    =   wa_vbak-zz1_l2_d_sdh.
*        wa_final-zz1_lid_3_sdh   =   wa_vbak-zz1_lid_3_sdh.
*        wa_final-zz1_l3_d_sdh    =   wa_vbak-zz1_l3_d_sdh.
*        wa_final-zz1_lid_4_sdh   =   wa_vbak-zz1_lid_4_sdh.
*        wa_final-zz1_l4_d_sdh    =   wa_vbak-zz1_l4_d_sdh.
*        wa_final-zz1_lid_5_sdh   =   wa_vbak-zz1_lid_5_sdh.
*        wa_final-zz1_l5_d_sdh    =   wa_vbak-zz1_l5_d_sdh.
*        wa_final-zz1_lid_6_sdh   =   wa_vbak-zz1_lid_6_sdh.
*        wa_final-zz1_l6_d_sdh    =   wa_vbak-zz1_l6_d_sdh.
*        wa_final-zz1_lid_7_sdh   =   wa_vbak-zz1_lid_7_sdh.
*        wa_final-zz1_l7_d_sdh    =   wa_vbak-zz1_l7_d_sdh.
*        wa_final-zz1_gid_1_sdh   =   wa_vbak-zz1_gid_1_sdh.
*        wa_final-zz1_g1_d_sdh    =   wa_vbak-zz1_g1_d_sdh.
*        wa_final-zz1_gid_2_sdh   =   wa_vbak-zz1_gid_2_sdh.
*        wa_final-zz1_g2_d_sdh    =   wa_vbak-zz1_g2_d_sdh.
*        wa_final-zz1_gid_3_sdh   =   wa_vbak-zz1_gid_3_sdh.
*        wa_final-zz1_g3_d_sdh    =   wa_vbak-zz1_g3_d_sdh.
*        wa_final-zz1_gid_4_sdh   =   wa_vbak-zz1_gid_4_sdh.
*        wa_final-zz1_g4_d_sdh    =   wa_vbak-zz1_g4_d_sdh.
*        wa_final-zz1_gid_5_sdh   =   wa_vbak-zz1_gid_5_sdh.
*        wa_final-zz1_g5_d_sdh    =   wa_vbak-zz1_g5_d_sdh.
*        wa_final-zz1_gid_6_sdh   =   wa_vbak-zz1_gid_6_sdh.
*        wa_final-zz1_g6_d_sdh    =   wa_vbak-zz1_g6_d_sdh.
*        wa_final-zz1_gid_7_sdh   =   wa_vbak-zz1_gid_7_sdh.
*        wa_final-zz1_g7_d_sdh    =   wa_vbak-zz1_g7_d_sdh.
*      ENDIF.
*      "APPEND wa_final TO it_final.
*      clear: wa_vbak.
*    ENDLOOP.
    """"""""""""""""""""""""""""Ended by Archna Gupta on 06.03.2026
    IF v_all = 'X'.
      IF wa_vbap-kbmeng GT v_dlfimg AND v_dlfimg IS NOT INITIAL.
        wa_final-lights = 2.
      ELSEIF wa_vbap-kbmeng EQ v_dlfimg AND wa_vbap-kbmeng IS NOT INITIAL.
        wa_final-lights = 3.
      ELSE.
        wa_final-lights = 1.
      ENDIF.
      IF wa_final-4bezei IS NOT INITIAL.
        wa_final-line_color = 'C601'.
      ENDIF.
      APPEND wa_final TO it_final.
    ENDIF.

    IF v_rem = 'X'.
      IF v_dlfimg IS INITIAL OR v_dvbeln1 IS INITIAL.
        wa_final-lights = 1.
        IF wa_final-4bezei IS NOT INITIAL.
          wa_final-line_color = 'C410'.
        ENDIF.
        APPEND wa_final TO it_final.
      ENDIF.
    ENDIF.

    IF v_par = 'X'.
      IF wa_vbap-kbmeng GT v_dlfimg AND v_dlfimg IS NOT INITIAL.
        wa_final-lights = 2.
        IF wa_final-4bezei IS NOT INITIAL.
          wa_final-line_color = 'C410'.
        ENDIF.
        APPEND wa_final TO it_final.
      ENDIF.
    ENDIF.

    IF v_com = 'X'.
      IF wa_vbap-kbmeng EQ v_dlfimg AND v_dvbeln1 IS NOT INITIAL.
        wa_final-lights = 3.
        IF wa_final-4bezei IS NOT INITIAL.
          wa_final-line_color = 'C410'.
        ENDIF.
        APPEND wa_final TO it_final.
      ENDIF.
    ENDIF.
    CLEAR :wa_final,wa_vbap,wa_lips,wa_stock,"wa_tvagt,wa_t178t,wa_tvm1t,wa_tvakt,
    v_dlfimg,v_dvbeln1,v_dlfimg1,v_invquan."wa_tvkbt,wa_t005u,
*           wa_knkk,wa_knvv.
  ENDLOOP.

  IF it_final IS NOT INITIAL.
    SELECT vbeln, posnr, parvw, kunnr
      INTO TABLE @DATA(lt_vbpa)
      FROM vbpa
      FOR ALL ENTRIES IN @it_final
      WHERE vbeln = @it_final-vbeln
        AND parvw = 'WE'.

    IF lt_vbpa[] IS NOT INITIAL.
      SELECT kunnr, name1, name2
        INTO TABLE @DATA(lt_kna1)
        FROM kna1
        FOR ALL ENTRIES IN @lt_vbpa
        WHERE kunnr = @lt_vbpa-kunnr.
    ENDIF.

    SELECT vbeln, posnr, inco1, inco2, kursk, bstkd, bstdk
      INTO TABLE @DATA(lt_vbkd)
      FROM vbkd
      FOR ALL ENTRIES IN @it_final
      WHERE vbeln = @it_final-vbeln.

    SELECT matnr, vkorg,vtweg, aumng
      INTO TABLE @DATA(lt_mvke)
      FROM mvke
      FOR ALL ENTRIES IN @it_final
      WHERE matnr = @it_final-matnr
        AND vkorg = @it_final-vkorg
        AND vtweg = @it_final-vtweg.

    SELECT matnr, brgew
      INTO TABLE @DATA(lt_mara)
      FROM mara
      FOR ALL ENTRIES IN @it_final
      WHERE matnr = @it_final-matnr.



* Quick Fix Replace KONV table access with the access of compatibility view V_KONV
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*    SELECT knumv, kposn, kschl, krech, kbetr, waers, kstat, kwert, mwsk1
*       FROM konv
*       INTO TABLE @DATA(it_konv)
*       FOR ALL ENTRIES IN @it_final
*       WHERE knumv EQ @it_final-knumv AND
*             kinak EQ ' '           AND
*             kposn EQ @it_final-posnr AND
*             kschl IN ('ZMAT','ZMND','ZCAD','ZCND','JOIG','JOCG','JOSG','ZCAD','ZINS','ZFRT','ZIIG','ZICG','ZISG','ZFIG','ZFCG','ZFSG','YMND','JTC1')  ."JTC1 Condition Added by Raj on 27.10.2023

   SELECT FROM v_konv FIELDS knumv , kposn , kschl , krech , kbetr , waers , kstat , kwert , mwsk1 FOR ALL ENTRIES IN @it_final WHERE knumv EQ @it_final-knumv AND kinak EQ ' ' AND kposn EQ @it_final-posnr AND kschl IN ( 'ZMAT' , 'ZMND' , 'ZCAD' , 'ZCND' ,
   'JOIG'
   ,
   'JOCG'
   ,
   'JOSG'
   ,
   'ZCAD'
   ,
   'ZINS'
   ,
   'ZFRT'
   ,
   'ZIIG'
   ,
   'ZICG'
   ,
   'ZISG'
   ,
   'ZFIG'
   ,
   'ZFCG'
   ,
   'ZFSG'
   ,
   'YMND'
   ,
   'JTC1'
   )
   INTO
   TABLE
   @DATA(it_konv) ."JTC1 Condition Added by Raj on 27.10.2023

* End of Quick Fix


    IF sy-subrc = 0.
      SORT it_konv BY knumv kposn.
    ENDIF.

    SELECT werks, name1 INTO TABLE @DATA(lt_t001w)
       FROM t001w FOR ALL ENTRIES IN @it_final
      WHERE werks = @it_final-werks.

  ENDIF.

  DATA:v_vbeln TYPE thead-tdname.
  DATA:it_line TYPE TABLE OF tline,
       wa_line TYPE tline.
  DATA:v_header(100) TYPE c.

  LOOP AT it_final ASSIGNING FIELD-SYMBOL(<fs_final>).
    v_vbeln = <fs_final>-vbeln.

    CALL FUNCTION 'READ_TEXT'
      EXPORTING
*       CLIENT                  = SY-MANDT
        id                      = '0002'
        language                = 'E'
        name                    = v_vbeln
        object                  = 'VBBK'
      TABLES
        lines                   = it_line
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.

    IF it_line IS NOT INITIAL.
      LOOP AT it_line INTO wa_line.
        CONCATENATE v_header wa_line-tdline INTO v_header SEPARATED BY space.
        CLEAR:wa_line.
      ENDLOOP.
      <fs_final>-headernote1 = v_header.
      CLEAR:v_header,v_vbeln.
      REFRESH:it_line.
    ENDIF.

    TRY .
        <fs_final>-shtpa = lt_vbpa[ vbeln = <fs_final>-vbeln ]-kunnr.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-shtpd = lt_kna1[ kunnr = <fs_final>-shtpa ]-name1.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-bstkd = lt_vbkd[ vbeln = <fs_final>-vbeln ]-bstkd. " Party Order No
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-bstdk = lt_vbkd[ vbeln = <fs_final>-vbeln ]-bstdk. " Party Order Date
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-kurrf = lt_vbkd[ vbeln = <fs_final>-vbeln ]-kursk. " Party Order Date
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-inco1 = lt_vbkd[ vbeln = <fs_final>-vbeln ]-inco1. " Incoterms
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
    TRY .
        <fs_final>-inco2 = lt_vbkd[ vbeln = <fs_final>-vbeln ]-inco2. " Incoterms
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    TRY .
        <fs_final>-aumng = lt_mvke[ matnr = <fs_final>-matnr
                                    vkorg = <fs_final>-vkorg
                                    vtweg = <fs_final>-vtweg ]-aumng.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
    IF <fs_final>-aumng NE 0.
      <fs_final>-noofb = <fs_final>-remqty / <fs_final>-aumng.
      <fs_final>-noofb1 = <fs_final>-dlfimg1 / <fs_final>-aumng.
    ENDIF.

    TRY .
        <fs_final>-grswt = lt_mara[ matnr = <fs_final>-matnr ]-brgew * <fs_final>-remqty. " Gross Weight
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    READ TABLE it_konv INTO DATA(wa_konv1)
      WITH KEY knumv = <fs_final>-knumv
               kposn = <fs_final>-posnr.
    IF sy-subrc = 0.
      lv_index = sy-tabix.
      LOOP AT it_konv INTO DATA(wa_konv) FROM lv_index.
        IF wa_konv-knumv <> <fs_final>-knumv
          OR wa_konv-kposn <> <fs_final>-posnr.
          EXIT.
        ENDIF.

        CASE wa_konv-kschl.
          WHEN 'ZMAT' OR 'ZMA1' OR 'ZMA2'.
            IF wa_konv-krech = 'A'.
              <fs_final>-discper = wa_konv-kbetr / 10.
            ENDIF.
            IF <fs_final>-waerk EQ 'INR'.
              <fs_final>-fixed_disamt  = <fs_final>-fixed_disamt + wa_konv-kwert.
            ELSE.
              <fs_final>-fixed_disamt  = <fs_final>-fixed_disamt + ( wa_konv-kwert * <fs_final>-kurrf ).
            ENDIF.

          WHEN 'ZMND' OR 'ZCAD' OR 'ZCND'.
            IF wa_konv-krech = 'A'.
              <fs_final>-mdiscper = wa_konv-kbetr / 10.
            ENDIF.
            IF <fs_final>-waerk EQ 'INR'.
              <fs_final>-spl_disamt  = wa_konv-kwert.
            ELSE.
              <fs_final>-spl_disamt  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZINS'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
              <fs_final>-zins  = <fs_final>-zins  + wa_konv-kwert.
            ELSE.
              <fs_final>-zins  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZFRT'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
              <fs_final>-zfrt  = <fs_final>-zfrt  + wa_konv-kwert.
            ELSE.
              <fs_final>-zfrt  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'JOCG' .                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*             <fs_final>-jocgp = gi_konv-kbetr / 10.
              <fs_final>-jocg  =  <fs_final>-jocg + wa_konv-kwert.
            ELSE.
              <fs_final>-jocg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZICG' .                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*             <fs_final>-jocgp = gi_konv-kbetr / 10.
              <fs_final>-zicg  =  <fs_final>-zicg + wa_konv-kwert.
            ELSE.
              <fs_final>-zicg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN  'ZFCG'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*             <fs_final>-jocgp = gi_konv-kbetr / 10.
              <fs_final>-zfcg  =  <fs_final>-zfcg + wa_konv-kwert.
            ELSE.
              <fs_final>-zfcg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.


          WHEN 'JOSG'.
            <fs_final>-josgp = wa_konv-kbetr / 10.                                      "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.

              <fs_final>-josg  = <fs_final>-josg + wa_konv-kwert.

            ELSE.
              <fs_final>-josg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZISG'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.

              <fs_final>-zisg  = <fs_final>-zisg + wa_konv-kwert.

            ELSE.
              <fs_final>-zisg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN  'ZFSG'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.

              <fs_final>-zfsg  = <fs_final>-zfsg + wa_konv-kwert.

            ELSE.
              <fs_final>-zfsg  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'JOIG' .
            <fs_final>-joigp = wa_konv-kbetr / 10.                                       "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.

              <fs_final>-joig  =  <fs_final>-joig + wa_konv-kwert.

            ELSE.
              <fs_final>-joig  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZIIG' .                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*            gw_data-josgp = gi_konv-kbetr / 10.
              <fs_final>-ziig  =  <fs_final>-ziig + wa_konv-kwert.

            ELSE.
              <fs_final>-ziig  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'ZFIG'.                                         "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*            gw_data-josgp = gi_konv-kbetr / 10.
              <fs_final>-zfig  =  <fs_final>-zfig + wa_konv-kwert.

            ELSE.
              <fs_final>-zfig  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.

          WHEN 'YMND'.
            IF wa_konv-krech = 'A'.
              <fs_final>-mandisper = wa_konv-kbetr / 10.
            ENDIF.

            "EXP INS.
            IF <fs_final>-waerk EQ 'INR'.
*            gw_data-josgp = gi_konv-kbetr / 10.
              <fs_final>-ymnd  =  <fs_final>-ymnd + wa_konv-kwert.

            ELSE.
              <fs_final>-ymnd  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.
**************************Added by Raj on 27.10.2023**********************
          WHEN 'JTC1'.       "TCS
            IF <fs_final>-waerk EQ 'INR'.
*            gw_data-josgp = gi_konv-kbetr / 10.
              <fs_final>-ztcs  =  <fs_final>-ztcs + wa_konv-kwert.

            ELSE.
              <fs_final>-ztcs  = wa_konv-kwert * <fs_final>-kurrf.
            ENDIF.
************************Added by Raj on 27.10.2023**************************


        ENDCASE.
      ENDLOOP.
    ENDIF.
    <fs_final>-ordvalu1 = <fs_final>-ordvalu * <fs_final>-kurrf.
    <fs_final>-netwr1   = <fs_final>-netwr *  <fs_final>-kurrf.
    TRY .
        <fs_final>-desc = lt_t001w[ werks = <fs_final>-werks ]-name1.
      CATCH cx_sy_itab_line_not_found.

    ENDTRY.

    IF <fs_final>-kwmeng <> '0'.
      v_price = <fs_final>-netwr / <fs_final>-kwmeng.
    ENDIF.
    IF v_price IS NOT INITIAL.
      <fs_final>-delnetwr = <fs_final>-dlfimg * v_price.
      <fs_final>-pginetwr = <fs_final>-dlfimg1 * v_price.
      <fs_final>-invnetwr = <fs_final>-invquan * v_price.
    ENDIF.
    IF  NOT <fs_final>-dlfimg1 IS INITIAL.
      <fs_final>-pgival = <fs_final>-netwr.
    ENDIF.

    IF <fs_final>-josgp IS NOT INITIAL.
      <fs_final>-josgp = <fs_final>-josgp * 2.
      v_gsttotal = ( <fs_final>-pginetwr + <fs_final>-ordvalu ) * ( <fs_final>-josgp ) / 100.
      <fs_final>-gsttotal = ( v_gsttotal + <fs_final>-pginetwr + <fs_final>-ordvalu ).
      CLEAR: v_gsttotal.
    ENDIF.
    IF <fs_final>-joigp IS NOT INITIAL.
      v_gsttotal = ( <fs_final>-pginetwr + <fs_final>-ordvalu ) * ( <fs_final>-joigp ) / 100.
      <fs_final>-gsttotal = ( v_gsttotal + <fs_final>-pginetwr + <fs_final>-ordvalu ).
      CLEAR: v_gsttotal.
    ENDIF.






  ENDLOOP.



  ""Added by Ranjan

  DATA(lt_temp) = it_final.
  CLEAR it_final.


  LOOP AT lt_temp ASSIGNING FIELD-SYMBOL(<fs_auth_check>).
    AUTHORITY-CHECK OBJECT 'ZKVGR1'
      ID 'KVGR1' FIELD <fs_auth_check>-kvgr1
      ID 'ACTVT' FIELD '03'.

    IF sy-subrc = 0.
      APPEND <fs_auth_check> TO it_final.
    ENDIF.
  ENDLOOP.

  ""EOC by Ranjan

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_FCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM build_fcat .

  SELECT sign, opti, low, high
    INTO TABLE @DATA(lt_acc_key1)
    FROM tvarvc
    WHERE name = @c_credit_user AND
          type = @c_credit_user_s.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'VBELN'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Order No'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 2.  wa_fcat-fieldname = 'POSNR'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Item'.
  wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 3.  wa_fcat-fieldname = 'BEZEI1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Order Type'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 4.  wa_fcat-fieldname = 'TEXT1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Order Status'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = 'ABGRU'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Rejection Code'. " ABGRU
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = '4BEZEI'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Reason for Rejection'. " ABGRU
  wa_fcat-outputlen = '40'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 6.  wa_fcat-fieldname = 'WERKS'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Plant'.
  wa_fcat-outputlen = '5'. wa_fcat-ref_fieldname = 'WERKS'.wa_fcat-ref_tabname = 'VBAP'.APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 7.  wa_fcat-fieldname = 'MATNR'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Material'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 8.  wa_fcat-fieldname = 'ARKTX'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Material Description'.
  wa_fcat-outputlen = '25'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 9.  wa_fcat-fieldname = 'VKORG'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales Org'.
  wa_fcat-outputlen = '10'. wa_fcat-ref_fieldname = 'VKORG'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 10.  wa_fcat-fieldname = 'VTWEG'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Dist Ch.'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'VTWEG'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 11.  wa_fcat-fieldname = 'SPART'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Div.'.
  wa_fcat-outputlen = '4'. wa_fcat-ref_fieldname = 'SPART'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 12.  wa_fcat-fieldname = 'VKBUR'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales Office'.
  wa_fcat-outputlen = '10'. wa_fcat-ref_fieldname = 'VKBUR'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 12.  wa_fcat-fieldname = 'SOFFICE'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales Office Desc'.
  wa_fcat-outputlen = '10'. wa_fcat-ref_fieldname = 'SOFFICE'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 13.  wa_fcat-fieldname = 'KUNNR'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sold to Party'.
  wa_fcat-outputlen = '15'. wa_fcat-ref_fieldname = 'KUNNR'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 5.  wa_fcat-fieldname = 'BEZEI4'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'pricing group Description'. " ABGRU
  wa_fcat-outputlen = '40'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*Customer Name
  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'NAME1'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Customer Name'.
  wa_fcat-outputlen = '20'. wa_fcat-ref_fieldname = 'NAME1'.wa_fcat-ref_tabname = 'KNA1'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'REGIO'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sold to region'.
  wa_fcat-outputlen = '20'. wa_fcat-ref_fieldname = 'REGIO'.wa_fcat-ref_tabname = 'KNA1'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

**Customer Group ""Added by Bhaumik|02.04.26|DEVK900996
  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'KVGR1'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Customer Group 1'.
  wa_fcat-outputlen = '5'. wa_fcat-ref_fieldname = 'KVGR1'.wa_fcat-ref_tabname = 'KNVV'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'KVGR2'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Customer Group 2'.
  wa_fcat-outputlen = '5'. wa_fcat-ref_fieldname = 'KVGR2'.wa_fcat-ref_tabname = 'KNVV'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
********

  wa_fcat-col_pos = 15.  wa_fcat-fieldname = 'NETWR'.    wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Price(OC)'.
  wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

************** Added by Carina Jose on 08/07/2021
  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME6'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L6 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME6'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L6 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME5'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L5 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME5'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L5 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME4'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L4 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME4'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L4 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME3'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L3 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME3'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L3 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME2'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L2 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME2'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L2 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'CLNAME1'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current L1 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'LNAME1'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L1 Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'ZONE'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Zone'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'SZONE'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sub zone'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
**************** End of changes by Carina Jose on 08/07/2021

*********************** added by parth 20.01.2022
  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'VKGRP'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales Group'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'VKGRP_TXT'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales Group Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'BZIRK'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales District'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 14.  wa_fcat-fieldname = 'BZTXT'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Sales District Name'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*************



  wa_fcat-col_pos = 15.  wa_fcat-fieldname = 'NETWR1'.    wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Price(INR)'.
  wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 16.  wa_fcat-fieldname = 'WAERK'. wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Order Curr.'.
  wa_fcat-outputlen = '4'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 17.  wa_fcat-fieldname = 'ERDAT'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Order Date'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 17.  wa_fcat-fieldname = 'CHANDT'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  ' Authorize Date'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 17.  wa_fcat-fieldname = 'WADAT_IST'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Actual GI Date'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 18.  wa_fcat-fieldname = 'ERZET'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Order Time'.
  wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 19.  wa_fcat-fieldname = 'KWMENG'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Order Qty'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 20.  wa_fcat-fieldname = 'KBMENG'.      wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Conf. Qty.'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*WA_FCAT-COL_POS = 16.  WA_FCAT-FIELDNAME = 'VRKME'.       WA_FCAT-TABNAME = 'IT_FINAL'. WA_FCAT-SELTEXT_M =  'UOM'.
*WA_FCAT-OUTPUTLEN = '4'.  APPEND WA_FCAT TO IT_FCAT. CLEAR WA_FCAT.

  wa_fcat-col_pos = 21.  wa_fcat-fieldname = 'DLFIMG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Delivered Qty'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 21.  wa_fcat-fieldname = 'DELNETWR'.   wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Delivered Price'.
  wa_fcat-emphasize = ' '. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'DLFIMG1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'PGI Pending Qty'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '16'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'PGINETWR'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'PGI Pending Value'.
  wa_fcat-emphasize = ' '. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

**** Added Incoterms field by Carina Jose on 25.02.2022
  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'INCO1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Incoterms'.
  wa_fcat-emphasize = ' '. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'INCO2'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Incoterms Desc.'.
  wa_fcat-emphasize = ' '. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
**** End of changes by Carina Jose on 25.02.2022

  wa_fcat-col_pos = 20.
  wa_fcat-fieldname = 'INVQUAN'.
  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-seltext_l =  'Pending Invoice Qty'.
  wa_fcat-emphasize = 'C1'.
  wa_fcat-outputlen = '16'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-col_pos = 20.
  wa_fcat-fieldname = 'INVNETWR'.
  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-seltext_l =  'Pending Invoice Price'.
  wa_fcat-emphasize = ' '.
  wa_fcat-outputlen = '12'.
  APPEND wa_fcat TO it_fcat.
  CLEAR wa_fcat.

  wa_fcat-col_pos = 23.  wa_fcat-fieldname = 'REMQTY'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Rem. Qty'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 23.  wa_fcat-fieldname = 'ORDVALU'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Pending Order Value(OC)'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 23.  wa_fcat-fieldname = 'ORDVALU1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Pending Order Value(INR)'.
  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*  wa_fcat-col_pos = 22.  wa_fcat-fieldname = 'PGIVAL'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'PGI Pending Value'.
*  wa_fcat-emphasize = 'C1'. wa_fcat-outputlen = '16'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*



  wa_fcat-col_pos = 24.  wa_fcat-fieldname = 'DMEINS'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'UOM'.
  wa_fcat-outputlen = '4'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 25.  wa_fcat-fieldname = 'DVBELN'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Delivery No'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 26.  wa_fcat-fieldname = 'DERDAT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Delivery Date'.
  wa_fcat-outputlen = '14'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 27.  wa_fcat-fieldname = 'DERZET'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Delivery Time'.
  wa_fcat-outputlen = '14'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*WA_FCAT-COL_POS = 22.  WA_FCAT-FIELDNAME = 'REMQTY'.     WA_FCAT-TABNAME = 'IT_FINAL'. WA_FCAT-SELTEXT_L =  'Rem. Qty'.
*WA_FCAT-EMPHASIZE = 'C1'. WA_FCAT-OUTPUTLEN = '10'. APPEND WA_FCAT TO IT_FCAT. CLEAR WA_FCAT.

  wa_fcat-col_pos = 28.  wa_fcat-fieldname = 'STOCK'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Stock'.
  wa_fcat-emphasize = 'C3'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'STOCK_R'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Rcl Stock '.
  wa_fcat-emphasize = 'C3'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 29.  wa_fcat-fieldname = 'MATKL'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Material Group'.
  wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 30.  wa_fcat-fieldname = 'VTEXT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Price Group'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 31.  wa_fcat-fieldname = 'BEZEI'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Segment Group'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 32.  wa_fcat-fieldname = 'SHTPA'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Ship To Party'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 33.  wa_fcat-fieldname = 'SHTPD'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Ship To Party Desc'.
  wa_fcat-outputlen = '40'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 34.  wa_fcat-fieldname = 'BSTKD'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Party Order No'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 35.  wa_fcat-fieldname = 'BSTDK'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Party Order Date'.
  wa_fcat-outputlen = '40'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 36.  wa_fcat-fieldname = 'AUMNG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Standard Packing No'.
  wa_fcat-outputlen = '30'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 37.  wa_fcat-fieldname = 'NOOFB'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'No.OF Boxes'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 38.  wa_fcat-fieldname = 'NOOFB1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'No.OF Boxes (PGI PENDING)'.
  wa_fcat-outputlen = '20'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 39.  wa_fcat-fieldname = 'GRSWT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Gross Weight'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 40.  wa_fcat-fieldname = 'HEADERNOTE1'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_l =  'Header Note'.
  APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 41.  wa_fcat-fieldname = 'DESC'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Plant DESC'.
  wa_fcat-outputlen = '5'. wa_fcat-ref_fieldname = 'NAME1'.wa_fcat-ref_tabname = 'T001W'.APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 42.  wa_fcat-fieldname = 'DISCPER'.    wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Fix Discount %'.
  wa_fcat-outputlen = '15'.  wa_fcat-ref_fieldname = 'NAME1'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 42.  wa_fcat-fieldname = 'FIXED_DISAMT'.    wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Fix Discount'.
  wa_fcat-outputlen = '15'.  wa_fcat-ref_fieldname = 'NAME1'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.




  wa_fcat-col_pos = 43.  wa_fcat-fieldname = 'MDISCPER'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Special Discount %'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*  ***********************************Added by Raj on 05.06.2023*******
  wa_fcat-col_pos = 43.  wa_fcat-fieldname = 'MANDISPER'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Manual Discount %'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


**************

  wa_fcat-col_pos = 43.  wa_fcat-fieldname = 'SPL_DISAMT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Special Discount'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'ZINS'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'INSURANCE'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'ZFRT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'FRIGHT'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'JOCG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'CGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


*  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'JOCG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'CGST'.
*  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'ZICG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'INSURANCE CGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 44.  wa_fcat-fieldname = 'ZFCG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'FRIGHT CGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*
  wa_fcat-col_pos = 45.  wa_fcat-fieldname = 'JOSG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'SGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 45.  wa_fcat-fieldname = 'ZISG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'INSURANCE SGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 45.  wa_fcat-fieldname = 'ZFSG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'FRIGHT SGST'.
  wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
*
  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'JOIG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'IGST'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'ZIIG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'INSURANCE IGST'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'ZFIG'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'FRIGHT IGST'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

* *********************************************************************Added by Raj on 05.06.2023********
  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'YMND'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'MANUAL DISCOUNT'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
* *********************************************************************Added by Raj on 05.06.2023********

  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'GSTTOTAL'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GST TOTAL'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 47.  wa_fcat-fieldname = 'PRCTR'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'PROFIT CENTER'.
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 48.  wa_fcat-fieldname = 'ZZTCODE'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Tcode'.            " Added by Gokul 30.05.2023
  wa_fcat-outputlen = '15'. wa_fcat-ref_fieldname = 'ZZTCODE' .wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 49.  wa_fcat-fieldname = 'ZZSYDATE'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'System Date'.     " Added by Gokul 30.05.2023
  wa_fcat-outputlen = '15'. wa_fcat-ref_fieldname = 'ZZSYDATE'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZSY_TIME'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'System Time'.    " Added by Gokul 30.05.2023
  wa_fcat-outputlen = '15'. wa_fcat-ref_fieldname = 'ZZSY_TIME'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZNAME'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'User name'.    " Added by Gokul 30.05.2023
  wa_fcat-outputlen = '15'. wa_fcat-ref_fieldname = 'ZZNAME'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 46.  wa_fcat-fieldname = 'ZTCS'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'TCS'."Added by Raj on 27.10.2023
  wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

**  Start Added By Archna Gupta on 03.06.2026
  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_1_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_1'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_1_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L1_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L1_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L1_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_2_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_2'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_2_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L2_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L2_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L2_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_3_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_3'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_3_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L3_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L3_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L3_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_4_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_4'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_4_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L4_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L4_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L4_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_5_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_5'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_5_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L5_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L5_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L5_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_6_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_6'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_6_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L6_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L6_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L6_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_LID_7_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'LID_7'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_LID_7_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_L7_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'L7_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_L7_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_1_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_1'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_1_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G1_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G1_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G1_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_2_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_2'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_2_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G2_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G2_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G2_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_3_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_3'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_3_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G3_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G3_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G3_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_4_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_4'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_4_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G4_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G4_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G4_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.


  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_5_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_5'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_5_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G5_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G5_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G5_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_6_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_6'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_6_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G6_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G6_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G6_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_GID_7_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'GID_7'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_GID_7_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

  wa_fcat-col_pos = 50.  wa_fcat-fieldname = 'ZZ1_G7_D_SDH'.  wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'G7_D'.
  wa_fcat-outputlen = '8'. wa_fcat-ref_fieldname = 'ZZ1_G7_D_SDH'.wa_fcat-hotspot = 'X'.wa_fcat-ref_tabname = 'VBAK'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.



**Ended by Archna Gupta on 03.06.2026

  LOOP AT lt_acc_key1 INTO DATA(lwa_acc_key1).
    IF sy-uname = lwa_acc_key1-low.
      wa_fcat-col_pos = 51.  wa_fcat-fieldname = 'KLIMK'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Customer credit limit'.
      wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

      wa_fcat-col_pos = 52.  wa_fcat-fieldname = 'SKFOR'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Current Balance '.
      wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

      wa_fcat-col_pos = 53.  wa_fcat-fieldname = 'LIMIT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Avl.Limit'.
      wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

      wa_fcat-col_pos = 54.  wa_fcat-fieldname = 'ZTERM'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Payment terms'.
      wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.

*      wa_fcat-col_pos = 51.  wa_fcat-fieldname = 'ITEXT'.     wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Debit/Credit'.
*      wa_fcat-outputlen = '15'.APPEND wa_fcat TO it_fcat. CLEAR wa_fcat.
    ENDIF.
  ENDLOOP.


  wa_layout-zebra = 'X'.
  wa_layout-lights_fieldname = 'LIGHTS'.
  wa_layout-info_fieldname =   'LINE_COLOR'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM display_alv .

  IF v_rem EQ 'X'.
    DELETE it_final WHERE abgru IS NOT INITIAL.
  ENDIF.

  SORT it_final BY erdat.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
      i_callback_top_of_page  = 'TOP_PAGE'
      i_callback_user_command = 'INTERACTIVE'
      i_save                  = 'A'
      is_layout               = wa_layout
      it_fieldcat             = it_fcat
    TABLES
      t_outtab                = it_final
    EXCEPTIONS
      program_error           = 1
      OTHERS                  = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.

FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).
  DATA : v_matkl(300).

  wa_header-typ = 'H'.
  IF v_all = 'X'.
    wa_header-info = 'All Sales Orders'.
  ELSEIF v_com = 'X'.
    wa_header-info = 'Completed Sales Orders'.
  ELSEIF v_par = 'X'.
    wa_header-info = 'Partially Completed Sales Orders'.
  ELSEIF v_rem = 'X'.
    wa_header-info = 'Remaining Sales Orders'.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_date-high IS INITIAL.
    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
    CONCATENATE s_date-high+6(2) '-' s_date-high+4(2) '-' s_date-high+0(4) INTO v_highdate.
    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
  ELSE.
    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
    LOOP AT s_date.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_date-low IS INITIAL.
          CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Date :- ' v_lowdate INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CLEAR : v_lowdate,v_highdate.

  wa_header-typ = 'S'.
  IF NOT s_werks-high IS INITIAL.
    CONCATENATE 'Plant :- ' s_werks-low  ' TO ' s_werks-high INTO wa_header-info SEPARATED BY space.
  ELSE.
    LOOP AT s_werks.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_werks-low IS INITIAL.
          CONCATENATE wa_header-info ',' s_werks-low INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Plant :- ' s_werks-low INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.


  wa_header-typ = 'S'.
  IF  v_matkl IS NOT INITIAL.
    CONCATENATE 'No authorization for material groups :' v_matkl INTO wa_header-info.
    APPEND wa_header TO it_header.
    CLEAR: wa_header, v_matkl.
  ENDIF.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'  "Uncommented by Raj on 12.07.2023
    EXPORTING
      it_list_commentary = it_header
      i_logo             = 'ASTRALS'.

ENDFORM.

FORM interactive USING r_ucomm TYPE sy-ucomm
                       selfield TYPE slis_selfield.
  CLEAR wa_final.
  CHECK r_ucomm = '&IC1'. "User Double Clicked on Some field

  CHECK NOT selfield-value IS INITIAL.

  CASE selfield-fieldname.
    WHEN 'VBELN'.
      READ TABLE it_final INDEX selfield-tabindex INTO wa_final.
      SET PARAMETER ID 'AUN' FIELD wa_final-vbeln.
      CALL TRANSACTION 'VA03' AND SKIP FIRST SCREEN.
  ENDCASE.

ENDFORM.
