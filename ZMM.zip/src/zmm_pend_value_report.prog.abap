*&---------------------------------------------------------------------*
*& Report  ZMM_RGP_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zmm_pend_value_report.   "
INCLUDE zmm_pend_value_top. "
INCLUDE zmm_pend_value_sel.
INCLUDE zmm_pend_value_main.
