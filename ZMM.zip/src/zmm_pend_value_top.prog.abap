*&---------------------------------------------------------------------*
*&  Include           ZMM_RGP_REPORT_TOP
*&---------------------------------------------------------------------*

****************Declaration of structures******************************

TYPES : BEGIN OF ty_lfa1,
          lifnr TYPE lfa1-lifnr,
          name1 TYPE lfa1-name1,
        END OF ty_lfa1.

TYPES : BEGIN OF ty_ekko,
          ebeln TYPE ekko-ebeln,
          bedat TYPE ekko-bedat,
          lifnr TYPE ekko-lifnr,
          waers TYPE ekko-waers,
        END OF ty_ekko.

TYPES : BEGIN OF ty_makt,
          matnr TYPE makt-matnr,
          maktx TYPE makt-maktx,
        END OF ty_makt.

DATA : it_makt TYPE STANDARD TABLE OF ty_makt,
       wa_makt TYPE ty_makt.

DATA : it_makt1 TYPE STANDARD TABLE OF ty_makt,
       wa_makt1 TYPE ty_makt.
TYPES : BEGIN OF ty_ekpo,
          ebeln     TYPE ekpo-ebeln,
          ebelp     TYPE ekpo-ebelp,
          werks     TYPE ekpo-werks,
          packno    TYPE ekpo-packno,
          netwr     TYPE ekpo-netwr,
          fplnr     TYPE ekpo-fplnr,
          loekz     TYPE ekpo-loekz,
          matnr     TYPE ekpo-matnr,
          txz01     TYPE ekpo-txz01,
          menge     TYPE ekpo-menge,
          netpr     TYPE ekpo-netpr,
          matkl     TYPE ekpo-matkl,
          elikz     TYPE ekpo-elikz,  "Added by Rahul Vasita on 04.04.2024 16:18:17
          EREKZ     TYPE EKPO-EREKZ,  "Added by Raj on 11.04.2024
          knttp     TYPE  ekpo-knttp,
          lv_packno TYPE ekpo-packno,
        END OF ty_ekpo.

TYPES : BEGIN OF ty_esll,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
          extrow     TYPE esll-extrow,
          menge      TYPE esll-menge,
          srvpos     TYPE esll-srvpos,
        END OF ty_esll.

TYPES : BEGIN OF ty_mseg,
          zeile TYPE mseg-zeile,
          ebeln TYPE mseg-ebeln,
          ebelp TYPE mseg-ebelp,
          erfmg TYPE mseg-erfmg,
          dmbtr TYPE mseg-dmbtr,

        END OF ty_mseg.

TYPES : BEGIN OF ty_asmdt,
          asnum TYPE asmdt-asnum,
          asktx TYPE asmdt-asktx,
        END OF ty_asmdt.

TYPES : BEGIN OF ty_ekbe,
          ebeln TYPE ekbe-ebeln,
          ebelp TYPE ekbe-ebelp,
          bewtp TYPE ekbe-bewtp,
          belnr TYPE ekbe-belnr,
        END OF ty_ekbe.

TYPES : BEGIN OF ty_esllpa,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
        END OF ty_esllpa.

TYPES : BEGIN OF ty_esllsu,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
          netwr      TYPE esll-netwr,
          introw     TYPE esll-introw,
          extrow     TYPE esll-extrow,
          srvpos     TYPE esll-srvpos,
          tbtwr      TYPE esll-tbtwr,
          pln_introw TYPE esll-pln_introw,
          lv_packno  TYPE ekpo-packno,

        END OF ty_esllsu.


TYPES : BEGIN OF ty_asmd,
          asnum TYPE asmd-asnum,
          matkl TYPE asmd-matkl,
        END OF ty_asmd.
******************Declaration of Internal tables and work area/line type/row type***************************************

DATA : it_lfa1      TYPE STANDARD TABLE OF ty_lfa1,
       wa_lfa1      TYPE ty_lfa1,
       it_ekko      TYPE STANDARD TABLE OF ty_ekko,
       wa_ekko      TYPE ty_ekko,
       it_ekpo      TYPE STANDARD TABLE OF ty_ekpo,
       wa_ekpo      TYPE ty_ekpo,

       it_ekpo1     TYPE STANDARD TABLE OF ty_ekpo,
       wa_ekpo1     TYPE ty_ekpo,

       it_ekpo_st   TYPE STANDARD TABLE OF ty_ekpo,
       wa_ekpo_st   TYPE ty_ekpo,

       it_esll      TYPE STANDARD TABLE OF ty_esll,
       wa_esll      TYPE ty_esll,
       it_mseg      TYPE STANDARD TABLE OF ty_mseg,
       wa_mseg      TYPE ty_mseg,
       it_ekbe      TYPE STANDARD TABLE OF ty_ekbe,
       wa_ekbe      TYPE ty_ekbe,
       it_ekbe_temp TYPE STANDARD TABLE OF ty_ekbe,
       wa_ekbe_temp TYPE ty_ekbe,
       it_asmdt     TYPE STANDARD TABLE OF ty_asmdt,
       wa_asmdt     TYPE ty_asmdt,
       it_esllpa    TYPE STANDARD TABLE OF ty_esllpa,
       wa_esllpa    TYPE ty_esllpa,
       it_esllsu    TYPE STANDARD TABLE OF ty_esllsu,
       wa_esllsu    TYPE ty_esllsu,
       it_esllsurd  TYPE STANDARD TABLE OF ty_esllsu,
       wa_esllsurd  TYPE ty_esllsu,
       it_asmd      TYPE STANDARD TABLE OF ty_asmd,
       wa_asmd      TYPE ty_asmd,
       it_esllrd    TYPE STANDARD TABLE OF ty_esllpa,
       wa_esllrd    TYPE ty_esllpa,
       it_asmdrd    TYPE STANDARD TABLE OF ty_asmd,
       wa_asmdrd    TYPE ty_asmd.

TYPES : BEGIN OF ty_extrow,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
          extrow     TYPE esll-extrow,
          menge      TYPE esll-menge,
        END OF ty_extrow.

TYPES : BEGIN OF ty_esllsr,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
          extrow     TYPE esll-extrow,
          menge      TYPE esll-menge,
        END OF ty_esllsr.

DATA : it_esllsr TYPE STANDARD TABLE OF ty_esllsr,
       wa_esllsr TYPE ty_esllsr.

DATA : it_extrow TYPE STANDARD TABLE OF ty_extrow,
       wa_extrow TYPE ty_extrow.


TYPES : BEGIN OF ty_srvpos,
          packno     TYPE esll-packno,
          extrow     TYPE esll-extrow,
          sub_packno TYPE esll-sub_packno,
          srvpos     TYPE esll-srvpos,
        END OF ty_srvpos.


DATA : it_srvpos TYPE STANDARD TABLE OF ty_srvpos,
       wa_srvpos TYPE ty_srvpos.

DATA : it_srvposrd TYPE STANDARD TABLE OF ty_srvpos,
       wa_srvposrd TYPE ty_srvpos.

TYPES : BEGIN OF ty_final,
          ebeln      TYPE ekpo-ebeln,
          ebelp      TYPE ekpo-ebelp,
          werks      TYPE ekpo-werks,
          packno     TYPE ekpo-packno,
          netwr      TYPE ekpo-netwr,
          bedat      TYPE ekko-bedat,
          lifnr      TYPE ekko-lifnr,
          name1      TYPE lfa1-name1,
          erfmg      TYPE mseg-erfmg,
          dmbtr      TYPE mseg-dmbtr,
          asnum      TYPE asmdt-asnum,
          asktx      TYPE asmdt-asktx,
          bewtp      TYPE ekbe-bewtp,
          sub_packno TYPE esll-sub_packno,
          extrow     TYPE esll-extrow,
          srvpos     TYPE esll-srvpos,
          matkl      TYPE asmd-matkl,
          still_qty  TYPE  esll-menge,
          menge      TYPE esll-menge,
          net_value  TYPE esll-menge,
          pend_value TYPE esll-menge,
          fakwr      TYPE fplt-fakwr,
          wrbtr      TYPE rseg-wrbtr,
          tbtwr      TYPE esll-menge,
          rec_qty    TYPE esll-menge,
          loekz      TYPE ekpo-loekz,
          v_graph    TYPE char4,
          maktx      TYPE makt-maktx,
          netpr      TYPE ekpo-netpr,
          stblg      TYPE rbkp-stblg,
          fplnr      TYPE fplt-fplnr,
          waers      TYPE ekko-waers,
          elikz      TYPE ekpo-elikz,  "Added by Rahul Vasita on 04.04.2024 16:18:17
          erekz type ekpo-erekz,"Added  by Raj on 11.04.2024 11:58:00
        END OF ty_final.
DATA : it_final TYPE STANDARD TABLE OF ty_final,
       wa_final TYPE ty_final.
DATA :lv_value TYPE i.
DATA : lv_days TYPE char10.
DATA : lv_days1 TYPE i.


TYPES : BEGIN OF ty_fplt,
          fplnr  TYPE fplt-fplnr,
          fpltr  TYPE fplt-fpltr,
          fakwr  TYPE fplt-fakwr,
          afdat  TYPE fplt-afdat,
          index1 TYPE i,
          ebeln  TYPE ekpo-ebeln,
        END OF ty_fplt.

DATA : it_fplt TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt TYPE ty_fplt.

DATA : it_fplt_inv TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt_inv TYPE ty_fplt.


DATA : it_fplt_temp TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt_temp TYPE ty_fplt.


DATA : it_fplt_new TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt_new TYPE ty_fplt.

DATA : it_fplt_inv1 TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt_inv1 TYPE ty_fplt.


DATA : it_fplt_inv2 TYPE STANDARD TABLE OF ty_fplt,
       wa_fplt_inv2 TYPE ty_fplt.

DATA :v_fakwr TYPE fplt-fakwr.

TYPES : BEGIN OF ty_rseg,
          belnr TYPE rseg-belnr,
          ebeln TYPE rseg-ebeln,
          ebelp TYPE rseg-ebelp,
          wrbtr TYPE rseg-wrbtr,
        END OF ty_rseg.

TYPES : BEGIN OF ty_rbkp,
          belnr TYPE rbkp-belnr,
          stblg TYPE rbkp-stblg,
          budat TYPE rbkp-budat,
        END OF ty_rbkp.

DATA : it_rbkp TYPE STANDARD TABLE OF ty_rbkp,
       wa_rbkp TYPE ty_rbkp.


TYPES : BEGIN OF ty_essr,
          ebeln  TYPE essr-ebeln,
          ebelp  TYPE essr-ebelp,
          packno TYPE essr-packno,

        END OF ty_essr.

DATA : it_essr TYPE STANDARD TABLE OF ty_essr,
       wa_essr TYPE ty_essr.

TYPES : BEGIN OF ty_esllmg,
          lv_key     TYPE string,
          packno     TYPE esll-packno,
          sub_packno TYPE esll-sub_packno,
          introw     TYPE esll-introw,
          extrow     TYPE esll-extrow,
          menge      TYPE esll-menge,
          tbtwr      TYPE esll-tbtwr,
          pln_packno TYPE esll-pln_packno,
          pln_introw TYPE esll-pln_introw,
          act_menge  TYPE esll-act_menge,
          lv_amt     TYPE esll-menge,
          net_amt    TYPE esll-menge,
        END OF ty_esllmg.

DATA : it_esllmg TYPE STANDARD TABLE OF ty_esllmg,
       wa_esllmg TYPE ty_esllmg.


DATA : it_esllpln TYPE STANDARD TABLE OF ty_esllmg,
       wa_esllpln TYPE ty_esllmg.

DATA : it_rseg TYPE STANDARD TABLE OF ty_rseg,
       wa_rseg TYPE ty_rseg.
DATA :v_wrbtr TYPE rseg-wrbtr.
*DATA : it_makt TYPE STANDARD TABLE OF ty_makt,
*       wa_makt TYPE ty_makt.
*DATA : it_gate TYPE STANDARD TABLE OF ty_gate,
*       wa_gate TYPE ty_gate.
*DATA : it_mseg TYPE STANDARD TABLE OF ty_mseg,
*       wa_mseg TYPE ty_mseg.

DATA : wa_fcat TYPE slis_fieldcat_alv.
DATA : it_fcat TYPE slis_t_fieldcat_alv.
DATA : wa_layout TYPE slis_layout_alv,
       lv_grswt  TYPE brgew.
*PARAMETERS: variant LIKE disvariant-variant.
DATA : g_save      TYPE c VALUE 'X',
       g_variant   TYPE disvariant,
       g_variant1  TYPE disvariant,
       gx_variant  TYPE disvariant,
       gx_variant1 TYPE disvariant,
       g_exit      TYPE c,
       t_event     TYPE slis_t_event WITH HEADER LINE.

DATA : alv_icon TYPE char4.

alv_icon = '@0N@'.

CONSTANTS : v_menge1 TYPE char1 VALUE '1', "If Received Qty is not initial
            v_menge2 TYPE char1 VALUE '0', "If Received Qty is initial
            v_menge3 TYPE char1 VALUE '1', "If inv book is not initial
            v_menge4 TYPE char1 VALUE '0'. "If inv book is initial

TYPES : BEGIN OF ty_ekbe_inv,
          lv_key TYPE string,
          ebeln  TYPE ekbe-ebeln,
          ebelp  TYPE ekbe-ebelp,
          zekkn  TYPE ekbe-zekkn,
          belnr  TYPE ekbe-belnr,
          wrbtr  TYPE ekbe-wrbtr,
          refwr  TYPE ekbe-refwr,
          cpudt  TYPE ekbe-cpudt,
          cputm  TYPE ekbe-cputm,
          bewtp  TYPE ekbe-bewtp,
          bekkn  TYPE ekbe-bekkn,
          menge  TYPE ekbe-menge,
          lv_amt TYPE ekbe-menge,
          index1 TYPE i,
          packno TYPE ekbe-packno,
          introw TYPE ekbe-introw,
        END OF ty_ekbe_inv.

DATA : it_ekbe_inv TYPE STANDARD TABLE OF ty_ekbe_inv,
       wa_ekbe_inv TYPE ty_ekbe_inv.


DATA : it_ekbe_inv1 TYPE STANDARD TABLE OF ty_ekbe_inv,
       wa_ekbe_inv1 TYPE ty_ekbe_inv.

DATA : it_ekbe_rec TYPE STANDARD TABLE OF ty_ekbe_inv,
       wa_ekbe_rec TYPE ty_ekbe_inv.
