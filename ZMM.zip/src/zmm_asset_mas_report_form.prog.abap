*&---------------------------------------------------------------------*
*&  Include           ZMM_ASSET_MAS_REPORT_FORM
*&---------------------------------------------------------------------*


START-OF-SELECTION.

  PERFORM auth_check.
  PERFORM get_data.
  PERFORM build_fcat.
  PERFORM display_alv.



FORM auth_check.
  AUTHORITY-CHECK OBJECT 'Z_MAS_WERK'
     ID 'WERKS' FIELD s_werks-low
     ID 'ACTVT' FIELD '03'.
  IF sy-subrc NE 0.
    MESSAGE e007(zsd) WITH s_werks-low.
  ENDIF.
ENDFORM.


FORM get_data.

  IF s_ebeln IS INITIAL.

    SELECT bukrs,anln1,anln2,posnr,txt50                                                                "Asset Code,Asset Name,WBS Element
     INTO TABLE @DATA(it_anla)
     FROM anla
     WHERE bukrs IN @s_bukrs
     AND   anln1 IN @s_anln1.

    DATA(it_anla1) = it_anla.                                                            "Taking WBS entries into one duplicate internal table
    IF it_anla1 IS NOT INITIAL.
      DELETE it_anla1 WHERE posnr LE 0.
      DELETE it_anla WHERE posnr GT 0.
    ENDIF.

    LOOP AT it_anla INTO DATA(ls_anln1).
      lsr_anln1-sign = 'I'.
      lsr_anln1-option = 'EQ'.
      lsr_anln1-low = ls_anln1-anln1.
      APPEND lsr_anln1 TO lr_anln1.
      CLEAR lsr_anln1.
    ENDLOOP.

    IF it_anla1 IS NOT INITIAL.
      SELECT pspnr,post1,pbukr,werks FROM prps INTO TABLE @DATA(it_prps) FOR ALL ENTRIES IN @it_anla1         "WBS Element Description
        WHERE pspnr  = @it_anla1-posnr
         AND  pbukr IN @s_bukrs
         AND  werks IN @s_werks.
    ENDIF.

    IF it_anla IS NOT INITIAL.
      SELECT ebeln, ebelp,zekkn,anln1,ps_psp_pnr,menge FROM ekkn INTO TABLE @DATA(it_ekkn) FOR ALL ENTRIES IN @it_anla   "Purchase Order/Purchase Order Item
        WHERE anln1 = @it_anla-anln1.                                                                        "Asset Based
    ENDIF.
    "Asset Based
    IF it_anla1 IS NOT INITIAL.

      SELECT ebeln ebelp zekkn anln1 ps_psp_pnr menge FROM ekkn APPENDING TABLE it_ekkn FOR ALL ENTRIES IN it_anla1   "Purchase Order/Purchase Order Item
          WHERE ps_psp_pnr = it_anla1-posnr.                                                             "WBS Based

    ENDIF.
  ELSE.
    SELECT ebeln ebelp zekkn anln1 ps_psp_pnr menge FROM ekkn INTO TABLE it_ekkn WHERE ebeln IN s_ebeln.   "Purchase Order/Purchase Order Item

    IF it_ekkn IS NOT INITIAL.
      SELECT bukrs anln1 anln2 posnr txt50                                                                "Asset Code,Asset Name,WBS Element
     INTO TABLE it_anla
     FROM anla FOR ALL ENTRIES IN it_ekkn
     WHERE anln1 = it_ekkn-anln1.

      LOOP AT it_anla INTO ls_anln1.
        lsr_anln1-sign = 'I'.
        lsr_anln1-option = 'EQ'.
        lsr_anln1-low = ls_anln1-anln1.
        APPEND lsr_anln1 TO lr_anln1.
        CLEAR lsr_anln1.
      ENDLOOP.

      SELECT pspnr post1 pbukr werks FROM prps INTO TABLE it_prps FOR ALL ENTRIES IN it_ekkn         "WBS Element Description
        WHERE pspnr  = it_ekkn-ps_psp_pnr.

      SELECT bukrs,anln1,anln2,posnr,txt50  FROM anla INTO TABLE @DATA(it_anla_w)
      FOR ALL ENTRIES IN @it_prps WHERE posnr =   @it_prps-pspnr.
    ENDIF.

  ENDIF.

  LOOP AT it_prps INTO DATA(ls_prps).
    lsr_ps_pnr-sign = 'I'.
    lsr_ps_pnr-option = 'EQ'.
    lsr_ps_pnr-low = ls_prps-pspnr.
    APPEND lsr_ps_pnr TO lr_ps_pnr.
    CLEAR lsr_ps_pnr.
  ENDLOOP.

  IF it_ekkn IS NOT INITIAL.    "WBS field of EKKN tabe based description
    SELECT pspnr,post1 FROM prps INTO TABLE @DATA(it_wbsdesc) FOR ALL ENTRIES IN @it_ekkn WHERE pspnr = @it_ekkn-ps_psp_pnr.
  ENDIF.


  IF it_ekkn IS NOT INITIAL.
    DELETE it_ekkn WHERE anln1 IS  INITIAL  AND ps_psp_pnr IS INITIAL.                                                   "In WBS Case
  ENDIF.


  IF it_ekkn IS NOT INITIAL.
    SELECT ebeln, bukrs,bedat,lifnr,waers,knumv FROM ekko INTO TABLE @DATA(it_ekko) FOR ALL ENTRIES IN @it_ekkn "Purchase Date/Vendor Code/Currency
      WHERE ebeln =  @it_ekkn-ebeln
        AND bukrs IN @s_bukrs.
  ENDIF.

  IF it_ekko IS NOT INITIAL.
    SELECT lifnr,name1 FROM lfa1 INTO TABLE @DATA(it_lfa1) FOR ALL ENTRIES IN @it_ekko              "Vendor Name
      WHERE lifnr = @it_ekko-lifnr.
  ENDIF.

  IF it_ekko IS NOT INITIAL.
    SELECT ebeln,ebelp,loekz,txz01,matnr,werks,menge,netpr,netwr,elikz,knttp,pstyp,vrtkz,packno,erekz FROM ekpo INTO TABLE @DATA(it_ekpo_p) FOR ALL ENTRIES IN @it_ekko  "Plant/Material/Purchase Order Value/Deletion Indicator/Short Closed
      WHERE ebeln = @it_ekko-ebeln AND werks IN @s_werks AND knttp IN ( 'A','P','Q' ).

  ENDIF.



  IF it_ekpo_p IS NOT INITIAL.                                                                               "Material Description
    SELECT matnr,maktx FROM makt INTO TABLE @DATA(it_makt) FOR ALL ENTRIES IN @it_ekpo_p
      WHERE matnr  = @it_ekpo_p-matnr.

    SELECT belnr, gjahr,ebeln,ebelp, buzei,zekkn,knttp,wrbtr,menge FROM rseg INTO TABLE @DATA(it_rseg)
    FOR ALL ENTRIES IN @it_ekpo_p WHERE ebeln = @it_ekpo_p-ebeln
                                    AND ebelp = @it_ekpo_p-ebelp
                                    AND knttp = @it_ekpo_p-knttp.

    DELETE it_rseg WHERE zekkn IS INITIAL.
    DATA(it_rseg_w) = it_rseg.
    DELETE it_rseg_w WHERE knttp = 'A'.                 "For WBS
    DELETE it_rseg WHERE knttp NE 'A'.                  "For asset

    IF it_rseg IS NOT INITIAL.
      SELECT belnr, gjahr, buzei,wrbtr,anln1,ps_psp_pnr,menge FROM rbco INTO TABLE @DATA(it_rbco)
      FOR ALL ENTRIES IN @it_rseg WHERE belnr = @it_rseg-belnr
                                    AND gjahr = @it_rseg-gjahr
                                    AND buzei = @it_rseg-buzei
                                    AND anln1 IN @lr_anln1.
    ENDIF.

    IF it_rseg_w IS NOT INITIAL.
      SELECT belnr, gjahr, buzei,wrbtr,anln1,ps_psp_pnr,menge FROM rbco APPENDING TABLE @it_rbco
      FOR ALL ENTRIES IN @it_rseg_w WHERE belnr = @it_rseg_w-belnr
                                    AND gjahr = @it_rseg_w-gjahr
                                    AND buzei = @it_rseg_w-buzei
                                    AND ps_psp_pnr IN @lr_ps_pnr.

    ENDIF.

  ENDIF.

  IF it_ekkn IS NOT INITIAL.
    SELECT ebeln,ebelp,zekkn,vgabe,gjahr,belnr,buzei,menge,wrbtr
       FROM ekbe INTO TABLE @DATA(it_ekbe) FOR ALL ENTRIES IN @it_ekkn  "Invoice Value
      WHERE ebeln  = @it_ekkn-ebeln AND vgabe = '2'.
  ENDIF.
  "Account assignment = P Or Q and  EKPO ( EBELP VRTKZ ) = Initial

  IF it_ekbe IS NOT INITIAL.
    LOOP AT it_ekbe INTO DATA(wa_ekbe).
      CONCATENATE  wa_ekbe-ebeln wa_ekbe-ebelp  wa_ekbe-zekkn INTO lv_str.        "Preparing key for summation
      wa_ekbes-lv_str = lv_str.
      MOVE-CORRESPONDING wa_ekbe TO wa_ekbes.
      APPEND wa_ekbes TO it_ekbes.
      CLEAR : wa_ekbe.
    ENDLOOP.
  ENDIF.

**********************Logic for Purchase Order Value/Qty in Service PO case****************
  DATA(it_ekpo_s)  = it_ekpo_p.  "for Service Entry Purchase Orders

**************Deleting the Purchase Orders Which are not Service********************
  DELETE it_ekpo_s WHERE pstyp <> '9'.
  DELETE it_ekpo_p WHERE pstyp = '9'.
**************Deleting the Purchase Orders Which are not Service********************

  IF it_ekpo_s IS NOT INITIAL.
    SELECT packno,sub_packno FROM esll INTO TABLE @DATA(it_esll) FOR ALL ENTRIES IN @it_ekpo_s WHERE packno =  @it_ekpo_s-packno.
    SELECT lblni,ebeln FROM essr INTO TABLE @DATA(it_essr) FOR ALL ENTRIES IN @it_ekpo_s WHERE ebeln = @it_ekpo_s-ebeln.
  ENDIF.

  IF it_esll IS NOT INITIAL.
    SELECT packno,sub_packno,menge FROM esll INTO TABLE @DATA(it_esllsp) FOR ALL ENTRIES IN @it_esll WHERE packno =  @it_esll-sub_packno.
  ENDIF.

***********************logic for invoice Value and invoice Qty in Service PO*******************************


  LOOP AT it_essr INTO DATA(wa_essr).  "To Avoid data types issue for that i have taken temporary internal table
    wa_temp-ebeln = wa_essr-ebeln.
    wa_temp-lblni = wa_essr-lblni.
    APPEND wa_temp TO it_temp.
    CLEAR : wa_temp,wa_essr.
  ENDLOOP.


  IF it_essr IS NOT INITIAL.
    SELECT packno zekkn FROM eskn INTO
     CORRESPONDING FIELDS OF TABLE it_eskn FOR ALL ENTRIES IN it_temp WHERE packno = it_temp-lblni.
  ENDIF.

  LOOP AT it_eskn INTO DATA(wa_eskn).
    READ TABLE it_temp INTO wa_temp WITH KEY lblni = wa_eskn-packno.
    READ TABLE it_essr INTO wa_essr WITH KEY lblni = wa_temp-lblni.
    wa_eskn_temp-ebeln = wa_essr-ebeln.
    wa_eskn_temp-packno = wa_eskn-packno.
    wa_eskn_temp-zekkn = wa_eskn-zekkn.
    APPEND wa_eskn_temp TO it_eskn_temp.
    CLEAR : wa_eskn_temp,wa_essr,wa_temp.
  ENDLOOP.

  IF it_eskn_temp IS NOT INITIAL.  "For Invoice Qty and Invoice Value
    SELECT ebeln,ebelp,zekkn,menge FROM ekbe INTO TABLE @DATA(it_ekbe_s) FOR ALL ENTRIES IN @it_eskn_temp WHERE
      ebeln = @it_eskn_temp-ebeln AND zekkn = @it_eskn_temp-zekkn AND vgabe = '2'.
  ENDIF.
***************************************Added by Rutvi***************************************************************
  SORT it_ekkn BY anln1.
  LOOP AT it_anla INTO DATA(wa_anla).
    READ TABLE it_ekko INTO DATA(wa_ekko) WITH KEY bukrs = wa_anla-bukrs.
    IF sy-subrc NE 0.
      CONTINUE.
    ENDIF.
    wa_final-anln1 = wa_anla-anln1.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
      EXPORTING
        input  = wa_final-anln1
      IMPORTING
        output = wa_final-anln1.
    wa_final-txt50 = wa_anla-txt50.
    CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
      EXPORTING
        input  = wa_anla-posnr
      IMPORTING
        output = wa_final-posnr.

    READ TABLE it_prps INTO DATA(wa_prps) WITH KEY pspnr = wa_anla-posnr.
    IF sy-subrc = 0.
      wa_final-post1 = wa_prps-post1.
    ENDIF.
    READ TABLE it_ekkn INTO DATA(wa_ekkn) WITH KEY anln1 = wa_anla-anln1.
    IF sy-subrc = 0.
      DATA(lv_tabix) = sy-tabix.
      LOOP AT it_ekkn INTO DATA(wa_ekkn_t) FROM lv_tabix.
        wa_final-anln1 = wa_anla-anln1.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = wa_final-anln1
          IMPORTING
            output = wa_final-anln1.
        wa_final-txt50 = wa_anla-txt50.
*        wa_final-posnr = wa_anla-posnr.
        CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
          EXPORTING
            input  = wa_anla-posnr
          IMPORTING
            output = wa_final-posnr.
        IF wa_ekkn_t-anln1 = wa_ekkn-anln1.
          wa_final-ebeln = wa_ekkn_t-ebeln.
          wa_final-ebelp = wa_ekkn_t-ebelp.
          wa_final-post1 = wa_prps-post1.
          READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekkn_t-ebeln.
          IF sy-subrc = 0.
            wa_final-bedat = wa_ekko-bedat.
            wa_final-lifnr = wa_ekko-lifnr.
            wa_final-knumv = wa_ekko-knumv. """added by akshay dt.07.05.2025

            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
              EXPORTING
                input  = wa_final-lifnr
              IMPORTING
                output = wa_final-lifnr.

            wa_final-waers = wa_ekko-waers.
          ENDIF.
          READ TABLE it_lfa1 INTO DATA(wa_lfa1) WITH KEY lifnr = wa_ekko-lifnr.
          IF sy-subrc = 0.
            wa_final-name1 = wa_lfa1-name1.
          ENDIF.
          READ TABLE it_ekpo_p INTO DATA(wa_ekpo_p) WITH KEY ebeln = wa_ekkn_t-ebeln
                                                             ebelp = wa_ekkn_t-ebelp.
          IF sy-subrc = 0.
            wa_final-werks = wa_ekpo_p-werks.
            wa_final-matnr = wa_ekpo_p-matnr.
            wa_final-erekz = wa_ekpo_p-erekz.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
              EXPORTING
                input  = wa_final-matnr
              IMPORTING
                output = wa_final-matnr.
            IF wa_ekpo_p-vrtkz IS INITIAL.
              LOOP AT it_ekpo_p INTO DATA(wa_ekpo) WHERE ebeln = wa_ekpo_p-ebeln
                                                     AND ebelp = wa_ekpo_p-ebelp.
                wa_final-po_qty = wa_ekpo_p-menge + wa_final-po_qty.
                wa_final-po_val = wa_ekpo_p-netwr + wa_final-po_val.
              ENDLOOP.
            ELSE.
              wa_final-po_val = wa_ekpo_p-netpr * wa_ekkn_t-menge.
              wa_final-po_qty = wa_ekkn_t-menge.
            ENDIF.
**            READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                         ebelp = wa_ekkn_t-ebelp.
**            IF sy-subrc = 0.
**              IF wa_ekpo_p-vrtkz IS INITIAL.
**                LOOP AT it_ekbe INTO DATA(wa_ekbe_t) WHERE ebeln = wa_ekkn_t-ebeln
**                                                   AND ebelp = wa_ekkn_t-ebelp.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ELSE.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                 AND ebelp = wa_ekkn_t-ebelp
**                                                 AND zekkn = wa_ekkn_t-zekkn.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.
**            ENDIF.
          ELSE.
**********************************************Service PO Case Logic Start***********************************
            READ TABLE it_ekpo_s INTO DATA(wa_ekpo_s) WITH KEY ebeln = wa_ekkn_t-ebeln
                                                               ebelp = wa_ekkn_t-ebelp.
            IF sy-subrc = 0.
              wa_final-maktx = wa_ekpo_s-txz01.
              wa_final-werks = wa_ekpo_s-werks.
              wa_final-erekz = wa_ekpo_s-erekz.
            ENDIF.
            IF wa_ekpo_s-vrtkz IS INITIAL.
              READ TABLE it_esll INTO DATA(wa_esll) WITH KEY packno = wa_ekpo_s-packno.
              IF sy-subrc = 0.
                LOOP AT it_esllsp INTO DATA(wa_esllsp) WHERE packno = wa_esll-sub_packno.
                  wa_final-po_qty = wa_final-po_qty + wa_esllsp-menge.
                ENDLOOP.
              ENDIF.
              wa_final-po_val = wa_ekpo_s-netwr.
**              READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                       ebelp = wa_ekkn_t-ebelp.
**              IF sy-subrc = 0.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                       AND ebelp = wa_ekkn_t-ebelp.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.
            ELSE.
              wa_final-po_val = wa_ekpo_s-netwr * wa_ekkn_t-menge.
              wa_final-po_qty = wa_ekkn_t-menge * wa_ekpo_s-menge.
**              READ TABLE it_essr INTO wa_essr WITH KEY ebeln = wa_ekpo_s-ebeln.
**              IF sy-subrc = 0.
****                READ TABLE it_eskn INTO wa_eskn WITH KEY packno = wa_essr-lblni.
****                IF sy-subrc = 0.
**                READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                     ebelp = wa_ekkn_t-ebelp.
**                IF sy-subrc = 0.
**                  LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                   AND ebelp = wa_ekkn_t-ebelp
**                                                   AND zekkn = wa_ekkn_t-zekkn.
**                    wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                    wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                  ENDLOOP.
**                ENDIF.
****                ENDIF.
**            ENDIF.
            ENDIF.
****************************************Service PO Case logic Ended*************************
          ENDIF.
          READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = wa_ekpo_p-matnr.
          IF sy-subrc = 0.
            wa_final-maktx = wa_makt-maktx.
          ENDIF.

          LOOP AT it_rseg INTO DATA(wa_rseg) WHERE ebeln = wa_ekkn_t-ebeln
                                               AND ebelp = wa_ekkn_t-ebelp.
*          IF sy-subrc = 0.
            READ TABLE it_rbco INTO DATA(wa_rbco_t) WITH KEY belnr = wa_rseg-belnr
                                                             gjahr = wa_rseg-gjahr
                                                             buzei = wa_rseg-buzei
                                                             anln1 = wa_ekkn_t-anln1.
            IF sy-subrc = 0.
              LOOP AT it_rbco INTO DATA(wa_rbco) WHERE belnr = wa_rseg-belnr
                                                 AND   gjahr = wa_rseg-gjahr
                                                 AND   buzei = wa_rseg-buzei
                                                 AND   anln1 = wa_ekkn_t-anln1.
                wa_final-inv_qty = wa_rbco-menge + wa_final-inv_qty.
                wa_final-inv_val = wa_rbco-wrbtr + wa_final-inv_val.
              ENDLOOP.
            ELSE.
              wa_final-inv_qty = wa_rseg-menge + wa_final-inv_qty.
              wa_final-inv_val = wa_rseg-wrbtr + wa_final-inv_val.
            ENDIF.
*          ENDIF.
          ENDLOOP.
          IF wa_ekpo_p-loekz IS NOT INITIAL OR wa_ekpo_p-elikz IS NOT INITIAL
            OR wa_ekpo_s-loekz IS NOT INITIAL OR wa_ekpo_s-elikz IS NOT INITIAL.
            wa_final-pend_val = 0.
          ELSE.
            wa_final-pend_val = wa_final-po_val - wa_final-inv_val.
          ENDIF.
          IF wa_ekpo_p IS NOT INITIAL.
            wa_final-loekz = wa_ekpo_p-loekz.
            wa_final-elikz = wa_ekpo_p-elikz.
          ELSEIF wa_ekpo_s IS NOT INITIAL.
            wa_final-loekz = wa_ekpo_s-loekz.
            wa_final-elikz = wa_ekpo_s-elikz.
          ENDIF.

          APPEND wa_final TO it_final.
          CLEAR: wa_final.
          CLEAR:wa_ekkn_t,wa_ekpo_p,wa_ekpo_s,wa_rbco,wa_rseg,wa_makt,wa_lfa1,lv_tabix.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDLOOP.

*****************************************WBS Element*********************************************
  SORT it_ekkn BY ps_psp_pnr.
  IF it_anla1 IS NOT INITIAL.

    LOOP AT it_anla1 INTO DATA(wa_anla1).
      READ TABLE it_ekko INTO wa_ekko WITH KEY bukrs = wa_anla1-bukrs.
      IF sy-subrc NE 0.
        CONTINUE.
      ENDIF.
      wa_final-anln1 = wa_anla1-anln1.
      wa_final-txt50 = wa_anla1-txt50.
      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = wa_anla1-posnr
        IMPORTING
          output = wa_final-posnr.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = wa_final-anln1
        IMPORTING
          output = wa_final-anln1.
      READ TABLE it_prps INTO wa_prps WITH KEY pspnr = wa_anla1-posnr.
      IF sy-subrc = 0.
        wa_final-post1 = wa_prps-post1.
      ENDIF.
      CLEAR:wa_ekkn.
      READ TABLE it_ekkn INTO wa_ekkn WITH KEY ps_psp_pnr = wa_prps-pspnr.
      IF sy-subrc = 0.
        lv_tabix = sy-tabix.
        LOOP AT it_ekkn INTO wa_ekkn_t FROM lv_tabix.
          wa_final-anln1 = wa_anla1-anln1.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
            EXPORTING
              input  = wa_final-anln1
            IMPORTING
              output = wa_final-anln1.
          wa_final-txt50 = wa_anla1-txt50.
*          wa_final-posnr = wa_anla1-posnr.
          CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
            EXPORTING
              input  = wa_anla1-posnr
            IMPORTING
              output = wa_final-posnr.
          IF wa_ekkn_t-ps_psp_pnr = wa_ekkn-ps_psp_pnr.
            wa_final-ebeln = wa_ekkn_t-ebeln.
            wa_final-ebelp = wa_ekkn_t-ebelp.
            wa_final-post1 = wa_prps-post1.
            READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekkn_t-ebeln.
            IF sy-subrc = 0.
              wa_final-bedat = wa_ekko-bedat.
              wa_final-lifnr = wa_ekko-lifnr.
              wa_final-knumv = wa_ekko-knumv. """added by akshay dt.07.05.2025
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = wa_final-lifnr
                IMPORTING
                  output = wa_final-lifnr.
              wa_final-waers = wa_ekko-waers.
            ENDIF.
            READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
            IF sy-subrc = 0.
              wa_final-name1 = wa_lfa1-name1.
            ENDIF.
            READ TABLE it_ekpo_p INTO wa_ekpo_p WITH KEY ebeln = wa_ekkn_t-ebeln
                                                         ebelp = wa_ekkn_t-ebelp.
            IF sy-subrc = 0.
              wa_final-werks = wa_ekpo_p-werks.
              wa_final-matnr = wa_ekpo_p-matnr.
              wa_final-erekz = wa_ekpo_p-erekz.
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = wa_final-matnr
                IMPORTING
                  output = wa_final-matnr.
              IF wa_ekpo_p-vrtkz IS INITIAL.
                LOOP AT it_ekpo_p INTO wa_ekpo WHERE ebeln = wa_ekpo_p-ebeln
                                                       AND ebelp = wa_ekpo_p-ebelp.
                  wa_final-po_qty = wa_ekpo_p-menge + wa_final-po_qty.
                  wa_final-po_val = wa_ekpo_p-netwr + wa_final-po_val.
                ENDLOOP.

**              READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                       ebelp = wa_ekkn_t-ebelp.
**              IF sy-subrc = 0.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                 AND ebelp = wa_ekkn_t-ebelp.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.
              ELSE.
                wa_final-po_val = wa_ekpo_p-netpr * wa_ekkn_t-menge.
                wa_final-po_qty = wa_ekkn_t-menge.

**              READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                       ebelp = wa_ekkn_t-ebelp.
**              IF sy-subrc = 0.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                               AND ebelp = wa_ekkn_t-ebelp
**                                               AND zekkn = wa_ekkn_t-zekkn.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.

              ENDIF.

              READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_ekpo_p-matnr.
              IF sy-subrc = 0.
                wa_final-maktx = wa_makt-maktx.
              ENDIF.
            ELSE.
**********************************************Service PO Case Logic Start***********************************
              READ TABLE it_ekpo_s INTO wa_ekpo_s WITH KEY ebeln = wa_ekkn_t-ebeln
                                                           ebelp = wa_ekkn_t-ebelp.
              IF sy-subrc = 0.
                wa_final-maktx = wa_ekpo_s-txz01.
                wa_final-werks = wa_ekpo_s-werks.
                wa_final-erekz = wa_ekpo_s-erekz.
              ENDIF.
              IF wa_ekpo_s-vrtkz IS INITIAL.
                READ TABLE it_esll INTO wa_esll WITH KEY packno = wa_ekpo_s-packno.
                IF sy-subrc = 0.
                  LOOP AT it_esllsp INTO wa_esllsp WHERE packno = wa_esll-sub_packno.
                    wa_final-po_qty = wa_final-po_qty + wa_esllsp-menge.
                  ENDLOOP.
                ENDIF.
                wa_final-po_val = wa_ekpo_s-netwr.
**              READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                       ebelp = wa_ekkn_t-ebelp.
**              IF sy-subrc = 0.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                       AND ebelp = wa_ekkn_t-ebelp.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.
              ELSE.
                wa_final-po_val = wa_ekpo_s-netwr * wa_ekkn_t-menge.
                wa_final-po_qty = wa_ekkn_t-menge * wa_ekpo_s-menge.
**              READ TABLE it_essr INTO wa_essr WITH KEY ebeln = wa_ekpo_s-ebeln.
**              IF sy-subrc = 0.
****                  READ TABLE it_eskn INTO wa_eskn WITH KEY packno = wa_essr-lblni.
****                  IF sy-subrc = 0.
**                READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                     ebelp = wa_ekkn_t-ebelp.
**                IF sy-subrc = 0.
**                  LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                   AND ebelp = wa_ekkn_t-ebelp
**                                                   AND zekkn = wa_ekkn_t-zekkn.
**                    wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                    wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                  ENDLOOP.
**                ENDIF.
****                  ENDIF.
**              ENDIF.
              ENDIF.
****************************************Service PO Case logic Ended*************************
            ENDIF.

            LOOP AT it_rseg_w INTO wa_rseg WHERE ebeln = wa_ekkn_t-ebeln
                                                AND  ebelp = wa_ekkn_t-ebelp.
              READ TABLE it_rbco INTO wa_rbco_t WITH KEY belnr = wa_rseg-belnr
                                                         gjahr = wa_rseg-gjahr
                                                         buzei = wa_rseg-buzei
                                                         ps_psp_pnr = wa_ekkn_t-ps_psp_pnr.
              IF sy-subrc = 0.
                LOOP AT it_rbco INTO wa_rbco WHERE belnr = wa_rseg-belnr
                                                   AND   gjahr = wa_rseg-gjahr
                                                   AND   buzei = wa_rseg-buzei
                                                   AND   ps_psp_pnr = wa_ekkn_t-ps_psp_pnr.
                  wa_final-inv_qty = wa_rbco-menge + wa_final-inv_qty.
                  wa_final-inv_val = wa_rbco-wrbtr + wa_final-inv_val.
                ENDLOOP.
              ELSE.
                wa_final-inv_qty = wa_rseg-menge + wa_final-inv_qty.
                wa_final-inv_val = wa_rseg-wrbtr + wa_final-inv_val.
              ENDIF.
            ENDLOOP.

            IF wa_ekpo_p-loekz IS NOT INITIAL OR wa_ekpo_p-elikz IS NOT INITIAL
           OR wa_ekpo_s-loekz IS NOT INITIAL OR wa_ekpo_s-elikz IS NOT INITIAL.
              wa_final-pend_val = 0.
            ELSE.
              wa_final-pend_val = wa_final-po_val - wa_final-inv_val.
            ENDIF.
            IF wa_ekpo_p IS NOT INITIAL.
              wa_final-loekz = wa_ekpo_p-loekz.
              wa_final-elikz = wa_ekpo_p-elikz.
            ELSEIF wa_ekpo_s IS NOT INITIAL.
              wa_final-loekz = wa_ekpo_s-loekz.
              wa_final-elikz = wa_ekpo_s-elikz.
            ENDIF.
            APPEND wa_final TO it_final.
            CLEAR: wa_final.
          ELSE.
            EXIT.
          ENDIF.
          CLEAR:wa_ekkn_t,wa_ekpo_p,wa_ekpo_s,wa_rbco,wa_rseg,wa_makt,wa_lfa1,lv_tabix.
        ENDLOOP.
      ENDIF.
    ENDLOOP.
  ELSEIF it_prps IS NOT INITIAL.
    LOOP AT it_prps INTO wa_prps.
      wa_final-posnr = wa_prps-pspnr.

      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = wa_prps-pspnr
        IMPORTING
          output = wa_final-posnr.

      wa_final-post1 = wa_prps-post1.
      CLEAR:wa_ekkn.
      READ TABLE it_ekkn INTO wa_ekkn WITH KEY ps_psp_pnr = wa_prps-pspnr.
      IF sy-subrc = 0.
        lv_tabix = sy-tabix.
        LOOP AT it_ekkn INTO wa_ekkn_t FROM lv_tabix.
*          wa_final-posnr = wa_prps-pspnr.
          CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
            EXPORTING
              input  = wa_prps-pspnr
            IMPORTING
              output = wa_final-posnr.
          IF wa_ekkn_t-ps_psp_pnr = wa_ekkn-ps_psp_pnr.
            READ TABLE it_anla_w INTO DATA(wa_anla_w) WITH KEY posnr = wa_prps-pspnr.
            IF sy-subrc = 0.
              wa_final-anln1 = wa_anla_w-anln1.
              wa_final-txt50 = wa_anla_w-txt50.
            ENDIF.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
              EXPORTING
                input  = wa_final-anln1
              IMPORTING
                output = wa_final-anln1.
            wa_final-ebeln = wa_ekkn_t-ebeln.
            wa_final-ebelp = wa_ekkn_t-ebelp.
            wa_final-post1 = wa_prps-post1.
            READ TABLE it_ekko INTO wa_ekko WITH KEY ebeln = wa_ekkn_t-ebeln.
            IF sy-subrc = 0.
              wa_final-bedat = wa_ekko-bedat.
              wa_final-lifnr = wa_ekko-lifnr.
              wa_final-knumv = wa_ekko-knumv. """added by akshay dt.07.05.2025
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = wa_final-lifnr
                IMPORTING
                  output = wa_final-lifnr.
              wa_final-waers = wa_ekko-waers.
            ELSE.
              CONTINUE.
            ENDIF.
            READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_ekko-lifnr.
            IF sy-subrc = 0.
              wa_final-name1 = wa_lfa1-name1.
            ENDIF.

            READ TABLE it_ekpo_p INTO wa_ekpo_p WITH KEY ebeln = wa_ekkn_t-ebeln
                                                         ebelp = wa_ekkn_t-ebelp.
            IF sy-subrc = 0.
              wa_final-werks = wa_ekpo_p-werks.
              wa_final-matnr = wa_ekpo_p-matnr.
              wa_final-erekz = wa_ekpo_p-erekz.
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                EXPORTING
                  input  = wa_final-matnr
                IMPORTING
                  output = wa_final-matnr.
              IF wa_ekpo_p-vrtkz IS INITIAL.
                LOOP AT it_ekpo_p INTO wa_ekpo WHERE ebeln = wa_ekpo_p-ebeln
                                                       AND ebelp = wa_ekpo_p-ebelp.
                  wa_final-po_qty = wa_ekpo_p-menge + wa_final-po_qty.
                  wa_final-po_val = wa_ekpo_p-netwr + wa_final-po_val.
                ENDLOOP.
              ELSE.
                wa_final-po_val = wa_ekpo_p-netpr * wa_ekkn-menge.
                wa_final-po_qty = wa_ekkn-menge.
              ENDIF.
**            READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                         ebelp = wa_ekkn_t-ebelp.
**            IF sy-subrc = 0.
**              IF wa_ekpo_p-vrtkz IS INITIAL.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                   AND ebelp = wa_ekkn_t-ebelp
**                                                   AND zekkn = wa_ekkn_t-zekkn.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ELSE.
**                LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                 AND ebelp = wa_ekkn_t-ebelp
**                                                 AND zekkn = wa_ekkn_t-zekkn.
**                  wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                  wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                ENDLOOP.
**              ENDIF.
**            ENDIF.
            ELSE.
**********************************************Service PO Case Logic Start***********************************
              READ TABLE it_ekpo_s INTO wa_ekpo_s WITH KEY ebeln = wa_ekkn_t-ebeln
                                                           ebelp = wa_ekkn_t-ebelp.
              IF sy-subrc = 0.
                wa_final-maktx = wa_ekpo_s-txz01.
                wa_final-werks = wa_ekpo_s-werks.
                wa_final-erekz = wa_ekpo_s-erekz.
              ENDIF.
              IF wa_ekpo_s-vrtkz IS INITIAL.
                READ TABLE it_esll INTO wa_esll WITH KEY packno = wa_ekpo_s-packno.
                IF sy-subrc = 0.
                  LOOP AT it_esllsp INTO wa_esllsp WHERE packno = wa_esll-sub_packno.
                    wa_final-po_qty = wa_final-po_qty + wa_esllsp-menge.
                  ENDLOOP.
                ENDIF.
                wa_final-po_val = wa_ekpo_s-netwr.
**                READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                         ebelp = wa_ekkn_t-ebelp.
**                IF sy-subrc = 0.
**                  LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                         AND ebelp = wa_ekkn_t-ebelp
**                                                         AND zekkn = wa_ekkn_t-zekkn.
**                    wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                    wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                  ENDLOOP.
**                ENDIF.
              ELSE.
                wa_final-po_val = wa_ekpo_s-netwr * wa_ekkn_t-menge.
                wa_final-po_qty = wa_ekkn_t-menge * wa_ekpo_s-menge.
**              READ TABLE it_essr INTO wa_essr WITH KEY ebeln = wa_ekpo_s-ebeln.
**              IF sy-subrc = 0.
****                  READ TABLE it_eskn INTO wa_eskn WITH KEY packno = wa_essr-lblni.
****                  IF sy-subrc = 0.
**                READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln = wa_ekkn_t-ebeln
**                                                     ebelp = wa_ekkn_t-ebelp.
**                IF sy-subrc = 0.
**                  LOOP AT it_ekbe INTO wa_ekbe_t WHERE ebeln = wa_ekkn_t-ebeln
**                                                   AND ebelp = wa_ekkn_t-ebelp
**                                                   AND zekkn = wa_ekkn_t-zekkn.
**                    wa_final-inv_qty = wa_final-inv_qty + wa_ekbe_t-menge.
**                    wa_final-inv_val = wa_final-inv_val + wa_ekbe_t-wrbtr.
**                  ENDLOOP.
**                ENDIF.
****                  ENDIF.
**              ENDIF.
              ENDIF.
****************************************Service PO Case logic Ended*************************
            ENDIF.
            IF wa_ekkn_t-ebeln NE wa_ekpo_p-ebeln AND wa_ekkn_t-ebeln NE wa_ekpo_s-ebeln.
              CONTINUE.
            ENDIF.
            READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_ekpo_p-matnr.
            IF sy-subrc = 0.
              wa_final-maktx = wa_makt-maktx.
            ENDIF.

            LOOP AT it_rseg_w INTO wa_rseg WHERE ebeln = wa_ekkn_t-ebeln
                                                 AND  ebelp = wa_ekkn_t-ebelp.
              READ TABLE it_rbco INTO wa_rbco_t WITH KEY belnr = wa_rseg-belnr
                                                        gjahr = wa_rseg-gjahr
                                                        buzei = wa_rseg-buzei
                                                        ps_psp_pnr = wa_ekkn_t-ps_psp_pnr.
              IF sy-subrc = 0.
                LOOP AT it_rbco INTO wa_rbco WHERE belnr = wa_rseg-belnr
                                                   AND   gjahr = wa_rseg-gjahr
                                                   AND   buzei = wa_rseg-buzei
                                                   AND   ps_psp_pnr = wa_ekkn_t-ps_psp_pnr.
                  wa_final-inv_qty = wa_rbco-menge + wa_final-inv_qty.
                  wa_final-inv_val = wa_rbco-wrbtr + wa_final-inv_val.
                ENDLOOP.
              ELSE.
                wa_final-inv_qty = wa_rseg-menge + wa_final-inv_qty.
                wa_final-inv_val = wa_rseg-wrbtr + wa_final-inv_val.
              ENDIF.
            ENDLOOP.

            IF wa_ekpo_p-loekz IS NOT INITIAL OR wa_ekpo_p-elikz IS NOT INITIAL
           OR wa_ekpo_s-loekz IS NOT INITIAL OR wa_ekpo_s-elikz IS NOT INITIAL.
              wa_final-pend_val = 0.
            ELSE.
              wa_final-pend_val = wa_final-po_val - wa_final-inv_val.
            ENDIF.

            IF wa_ekpo_p IS NOT INITIAL.
              wa_final-loekz = wa_ekpo_p-loekz.
              wa_final-elikz = wa_ekpo_p-elikz.
            ELSEIF wa_ekpo_s IS NOT INITIAL.
              wa_final-loekz = wa_ekpo_s-loekz.
              wa_final-elikz = wa_ekpo_s-elikz.
            ENDIF.
            APPEND wa_final TO it_final.
            CLEAR: wa_final.
          ELSE.
            EXIT.
          ENDIF.
          CLEAR:wa_ekkn_t,wa_ekpo_p,wa_ekpo_s,wa_rbco,wa_rseg,wa_makt,wa_lfa1,lv_tabix.
        ENDLOOP.
      ENDIF.
    ENDLOOP.
  ENDIF.
********************************************************************************************************************

*********************Correct Purchase Requisition against Correct Purchase Order******************************
**  IF it_ekpo_p IS NOT INITIAL.
**    SELECT banfn,bnfpo,ebeln FROM eban INTO TABLE @DATA(it_ebann) FOR ALL ENTRIES IN @it_ekpo_p WHERE ebeln = @it_ekpo_p-ebeln.
**  ENDIF.
**********************Correct Purchase Requisition against Correct Purchase Order*******************************

**  LOOP AT it_ekkn INTO DATA(wa_ekkn).
**
**    READ TABLE  it_ekpo_p INTO DATA(wa_ekpo_p) WITH KEY ebeln = wa_ekkn-ebeln.
**    wa_final-ebeln = wa_ekpo_p-ebeln.
**    wa_final-ebelp = wa_ekpo_p-ebelp.
**    wa_final-matnr = wa_ekpo_p-matnr.
**    wa_final-loekz = wa_ekpo_p-loekz.
**    wa_final-elikz = wa_ekpo_p-elikz.
**    wa_final-werks = wa_ekpo_p-werks.
**    wa_final-knttp = wa_ekpo_p-knttp.  "Account Assignment Category
**    wa_final-vrtkz = wa_ekpo_p-vrtkz.  "Distribution indicator for multiple account assignment
**    wa_final-po_qty = wa_ekpo_p-menge. "Purchase Order Qty
**    wa_final-po_val = wa_ekpo_p-netwr. "Purchase Order Value
**
**    READ TABLE it_ekko INTO DATA(wa_ekko) WITH KEY ebeln = wa_ekpo_p-ebeln.
**    IF sy-subrc = 0.
**      wa_final-bedat = wa_ekko-bedat.
**      wa_final-lifnr = wa_ekko-lifnr.
**      wa_final-waers = wa_ekko-waers.
**    ENDIF.
**    READ TABLE it_makt INTO DATA(wa_makt) WITH KEY matnr = wa_ekpo_p-matnr.
**    IF sy-subrc = 0.
**      wa_final-maktx = wa_makt-maktx.
**    ENDIF.
**    READ TABLE it_lfa1 INTO DATA(wa_lfa1) WITH KEY lifnr = wa_ekko-lifnr.
**    IF sy-subrc = 0.
**      wa_final-name1 = wa_lfa1-name1.
**    ENDIF.
**
**    READ TABLE it_ekkn INTO wa_ekkn WITH KEY ebeln = wa_ekpo_p-ebeln.
**    IF sy-subrc = 0.
***      wa_final-anln1 = wa_ekkn-anln1.
**    ENDIF.
**
**    READ TABLE it_anla INTO DATA(wa_anla) WITH KEY anln1 = wa_ekkn-anln1.
**    IF sy-subrc = 0.
**      wa_final-posnr = wa_ekkn-anln1.
**      wa_final-txt50 = wa_anla-txt50.
**      wa_final-anln1 = wa_anla-anln1.
**    ENDIF.
**
**    IF wa_final-posnr IS INITIAL.
**      wa_final-posnr = wa_ekkn-ps_psp_pnr.
**    ENDIF.
**
**    READ TABLE it_prps INTO DATA(wa_prps) WITH KEY pspnr = wa_anla-posnr.
**    IF sy-subrc = 0.
**      wa_final-post1 = wa_prps-post1.
**    ENDIF.
**
**    READ TABLE it_wbsdesc INTO DATA(wa_desc) WITH KEY pspnr = wa_ekkn-ps_psp_pnr.
**
**    IF wa_final-post1 IS INITIAL.
**      wa_final-post1 = wa_desc-post1.
**    ENDIF.
**
****    READ TABLE it_ebkn INTO DATA(wa_ekbn) WITH KEY anln1 = wa_anla-anln1.
****    IF sy-subrc = 0.
****        wa_final-banfn = wa_ekbn-banfn.
****        wa_final-bnfpo = wa_ekbn-bnfpo.
****    ENDIF.
**
****    READ TABLE it_ebann INTO DATA(wa_ebann) WITH KEY ebeln = wa_ekpo_p-ebeln.
****    IF sy-subrc = 0.
****      wa_final-banfn = wa_ebann-banfn.
****      wa_final-bnfpo = wa_ebann-bnfpo.
****    ENDIF.
****
****    READ TABLE it_eban INTO DATA(wa_eban) WITH KEY banfn = wa_ekbn-banfn.
****    IF sy-subrc = 0.
****      wa_eban-badat = wa_eban-badat.
****    ENDIF.
**
**    READ TABLE it_ekbe INTO wa_ekbe WITH KEY ebeln  = wa_ekpo_p-ebeln ebelp = wa_ekpo_p-ebelp.
**    IF sy-subrc = 0.
**      wa_final-inv_qty = wa_ekbe-menge.
**      wa_final-inv_val = wa_ekbe-wrbtr.
**    ENDIF.
**
**    wa_final-pend_val =   ( wa_final-po_val - wa_final-inv_val ).
**
**    IF wa_ekpo_p-loekz = 'L'.
**      wa_final-pend_val = 0.
**    ENDIF.
**
**    IF wa_ekpo_p-pstyp = '9'.
**      wa_final-maktx = wa_ekpo_p-txz01.
**    ENDIF.
**
**    wa_final-pstyp = wa_ekpo_p-pstyp.
**
**    APPEND wa_final TO it_final.
**
**    CLEAR : wa_ekpo_p,wa_final,wa_ekko,wa_makt,wa_lfa1,wa_prps,wa_anla,wa_lfa1,wa_ekpo_p,wa_ekbe,wa_ekkn.
**  ENDLOOP.

**  IF it_final IS NOT INITIAL.
**    DELETE it_final WHERE anln1 IS INITIAL AND posnr IS INITIAL.
**  ENDIF.
**  REFRESH : it_final1.
**
**
**  IF s_ebeln IS NOT INITIAL.
**    LOOP AT s_ebeln INTO DATA(w_ebeln).
**      LOOP AT it_final INTO wa_final WHERE ebeln = w_ebeln-low.
**        MOVE-CORRESPONDING wa_final TO wa_final1.
**        APPEND wa_final1 TO it_final1.
**        CLEAR : w_ebeln,wa_final1,wa_final.
**      ENDLOOP.
**      CLEAR : w_ebeln.
**    ENDLOOP.
**  ELSE.
**    it_final1 = it_final.
**  ENDIF.
  DELETE it_final WHERE werks IS INITIAL.

  """""added by akshay dt.07.05.2025
  DATA: r_doctype      TYPE RANGE OF konv-kschl,
        r_doctype_line LIKE LINE OF r_doctype.
  DATA : lv_kwert TYPE konv-kwert.
  DATA : lv_wrbtr TYPE rseg-wrbtr.
  REFRESH : r_doctype[].
  SELECT  * FROM tvarvc INTO TABLE @DATA(lt_doc_type) WHERE name = 'ZMM_ASSET_DOCTYPE'.
  IF lt_doc_type IS NOT INITIAL.
    LOOP AT lt_doc_type INTO DATA(wa_doc_type).

      r_doctype_line-sign = 'I'.
      r_doctype_line-option = 'EQ'.
      r_doctype_line-low = wa_doc_type-low.
      APPEND r_doctype_line TO r_doctype.
      CLEAR : r_doctype_line,wa_doc_type.

    ENDLOOP.
    IF it_final[] IS NOT INITIAL.

* Quick Fix Replace KONV table access with the access of compatibility view V_KONV
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT knumv, kposn,  lifnr, kwert
*        FROM konv
*        INTO TABLE @DATA(gt_konv)
*        FOR ALL ENTRIES IN @it_final
*        WHERE ( knumv = @it_final-knumv AND kstat = 'X'  "AND kwert IS NOT NULL
**         AND ( kschl = 'FRB1' OR kschl = 'FRB3' OR kschl = 'P&F1' OR kschl = 'P&F2' ) ).
*        AND kschl IN @r_doctype ) .

SELECT FROM V_KONV FIELDS KNUMV , KPOSN , LIFNR , KWERT FOR ALL ENTRIES IN @IT_FINAL WHERE ( KNUMV = @IT_FINAL-KNUMV AND KSTAT = 'X' AND KSCHL IN @R_DOCTYPE ) INTO TABLE @DATA(GT_KONV) .
* End of Quick Fix

    ENDIF.

    IF it_final[] IS NOT INITIAL.
      SELECT ebeln, belnr, gjahr, ebelp, kschl, wrbtr
        FROM rseg
        INTO TABLE @DATA(gt_rseg)
        FOR ALL ENTRIES IN @it_final
        WHERE ( ebeln = @it_final-ebeln
*         AND ( kschl = 'FRB1' OR kschl = 'FRB3' OR kschl = 'P&F1' OR kschl = 'P&F2' ) ).
        AND kschl IN @r_doctype ) .
      IF gt_rseg[] IS NOT INITIAL.
        SELECT belnr , gjahr , lifnr
          FROM rbkp INTO TABLE @DATA(gt_vendor)
          FOR ALL ENTRIES IN @gt_rseg
     WHERE  belnr = @gt_rseg-belnr
        AND gjahr = @gt_rseg-gjahr.
        IF gt_vendor[] IS NOT INITIAL.
          SELECT lifnr,name1 FROM lfa1 APPENDING TABLE @it_lfa1 FOR ALL ENTRIES IN @gt_vendor              "Vendor Name
            WHERE lifnr = @gt_vendor-lifnr.
        ENDIF.
      ENDIF.
    ENDIF.


    LOOP AT it_final INTO wa_final.

      MOVE-CORRESPONDING wa_final TO wa_final1.

      LOOP AT gt_konv INTO DATA(gw_konv) WHERE knumv = wa_final1-knumv AND kposn = wa_final1-ebelp AND kwert IS NOT INITIAL.
        wa_final1-lifnr_n = gw_konv-lifnr.
        lv_kwert =  lv_kwert + gw_konv-kwert.
        CLEAR:gw_konv.
      ENDLOOP.

      wa_final1-kwert = lv_kwert.

      LOOP AT gt_rseg INTO DATA(gw_rseg) WHERE ebeln = wa_final1-ebeln AND ebelp = wa_final1-ebelp AND wrbtr IS NOT INITIAL.
        lv_wrbtr =  lv_wrbtr + gw_rseg-wrbtr.

        IF  wa_final1-lifnr_f IS INITIAL AND  wa_final1-name1_f IS INITIAL.

          READ TABLE gt_vendor INTO DATA(gw_vendor) WITH KEY belnr = gw_rseg-belnr  gjahr = gw_rseg-gjahr.
          IF sy-subrc = 0.
            wa_final1-lifnr_f = gw_vendor-lifnr.

            READ TABLE it_lfa1 INTO DATA(wa_lfa1_f) WITH KEY lifnr = wa_final1-lifnr_f.
            IF sy-subrc = 0.
              wa_final1-name1_f  = wa_lfa1_f-name1.
            ENDIF.

          ENDIF.
        ENDIF.

        CLEAR:gw_rseg.
      ENDLOOP.

      wa_final1-wrbtr = lv_wrbtr.
*      wa_final1-wrbtr_n = lv_kwert - lv_wrbtr.

      APPEND wa_final1 TO it_final1.
      CLEAR:wa_final1,lv_kwert,lv_wrbtr,gw_vendor,wa_lfa1_f.
    ENDLOOP.
  ENDIF.
  """""eoc dt.07.05.2025

ENDFORM.


FORM build_fcat.
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'ANLN1'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Asset Code'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'TXT50'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Asset Code Desc.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '50'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'POSNR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'WBS Element'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '20'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'POST1'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'WBS Element Desc.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '40'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BANFN'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Purchase Req. no'.
*  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '12' .wa_fcat-hotspot = 'X'.APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
*
*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BNFPO'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Purchase Req. Line'.
*  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

*  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BADAT'.       wa_fcat-tabname = 'IT_FINAL'. wa_fcat-seltext_m =  'Purchase Req. Date'.
*  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '20'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EBELN'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Purchase Order'.
  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '15'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EBELP'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'PO Line Item'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'BEDAT'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'PO Date'.
  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '20'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LIFNR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Vendor'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'NAME1'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Vendor Name'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '40'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.



  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WAERS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Currency'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WERKS'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Plant'.
  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MATNR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '18'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'MAKTX'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material Desc.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '40'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  wa_fcat-col_pos = 1..  wa_fcat-fieldname = 'PO_QTY'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Purchase Order Qty.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'PO_VAL'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Purchase Order Value'.
  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.



  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'INV_QTY'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Invoice Qty.'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'INV_VAL'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Invoice Value'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '12'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.




  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'PEND_VAL'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Pending Value'.
  wa_fcat-outputlen = 'C5'. wa_fcat-outputlen = '20'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'ELIKZ'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Short Closed'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'EREKZ'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Final Invoice'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LOEKZ'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Deletion Indicator'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
  """"added by akshay dt.07.05.2025
  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LIFNR_N'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Supplier Number'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'KWERT'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Condition Value'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WRBTR'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Amount'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'LIFNR_F'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Freight paid vendor'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '10'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'NAME1_F'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Freight paid vendor Name'.
  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '30'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.

**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'WRBTR_N'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Remaining Amount'.
**  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'.  APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.


  """"eoc dt.07.05.2025
**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'KNTTP'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'A/c Assign Category'.
**  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
**
**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'VRTKZ'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Multiple A/c Assign Ind.'.
**  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.
**
**  wa_fcat-col_pos = 1.  wa_fcat-fieldname = 'PSTYP'.       wa_fcat-tabname = 'IT_FINAL1'. wa_fcat-seltext_m =  'Material or Service'.
**  wa_fcat-emphasize = 'C5'. wa_fcat-outputlen = '5'. wa_fcat-hotspot = 'X'. APPEND wa_fcat TO it_fcat.CLEAR wa_fcat.



ENDFORM.




FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).

  wa_header-typ = 'H'.
  wa_header-info = 'Material and Service Asset Report'.

  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  DATA : v_date TYPE char10.
  CALL FUNCTION 'CONVERSION_EXIT_PDATE_OUTPUT'
    EXPORTING
      input  = sy-datum
    IMPORTING
      output = v_date.

  CONCATENATE 'Date :- ' v_date INTO wa_header-info SEPARATED BY space.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'  "Uncommented by Raj on 12.07.2023
    EXPORTING
      it_list_commentary = it_header.
ENDFORM.


FORM display_alv.
  IF it_final IS NOT INITIAL.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        i_callback_program     = sy-repid
        i_callback_top_of_page = 'TOP_PAGE'
*       i_callback_user_command = 'INTERACTIVE'
        i_save                 = 'A'
        is_layout              = wa_layout
        it_fieldcat            = it_fcat
      TABLES
*       t_outtab               = it_final """COMMENTED BY AKSHAY DT.07.05.2025
        t_outtab               = it_final1 """ADDED BY AKSHAY DT.07.05.2025
      EXCEPTIONS
        program_error          = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

  ENDIF.
ENDFORM.
