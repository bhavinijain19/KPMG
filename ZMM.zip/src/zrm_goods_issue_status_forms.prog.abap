*************************************************************************************
*Object Name              : ZRM_GOODS_ISSUE_STATUS_FORMS
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Include for 9000 Screen
*************************************************************************************

*********************************************************
*PBO of screen 9000.
*********************************************************
MODULE status_9000 OUTPUT.
  SET PF-STATUS 'ZRM_GOODS'.
  SET TITLEBAR 'RM Goods issue'.



ENDMODULE.
*********************************************************
*PAI of screen 9001.
*********************************************************
MODULE user_command_9000 INPUT.
*********************************************************
*Enter button is pressed.
*********************************************************
  IF sy-ucomm = 'ENTER'.
    CLEAR  gt_ltbp.
    IF  ltbp-tbnum IS NOT INITIAL.

      SELECT lgnum,
             tbnum,
             tbpos,
             elikz,
             matnr,
             charg,
             menge,
             meins
      INTO TABLE  @DATA(lt_ltbp)
        FROM ltbp
         WHERE tbnum =  @ltbp-tbnum  AND
               lgort = @lgort AND
               elikz = ' '.
        describe TABLE lt_ltbp LINES fill_9000.

    ENDIF.
*********************************************************
*Page down button is pressed.
*********************************************************
  ELSEIF sy-ucomm = 'PGDWN'.
    "slines = slines + 6.
    line_9000 = line_9000 + lines_9000.
    limit_9000 = fill_9000 - lines_9000.
    IF line_9000 > limit_9000.
      line_9000 = limit_9000.
    ENDIF.
*********************************************************
*Page Up button is pressed.
*********************************************************
  ELSEIF sy-ucomm = 'PGUP'.
    "slines = slines - 6.
    line_9000 = line_9000 - lines_9000.
    IF line_9000 < 0.
      line_9000 = 0.
    ENDIF.
*********************************************************
*Next down button is pressed.
*********************************************************
  ELSEIF sy-ucomm = 'NEXT'.
    CALL SCREEN 9001.
*********************************************************
*Cancel button is pressed.
*********************************************************
  ELSEIF sy-ucomm = 'CANCEL'.
    LEAVE PROGRAM.
*********************************************************
*Back button is pressed.
*********************************************************
  ELSEIF sy-ucomm = 'BACK'.
    LEAVE PROGRAM.
    CLEAR it_final.
  ENDIF.



ENDMODULE.
*********************************************************
*PAI for screen 9000.
*********************************************************
MODULE transp_itab_out_9000 OUTPUT.

  idx_9000 = sy-stepl + line_9000.

  TRY.
      if gv_tanum is NOT INITIAL and flag_dlt eq 0.
        delete lt_ltbp INDEX c.
        delete gt_ltbp INDEX c.
        flag_dlt = 1.
        clear c.
      endif.
      clear gv_tanum.
      clear flag_dlt.
      if c ne idx_9000 or sy-ucomm = 'BACK'.
      DATA(lw_ltbp) = lt_ltbp[ idx_9000 ].

      wa_ltbp-matnr = lw_ltbp-matnr.
      wa_ltbp-menge = lw_ltbp-menge.
      wa_ltbp-charg = lw_ltbp-charg.
      wa_ltbp-meins  = lw_ltbp-meins.
      wa_ltbp-tbpos = lw_ltbp-tbpos.
      APPEND wa_ltbp TO gt_ltbp.
   endif.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.
*  ENDIF.
*  endif.
*  data(gt_ltbp1) = lt_ltbp[ idx ].
*      ENDLOOP.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_IN_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_in_9000 INPUT.
  lines_9000 = sy-loopc.
  idx_9000 = sy-stepl + line_9000.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CURSOR_DATA  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE cursor_data INPUT.
  flag_dlt = 0.
  CLEAR c.
  GET CURSOR  LINE c.
  c = c + lines_9000.
ENDMODULE.
