*&---------------------------------------------------------------------*
*&  Include           ZMM_SU_NUMBER_LIST_REP_TOP
*&---------------------------------------------------------------------*

TYPE-POOLS : slis.

TABLES: zmm_su_number, mara, makt, t024d.

TYPES: BEGIN OF ty_mara,
         matnr TYPE mara-matnr,
         lvorm TYPE mara-lvorm,
         mtart TYPE mara-mtart,
         bismt TYPE mara-bismt,
       END OF ty_mara,

       BEGIN OF ty_t001w,
         werks TYPE werks_d,
       END OF ty_t001w,

       BEGIN OF ty_t024d,
         werks TYPE t024d-werks,
         dispo TYPE t024d-dispo,
         dsnam TYPE t024d-dsnam,
       END OF ty_t024d,

       BEGIN OF ty_final,
         zsu_no     TYPE zmm_su_number-zsu_no,
         aufnr      TYPE zmm_su_number-aufnr,
         matnr      TYPE zmm_su_number-matnr,
         werks      TYPE zmm_su_number-werks,
         lgort      TYPE zmm_su_number-lgort,
         charg      TYPE zmm_su_number-charg,
         meins      TYPE zmm_su_number-meins,
         lgpla      TYPE zmm_su_number-lgpla,
         zlhmg1     TYPE zmm_su_number-zlhmg1,
         lhme1      TYPE zmm_su_number-lhme1,
         lhmg1      TYPE zmm_su_number-lhmg1,
         lety1      TYPE zmm_su_number-lety1,
         zbatch_stk TYPE zmm_su_number-zbatch_stk,
         mtart      TYPE mara-mtart,
         lvorm      TYPE mara-lvorm,
         bismt      TYPE mara-bismt,
         dispo      TYPE zmm_su_number-dispo,
         budat      TYPE zmm_su_number-budat,
         maktx      TYPE makt-maktx,
         dsnam      TYPE t024d-dsnam,
       END OF ty_final.

DATA: it_final TYPE STANDARD TABLE OF ty_final,
      wa_final TYPE ty_final,
      it_main  TYPE STANDARD TABLE OF zmm_su_number,
      wa_main  TYPE zmm_su_number,
      it_makt  TYPE STANDARD TABLE OF makt,
      wa_makt  TYPE makt,
      it_mara  TYPE STANDARD TABLE OF ty_mara,
      wa_mara  TYPE ty_mara,
      it_t024d TYPE STANDARD TABLE OF ty_t024d,
      wa_t024d TYPE t024d,
      gt_t001w TYPE STANDARD TABLE OF ty_t001w,
      wa_t001w TYPE ty_t001w.

DATA: it_fieldcat   TYPE slis_t_fieldcat_alv WITH HEADER LINE,
      it_listheader TYPE slis_t_listheader WITH HEADER LINE,
      t_event       TYPE slis_t_event WITH HEADER LINE,
      wa_layout     TYPE slis_layout_alv.
