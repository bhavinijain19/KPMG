**&-------------------------------------------------------------------*
**& REPORT AUTHOR         : Mahir Maniar
**& FUNCTIONAL CONSULTANT :
**& REPORT CREATION DATE  : 15/10/2016
**& TRANSACTION CODE      : ZFI_VEN_AGE
**& PURPOSE               : Vendor Ageing Report( Payment/Transaction of Vendor)
**&-------------------------------------------------------------------*

REPORT zfi_vend_ageing_report_new.
TYPE-POOLS: slis.

TABLES:lfa1,bsik,lfb1,industype.

SELECTION-SCREEN:BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-000.

  SELECT-OPTIONS:s_regio FOR lfa1-regio NO INTERVALS,            "Region
                 s_lifnr FOR lfa1-lifnr,                         "Vendor Number
                 s_bukrs FOR bsik-bukrs DEFAULT '1000',          "Company Code
                 s_gjahr FOR bsik-gjahr NO-EXTENSION NO-DISPLAY, "Fiscal Year  "Comment Rremove Squirrel (2022)
                 s_date  FOR bsik-budat NO INTERVALS OBLIGATORY, "Date
                 s_itype FOR industype-indtype,                    " Type of industry
                 s_akont FOR lfb1-akont,                         "Reconciliation Account in General Ledger
                 s_umskz FOR bsik-umskz.                         " Special g/l ind

SELECTION-SCREEN:END OF BLOCK b1.

SELECTION-SCREEN:BEGIN OF BLOCK b4 WITH FRAME TITLE TEXT-003.

  SELECTION-SCREEN BEGIN OF LINE.

    PARAMETERS: ageslb1(3) TYPE n DEFAULT 15,    "8,
                ageslb2(3) TYPE n DEFAULT 30,  "15,
                ageslb3(3) TYPE n DEFAULT 60,  "30,
                ageslb4(3) TYPE n DEFAULT 90.  "60,
*              ageslb5(3)  TYPE n DEFAULT 120, "90,
*              ageslb6(3)  TYPE n DEFAULT 180,
*              ageslb7(3)  TYPE n DEFAULT 270,
*              ageslb8(3)  TYPE n DEFAULT 365,
*              ageslb9(3)  TYPE n DEFAULT 730, " NO-DISPLAY,
*              ageslb10(4) TYPE n DEFAULT 1095. "  NO-DISPLAY.

  SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN:END OF BLOCK b4.

*SELECTION-SCREEN:BEGIN OF BLOCK b2 WITH FRAME TITLE text-001.
*
*PARAMETERS:p_both   RADIOBUTTON GROUP rg1,
*           p_normal RADIOBUTTON GROUP rg1.
**           p_spl    RADIOBUTTON GROUP rg1 .
*
*SELECTION-SCREEN:END OF BLOCK b2.

SELECTION-SCREEN:BEGIN OF BLOCK b3 WITH FRAME TITLE TEXT-002.

  PARAMETERS:p_budat RADIOBUTTON GROUP rg2,
             p_bldat RADIOBUTTON GROUP rg2.

SELECTION-SCREEN:END OF BLOCK b3.

****Added by Squirrel(Manoj) to bifurcate plants
SELECTION-SCREEN:BEGIN OF BLOCK b5 WITH FRAME TITLE TEXT-004.

  PARAMETERS:p_plnt1 RADIOBUTTON GROUP rg4,
             p_plnt2 RADIOBUTTON GROUP rg4,
             p_plnt3 RADIOBUTTON GROUP rg4.

SELECTION-SCREEN:END OF BLOCK b5.
****End of code

TYPES: BEGIN OF ty_s,
         bukrs     TYPE bsik-bukrs,
         lifnr     TYPE bsik-lifnr,
         umskz     TYPE bsik-umskz,
         augdt     TYPE bsik-augdt,
         gjahr     TYPE bsik-gjahr,
         belnr     TYPE bsik-belnr,
         budat     TYPE bsik-budat,
         bldat     TYPE bsik-bldat,
         waers     TYPE bsik-waers,
         blart     TYPE bsik-blart,
         shkzg     TYPE bsik-shkzg,
         gsber     TYPE bsik-gsber,
         dmbtr     TYPE bsik-dmbtr,
         ktokk     TYPE lfa1-ktokk,
         name1     TYPE lfa1-name1,
         regio     TYPE lfa1-regio,
         akont     TYPE lfb1-akont,
         busab     TYPE lfb1-busab,
         j_1kftind TYPE lfa1-j_1kftind,
         amt1      TYPE bsik-dmbtr,
         amt2      TYPE bsik-dmbtr,
         amt3      TYPE bsik-dmbtr,
         ind       TYPE c,
       END OF ty_s.

DATA:wa_s TYPE ty_s,
     it_s TYPE TABLE OF ty_s.

DATA:wa_h TYPE ty_s,
     it_h TYPE TABLE OF ty_s.

DATA:wa_h1 TYPE ty_s,
     it_h1 TYPE TABLE OF ty_s.

TYPES:BEGIN OF ty_sum,
        bukrs TYPE bsik-bukrs,
        lifnr TYPE bsik-lifnr,
        gjahr TYPE bsik-gjahr,
        dmbtr TYPE bsik-dmbtr,
      END OF ty_sum.

DATA:wa_sum TYPE ty_sum,
     it_sum TYPE TABLE OF ty_sum.

DATA:wa_spl TYPE ty_s,
     it_spl TYPE TABLE OF ty_s.

TYPES:BEGIN OF ty_lifnr,
        lifnr TYPE lfa1-lifnr,
      END OF ty_lifnr.

DATA:wa_lifnr TYPE ty_lifnr,
     it_lifnr TYPE TABLE OF ty_lifnr.

TYPES:BEGIN OF ty_final,
        regio      TYPE lfa1-regio,
        ktokk      TYPE lfa1-ktokk,
        txt30      TYPE t077y-txt30,     "  Text of ktokk
        akont      TYPE lfb1-akont,
        lifnr      TYPE bsik-lifnr,
        name1      TYPE lfa1-name1,
        j_1kfrepre TYPE lfa1-j_1kfrepre,
        j_1kftind  TYPE lfa1-j_1kftind,
*        stcd4      TYPE lfa1-stcd4,
        profs      TYPE lfa1-profs,
        j_1kftbus  TYPE lfa1-j_1kftbus,
        0to15      TYPE dmbtr,
        16to30     TYPE dmbtr,
        31to60     TYPE dmbtr,
        61to90     TYPE dmbtr,
        91to120    TYPE dmbtr,
        121to180   TYPE dmbtr,
        181to270   TYPE dmbtr,
        271to365   TYPE dmbtr,
        366to730   TYPE dmbtr,
        731to1095  TYPE dmbtr,
        1096to     TYPE dmbtr,
        cdam01     LIKE bsid-dmbtr,   " SLOT AMT
        cdam02     LIKE bsid-dmbtr,   " SLOT AMT
        cdam03     LIKE bsid-dmbtr,   " SLOT AMT
        cdam04     LIKE bsid-dmbtr,   " SLOT AMT
        cdam05     LIKE bsid-dmbtr,   " SLOT AMT
        cdam06     LIKE bsid-dmbtr,   " SLOT AMT
        cdam07     LIKE bsid-dmbtr,   " SLOT AMT
        cdam08     LIKE bsid-dmbtr,   " SLOT AMT
        cdam09     LIKE bsid-dmbtr,   " SLOT AMT
        cdam10     LIKE bsid-dmbtr,   " SLOT AMT
        cdam11     LIKE bsid-dmbtr,   " SLOT AMT
*        crbal     LIKE bsid-dmbtr,   " Credit Balance
        total      LIKE bsid-dmbtr,   " TOTAL AMOUNT
        color(4)   TYPE c,
        spl        TYPE c,
        memo       TYPE lfb1-kverm,   " Account memo
        zterm      TYPE lfb1-zterm,   " Account memo    "Added by Rutvi on 19.02.2024
        text1      TYPE t052u-text1,   " Account memo   "Added by Rutvi on 19.02.2024
*        totcd     LIKE bsid-dmbtr,   " TOTAL CR/DR AMOUNT
*        cltot     LIKE bsid-dmbtr,   " CLOSING AMOUNT
      END OF ty_final.

DATA:wa_final TYPE ty_final,
     it_final TYPE TABLE OF ty_final.

DATA:v_amount   TYPE bsak-dmbtr,
     v_pending  TYPE bsak-dmbtr,
     v_pending1 TYPE bsak-dmbtr,
     v_gjahr    TYPE bsak-gjahr,
     v_date     TYPE i.

DATA:v_0to15     TYPE dmbtr,
     v_16to30    TYPE dmbtr,
     v_31to60    TYPE dmbtr,
     v_61to90    TYPE dmbtr,
     v_91to120   TYPE dmbtr,
     v_121to180  TYPE dmbtr,
     v_181to270  TYPE dmbtr,
     v_271to365  TYPE dmbtr,
     v_366to730  TYPE dmbtr,
     v_731to1095 TYPE dmbtr,
     v_1096to    TYPE dmbtr.

TYPES:BEGIN OF ty_slabs,
        slab(2) TYPE n,
        days(4) TYPE n,
      END OF ty_slabs.

DATA:wa_slabs TYPE ty_slabs,
     it_slabs TYPE TABLE OF ty_slabs.

DATA : no_of_days TYPE i.

DATA : tit_headtotal  LIKE bsid-dmbtr,
       tit_headtotcd  LIKE bsid-dmbtr,
       tit_headcltot  LIKE bsid-dmbtr,
       tit_headkunnr  LIKE kna1-kunnr,
       tit_headcdam01 LIKE bsid-dmbtr,
       tit_headcdam02 LIKE bsid-dmbtr,
       tit_headcdam03 LIKE bsid-dmbtr,
       tit_headcdam04 LIKE bsid-dmbtr,
       tit_headcdam05 LIKE bsid-dmbtr,
       tit_headcdam06 LIKE bsid-dmbtr,
       tit_headcdam07 LIKE bsid-dmbtr,
       tit_headcdam08 LIKE bsid-dmbtr,
       tit_headcdam09 LIKE bsid-dmbtr,
       tit_headcdam10 LIKE bsid-dmbtr,
       tit_headcdam11 LIKE bsid-dmbtr.

DATA:wa_fcat TYPE slis_fieldcat_alv,
     it_fcat TYPE slis_t_fieldcat_alv.

DATA: i_sp_group  TYPE slis_t_sp_group_alv.

DATA:wa_fcat1 TYPE slis_fieldcat_alv,
     it_fcat1 TYPE slis_t_fieldcat_alv.

DATA:wa_layout TYPE slis_layout_alv.

DATA: gd_layout TYPE slis_layout_alv,
      i_events  TYPE slis_t_event.

*  data: wa_fcat      type slis_fieldcat_alv.
DATA: fldname(6)       TYPE c.
DATA: lbcdam1(11)      TYPE c.
DATA: pit_slabsdays(4) TYPE n.
DATA: tcounter(2)      TYPE n.

TYPES: BEGIN OF ty_tx,
         lev(2) TYPE n,
         cr     LIKE bsid-dmbtr,
         dr     LIKE bsid-dmbtr,
       END OF ty_tx.

DATA:wa_tx TYPE ty_tx,
     it_tx TYPE TABLE OF ty_tx.

DATA:h   TYPE c,
     spl TYPE c,
     s   TYPE c.

TYPES: BEGIN OF ty_lfa1,
         lifnr      TYPE lfa1-lifnr,
         name1      TYPE lfa1-name1,
         regio      TYPE lfa1-regio,
         ktokk      TYPE lfa1-ktokk,
         j_1kfrepre TYPE lfa1-j_1kfrepre,
         j_1kftind  TYPE lfa1-j_1kftind,
*         stcd4      TYPE lfa1-stcd4,
         profs      TYPE lfa1-profs,
         j_1kftbus  TYPE lfa1-j_1kftbus,
       END OF ty_lfa1.

DATA:wa_lfa1 TYPE ty_lfa1,
     it_lfa1 TYPE TABLE OF ty_lfa1.

TYPES: BEGIN OF ty_lfb1,
         lifnr TYPE lfb1-lifnr,
         bukrs TYPE lfb1-bukrs,
         akont TYPE lfb1-akont,
         kverm TYPE lfb1-kverm,
         zterm TYPE lfb1-zterm, "Added by Rutvi on 19.02.2024
       END OF ty_lfb1.

********************Added by Rutvi on 19.02.2024
TYPES: BEGIN OF ty_t052u,
         spras TYPE spras,
         zterm TYPE dzterm,
         text1 TYPE text1_052,
       END OF ty_t052u.

DATA: it_t052u TYPE TABLE OF ty_t052u,
      wa_t052u TYPE ty_t052u.
************************************************

DATA:wa_lfb1 TYPE ty_lfb1,
     it_lfb1 TYPE TABLE OF ty_lfb1.

TYPES: BEGIN OF ty_t077y,
         ktokk TYPE t077y-ktokk,
         txt30 TYPE t077y-txt30,
       END OF ty_t077y.

DATA:wa_t077y TYPE ty_t077y,
     it_t077y TYPE TABLE OF ty_t077y.
*****" Added for auth. at company level by Carina Jose on 06.03.2020
TYPES: BEGIN OF ty_t001,
         bukrs TYPE bukrs,
       END OF ty_t001.
DATA : gt_t001 TYPE STANDARD TABLE OF ty_t001,
       wa_t001 TYPE ty_t001.
*****" Added for auth. at company level by Carina Jose on 06.03.2020
*User Command Logic
TYPES: BEGIN OF ty_bsik,
         umskz TYPE bsik-umskz,
         gjahr TYPE bsik-gjahr,
         belnr TYPE bsik-belnr,
         dmbtr TYPE bsik-dmbtr,
         budat TYPE bsik-budat,
         bldat TYPE bsik-bldat,
         shkzg TYPE bsik-shkzg,
         bukrs TYPE bsik-bukrs,
       END OF ty_bsik.

DATA:wa_bsik TYPE ty_bsik,
     it_bsik TYPE TABLE OF ty_bsik.

START-OF-SELECTION.
  PERFORM authorization_check.  " Added for auth. at company level by Carina Jose on 06.03.2020
* Data Entered into the slabs is inserted into Internal Table
  PERFORM slabs.
* Fetching All the data from tables
  PERFORM get_data.
*Combining All Internal Table
  PERFORM combine.
*Filling Main Fieldcatalog
  PERFORM fillcat.
*Displaying Data
  PERFORM display.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM slabs.

  IF ageslb1 IS NOT INITIAL.
    CLEAR wa_slabs.
    wa_slabs-slab = 1.
    wa_slabs-days = ageslb1.
    APPEND wa_slabs TO it_slabs.
  ENDIF.

  IF ageslb2 IS NOT INITIAL.
    CLEAR wa_slabs.
    wa_slabs-slab = 2.
    wa_slabs-days = ageslb2.
    APPEND wa_slabs TO it_slabs.
  ENDIF.

  IF ageslb3 IS NOT INITIAL.
    CLEAR wa_slabs.
    wa_slabs-slab = 3.
    wa_slabs-days = ageslb3.
    APPEND wa_slabs TO it_slabs.
  ENDIF.

  IF ageslb4 IS NOT INITIAL.
    CLEAR wa_slabs.
    wa_slabs-slab = 4.
    wa_slabs-days = ageslb4.
    APPEND wa_slabs TO it_slabs.
  ENDIF.
*
*  IF ageslb5 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 5.
*    wa_slabs-days = ageslb5.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.
*
*  IF ageslb6 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 6.
*    wa_slabs-days = ageslb6.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.
*
*  IF ageslb7 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 7.
*    wa_slabs-days = ageslb7.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.
*
*  IF ageslb8 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 8.
*    wa_slabs-days = ageslb8.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.
*
*  IF ageslb9 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 9.
*    wa_slabs-days = ageslb9.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.
*
*  IF ageslb10 IS NOT INITIAL.
*    CLEAR wa_slabs.
*    wa_slabs-slab = 10.
*    wa_slabs-days = ageslb10.
*    APPEND wa_slabs TO it_slabs.
*  ENDIF.

ENDFORM.

FORM get_data .

*FOR S

  SELECT bsik~bukrs bsik~lifnr bsik~umskz bsik~augdt bsik~gjahr bsik~belnr bsik~budat bsik~bldat bsik~waers bsik~blart
         bsik~shkzg bsik~gsber bsik~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind APPENDING TABLE it_s
                                                     FROM bsik INNER JOIN lfa1 ON bsik~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON lfa1~lifnr = lfb1~lifnr AND bsik~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsik~belnr = bkpf~belnr AND bsik~bukrs = bkpf~bukrs AND bsik~gjahr = bkpf~gjahr
                                                     WHERE bsik~bukrs IN s_bukrs  AND bsik~lifnr IN s_lifnr AND bsik~budat LE s_date-low
                                                       AND bsik~gjahr IN s_gjahr  AND bsik~shkzg EQ 'S'     AND bsik~umskz IN s_umskz
                                                       AND bkpf~bstat NE 'S'      AND lfb1~akont IN s_akont AND lfa1~regio IN s_regio
                                                       AND lfa1~j_1kftind IN s_itype.


  SELECT bsak~bukrs bsak~lifnr bsak~umskz bsak~augdt bsak~gjahr bsak~belnr bsak~budat bsak~bldat bsak~waers bsak~blart
         bsak~shkzg bsak~gsber bsak~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind APPENDING TABLE it_s "
                                                     FROM bsak INNER JOIN lfa1 ON bsak~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON lfa1~lifnr = lfb1~lifnr AND bsak~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsak~belnr = bkpf~belnr AND bsak~bukrs = bkpf~bukrs AND bsak~gjahr = bkpf~gjahr
                                                     WHERE bsak~bukrs IN s_bukrs    AND bsak~lifnr IN s_lifnr
                                                       AND bsak~budat LE s_date-low AND bsak~augdt GT s_date-low
                                                       AND bsak~gjahr IN s_gjahr    AND bsak~shkzg EQ 'S'
                                                       AND bsak~umskz IN s_umskz        AND bkpf~bstat NE 'S'
                                                       AND lfb1~akont IN s_akont    AND lfa1~regio IN s_regio AND lfa1~j_1kftind IN s_itype.

*FOR H

  SELECT bsik~bukrs bsik~lifnr bsik~umskz bsik~augdt bsik~gjahr bsik~belnr bsik~budat bsik~bldat bsik~waers bsik~blart
         bsik~shkzg bsik~gsber bsik~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind INTO TABLE it_h
                                                     FROM bsik INNER JOIN lfa1 ON bsik~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON bsik~lifnr = lfb1~lifnr AND bsik~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsik~belnr = bkpf~belnr AND bsik~bukrs = bkpf~bukrs AND bsik~gjahr = bkpf~gjahr
                                                     WHERE bsik~bukrs IN s_bukrs AND bsik~lifnr IN s_lifnr AND bsik~budat LE s_date-low
                                                       AND bsik~gjahr IN s_gjahr AND bsik~shkzg EQ 'H'     AND bsik~umskz IN s_umskz
                                                       AND bkpf~bstat NE 'S'     AND lfb1~akont IN s_akont AND lfa1~regio IN s_regio
                                                        AND lfa1~j_1kftind IN s_itype.


  SELECT bsak~bukrs bsak~lifnr bsak~umskz bsak~augdt bsak~gjahr bsak~belnr bsak~budat bsak~bldat bsak~waers bsak~blart
         bsak~shkzg bsak~gsber bsak~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind APPENDING TABLE it_h
                                                     FROM bsak INNER JOIN lfa1 ON bsak~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON bsak~lifnr = lfb1~lifnr AND bsak~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsak~belnr = bkpf~belnr AND bsak~bukrs = bkpf~bukrs AND bsak~gjahr = bkpf~gjahr
                                                     WHERE bsak~bukrs IN s_bukrs     AND bsak~lifnr IN s_lifnr
                                                       AND bsak~budat LE s_date-low  AND bsak~augdt GT s_date-low
                                                       AND bsak~gjahr IN s_gjahr     AND bsak~shkzg EQ 'H'
                                                       AND bsak~umskz IN s_umskz         AND bkpf~bstat NE 'S'
                                                       AND lfb1~akont IN s_akont     AND lfa1~regio IN s_regio
                                                        AND lfa1~j_1kftind IN s_itype.
*For Special G/L

  SELECT bsik~bukrs bsik~lifnr bsik~umskz bsik~augdt bsik~gjahr bsik~belnr bsik~budat bsik~bldat bsik~waers bsik~blart
         bsik~shkzg bsik~gsber bsik~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind INTO TABLE it_spl
                                                     FROM bsik INNER JOIN lfa1 ON bsik~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON bsik~lifnr = lfb1~lifnr  AND bsik~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsik~belnr = bkpf~belnr  AND bsik~bukrs = bkpf~bukrs AND bsik~gjahr = bkpf~gjahr
                                                     WHERE bsik~bukrs IN s_bukrs     AND bsik~lifnr IN s_lifnr
                                                       AND bsik~budat LE s_date-low  AND bsik~gjahr IN s_gjahr
                                                       AND bkpf~bstat NE 'S'         AND lfb1~akont IN s_akont
*                                                       AND lfa1~regio IN s_regio     AND bsik~umskz NE ' '
                                                       AND lfa1~regio IN s_regio     AND bsik~umskz IN s_umskz
                                                       AND lfa1~j_1kftind IN s_itype.


  SELECT bsak~bukrs bsak~lifnr bsak~umskz bsak~augdt bsak~gjahr bsak~belnr bsak~budat bsak~bldat bsak~waers bsak~blart
         bsak~shkzg bsak~gsber bsak~dmbtr lfa1~ktokk lfa1~regio lfa1~name1 lfb1~akont lfb1~busab lfa1~j_1kftind APPENDING TABLE it_spl
                                                     FROM bsak INNER JOIN lfa1 ON bsak~lifnr = lfa1~lifnr
                                                     INNER JOIN lfb1 ON bsak~lifnr = lfb1~lifnr AND bsak~bukrs = lfb1~bukrs
                                                     INNER JOIN bkpf ON bsak~belnr = bkpf~belnr AND bsak~bukrs = bkpf~bukrs AND bsak~gjahr = bkpf~gjahr
                                                     WHERE bsak~bukrs IN s_bukrs      AND bsak~lifnr IN s_lifnr
                                                       AND bsak~budat LE s_date-low   AND bsak~augdt GT s_date-low
*                                                       AND bsak~gjahr IN s_gjahr      AND bsak~umskz NE ' '
                                                       AND bsak~gjahr IN s_gjahr      AND bsak~umskz IN s_umskz
                                                       AND bkpf~bstat NE 'S'          AND lfb1~akont IN s_akont
*                                                       AND lfa1~regio IN s_regio      AND bsak~umskz NE ' '
                                                       AND lfa1~regio IN s_regio      AND bsak~umskz IN s_umskz
                                                       AND lfa1~j_1kftind IN s_itype.

  IF p_budat EQ 'X'.
    SORT it_s BY bukrs lifnr gjahr."budat augdt." gjahr." budat augdt.
    SORT it_h BY bukrs lifnr budat augdt.
  ELSE.
    SORT it_s BY bukrs lifnr gjahr."bldat augdt. "gjahr."bldat augdt.
    SORT it_h BY bukrs lifnr bldat augdt.
  ENDIF.

  LOOP AT it_s INTO wa_s.

    v_amount = v_amount + wa_s-dmbtr.
    v_gjahr = wa_s-gjahr.

    AT END OF lifnr.

      wa_sum-bukrs = wa_s-bukrs.
      wa_sum-lifnr = wa_s-lifnr.
      wa_sum-dmbtr = v_amount.
      wa_sum-gjahr = v_gjahr.
      APPEND wa_sum TO it_sum.
      CLEAR:wa_sum,v_amount,v_gjahr.

    ENDAT.
    CLEAR:wa_sum.
  ENDLOOP.

  IF it_s IS NOT INITIAL.
    SELECT lifnr FROM lfa1 INTO TABLE it_lifnr FOR ALL ENTRIES IN it_s WHERE lifnr = it_s-lifnr.
  ENDIF.
  IF it_h IS NOT INITIAL.
    SELECT lifnr FROM lfa1 APPENDING TABLE it_lifnr FOR ALL ENTRIES IN it_h WHERE lifnr = it_h-lifnr.
  ENDIF.
  IF it_spl IS NOT INITIAL.
    SELECT lifnr FROM lfa1 APPENDING TABLE it_lifnr FOR ALL ENTRIES IN it_spl WHERE lifnr = it_spl-lifnr.
  ENDIF.

  SORT it_lifnr BY lifnr.
  DELETE ADJACENT DUPLICATES FROM it_lifnr COMPARING lifnr.

  IF it_lifnr[] IS NOT INITIAL.

    SELECT lifnr name1 regio ktokk j_1kfrepre j_1kftind  profs j_1kftbus FROM lfa1 INTO
                                              TABLE it_lfa1
                                              FOR ALL ENTRIES IN it_lifnr
                                              WHERE lifnr = it_lifnr-lifnr.

    SELECT lifnr bukrs akont kverm zterm FROM lfb1
                             INTO TABLE it_lfb1
                             FOR ALL ENTRIES IN it_lifnr
                             WHERE lifnr = it_lifnr-lifnr
                             AND bukrs = s_bukrs-low.

************************Added by Rutvi on 19.02.2024
    IF it_lfb1 IS NOT INITIAL.
      SELECT spras
             zterm
             text1 FROM t052u INTO TABLE it_t052u
             FOR ALL ENTRIES IN it_lfb1 WHERE zterm = it_lfb1-zterm.
    ENDIF.
****************************************************

  ENDIF.

  IF it_lfa1 IS NOT INITIAL.

    SELECT ktokk
           txt30 FROM t077y INTO TABLE it_t077y FOR ALL ENTRIES IN it_lfa1 WHERE ktokk = it_lfa1-ktokk AND spras = 'EN'. "#EC CI_NOORDER

  ENDIF.

ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  COMBINE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM combine .

  CLEAR:v_amount.



  LOOP AT it_lifnr INTO wa_lifnr.

*    READ TABLE it_sum INTO wa_sum WITH KEY lifnr = wa_lifnr-lifnr.
*    IF sy-subrc EQ 0.
*      v_amount = wa_sum-dmbtr.
*      v_pending = wa_sum-dmbtr.
*
*      LOOP AT it_h INTO wa_h WHERE lifnr = wa_lifnr-lifnr.
*
*        v_pending = v_pending - wa_h-dmbtr.
*
*        IF v_pending GT 0.
*          wa_h-ind = 'X'.
*
*          MODIFY it_h FROM wa_h TRANSPORTING ind.
*        ELSE.
*          v_pending = v_pending * ( -1 ).
*          wa_h-dmbtr = 0.
*          wa_h-amt1 = v_pending.
*          MODIFY it_h FROM wa_h TRANSPORTING amt1 dmbtr.
*          EXIT.
*        ENDIF.
*        CLEAR:wa_h.
*      ENDLOOP.
*      IF v_pending GT 0.
*
*      ENDIF.
*
*    ELSE.
*
*    ENDIF.
*
    LOOP AT it_s INTO wa_s WHERE lifnr = wa_lifnr-lifnr.

      v_amount = wa_s-dmbtr.
      v_pending = wa_s-dmbtr.

      LOOP AT it_h INTO wa_h WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.

        IF wa_h-amt1 IS NOT INITIAL.
          v_pending = v_pending - wa_h-amt1.
        ELSE.
          v_pending = v_pending - wa_h-dmbtr.
        ENDIF.

        IF v_pending GT 0.
          wa_h-ind = 'X'.
          MODIFY it_h FROM wa_h TRANSPORTING ind.
        ELSE.
          v_pending = v_pending * ( -1 ).
          wa_h-dmbtr = 0.
          wa_h-amt1 = v_pending.
          MODIFY it_h FROM wa_h TRANSPORTING amt1 dmbtr.
          v_pending = 0.
          EXIT.
        ENDIF.
        CLEAR:wa_h.
      ENDLOOP.

      IF v_pending GT 0.
*        v_pending = v_pending * ( -1 ).
        wa_s-dmbtr = 0.
        wa_s-amt1 = v_pending.
        MODIFY it_s FROM wa_s TRANSPORTING amt1 dmbtr.
        EXIT.
      ELSE.
        wa_s-ind = 'X'.
        MODIFY it_s FROM wa_s TRANSPORTING ind.
      ENDIF.
      CLEAR:wa_s.
    ENDLOOP.
    CLEAR:v_amount,v_pending,wa_lifnr,wa_h,wa_s.

  ENDLOOP.
  CLEAR:v_amount,v_pending,v_pending1.

*  IF p_both EQ 'X'.
  PERFORM p_both.
*  ELSEIF p_normal EQ 'X'.
*    PERFORM p_normal.
*  ELSEIF p_spl EQ 'X'.
*    PERFORM p_normal.
*    REFRESH:it_tx.
*    PERFORM p_spl.
*  ENDIF.

*  IF p_both EQ 'X' OR p_normal EQ 'X'.
*
*  LOOP AT it_lifnr INTO wa_lifnr.
*
*    LOOP AT it_h INTO wa_h WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.
*
*      h = 'X'.
*      v_date = s_date-low - wa_h-budat.
*      PERFORM calslabs.
*      CLEAR:wa_h,v_date.
*
*    ENDLOOP.
*
*    CLEAR:v_date,v_amount,v_pending,v_pending1,h.
*
*    PERFORM  make_it_tx.
*
*    DATA:rem       LIKE  tit_headcdam01.
*    DATA : tempvar(15).
*
*    LOOP AT it_tx INTO wa_tx.
*
*      CONCATENATE 'WA_FINAL-CDAM' wa_tx-lev INTO tempvar.
*      PERFORM assign_tx USING wa_tx-cr tempvar."v_amount tempvar.
*
*    ENDLOOP.
*
*    wa_final-total = wa_final-cdam01 + wa_final-cdam02 + wa_final-cdam03 + wa_final-cdam04 + wa_final-cdam05 + wa_final-cdam06 +
*                     wa_final-cdam07 + wa_final-cdam08 + wa_final-cdam09 + wa_final-cdam10 + wa_final-cdam11.
*
*    wa_final-lifnr = wa_lifnr-lifnr.
*
*    READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_lifnr-lifnr.
*    IF sy-subrc EQ 0.
*
*      wa_final-name1 = wa_lfa1-name1.
*      wa_final-regio = wa_lfa1-regio.
*      wa_final-ktokk = wa_lfa1-ktokk.
*      wa_final-j_1kfrepre = wa_lfa1-j_1kfrepre.
*
*      READ TABLE it_t077y INTO wa_t077y WITH KEY ktokk = wa_lfa1-ktokk.
*      IF sy-subrc EQ 0.
*        wa_final-txt30 = wa_t077y-txt30.
*      ENDIF.
*      CLEAR:wa_lfa1.
*    ENDIF.
*
*    READ TABLE it_lfb1 INTO wa_lfb1 WITH KEY lifnr = wa_lifnr-lifnr.
*    IF sy-subrc EQ 0.
*      wa_final-akont = wa_lfb1-akont.
*      CLEAR:wa_lfb1.
*    ENDIF.
*
*    APPEND wa_final TO it_final.
*
*    CLEAR:v_0to15 , v_16to30 , v_31to60 , v_61to90 , v_91to120 , v_121to180 , v_181to270 , v_271to365 , v_366to730 , v_731to1095, v_1096to,
*          tit_headcdam01, tit_headcdam02, tit_headcdam03, tit_headcdam04, tit_headcdam05,  tit_headcdam06,
*          tit_headcdam07, tit_headcdam08, tit_headcdam09, tit_headcdam10, tit_headcdam11.
*
*    CLEAR:wa_final.
*
*  ENDLOOP.
*
**  ENDIF.
*
*  REFRESH:it_tx.
*
**  IF p_both EQ 'X' OR p_spl EQ 'X'.
*
*  LOOP AT it_lifnr INTO wa_lifnr.
*
*    CLEAR:v_date,v_amount,v_pending,v_pending1,h.
*
*    LOOP AT it_spl INTO wa_spl WHERE lifnr = wa_lifnr-lifnr.
*
*      spl = 'X'.
*      v_date = s_date-low - wa_spl-budat.
*
*      IF wa_spl-shkzg EQ 'S'.
*        wa_spl-dmbtr = wa_spl-dmbtr * ( -1 ).
*      ELSE.
*        wa_spl-dmbtr = wa_spl-dmbtr.
*      ENDIF.
*
*      PERFORM calslabs.
*      CLEAR:wa_spl,v_amount,v_date.
*    ENDLOOP.
*
*    CLEAR:v_date,v_amount,v_pending,v_pending1,h.
*
*    PERFORM  make_it_tx.
**
**    DATA:rem       LIKE  tit_headcdam01.
**    DATA : tempvar(15).
*
*    LOOP AT it_tx INTO wa_tx.
*
*      CONCATENATE 'WA_FINAL-CDAM' wa_tx-lev INTO tempvar.
*      PERFORM assign_tx USING wa_tx-cr tempvar."v_amount tempvar.
*
*    ENDLOOP.
*
*    wa_final-total = wa_final-cdam01 + wa_final-cdam02 + wa_final-cdam03 + wa_final-cdam04 + wa_final-cdam05 + wa_final-cdam06 +
*                     wa_final-cdam07 + wa_final-cdam08 + wa_final-cdam09 + wa_final-cdam10 + wa_final-cdam11.
*
*    wa_final-lifnr = wa_lifnr-lifnr.
*
*    READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_lifnr-lifnr.
*    IF sy-subrc EQ 0.
*
*      wa_final-name1 = wa_lfa1-name1.
*      wa_final-regio = wa_lfa1-regio.
*      wa_final-ktokk = wa_lfa1-ktokk.
*      wa_final-j_1kfrepre = wa_lfa1-j_1kfrepre.
*
*      READ TABLE it_t077y INTO wa_t077y WITH KEY ktokk = wa_lfa1-ktokk.
*      IF sy-subrc EQ 0.
*        wa_final-txt30 = wa_t077y-txt30.
*      ENDIF.
*      CLEAR:wa_lfa1.
*    ENDIF.
*
*    READ TABLE it_lfb1 INTO wa_lfb1 WITH KEY lifnr = wa_lifnr-lifnr.
*    IF sy-subrc EQ 0.
*      wa_final-akont = wa_lfb1-akont.
*      CLEAR:wa_lfb1.
*    ENDIF.
*
*    APPEND wa_final TO it_final.
*
*    CLEAR:v_0to15 , v_16to30 , v_31to60 , v_61to90 , v_91to120 , v_121to180 , v_181to270 , v_271to365 , v_366to730 , v_731to1095, v_1096to,
*          tit_headcdam01, tit_headcdam02, tit_headcdam03, tit_headcdam04, tit_headcdam05,  tit_headcdam06,
*          tit_headcdam07, tit_headcdam08, tit_headcdam09, tit_headcdam10, tit_headcdam11.
*
*    CLEAR:wa_final.
*  ENDLOOP.
*  ENDIF.

ENDFORM.                    " COMBINE
*&---------------------------------------------------------------------*
*&      Form  FILLCAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fillcat .

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'REGIO'.
*  wa_fcat-key       = 'X'.
  wa_fcat-seltext_m = 'Region'.
  wa_fcat-seltext_l = 'Region'.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen = 5.
*  wa_fcat-col_pos = 1.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'KTOKK'.
*  wa_fcat-key       = 'X'.
  wa_fcat-seltext_m = 'V.Grp'.
  wa_fcat-seltext_l = 'Vendor Grp'.
*  wa_fcat-tabname = 'IT_FINAL'.

  wa_fcat-outputlen = 5.
*  wa_fcat-col_pos = 2.
  APPEND wa_fcat TO it_fcat.


  CLEAR wa_fcat.
  wa_fcat-fieldname = 'TXT30'.
*  wa_fcat-key       = 'X'.
  wa_fcat-seltext_m = 'V.Grp Desc'.
  wa_fcat-seltext_l = 'Vendor Grp Desc'.
*  wa_fcat-tabname = 'IT_FINAL'.

  wa_fcat-outputlen = 5.
*  wa_fcat-col_pos = 2.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'AKONT'.
*  wa_fcat-key       = 'X'.
  wa_fcat-seltext_l = 'Recon.Account.'.                     "DEVK900410
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen = 10.
*  wa_fcat-col_pos = 3.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'LIFNR'.
*  wa_fcat-key = 'X'.
  wa_fcat-seltext_l = 'Party Code'.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-hotspot = 'X'.
*  wa_fcat-col_pos = 5.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'NAME1'.
*  wa_fcat-key = 'X'.
  wa_fcat-seltext_m = 'Name '.
  wa_fcat-seltext_l = 'Name '.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen    = 25.
*  wa_fcat-col_pos = 6.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'J_1KFTIND'.
*  wa_fcat-key = 'X'.
  wa_fcat-seltext_m = 'Type of Industry '.
  wa_fcat-seltext_l = 'Type of Industry '.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen    = 25.
*  wa_fcat-col_pos = 6.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'PROFS'.
*  wa_fcat-key = 'X'.
  wa_fcat-seltext_m = 'MSME No'.
  wa_fcat-seltext_l = 'MSME No'.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen    = 25.
*  wa_fcat-col_pos = 6.
  APPEND wa_fcat TO it_fcat.

  CLEAR wa_fcat.
  wa_fcat-fieldname = 'J_1KFTBUS'.
*  wa_fcat-key = 'X'.
  wa_fcat-seltext_m = 'Type of Business'.
  wa_fcat-seltext_l = 'Type of Business'.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-outputlen    = 25.
*  wa_fcat-col_pos = 6.
  APPEND wa_fcat TO it_fcat.

  CLEAR:wa_fcat.
  wa_fcat-fieldname = 'MEMO'.
*    wa_fcat-SELTEXT_M = 'Debit Bal.'.
  wa_fcat-seltext_m = 'HOD'.
  wa_fcat-seltext_l = 'HOD'.
*  wa_fcat-do_sum    = 'X'.
  wa_fcat-outputlen = 25.

  APPEND wa_fcat TO it_fcat.
  CLEAR:wa_fcat.
*************************Added by Rutvi on 19.02.2024
  CLEAR:wa_fcat.
  wa_fcat-fieldname = 'ZTERM'.
*    wa_fcat-SELTEXT_M = 'Debit Bal.'.
  wa_fcat-seltext_m = 'Payment term '.
  wa_fcat-seltext_l = 'Payment term '.
*  wa_fcat-do_sum    = 'X'.
  wa_fcat-outputlen = 4.

  APPEND wa_fcat TO it_fcat.
  CLEAR:wa_fcat.

  CLEAR:wa_fcat.
  wa_fcat-fieldname = 'TEXT1'.
*    wa_fcat-SELTEXT_M = 'Debit Bal.'.
  wa_fcat-seltext_m = 'Payment term Description '.
  wa_fcat-seltext_l = 'Payment term Desc '.
*  wa_fcat-do_sum    = 'X'.
  wa_fcat-outputlen = 50.

  APPEND wa_fcat TO it_fcat.
  CLEAR:wa_fcat.
******************************************************************

  LOOP AT it_slabs INTO wa_slabs.

    CLEAR wa_fcat.

    WRITE wa_slabs-days NO-ZERO TO wa_slabs-days.
    WRITE pit_slabsdays NO-ZERO TO pit_slabsdays.
    CONCATENATE 'CDAM' wa_slabs-slab INTO fldname.
    wa_fcat-fieldname    = fldname.

    IF sy-tabix = 1.
      CONCATENATE '0 - ' wa_slabs-days INTO lbcdam1.
      pit_slabsdays = wa_slabs-days + 1.
    ELSE.
      CONCATENATE pit_slabsdays ' - ' wa_slabs-days INTO lbcdam1.
      pit_slabsdays = wa_slabs-days + 1.
    ENDIF.
    wa_fcat-seltext_m = lbcdam1.
*    wa_fcat-tabname = 'IT_FINAL'.
    wa_fcat-do_sum = 'X'.
    wa_fcat-outputlen    = 14.
    wa_fcat-just = 'R'.
*    wa_fcat-col_pos = 7.
    APPEND wa_fcat TO it_fcat.
    tcounter = tcounter + 1.

  ENDLOOP.

  tcounter = tcounter + 1.
  pit_slabsdays = pit_slabsdays - 1.
  CLEAR wa_fcat.
  CONCATENATE 'CDAM' tcounter INTO fldname.
  wa_fcat-fieldname    = fldname.
  WRITE pit_slabsdays NO-ZERO TO pit_slabsdays.
  CONCATENATE ' > ' pit_slabsdays INTO lbcdam1.
  wa_fcat-seltext_m = lbcdam1.
*  wa_fcat-tabname = 'IT_FINAL'.
  wa_fcat-do_sum = 'X'.
  wa_fcat-outputlen    = 14.
  wa_fcat-just = 'R'.
*  wa_fcat-col_pos = 8.
  APPEND wa_fcat TO it_fcat.



  CLEAR:wa_fcat.
  wa_fcat-fieldname = 'TOTAL'.
*    wa_fcat-SELTEXT_M = 'Debit Bal.'.
  wa_fcat-seltext_m = 'Total '.
  wa_fcat-seltext_l = ''.
  wa_fcat-do_sum    = 'X'.
  wa_fcat-outputlen = 14.
  wa_fcat-just      = 'R'.
*    wa_fcat-col_pos = 14.
  APPEND wa_fcat TO it_fcat.
  CLEAR:wa_fcat.


  CLEAR:wa_fcat.
  wa_fcat-fieldname = 'SPL'.
*    wa_fcat-SELTEXT_M = 'Debit Bal.'.
  wa_fcat-seltext_m = 'Spl. G/L Ind '.
  wa_fcat-seltext_l = 'Spl. G/L Ind '.
  wa_fcat-do_sum    = 'X'.
  wa_fcat-outputlen = 1.
*  wa_fcat-just      = 'R'.
*    wa_fcat-col_pos = 14.
  APPEND wa_fcat TO it_fcat.
  CLEAR:wa_fcat.



  wa_layout-zebra = 'X'.
  wa_layout-colwidth_optimize = 'X'.
  wa_layout-info_fieldname = 'COLOR'.


ENDFORM.                    " FILLCAT
*&---------------------------------------------------------------------*
*&      Form  CALSLABS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM calslabs .

  DATA : counter(2) TYPE n.
  DATA : tempvar(14).
  DATA : fountrec   TYPE  c.

  LOOP AT it_slabs INTO wa_slabs.

    IF v_date LE wa_slabs-days.

      CONCATENATE 'TIT_HEADCDAM' wa_slabs-slab INTO tempvar.

      CASE tempvar.
        WHEN 'TIT_HEADCDAM01'.
          PERFORM updcdamt CHANGING tit_headcdam01.
          fountrec = 'X'.
          EXIT.
        WHEN 'TIT_HEADCDAM02'.
          PERFORM updcdamt CHANGING tit_headcdam02.
          fountrec = 'X'.
          EXIT.
        WHEN 'TIT_HEADCDAM03'.
          PERFORM updcdamt CHANGING tit_headcdam03.
          fountrec = 'X'.
          EXIT.
        WHEN 'TIT_HEADCDAM04'.
          PERFORM updcdamt CHANGING tit_headcdam04.
          fountrec = 'X'.
          EXIT.
*        WHEN 'TIT_HEADCDAM05'.
*          PERFORM updcdamt CHANGING tit_headcdam05.
*          fountrec = 'X'.
*          EXIT.
*        WHEN 'TIT_HEADCDAM06'.
*          PERFORM updcdamt CHANGING tit_headcdam06.
*          fountrec = 'X'.
*          EXIT.
*        WHEN 'TIT_HEADCDAM07'.
*          PERFORM updcdamt CHANGING tit_headcdam07.
*          fountrec = 'X'.
*          EXIT.
*        WHEN 'TIT_HEADCDAM08'.
*          PERFORM updcdamt CHANGING tit_headcdam08.
*          fountrec = 'X'.
*          EXIT.
*        WHEN 'TIT_HEADCDAM09'.
*          PERFORM updcdamt CHANGING tit_headcdam09.
*          fountrec = 'X'.
*          EXIT.
*        WHEN 'TIT_HEADCDAM10'.
*          PERFORM updcdamt CHANGING tit_headcdam10.
*          fountrec = 'X'.
*          EXIT.
      ENDCASE.

    ENDIF.
    counter = counter + 1.
  ENDLOOP.

  counter = counter + 1.

  IF fountrec = ' '.

    CONCATENATE 'TIT_HEADCDAM' counter INTO tempvar.
    CASE tempvar.
      WHEN 'TIT_HEADCDAM01'.
        PERFORM updcdamt CHANGING tit_headcdam01.
        fountrec = 'X'.
        EXIT.
      WHEN 'TIT_HEADCDAM02'.
        PERFORM updcdamt CHANGING tit_headcdam02.
        fountrec = 'X'.
        EXIT.
      WHEN 'TIT_HEADCDAM03'.
        PERFORM updcdamt CHANGING tit_headcdam03.
        fountrec = 'X'.
        EXIT.
      WHEN 'TIT_HEADCDAM04'.
        PERFORM updcdamt CHANGING tit_headcdam04.
        fountrec = 'X'.
        EXIT.
      WHEN 'TIT_HEADCDAM05'.
        PERFORM updcdamt CHANGING tit_headcdam05.
        fountrec = 'X'.
        EXIT.
*      WHEN 'TIT_HEADCDAM06'.
*        PERFORM updcdamt CHANGING tit_headcdam06.
*        fountrec = 'X'.
*        EXIT.
*      WHEN 'TIT_HEADCDAM07'.
*        PERFORM updcdamt CHANGING tit_headcdam07.
*        fountrec = 'X'.
*        EXIT.
*      WHEN 'TIT_HEADCDAM08'.
*        PERFORM updcdamt CHANGING tit_headcdam08.
*        fountrec = 'X'.
*        EXIT.
*      WHEN 'TIT_HEADCDAM09'.
*        PERFORM updcdamt CHANGING tit_headcdam09.
*        fountrec = 'X'.
*        EXIT.
*      WHEN 'TIT_HEADCDAM10'.
*        PERFORM updcdamt CHANGING tit_headcdam10.
*        fountrec = 'X'.
*        EXIT.
*      WHEN 'TIT_HEADCDAM11'.
*        PERFORM updcdamt CHANGING tit_headcdam10.
*        fountrec = 'X'.
*        EXIT.
    ENDCASE.

  ENDIF.

ENDFORM.                    " CALSLABS
*&---------------------------------------------------------------------*
*&      Form  UPDCDAMT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_TIT_HEADCDAM01  text
*      <--P_TIT_HEADTOTCD  text
*      <--P_T1  text
*----------------------------------------------------------------------*
FORM updcdamt  CHANGING p_amount.

  IF h EQ 'X'.

    IF wa_h-amt1 IS NOT INITIAL.
      p_amount = p_amount - wa_h-amt1.
    ELSE.
      p_amount = p_amount - wa_h-dmbtr.
    ENDIF.

  ELSEIF spl EQ 'X'.

    IF wa_spl-amt1 IS NOT INITIAL.
      p_amount = p_amount + wa_spl-amt1.
    ELSE.
      p_amount = p_amount + wa_spl-dmbtr.
    ENDIF.

  ELSEIF s EQ 'X'.

    IF wa_s-amt1 IS NOT INITIAL.
      p_amount = p_amount + wa_s-amt1.
    ELSE.
      p_amount = p_amount + wa_s-dmbtr.
    ENDIF.

  ENDIF.

ENDFORM.                    " UPDCDAMT
*&---------------------------------------------------------------------*
*&      Form  MAKE_IT_TX
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM make_it_tx .

*  wa_tx-lev = 11.
*  wa_tx-cr = tit_headcdam11.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
*  wa_tx-lev = 10.
*  wa_tx-cr = tit_headcdam10.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
*  wa_tx-lev = 9.
*  wa_tx-cr = tit_headcdam09.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
*  wa_tx-lev = 8.
*  wa_tx-cr = tit_headcdam08.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
*  wa_tx-lev = 7.
*  wa_tx-cr = tit_headcdam07.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
*  wa_tx-lev = 6.
*  wa_tx-cr = tit_headcdam06.
*  APPEND wa_tx TO it_tx.
*  CLEAR:wa_tx.
*
  wa_tx-lev = 5.
  wa_tx-cr = tit_headcdam05.
  APPEND wa_tx TO it_tx.
  CLEAR:wa_tx.

  wa_tx-lev = 4.
  wa_tx-cr = tit_headcdam04.
  APPEND wa_tx TO it_tx.
  CLEAR:wa_tx.

  wa_tx-lev = 3.
  wa_tx-cr = tit_headcdam03.
  APPEND wa_tx TO it_tx.
  CLEAR:wa_tx.

  wa_tx-lev = 2.
  wa_tx-cr = tit_headcdam02.
  APPEND wa_tx TO it_tx.
  CLEAR:wa_tx.

  wa_tx-lev = 1.
  wa_tx-cr = tit_headcdam01.
  APPEND wa_tx TO it_tx.
  CLEAR:wa_tx.

ENDFORM.                    " MAKE_IT_TX

FORM assign_tx  USING p_rem p_tempvar.

  CASE  p_tempvar.
*    WHEN 'WA_FINAL-CDAM11'.
*      wa_final-cdam11 = p_rem."0.
*    WHEN 'WA_FINAL-CDAM10'.
*      wa_final-cdam10 = p_rem."0.
*    WHEN 'WA_FINAL-CDAM09'.
*      wa_final-cdam09 = p_rem."0.
*    WHEN 'WA_FINAL-CDAM08'.
*      wa_final-cdam08 = p_rem."0.
*    WHEN 'WA_FINAL-CDAM07'.
*      wa_final-cdam07 = p_rem."0.
*    WHEN 'WA_FINAL-CDAM06'.
*      wa_final-cdam06 = p_rem."0.
    WHEN 'WA_FINAL-CDAM05'.
      wa_final-cdam05 = p_rem."0.
    WHEN 'WA_FINAL-CDAM04'.
      wa_final-cdam04 = p_rem."0.
    WHEN 'WA_FINAL-CDAM03'.
      wa_final-cdam03 = p_rem."0.
    WHEN 'WA_FINAL-CDAM02'.
      wa_final-cdam02 = p_rem."0.
    WHEN 'WA_FINAL-CDAM01'.
      wa_final-cdam01 = p_rem."0.
  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display .



  SORT it_final BY lifnr.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program      = sy-repid
*     is_layout               = wa_layout
      is_layout               = gd_layout
      i_callback_user_command = 'USER_COMMAND'
      i_callback_top_of_page  = 'TOP_PAGE'
      it_fieldcat             = it_fcat[]
*     it_special_groups       = i_sp_group[]
*     IT_SORT                 =
      i_save                  = 'A'
      it_events               = i_events[]
    TABLES
      t_outtab                = it_final
    EXCEPTIONS
      program_error           = 1
      OTHERS                  = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


ENDFORM.
FORM top_page.
  DATA : wa_header TYPE slis_listheader.
  DATA : it_header TYPE slis_t_listheader.
  DATA : v_wheret(100).
  DATA : v_lowdate(10).
  DATA : v_highdate(10).
  DATA: v_times(10).


  wa_header-typ = 'H'.

  wa_header-info = 'Vendor Ageing Report-MSME (Based on Doc. Date)'.
*  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  IF NOT s_date-high IS INITIAL.
    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
    CONCATENATE s_date-high+6(2) '-' s_date-high+4(2) '-' s_date-high+0(4) INTO v_highdate.
    CONCATENATE 'Date :- ' v_lowdate  ' TO ' v_highdate INTO wa_header-info SEPARATED BY space.
  ELSE.
    CONCATENATE s_date-low+6(2) '-' s_date-low+4(2) '-' s_date-low+0(4) INTO v_lowdate.
    LOOP AT s_date.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_date-low IS INITIAL.
          CONCATENATE wa_header-info ',' v_lowdate INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE sy-uzeit+0(2)':' sy-uzeit+2(2)':' sy-uzeit+4(2) INTO v_times.
        CONCATENATE 'Date & time :- ' v_lowdate  v_times INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.
  CLEAR : v_lowdate,v_highdate.

  wa_header-typ = 'S'.
  IF NOT s_bukrs-high IS INITIAL.
    CONCATENATE 'Company Code :- ' s_bukrs-low  ' TO ' s_bukrs-high INTO wa_header-info SEPARATED BY space.
  ELSE.
    LOOP AT s_bukrs.
      IF NOT wa_header-info IS INITIAL.
        IF NOT s_bukrs-low IS INITIAL.
          CONCATENATE wa_header-info ',' s_bukrs-low INTO wa_header-info.
        ENDIF.
      ELSE.
        CONCATENATE 'Company Code :- ' s_bukrs-low INTO wa_header-info SEPARATED BY space.
      ENDIF.
    ENDLOOP.
  ENDIF.
  APPEND wa_header TO it_header.
  CLEAR wa_header.

  wa_header-typ = 'S'.
  SELECT SINGLE butxt
                INTO wa_header-info
                FROM t001
                WHERE bukrs = s_bukrs-low.

  APPEND wa_header TO it_header.
  CLEAR wa_header.




  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_header.
*      I_LOGO             = 'ASTRALS'.


ENDFORM.         " DISPLAY

FORM user_command USING ucomm LIKE sy-ucomm
                        selfield TYPE slis_selfield.

  DATA : value1     TYPE  char30.

  CASE ucomm.

    WHEN '&IC1'.

      value1 = selfield-value.

      CASE selfield-fieldname.

        WHEN 'LIFNR'.

          SELECT bsik~umskz bsik~gjahr bsik~belnr bsik~dmbtr
                 bsik~budat bsik~bldat bsik~shkzg bsik~bukrs INTO TABLE it_bsik
                                                  FROM bsik
                                                  INNER JOIN bkpf ON bsik~belnr = bkpf~belnr AND bsik~bukrs = bkpf~bukrs AND bsik~gjahr = bkpf~gjahr
                                                  WHERE bsik~bukrs IN s_bukrs  AND bsik~lifnr EQ selfield-value AND bsik~budat LE s_date-low
                                                  AND bsik~gjahr IN s_gjahr    AND bkpf~bstat NE 'S' AND bsik~umskz IN s_umskz.


          SELECT bsak~umskz bsak~gjahr bsak~belnr bsak~dmbtr
                 bsak~budat bsak~bldat bsak~shkzg bsak~bukrs APPENDING TABLE it_bsik
                                                  FROM bsak
                                                  INNER JOIN bkpf ON bsak~belnr = bkpf~belnr AND bsak~bukrs = bkpf~bukrs AND bsak~gjahr = bkpf~gjahr
                                                  WHERE bsak~bukrs IN s_bukrs  AND bsak~lifnr EQ selfield-value AND bsak~budat LE s_date-low
                                                    AND bsak~augdt GT s_date-low AND bsak~gjahr IN s_gjahr    AND bkpf~bstat NE 'S' AND bsak~umskz IN s_umskz.
          DATA: lv_flag TYPE flag.

          "Authorization check from stvarv table.

          DATA: r_astral TYPE RANGE OF tvarvc-low.
          DATA: r_adhesive TYPE RANGE OF tvarvc-low.
          REFRESH: r_astral,r_adhesive.
          SELECT low FROM tvarvc INTO TABLE @DATA(lt_astral)
              WHERE name = 'Z_MSME_ASTRAL'.

          r_astral = VALUE #( FOR ls_astral IN lt_astral
                              LET s      = 'I'
                                  o      = 'EQ'
                              IN  sign   = s
                                  option = o
                              ( low = ls_astral-low )
                            ).

          SELECT low FROM tvarvc INTO TABLE @DATA(lt_adhesive)
             WHERE name = 'Z_MSME_ADHESIVE'.

          r_adhesive = VALUE #( FOR ls_adhesive IN lt_adhesive
                                LET s      = 'I'
                                    o      = 'EQ'
                                IN  sign   = s
                                    option = o
                                ( low = ls_adhesive-low )
                              ).


          " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
          SORT it_bsik .
          " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC
          LOOP AT it_bsik INTO wa_bsik.
            CLEAR: lv_flag.
            """"""""SQUIRREL"""""" START
            " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*            SELECT SINGLE gjahr,belnr,rbukrs,MAX( prctr ) AS prctr FROM faglflexa INTO @DATA(ls_faglf)
*              WHERE belnr = @wa_bsik-belnr AND gjahr = @wa_bsik-gjahr AND rbukrs = @wa_bsik-bukrs GROUP BY gjahr,belnr,rbukrs.
            SELECT gjahr , belnr , rbukrs , MAX( prctr ) AS prctr FROM faglflexa
            UP TO 1 ROWS INTO @DATA(ls_faglf)
              WHERE belnr = @wa_bsik-belnr AND
           gjahr = @wa_bsik-gjahr AND rbukrs = @wa_bsik-bukrs
           GROUP BY gjahr , belnr , rbukrs.             "#EC CI_NOORDER
            ENDSELECT.
            " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

            IF ls_faglf-prctr IS NOT INITIAL.
              IF p_plnt1 = 'X'.
*                IF ls_faglf-prctr+0(1) EQ '1' OR ls_faglf-prctr+0(1) EQ '5'.
*                IF ls_faglf-prctr+0(1) IN r_astral.
                IF ls_faglf-prctr+4(1) IN r_astral.
                  AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
                  ID 'ACTVT' FIELD '03'
                  ID 'PRCTR' FIELD ls_faglf-prctr.
                  IF sy-subrc <> 0.
                    MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
                    LEAVE LIST-PROCESSING.
                  ENDIF.
                ELSE.
                  DELETE it_bsik WHERE belnr = wa_bsik-belnr AND gjahr = wa_bsik-gjahr AND bukrs = wa_bsik-bukrs.
                  lv_flag = 'X'.
                ENDIF.

              ELSEIF p_plnt2 = 'X'.
*                IF ls_faglf-prctr+0(1) EQ '4'.
*                IF ls_faglf-prctr+0(1) IN r_adhesive.
                IF ls_faglf-prctr+4(1) IN r_adhesive.
                  AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
                  ID 'ACTVT' FIELD '03'
                  ID 'PRCTR' FIELD ls_faglf-prctr.
                  IF sy-subrc <> 0.
                    MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
                    LEAVE LIST-PROCESSING.
                  ENDIF.
                ELSE.
                  DELETE it_bsik WHERE belnr = wa_bsik-belnr AND gjahr = wa_bsik-gjahr AND bukrs = wa_bsik-bukrs.
                  lv_flag = 'X'.
                ENDIF.
              ENDIF.

            ELSE.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*              SELECT SINGLE bupla FROM bsak INTO @DATA(lv_bupla2) WHERE
*              belnr = @wa_bsik-belnr AND gjahr = @wa_bsik-gjahr AND bukrs = @wa_bsik-bukrs ."GROUP BY gjahr,belnr,bukrs.

              SELECT bupla FROM bsak INTO @DATA(lv_bupla2) UP TO 1 ROWS WHERE
               belnr = @wa_bsik-belnr AND gjahr = @wa_bsik-gjahr AND bukrs = @wa_bsik-bukrs
               ORDER BY PRIMARY KEY .
              ENDSELECT."GROUP BY gjahr,belnr,bukrs.

* End of Quick Fix

              IF lv_bupla2 IS NOT INITIAL.
                IF p_plnt1 = 'X'.
                  IF lv_bupla2+2(2) = 'AP'.
                    AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
          ID 'ACTVT' FIELD '03'
          ID 'ZBUPLA' FIELD lv_bupla2+2(2).
                    IF sy-subrc <> 0.
                      MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
                      LEAVE LIST-PROCESSING.
                    ENDIF.
                  ELSE.
                    DELETE it_bsik WHERE belnr = wa_bsik-belnr AND gjahr = wa_bsik-gjahr AND bukrs = wa_bsik-bukrs.
                    lv_flag = 'X'.
                  ENDIF.
                ELSEIF p_plnt2 = 'X'.
                  IF lv_bupla2+2(2) = 'RC'.
                    AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
ID 'ACTVT' FIELD '03'
ID 'ZBUPLA' FIELD lv_bupla2+2(2).
                    IF sy-subrc <> 0.
                      MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
                      LEAVE LIST-PROCESSING.
                    ENDIF.
                  ELSE.
                    DELETE it_bsik WHERE belnr = wa_bsik-belnr AND gjahr = wa_bsik-gjahr AND bukrs = wa_bsik-bukrs.
                    lv_flag = 'X'.
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDIF.
            """""""END"""""""""
            IF lv_flag IS INITIAL.
              IF wa_bsik-shkzg EQ 'H'.
                wa_bsik-dmbtr = wa_bsik-dmbtr * ( -1 ).
              ELSE.
                wa_bsik-dmbtr = wa_bsik-dmbtr.
              ENDIF.
              MODIFY it_bsik FROM wa_bsik TRANSPORTING dmbtr.
            ENDIF.

          ENDLOOP.

          DEFINE fillcat.

            wa_fcat1-fieldname = &1.
            wa_fcat1-tabname   = &2.
            wa_fcat1-seltext_m = &3.
            wa_fcat1-col_pos    = &4.
            wa_fcat1-hotspot    = &5.
            APPEND wa_fcat1 TO it_fcat1.
            CLEAR:wa_fcat1.

          END-OF-DEFINITION.

          fillcat 'BELNR' 'IT_BSIK' 'Document'          1      'X' .
          fillcat 'GJAHR' 'IT_BSIK' 'Fiscal Year'       2      ' ' .
          fillcat 'BUDAT' 'IT_BSIK' 'Posting Date'      3      ' ' .
          fillcat 'BLDAT' 'IT_BSIK' 'Document Date'     4      ' ' .
          fillcat 'DMBTR' 'IT_BSIK' 'Amount'            5      ' ' .
          fillcat 'SHKZG' 'IT_BSIK' 'Credit/Debit Ind.' 6      ' ' .
          fillcat 'UMSKZ' 'IT_BSIK' 'Spl G/L Ind'       7      ' ' .

          CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
            EXPORTING
              i_callback_program       = sy-repid
              i_callback_pf_status_set = ' '
              is_layout                = gd_layout
              i_callback_user_command  = 'USER_COMMAND'
              it_fieldcat              = it_fcat1[]
              i_save                   = 'A'
            TABLES
              t_outtab                 = it_bsik
            EXCEPTIONS
              program_error            = 1
              OTHERS                   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          ENDIF.

          REFRESH:it_bsik,it_fcat1.

        WHEN 'BELNR'.

          READ TABLE it_bsik INTO wa_bsik INDEX selfield-tabindex.

          IF sy-subrc EQ 0.
            SET PARAMETER ID 'BLN' FIELD wa_bsik-belnr.
            SET PARAMETER ID 'BUK' FIELD wa_bsik-bukrs.
            SET PARAMETER ID 'GJR' FIELD wa_bsik-gjahr.
            CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN.
          ENDIF.

      ENDCASE.

  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  P_BOTH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM p_both .


  DATA:rem       LIKE  tit_headcdam01.
  DATA : tempvar(15).

  DATA: r_astral TYPE RANGE OF tvarvc-low.
  DATA: r_adhesive TYPE RANGE OF tvarvc-low.
  DATA: r_paint TYPE RANGE OF tvarvc-low.
  REFRESH: r_astral,r_adhesive,r_paint.
  SELECT low FROM tvarvc INTO TABLE @DATA(lt_astral)
      WHERE name = 'Z_MSME_ASTRAL'.

  r_astral = VALUE #( FOR ls_astral IN lt_astral
                      LET s      = 'I'
                          o      = 'EQ'
                      IN  sign   = s
                          option = o
                      ( low = ls_astral-low )
                    ).

  SELECT low FROM tvarvc INTO TABLE @DATA(lt_adhesive)
     WHERE name = 'Z_MSME_ADHESIVE'.

  r_adhesive = VALUE #( FOR ls_adhesive IN lt_adhesive
                        LET s      = 'I'
                            o      = 'EQ'
                        IN  sign   = s
                            option = o
                        ( low = ls_adhesive-low )
                      ).

***********************  for paint 14.04.2023
  SELECT low FROM tvarvc INTO TABLE @DATA(lt_paint)
    WHERE name = 'Z_MSME_PAINT'.

  r_paint = VALUE #( FOR ls_paint IN lt_paint
                     LET s      = 'I'
                         o      = 'EQ'
                     IN  sign   = s
                         option = o
                     ( low = ls_paint-low )
                   ).


****************  ened paint 14.04.2023

******SQUIRREL (Manoj) 09-09-2022 ( Authorization check on Prctr )

  LOOP AT it_h INTO DATA(ls_hauth).
    " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*    SELECT SINGLE gjahr,belnr,rbukrs,MAX( prctr ) AS prctr FROM faglflexa INTO @DATA(ls_h_faglflexa)
*          WHERE belnr = @ls_hauth-belnr AND gjahr = @ls_hauth-gjahr AND rbukrs = @ls_hauth-bukrs GROUP BY gjahr,belnr,rbukrs.
    SELECT gjahr , belnr , rbukrs , MAX( prctr ) AS prctr FROM faglflexa
    UP TO 1 ROWS INTO @DATA(ls_h_faglflexa) WHERE belnr = @ls_hauth-belnr
   AND gjahr = @ls_hauth-gjahr AND rbukrs = @ls_hauth-bukrs GROUP BY gjahr
   , belnr , rbukrs.                                    "#EC CI_NOORDER
    ENDSELECT.
    " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

    IF ls_h_faglflexa-prctr IS NOT INITIAL.
*
      IF p_plnt1 = 'X'.
*        IF ls_h_faglflexa-prctr+0(1) EQ '1' OR ls_h_faglflexa-prctr+0(1) EQ '5'.
*        IF ls_h_faglflexa-prctr+0(1) IN r_astral.
        IF ls_h_faglflexa-prctr+4(1) IN r_astral.

          AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
          ID 'ACTVT' FIELD '03'
          ID 'PRCTR' FIELD ls_h_faglflexa-prctr.
          IF sy-subrc <> 0.
            MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
            LEAVE LIST-PROCESSING.
          ENDIF.

        ELSE.
          DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.
        ENDIF.

      ELSEIF p_plnt2 = 'X'.

*        IF ls_h_faglflexa-prctr+0(1) EQ '4'.
*        IF ls_h_faglflexa-prctr+0(1) IN r_adhesive.
        IF ls_h_faglflexa-prctr+4(1) IN r_adhesive.

          AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
          ID 'ACTVT' FIELD '03'
          ID 'PRCTR' FIELD ls_h_faglflexa-prctr.
          IF sy-subrc <> 0.
            MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
            LEAVE LIST-PROCESSING.
          ENDIF.

        ELSE.
*          flagcheck = 'X'.
          DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.
        ENDIF.
*****************************         start for paint 14.04.2023
      ELSEIF p_plnt3 = 'X'.

*        IF ls_h_faglflexa-prctr+0(1) EQ '4'.
*        IF ls_h_faglflexa-prctr+0(1) IN r_paint.
        IF ls_h_faglflexa-prctr+4(1) IN r_paint.

          AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
          ID 'ACTVT' FIELD '03'
          ID 'PRCTR' FIELD ls_h_faglflexa-prctr.
          IF sy-subrc <> 0.
            MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
            LEAVE LIST-PROCESSING.
          ENDIF.
        ELSE.
*          flagcheck = 'X'.
          DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.
        ENDIF.
***********************          ended for paint 14.04.2023



      ENDIF.

    ELSE.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE bupla FROM bsak INTO @DATA(lv_bupla) WHERE
*      belnr = @wa_h-belnr AND gjahr = @wa_h-gjahr AND bukrs = @wa_h-bukrs ."GROUP BY gjahr,belnr,bukrs.

      SELECT bupla FROM bsak INTO @DATA(lv_bupla) UP TO 1 ROWS WHERE
       belnr = @wa_h-belnr AND gjahr = @wa_h-gjahr AND bukrs = @wa_h-bukrs
       ORDER BY PRIMARY KEY .
      ENDSELECT."GROUP BY gjahr,belnr,bukrs.

* End of Quick Fix

      IF lv_bupla IS NOT INITIAL.

        IF p_plnt1 = 'X'.

          IF lv_bupla+2(2) = 'AP'.

            AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
            ID 'ACTVT' FIELD '03'
            ID 'ZBUPLA' FIELD lv_bupla+2(2).
            IF sy-subrc <> 0.
              MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
              LEAVE LIST-PROCESSING.
            ENDIF.

          ELSE.
*            flagcheck = 'X'.
            DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.
          ENDIF.

        ELSEIF p_plnt2 = 'X'.

          IF lv_bupla+2(2) = 'RC'.

            AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
            ID 'ACTVT' FIELD '03'
            ID 'ZBUPLA' FIELD lv_bupla+2(2).
            IF sy-subrc <> 0.
              MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
              LEAVE LIST-PROCESSING.
            ENDIF.

          ELSE.
*            flagcheck = 'X'.
            DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.

          ENDIF.
*****************************          start for paint 14.04.2023
        ELSEIF p_plnt3 = 'X'.

          IF lv_bupla+2(2) = 'GP'.

            AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
            ID 'ACTVT' FIELD '03'
            ID 'ZBUPLA' FIELD lv_bupla+2(2).
            IF sy-subrc <> 0.
              MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
              LEAVE LIST-PROCESSING.
            ENDIF.

          ELSE.
*            flagcheck = 'X'.
            DELETE it_h WHERE belnr = ls_hauth-belnr AND gjahr = ls_hauth-gjahr AND bukrs = ls_hauth-bukrs.

          ENDIF.

************************   ened for paint 14.04.2023
        ENDIF.
      ENDIF.

    ENDIF.
  ENDLOOP.

  LOOP AT it_s INTO DATA(ls_sauth).

    " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 12.01.2026  FOR ATC
*    SELECT SINGLE gjahr,belnr,rbukrs,MAX( prctr ) AS prctr FROM faglflexa INTO @DATA(ls_s_faglflexa)
*        WHERE belnr = @ls_sauth-belnr AND gjahr = @ls_sauth-gjahr AND rbukrs = @ls_sauth-bukrs GROUP BY gjahr,belnr,rbukrs.
    SELECT gjahr , belnr , rbukrs , MAX( prctr ) AS prctr FROM faglflexa
    UP TO 1 ROWS INTO @DATA(ls_s_faglflexa) WHERE belnr = @ls_sauth-belnr
   AND gjahr = @ls_sauth-gjahr AND rbukrs = @ls_sauth-bukrs GROUP BY gjahr "#EC CI_NOORDER
   , belnr , rbukrs.  ENDSELECT.
    " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 12.01.2026 FOR ATC

    IF ls_s_faglflexa-prctr IS NOT INITIAL.


*     AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
*               ID 'ACTVT' FIELD '03'
*               ID 'PRCTR' FIELD ls_s_FAGLFLEXA-prctr.
*      IF sy-subrc <> 0.
*        delete it_h WHERE belnr = ls_sauth-belnr AND gjahr = ls_sauth-gjahr AND bukrs = ls_sauth-bukrs.
*      ENDIF.
      IF p_plnt1 = 'X'.
*        IF ls_s_faglflexa-prctr+0(1) EQ '1' OR ls_s_faglflexa-prctr+0(1) EQ '5'.
*        IF ls_s_faglflexa-prctr+0(1)  IN r_astral.
        IF ls_s_faglflexa-prctr+4(1)  IN r_astral.

          AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
          ID 'ACTVT' FIELD '03'
          ID 'PRCTR' FIELD ls_s_faglflexa-prctr.
          IF sy-subrc <> 0.
            MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
            LEAVE LIST-PROCESSING.
          ENDIF.

        ELSE.
*           flagcheck = 'X'.
          DELETE it_s WHERE belnr = ls_sauth-belnr AND gjahr = ls_sauth-gjahr AND bukrs = ls_sauth-bukrs.
        ENDIF.

      ELSEIF p_plnt2 = 'X'.

*        IF ls_s_faglflexa-prctr+0(1) EQ '4'.
*        IF ls_s_faglflexa-prctr+0(1) IN r_adhesive.
        IF ls_s_faglflexa-prctr+4(1) IN r_adhesive.

          AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
          ID 'ACTVT' FIELD '03'
          ID 'PRCTR' FIELD ls_s_faglflexa-prctr.
          IF sy-subrc <> 0.
            MESSAGE: 'You are not authorized for the Profit Centre' TYPE 'E' .
            LEAVE LIST-PROCESSING.
          ENDIF.

        ELSE.
          DELETE it_s WHERE belnr = ls_sauth-belnr AND gjahr = ls_sauth-gjahr AND bukrs = ls_sauth-bukrs.
        ENDIF.

      ENDIF.

    ELSE.


* Quick Fix Replace this statement by a SELECT statement with ORDER BY
* Transport DEVK900442 ECC to S4 Hana Migration
* Replaced Code:
*      SELECT SINGLE bupla FROM bsak INTO @DATA(lv_bupla1) WHERE
*      belnr = @wa_h-belnr AND gjahr = @wa_s-gjahr AND bukrs = @wa_s-bukrs ."GROUP BY gjahr,belnr,bukrs.

      SELECT bupla FROM bsak INTO @DATA(lv_bupla1) UP TO 1 ROWS WHERE
       belnr = @wa_h-belnr AND gjahr = @wa_s-gjahr AND bukrs = @wa_s-bukrs
       ORDER BY PRIMARY KEY .
      ENDSELECT."GROUP BY gjahr,belnr,bukrs.

* End of Quick Fix

      IF lv_bupla1 IS NOT INITIAL.

        IF p_plnt1 = 'X'.

          IF lv_bupla1+2(2) = 'AP'.

            AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
         ID 'ACTVT' FIELD '03'
         ID 'ZBUPLA' FIELD lv_bupla1+2(2).
            IF sy-subrc <> 0.
              MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
              LEAVE LIST-PROCESSING.
            ENDIF.

          ELSE.
*            flagcheck = 'X'.
            DELETE it_s WHERE belnr = ls_sauth-belnr AND gjahr = ls_sauth-gjahr AND bukrs = ls_sauth-bukrs.
          ENDIF.

        ELSEIF p_plnt2 = 'X'.

          IF lv_bupla1+2(2) = 'RC'.

            AUTHORITY-CHECK OBJECT 'ZVEND_BUPL'
         ID 'ACTVT' FIELD '03'
         ID 'ZBUPLA' FIELD lv_bupla1+2(2).
            IF sy-subrc <> 0.
              MESSAGE: 'You are not authorized for the Business Place' TYPE 'E' .
              LEAVE LIST-PROCESSING.
            ENDIF.

          ELSE.
*            flagcheck = 'X'.
            DELETE it_s WHERE belnr = ls_sauth-belnr AND gjahr = ls_sauth-gjahr AND bukrs = ls_sauth-bukrs.
          ENDIF.
        ENDIF.
      ENDIF.

    ENDIF.

  ENDLOOP.

******End of code
*  DATA: flagcheck TYPE flag.
  LOOP AT it_lifnr INTO wa_lifnr.
*     CLEAR: flagcheck.
    LOOP AT it_h INTO wa_h WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.

      """"""""Added by Squirrel to bifurcate company code based on prtct.
*      SELECT SINGLE gjahr,belnr,rbukrs,MAX( prctr ) AS prctr FROM faglflexa INTO @DATA(ls_h_faglflexa)
*       WHERE belnr = @wa_h-belnr AND gjahr = @wa_h-gjahr AND rbukrs = @wa_h-bukrs GROUP BY gjahr,belnr,rbukrs.
*
*      IF ls_h_faglflexa-prctr IS NOT INITIAL.
*
*       if p_plnt1 = 'X'.
*         if ls_h_faglflexa-prctr+0(1) eq '1' or ls_h_faglflexa-prctr+0(1) eq '5'.
*
*         ELSE.
*           flagcheck = 'X'.
*          EXIT.
*         endif.
*
*       ELSEIF p_plnt2 = 'X'.
*
*        if ls_h_faglflexa-prctr+0(1) eq '4'.
*
*        ELSE.
*          flagcheck = 'X'.
*          EXIT.
*         endif.
*
*       endif.
*
**        AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
**                  ID 'ACTVT' FIELD '03'
**                  ID 'PRCTR' FIELD ls_h_faglflexa-prctr.
**        IF sy-subrc <> 0.
**          flagcheck = 'X'.
**          EXIT.
**        ENDIF.
*
*     ELSE.
*
*      SELECT SINGLE bupla FROM bsak INTO @DATA(lv_bupla) WHERE
*         belnr = @wa_h-belnr AND gjahr = @wa_h-gjahr AND bukrs = @wa_h-bukrs ."GROUP BY gjahr,belnr,bukrs.
*       IF lv_bupla is NOT INITIAL.
*
*        if p_plnt1 = 'X'.
*
*         IF lv_bupla+2(2) = 'AP'.
*
*          ELSE.
*            flagcheck = 'X'.
*            EXIT.
*         ENDIF.
*
*       ELSEIF p_plnt2 = 'X'.
*
*        IF lv_bupla+2(2) = 'RC'.
*
*          ELSE.
*            flagcheck = 'X'.
*            EXIT..
*
*        ENDIF.
*       ENDIF.
*       ENDIF.
*      ENDIF.

*****End of code

      h = 'X'.
      IF p_budat EQ 'X'."added by parth 05.01.2021
        v_date = s_date-low - wa_h-budat.
      ELSE.
        v_date = s_date-low - wa_h-bldat. "added by parth 05.01.2021
      ENDIF.
      PERFORM calslabs.
      CLEAR:wa_h,v_date.

    ENDLOOP.

    """"""""""""" Check if plant is not selected then exclude the documents
*    IF flagcheck = 'X'.
*      CONTINUE.
*    ENDIF.

    """""End of code

    CLEAR:v_date,v_amount,v_pending,v_pending1,h,wa_h.

*    LOOP AT it_spl INTO wa_spl WHERE lifnr = wa_lifnr-lifnr.
*
*      spl = 'X'.
*
*      IF p_budat EQ 'X'. "added by parth 05.01.2021
*        v_date = s_date-low - wa_spl-budat.
*      ELSE.
*        v_date = s_date-low - wa_spl-bldat. "added by parth 05.01.2021
*      ENDIF.
*
*      IF wa_spl-shkzg EQ 'H'.
*        wa_spl-dmbtr = wa_spl-dmbtr * ( -1 ).
*      ELSE.
*        wa_spl-dmbtr = wa_spl-dmbtr.
*      ENDIF.
*
*      PERFORM calslabs.
*      CLEAR:wa_spl,v_amount,v_date.
*    ENDLOOP.

    CLEAR:v_date,v_amount,v_pending,v_pending1,spl,wa_h.

    LOOP AT it_s INTO wa_s WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.

      """"""""Added by Squirrel to bifurcate company code based on prtct.
*      SELECT SINGLE gjahr,belnr,rbukrs,MAX( prctr ) AS prctr FROM faglflexa INTO @DATA(ls_s_faglflexa)
*       WHERE belnr = @wa_s-belnr AND gjahr = @wa_s-gjahr AND rbukrs = @wa_s-bukrs GROUP BY gjahr,belnr,rbukrs.
*
*      IF ls_s_faglflexa-prctr IS NOT INITIAL.
*
*       if p_plnt1 = 'X'.
*         if ls_s_faglflexa-prctr+0(1) eq '1' or ls_s_faglflexa-prctr+0(1) eq '5'.
*
*         ELSE.
*           flagcheck = 'X'.
*          EXIT.
*         endif.
*
*       ELSEIF p_plnt2 = 'X'.
*
*        if ls_s_faglflexa-prctr+0(1) eq '4'.
*
*        ELSE.
*          flagcheck = 'X'.
*          EXIT.
*         endif.
*
*       endif.
*
**        AUTHORITY-CHECK OBJECT 'ZVEND_AGEI'
**                  ID 'ACTVT' FIELD '03'
**                  ID 'PRCTR' FIELD ls_h_faglflexa-prctr.
**        IF sy-subrc <> 0.
**          flagcheck = 'X'.
**          EXIT.
**        ENDIF.
*      ELSE.
*
*       SELECT SINGLE bupla FROM bsak INTO @DATA(lv_bupla1) WHERE
*         belnr = @wa_s-belnr AND gjahr = @wa_s-gjahr AND bukrs = @wa_s-bukrs .
*
*           if p_plnt1 = 'X'.
*
*         IF lv_bupla1+2(2) = 'AP'.
*
*          ELSE.
*            flagcheck = 'X'.
*            EXIT.
*         ENDIF.
*
*       ELSEIF p_plnt2 = 'X'.
*
*        IF lv_bupla1+2(2) = 'RC'.
*
*          ELSE.
*            flagcheck = 'X'.
*            EXIT..
*
*        ENDIF.
*       ENDIF.
*
*
*
*      ENDIF.

*****End of code

      s = 'X'.
      IF p_budat EQ 'X'."added by parth 05.01.2021
        v_date = s_date-low - wa_s-budat.
      ELSE.
        v_date = s_date-low - wa_s-bldat."added by parth 05.01.2021
      ENDIF.
      PERFORM calslabs.
      CLEAR:wa_s,v_date.

    ENDLOOP.

    """"""""""""" Check if plant is not selected then exclude the documents
*    IF flagcheck = 'X'.
*      CONTINUE.
*    ENDIF.

    """""End of code

    CLEAR:v_date,v_amount,v_pending,v_pending1,h.

    PERFORM  make_it_tx.

    LOOP AT it_tx INTO wa_tx.

      CONCATENATE 'WA_FINAL-CDAM' wa_tx-lev INTO tempvar.
      PERFORM assign_tx USING wa_tx-cr tempvar."v_amount tempvar.

    ENDLOOP.

    wa_final-total = wa_final-cdam01 + wa_final-cdam02 + wa_final-cdam03 + wa_final-cdam04 + wa_final-cdam05.
*     + wa_final-cdam06 +
*                     wa_final-cdam07 + wa_final-cdam08 + wa_final-cdam09 + wa_final-cdam10 + wa_final-cdam11.

    wa_final-lifnr = wa_lifnr-lifnr.

    READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.

      wa_final-name1 = wa_lfa1-name1.
      wa_final-regio = wa_lfa1-regio.
      wa_final-ktokk = wa_lfa1-ktokk.
      wa_final-j_1kfrepre = wa_lfa1-j_1kfrepre.
      wa_final-j_1kftind = wa_lfa1-j_1kftind.
      wa_final-profs = wa_lfa1-profs.
      wa_final-j_1kftbus = wa_lfa1-j_1kftbus.

      READ TABLE it_t077y INTO wa_t077y WITH KEY ktokk = wa_lfa1-ktokk.
      IF sy-subrc EQ 0.
        wa_final-txt30 = wa_t077y-txt30.
      ENDIF.
      CLEAR:wa_lfa1.
    ENDIF.

    READ TABLE it_lfb1 INTO wa_lfb1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.
      wa_final-akont = wa_lfb1-akont.
      wa_final-memo  = wa_lfb1-kverm.
***************************Added by Rutvi on 19.02.2024
      wa_final-zterm = wa_lfb1-zterm.
      READ TABLE it_t052u INTO wa_t052u WITH KEY zterm = wa_lfb1-zterm.
      IF sy-subrc = 0 .
        wa_final-text1 = wa_t052u-text1.
      ENDIF.
************************************************************
      CLEAR:wa_lfb1.
    ENDIF.

    APPEND wa_final TO it_final.

    CLEAR:v_0to15 , v_16to30 , v_31to60 , v_61to90 , v_91to120 , v_121to180 , v_181to270 , v_271to365 , v_366to730 , v_731to1095, v_1096to,
          tit_headcdam01, tit_headcdam02, tit_headcdam03, tit_headcdam04, tit_headcdam05,  tit_headcdam06,
          tit_headcdam07, tit_headcdam08, tit_headcdam09, tit_headcdam10, tit_headcdam11.

    CLEAR:wa_final.

  ENDLOOP.

******SQUIRREL (Manoj) 09-09-2022

*    SELECT gjahr,belnr,rbukrs,MAX( prctr ) FROM FAGLFLEXA INTO TABLE @DATA(lt_FAGLFLEXA)
*         FOR ALL ENTRIES IN @it_final WHERE belnr = @it_final-

******End of code

ENDFORM.                    " P_BOTH
*&---------------------------------------------------------------------*
*&      Form  P_NORMAL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM p_normal .

  DATA:rem       LIKE  tit_headcdam01.
  DATA : tempvar(15).

  LOOP AT it_lifnr INTO wa_lifnr.

    LOOP AT it_h INTO wa_h WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.

      h = 'X'.
      IF p_budat EQ 'X'."added by parth 05.01.2021
        v_date = s_date-low - wa_h-budat.
      ELSE.
        v_date = s_date-low - wa_h-bldat. "added by parth 05.01.2021
      ENDIF.
      PERFORM calslabs.
      CLEAR:wa_h,v_date.

    ENDLOOP.

    LOOP AT it_s INTO wa_s WHERE lifnr = wa_lifnr-lifnr AND ind NE 'X'.

      s = 'X'.
      IF p_budat EQ 'X'."added by parth 05.01.2021
        v_date = s_date-low - wa_s-budat.
      ELSE.
        v_date = s_date-low - wa_s-bldat. "added by parth 05.01.2021
      ENDIF.
      PERFORM calslabs.
      CLEAR:wa_s,v_date.

    ENDLOOP.

    CLEAR:v_date,v_amount,v_pending,v_pending1,h.

    PERFORM  make_it_tx.

    LOOP AT it_tx INTO wa_tx.

      CONCATENATE 'WA_FINAL-CDAM' wa_tx-lev INTO tempvar.
      PERFORM assign_tx USING wa_tx-cr tempvar."v_amount tempvar.

    ENDLOOP.

    wa_final-total = wa_final-cdam01 + wa_final-cdam02 + wa_final-cdam03 + wa_final-cdam04 + wa_final-cdam05 + wa_final-cdam06 +
                     wa_final-cdam07 + wa_final-cdam08 + wa_final-cdam09 + wa_final-cdam10 + wa_final-cdam11.

    wa_final-lifnr = wa_lifnr-lifnr.

    READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.

      wa_final-name1 = wa_lfa1-name1.
      wa_final-regio = wa_lfa1-regio.
      wa_final-ktokk = wa_lfa1-ktokk.
      wa_final-j_1kfrepre = wa_lfa1-j_1kfrepre.
      wa_final-profs = wa_lfa1-profs.

      READ TABLE it_t077y INTO wa_t077y WITH KEY ktokk = wa_lfa1-ktokk.
      IF sy-subrc EQ 0.
        wa_final-txt30 = wa_t077y-txt30.
      ENDIF.
      CLEAR:wa_lfa1.
    ENDIF.

    READ TABLE it_lfb1 INTO wa_lfb1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.
      wa_final-akont = wa_lfb1-akont.
      CLEAR:wa_lfb1.
    ENDIF.

    APPEND wa_final TO it_final.

    CLEAR:v_0to15 , v_16to30 , v_31to60 , v_61to90 , v_91to120 , v_121to180 , v_181to270 , v_271to365 , v_366to730 , v_731to1095, v_1096to,
          tit_headcdam01, tit_headcdam02, tit_headcdam03, tit_headcdam04, tit_headcdam05,  tit_headcdam06,
          tit_headcdam07, tit_headcdam08, tit_headcdam09, tit_headcdam10, tit_headcdam11.

    CLEAR:wa_final.

  ENDLOOP.

ENDFORM.                    " P_NORMAL
*&---------------------------------------------------------------------*
*&      Form  P_SPL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM p_spl .


  DATA:rem       LIKE  tit_headcdam01.
  DATA : tempvar(15).

  LOOP AT it_lifnr INTO wa_lifnr.

    CLEAR:v_date,v_amount,v_pending,v_pending1,h.

    LOOP AT it_spl INTO wa_spl WHERE lifnr = wa_lifnr-lifnr.

      spl = 'X'.

      IF p_budat EQ 'X'."added by parth 05.01.2021
        v_date = s_date-low - wa_spl-budat.
      ELSE.
        v_date = s_date-low - wa_spl-bldat."added by parth 05.01.2021
      ENDIF.

      IF wa_spl-shkzg EQ 'H'.
        wa_spl-dmbtr = wa_spl-dmbtr * ( -1 ).
      ELSE.
        wa_spl-dmbtr = wa_spl-dmbtr.
      ENDIF.

      PERFORM calslabs.
      CLEAR:wa_spl,v_amount,v_date.
    ENDLOOP.

    CLEAR:v_date,v_amount,v_pending,v_pending1,h.

    PERFORM  make_it_tx.
*
*    DATA:rem       LIKE  tit_headcdam01.
*    DATA : tempvar(15).

    LOOP AT it_tx INTO wa_tx.

      CONCATENATE 'WA_FINAL-CDAM' wa_tx-lev INTO tempvar.
      PERFORM assign_tx USING wa_tx-cr tempvar."v_amount tempvar.

    ENDLOOP.

    wa_final-total = wa_final-cdam01 + wa_final-cdam02 + wa_final-cdam03 + wa_final-cdam04 + wa_final-cdam05 + wa_final-cdam06 +
                     wa_final-cdam07 + wa_final-cdam08 + wa_final-cdam09 + wa_final-cdam10 + wa_final-cdam11.

    wa_final-lifnr = wa_lifnr-lifnr.

    READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.

      wa_final-name1 = wa_lfa1-name1.
      wa_final-regio = wa_lfa1-regio.
      wa_final-ktokk = wa_lfa1-ktokk.
      wa_final-j_1kfrepre = wa_lfa1-j_1kfrepre.

      READ TABLE it_t077y INTO wa_t077y WITH KEY ktokk = wa_lfa1-ktokk.
      IF sy-subrc EQ 0.
        wa_final-txt30 = wa_t077y-txt30.
      ENDIF.
      CLEAR:wa_lfa1.
    ENDIF.

    READ TABLE it_lfb1 INTO wa_lfb1 WITH KEY lifnr = wa_lifnr-lifnr.
    IF sy-subrc EQ 0.
      wa_final-akont = wa_lfb1-akont.
      CLEAR:wa_lfb1.
    ENDIF.

    wa_final-color = 'C410'.
    wa_final-spl   = 'X'.
    APPEND wa_final TO it_final.

    CLEAR:v_0to15 , v_16to30 , v_31to60 , v_61to90 , v_91to120 , v_121to180 , v_181to270 , v_271to365 , v_366to730 , v_731to1095, v_1096to,
          tit_headcdam01, tit_headcdam02, tit_headcdam03, tit_headcdam04, tit_headcdam05,  tit_headcdam06,
          tit_headcdam07, tit_headcdam08, tit_headcdam09, tit_headcdam10, tit_headcdam11.

    CLEAR:wa_final.
  ENDLOOP.

ENDFORM.                    " P_SPL
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization_check .
  SELECT bukrs FROM t001 INTO TABLE gt_t001 WHERE bukrs IN s_bukrs.
  LOOP AT gt_t001 INTO wa_t001.
    AUTHORITY-CHECK OBJECT 'ZMSME_BUKR'
    ID 'BUKRS' FIELD wa_t001-bukrs
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorized for the company code' TYPE 'E' .
    ENDIF.
  ENDLOOP.
ENDFORM.
