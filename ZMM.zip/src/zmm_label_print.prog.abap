*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Khushbu Garg
*&  Functional Consultant   :    Sachin
*&  Requirement             :    For Label Printing in WM Module
*&  Revieved By             :    Sneha
*&  Request                 :    DEVK912058
*&---------------------------------------------------------------------*
*& Report  ZMM_LABEL_PRINT
*&---------------------------------------------------------------------*
REPORT zmm_label_print.
*&---------------------------------------------------------------------*
*&                INCLUDES
*&---------------------------------------------------------------------*
TABLES : zmm_su_number,makt.
INCLUDE zmm_label_print_top.
INCLUDE zmm_label_print_scr.
*&---------------------------------------------------------------------*
*&                start-of-selection
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  PERFORM authorisation.

  CLEAR : it_zmm_su_number,
            it_makt,
            it_mch1.

  IF s_zsu_no IS NOT INITIAL.
    SELECT mandt
    zsu_no
    aufnr
    matnr
    werks
    lgort
    charg
    zbatch_stk
    meins
    lhmg1
    lety1
    lhme1
    lgpla
       FROM zmm_su_number
      INTO TABLE it_zmm_su_number
    WHERE zsu_no IN s_zsu_no AND werks = p_werks.
    IF sy-subrc EQ 0.
      SORT it_zmm_su_number BY zsu_no.
    ENDIF.
  ENDIF.

  IF it_zmm_su_number IS NOT INITIAL.
*******  Added by Carina Jose on 05/01/2022
    CLEAR : v_uom,wa_header,wa_address.
    SELECT SINGLE low
    INTO v_uom
    FROM tvarvc
    WHERE name = c_uom .

    SELECT SINGLE adrnr
      INTO @DATA(v_adrnr)
      FROM t001w
      WHERE werks = @p_werks.

    SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
    city1 city2 post_code1 region country
      INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
                    wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
                    wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country)
      FROM adrc
      WHERE addrnumber = v_adrnr.

    SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland = wa_header-plant_region AND land1 = wa_header-plant_country AND spras = sy-langu.
    SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = sy-langu.


    v_plant_name = wa_header-plant_name1.
    IF NOT wa_header-plant_house_num1 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num1 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num1.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_house_num2 IS INITIAL.
      IF NOT wa_address-street_address1 IS INITIAL.
        CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num2 INTO wa_address-street_address1 SEPARATED BY space.
      ELSE.
        wa_address-street_address1 = wa_header-plant_house_num2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_str_suppl1 IS INITIAL.
      wa_address-street_address2 = wa_header-plant_str_suppl1.
    ENDIF.

    IF NOT wa_header-plant_str_suppl2 IS INITIAL.
      wa_address-street_address3 = wa_header-plant_str_suppl2.
    ENDIF.

    IF NOT wa_header-plant_str_suppl3 IS INITIAL.
      wa_address-street_address4 = wa_header-plant_str_suppl3.
    ENDIF.

    IF NOT wa_header-plant_city1 IS INITIAL.
      wa_address-city_address1 = wa_header-plant_city1.
    ENDIF.

    IF NOT wa_header-plant_city2 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 ','  wa_header-plant_city2 INTO wa_address-city_address1 SEPARATED BY space.
        wa_address-city_address1 = wa_header-plant_city2.
      ENDIF.
    ENDIF.

    IF NOT wa_header-plant_post_code1 IS INITIAL.
      IF NOT wa_address-city_address1 IS INITIAL.
        CONCATENATE wa_address-city_address1 '-' wa_header-plant_post_code1 INTO wa_address-city_address1 SEPARATED BY space.
      ELSE.
        wa_address-city_address1 = wa_header-plant_post_code1.
      ENDIF.
    ENDIF.
    IF NOT v_region IS INITIAL.
      wa_address-state_address1 = v_region.
    ENDIF.

    IF NOT v_country IS INITIAL.
      IF NOT wa_address-state_address1 IS INITIAL.
        CONCATENATE wa_address-state_address1 ',' v_country INTO wa_address-state_address1 SEPARATED BY space.
      ELSE.
        wa_address-state_address1 = v_country.
      ENDIF.
    ENDIF.
****** End of changes by Carina Jose on 05/01/2022
    SELECT matnr
         charg
         hsdat
         FROM mch1
         INTO TABLE it_mch1
         FOR ALL ENTRIES IN it_zmm_su_number
         WHERE matnr EQ it_zmm_su_number-matnr AND
    charg EQ it_zmm_su_number-charg.

    IF sy-subrc EQ 0.
      SORT it_mch1 BY matnr charg.
    ENDIF.

    SELECT matnr
           maktx
           FROM makt
           INTO TABLE it_makt
           FOR ALL ENTRIES IN it_zmm_su_number
    WHERE matnr EQ it_zmm_su_number-matnr AND spras = 'EN'.

    IF sy-subrc EQ 0.
      SORT it_makt BY matnr.
    ENDIF.
  ENDIF.

  CLEAR it_final.
  CLEAR wa_final.

************************Begin of Changes Added by Raj on 17.06.2024*******************************
select matnr,mtart from mara into table @data(it_mara) FOR ALL ENTRIES IN @it_zmm_su_number where matnr  = @it_zmm_su_number-matnr.
  READ TABLE it_mara into data(wa_mara) INDEX 1.
  lv_mtart = wa_mara-mtart.
*********************Begin of Changes Added by Raj on 17.06.2024*******************************
  LOOP AT it_zmm_su_number INTO wa_zmm_su_number.
    wa_final-zsu_no =  wa_zmm_su_number-zsu_no.
    wa_final-zbatch_stk = wa_zmm_su_number-lhmg1.
    wa_final-uom = wa_zmm_su_number-lhme1.
    wa_final-matnr = wa_zmm_su_number-matnr .
    wa_final-charg = wa_zmm_su_number-charg.
    wa_final-lgpla = wa_zmm_su_number-lgpla.

******    Added by Carina Jose on 06/01/2022
    IF wa_final-uom = 'EA'.
      wa_final-uom = v_uom.
    ENDIF.
******    End of changes by Carina Jose on 06/01/2022


    CALL FUNCTION 'VB_BATCH_GET_DETAIL'
      EXPORTING
        matnr              = wa_zmm_su_number-matnr
        charg              = wa_zmm_su_number-charg
        werks              = wa_zmm_su_number-werks
        get_classification = 'X'
*       EXISTENCE_CHECK    =
*       READ_FROM_BUFFER   =
*       NO_CLASS_INIT      = ' '
*       LOCK_BATCH         = ' '
      IMPORTING
        ymcha              = gv_ymcha
        classname          = gv_classname
      TABLES
        char_of_batch      = it_clbatch
      EXCEPTIONS
        no_material        = 1
        no_batch           = 2
        no_plant           = 3
        material_not_found = 4
        plant_not_found    = 5
        no_authority       = 6
        batch_not_exist    = 7
        lock_on_batch      = 8
        OTHERS             = 9.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
    CLEAR wa_clbatch.
    IF gv_classname = 'BATCH_EXP'.
      READ TABLE it_clbatch INTO wa_clbatch WITH KEY atnam = 'MFGD_DATE_PRINT'.
      IF sy-subrc EQ 0.
        REPLACE ALL OCCURRENCES OF '.' IN wa_clbatch-atwtb WITH space.
        CONDENSE wa_clbatch-atwtb.
        CONCATENATE wa_clbatch-atwtb+4(4) wa_clbatch-atwtb+2(2) wa_clbatch-atwtb+0(2) INTO wa_final-hsdat.
      ENDIF.
    ENDIF.

    IF wa_clbatch-atwtb IS INITIAL.
      CLEAR wa_mch1.
      READ TABLE it_mch1 INTO wa_mch1 WITH KEY matnr = wa_zmm_su_number-matnr
                                               charg = wa_zmm_su_number-charg BINARY SEARCH.
      IF sy-subrc EQ 0.
        wa_final-hsdat = wa_mch1-hsdat.
      ENDIF.
    ENDIF.

    CLEAR wa_makt.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_zmm_su_number-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-maktx = wa_makt-maktx.
    ENDIF.
    APPEND wa_final TO it_final.
    CLEAR : wa_final.
  ENDLOOP.

DESCRIBE TABLE it_final lines lv_no."Added by Raj on 08.01.2024

  CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
    EXPORTING
      formname = 'ZLABEL_PRINT'
*     VARIANT  = ' '
*     DIRECT_CALL              = ' '
    IMPORTING
      fm_name  = v_form_name
*           EXCEPTIONS
*     NO_FORM  = 1
*     NO_FUNCTION_MODULE       = 2
*     OTHERS   = 3
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  IF it_final IS NOT INITIAL.
    DESCRIBE TABLE it_final LINES w_cnt.

    LOOP AT it_final INTO wa_final.
      count = count + 1.
      IF w_cnt GT 1.
        w_cnt2 = sy-tabix .
        CASE w_cnt2.
          WHEN 1.
            control_parameters-no_open   = space .
            control_parameters-no_close  = 'X' .
          WHEN w_cnt .
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = space .
          WHEN OTHERS.
            control_parameters-no_open   = 'X' .
            control_parameters-no_close  = 'X' .
        ENDCASE.
      ELSE.
        control_parameters-no_open   = space .
        control_parameters-no_close  = space .
      ENDIF.

      CALL FUNCTION v_form_name
        EXPORTING
          control_parameters = control_parameters
          wa_final           = wa_final
          wa_address         = wa_address
          v_plant_name       = v_plant_name
          count              = count
          lv_no              = lv_no
          LV_MTART       = LV_MTART
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.

    ENDLOOP.
  ENDIF.
*  *&---------------------------------------------------------------------*
*&      Form  ZSU_NOF4HELP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM zsu_nof4help .

  CLEAR it_zsu_no.

  SELECT zsu_no
        FROM zmm_su_number
  INTO TABLE it_zsu_no.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
*     DDIC_STRUCTURE  = ' '
      retfield        = 'ZSU_NO'
*     PVALKEY         = ' '
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'S_ZSU_NO '
*     STEPL           = 0
*     WINDOW_TITLE    =
*     VALUE           = ' '
      value_org       = 'S'
*     MULTIPLE_CHOICE = ' '
*     DISPLAY         = ' '
*     CALLBACK_PROGRAM       = ' '
*     CALLBACK_FORM   = ' '
*     CALLBACK_METHOD =
*     MARK_TAB        =
*    IMPORTING
*     USER_RESET      =
    TABLES
      value_tab       = it_zsu_no
*     FIELD_TAB       =
*     RETURN_TAB      =
*     DYNPFLD_MAPPING =
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORISATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorisation .

  SELECT werks FROM t001w INTO TABLE gt_t001w WHERE werks EQ p_werks.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'ZLAB_WERKS'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.

ENDFORM.
