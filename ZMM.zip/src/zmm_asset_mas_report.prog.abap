*&---------------------------------------------------------------------*
*& Report  ZMM_ASSET_MAS_REPORT
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT ZMM_ASSET_MAS_REPORT.

Include ZMM_ASSET_MAS_REPORT_TOP.
include ZMM_ASSET_MAS_REPORT_SEL.
include ZMM_ASSET_MAS_REPORT_FORM.
