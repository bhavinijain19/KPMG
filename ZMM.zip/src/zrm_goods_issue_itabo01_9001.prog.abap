*************************************************************************************
*Object Name              : ZRM_GOODS_ISSUE.
*Author/Comapny Name      : Uday Malhotra/Kpit Technologies Ltd.
*Creation Date            : 28/03/2019.
*************************************************************************************
*Description              : Screen 9001.
*************************************************************************************
MODULE transp_itab_out_9001 OUTPUT.
  CLEAR wa_final.
  idx_9001 = sy-stepl + line_9001.
  READ TABLE it_final INTO wa_final INDEX idx_9001.
  IF sy-subrc EQ 0.
    wa_final = it_final[ idx_9001 ].
  ENDIF.
  CLEAR : p_scan.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_IN_9001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_in_9001 INPUT.
  lines_9001 = sy-loopc.
  idx_9001 = sy-stepl + line_9001.
  MODIFY it_final FROM wa_final INDEX idx_9001.
  if idx_9001 eq 1.
      clear gv_issue_qty..
  endif.
gv_issue_qty = gv_issue_qty + wa_final-menge.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9001 INPUT.
  IF sy-ucomm = 'PGDWN'.
    "slines = slines + 6.
    line_9001 = line_9001 + lines_9001.
    limit = fill - lines_9001.
    IF line_9001 > limit.
      line_9001 = limit.
    ENDIF.

  ELSEIF sy-ucomm = 'PGUP'.
    "slines = slines - 6.
    line_9001 = line_9001 - lines_9001.
    IF line_9001 < 0.
      line_9001 = 0.
    ENDIF.
  ELSEIF sy-ucomm = 'BACK'.
    CLEAR : gv_text,gv_tanum,it_final,IT_TRITE,wa_final,wa_trite.
    CLEAR : it_final,wa_final,gv_charg,gv_tbpos,gv_matnr,gv_menge,flag_enter,flag_post,flag_check,flag_post.
    CLEAR : idx,idx_9001,line_9001,limit,LINES,lines_9001,LINE,gv_issue_qty,flag_less, fill,flag_edit,flag_exceed.
  "IF flag_edit = 1.
    LOOP AT SCREEN.
      IF  SCREEN-name = 'WA_FINAL-MENGE'.
        SCREEN-INPUT = 0.
        MODIFY SCREEN.
      ENDIF.
      IF  SCREEN-name = 'P_SCAN'.
        SCREEN-INPUT = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
    CLEAR flag_EDIT.
    LEAVE  TO SCREEN 9000 .

  ELSEIF sy-ucomm = 'CANCEL'.
    LEAVE PROGRAM.
  ELSEIF sy-ucomm  = 'ENTER'.
    flag_enter = 1.
  ELSEIF sy-ucomm  = 'POST'.
    flag_post = 1.
   ELSEIF sy-ucomm  = 'EDIT'.
    flag_edit = 1.
    flag_exceed = 1.
  ENDIF.

ENDMODULE.

***********************************************************
*BDC FORM bdc_dynpro
***********************************************************
FORM bdc_dynpro USING PROGRAM DYNPRO.
  CLEAR wa_bdcdata.
  wa_bdcdata-PROGRAM  = PROGRAM.
  wa_bdcdata-DYNPRO   = DYNPRO.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Module  STATUS_9001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9001 OUTPUT.
  SET PF-STATUS 'ZPF_9001'.
*  SET TITLEBAR 'xxx'.

  CLEAR wa_final.
  IF  flag_enter = 1 AND p_scan IS NOT INITIAL.
    clear : v_field1,v_field2,v_field3,v_field4.
    SHIFT p_scan LEFT DELETING LEADING space.
    SPLIT p_scan AT ' ' INTO v_field1 v_field2.
    SHIFT v_field2 LEFT DELETING LEADING space.
    SHIFT v_field1 LEFT DELETING LEADING space.
    SPLIT v_field2 AT ' ' INTO v_field3 v_field4.
    SHIFT v_field3 LEFT DELETING LEADING space.
    SHIFT v_field4 LEFT DELETING LEADING space.


    SELECT SINGLE lgnum,
                  tbnum,
                  tbpos,
                  matnr,
                  charg
     FROM ltbp
     INTO @DATA(wa_ltbp1)
     WHERE ( matnr EQ @v_field1
      OR    matnr EQ @v_field3 ).
    " AND   ( tbpos EQ @gv_tbpos ).

    IF wa_ltbp1 IS NOT INITIAL.

      IF v_field1 = wa_ltbp1-matnr.
        v_field1 = wa_ltbp1-matnr.
        v_field4 = v_field4.
        v_field3 = v_field3.
      ELSE.
        v_field3 = v_field4.
        v_field4 = v_field1.
        v_field1 = wa_ltbp1-matnr.
      ENDIF.
      clear wa_ltbp1.
      IF v_field1 NE gv_matnr.
        MESSAGE 'Scanned material is wrong' TYPE 'I' DISPLAY LIKE 'E'.
        flag_enter = 2.
        clear wa_ltbp1.
        LEAVE LIST-PROCESSING.
      ELSEIF v_field4 NE gv_charg.
        MESSAGE 'Scanned batch is wrong' TYPE 'I' DISPLAY LIKE 'E'.
        flag_enter = 2.
         clear wa_ltbp1.
        LEAVE LIST-PROCESSING.
      ENDIF.

      IF flag_enter = 1.
        SELECT SINGLE lgnum,
        tbnum,
        tbpos,
        werks,
        matnr,
        charg,
        meins
        FROM ltbp
        INTO @DATA(wa_ltbp2)
              WHERE ( matnr EQ @gv_matnr )
              AND   ( charg EQ @gv_charg )
              AND   ( tbpos EQ @gv_tbpos ).

        IF wa_ltbp2 IS INITIAL.
          MESSAGE 'Material batch item combination is not correct'  TYPE 'I' DISPLAY LIKE 'E'.
          flag_enter = 2.
          LEAVE LIST-PROCESSING.
        ENDIF.

        CLEAR wa_final.
        wa_final-matnr = v_field1.
        wa_final-charg = v_field4.
        wa_final-meins = wa_ltbp2-meins.
        wa_final-menge = v_field3.
        wa_final-tbpos = gv_tbpos.
        gv_lgnum = wa_ltbp2-lgnum.
        gv_plant = wa_ltbp2-werks.
        CLEAR wa_final1.

         gv_issue_qty = gv_issue_qty + wa_final-menge.


        IF  flag_enter = 1.
          APPEND wa_final TO it_final.
          "if flag_exceed eq 0.
          APPEND wa_final TO it_final_comp.
          "endif.
          clear wa_final.
          flag_check = 1.
        ENDIF.
        DESCRIBE TABLE it_final LINES fill.
      ENDIF.
    ELSE.
      MESSAGE 'Scanned values are wrong.'  TYPE 'I' DISPLAY LIKE 'E'.
      flag_enter = 2.
      LEAVE LIST-PROCESSING.

    ENDIF.
  ENDIF.

  IF gv_issue_qty EQ gv_menge and gv_menge is NOT INITIAL.
    LOOP AT SCREEN.
      IF  SCREEN-name = 'P_SCAN'.
        SCREEN-INPUT = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
    "MESSAGE : 'Issue quantiy exceeded then TR quantity' TYPE 'I' DISPLAY LIKE 'E'.
    "gv_issue_qty = gv_issue_qty - wa_final-menge.
   " EXIT.
  ENDIF.

  IF gv_issue_qty GT gv_menge.
    LOOP AT SCREEN.
      IF  SCREEN-name = 'P_SCAN'.
        SCREEN-INPUT = 0.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
    MESSAGE : 'Issue quantiy exceeded then TR quantity' TYPE 'I' DISPLAY LIKE 'S'.
    "gv_issue_qty = gv_issue_qty - wa_final-menge.
    "EXIT.
  ENDIF.

  if flag_edit = 1.
    loop at SCREEN.
  IF  SCREEN-name = 'WA_FINAL-MENGE'.
      SCREEN-INPUT = 1.
      MODIFY SCREEN.
  endif.
      IF  SCREEN-name = 'P_SCAN'.
        SCREEN-INPUT = 0.
        MODIFY SCREEN.
      ENDIF.
    endloop.
    flag_edit = 0.
  endif.
  IF flag_enter = 1 AND flag_post = 1.
    data i(4) TYPE n VALUE 0.
    clear wa_final.
    clear wa_final_comp.

    loop at it_final_comp into wa_final_comp.

    i = i + 1.

    read TABLE it_final INTO wa_final INDEX i.

      IF wa_final-menge > wa_final_comp-menge.
        message 'Edited issue quantity is greater then scanned issue quantity.' TYPE 'I' DISPLAY LIKE 'E'.
        clear i.
        return.

      endif.

    endloop.


    clear gv_issue_qty.
    clear :IT_TRITE,wa_trite.
    SELECT SINGLE werks,
                  lgort,
           lgnum,
           lgtyp,
           lgber
   FROM zwm_picklist
    INTO @DATA(wa_zwm_picklist)
   WHERE  werks = @gv_plant
    AND   lgort = @lgort
    AND  lgnum = @gv_lgnum.
    IF sy-subrc EQ 0.

      SELECT lgnum,
             matnr,
             werks,
             charg,
             lgtyp,
             lgpla,
             verme,
             lgort
     FROM lqua
     INTO TABLE @DATA(it_lqua)
     WHERE lgnum EQ @gv_lgnum
     AND   matnr EQ @gv_matnr
     AND   werks EQ @gv_plant
     AND   charg EQ @gv_charg
     AND   lgtyp EQ @wa_zwm_picklist-lgtyp
     AND   lgort EQ @lgort.

    ENDIF.


    CLEAR gv_issue_qty.
    CLEAR wa_final.
    gv_text = 'TO No created and confirmed:'.
    LOOP AT it_final INTO wa_final.

      gv_issue_qty = gv_issue_qty + wa_final-menge.

      IF gv_issue_qty gt gv_menge.
        MESSAGE : 'Issue quantiy is greater then TR quantity' TYPE 'I' DISPLAY LIKE 'E'.
        flag_post = 0.
        EXIT.
      ENDIF.

      wa_trite-tbpos = wa_final-tbpos.
      wa_trite-anfme = wa_final-menge.
      wa_trite-altme = wa_final-meins.
      wa_trite-charg = wa_final-charg.
      wa_trite-nltyp = wa_zwm_picklist-lgtyp.
      wa_trite-nlber = wa_zwm_picklist-lgber.

     loop at it_lqua ASSIGNING FIELD-SYMBOL(<fs_lqua>).
     if <fs_lqua> is ASSIGNED.
      IF <fs_lqua>-verme > wa_final-menge.
     <fs_lqua>-verme = <fs_lqua>-verme - wa_final-menge.
      wa_trite-nlpla = <fs_lqua>-lgpla.
       MODIFY TABLE it_lqua FROM <fs_lqua> TRANSPORTING verme.
      exit.
      endif.


     endif.
    endloop.
   "if flag_less eq 0.
    append wa_trite to IT_TRITE.
   " endif.
*    if flag_less eq 1.
*      modify TABLE IT_TRITE FROM wa_trite.
*      flag_less = 0.
   " endif.
    clear : wa_trite,wa_final.
  endloop.
    IF gv_issue_qty lt gv_menge.
      MESSAGE : 'Issue quantiy is less then TR quantity' TYPE 'I' DISPLAY LIKE 'E'.
      "flag_less = 1.
      flag_post = 0.
      exit.
    ENDIF.

  ENDIF.

if flag_edit eq 0 and flag_post eq 1.
  IF gv_issue_qty GT gv_menge.
    MESSAGE : 'Issue quantiy is greater then TR quantity' TYPE 'I' DISPLAY LIKE 'E'.
     flag_post = 0.
    "gv_issue_qty = gv_issue_qty - wa_final-menge.
    EXIT.
  ENDIF.
endif.
  if flag_post eq 1 and flag_less eq 0.

    CALL FUNCTION 'L_TO_CREATE_TR'
      EXPORTING
    i_lgnum                              = gv_lgnum
    i_tbnum                              = ltbp-tbnum

    "I_COMMIT_WORK                        = 'X'
    I_BNAME                              = SY-UNAME
    I_SOLEX                              = gv_menge
    IT_TRITE                             = IT_TRITE
      IMPORTING
        E_TANUM                              = gv_tanum
     EXCEPTIONS
       FOREIGN_LOCK                         = 1
       QM_RELEVANT                          = 2
       TR_COMPLETED                         = 3
       XFELD_WRONG                          = 4
       LDEST_WRONG                          = 5
       DRUKZ_WRONG                          = 6
       TR_WRONG                             = 7
       SQUIT_FORBIDDEN                      = 8
       NO_TO_CREATED                        = 9
       UPDATE_WITHOUT_COMMIT                = 10
       NO_AUTHORITY                         = 11
       PREALLOCATED_STOCK                   = 12
       PARTIAL_TRANSFER_REQ_FORBIDDEN       = 13
       INPUT_ERROR                          = 14
       OTHERS                               = 15
              .
    IF sy-subrc = 0.
      COMMIT WORK AND WAIT.
* Implement suitable error handling here
    ENDIF.
    endif.
    if gv_tanum is NOT INITIAL.
***********************************************************
*BDC for confirming created TO.
***********************************************************
    PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
    PERFORM bdc_field       USING 'BDC_CURSOR'
          'LTAK-TANUM'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
          '/00'.
    PERFORM bdc_field       USING 'LTAK-TANUM'
          gv_tanum.
    PERFORM bdc_field       USING 'LTAK-LGNUM'
          gv_lgnum.

    PERFORM bdc_dynpro      USING 'SAPML03T' '0114'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
          '=QU'.
    PERFORM bdc_field       USING 'BDC_OKCODE'
          '=BU'.

    CALL TRANSACTION 'LT12' USING it_bdcdata MODE 'N' UPDATE 'S'.


    CLEAR it_bdcdata.
    CLEAR wa_bdcdata.

    concatenate gv_text gv_tanum INTO gv_text SEPARATED BY space.
    message : gv_text TYPE 'I' DISPLAY LIKE 'S'.
    clear : gv_text,it_final,IT_TRITE,wa_final,wa_trite.
    CLEAR : it_final,wa_final,gv_charg,gv_tbpos,gv_matnr,gv_menge,flag_enter,flag_post,flag_check,flag_post.
    CLEAR : idx,idx_9001,line_9001,limit,lines,lines_9001,line,gv_issue_qty,flag_less,fill, flag_edit,flag_exceed.
    LOOP AT SCREEN.
      IF  SCREEN-name = 'WA_FINAL-MENGE'.
        SCREEN-INPUT = 0.
        MODIFY SCREEN.
      ENDIF.
      IF  SCREEN-name = 'P_SCAN'.
        SCREEN-INPUT = 1.
        MODIFY SCREEN.
      ENDIF.
    ENDLOOP.
    CLEAR flag_EDIT.

    call SCREEN 9000.

  ENDIF.



ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  FILL_CURSOR_DATA  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE fill_cursor_data OUTPUT.
  CLEAR:gv_matnr,gv_charg,gv_menge.
  READ TABLE gt_ltbp INTO DATA(wa_temp) INDEX c.
  gv_matnr = wa_temp-matnr.
  gv_charg = wa_temp-charg.
  gv_menge = wa_temp-menge.
  gv_tbpos = wa_temp-tbpos.
  CLEAR wa_temp.

ENDMODULE.
