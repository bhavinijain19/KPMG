FUNCTION-POOL ZLOG_DETAILS               MESSAGE-ID SV.

* INCLUDE LZLOG_DETAILSD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZLOG_DETAILST00                        . "view rel. data dcl.
