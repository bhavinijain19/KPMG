FUNCTION zfm_migo_set_header_text.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_MBLNR) TYPE  MKPF-MBLNR
*"     REFERENCE(IV_MJAHR) TYPE  MKPF-MJAHR
*"----------------------------------------------------------------------

  gv_mblnr = iv_mblnr.
  gv_mjahr = iv_mjahr.

ENDFUNCTION.
