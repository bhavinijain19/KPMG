class ZCL_WORKFLOW_CONDITION_EVAL_PR definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_EVAL .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKFLOW_CONDITION_EVAL_PR IMPLEMENTATION.


  method IF_SWF_FLEX_IFS_CONDITION_EVAL~EVALUATE_CONDITION.
    DATA: lv_custom_field TYPE string.

    IF ( is_condition-condition_id > 1 ).
*      RAISE EXCEPTION TYPE cx_ble_runtime_error
*        EXPORTING
*          previous = NEW cx_swf_flex_lra( textid = cx_swf_flex_lra=>condition_not_supported ).
    ENDIF.

    cv_is_true = abap_false.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT  SINGLE *
*      INTO  @DATA(ls_purchasereq)
*      FROM eBAN
*      WHERE BANFN = @is_sap_object_node_type-sont_key_part_1.
    SELECT  *
      INTO  @DATA(ls_purchasereq)
      FROM eBAN UP TO 1 ROWS
      WHERE BANFN = @is_sap_object_node_type-sont_key_part_1 ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************




    CASE is_condition-condition_id.
      WHEN 1.
        READ TABLE it_parameter_value INTO DATA(ls_param_value) WITH KEY name = 'PR Document Type'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value-value.
          IF lv_custom_field = ls_purchasereq-BSART.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.
 WHEN 2.
        READ TABLE it_parameter_value INTO DATA(ls_param_value1) WITH KEY name = 'Plant'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value1-value.
          IF lv_custom_field = ls_purchasereq-werks.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.


      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
