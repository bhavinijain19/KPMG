*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZTVM12TOP.                        " Global Declarations
  INCLUDE LZTVM12UXX.                        " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTVM12F...                        " Subroutines
* INCLUDE LZTVM12O...                        " PBO-Modules
* INCLUDE LZTVM12I...                        " PAI-Modules
* INCLUDE LZTVM12E...                        " Events
* INCLUDE LZTVM12P...                        " Local class implement.
* INCLUDE LZTVM12T99.                        " ABAP Unit tests
  INCLUDE LZTVM12F00                              . " subprograms
  INCLUDE LZTVM12I00                              . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
