"Name: \PR:SAPLMR1M\FO:MENGE_PRUEFEN\SE:END\EI
ENHANCEMENT 0 ZENH_PO_DOC_TYPE_GNRL.
**$*$===================================================================*
*$*$  PROGRAM ID    : LMR1MF26                                         *
*$*$  ENHANCEMENT   : ZENH_PO_DOC_TYPE_GNRL                            *
*$*$  T-CODE        : MIRO                                             *
*$*$  AUTHOR ID     : Sachin Joshi(KPIT)                               *
*$*$  Ticket ID     : ASTR25                                           *
*$*$  CREATION ON   : 22.09.2015                                       *
*$*$  REVIEWED BY   : Ketki Rathkantiwar                               *
*$*$  REVIEWED ON   : 23.09.2015                                       *
*$*$  REQUST NO     : DEVK904262                                       *
*$*$  DESCRIPTION   : Display message M8 088/504 as Warning(W) when    *
*$*$                  Purchasing document type is not 'GNRL'           *
*$*$===================================================================*
CONSTANTS: cs_e    TYPE char1 VALUE 'E',"Error
           cs_w    TYPE char1 VALUE 'W',"Warning
           cs_m8   TYPE char2 VALUE 'M8',"Message Class
           cs_088  TYPE char3 VALUE '088',"Message No 088
           cs_504  TYPE char3 VALUE '504',"Message No 504
           cs_serv TYPE char4 VALUE 'SERV',"document Type SERV
           cs_miro TYPE char4 VALUE 'MIRO'."T Code MIRO

IF sy-tcode = cs_miro."'MIRO'.
  IF ekko-bsart EQ cs_serv..
   LOOP AT T_ERRPROT.
"check message type,message id,message no and change message type to 'W'.
    IF T_ERRPROT-MSGTY = cs_e AND T_ERRPROT-MSGID = cs_m8 AND T_ERRPROT-MSGNO = cs_088.
      T_ERRPROT-MSGTY = cs_w.
      MODIFY T_ERRPROT.
    ENDIF.

    IF T_ERRPROT-MSGTY = cs_e AND T_ERRPROT-MSGID = cs_m8 AND T_ERRPROT-MSGNO = cs_504.
      T_ERRPROT-MSGTY = cs_w.
      MODIFY T_ERRPROT.
    ENDIF.

   ENDLOOP.

  ENDIF.
ENDIF.
ENDENHANCEMENT.
