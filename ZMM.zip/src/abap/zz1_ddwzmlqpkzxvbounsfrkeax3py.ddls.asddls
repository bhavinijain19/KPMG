@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_D5BFD7DD9E34'

extend view A_SERVICEENTRYSHEET with ZZ1_DDWZMLQPKZXVBOUNSFRKEAX3PY
  
{ 
  _Extension.ZZ1_REFERENCE_MDH as ZZ1_REFERENCE_MDH
}
