FUNCTION-POOL ZMM_RETENTION              MESSAGE-ID SV.

* INCLUDE LZMM_RETENTIOND...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_RETENTIONT00                       . "view rel. data dcl.
