FUNCTION Z_UPDATE_PO_EMAIL_STATUS.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_EBELN) TYPE  EBELN
*"     VALUE(IV_FLAG) TYPE  CHAR1
*"----------------------------------------------------------------------

UPDATE ZPO_EMAILE SET flag = IV_FLAG
    WHERE ebeln = IV_EBELN.



ENDFUNCTION.
