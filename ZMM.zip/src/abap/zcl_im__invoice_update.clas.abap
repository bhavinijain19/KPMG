class ZCL_IM__INVOICE_UPDATE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_INVOICE_UPDATE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM__INVOICE_UPDATE IMPLEMENTATION.


  method IF_EX_INVOICE_UPDATE~CHANGE_AT_SAVE.
        IF sy-ucomm <> 'DELE'.
      IF sy-tcode EQ 'MIR7' OR sy-tcode EQ 'MIRO' OR sy-tcode EQ 'MIR4'.
        " For assignment field
        SELECT SINGLE * FROM tvarvc INTO @DATA(lv_doc_type) WHERE name = 'ZDOC_TYPE' AND type = 'S' AND low = @s_rbkp_new-blart. "Changed by Rahul Vasita on 18.07.2024 12:08:36
*        IF s_rbkp_new-blart EQ lv_doc_type-low. " 'RE'.   "Invoice - Gross'. "Comment by Rahul Vasita on 18.07.2024 12:08:50
        IF sy-subrc = 0. " 'RE'.   "Invoice - Gross'. "Added by Rahul Vasita on 18.07.2024 12:08:51
          DATA: lv_name_zuonr(18) TYPE c VALUE  '(SAPLMRMP)RBKPV'. "'(SAPLMR1M)RM08M-EBELN'.
          DATA: lv_name_zuonr1(18) TYPE c VALUE  '(SAPLMR1M)RBKPV'. "'(SAPLMR1M)RM08M-EBELN'.
          FIELD-SYMBOLS: <fs_rbkpv> TYPE mrm_rbkpv.
          IF sy-tcode EQ 'MIR7'.
            ASSIGN (lv_name_zuonr1) TO <fs_rbkpv>.
            IF <fs_rbkpv> IS ASSIGNED.
              READ TABLE ti_rseg_new INTO DATA(lw_zuonr) INDEX 1.
              IF sy-subrc = 0.
                <fs_rbkpv>-zuonr = lw_zuonr-ebeln.
              ENDIF.
            ENDIF.
          ENDIF.

          IF sy-tcode EQ 'MIR4'.
*          ASSIGN (lv_name_zuonr1) TO <fs_rbkpv>.
*          IF <fs_rbkpv> IS ASSIGNED.
*            READ TABLE ti_rseg_new INTO lw_zuonr INDEX 1.
*            IF sy-subrc = 0.
*              <fs_rbkpv>-zuonr = lw_zuonr-ebeln.
*            ENDIF.
*          else.
            ASSIGN (lv_name_zuonr) TO <fs_rbkpv>.
            IF <fs_rbkpv> IS ASSIGNED.
              READ TABLE ti_rseg_new INTO lw_zuonr INDEX 1.
              IF sy-subrc = 0.
                <fs_rbkpv>-zuonr = lw_zuonr-ebeln.
              ENDIF.
            ENDIF.
*          ENDIF.
          ENDIF.

          IF sy-tcode EQ 'MIRO'.
            ASSIGN (lv_name_zuonr1) TO <fs_rbkpv>.
            IF <fs_rbkpv> IS ASSIGNED.
              READ TABLE ti_rseg_new INTO lw_zuonr INDEX 1.
              IF sy-subrc = 0.
                <fs_rbkpv>-zuonr = lw_zuonr-ebeln.
              ENDIF.

              ASSIGN (lv_name_zuonr) TO <fs_rbkpv>.
              IF <fs_rbkpv> IS ASSIGNED.
                READ TABLE ti_rseg_new INTO lw_zuonr INDEX 1.
                IF sy-subrc = 0.
                  <fs_rbkpv>-zuonr = lw_zuonr-ebeln.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.


          SELECT ebeln
          FROM ekpo
          INTO TABLE @DATA(lt_ekpo)
          FOR ALL ENTRIES IN @ti_rseg_new
          WHERE ebeln = @ti_rseg_new-ebeln
           AND  pstyp <> '7'
           AND  fplnr = ''
           AND  pstyp <> '9'.

          SELECT ebeln
          FROM ekpo
          INTO TABLE @DATA(lt_ekpo1)
          FOR ALL ENTRIES IN @ti_rseg_new
          WHERE ebeln = @ti_rseg_new-ebeln
            AND pstyp <> '7'
            AND fplnr = ''
            AND pstyp = '9'.
          "For material po
          IF lt_ekpo IS NOT INITIAL.
            SELECT ebeln , budat , belnr
            FROM ekbe
            INTO TABLE @DATA(lt_ekbe1)
            FOR ALL ENTRIES IN @ti_rseg_new
            WHERE ebeln = @ti_rseg_new-ebeln
            AND vgabe = '1'
            AND bwart = '101'
            AND belnr = @ti_rseg_new-lfbnr.

            SELECT ebeln , lfbnr
            FROM ekbe
            INTO TABLE @DATA(lt_ekbe)
            FOR ALL ENTRIES IN @ti_rseg_new
            WHERE ebeln = @ti_rseg_new-ebeln
            AND vgabe = '1'
            AND bwart = '102'
            AND lfbnr = @ti_rseg_new-lfbnr.

            IF lt_ekbe IS NOT INITIAL.
              LOOP AT lt_ekbe INTO DATA(gw_ekbe).
                DELETE lt_ekbe1 WHERE belnr = gw_ekbe-lfbnr.
                CLEAR : gw_ekbe.
              ENDLOOP.
            ENDIF.

            SORT lt_ekpo BY ebeln.
            SORT lt_ekbe1 BY ebeln.

            LOOP AT lt_ekbe1 INTO DATA(lw_ekbe1).
              READ TABLE lt_ekpo INTO DATA(lw_ekpo) WITH KEY ebeln  = lw_ekbe1-ebeln BINARY SEARCH.
              IF sy-subrc = 4.
                DELETE lt_ekbe1 WHERE ebeln  = lw_ekbe1-ebeln.
              ENDIF.
            ENDLOOP.
          ENDIF.
*****************          comment by parth 13.05.2024 for base line date  restrication not needed
          "For service purchase order
*          IF lt_ekpo1 IS NOT INITIAL.
*            SELECT budat FROM essr INTO TABLE @DATA(lt_essr) FOR ALL ENTRIES IN @ti_rseg_new WHERE ebeln = @ti_rseg_new-ebeln AND kzabn = 'X' AND lblni = @ti_rseg_new-lfbnr.
*            SORT lt_essr DESCENDING BY budat.
*          ENDIF.
*
*          "assigning latest grn posting date to baseline date
*          SORT lt_ekbe1 DESCENDING BY budat.
*          IF lt_ekbe1 IS NOT INITIAL OR lt_essr IS NOT INITIAL.
*            READ TABLE lt_essr INTO DATA(lw_essr) INDEX 1.
*            READ TABLE lt_ekbe1 INTO lw_ekbe1 INDEX 1.
*            IF lw_essr-budat GT lw_ekbe1-budat.
*              IF <fs_rbkpv> IS ASSIGNED.
*                <fs_rbkpv>-zfbdt = lw_essr-budat.
*              ENDIF.
*            ELSE.
*              IF <fs_rbkpv> IS ASSIGNED.
*                <fs_rbkpv>-zfbdt = lw_ekbe1-budat.
*              ENDIF.
*            ENDIF.
*          ELSE.
*            <fs_rbkpv>-zfbdt =  <fs_rbkpv>-budat.
*          ENDIF.
******************************************     comment end by parth 13.05.2024
*          CLEAR :  lv_name_zuonr, lv_name_zuonr1,  lw_essr, lw_zuonr, lw_ekbe1, lw_ekpo.
          CLEAR :  lv_name_zuonr, lv_name_zuonr1, lw_zuonr, lw_ekbe1, lw_ekpo.
        ENDIF.
      ENDIF.
    ENDIF.
  endmethod.


  method IF_EX_INVOICE_UPDATE~CHANGE_BEFORE_UPDATE.
  endmethod.


  method IF_EX_INVOICE_UPDATE~CHANGE_IN_UPDATE.
  endmethod.
ENDCLASS.
