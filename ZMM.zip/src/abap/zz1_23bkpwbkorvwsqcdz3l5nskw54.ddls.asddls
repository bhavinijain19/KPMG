@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_6B62B174E4A3'

extend view I_SERVICEENTRYSHEET with ZZ1_23BKPWBKORVWSQCDZ3L5NSKW54
  
{ 
  _ServiceEntrySheetExtension.ZZ1_DOCUMENTDATE_MDH as ZZ1_DOCUMENTDATE_MDH
}
