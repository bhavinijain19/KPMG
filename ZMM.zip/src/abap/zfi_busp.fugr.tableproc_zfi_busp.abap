*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_BUSP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_BUSP            .

  PERFORM TABLEPROC.

ENDFUNCTION.
