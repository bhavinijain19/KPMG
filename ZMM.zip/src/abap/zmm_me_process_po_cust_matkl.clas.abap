class ZMM_ME_PROCESS_PO_CUST_MATKL definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZMM_ME_PROCESS_PO_CUST_MATKL IMPLEMENTATION.


  method IF_EX_ME_PROCESS_PO_CUST~CHECK.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  METHOD if_ex_me_process_po_cust~fieldselection_item.

    DATA: l_re_item TYPE mepoitem.
    FIELD-SYMBOLS: <fs_field> TYPE mmpur_fs.

    " 1. Get current item data
    l_re_item = im_item->get_data( ).

    " 2. Check if a Material Number exists
    " This ensures the field is only greyed out when MM01 data is present
    IF l_re_item-matnr IS NOT INITIAL.

      " 3. Directly find the Material Group field in the selection table
      " '045' is the standard technical metafield ID for MATKL in POs
      READ TABLE ch_fieldselection ASSIGNING <fs_field>
                                   WITH TABLE KEY metafield = '045'.

      IF sy-subrc = 0.
        " 4. Set status to '*' (Display Only)
        " This applies regardless of the Document Type (NB, FO, Z-types, etc.)
        <fs_field>-fieldstatus = '*'.
      ENDIF.

    ENDIF.



  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
