FUNCTION-POOL ZFG_MIGO_HEADER.              "MESSAGE-ID ..

* INCLUDE LZFG_MIGO_HEADERD...               " Local class definition


DATA: gv_zzgat TYPE zde_zzgat.
DATA: gv_year TYPE zgate_header-ZYEAR.
DATA: gv_werks TYPE werks_d.
DATA: gv_mblnr TYPE mblnr.
DATA: gv_mjahr TYPE mjahr.
DATA: g_no_dis TYPE xfeld.
FIELD-SYMBOLS: <x_trtyp> TYPE char3.

DATA: gv_header_text TYPE zmm_migo_cf-zz1_header_text,
      gv_display     TYPE flag,
      gv_first_fetch TYPE flag.

DATA: gs_zmm_migo_cf TYPE zmm_migo_cf.
