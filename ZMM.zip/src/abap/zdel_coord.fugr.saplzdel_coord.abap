*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDEL_COORDTOP.                    " Global Declarations
  INCLUDE LZDEL_COORDUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDEL_COORDF...                    " Subroutines
* INCLUDE LZDEL_COORDO...                    " PBO-Modules
* INCLUDE LZDEL_COORDI...                    " PAI-Modules
* INCLUDE LZDEL_COORDE...                    " Events
* INCLUDE LZDEL_COORDP...                    " Local class implement.
* INCLUDE LZDEL_COORDT99.                    " ABAP Unit tests
  INCLUDE LZDEL_COORDF00                          . " subprograms
  INCLUDE LZDEL_COORDI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
