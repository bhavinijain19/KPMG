*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZLOG_DETAILS....................................*
DATA:  BEGIN OF STATUS_ZLOG_DETAILS                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZLOG_DETAILS                  .
CONTROLS: TCTRL_ZLOG_DETAILS
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZLOG_DETAILS                  .
TABLES: ZLOG_DETAILS                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
