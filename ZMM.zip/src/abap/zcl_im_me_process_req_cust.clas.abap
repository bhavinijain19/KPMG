class ZCL_IM_ME_PROCESS_REQ_CUST definition
  public
  final
  create public .

public section.

  interfaces IF_EX_ME_PROCESS_REQ_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_ME_PROCESS_REQ_CUST IMPLEMENTATION.


  METHOD if_ex_me_process_req_cust~check.
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001>  Saurabh Saumya          DEVK900440 Task - DEVK954925          *
* Date: 19.01.2026                                                     *
* Functional : Sidhesh Rai                                             *
* Reason: Valdiate PR & Service Code & raise message ZMM_MSGS(008)     *
*         while saving if PR & Service Code combination doesn't exist  *
*----------------------------------------------------------------------*


    DATA ls_header TYPE mereq_header.
    ls_header = im_header->get_data( ).

    DATA lt_items TYPE mmpur_requisition_items.
    lt_items = im_header->get_items( ).

*Loop through all PR items
    LOOP AT lt_items INTO DATA(ls_wrap).

      DATA(lo_item) = ls_wrap-item.
      DATA(ls_item) = lo_item->get_data( ).

*Skip non-service items
      IF ls_item-packno IS INITIAL.
        CONTINUE.
      ENDIF.

*Determine vendor
      DATA(lv_lifnr_int) = ls_item-lifnr.

      IF lv_lifnr_int IS INITIAL.
        SELECT SINGLE lifnr
          FROM eban
          INTO @lv_lifnr_int
          WHERE banfn = @ls_header-banfn
            AND bnfpo = @ls_item-bnfpo.
      ENDIF.

      IF lv_lifnr_int IS INITIAL.
        CONTINUE.
      ENDIF.

*Get runtime Services buffer via IF_SERVICES_MM
      DATA: lt_esll TYPE mmsrv_esll,
            lt_esuh TYPE mmsrv_esuh,
            lt_esuc TYPE mmsrv_esuc,
            lt_eskl TYPE mmsrv_eskl.

      TRY.
          DATA(lo_services) = CAST if_services_mm( lo_item ).
        CATCH cx_sy_move_cast_error.
          CONTINUE.   "item isn't a service-capable item
      ENDTRY.

      CALL METHOD lo_services->get_srv_data
        EXPORTING
          im_packno = ls_item-packno
        IMPORTING
          ex_esll   = lt_esll
          ex_esuh   = lt_esuh
          ex_esuc   = lt_esuc
          ex_eskl   = lt_eskl.

      IF lt_esll IS INITIAL.
        CONTINUE.
      ENDIF.

*Find subpackages under main PACKNO
      DATA lt_sub TYPE HASHED TABLE OF packno WITH UNIQUE KEY table_line.

      LOOP AT lt_esll ASSIGNING FIELD-SYMBOL(<l1>)
           WHERE packno = ls_item-packno.
        IF <l1>-sub_packno IS NOT INITIAL.
          INSERT <l1>-sub_packno INTO TABLE lt_sub.
        ENDIF.
      ENDLOOP.

      IF lt_sub IS INITIAL.
        CONTINUE.
      ENDIF.

*Collect all actual service lines under these subpackages
      DATA lt_srv TYPE mmsrv_esll.

      LOOP AT lt_esll ASSIGNING FIELD-SYMBOL(<ls_srv>).
        IF line_exists( lt_sub[ table_line = <ls_srv>-packno ] ).
          APPEND <ls_srv> TO lt_srv.
        ENDIF.
      ENDLOOP.

      IF lt_srv IS INITIAL.
        CONTINUE.
      ENDIF.

*Determine latest SRVPOS (highest position)
      SORT lt_srv BY srvpos DESCENDING.
      DATA(lv_srvpos_latest) = lt_srv[ 1 ]-srvpos.

      IF lv_srvpos_latest IS INITIAL.
        CONTINUE.
      ENDIF.

*Validate Vendor & Service Code combination in custom table
      SELECT SINGLE @abap_true
        FROM zmm_vendor_serv
        WHERE lifnr = @lv_lifnr_int
          AND srvpos = @lv_srvpos_latest
        INTO @DATA(lv_exists).

      IF sy-subrc <> 0.
*Raise error for the item where Vendor & Service Code combination doesn't exist
        MESSAGE e008(zmm_msgs) WITH ls_item-bnfpo.
      ENDIF.
    ENDLOOP.






******************Retrofit Code*************************

    DATA i_items   TYPE  mmpur_requisition_items.
    DATA: wa_item     LIKE LINE OF i_items,
          lv_if_item  TYPE REF TO if_purchase_requisition_item,
          lt_itm_data TYPE mereq_item.

    TYPES: BEGIN OF t_final,
             werks TYPE t001w-werks,
             kostl TYPE bseg-kostl,
             matnr TYPE mara-matnr,
             bsart TYPE ekko-bsart,
           END OF t_final.
    DATA: it_final TYPE STANDARD TABLE OF t_final,
          wa_final TYPE t_final.
    DATA: idx TYPE sy-tabix.
*
    DATA: lt_requisition_items  TYPE mmpur_requisition_items.
    DATA:  ls_mereqitem         TYPE mereq_item.
    DATA: mmpur_accounting_list TYPE mmpur_accounting_list,
          re_exkn               TYPE exkn.
    FIELD-SYMBOLS: <is_acc> TYPE LINE OF mmpur_accounting_list.
    FIELD-SYMBOLS: <item>       TYPE LINE OF mmpur_requisition_items.

    DATA:  lv_len TYPE i.
    DATA: v_kostl(10).

    CALL METHOD im_header->get_items
      RECEIVING
        re_items = i_items.

    LOOP AT i_items INTO wa_item.
      lv_if_item = wa_item-item.

      CALL METHOD lv_if_item->get_data
        RECEIVING
          re_data = lt_itm_data.
      wa_final-werks = lt_itm_data-werks.
      wa_final-matnr = lt_itm_data-matnr.
      wa_final-bsart = lt_itm_data-bsart.
      APPEND wa_final TO it_final.
    ENDLOOP.

    READ TABLE it_final INTO wa_final INDEX 1.
    LOOP AT it_final TRANSPORTING NO FIELDS
       WHERE ( werks NE wa_final-werks ).
      EXIT.
    ENDLOOP.
    IF ( syst-subrc = 0 ) .

      MESSAGE 'MULTIPLE PLANT NOT ALLOW IN SINGLE PR ' TYPE 'E'.
      ch_failed = 'X'.
    ENDIF.

******************** Costcenter as per plant
    LOOP AT i_items ASSIGNING <item>.
      idx = idx + 1.


      CALL METHOD <item>-item->get_data
        RECEIVING
          re_data = ls_mereqitem.

      CALL METHOD <item>-item->if_acct_container_mm~get_items
        RECEIVING
          re_items = mmpur_accounting_list.

      LOOP AT mmpur_accounting_list ASSIGNING <is_acc>.

        CALL METHOD <is_acc>-model->get_exkn
          RECEIVING
            re_exkn = re_exkn.
        wa_final-kostl =  re_exkn-kostl.
        MODIFY it_final FROM wa_final INDEX idx TRANSPORTING kostl.
      ENDLOOP.
    ENDLOOP.

    LOOP AT it_final INTO wa_final.
      IF wa_final-kostl IS NOT INITIAL.
        lv_len = strlen( wa_final-kostl ).
        lv_len = lv_len - 6.
        v_kostl = wa_final-kostl+0(lv_len).


        IF v_kostl IS NOT INITIAL.
**          IF v_kostl = '1600' AND wa_final-werks = '1615'.
**          ELSEIF v_kostl = '200N' AND wa_final-werks = '2000'." Added by Soham Upadhyay 10.04.2017
**          ELSEIF v_kostl = '210N' AND wa_final-werks = '2100'." Added by Soham Upadhyay 10.04.2017
**
**          ELSEIF wa_final-werks <> v_kostl.
**            MESSAGE 'Costcenter not relevant to this plant' TYPE 'E'.
**          ELSEIF v_kostl = '2000' AND wa_final-werks = '2000'.
**            MESSAGE 'Costcenter not relevant to this Plant' TYPE 'E'.
**          ELSEIF v_kostl = '2100' AND wa_final-werks = '2100'.
**            MESSAGE 'Costcenter not relevant to this Plant' TYPE 'E'.
**          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
***************
*   field-symbols : <fs_zdomes> type any table.
*
*     lt_items  = im_header->get_items( ).
*      refresh lt_details.
*      loop at lt_items into ls_item.
*        ls_detail = ls_item-item->get_data( ).
*        append ls_detail to lt_details.
*       endloop.
*
*       read table lt_details into ls_detail index 1.
*       loop at lt_details transporting no fields
*          where ( werks ne ls_detail-werks ).
*         exit.
*       endloop.
*       if ( syst-subrc = 0 ) .
*
*         message 'MULTIPLE PLANT NOT ALLOW' type 'E'.
*          ch_failed = 'X'.
*       endif.
***************************
*    ****** Added changes for check of Release Strategy by parth  on 23.09.2022

    CONSTANTS:
      c_tvarvc_name TYPE rvari_vnam VALUE 'Z_PRTYPES_VALI',
      c_type_user   TYPE rsscr_kind VALUE 'S'.

    TYPES :BEGIN OF ty_tvarvc,
             low TYPE tvarvc-low,
           END OF ty_tvarvc.
    DATA : it_tvarvc TYPE STANDARD TABLE OF ty_tvarvc,
           wa_tvarvc TYPE ty_tvarvc.

    IF <item> IS ASSIGNED.
      UNASSIGN <item>.
    ENDIF.

    SELECT low
      INTO TABLE it_tvarvc
      FROM tvarvc
      WHERE name = c_tvarvc_name.

    LOOP AT i_items ASSIGNING <item>.
      CLEAR: ls_mereqitem.
      CALL METHOD <item>-item->get_data
        RECEIVING
          re_data = ls_mereqitem.

      READ TABLE it_tvarvc INTO wa_tvarvc WITH KEY low = ls_mereqitem-bsart.
      IF sy-subrc <> '0'.
        IF ls_mereqitem-loekz NE 'X'.
          IF ls_mereqitem-frgkz IS INITIAL AND ls_mereqitem-frgst IS INITIAL.
            MESSAGE 'Please Configure Release Strategy' TYPE 'E'.
          ENDIF.
        ENDIF.
      ENDIF.

    ENDLOOP.

*    READ TABLE it_tvarvc INTO wa_tvarvc WITH KEY low = ls_mereqitem-bsart.
*    IF sy-subrc <> '0'.
*      IF ls_mereqitem-loekz NE 'L'.
*      IF ls_mereqitem-frgkz IS INITIAL AND ls_mereqitem-frgst IS INITIAL.
*        MESSAGE 'Please Configure Release Strategy' TYPE 'E'.
*      ENDIF.
*      ENDIF.
*    ENDIF.
****** End of changes by parth shukla on 23.09.2022
***************
*    LOOP AT it_final INTO wa_final.
*      IF wa_final-matnr IS INITIAL AND wa_final-bsart <> 'SERV'.
*        MESSAGE 'Enter Material Code ' TYPE 'E'.
*      ENDIF.
*    ENDLOOP.

***&--------------------------------------------------------------------------------&*
***& Author   : AIS-Bhushan Bhalerao
***& Date     : 13-06-2023
***& Purpose  : Not Allow to Change the PR if PO exist against the same PR
***&--------------------------------------------------------------------------------&*
**    DATA : it_items        TYPE mmpur_requisition_items,
**           ls_item_data    TYPE mereq_item,
**           ls_item_datax   TYPE mereq_itemx,
**           lw_item_data    TYPE REF TO if_purchase_requisition_item,
**           ls_mereq_header TYPE mereq_header,
**           lt_items_old    TYPE TABLE OF mereq_item,
**           lw_items_old    TYPE mereq_item.
**
**    TYPES : BEGIN OF ty_pr_item,
**              ebeln TYPE ekpo-ebeln,
**              ebelp TYPE ekpo-ebelp,
**              banfn TYPE ekpo-banfn,
**              bnfpo TYPE ekpo-bnfpo,
**              menge TYPE ekpo-menge,
**              txt40 TYPE char40,
**            END OF ty_pr_item.
**
**    DATA: lt_pr_item TYPE TABLE OF ty_pr_item,
**          lw_pr_item TYPE ty_pr_item,
**          lt_ekpo    TYPE TABLE OF ty_pr_item,
**          lw_ekpo    TYPE ty_pr_item.
**
**    CALL METHOD im_header->get_items
**      RECEIVING
**        re_items = it_items.
**
**    CALL METHOD im_header->get_data
**      RECEIVING
**        re_data = ls_mereq_header.
**
**    LOOP AT it_items INTO DATA(lw_items).
**      lw_item_data = lw_items-item.
**
**      CALL METHOD lw_item_data->get_data
**        RECEIVING
**          re_data = ls_item_data.
**
**      lw_pr_item-banfn = ls_mereq_header-banfn.
**      lw_pr_item-bnfpo = ls_item_data-bnfpo.
**      APPEND lw_pr_item TO lt_pr_item.
**      CLEAR lw_pr_item.
**    ENDLOOP.
**
**    IMPORT lt_items_old TO lt_items_old FROM MEMORY ID 'OLD_PR_VAL'.
***    FREE MEMORY ID 'OLD_PR_VAL'.
**
**    SELECT ebeln ebelp banfn bnfpo menge
**           FROM ekpo
**           INTO TABLE lt_ekpo
**           FOR ALL ENTRIES IN lt_pr_item
**           WHERE banfn = lt_pr_item-banfn
**           AND   bnfpo = lt_pr_item-bnfpo
**           AND   loekz = ''.
**    LOOP AT lt_pr_item INTO lw_pr_item.
**      READ TABLE lt_ekpo INTO lw_ekpo WITH KEY banfn = lw_pr_item-banfn
**                                               bnfpo = lw_pr_item-bnfpo.
**      IF sy-subrc = 0.
**        LOOP AT it_items INTO lw_items.
**          lw_item_data = lw_items-item.
**
**          CALL METHOD lw_item_data->get_data
**            RECEIVING
**              re_data = ls_item_data.
**
**          "To Overwrite the Changes
**          IF ls_item_data-bnfpo = lw_pr_item-bnfpo.
**            READ TABLE lt_items_old INTO lw_items_old WITH KEY bnfpo = ls_item_data-bnfpo.
**            IF sy-subrc = 0.
**              CALL METHOD lw_item_data->set_data
**                EXPORTING
**                  im_data = lw_items_old.
**            ENDIF.
**          ENDIF.
**        ENDLOOP.
**      ENDIF.
**    ENDLOOP.












  ENDMETHOD.


  method IF_EX_ME_PROCESS_REQ_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_REQ_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_REQ_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  METHOD if_ex_me_process_req_cust~fieldselection_item.

    IF sy-uname IS NOT INITIAL.

    ENDIF.

    DATA: ls_item  TYPE mereq_item.
    ls_item = im_item->get_data( ).

    IF ls_item-pstyp = 'E'.
      ls_item-producttype = '2'.
    ENDIF.

  ENDMETHOD.


  METHOD if_ex_me_process_req_cust~fieldselection_item_refkeys.

    DATA: ls_item  TYPE mereq_item.
    ls_item = im_item->get_data( ).

    IF ls_item-pstyp = 'E'.
      ls_item-producttype = '2'.
    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_REQ_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_REQ_CUST~OPEN.
******************Retrofit Code **********************************
    TYPES : BEGIN OF ty_itemtext,
              bnfpo   TYPE bnfpo,
              line_no TYPE i,
              id      TYPE tdid,
              line    TYPE tdline,
            END OF ty_itemtext.

    DATA: lt_itemtext TYPE TABLE OF ty_itemtext,
          lw_itemtext TYPE ty_itemtext,
          tdname      TYPE thead-tdname,
          lines       TYPE TABLE OF tline,
          tdid        TYPE tdid,
          ls_header   TYPE mereq_header,
          lv_cnt      TYPE i,
          lv_cnt1     TYPE i.

    ls_header = im_header->get_data( ).

    SELECT * FROM eban
             INTO TABLE @DATA(lt_eban)
             WHERE banfn = @ls_header-banfn.

    LOOP AT lt_eban INTO DATA(lw_eban).
      CLEAR :lv_cnt,tdname,tdid.
      CONCATENATE lw_eban-banfn lw_eban-bnfpo INTO tdname.
      DO 4 TIMES.
        lv_cnt = lv_cnt + 1.
        CASE lv_cnt.
          WHEN 1. tdid = 'B01'.
          WHEN 2. tdid = 'B02'.
          WHEN 3. tdid = 'B03'.
          WHEN 4. tdid = 'B04'.
          WHEN OTHERS.
        ENDCASE.
        REFRESH lines.
        CALL FUNCTION 'READ_TEXT'
          EXPORTING
            client                  = sy-mandt
            id                      = tdid
            language                = sy-langu
            name                    = tdname
            object                  = 'EBAN'
          TABLES
            lines                   = lines
          EXCEPTIONS
            id                      = 1
            language                = 2
            name                    = 3
            not_found               = 4
            object                  = 5
            reference_check         = 6
            wrong_access_to_archive = 7
            OTHERS                  = 8.
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ENDIF.
        clear lv_cnt1.
        LOOP AT lines INTO DATA(wa_line).
          lv_cnt1 = lv_cnt1 + 1.
          lw_itemtext-line_no = lv_cnt1.
          lw_itemtext-bnfpo   = lw_eban-bnfpo.
          lw_itemtext-id      = tdid.
          lw_itemtext-line    = wa_line-tdline.
          APPEND lw_itemtext TO lt_itemtext.
          CLEAR lw_itemtext.
        ENDLOOP.
      ENDDO.
    ENDLOOP.

    FREE MEMORY ID 'PR_ITEM_TEXT'.
    IF lt_itemtext IS NOT INITIAL.
      EXPORT lt_itemtext FROM lt_itemtext TO MEMORY ID 'PR_ITEM_TEXT'.
    ENDIF.
  endmethod.


  METHOD if_ex_me_process_req_cust~post.

*    DATA: lr_item TYPE REF TO if_purchase_requisition,
*          ls_item TYPE mereq_item.
*
*    LOOP AT im_header->get_items_mm( ) INTO lr_item.
*
*      lr_item->get_data( IMPORTING es_item = ls_item ).
*
*      "Check for item category E
*      IF ls_item-pstyp = 'E'.
*        ls_item-producttype = '2'.
*
*        "Very important - update back the PR item
*        lr_item->set_data( ls_item ).
*      ENDIF.
*
*    ENDLOOP.


  ENDMETHOD.


  method IF_EX_ME_PROCESS_REQ_CUST~PROCESS_ACCOUNT.
  endmethod.


  METHOD if_ex_me_process_req_cust~process_header.
**BOC
*    DATA ls_header TYPE mereq_headerx.
*
*    ls_header = im_header->get_data( ).
*
*    SELECT SINGLE banfn, bnfpo
*      FROM eban
*      INTO @DATA(ls_eban)
*      WHERE banfn = @ls_header-banfn.
**EOC
********** Retrofit Code ****************
     DATA : l_header TYPE mereq_header.
    l_header = im_header->get_data( ).
*****************************
  ENDMETHOD.


  METHOD if_ex_me_process_req_cust~process_item.
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001>   Jayprakash Tiwari       DEVK900440                           *
* Date: 16.12.2025                                                     *
* Reason: Validate PR and raise message ZMM_MSGS(002)                  *
*......................................................................*
*......................................................................*
* <002>   Archna Gupta     DEVK900440   subtask id - DEVK901854        *
* Date: 24.02.2026                                                     *
* Reason: Validate wbs element and raise error msg  multiple wbs not   *
*          allowed  for a single line item                             *                                                                      *
*......................................................................*




    DATA: ls_item  TYPE mereq_item.


    ls_item = im_item->get_data( ).

    " Table zmm_plant_mat to maintain Plant Material COmbination
    SELECT SINGLE matnr, werks
      INTO @DATA(ls_data)
      FROM zmm_plant_mat
      WHERE matnr = @ls_item-matnr
        AND werks = @ls_item-werks.

    " Check the result of the SELECT statement
    IF sy-subrc = 0.
      DATA(lv_matnr) = |{ ls_item-matnr ALPHA = OUT }|.
      "PR for Plant &1 and Material &2 must be created from Ariba Buying
      MESSAGE e002(zmm_msgs) WITH ls_item-werks ls_item-matnr.
    ENDIF.



*****************Retrofit Code***********************************
    DATA : l_item   TYPE mereq_item,
           l_header TYPE mereq_header.

    DATA: v_mtart TYPE mara-mtart.

*    ***********    added by parth 27.06.2022
    TYPES: BEGIN OF ty_tvarv,
             sign TYPE tvarv_sign,
             opti TYPE tvarv_opti,
             low  TYPE tvarv_val,
             high TYPE tvarv_val,
           END OF ty_tvarv.

*    **************    added by parth 15.06.2022
    DATA: lt_acc_tk TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_tk TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_tk TYPE rvari_vnam VALUE 'ACCOUNT_PO_TYPE',
               c_type_tk   TYPE rsscr_kind VALUE 'S'.

    DATA: lt_acc_k TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_k TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_k TYPE rvari_vnam VALUE 'ACCOUNT_MAT_TYPE',
               c_type_k   TYPE rsscr_kind VALUE 'S'.

    DATA: lt_acc_capt TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_capt TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_ct TYPE rvari_vnam VALUE 'CAPT_PO_TYPE',
               c_type_ct   TYPE rsscr_kind VALUE 'S'.

    DATA: lt_acc_capk TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_capk TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_ck TYPE rvari_vnam VALUE 'CAPT_MAT_TYPE',
               c_type_ck   TYPE rsscr_kind VALUE 'S'.

    DATA: wa_mtart_type TYPE char200.
    DATA: wa_po_type TYPE char200.

    CONSTANTS:
      c_pr_name TYPE rvari_vnam VALUE 'Z_PRTYPES_VALI',
      c_pr_user TYPE rsscr_kind VALUE 'S'.

    TYPES :BEGIN OF ty_tvarvc,
             low TYPE tvarvc-low,
           END OF ty_tvarvc.
    DATA : it_pr TYPE STANDARD TABLE OF ty_tvarvc,
           wa_pr TYPE ty_tvarvc.

*********

****************   add changes by parth  15.06.2022

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_tk
               FROM tvarvc
               WHERE name = c_tvarvc_tk AND
                     type =  c_type_tk.

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_k
               FROM tvarvc
               WHERE name = c_tvarvc_k AND
                     type =  c_type_k.

*************************

*SELECT SINGLE low
*         INTO wa_po_type
*         FROM tvarvc
*         WHERE name = c_tvarvc_ct  .

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_capt
               FROM tvarvc
               WHERE name = c_tvarvc_ct AND
                     type =  c_type_ct.

*  SELECT SINGLE low
*         INTO wa_mtart_type
*         FROM tvarvc
*         WHERE name = c_tvarvc_ck .

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_capk
               FROM tvarvc
               WHERE name = c_tvarvc_ck AND
                     type =  c_type_ck.

    SELECT low
        INTO TABLE it_pr
        FROM tvarvc
        WHERE name = c_pr_name.
***************      end of changes by parth 15.06.2022


*
    CALL METHOD im_item->get_data
      RECEIVING
        re_data = l_item.


*ls_poheader  = im_header->get_data( ).

*l_header = l_header->get_data( ).
*    CALL METHOD im_header->get_data
*      RECEIVING
*        re_data = l_header.

*
*    READ TABLE lt_acc_tk INTO lw_acc_tk WITH KEY low = l_item-bsart.
*    IF sy-subrc <> 0.
*
*      SELECT single mtart FROM mara INTO v_mtart WHERE matnr = l_item-matnr.
*
*        READ TABLE lt_acc_k INTO lw_acc_k WITH KEY low = v_mtart.
*        IF sy-subrc <> 0.
*          IF l_item-knttp = 'K'.
**            MESSAGE 'Account Assignment Allowd For UNBW Material' TYPE 'E'.
*             MESSAGE e043(zmm) WITH v_mtart.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*      clear: v_mtart.
*
************************      Po 29.06.2022
*     READ TABLE lt_acc_capt INTO lw_acc_capt WITH KEY low = l_item-bsart.
**       if wa_po_type <> l_item-bsart.
*       IF sy-subrc <> 0.
*
*       SELECT single mtart FROM mara INTO v_mtart WHERE matnr = l_item-matnr.
*
*       READ TABLE lt_acc_capk into lw_acc_capk with key low = v_mtart.
**     if  wa_mtart_type  = v_mtart.
*        IF sy-subrc =  0.
**         MESSAGE 'Material group not allowed ' TYPE 'E'.
*         MESSAGE e044(zmm) WITH l_item-bsart .
*        ENDIF.
*       else.
*
*        SELECT single mtart FROM mara INTO v_mtart WHERE matnr = l_item-matnr.
*
*        READ TABLE lt_acc_capk INTO lw_acc_capk WITH KEY low = v_mtart.
**        if  wa_mtart_type  <> v_mtart.
*        IF sy-subrc <>  0.
**         MESSAGE 'Material group not allowed ' TYPE 'E'.
*          MESSAGE e044(zmm) WITH l_item-bsart.
*        ENDIF.
*
*        ENDIF.
*
***************************        FOR ACCOUNT ASSIGMENT
*        READ TABLE lt_acc_capt INTO lw_acc_capt WITH KEY low = l_item-bsart.
*
*

*
*       READ TABLE lt_acc_capk into lw_acc_capk with key low = v_mtart.
**     if  wa_mtart_type  = v_mtart.
*        IF sy-subrc =  0.
*
*          IF l_item-knttp <> 'A' AND l_item-knttp <> 'P' AND l_item-knttp <>  'Q' .
**         MESSAGE 'Material group not allowed ' TYPE 'E'.
*         MESSAGE e044(zmm) WITH l_item-bsart .
*        ENDIF.
*        ENDIF.

***********************
*
*         SELECT single mtart FROM mara INTO v_mtart WHERE matnr = l_item-matnr.
*
*         if wa_po_type = l_item-bsart and wa_mtart_type  = v_mtart.
*         else.
*           MESSAGE 'Material group ZCAP not allowed ' TYPE 'E'.
*         endif.



*      ENDIF.
*    CLEAR: v_mtart.

*******************       fOR RELEASE CHECK IN PR
*       READ TABLE it_pr INTO wa_pr WITH KEY low = l_item-bsart.
*      IF sy-subrc <> '0'.
*        IF l_item-loekz NE 'L'.
*          IF l_item-frgkz IS INITIAL AND l_item-frgst IS INITIAL.
*            MESSAGE 'Please Configure Release Strategy' TYPE 'E'.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*************

    SELECT SINGLE mtart FROM mara INTO v_mtart WHERE matnr = l_item-matnr.

    SELECT bsart,
                knttp,
                pstyp,
                mtart FROM zmm_prpo_type INTO TABLE @DATA(lt_prpo).

    SELECT pstyp,
           epstp FROM t163y INTO TABLE @DATA(lt_t163) WHERE spras = 'E'.

*     LOOP at lt_prpo into data(ls_prpo).
    READ TABLE lt_t163 INTO DATA(ls_t163) WITH KEY pstyp = l_item-pstyp.

    READ TABLE lt_prpo INTO DATA(ls_prpo) WITH KEY bsart = l_item-bsart knttp = l_item-knttp pstyp = ls_t163-epstp mtart = v_mtart.

*    IF ls_prpo-pstyp IS INITIAL.
*      ls_prpo-pstyp = '0'.
*ENDIF.
    IF ls_prpo IS INITIAL.
      MESSAGE 'Please mention correct combination of doc type and material.' TYPE 'E'.
    ENDIF.
    IF ls_prpo-bsart <> l_item-bsart AND ls_prpo-knttp <> l_item-knttp AND
       ls_prpo-pstyp <> l_item-pstyp AND ls_prpo-mtart <> v_mtart.

      MESSAGE 'Please mention correct combination of doc type and material.' TYPE 'E'.
    ENDIF.



**
*&--------------------------------------------------------------------------------&*
*& Author   : AIS-Bhushan Bhalerao
*& Date     : 24-06-2023
*& Purpose  : Not Allow to Change the PR if PO exist against the same PR
*&          : Only for Text
*&--------------------------------------------------------------------------------&*
    TYPES : BEGIN OF ty_itemtext,
              bnfpo   TYPE bnfpo,
              line_no TYPE i,
              id      TYPE tdid,
              line    TYPE tdline,
            END OF ty_itemtext.

    DATA: lt_itemtext   TYPE TABLE OF ty_itemtext,
          lw_itemtext   TYPE ty_itemtext,
          lt_itemtext_n TYPE TABLE OF ty_itemtext,
          lw_itemtext_n TYPE ty_itemtext,
          tdname        TYPE thead-tdname,
          lines         TYPE TABLE OF tline,
          tdid          TYPE tdid,
          im_header     TYPE REF TO if_purchase_requisition,
          ls_header     TYPE mereq_header,
          lv_cnt        TYPE i,
          lv_cnt1       TYPE i,
*          ls_item       TYPE mereq_item,
          lt_ekpo       TYPE TABLE OF ekpo.

    im_header = im_item->get_requisition( ).
    ls_header = im_header->get_data( ).
    ls_item = im_item->get_data( ).

    SELECT * FROM ekpo
             INTO TABLE lt_ekpo
             WHERE banfn = ls_header-banfn
             AND   bnfpo = ls_item-bnfpo
             AND   loekz = ''.

    IF sy-subrc = 0.
      CLEAR :lv_cnt,tdname.
      CONCATENATE ls_header-banfn ls_item-bnfpo INTO tdname.

      DO 4 TIMES.
        lv_cnt = lv_cnt + 1.
        CASE lv_cnt.
          WHEN 1. tdid = 'B01'.
          WHEN 2. tdid = 'B02'.
          WHEN 3. tdid = 'B03'.
          WHEN 4. tdid = 'B04'.
          WHEN OTHERS.
        ENDCASE.
        REFRESH lines.
        CALL FUNCTION 'READ_TEXT'
          EXPORTING
            client                  = sy-mandt
            id                      = tdid
            language                = sy-langu
            name                    = tdname
            object                  = 'EBAN'
          TABLES
            lines                   = lines
          EXCEPTIONS
            id                      = 1
            language                = 2
            name                    = 3
            not_found               = 4
            object                  = 5
            reference_check         = 6
            wrong_access_to_archive = 7
            OTHERS                  = 8.
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ENDIF.
        CLEAR lv_cnt1.
        LOOP AT lines INTO DATA(wa_line).
          lv_cnt1 = lv_cnt1 + 1.
          lw_itemtext_n-line_no = lv_cnt1.
          lw_itemtext_n-bnfpo = ls_item-bnfpo.
          lw_itemtext_n-id    = tdid.
          lw_itemtext_n-line  = wa_line-tdline.
          APPEND lw_itemtext_n TO lt_itemtext_n.
          CLEAR lw_itemtext_n.
        ENDLOOP.
      ENDDO.

      IMPORT lt_itemtext TO lt_itemtext FROM MEMORY ID 'PR_ITEM_TEXT'.
      DELETE lt_itemtext WHERE bnfpo NE ls_item-bnfpo.
      DESCRIBE TABLE lt_itemtext LINES DATA(lv_lines).
      DESCRIBE TABLE lt_itemtext_n LINES DATA(lv_lines_n).

      IF lt_itemtext IS NOT INITIAL AND lt_itemtext_n IS NOT INITIAL.
        LOOP AT lt_itemtext INTO lw_itemtext.
          READ TABLE lt_itemtext_n INTO lw_itemtext_n WITH KEY line_no = lw_itemtext-line_no
                                                               id      = lw_itemtext-id.
          IF sy-subrc = 0.
            IF lw_itemtext-line NE lw_itemtext_n-line.
              MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
            ENDIF.
          ELSE.
            MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
          ENDIF.
          CLEAR:lw_itemtext,lw_itemtext_n.
        ENDLOOP.

        LOOP AT lt_itemtext_n INTO lw_itemtext_n.
          READ TABLE lt_itemtext INTO lw_itemtext WITH KEY line_no = lw_itemtext_n-line_no
                                                           id      = lw_itemtext_n-id.
          IF sy-subrc = 0.
            IF lw_itemtext-line NE lw_itemtext_n-line.
              MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
            ENDIF.
          ELSE.
            MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
          ENDIF.
          CLEAR:lw_itemtext,lw_itemtext_n.
        ENDLOOP.
      ELSEIF lt_itemtext IS NOT INITIAL AND lt_itemtext_n IS INITIAL.
        MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
      ELSEIF lt_itemtext IS INITIAL AND lt_itemtext_n IS NOT INITIAL.
        MESSAGE 'Item texts change not possible due to PO exits' TYPE 'E'.
      ENDIF.
    ENDIF.
    "Adding Start by Rahul Vasita on 16.05.2024 10:38:35
    DATA : li_items TYPE mmpur_accounting_list,
           lw_items TYPE mmpur_accounting_type,
           lw_exkn  TYPE exkn.
    TYPES : BEGIN OF ty_hkont,
              hkont TYPE saknr,
            END OF ty_hkont.
    DATA : lt_hkont     TYPE TABLE OF ty_hkont,
           ls_hkont     TYPE ty_hkont,
           lv_msg_e     TYPE char255,
           lv_switch(1) TYPE c.
    CLEAR : lv_switch , lv_msg_e , ls_hkont .
    REFRESH : lt_hkont[].

******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low FROM tvarvc INTO lv_switch WHERE name = 'ZMM_GL_EN_SWITCH' AND type = 'P'.
    SELECT low FROM tvarvc INTO lv_switch WHERE name = 'ZMM_GL_EN_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************




    IF lv_switch = abap_true.
      IF l_item-knttp = 'P' OR l_item-knttp = 'Q'.
        SELECT name,
               low
          FROM tvarvc
          INTO TABLE @DATA(lt_tvarvc)
          WHERE name = 'ZMM_GL_ENHANCEMENT' AND type = 'S'.
        LOOP AT lt_tvarvc INTO DATA(ls_tv).
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = ls_tv-low
            IMPORTING
              output = ls_hkont-hkont.

          APPEND ls_hkont TO lt_hkont.
          CLEAR : ls_hkont , ls_tv.
        ENDLOOP.


        CALL METHOD im_item->if_acct_container_mm~get_items
          RECEIVING
            re_items = li_items.
        LOOP AT li_items INTO lw_items.
          CALL METHOD lw_items-model->get_exkn
            RECEIVING
              re_exkn = lw_exkn.



          "Added by Ranjan 20.02.2026
          IF l_item-knttp = 'P'.

            IF lw_exkn-sakto IS INITIAL.

              SELECT SINGLE
         low
    FROM tvarvc
    INTO @lw_exkn-sakto
    WHERE name = 'ZMM_GL_DEFAULT' AND type = 'P'.



              CALL METHOD lw_items-model->set_exkn
                EXPORTING
                  im_exkn = lw_exkn.

            ENDIF.
          ENDIF.


          "End of change by Ranjan




          READ TABLE lt_hkont INTO ls_hkont WITH KEY hkont = lw_exkn-sakto.
          IF sy-subrc <> 0.
            lv_msg_e = 'DIFFERENT G/L FOR STOCK OR PROJECT EXPENSE'. CONDENSE : lv_msg_e.

            MESSAGE lv_msg_e TYPE 'E'.
          ENDIF.

        ENDLOOP.
      ENDIF."IF l_item-knttp = 'P' OR l_item-knttp = 'Q'.
    ENDIF."    IF lv_switch = abap_true.

    "Adding End by Rahul Vasita on 16.05.2024 10:38:35

**Start change of Archna Gupta on 23.02.2026
    im_header = im_item->get_requisition( ).
    DATA(ls_items) = im_item->get_data( ).
*    IF ls_items-knttp = 'P' and ls_items-knttp = 'D'.
    DATA: lv_item1 TYPE bnfpo.
    LOOP AT li_items INTO lw_items.

      CALL METHOD lw_items-model->get_exkn
        RECEIVING
          re_exkn = lw_exkn.
      IF ls_items-knttp = 'P' AND ls_items-pstyp = '9'.

        DATA(lv_item) = ls_items-bnfpo.

        IF lv_item <> lv_item1.

          DATA(lv_first_wbs_element) = lw_exkn-psp_pnr.
          lv_item1 = lv_item.
        ENDIF.

        IF lv_first_wbs_element <> lw_exkn-psp_pnr.
          lv_msg_e = 'Multiple WBS not allowed for a single line item'. CONDENSE : lv_msg_e.

          MESSAGE lv_msg_e TYPE 'E'.
        ENDIF.
      ENDIF.
    ENDLOOP.

*endif.

    IF ls_item-pstyp = 'A'.
      ls_item-producttype = '2'.
    ENDIF.

***End of change on Archna Gupta 23.02.2026
  ENDMETHOD.
ENDCLASS.
