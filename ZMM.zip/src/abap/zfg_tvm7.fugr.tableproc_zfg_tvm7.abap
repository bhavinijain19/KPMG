*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM7
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM7            .

  PERFORM TABLEPROC.

ENDFUNCTION.
