*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM10TOP.                     " Global Declarations
  INCLUDE LZFG_TVM10UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM10F...                     " Subroutines
* INCLUDE LZFG_TVM10O...                     " PBO-Modules
* INCLUDE LZFG_TVM10I...                     " PAI-Modules
* INCLUDE LZFG_TVM10E...                     " Events
* INCLUDE LZFG_TVM10P...                     " Local class implement.
* INCLUDE LZFG_TVM10T99.                     " ABAP Unit tests
  INCLUDE LZFG_TVM10F00                           . " subprograms
  INCLUDE LZFG_TVM10I00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
