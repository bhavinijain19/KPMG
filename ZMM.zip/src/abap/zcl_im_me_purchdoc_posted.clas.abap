class ZCL_IM_ME_PURCHDOC_POSTED definition
  public
  final
  create public .

public section.

  interfaces IF_EX_ME_PURCHDOC_POSTED .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_ME_PURCHDOC_POSTED IMPLEMENTATION.


  METHOD if_ex_me_purchdoc_posted~posted.
*
*    IF sy-tcode = 'ME29N'.
*      IF im_ekko-frgke = '2'.
*        DATA : it_po2 TYPE zit_po1.
*        DATA : wa_po2 TYPE zwa_po1.
*
*        TYPES : BEGIN OF t_po1,
*                  code     TYPE  matnr,
*                  desc     TYPE  maktx,
*                  ebelp    TYPE konv-kposn,
*                  uom      TYPE  bstme,
*                  qty      TYPE  bstmg,
*                  discount TYPE  kwert,
*                  date     TYPE eket-eindt,
*                  knumv    TYPE ekko-knumv,
*                  netwr    TYPE ekpo-netwr,
*                END OF t_po1.
*        DATA : wa_po1 TYPE t_po1.
*        DATA : it_po1 TYPE STANDARD TABLE OF t_po1.
*
*        TYPES : BEGIN OF t_po,
*                  id       TYPE i,
*                  code     TYPE  matnr,
*                  desc     TYPE  maktx,
*                  uom      TYPE  bstme,
*                  qty      TYPE  bstmg,
*                  rate     TYPE  kwert,
*                  discount TYPE  kwert,
*                  value    TYPE bprei,
*                  date     TYPE eket-eindt,
*                END OF t_po.
*        DATA : wa_po TYPE t_po.
*        DATA : it_po TYPE STANDARD TABLE OF t_po.
*
*        DATA : v_id TYPE i.
*        DATA : v_taxval TYPE kwert.
*        DATA : v_baseval TYPE kwert.
*        DATA : v_netval TYPE kwert.
*        DATA : v_basevalc(50).
*        DATA : v_netvalc(50).
*        DATA : it_tax TYPE zit_tax1.
*        DATA : wa_tax TYPE zwa_tax1.
*        DATA : v_ass TYPE kwert.
*        DATA : v_frt TYPE kwert.
*        DATA : v_frtwo TYPE kwert.
*        DATA : v_pf TYPE kwert.
*        DATA : v_bed TYPE kwert.
*        DATA : v_cess TYPE kwert.
*        DATA : v_mwskz TYPE ekpo-mwskz.
*        DATA : v_taxper TYPE kbetr_kond.
*        DATA : lv_text  TYPE char20.
*
*        TYPES : BEGIN OF t_tax1,
*                  id       TYPE  i,
*                  ztax(50),
*                  zval     TYPE  kwert,
*                END OF t_tax1.
*        DATA : wa_tax1 TYPE t_tax1.
*        DATA : it_tax1 TYPE STANDARD TABLE OF t_tax1.
*
*        TYPES : BEGIN OF t_gen,
*                  ebeln         TYPE ekko-ebeln,
*                  aedat         TYPE ekko-aedat,
*                  lifnr         TYPE ekko-lifnr,
*                  ekgrp         TYPE ekko-ekgrp,
*                  eknam         TYPE t024-eknam,
*                  smtp_addr     TYPE t024-smtp_addr,
*                  land1         TYPE lfa1-land1,
*                  name1         TYPE lfa1-name1,
*                  name2         TYPE lfa1-name2,
*                  name3         TYPE lfa1-name3,
*                  name4         TYPE lfa1-name4,
*                  ort01         TYPE lfa1-ort01,
*                  pstlz         TYPE lfa1-pstlz,
*                  regio         TYPE lfa1-regio,
*                  telf1         TYPE lfa1-telf1,
*                  regio_text    TYPE t005u-bezei,
*                  country_text  TYPE t005t-landx50,
*                  pland1        TYPE lfa1-land1,
*                  pname1        TYPE lfa1-name1,
*                  pname2        TYPE lfa1-name2,
*                  pname3        TYPE lfa1-name3,
*                  pname4        TYPE lfa1-name4,
*                  port01        TYPE lfa1-ort01,
*                  ppstlz        TYPE lfa1-pstlz,
*                  pregio        TYPE lfa1-regio,
*                  ptelf1        TYPE lfa1-telf1,
*                  pregio_text   TYPE t005u-bezei,
*                  pcountry_text TYPE t005t-landx50,
*                END OF t_gen.
*        DATA : wa_gen TYPE t_gen.
*        DATA : it_gen TYPE STANDARD TABLE OF t_gen.
*
*        TYPES : BEGIN OF t_genf,
*                  zpono      TYPE ekko-ebeln,
*                  zpodt      TYPE ekko-aedat,
*                  zeknam     TYPE t024-eknam,
*                  zsmtp_addr TYPE t024-smtp_addr,
*                  zlifnr     TYPE ekko-lifnr,
*                  zname1     TYPE lfa1-name1,
*                  zname2     TYPE lfa1-name2,
*                  zname3     TYPE lfa1-name3,
*                  zname4     TYPE lfa1-name4,
*                  zort01     TYPE lfa1-ort01,
*                  zpstlz     TYPE lfa1-pstlz,
*                  zregio     TYPE t005u-bezei,
*                  zcountry   TYPE t005t-landx50,
*                  zphone     TYPE lfa1-telf1,
*                  zpname1    TYPE lfa1-name1,
*                  zpname2    TYPE lfa1-name2,
*                  zpname3    TYPE lfa1-name3,
*                  zpname4    TYPE lfa1-name4,
*                  zport01    TYPE lfa1-ort01,
*                  zppstlz    TYPE lfa1-pstlz,
*                  zpregio    TYPE t005u-bezei,
*                  zpcountry  TYPE t005t-landx50,
*                  zpphone    TYPE lfa1-telf1,
*                END OF t_genf.
*        DATA : wa_genf TYPE t_genf.
*        DATA : it_genf TYPE STANDARD TABLE OF t_genf.
*        DATA : wa_genfinal TYPE zwa_pogen.
*
*        TYPES : BEGIN OF t_konv,
*                  kschl TYPE konv-kschl,
*                  kwert TYPE konv-kwert,
*                  kposn TYPE konv-kposn,
*                END OF t_konv.
*        DATA : wa_konv TYPE t_konv.
*        DATA : it_konv TYPE STANDARD TABLE OF t_konv.
*        DATA : wa_konv1 TYPE t_konv.
*        DATA : it_konv1 TYPE STANDARD TABLE OF t_konv.
*        DATA : v_fm_name TYPE  rs38l_fnam.
*        DATA : v_werks TYPE ekpo-werks.
*        DATA : v_lifnr TYPE t001w-lifnr.
*        DATA : v_tax TYPE kwert.
*        DATA : v_taxname(50).
*        DATA : v_ebeln TYPE ekko-ebeln.
*
*        DATA:wa_control_par     TYPE ssfctrlop.
*        DATA:wa_output_options  TYPE ssfcompop.
*        DATA:flag               TYPE c.
*        DATA:no_of_records      TYPE i.
*        DATA:it_otf_data        TYPE ssfcrescl.
*        DATA:it_otf_final       TYPE TABLE OF itcoo.
*        DATA:bin_filesize       TYPE i.
*        DATA:it_pdfdata         TYPE TABLE OF tline.
*        DATA:it_pdf             TYPE TABLE OF solisti1.
*        DATA :g_sent_to_all     TYPE sonv-flag.
*        DATA :g_tab_lines       TYPE i.
*
*        DATA :i_document_data TYPE STANDARD TABLE OF sodocchgi1,
*              i_packing_list  TYPE STANDARD TABLE OF sopcklsti1,
*              i_attachment    TYPE STANDARD TABLE OF solisti1,
*              i_body_msg      TYPE STANDARD TABLE OF solisti1,
*              i_receivers     TYPE STANDARD TABLE OF somlreci1,
*              i_pdf           TYPE STANDARD TABLE OF tline,
*              w_document_data LIKE LINE OF i_document_data,
*              w_packing_list  LIKE LINE OF i_packing_list,
*              w_attachment    LIKE LINE OF i_attachment,
*              w_body_msg      LIKE LINE OF i_body_msg,
*              w_receivers     LIKE LINE OF i_receivers,
*              w_pdf           LIKE LINE OF i_pdf.
*
*        v_ebeln = im_ekko-ebeln.
*
*        SELECT makt~matnr makt~maktx ekpo~ebelp ekpo~meins ekpo~menge ekpo~netpr eket~eindt ekko~knumv ekpo~netwr
*          INTO TABLE it_po1 FROM ekpo
*          INNER JOIN makt ON ekpo~matnr = makt~matnr
*          INNER JOIN eket ON eket~ebeln = v_ebeln AND eket~ebelp = ekpo~ebelp
*          INNER JOIN ekko ON ekko~ebeln = ekpo~ebeln
*          WHERE ekpo~ebeln EQ v_ebeln.
*
*        SELECT kschl kwert kposn FROM konv INTO TABLE it_konv FOR ALL ENTRIES IN it_po1 WHERE knumv = it_po1-knumv AND kposn = it_po1-ebelp
*        AND kschl IN ('P&F1','P&F2','P&F3','FRB5','FRB4','FRB3','FRB1','FRC4','FRC5','FRC1','FRB2','FRC2').
*
*        LOOP AT it_po1 INTO wa_po1.
*          v_id = v_id + 1.
*          wa_po-id = v_id.
*          wa_po-code = wa_po1-code.
*          wa_po-desc = wa_po1-desc.
*          wa_po-uom = wa_po1-uom.
*          wa_po-qty = wa_po1-qty.
*          SELECT SINGLE kwert FROM konv INTO wa_po-value WHERE knumv = wa_po1-knumv AND kposn = wa_po1-ebelp AND kschl IN ('P001','P000') AND kappl = 'M'.
*          SELECT SINGLE kwert FROM konv INTO wa_po-discount WHERE knumv = wa_po1-knumv AND kposn = wa_po1-ebelp AND kschl = 'R003' AND kappl = 'M'.
*          wa_po-discount = ( wa_po-discount * 100 ) /  wa_po-rate.
*          wa_po-discount = wa_po-discount * -1.
*          wa_po-rate = wa_po-value /  wa_po-qty.
*          v_ass = v_ass + wa_po-value.
*          v_baseval = v_baseval + wa_po-value.
*          wa_po-date = wa_po1-date.
*          APPEND wa_po TO it_po.
*          CLEAR : wa_po1,wa_po.
*        ENDLOOP.
*
*        SORT it_konv BY kschl kposn.
*        DELETE ADJACENT DUPLICATES FROM it_konv COMPARING kschl kposn.
*
*        LOOP AT it_konv INTO wa_konv.
*          v_taxval = v_taxval + wa_konv-kwert.
*          CASE wa_konv-kschl.
*            WHEN 'P&F2' OR 'P&F1' OR 'P&F3'.
*              v_pf = v_pf + wa_konv-kwert.
*              v_ass = v_ass + wa_tax1-zval.
*              CLEAR : wa_tax1,wa_konv.
*            WHEN 'FRB4' OR 'FRB3' OR 'FRC4' OR 'FRC5'.
*              v_frt = v_frt + wa_konv-kwert.
*              v_ass = v_ass + wa_tax1-zval.
*              CLEAR : wa_tax1,wa_konv.
*            WHEN 'FRC1' OR 'FRB2' OR 'FRC2' OR 'FRB1'.
*              v_frtwo = v_frtwo + wa_konv-kwert.
*              CLEAR : wa_tax1,wa_konv.
*
*          ENDCASE.
**  ENDAT.
*          CLEAR wa_konv.
*        ENDLOOP.
*
*        wa_tax1-id = 1.
*        wa_tax1-ztax = 'PACK & FORWARD'.
*        wa_tax1-zval = v_pf.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_pf.
*
*        wa_tax1-id = 2.
*        wa_tax1-ztax = 'FREIGHT'.
*        wa_tax1-zval = v_frt.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_frt.
*
*        SELECT SINGLE mwskz FROM ekpo INTO v_mwskz WHERE ebeln = v_ebeln.
*
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JMIP' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = wa_tax1-zval + ( ( v_ass * v_taxper ) / 100 ).
*          v_taxval = v_taxval + wa_tax1-zval.
*          v_bed = v_bed + wa_tax1-zval.
*        ENDIF.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JMOP' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-id = 3.
*        wa_tax1-ztax = 'BED'.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_ass * v_taxper ) / 100 ).
*        v_taxval = v_taxval + wa_tax1-zval.
*        v_bed = v_bed + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JEC2' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = wa_tax1-zval + ( ( v_bed * v_taxper ) / 100 ).
*          v_taxval = v_taxval + wa_tax1-zval.
*          v_cess = v_cess + wa_tax1-zval.
*        ENDIF.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JEC1' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-id = 4.
*        wa_tax1-ztax = 'E.CESS'.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_bed * v_taxper ) / 100 ).
*        v_taxval = v_taxval + wa_tax1-zval.
*        v_cess = v_cess + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSEI' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = wa_tax1-zval + ( ( v_bed * v_taxper ) / 100 ).
*          v_taxval = v_taxval + wa_tax1-zval.
*          v_cess = v_cess + wa_tax1-zval.
*        ENDIF.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSEP' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-id = 5.
*        wa_tax1-ztax = 'S&E.CESS'.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_bed * v_taxper ) / 100 ).
*        v_taxval = v_taxval + wa_tax1-zval.
*        v_cess = v_cess + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JVCD' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = ( ( wa_tax1-zval + v_cess + v_bed + v_baseval ) * v_taxper ).
*          wa_tax1-zval = wa_tax1-zval / 100.
*        ENDIF.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JVRD' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = ( ( wa_tax1-zval + v_cess + v_bed + v_baseval ) * v_taxper ).
*          wa_tax1-zval = wa_tax1-zval / 100.
*        ENDIF.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JVCS' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-id = 6.
*        wa_tax1-ztax = 'VAT/CST'.
*        IF v_taxper IS NOT INITIAL.
*          wa_tax1-zval = ( ( wa_tax1-zval + v_cess + v_bed + v_baseval ) * v_taxper ).
*          wa_tax1-zval = wa_tax1-zval / 100.
*        ENDIF.
*        v_taxval = v_taxval + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'ZVCD' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = ( ( wa_tax1-zval + v_cess + v_bed + v_baseval ) * v_taxper ).
*        wa_tax1-zval = wa_tax1-zval / 100.
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'ZVRD' AND mwsk1 = v_mwskz.
*        wa_tax1-id = 7.
*        v_taxper = v_taxper / 10.
*        wa_tax1-ztax = 'ADDITIONAL VAT'.
*        wa_tax1-zval = ( ( wa_tax1-zval + v_cess + v_bed + v_baseval ) * v_taxper ).
*        wa_tax1-zval = wa_tax1-zval / 100.
*        v_taxval = v_taxval + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSVD' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSV2' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JEC3' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JEC4' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSE2' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        CLEAR v_taxper.
*
*        SELECT SINGLE kbetr FROM konp INTO v_taxper WHERE kschl = 'JSE1' AND mwsk1 = v_mwskz.
*        v_taxper = v_taxper / 10.
*        wa_tax1-id = 6.
*        wa_tax1-ztax = 'SERVICE TAX'.
*        wa_tax1-zval = wa_tax1-zval + ( ( v_cess * v_taxper ) / 100 ).
*        v_taxval = v_taxval + wa_tax1-zval.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_taxper.
*        CLEAR : v_bed,v_ass,v_cess.
*
*        wa_tax1-id = 7.
*        wa_tax1-ztax = 'FREIGHT W/O TAX'.
*        wa_tax1-zval = v_frtwo.
*        IF wa_tax1-zval IS NOT INITIAL.
*          APPEND wa_tax1 TO it_tax1.
*        ENDIF.
*        CLEAR : wa_tax1,v_frtwo.
*
*        SORT it_tax1 BY id.
*
*        LOOP AT it_tax1 INTO wa_tax1.
*          v_tax = v_tax + wa_tax1-zval.
*          v_taxname = wa_tax1-ztax.
*          AT END OF id.
*            wa_tax-id =  wa_tax-id + 1.
*            wa_tax-ztax = v_taxname.
*            wa_tax-zval = v_tax.
*            APPEND wa_tax TO it_tax.
*            CLEAR : wa_tax,v_tax,v_taxname.
*          ENDAT.
*          CLEAR : wa_tax1,v_taxname.
*        ENDLOOP.
*
*        v_netval = v_baseval + v_taxval.
*
*        MOVE v_baseval TO v_basevalc.
*        MOVE v_netval TO v_netvalc.
*
*        wa_tax-ztax = 'NET TOTAL'.
*        wa_tax-zval = v_netvalc.
*        APPEND wa_tax TO it_tax.
*        CLEAR wa_tax.
*
*        LOOP AT it_po INTO wa_po.
*          MOVE-CORRESPONDING wa_po TO wa_po2.
*          CONCATENATE wa_po-date+6(2) '-' wa_po-date+4(2) '-' wa_po-date+0(4) INTO wa_po2-date.
*          APPEND wa_po2 TO it_po2.
*          CLEAR : wa_po , wa_po2.
*        ENDLOOP.
*
*        CLEAR wa_gen.
*        SELECT SINGLE ekko~ebeln ekko~aedat ekko~lifnr ekko~ekgrp t024~eknam t024~smtp_addr lfa1~land1 lfa1~name1 lfa1~name2 lfa1~name3
*                      lfa1~name4 lfa1~ort01 lfa1~pstlz lfa1~regio lfa1~telf1 ekpo~werks
*                      INTO (wa_gen-ebeln,wa_gen-aedat,wa_gen-lifnr,wa_gen-ekgrp,wa_gen-eknam,wa_gen-smtp_addr,wa_gen-land1,wa_gen-name1,
*                            wa_gen-name2,wa_gen-name3,wa_gen-name4,wa_gen-ort01,wa_gen-pstlz,wa_gen-regio,wa_gen-telf1,v_werks)
*                      FROM ekko LEFT OUTER JOIN t024 ON ekko~ekgrp = t024~ekgrp
*                                LEFT OUTER JOIN lfa1 ON ekko~lifnr = lfa1~lifnr
*                                LEFT OUTER JOIN ekpo ON ekko~ebeln = ekpo~ebeln
*                      WHERE ekko~ebeln = v_ebeln.
*
*        SELECT SINGLE bezei FROM t005u INTO wa_gen-regio_text WHERE spras = 'EN' AND land1 = wa_gen-land1 AND bland = wa_gen-regio.
*        SELECT SINGLE landx50 FROM t005t INTO wa_gen-country_text WHERE spras = 'EN' AND land1 = wa_gen-land1.
*        SELECT SINGLE lifnr FROM t001w INTO v_lifnr WHERE werks = v_werks.
*        SELECT SINGLE land1 name1 name2 name3 name4 ort01 pstlz regio telf1 INTO (wa_gen-pland1,wa_gen-pname1,wa_gen-pname2,wa_gen-pname3,
*                      wa_gen-pname4,wa_gen-port01,wa_gen-ppstlz,wa_gen-pregio,wa_gen-ptelf1) FROM lfa1 WHERE lifnr = v_lifnr.
*        SELECT SINGLE bezei FROM t005u INTO wa_gen-pregio_text WHERE spras = 'EN' AND land1 = wa_gen-pland1 AND bland = wa_gen-pregio.
*        SELECT SINGLE landx50 FROM t005t INTO wa_gen-pcountry_text WHERE spras = 'EN' AND land1 = wa_gen-pland1.
*
*        wa_genf-zpono      =   wa_gen-ebeln.
*        wa_genf-zpodt      =   wa_gen-aedat.
*        wa_genf-zeknam     =   wa_gen-eknam.
*        wa_genf-zsmtp_addr =  wa_gen-smtp_addr.
*        wa_genf-zlifnr     =   wa_gen-lifnr.
*        wa_genf-zname1     =   wa_gen-name1.
*        wa_genf-zname2     =   wa_gen-name2.
*        wa_genf-zname3     =   wa_gen-name3.
*        wa_genf-zname4     =   wa_gen-name4.
*        wa_genf-zort01     =   wa_gen-ort01.
*        wa_genf-zpstlz     =   wa_gen-pstlz.
*        wa_genf-zregio     =   wa_gen-regio_text.
*        wa_genf-zcountry   =   wa_gen-country_text.
*        wa_genf-zphone     =   wa_gen-telf1.
*        wa_genf-zpname1    =   wa_gen-pname1.
*        wa_genf-zpname2    =   wa_gen-pname2.
*        wa_genf-zpname3    =   wa_gen-pname3.
*        wa_genf-zpname4    =   wa_gen-pname4.
*        wa_genf-zport01    =   wa_gen-port01.
*        wa_genf-zppstlz    =   wa_gen-ppstlz.
*        wa_genf-zpregio    =   wa_gen-pregio_text.
*        wa_genf-zpcountry  =   wa_gen-pcountry_text.
*        wa_genf-zpphone    =   wa_gen-ptelf1.
*        MOVE-CORRESPONDING wa_genf TO wa_genfinal.
*        CONCATENATE wa_genf-zpodt+6(2) '/' wa_genf-zpodt+4(2) '/' wa_genf-zpodt+0(4) INTO wa_genfinal-zpodt.
*
*        CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
*          EXPORTING
*            formname = 'ZPO_EMAIL_SSF'
*          IMPORTING
*            fm_name  = v_fm_name.
*        IF sy-subrc <> 0.
*        ENDIF.
*
*        wa_control_par-getotf = 'X'.
*        wa_control_par-no_dialog = 'X'.
*        wa_output_options-tdnoprev = 'X'.
*
*        CALL FUNCTION v_fm_name
*          EXPORTING
*            control_parameters = wa_control_par
*            output_options     = wa_output_options
*            it_po              = it_po2
*            it_tax             = it_tax
*            wa_pogen           = wa_genfinal
*            v_baseval          = v_basevalc
*            user_settings      = 'X'
*          IMPORTING
*            job_output_info    = it_otf_data.
*        IF sy-subrc <> 0.
*        ENDIF.
*        it_otf_final[] =  it_otf_data-otfdata[].
*
*        CALL FUNCTION 'CONVERT_OTF'
*          EXPORTING
*            format                = 'PDF'
*          IMPORTING
*            bin_filesize          = bin_filesize
*          TABLES
*            otf                   = it_otf_final
*            lines                 = it_pdfdata[]
*          EXCEPTIONS
*            err_max_linewidth     = 1
*            err_format            = 2
*            err_conv_not_possible = 3
*            OTHERS                = 4.
*        IF sy-subrc <> 0.
*        ENDIF.
*
*        CALL FUNCTION 'SX_TABLE_LINE_WIDTH_CHANGE'
*          EXPORTING
*            line_width_dst = '255'
*          TABLES
*            content_in     = it_pdfdata[]
*            content_out    = it_pdf[].
*        IF sy-subrc = 0.
*
*          "Subject of the mail.
*          w_document_data-obj_name  = 'MAIL_TO_HEAD'.
*          w_document_data-obj_descr = 'REGARDING MAIL PROGRAM BY SAP ABAP'.
*          "BODY OF THE MAIL
*          w_body_msg = 'THIS IS BODY OF MAIL MSG.'.
*          APPEND w_body_msg TO i_body_msg.
*          CLEAR  w_body_msg.
*          "WRITE PACKING LIST FOR BODY
*          DESCRIBE TABLE i_body_msg LINES g_tab_lines.
*          w_packing_list-head_start = 1.
*          w_packing_list-head_num   = 0.
*          w_packing_list-body_start = 1.
*          w_packing_list-body_num   = g_tab_lines.
*          w_packing_list-doc_type   = 'RAW'.
*          APPEND w_packing_list TO i_packing_list.
*          CLEAR  w_packing_list.
*          "WRITE PACKING LIST FOR ATTACHMENT
*          w_packing_list-transf_bin = 'X'.
*          w_packing_list-head_start = 1.
*          w_packing_list-head_num   = 1.
*          w_packing_list-body_start = 1.
*          DESCRIBE TABLE it_pdf LINES w_packing_list-body_num.
*          w_packing_list-doc_type   = 'PDF'.
*          w_packing_list-obj_descr  = 'PDF ATTACHMENT'.
*          w_packing_list-obj_name   = 'PDF_ATTACHMENT'.
*          w_packing_list-doc_size   = w_packing_list-body_num * 255.
*          APPEND w_packing_list TO i_packing_list.
*          CLEAR  w_packing_list.
*          "FILL THE DOCUMENT DATA AND GET SIZE OF ATTACHMENT
*          w_document_data-obj_langu  = sy-langu.
*          READ TABLE it_pdf INTO w_pdf INDEX g_tab_lines.
*          w_document_data-doc_size = ( g_tab_lines - 1 ) * 255 + strlen( w_attachment ).
*          "RECEIVERS LIST.
*          w_receivers-rec_type   = 'U'."INTERNET ADDRESS
*          w_receivers-receiver   = 'hardik.patel@astralpipes.com'.
*          w_receivers-express    = 'X'.
*          APPEND w_receivers TO i_receivers .
*          CLEAR:w_receivers.
*          "FUNCTION MODULE TO SEND MAIL TO RECIPIENTS
*          CALL FUNCTION 'SO_NEW_DOCUMENT_ATT_SEND_API1'
*            EXPORTING
*              document_data              = w_document_data
*              put_in_outbox              = 'X'
*              commit_work                = 'X'
*            IMPORTING
*              sent_to_all                = g_sent_to_all
*            TABLES
*              packing_list               = i_packing_list
*              contents_bin               = it_pdf
*              contents_txt               = i_body_msg
*              receivers                  = i_receivers
*            EXCEPTIONS
*              too_many_receivers         = 1
*              document_not_sent          = 2
*              document_type_not_exist    = 3
*              operation_no_authorization = 4
*              parameter_error            = 5
*              x_error                    = 6
*              enqueue_error              = 7
*              OTHERS                     = 8.
*          IF sy-subrc = 0 .
*            MESSAGE 'MAIL HAS BEEN SUCCESSFULLY SENT.' TYPE 'I'.
*          ENDIF.
*
*        ENDIF.

*      ENDIF.
*    ENDIF.




    IF  ( sy-tcode = 'ME29N' OR  sy-tcode =  'ME28'  )   AND im_ekko-frgke = '2'. "#EC CI_USAGE_OK[1803189]
      """"ADDED BY AKSHAY DT.30.09.2025
      DATA:wa_po_status TYPE zpo_emaile.
*           IT_PO_STATUS TYPE TABLE OF ZPO_EMAILE.


      SELECT * FROM cdpos INTO TABLE @DATA(it_cdpos)
      WHERE objectclas = 'EINKBELEG' AND objectid = @im_ekko-ebeln
      AND fname = 'FRGKE' AND value_new = '2'.


      IF sy-subrc NE 0.
        wa_po_status-mandt = sy-mandt.
        wa_po_status-ebeln = im_ekko-ebeln.
        wa_po_status-entry_date = sy-datum.
        MODIFY zpo_emaile FROM wa_po_status.
        CLEAR:wa_po_status.
      ENDIF.
      """"END BY AKSHAY DT.30.09.2025
*      data : IM_EKKO type ekko.

      DATA : ent_retco  TYPE c VALUE 'X',
             ent_screen TYPE c VALUE 'X'.
      DATA : v_druv TYPE t166k-druvo.
      DATA : nast TYPE nast.
      DATA: v_ebeln TYPE ekko-ebeln,
            ls_ekko TYPE ekko,
            v_waers TYPE ekko-waers,
            v_erdat TYPE ekko-aedat,
            v_bsart TYPE ekko-bsart,
            v_lifnr TYPE ekko-lifnr.

*      v_ebeln = im_ekko-ebeln.

**      PERFORM entry_neu IN PROGRAM zpo_email_ssf  USING ent_retco
**                                                       ent_screen.
*      EXPORT wa_ekko = im_ekko TO MEMORY ID 'ZTEST'.
**      SUBMIT zpo_email_ssf AND RETURN.
*
      ls_ekko = im_ekko.
*      PERFORM entry_neu IN PROGRAM zpo_email_ssf  USING ent_retco
*                                                     ent_screen wa_ekko.

      PERFORM release_functionality IN PROGRAM zpo_email_ssf  USING  ls_ekko.

    ENDIF.


  ENDMETHOD.
ENDCLASS.
