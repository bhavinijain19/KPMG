*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_ABAPTOP.                      " Global Declarations
  INCLUDE LZMM_ABAPUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_ABAPF...                      " Subroutines
* INCLUDE LZMM_ABAPO...                      " PBO-Modules
* INCLUDE LZMM_ABAPI...                      " PAI-Modules
* INCLUDE LZMM_ABAPE...                      " Events
* INCLUDE LZMM_ABAPP...                      " Local class implement.
* INCLUDE LZMM_ABAPT99.                      " ABAP Unit tests
