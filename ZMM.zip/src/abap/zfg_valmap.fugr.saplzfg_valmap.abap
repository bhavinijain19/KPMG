*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_VALMAPTOP.                    " Global Declarations
  INCLUDE LZFG_VALMAPUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_VALMAPF...                    " Subroutines
* INCLUDE LZFG_VALMAPO...                    " PBO-Modules
* INCLUDE LZFG_VALMAPI...                    " PAI-Modules
* INCLUDE LZFG_VALMAPE...                    " Events
* INCLUDE LZFG_VALMAPP...                    " Local class implement.
* INCLUDE LZFG_VALMAPT99.                    " ABAP Unit tests
  INCLUDE LZFG_VALMAPF00                          . " subprograms
  INCLUDE LZFG_VALMAPI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
