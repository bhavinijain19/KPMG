FUNCTION-POOL ZTAX_INOP                  MESSAGE-ID SV.

* INCLUDE LZTAX_INOPD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTAX_INOPT00                           . "view rel. data dcl.
