FUNCTION-POOL ZFG_TVM8                   MESSAGE-ID SV.

* INCLUDE LZFG_TVM8D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM8T00                            . "view rel. data dcl.
