*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_PIR_RANGE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_PIR_RANGE       .

  PERFORM TABLEPROC.

ENDFUNCTION.
