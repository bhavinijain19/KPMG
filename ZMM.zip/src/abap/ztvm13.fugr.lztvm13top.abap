FUNCTION-POOL ZTVM13                     MESSAGE-ID SV.

* INCLUDE LZTVM13D...                        " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTVM13T00                              . "view rel. data dcl.
