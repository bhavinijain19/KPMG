*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_UNSEZ.......................................*
DATA:  BEGIN OF STATUS_ZMM_UNSEZ                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_UNSEZ                     .
CONTROLS: TCTRL_ZMM_UNSEZ
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZMM_UNSEZ                     .
TABLES: ZMM_UNSEZ                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
