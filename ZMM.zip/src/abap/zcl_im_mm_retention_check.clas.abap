class ZCL_IM_MM_RETENTION_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_RETENTION_CHECK IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.

*    DATA: ls_header TYPE mepoheader,
*          lv_zterm  TYPE dzterm.
*
*    CALL METHOD im_header->get_data
*      RECEIVING
*        re_data = ls_header.
*
*    lv_zterm = ls_header-zterm.
*
*    IF lv_zterm IS NOT INITIAL.
*      RETURN.
*    ENDIF.
*    SELECT SINGLE zterm
*      FROM zmm_retention
*      INTO @DATA(lv_exist)
*      WHERE zterm = @lv_zterm.
*
*    "Message 2: ZTERM not maintained
*    IF sy-subrc <> 0.
*      RETURN. "MESSAGE e002(zmm_ret) WITH lv_zterm.
*    ENDIF.
*
*    "Message 1: Fields mandatory
*    IF ls_header-rettp IS INITIAL
*       OR ls_header-retpc IS INITIAL.
*
*      MESSAGE e001(zmm_ret).
*
*    ENDIF.

*    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  METHOD if_ex_me_process_po_cust~process_header.

    DATA: ls_header TYPE mepoheader,
          ls_ret    TYPE zmm_retention.

* Get PO header data
    CALL METHOD im_header->get_data
      RECEIVING
        re_data = ls_header.

* Check payment term exists
    IF ls_header-zterm IS INITIAL.
      RETURN.
    ENDIF.

* Fetch retention mapping
    SELECT SINGLE *
      FROM zmm_retention
      INTO ls_ret
      WHERE zterm = ls_header-zterm.

    IF sy-subrc = 0.

* Fill only if empty
*      IF ls_header-rettp IS INITIAL.
*        ls_header-rettp = ls_ret-rettp.
*      ENDIF.
*
*      IF ls_header-retpc IS INITIAL.
*        ls_header-retpc = ls_ret-retpc.
*      ENDIF.
      IF ls_header-rettp <> ls_ret-rettp
        OR ls_header-retpc <> ls_ret-retpc.

        ls_header-rettp = ls_ret-rettp.
        ls_header-retpc = ls_ret-retpc.

* Set data back to PO
        CALL METHOD im_header->set_data
          EXPORTING
            im_data = ls_header.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
