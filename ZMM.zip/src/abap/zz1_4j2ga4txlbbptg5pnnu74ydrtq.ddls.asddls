@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_5EED8A411C31'

extend view I_SERVICEENTRYSHEETTP with ZZ1_4J2GA4TXLBBPTG5PNNU74YDRTQ
  
{ 
  _ServiceEntrySheetExtension.ZZ1_REFERENCE_MDH as ZZ1_REFERENCE_MDH
}
