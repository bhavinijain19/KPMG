*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTVM13
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTVM13              .

  PERFORM TABLEPROC.

ENDFUNCTION.
