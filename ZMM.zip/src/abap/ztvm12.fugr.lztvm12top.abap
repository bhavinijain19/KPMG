FUNCTION-POOL ZTVM12                     MESSAGE-ID SV.

* INCLUDE LZTVM12D...                        " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTVM12T00                              . "view rel. data dcl.
