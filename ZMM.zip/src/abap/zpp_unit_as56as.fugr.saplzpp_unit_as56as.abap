*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_UNIT_AS56ASTOP.               " Global Data
  INCLUDE LZPP_UNIT_AS56ASUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_UNIT_AS56ASF...               " Subroutines
* INCLUDE LZPP_UNIT_AS56ASO...               " PBO-Modules
* INCLUDE LZPP_UNIT_AS56ASI...               " PAI-Modules
* INCLUDE LZPP_UNIT_AS56ASE...               " Events
* INCLUDE LZPP_UNIT_AS56ASP...               " Local class implement.
* INCLUDE LZPP_UNIT_AS56AST99.               " ABAP Unit tests
  INCLUDE LZPP_UNIT_AS56ASF00                     . " subprograms
  INCLUDE LZPP_UNIT_AS56ASI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
