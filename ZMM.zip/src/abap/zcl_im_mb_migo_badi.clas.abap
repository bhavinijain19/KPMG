class ZCL_IM_MB_MIGO_BADI definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MB_MIGO_BADI .

  class-data GV_HEADER_TEXT type ZMM_MIGO_CF-ZZ1_HEADER_TEXT .
  data GV_DISPLAY type FLAG .
  data GV_ACTION type GOACTION .
  constants GV_CLASS_ID type MIGO_CLASS_ID value 'ZMB_MIGO_BADI' ##NO_TEXT.
  data G_NO_INPUT type XFELD .
  data G_CANCEL type XFELD .
  data GV_WERKS type WERKS_D .
  data WA_MSEG_C type GOITEM .
  data G_CHECK type XFELD .
  data GT_BAPIRET2_ATT type BAPIRET2_T .
  data GV_ZZGAT type ZDE_ZZGAT .
protected section.
private section.

  constants GF_CLASS_ID type MIGO_CLASS_ID value 'ZMB_MIGO_BADI' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_IM_MB_MIGO_BADI IMPLEMENTATION.


  method IF_EX_MB_MIGO_BADI~CHECK_HEADER.
  endmethod.


  METHOD if_ex_mb_migo_badi~check_item.
*
*    DATA : lv_id TYPE numc4.
*    DATA : wa_mseg_c1 TYPE goitem.
*    DATA : ls_bapiret TYPE bapiret2,
*           lv_lfimg   TYPE lfimg,
*           lv_lfimg1  TYPE lfimg.
*
    CHECK g_check IS NOT INITIAL.
*    lv_id = i_line_id.
*    READ TABLE gt_mseg_c INTO wa_mseg_c WITH KEY zeile = lv_id.
**    lv_werks = wa_mseg_c-werks.
*
*    SELECT SINGLE lfimg INTO lv_lfimg
*      FROM lips
*        WHERE vbeln = wa_mseg_c-vbeln
*          AND posnr = wa_mseg_c-posnr.
*
*    LOOP AT gt_mseg_c INTO wa_mseg_c1 WHERE vbeln = wa_mseg_c-vbeln AND posnr = wa_mseg_c-posnr.
*
*      lv_lfimg1 = lv_lfimg1 + wa_mseg_c1-menge.
***      IF wa_mseg_c-vbeln EQ wa_mseg_c1-vbeln AND
***         wa_mseg_c-posnr EQ wa_mseg_c1-posnr AND
***         wa_mseg_c-menge EQ wa_mseg_c1-menge.
***      ENDIF.
*    ENDLOOP.
*    IF lv_lfimg1 GT lv_lfimg.
*      ls_bapiret-type       = 'E'.
*      ls_bapiret-id         = 'ZMM'.
*      ls_bapiret-number     = '033'.
*      ls_bapiret-message_v1 = lv_lfimg1.
*      CONDENSE ls_bapiret-message_v1.
*      ls_bapiret-message_v2 = lv_lfimg.
*      CONDENSE ls_bapiret-message_v2.
*      APPEND ls_bapiret TO et_bapiret2.
*    ENDIF.
*
    DATA : lt_bapiret2  TYPE  bapiret2_t.
    CLEAR: et_bapiret2,lt_bapiret2.
    IF gt_bapiret2_att IS NOT INITIAL.
      lt_bapiret2 = gt_bapiret2_att.
      DELETE lt_bapiret2 WHERE message_v3 <> i_line_id.
      et_bapiret2 =  lt_bapiret2.
    ENDIF.

  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_DELETE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_LOAD.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_SAVE.
  endmethod.


  METHOD if_ex_mb_migo_badi~init.
    APPEND gv_class_id TO ct_init. "Register the implementation ID
  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~LINE_DELETE.
  endmethod.


  METHOD if_ex_mb_migo_badi~line_modify.
    CALL FUNCTION 'ZFM_MIGO_SET_HEADER_TEXT'
      EXPORTING
        iv_mblnr = cs_goitem-mblnr
        iv_mjahr = cs_goitem-mjahr.


******* Retrofit Code********************************

    FIELD-SYMBOLS : <fs_mseg> TYPE goitem.
    IF cs_goitem-werks IS NOT INITIAL.

      gv_werks = cs_goitem-werks.
      IF g_no_input IS INITIAL AND g_cancel IS INITIAL.
        IF gv_werks IS NOT INITIAL.
          CALL FUNCTION 'ZFM_GET_DATA_MIGO'
            EXPORTING
*             i_zzgat = gv_zzgat
              i_werks = gv_werks.
        ENDIF.
      ENDIF.
    ENDIF.
*    READ TABLE gt_mseg_c ASSIGNING <fs_mseg> WITH KEY zeile = cs_goitem-zeile.
*    IF sy-subrc NE 0 .
*      IF cs_goitem-take_it = 'X'.
*        MOVE cs_goitem TO wa_mseg_c.
**        MODIFY gt_mseg_c FROM wa_mseg_c.
*        APPEND wa_mseg_c TO gt_mseg_c.
*        CLEAR wa_mseg_c.
*      ENDIF.
*    ELSE.
*      IF cs_goitem-take_it NE 'X'.
*        DELETE gt_mseg_c WHERE zeile = cs_goitem-zeile.
*      ELSE.
*        IF <fs_mseg> IS ASSIGNED.
*          <fs_mseg> = cs_goitem.
*        ENDIF.
**        MODIFY gt_mseg_c FROM cs_goitem WHERE zeile = cs_goitem-zeile..
*      ENDIF.
*    ENDIF.

    DATA : v_belnr(10),
           v_auart(04),
           v_elikz(01).

***** Added changes by Carina Jose on 06.07.2020
    TYPES : BEGIN OF ty_tvarvc_wrks,
              low TYPE ekpo-werks,
            END OF ty_tvarvc_wrks.
    TYPES : BEGIN OF ty_tvarvc_auart,
              low TYPE ekko-bsart,
            END OF ty_tvarvc_auart.
    DATA : it_tvarvc_wrks  TYPE STANDARD TABLE OF ty_tvarvc_wrks,
           wa_tvarvc_wrks  TYPE ty_tvarvc_wrks,
           it_tvarvc_auart TYPE STANDARD TABLE OF ty_tvarvc_auart,
           wa_tvarvc_auart TYPE ty_tvarvc_auart.
    CONSTANTS:
      c_tvarvc_werks TYPE rvari_vnam VALUE 'ZMM_EX_CUSTOM_WERKS',
      c_tvarvc_auart TYPE rvari_vnam VALUE 'ZMM_EX_CUSTOM_AUART'.
***** End of changes by Carina Jose on 06.07.2020

    IF cs_goitem-bwtar = 'IMPORTED' AND cs_goitem-bwart = '101'.

      SELECT SINGLE belnr FROM ekbz INTO v_belnr
        WHERE ebeln =  cs_goitem-ebeln AND
              ebelp = cs_goitem-ebelp.

***** Added changes by Carina Jose on 06.07.2020
      SELECT low
        INTO CORRESPONDING FIELDS OF TABLE it_tvarvc_wrks
          FROM tvarvc
          WHERE name = c_tvarvc_werks .

      SELECT low
        INTO CORRESPONDING FIELDS OF TABLE it_tvarvc_auart
          FROM tvarvc
          WHERE name = c_tvarvc_auart .
***** End of changes by Carina Jose on 06.07.2020

      SELECT SINGLE bsart FROM ekko INTO v_auart
        WHERE ebeln = cs_goitem-ebeln.
      "
***** Added changes by Carina Jose on 06.07.2020
      READ TABLE  it_tvarvc_wrks INTO wa_tvarvc_wrks WITH KEY low =  cs_goitem-werks.
      IF sy-subrc <> 0.
        READ TABLE  it_tvarvc_auart INTO  wa_tvarvc_auart WITH KEY low = v_auart.
        IF sy-subrc <> 0.
***** End of changes by Carina Jose on 06.07.2020
          "
*      IF cs_goitem-werks <> '1701' AND cs_goitem-werks <> '1702' AND  cs_goitem-werks <> '1703'  AND v_auart <> 'YUB3'  " Commented by Carina Jose on 06.07.2020
*         AND v_auart <> 'YUB4' AND v_auart <> 'ZUB1' AND v_auart <> 'ZUB4' AND v_auart <> 'ZUB2' AND v_auart <> 'ZUB3'. " Commented by Carina Jose on 06.07.2020
          IF v_belnr IS INITIAL.
            MESSAGE 'CUSTOM MIRO NOT DONE' TYPE 'E'.
          ENDIF.
        ENDIF.
      ENDIF. " Added by Carina Jose on 06.07.2020
      CLEAR : wa_tvarvc_wrks,wa_tvarvc_auart.
    ENDIF.



*by KPIT/BIRLASOFT:rajni(135402): 30/03/2019
    DATA: lw_bapiret2_att  TYPE bapiret2.
    IF cs_goitem-bwart = '101' AND cs_goitem-werks IS NOT INITIAL AND cs_goitem-lgort IS NOT INITIAL
        AND cs_goitem-matnr IS NOT INITIAL AND i_line_id IS NOT INITIAL
        AND cs_goitem-take_it IS NOT INITIAL.
*      CLEAR : ls_bapiret.
      SELECT SINGLE werks,lgort FROM t320 INTO @DATA(wa_t320)
                                     WHERE werks = @cs_goitem-werks "goitem-werks
                                      AND lgort = @cs_goitem-lgort." goitem-lgort.
      IF sy-subrc <> 0.
        SELECT SINGLE werks, lgort, lgnum
                             FROM zwm_mat_valid INTO @DATA(wa_zwm_mat_valid)
                                     WHERE werks = @cs_goitem-werks "goitem-werks
                                      AND lgort = @cs_goitem-lgort." goitem-lgort.
        IF sy-subrc = 0.
          SELECT SINGLE matnr, lgnum FROM mlgn INTO @DATA(wa_mlgn)
                                         WHERE matnr = @cs_goitem-matnr AND  "@goitem-matnr AND
                                         lgnum = @wa_zwm_mat_valid-lgnum.
          IF sy-subrc = 0.
*    clear gt_bapiret2_att.
            IF gt_bapiret2_att IS NOT INITIAL.
              READ TABLE gt_bapiret2_att TRANSPORTING NO FIELDS WITH KEY message_v4 = cs_goitem-matnr message_v3 = i_line_id .
              IF sy-subrc = 0.
                DELETE gt_bapiret2_att  WHERE message_v4 = cs_goitem-matnr AND message_v3 = i_line_id .
              ENDIF.
            ENDIF.
            CLEAR:lw_bapiret2_att.
            lw_bapiret2_att-type       = 'E'.
            lw_bapiret2_att-id         = 'ZMM'.
            lw_bapiret2_att-number     = '035'.
            lw_bapiret2_att-message_v4 = cs_goitem-matnr.
            lw_bapiret2_att-message_v3 = i_line_id.
            APPEND lw_bapiret2_att TO gt_bapiret2_att.
          ELSE.
            IF gt_bapiret2_att IS NOT INITIAL.
              READ TABLE gt_bapiret2_att TRANSPORTING NO FIELDS WITH KEY message_v4 = cs_goitem-matnr  message_v3 = i_line_id .
              IF sy-subrc = 0.
                DELETE gt_bapiret2_att  WHERE message_v4 = cs_goitem-matnr AND message_v3 = i_line_id.
              ENDIF.
            ENDIF.
          ENDIF.
        ELSE.
          IF gt_bapiret2_att IS NOT INITIAL.
            READ TABLE gt_bapiret2_att TRANSPORTING NO FIELDS WITH KEY message_v4 = cs_goitem-matnr message_v3 = i_line_id.
            IF sy-subrc = 0.
              DELETE gt_bapiret2_att  WHERE message_v4 = cs_goitem-matnr AND message_v3 = i_line_id.
            ENDIF.
          ENDIF.
        ENDIF.
      ELSE.
        IF gt_bapiret2_att IS NOT INITIAL.
          READ TABLE gt_bapiret2_att TRANSPORTING NO FIELDS WITH KEY message_v4 = cs_goitem-matnr message_v3 = i_line_id.
          IF sy-subrc = 0.
            DELETE gt_bapiret2_att  WHERE message_v4 = cs_goitem-matnr AND message_v3 = i_line_id.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
*by KPIT/BIRLASOFT:rajni(135402): 30/03/2019




  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~MAA_LINE_ID_ADJUST.
  endmethod.


  METHOD if_ex_mb_migo_badi~mode_set.
* i_action:
* A01 = Goods receipt
* A02 = Return delivery
* A03 = Cancellation
* A04 = Display
* A05 = Release GR bl.st.
* A06 = Subsequent deliv.
* A07 = Goods issue
*
* i_refdoc:
* R01 = Purchase order
* R02 = Material document
* R03 = Delivery note
* R04 = Inbound delivery
* R05 = Outbound delivery
* R06 = Transport
* R07 = Transport ID code
* R08 = Order
* R09 = Reservation
* R10 = Other GR
    CLEAR gv_display.
    gv_action = i_action.
    " Set the flag to 'X' for display or cancel modes
    IF i_action = 'A03' OR i_action = 'A04'.
      gv_display = 'X'.
    ENDIF.



********** Retrofit Code*****************
* ACTION and REFDOC will discribe the mode of transaction MIGO.
* ----------------------------------------------------------------------
* i_action:
* A01 = Goods receipt
* A02 = Return delivery
* A03 = Cancellation
* A04 = Display
* A05 = Release GR bl.st.
* A06 = Subsequent deliv.
* A07 = Goods issue
*
* i_refdoc:
* R01 = Purchase order
* R02 = Material document
* R03 = Delivery note
* R04 = Inbound delivery
* R05 = Outbound delivery
* R06 = Transport
* R07 = Transport ID code
* R08 = Order
* R09 = Reservation
* R10 = Other GR
*-----------------------------------------------------------------------

* In case of 'DISPLAY' the global field G_NO_INPUT will be set to 'X'.
* The result is that a different external subscreen will be choosen in
* method PBO_DETAIL.

* In case of 'CANCEL' the global field G_CANCEL will be set to 'X'.
* The result is that in method POST_DOCUMENT a different handling is
* used
    CLEAR: g_no_input,g_cancel.
    IF i_action = 'A04' OR i_action = 'A03'.
      g_no_input = 'X'.
    ENDIF.
    IF i_action = 'A03'.
      g_cancel = 'X'.
    ENDIF.
    IF i_refdoc = 'R05' AND i_action = 'A01'.
      g_check = 'X'.
    ELSE.
      CLEAR: g_check.
    ENDIF.

    IF i_refdoc = 'R01' AND i_action = 'A01'.
      g_check = 'X'.
    ELSE.
      CLEAR: g_check.
    ENDIF.



  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~PAI_DETAIL.
  endmethod.


  METHOD if_ex_mb_migo_badi~pai_header.
    DATA: gv_zzgat    TYPE zde_zzgat,
          ls_godynpro TYPE godynpro.

    FIELD-SYMBOLS: <fs_godynpro> TYPE godynpro.

    IF g_no_input IS INITIAL AND g_cancel IS INITIAL.
      IF gv_werks IS NOT INITIAL.
        CALL FUNCTION 'ZFM_GET_DATA_MIGO'
          EXPORTING
            i_zzgat = gv_zzgat
            i_werks = gv_werks.
        ENDIF.
    ELSE.
      IF is_gohead-mblnr IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*        SELECT SINGLE zzgat
*          FROM zgate_header
*            INTO gv_zzgat
*              WHERE mblnr = is_gohead-mblnr
*                AND mjahr = is_gohead-mjahr.
        SELECT zzgat
          FROM zgate_header
            INTO gv_zzgat UP TO 1 ROWS
              WHERE mblnr = is_gohead-mblnr
                AND mjahr = is_gohead-mjahr ORDER BY PRIMARY KEY.
        ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

      ELSE.
        ASSIGN ('(SAPLMIGO)GODYNPRO') TO <fs_godynpro>.
        IF <fs_godynpro> IS ASSIGNED.
          ls_godynpro = <fs_godynpro>.
        ENDIF.
        IF ls_godynpro-mat_doc IS NOT INITIAL .
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*          SELECT SINGLE zzgat
*            FROM zgate_header
*              INTO gv_zzgat
*                WHERE mblnr = ls_godynpro-mat_doc
*                  AND mjahr = ls_godynpro-doc_year.
          SELECT zzgat
            FROM zgate_header
              INTO gv_zzgat UP TO 1 ROWS
                WHERE mblnr = ls_godynpro-mat_doc
                  AND mjahr = ls_godynpro-doc_year ORDER BY PRIMARY KEY.
          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
        ENDIF.
      ENDIF.

      CALL FUNCTION 'ZFM_GET_DATA_MIGO'
        EXPORTING
          i_zzgat = gv_zzgat
          i_werks = gv_werks.

    ENDIF.


  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~PBO_DETAIL.
  endmethod.


  METHOD if_ex_mb_migo_badi~pbo_header.
    CHECK sy-tcode = 'MIGO'.
    CHECK i_class_id = gv_class_id.

****    e_cprog   = 'SAPLZFG_MIGO_EXT'.
****    e_dynnr   = '0100'.
****    e_heading = 'MIGO Custom Fields'.

*    " Pass the Display flag to the function module
****    CALL FUNCTION 'ZFM_MIGO_SET_FIELD'
****      EXPORTING
****        iv_display = gv_display.


*****    Retrofit Code ***********
    CHECK i_class_id = gf_class_id.
    CHECK sy-tcode = 'MIGO'.
    e_cprog   = 'SAPLZFG_MIGO_HEADER'.
    e_dynnr   = '9100'.                     "External fields: Input
    e_heading = 'Custom Fields'.

    " For Additional Text
    CALL FUNCTION 'ZFM_MIGO_SET_FIELD1'
      EXPORTING
        iv_display = gv_display.

    CALL FUNCTION 'ZFM_SET_DATA_GATE'
      EXPORTING
        g_no_input = g_no_input.
*********************
  ENDMETHOD.


  METHOD if_ex_mb_migo_badi~post_document.
****    CALL FUNCTION 'ZFM_MIGO_SET_HEADER_TEXT'
****      EXPORTING
****        iv_mblnr = is_mkpf-mblnr
****        iv_mjahr = is_mkpf-mjahr.
    " For Additional Text
    CALL FUNCTION 'ZFM_SET_DATA_GATE'
      EXPORTING
        iv_mblnr = is_mkpf-mblnr
        iv_mjahr = is_mkpf-mjahr.



***********Retrofit Code***********************

    DATA: gv_gate TYPE zde_zzgat,
          lw_mseg TYPE mseg.
    IF g_no_input IS INITIAL AND is_mkpf-mblnr IS NOT INITIAL.

      READ TABLE it_mseg INTO lw_mseg WITH KEY mblnr = is_mkpf-mblnr
                                               mjahr = is_mkpf-mjahr.

      CALL FUNCTION 'ZFM_GET_DATA_GATE'
        IMPORTING
          cs_gate = gv_gate.

      UPDATE zgate_header SET mblnr = is_mkpf-mblnr
                              mjahr = is_mkpf-mjahr
                          WHERE zzgat = gv_gate
*                            AND zzyear = lw_mseg-gjahr
                            AND zzyear = lw_mseg-mjahr "added by parth
                            AND werks  = lw_mseg-werks.
    ENDIF.


***************add 15 sept
*    break sap_abap.

    DATA: gc_migo    TYPE sy-tcode VALUE 'MIGO',
          gc_migo_gr TYPE sy-tcode VALUE 'MIGO_GR'.

    DATA:lv_date1 TYPE d,
         lv_date2 TYPE d.
    DATA: lv_podat TYPE ekko-aedat,
          lv_ebeln TYPE ekko-ebeln,
          lv_ebelp TYPE mseg-ebelp,
          lv_gjahr TYPE mseg-gjahr,
          lv_mkpf  TYPE mseg-xblnr_mkpf.


    lv_date2 = is_mkpf-bldat.
    lv_date1 = is_mkpf-budat.

    lv_ebeln = lw_mseg-ebeln.
    lv_ebelp = lw_mseg-ebelp.
    lv_gjahr = lw_mseg-gjahr.

    CHECK sy-tcode EQ gc_migo OR sy-tcode EQ gc_migo_gr.

*    IF is_mkpf-bldat GT is_mkpf-budat.
    IF   lv_date2 GT lv_date1.
      MESSAGE TEXT-004 TYPE 'E'.
    ENDIF.

*    IF sy-datum LT is_mkpf-budat.
    IF sy-datum LT lv_date1.
      MESSAGE TEXT-005 TYPE 'E'.
    ENDIF.

    CLEAR : lv_podat.
    SELECT SINGLE aedat FROM ekko INTO lv_podat
                                  WHERE ebeln = lv_ebeln.
    IF sy-subrc = 0.
      IF lv_podat GT lv_date1.
        MESSAGE TEXT-003 TYPE 'E'.
      ENDIF.
    ENDIF.
*************add above 15 sept
****************    check
*    SELECT SINGLE xblnr_mkpf FROM mseg INTO lv_mkpf
*                                  WHERE lifnr = lw_mseg-lifnr AND
*                                        gjahr = lv_gjahr AND
*                                        xblnr_mkpf = lw_mseg-xblnr_mkpf .
*     IF SY-SUBRC = 0.
*      MESSAGE 'Delivery Note Already Processed' TYPE 'E'.
*    ENDIF.
**************

*By Mahir Maniar (APTL)

    TYPES:BEGIN OF ty_mail,
            mblnr          TYPE mblnr,
            ebeln          TYPE ebeln,
            matnr          TYPE matnr,
            menge          TYPE menge_d,
            dmbtr          TYPE dmbtr,
            meins          TYPE meins,
            budat_mkpf(10) TYPE c,
          END OF ty_mail.

    DATA: wa_mail TYPE ty_mail,
          it_mail TYPE TABLE OF ty_mail.

    DATA: lt_mailsubject     TYPE sodocchgi1.
    DATA: lt_mailrecipients  TYPE STANDARD TABLE OF somlrec90, " with header line,
          lwa_mailrecipients TYPE somlrec90.
*    DATA : lt_objpack type STANDARD TABLE OF sopcklsti1 .
    DATA : lt_objpack  TYPE STANDARD TABLE OF sopcklsti1,
           lwa_objpack TYPE sopcklsti1.
    DATA :        tab_lines          LIKE sy-tabix.


    DATA: lt_mailtxt  TYPE STANDARD TABLE OF soli, "      with header line.
          lwa_mailtxt TYPE soli.

    DATA:lv_group TYPE esart.
    DATA:string TYPE so_text255.
    DATA:lv_dmbtr(17) TYPE c.
    DATA:lv_menge(16) TYPE c.
    DATA:lv_maktx TYPE maktx.
    DATA:date(10) TYPE c.
    DATA : v_emailid TYPE somlreci1-receiver.
    DATA : v_emailid1 TYPE somlreci1-receiver.

    DATA l_sender TYPE soextreci1-receiver.
    CONSTANTS :c_tvarvc_mailsend     TYPE rvari_vnam VALUE 'ZSENDER_MAIL'.
    CONSTANTS :c_tvarvc_mailsend1     TYPE rvari_vnam VALUE 'ZASSETS_MAIL'.

*****************  for sender mail id.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low
*    INTO v_emailid
*    FROM tvarvc
*    WHERE name = c_tvarvc_mailsend.
    SELECT low
    INTO v_emailid
    FROM tvarvc UP TO 1 ROWS
    WHERE name = c_tvarvc_mailsend ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
***********   receiver mail id.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low
*    INTO v_emailid1
*    FROM tvarvc
*    WHERE name = c_tvarvc_mailsend1.
    SELECT low
    INTO v_emailid1
    FROM tvarvc UP TO 1 ROWS
    WHERE name = c_tvarvc_mailsend1 ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

***********************

    SELECT SINGLE bsart FROM ekko INTO lv_group
                                  WHERE ebeln = lv_ebeln.

    IF lv_group EQ 'CAPT'.


      LOOP AT it_mseg INTO lw_mseg.

        wa_mail-mblnr      = lw_mseg-mblnr.
        wa_mail-ebeln      = lw_mseg-ebeln.
        wa_mail-matnr      = lw_mseg-matnr.
        wa_mail-dmbtr      = lw_mseg-dmbtr.
        wa_mail-menge      = lw_mseg-menge.
        wa_mail-meins      = lw_mseg-meins.
        wa_mail-budat_mkpf = lw_mseg-budat_mkpf.
        APPEND wa_mail TO it_mail.
        CLEAR:wa_mail.

      ENDLOOP.

* Recipients
      lwa_mailrecipients-rec_type  = 'U'.
*      lwa_mailrecipients-receiver = 'insurance@astralpipes.com'.
      lwa_mailrecipients-receiver = v_emailid1.
      APPEND lwa_mailrecipients TO lt_mailrecipients.
      CLEAR lwa_mailrecipients .

*      CLEAR lwa_objpack-transf_bin.
*      lwa_objpack-transf_bin = 'SPACE'.
*      lwa_objpack-head_start = 1.
*      lwa_objpack-head_num = 0.
*      lwa_objpack-body_start = 1.
*      lwa_objpack-body_num = tab_lines.
*      lwa_objpack-doc_type = 'RAW'.
*      APPEND lwa_objpack to lt_objpack.
*      clear: lwa_objpack.

      l_sender  = v_emailid.
*
*      lwa_mailrecipients-rec_type  = 'U'.
*      lwa_mailrecipients-receiver = 'tarak.acharya@astralpipes.com'.
*      APPEND lwa_mailrecipients TO lt_mailrecipients.
*      CLEAR lwa_mailrecipients .

*      lwa_mailrecipients-rec_type  = 'U'.
*      lwa_mailrecipients-receiver = 'biren.parikh@astralpipes.com'.
*      APPEND lwa_mailrecipients TO lt_mailrecipients.
*      CLEAR lwa_mailrecipients .

* Subject.
      lt_mailsubject-obj_name = 'Asset MIGO Creation'.
      lt_mailsubject-obj_langu = sy-langu.
      lt_mailsubject-obj_descr = 'Asset MIGO Created'.

      DATA:str1(4) TYPE c,
           str2(2) TYPE c,
           str3(2) TYPE c.

      LOOP AT it_mail INTO wa_mail.

*  DATE = WA_MAIL-BUDAT_MKPF.

        str1 = wa_mail-budat_mkpf+0(4).
        str2 = wa_mail-budat_mkpf+4(2).
        str3 = wa_mail-budat_mkpf+6(2).

        CONCATENATE str3 str2 str1 INTO date SEPARATED BY '/'.

        AT FIRST.

          "Heading of the Mail

* Mail Contents
          string = 'Dear All,'.
          lwa_mailtxt = string.                                        "'This is a test mail'.
          APPEND lwa_mailtxt TO lt_mailtxt.
          CLEAR lwa_mailtxt.

* Mail Contents
          CONCATENATE 'Capital Item Received. on'  date '. This is for Insurance Consideration Purpose' INTO string SEPARATED BY ' '.
          lwa_mailtxt = string.                                       "'This is a test mail'.
          APPEND lwa_mailtxt TO lt_mailtxt.
          CLEAR lwa_mailtxt.

        ENDAT.

*Write Invoice Number Details Here

        SELECT SINGLE maktx FROM makt
                            INTO lv_maktx
                            WHERE matnr = wa_mail-matnr
                            AND spras EQ 'EN'.

        lv_dmbtr = wa_mail-dmbtr.
        lv_menge = wa_mail-menge.

        CONDENSE lv_dmbtr.
        CONDENSE lv_menge.

        CONCATENATE ' Doc. No.:'              wa_mail-mblnr
                    ' PO. No.:'               wa_mail-ebeln
                    ' Mat. Code. :'           wa_mail-matnr
                    ' Description:'           lv_maktx
                    ' Amount:'                lv_dmbtr
                    ' Quantity:'              lv_menge
                                              wa_mail-meins
                    INTO string SEPARATED BY ' '.


        CLEAR:wa_mail,lv_dmbtr,lv_maktx.

* Mail Contents
        lwa_mailtxt = string.                                         "'This is a test mail'.
        APPEND lwa_mailtxt TO lt_mailtxt.
        CLEAR lwa_mailtxt.

      ENDLOOP.

      DESCRIBE TABLE lt_mailtxt LINES tab_lines.
      READ TABLE lt_mailtxt ASSIGNING FIELD-SYMBOL(<fs_mailtxt>) INDEX tab_lines.
      lt_mailsubject-doc_size = ( tab_lines - 1 ) * 255 + strlen( <fs_mailtxt>-line ).
*      DATA(w_time)  = sy-uzeit.
*      DATA : w_time1(10).
*      w_time1 = w_time.

      CLEAR lwa_objpack-transf_bin.
      lwa_objpack-transf_bin = 'SPACE'.
      lwa_objpack-head_start = 1.
      lwa_objpack-head_num = 0.
      lwa_objpack-body_start = 1.
*      lwa_objpack-body_num = tab_lines.
      DESCRIBE TABLE lt_mailtxt LINES lwa_objpack-body_num.
      lwa_objpack-doc_type = 'RAW'.
      APPEND lwa_objpack TO lt_objpack.
      CLEAR: lwa_objpack.

      l_sender  = v_emailid.
************************* for add sender address new function module call
      CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
        EXPORTING
          document_data              = lt_mailsubject
          put_in_outbox              = 'X'
          sender_address             = l_sender
          sender_address_type        = 'INT'
          commit_work                = 'X'
*         IP_ENCRYPT                 =
*         IP_SIGN                    =
*         IV_VSI_PROFILE             =
* IMPORTING
*         SENT_TO_ALL                =
*         NEW_OBJECT_ID              =
*         SENDER_ID                  =
        TABLES
          packing_list               = lt_objpack
**         object_header              = lt_objhead
*         contents_bin               = lt_objbin
          contents_txt               = lt_mailtxt
*         CONTENTS_HEX               =
*         OBJECT_PARA                =
*         OBJECT_PARB                =
          receivers                  = lt_mailrecipients
*         ET_VSI_ERROR               =
        EXCEPTIONS
          too_many_receivers         = 1
          document_not_sent          = 2
          document_type_not_exist    = 3
          operation_no_authorization = 4
          parameter_error            = 5
          x_error                    = 6
          enqueue_error              = 7
          OTHERS                     = 8.

*      CALL FUNCTION 'SO_NEW_DOCUMENT_SEND_API1'
*        EXPORTING
*          document_data              = lt_mailsubject
*        TABLES
*          object_content             = lt_mailtxt
*          receivers                  = lt_mailrecipients
*        EXCEPTIONS
*          too_many_receivers         = 1
*          document_not_sent          = 2
*          document_type_not_exist    = 3
*          operation_no_authorization = 4
*          parameter_error            = 5
*          x_error                    = 6
*          enqueue_error              = 7
*          OTHERS                     = 8.
      IF sy-subrc EQ 0.
        COMMIT WORK.
*   Push mail out from SAP outbox
        SUBMIT rsconn01 WITH mode = 'INT' AND RETURN.


      ENDIF.

    ENDIF.




  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~PROPOSE_SERIALNUMBERS.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PUBLISH_MATERIAL_ITEM.
  endmethod.


  METHOD if_ex_mb_migo_badi~reset.
  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~STATUS_AND_HEADER.
  endmethod.
ENDCLASS.
