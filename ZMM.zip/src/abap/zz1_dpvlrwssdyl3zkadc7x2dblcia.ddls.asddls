@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_ADD3729945F1'

extend view I_SERVICEENTRYSHEETAPI01 with ZZ1_DPVLRWSSDYL3ZKADC7X2DBLCIA
  
{ 
  _ServiceEntrySheetExtension.ZZ1_DOCUMENTDATE_MDH as ZZ1_DOCUMENTDATE_MDH
}
