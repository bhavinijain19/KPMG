*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM11
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM11           .

  PERFORM TABLEPROC.

ENDFUNCTION.
