class ZCL_IM_MM_QANT_VALIDATION definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MB_MIGO_ITEM_BADI .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_QANT_VALIDATION IMPLEMENTATION.


  METHOD if_ex_mb_migo_item_badi~item_modify.
*    BREAK-POINT.
    DATA:lv_var TYPE menge_d.

*    IF sy-uname = 'SAP_ABAP1' AND is_goitem-bwart = '501'.
*
*      SELECT SINGLE verpr FROM mbew INTO @DATA(ls_mbew)
*         WHERE matnr = @is_goitem-matnr
*         AND bwkey = @is_goitem-bwkey
*         AND bwtar = @is_goitem-bwart.

*select SINGLE mtart FROM mara WHERE matnr = is_goitem-matnr
*
*      lv_var = is_goitem-menge * ls_mbew.
*
*      IF lv_var IS NOT INITIAL.
*
*        IF lv_var GE 100000.
*
*          MESSAGE 'Quantity is greater' TYPE 'E'.
*
*        ENDIF.
*
*      ENDIF.
*
*    ELSE.
*
*      MESSAGE 'You have no authorization' TYPE 'E'.
*
*    ENDIF.

  ENDMETHOD.
ENDCLASS.
