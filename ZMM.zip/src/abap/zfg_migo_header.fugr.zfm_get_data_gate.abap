FUNCTION ZFM_GET_DATA_GATE.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  EXPORTING
*"     REFERENCE(CS_GATE) TYPE  ZDE_ZZGAT
*"----------------------------------------------------------------------

cs_gate = gv_zzgat.

CLEAR: gv_zzgat.




ENDFUNCTION.
