@AbapCatalog.sqlViewName: 'ZSQLHDTOT'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'TotalConditionBaseValue'
@Metadata.ignorePropagatedAnnotations: true
define view Zcds_Header_Total_Base as select from Zcds_Item_Max_Base {
 key PurchaseOrder,
    sum( MaxBaseValue ) as TotalConditionBaseValue,
        sum( MinBaseValue ) as TotalConditionBaseValue_min
}group by PurchaseOrder
