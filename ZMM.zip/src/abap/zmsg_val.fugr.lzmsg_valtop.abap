FUNCTION-POOL ZMSG_VAL                   MESSAGE-ID SV.

* INCLUDE LZMSG_VALD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMSG_VALT00                            . "view rel. data dcl.
