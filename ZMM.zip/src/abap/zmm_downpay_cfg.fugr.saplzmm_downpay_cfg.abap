*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_DOWNPAY_CFGTOP.               " Global Declarations
  INCLUDE LZMM_DOWNPAY_CFGUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_DOWNPAY_CFGF...               " Subroutines
* INCLUDE LZMM_DOWNPAY_CFGO...               " PBO-Modules
* INCLUDE LZMM_DOWNPAY_CFGI...               " PAI-Modules
* INCLUDE LZMM_DOWNPAY_CFGE...               " Events
* INCLUDE LZMM_DOWNPAY_CFGP...               " Local class implement.
* INCLUDE LZMM_DOWNPAY_CFGT99.               " ABAP Unit tests
  INCLUDE LZMM_DOWNPAY_CFGF00                     . " subprograms
  INCLUDE LZMM_DOWNPAY_CFGI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
