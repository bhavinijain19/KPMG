@AbapCatalog.sqlViewAppendName: 'ZCLPURORITEM'
@EndUserText.label: ' I_PurchaseOrderItem'
extend view I_PurchaseOrderItem  with ZCL_PurchaseOrderItem
{
R_PurchasingDocumentItem.test,
R_PurchasingDocumentItem.KOSTL ,
R_PurchasingDocumentItem.SAKTO
}
