*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM6TOP.                      " Global Declarations
  INCLUDE LZFG_TVM6UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM6F...                      " Subroutines
* INCLUDE LZFG_TVM6O...                      " PBO-Modules
* INCLUDE LZFG_TVM6I...                      " PAI-Modules
* INCLUDE LZFG_TVM6E...                      " Events
* INCLUDE LZFG_TVM6P...                      " Local class implement.
* INCLUDE LZFG_TVM6T99.                      " ABAP Unit tests
  INCLUDE LZFG_TVM6F00                            . " subprograms
  INCLUDE LZFG_TVM6I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
