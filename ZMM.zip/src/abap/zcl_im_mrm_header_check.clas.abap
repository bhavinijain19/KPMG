class ZCL_IM_MRM_HEADER_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MRM_HEADER_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MRM_HEADER_CHECK IMPLEMENTATION.


  method IF_EX_MRM_HEADER_CHECK~HEADERDATA_CHECK.
  endmethod.
ENDCLASS.
