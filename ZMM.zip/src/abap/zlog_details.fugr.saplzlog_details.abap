*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZLOG_DETAILSTOP.                  " Global Declarations
  INCLUDE LZLOG_DETAILSUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZLOG_DETAILSF...                  " Subroutines
* INCLUDE LZLOG_DETAILSO...                  " PBO-Modules
* INCLUDE LZLOG_DETAILSI...                  " PAI-Modules
* INCLUDE LZLOG_DETAILSE...                  " Events
* INCLUDE LZLOG_DETAILSP...                  " Local class implement.
* INCLUDE LZLOG_DETAILST99.                  " ABAP Unit tests
  INCLUDE LZLOG_DETAILSF00                        . " subprograms
  INCLUDE LZLOG_DETAILSI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
