*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDEL_COORD
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDEL_COORD          .

  PERFORM TABLEPROC.

ENDFUNCTION.
