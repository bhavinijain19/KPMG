class ZCL_MMPUR_PO_WORKFLOW_RESTART definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_MMPUR_PO_WORKFLOW_RESTART .
protected section.
private section.
ENDCLASS.



CLASS ZCL_MMPUR_PO_WORKFLOW_RESTART IMPLEMENTATION.


  method IF_MMPUR_PO_WORKFLOW_RESTART~CHECK_PO_WORKFLOW_RESTART.
  endmethod.
ENDCLASS.
