*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZTMM_PO_WF_AGENTTOP.              " Global Declarations
  INCLUDE LZTMM_PO_WF_AGENTUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTMM_PO_WF_AGENTF...              " Subroutines
* INCLUDE LZTMM_PO_WF_AGENTO...              " PBO-Modules
* INCLUDE LZTMM_PO_WF_AGENTI...              " PAI-Modules
* INCLUDE LZTMM_PO_WF_AGENTE...              " Events
* INCLUDE LZTMM_PO_WF_AGENTP...              " Local class implement.
* INCLUDE LZTMM_PO_WF_AGENTT99.              " ABAP Unit tests
  INCLUDE LZTMM_PO_WF_AGENTF00                    . " subprograms
  INCLUDE LZTMM_PO_WF_AGENTI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
