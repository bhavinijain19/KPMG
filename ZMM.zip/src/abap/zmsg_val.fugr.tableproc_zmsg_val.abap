*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMSG_VAL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMSG_VAL            .

  PERFORM TABLEPROC.

ENDFUNCTION.
