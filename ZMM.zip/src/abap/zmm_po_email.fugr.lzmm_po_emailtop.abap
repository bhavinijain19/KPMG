FUNCTION-POOL ZMM_PO_EMAIL.                 "MESSAGE-ID ..

* INCLUDE LZMM_PO_EMAILD...                  " Local class definition
