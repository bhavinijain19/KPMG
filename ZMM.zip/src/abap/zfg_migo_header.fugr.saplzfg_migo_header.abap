*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_MIGO_HEADERTOP.               " Global Declarations
  INCLUDE LZFG_MIGO_HEADERUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_MIGO_HEADERF...               " Subroutines
* INCLUDE LZFG_MIGO_HEADERO...               " PBO-Modules
* INCLUDE LZFG_MIGO_HEADERI...               " PAI-Modules
* INCLUDE LZFG_MIGO_HEADERE...               " Events
* INCLUDE LZFG_MIGO_HEADERP...               " Local class implement.
* INCLUDE LZFG_MIGO_HEADERT99.               " ABAP Unit tests

INCLUDE lzfg_migo_headero01.

INCLUDE lzfg_migo_headeri01.
