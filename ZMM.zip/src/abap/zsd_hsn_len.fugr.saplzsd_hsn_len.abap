*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_HSN_LENTOP.                   " Global Data
  INCLUDE LZSD_HSN_LENUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_HSN_LENF...                   " Subroutines
* INCLUDE LZSD_HSN_LENO...                   " PBO-Modules
* INCLUDE LZSD_HSN_LENI...                   " PAI-Modules
* INCLUDE LZSD_HSN_LENE...                   " Events
* INCLUDE LZSD_HSN_LENP...                   " Local class implement.
* INCLUDE LZSD_HSN_LENT99.                   " ABAP Unit tests
  INCLUDE LZSD_HSN_LENF00                         . " subprograms
  INCLUDE LZSD_HSN_LENI00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
