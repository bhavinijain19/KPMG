FUNCTION-POOL ZMM_DOWNPAY_CFG            MESSAGE-ID SV.

* INCLUDE LZMM_DOWNPAY_CFGD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_DOWNPAY_CFGT00                     . "view rel. data dcl.
