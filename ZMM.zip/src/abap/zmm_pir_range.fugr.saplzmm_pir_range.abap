*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_PIR_RANGETOP.                 " Global Declarations
  INCLUDE LZMM_PIR_RANGEUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_PIR_RANGEF...                 " Subroutines
* INCLUDE LZMM_PIR_RANGEO...                 " PBO-Modules
* INCLUDE LZMM_PIR_RANGEI...                 " PAI-Modules
* INCLUDE LZMM_PIR_RANGEE...                 " Events
* INCLUDE LZMM_PIR_RANGEP...                 " Local class implement.
* INCLUDE LZMM_PIR_RANGET99.                 " ABAP Unit tests
  INCLUDE LZMM_PIR_RANGEF00                       . " subprograms
  INCLUDE LZMM_PIR_RANGEI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
