class ZCL_BADI_J_1IG_STO definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_BADI_J_1IG_STO .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BADI_J_1IG_STO IMPLEMENTATION.


  method IF_BADI_J_1IG_STO~ADD_MOVEMENT_TYPE.
  endmethod.


  method IF_BADI_J_1IG_STO~CHANGE_BEFORE_DISPLAY.
  endmethod.


  method IF_BADI_J_1IG_STO~CHANGE_BEFORE_POST.
        DATA :it_tvarvc TYPE TABLE OF tvarvc,
          wa_tvarvc TYPE tvarvc.

    DATA : s_vkorg_low TYPE char10.

    select single *
      from tvarvc
      into @data(ls_tvar)
      where name = 'ZJ1IGSTO_OPTAXCODE'.

    select single *
      from tvarvc
      into @data(ls_INP)
      where name = 'ZJ1IGSTO_IPTAXCODE'.


    SELECT *
    INTO TABLE it_tvarvc
    FROM tvarvc
    WHERE name = 'ZIND_J1IGSTO_INFO'
    AND type = 'S'.

    IF it_tvarvc IS INITIAL.
      MESSAGE 'No entry in TVARVC' TYPE 'E'.
    ENDIF.

    LOOP AT it_tvarvc INTO wa_tvarvc.

      s_vkorg_low = wa_tvarvc-low.

    ENDLOOP.

    IF s_vkorg_low IS NOT INITIAL.
      IF  sy-subrc = 0.
    ENDIF.

      LOOP AT t_bset INTO DATA(ts_bset).

*        IF ts_bset-mwskz = 'A0'.
        IF ts_bset-mwskz = LS_INP-low.
          READ TABLE t_accgl INTO DATA(ls_accgl) index sy-tabix.
          CHECK sy-subrc = 0.
*          ls_accgl-tax_code = 'V0'.
          ls_accgl-tax_code = ls_tvar-low.
           MODIFY t_accgl FROM ls_accgl INDEX sy-tabix TRANSPORTING tax_code .
        ELSE.
          SELECT SINGLE *
                    FROM ztax_inop
                    INTO @DATA(ls_tax)
                    WHERE mwskz_ip = @ts_bset-mwskz.
          CHECK sy-subrc = 0.
          READ TABLE t_accgl INTO ls_accgl INDEX sy-tabix.
          IF  ls_accgl-tax_code NE ls_tax-mwskz_op.
            ls_accgl-tax_code = ls_tax-mwskz_op. "-mwskz.
             MODIFY t_accgl FROM ls_accgl INDEX sy-tabix TRANSPORTING tax_code.
          ENDIF.
          READ TABLE t_tax INTO DATA(wa_tax) INDEX sy-tabix.
          IF  wa_tax-tax_code NE ls_tax-mwskz_op.
            wa_tax-tax_code = ls_tax-mwskz_op.
             MODIFY t_tax from wa_tax INDEX sy-tabix TRANSPORTING tax_code.
            endif.
          ENDIF.
        ENDLOOP.
        LOOP AT t_accgl into ls_accgl.
          check t_bset is INITIAL.

           ls_accgl-tax_code = ls_tvar-LOW.
           MODIFY t_accgl FROM ls_accgl INDEX sy-tabix TRANSPORTING tax_code .
        ENDLOOP.

      ENDIF.




*        ELSEIF IM_BSEG-MWSKZ is INITIAL .

*      MESSAGE 'No Tax code Found' TYPE 'E'.
*    ENDIF.

*    ENDIF.
*ENDIF.

*     DATA: wa_accgl      TYPE bapiacgl09,
*            wa_curr       TYPE bapiaccr09,
*            wa_tax        TYPE bapiactx09,
*            lv_tabix      TYPE sy-tabix,
*            lv_tabix_curr TYPE sy-tabix,
*            lv_amt        TYPE bapidoccur,
*            lv_base       TYPE bapiamtbase,
*            lv_upd        TYPE c.
*
*      LOOP AT t_tax INTO wa_tax WHERE cond_key = 'JIIG'.
*        IF sy-subrc = 0.
*          lv_tabix = sy-tabix.
*          READ TABLE t_curr INTO wa_curr WITH KEY itemno_acc = wa_tax-itemno_acc.
*          IF sy-subrc = 0.
*            lv_tabix_curr = sy-tabix.
*            READ TABLE t_accgl INTO wa_accgl WITH KEY itemno_tax = wa_tax-itemno_tax.
*            IF sy-subrc = 0.
*
*              lv_amt  = wa_curr-amt_doccur + lv_amt.
*              lv_base = wa_curr-amt_base + lv_base.
*              wa_curr-amt_doccur = 0.
*              wa_tax-gl_account = ''.
*              wa_tax-cond_key = 'JIIN'.
*              wa_tax-acct_key = 'NVV'.
*              lv_upd  = 'X'.
*              MODIFY t_tax  INDEX lv_tabix FROM wa_tax TRANSPORTING gl_account cond_key acct_key.
*              MODIFY t_curr INDEX lv_tabix_curr FROM wa_curr TRANSPORTING amt_doccur.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
*
****  Build new G/L line
*      IF lv_upd = 'X'.
*        CLEAR: wa_curr,
*               wa_accgl.
*
*        SORT t_curr DESCENDING BY itemno_acc.
*        SORT t_accgl DESCENDING BY itemno_tax.
*
*        READ TABLE t_curr INTO wa_curr INDEX 1.
*        READ TABLE t_accgl INTO wa_accgl INDEX 1.
*
*        IF sy-subrc = 0.
*          wa_accgl-itemno_acc = wa_curr-itemno_acc + 1.
*          wa_accgl-itemno_tax = wa_accgl-itemno_tax + 1.
*          wa_accgl-gl_account = '0015060103'.
*          APPEND wa_accgl TO t_accgl.
*
*          wa_curr-itemno_acc = wa_accgl-itemno_acc.
*          wa_curr-curr_type  = '00'.
*          wa_curr-currency   = 'INR'.
*          wa_curr-amt_doccur = lv_amt.
*          wa_curr-tax_amt    = 0.
*          wa_curr-amt_base   = lv_base.
*          APPEND wa_curr TO t_curr.
*
*        ENDIF.
*      ENDIF.
*
*      SORT t_curr  BY itemno_acc.
*      SORT t_accgl BY itemno_acc.
  endmethod.


  method IF_BADI_J_1IG_STO~CHANGE_TAX_CODE.
    DATA :it_tvarvc TYPE TABLE OF tvarvc,
      wa_tvarvc type tvarvc.

DATA : S_VKORG_LOW TYPE CHAR10.
*DATA : LV_V0 TYPE BSEG-mwskz VALUE 'V0'.

  SELECT SINGLE *
    FROM TVARVC
    INTO @DATA(LS_TVAR)
    WHERE NAME = 'ZJ1IGSTO_OPTAXCODE'.

  SELECT *
  INTO table it_tvarvc
  FROM tvarvc
  WHERE name = 'ZIND_J1IGSTO_INFO'
  and type = 'S'.

  IF it_tvarvc IS INITIAL.
    MESSAGE 'No entry in TVARVC' TYPE 'E'.
  ENDIF.

  loop at it_tvarvc INTO wa_tvarvc.

    S_VKORG_LOW = wa_tvarvc-low.

  endloop.

  IF S_VKORG_LOW IS NOT INITIAL.

  IF IM_BSEG-MWSKZ is not INITIAL .

        select single *
        from ZTAX_INOP
        into @data(ls_tax)
        where MWSKZ_IP = @IM_BSEG-MWSKZ.

        IF  sy-subrc = 0.
          CH_MWSKZ = ls_tax-mwskz_op.
        ENDIF.
*        ELSEIF IM_BSEG-MWSKZ is INITIAL .

*      MESSAGE 'No Tax code Found' TYPE 'E'.

ELSE .
         CH_MWSKZ = LS_TVAR-low.
    ENDIF.

  ENDIF.
  endmethod.
ENDCLASS.
