FUNCTION-POOL ZFG_TVM10                  MESSAGE-ID SV.

* INCLUDE LZFG_TVM10D...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM10T00                           . "view rel. data dcl.
