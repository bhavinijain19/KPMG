*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPLANT_COORDTOP.                  " Global Declarations
  INCLUDE LZPLANT_COORDUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPLANT_COORDF...                  " Subroutines
* INCLUDE LZPLANT_COORDO...                  " PBO-Modules
* INCLUDE LZPLANT_COORDI...                  " PAI-Modules
* INCLUDE LZPLANT_COORDE...                  " Events
* INCLUDE LZPLANT_COORDP...                  " Local class implement.
* INCLUDE LZPLANT_COORDT99.                  " ABAP Unit tests
  INCLUDE LZPLANT_COORDF00                        . " subprograms
  INCLUDE LZPLANT_COORDI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
