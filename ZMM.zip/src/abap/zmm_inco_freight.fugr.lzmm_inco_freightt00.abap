*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_INCO_FREIGHT................................*
DATA:  BEGIN OF STATUS_ZMM_INCO_FREIGHT              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_INCO_FREIGHT              .
CONTROLS: TCTRL_ZMM_INCO_FREIGHT
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_INCO_FREIGHT              .
TABLES: ZMM_INCO_FREIGHT               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
