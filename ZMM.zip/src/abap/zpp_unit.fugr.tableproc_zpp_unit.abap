*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_UNIT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_UNIT            .

  PERFORM TABLEPROC.

ENDFUNCTION.
