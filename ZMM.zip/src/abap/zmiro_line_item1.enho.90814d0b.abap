"Name: \PR:SAPLMR1M\FO:ZUORDNUNG_DURCHFUEHREN\SE:END\EI
ENHANCEMENT 0 ZMIRO_LINE_ITEM1.
*


  CHECK sy-tcode EQ 'MIRO' OR sy-tcode EQ 'MIR7'.
  FIELD-SYMBOLS : <fs_drseg> LIKE LINE OF ydrseg.
  DATA: lv_ktokk TYPE ktokk.


  READ TABLE ydrseg ASSIGNING <fs_drseg> INDEX 1.
  IF <fs_drseg> is ASSIGNED .
    SELECT SINGLE ktokk INTO lv_ktokk FROM lfa1 WHERE lifnr = <fs_drseg>-lifnr.
  ENDIF.
" """"""""""""change of begin 11-02-26""""""""""""""""

*  CHECK lv_ktokk eq 'ZDCU'.
*  CHECK lv_ktokk eq 'ZIMP'.
  CHECK lv_ktokk eq 'ZOTD'.
" """"""""""""end of begin 11-02-26""""""""""""""""
*  ASSIGN ('(SAPLFDCB)LFA1-KTOKK') to <fs_ktokk>.
    LOOP AT ydrseg ASSIGNING <fs_drseg>.
        <fs_drseg>-wrbtr = <fs_drseg>-netwr.
        <fs_drseg>-menge = <fs_drseg>-bsmng.
    ENDLOOP.
ENDENHANCEMENT.
