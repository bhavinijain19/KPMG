class ZCL_IM_MM_MATERIAL_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_EX_BADI_MATERIAL_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_MATERIAL_CHECK IMPLEMENTATION.


  method IF_EX_BADI_MATERIAL_CHECK~CHECK_CHANGE_MARA_MEINS.
  endmethod.


  method IF_EX_BADI_MATERIAL_CHECK~CHECK_CHANGE_PMATA.
  endmethod.


  METHOD if_ex_badi_material_check~check_data.
*&----------------------Development Details----------------------------*
*&--Enhancemnet      : ZCL_IM_MM_MATERIAL_CHECK                     ---*
*&--Package          : ZMM_ABAP                                     ---*
*&--Description      : Material Master Mandatory Views              ---*
*&--RICEF ID         : 3-1142                                       ---*
*&--Technical Owner  : Saurabh Saumya                               ---*
*&--Functional Owner : Sidhesh Rai                                  ---*
*&--TR No            : DEVK904194,DEVK906204                        ---*
*&---------------------------------------------------------------------*

    DATA: ls_mara TYPE mara,
          ls_mbew TYPE mbew,
          ls_mvke TYPE mvke.

    DATA: lv_val    TYPE string,
          lv_over   TYPE string,
          lv_origin TYPE string,
          lv_acc    TYPE string.

    ls_mara = wmara.
    ls_mbew = wmbew.
    ls_mvke = wmvke.

    "Accounting 1: Valuation Category mandatory for below material types
    IF ls_mbew IS NOT INITIAL AND ( ls_mara-mtart = 'FERT'
                            OR ls_mara-mtart = 'HALB' ).
*                            OR ls_mara-mtart = 'VERP' "Commented out
*                            OR ls_mara-mtart = 'ESRA'
*                            OR ls_mara-mtart = 'ROH'
*                            OR ls_mara-mtart = 'HAWA' ).
      IF ls_mbew-bwtty IS INITIAL.
        lv_acc = |Valuation Category is mandatory for { ls_mara-mtart } material type|.
        MESSAGE lv_acc TYPE 'E'.
      ENDIF.
    ENDIF.

*    "Costing 1: Overhead Group for FERT/HALB
*    IF ls_mbew IS NOT INITIAL AND ( ls_mara-mtart = 'FERT' OR ls_mara-mtart = 'HALB' ).
*      IF ls_mbew-kosgr IS INITIAL.
*        lv_over = |Overhead Group is mandatory for { ls_mara-mtart } in Valuation Area { ls_mbew-bwkey }|.
*        MESSAGE lv_over TYPE 'E'.
*      ENDIF.
*    ENDIF.
*
*    "Costing 1: Origin Group for ROH/VERP
*    IF ls_mbew IS NOT INITIAL AND ( ls_mara-mtart = 'ROH' OR ls_mara-mtart = 'VERP' ).
*      IF ls_mbew-hrkft IS INITIAL.
*        lv_origin = |Origin Group is mandatory for { ls_mara-mtart } in Valuation Area { ls_mbew-bwkey }|.
*        MESSAGE lv_origin TYPE 'E'.
*      ENDIF.
*    ENDIF.

    "Sales Org 2: Account Assignment Group for all mtaerial types
    IF ls_mvke IS NOT INITIAL AND ls_mara-mtart IS NOT INITIAL.
      IF ls_mvke-ktgrm IS INITIAL.
        lv_acc = |Account Assignment Group is mandatory for SalesOrg { ls_mvke-vkorg } / DC { ls_mvke-vtweg }|.
        MESSAGE lv_acc TYPE 'E'.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method IF_EX_BADI_MATERIAL_CHECK~CHECK_DATA_RETAIL.
  endmethod.


  method IF_EX_BADI_MATERIAL_CHECK~CHECK_MASS_MARC_DATA.
  endmethod.


  method IF_EX_BADI_MATERIAL_CHECK~FRE_SUPPRESS_MARC_CHECK.
  endmethod.
ENDCLASS.
