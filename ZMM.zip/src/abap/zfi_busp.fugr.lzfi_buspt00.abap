*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZFI_BUSP........................................*
DATA:  BEGIN OF STATUS_ZFI_BUSP                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_BUSP                      .
CONTROLS: TCTRL_ZFI_BUSP
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZFI_BUSP                      .
TABLES: ZFI_BUSP                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
