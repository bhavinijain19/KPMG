*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPP_UNIT........................................*
DATA:  BEGIN OF STATUS_ZPP_UNIT                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPP_UNIT                      .
CONTROLS: TCTRL_ZPP_UNIT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZPP_UNIT                      .
TABLES: ZPP_UNIT                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
