FUNCTION-POOL ZPLANT_COORD               MESSAGE-ID SV.

* INCLUDE LZPLANT_COORDD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPLANT_COORDT00                        . "view rel. data dcl.
