*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMSG_VALTOP.                      " Global Declarations
  INCLUDE LZMSG_VALUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMSG_VALF...                      " Subroutines
* INCLUDE LZMSG_VALO...                      " PBO-Modules
* INCLUDE LZMSG_VALI...                      " PAI-Modules
* INCLUDE LZMSG_VALE...                      " Events
* INCLUDE LZMSG_VALP...                      " Local class implement.
* INCLUDE LZMSG_VALT99.                      " ABAP Unit tests
  INCLUDE LZMSG_VALF00                            . " subprograms
  INCLUDE LZMSG_VALI00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
