FUNCTION-POOL ZDEL_COORD                 MESSAGE-ID SV.

* INCLUDE LZDEL_COORDD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDEL_COORDT00                          . "view rel. data dcl.
