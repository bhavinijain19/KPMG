FUNCTION-POOL ZFG_TVM9                   MESSAGE-ID SV.

* INCLUDE LZFG_TVM9D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM9T00                            . "view rel. data dcl.
