*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_SU_NUMBER
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_SU_NUMBER       .

  PERFORM TABLEPROC.

ENDFUNCTION.
