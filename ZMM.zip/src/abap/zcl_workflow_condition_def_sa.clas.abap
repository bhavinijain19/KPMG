class ZCL_WORKFLOW_CONDITION_DEF_SA definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_DEF .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKFLOW_CONDITION_DEF_SA IMPLEMENTATION.


  method IF_SWF_FLEX_IFS_CONDITION_DEF~GET_CONDITIONS.

  ct_condition = VALUE #(
            ( id = 1 subject = 'Department Name (Our Reference)' type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
            ( id = 2 subject = 'Plant'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
            ( id = 3 subject = 'Account Assignment'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
            ( id = 4 subject = 'Purchasing Group'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
               ).

  ct_parameter = VALUE #(
            ( id = 1 name = 'Department Name (Our Reference)'   xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string   mandatory = abap_true
            )
            ( id = 2 name = 'Plant'         xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true
             service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'Plant' )
            ( id = 3 name = 'Account Assignment'         xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true
            service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'AccAssgnmtCat'

            )
              ( id = 4 name = 'Purchasing Group'    xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true
            service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'PurchasingGroup'   )

               ).


  endmethod.
ENDCLASS.
