FUNCTION-POOL ZMM_GATE_SNRO              MESSAGE-ID SV.

* INCLUDE LZMM_GATE_SNROD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_GATE_SNROT00                       . "view rel. data dcl.
