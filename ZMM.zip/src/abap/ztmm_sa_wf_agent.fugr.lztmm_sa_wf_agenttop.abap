FUNCTION-POOL ZTMM_SA_WF_AGENT           MESSAGE-ID SV.

* INCLUDE LZTMM_SA_WF_AGENTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTMM_SA_WF_AGENTT00                    . "view rel. data dcl.
