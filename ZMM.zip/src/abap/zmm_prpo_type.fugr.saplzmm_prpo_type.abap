*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_PRPO_TYPETOP.                 " Global Declarations
  INCLUDE LZMM_PRPO_TYPEUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_PRPO_TYPEF...                 " Subroutines
* INCLUDE LZMM_PRPO_TYPEO...                 " PBO-Modules
* INCLUDE LZMM_PRPO_TYPEI...                 " PAI-Modules
* INCLUDE LZMM_PRPO_TYPEE...                 " Events
* INCLUDE LZMM_PRPO_TYPEP...                 " Local class implement.
* INCLUDE LZMM_PRPO_TYPET99.                 " ABAP Unit tests
  INCLUDE LZMM_PRPO_TYPEF00                       . " subprograms
  INCLUDE LZMM_PRPO_TYPEI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
