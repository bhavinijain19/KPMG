*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMAT_DESC.......................................*
DATA:  BEGIN OF STATUS_ZMAT_DESC                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMAT_DESC                     .
CONTROLS: TCTRL_ZMAT_DESC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMAT_DESC                     .
TABLES: ZMAT_DESC                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
