*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPLANT_COORD
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPLANT_COORD        .

  PERFORM TABLEPROC.

ENDFUNCTION.
