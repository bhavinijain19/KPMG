*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_EMAIL.......................................*
DATA:  BEGIN OF STATUS_ZMM_EMAIL                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_EMAIL                     .
CONTROLS: TCTRL_ZMM_EMAIL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_EMAIL                     .
TABLES: ZMM_EMAIL                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
