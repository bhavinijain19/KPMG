FUNCTION-POOL ZMM_VENDOR_SERV            MESSAGE-ID SV.

* INCLUDE LZMM_VENDOR_SERVD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_VENDOR_SERVT00                     . "view rel. data dcl.
