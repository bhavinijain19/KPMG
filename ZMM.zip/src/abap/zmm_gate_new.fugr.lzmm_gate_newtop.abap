FUNCTION-POOL ZMM_GATE_NEW.                 "MESSAGE-ID ..

* INCLUDE LZMM_GATE_NEWD...                  " Local class definition
