FUNCTION-POOL ZMM_EMAIL                  MESSAGE-ID SV.

* INCLUDE LZMM_EMAILD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_EMAILT00                           . "view rel. data dcl.
