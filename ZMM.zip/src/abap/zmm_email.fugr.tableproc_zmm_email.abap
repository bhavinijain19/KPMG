*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_EMAIL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_EMAIL           .

  PERFORM TABLEPROC.

ENDFUNCTION.
