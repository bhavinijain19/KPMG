class ZCL_MIRO_DATA_INSRT definition
  public
  final
  create public .

public section.

  methods INSERT_DATA
    importing
      value(BELNR) type BELNR_D
      value(GJAHR) type GJAHR
      value(EBELN) type EBELN
      value(WERKS) type WERKS_D
      value(REF_NO) type CHAR10
    exporting
      !PNR_ITM type ZMM_MIRO_PNR_ITM .
protected section.
private section.
ENDCLASS.



CLASS ZCL_MIRO_DATA_INSRT IMPLEMENTATION.


  METHOD insert_data.

    IF ref_no IS NOT INITIAL.
      pnr_itm-belnr = belnr.
      pnr_itm-gjahr = gjahr.
      pnr_itm-ebeln = ebeln.
      pnr_itm-werks = werks.
      pnr_itm-ref_num = ref_no.

      INSERT INTO zmm_miro_pnr_itm VALUES pnr_itm.

    ENDIF.

  ENDMETHOD.
ENDCLASS.
