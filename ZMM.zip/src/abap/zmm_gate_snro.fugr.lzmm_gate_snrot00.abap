*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_GATE_SNRO...................................*
DATA:  BEGIN OF STATUS_ZMM_GATE_SNRO                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_GATE_SNRO                 .
CONTROLS: TCTRL_ZMM_GATE_SNRO
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_GATE_SNRO                 .
TABLES: ZMM_GATE_SNRO                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
