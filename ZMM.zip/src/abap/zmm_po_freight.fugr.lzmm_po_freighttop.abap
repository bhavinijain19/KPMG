FUNCTION-POOL ZMM_PO_FREIGHT             MESSAGE-ID SV.

* INCLUDE LZMM_PO_FREIGHTD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_PO_FREIGHTT00                      . "view rel. data dcl.
