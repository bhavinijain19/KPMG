*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_VENDOR_SERVTOP.               " Global Declarations
  INCLUDE LZMM_VENDOR_SERVUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_VENDOR_SERVF...               " Subroutines
* INCLUDE LZMM_VENDOR_SERVO...               " PBO-Modules
* INCLUDE LZMM_VENDOR_SERVI...               " PAI-Modules
* INCLUDE LZMM_VENDOR_SERVE...               " Events
* INCLUDE LZMM_VENDOR_SERVP...               " Local class implement.
* INCLUDE LZMM_VENDOR_SERVT99.               " ABAP Unit tests
  INCLUDE LZMM_VENDOR_SERVF00                     . " subprograms
  INCLUDE LZMM_VENDOR_SERVI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
