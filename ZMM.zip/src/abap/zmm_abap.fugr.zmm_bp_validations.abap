FUNCTION zmm_bp_validations.
*****"----------------------------------------------------------------------
*****"*"Local Interface:
*****"----------------------------------------------------------------------
****  TYPES: BEGIN OF ty_cag,
****           low TYPE tvarv_val,
****         END OF ty_cag.
****
****  DATA: it_title TYPE STANDARD TABLE OF zsd_title_prefix,
****        wa_title TYPE zsd_title_prefix.
****
****  DATA: ls_lfa1_new TYPE lfa1,            " Vendor General Data (BP buffer)
****        ls_lfb1_new TYPE lfb1,            " Vendor Company Code Data (BP buffer)
****        lt_tax      TYPE TABLE OF dfkkbptaxnum,
****        ls_tax_gst  TYPE dfkkbptaxnum,
****        lv_panno    TYPE lfa1-j_1ipanno,
****        lv_gstn     TYPE bptaxnum.
****
****  DATA: it_cag      TYPE STANDARD TABLE OF ty_cag,
****        wa_cag      TYPE ty_cag,
****        ptitle(01),
****        len(10)     TYPE n,
****        lv_len(10)  TYPE n,
****        moff        TYPE i,
****        mlen        TYPE i,
****        s1          TYPE string,
****        s2          TYPE string,
****        lv_gstn_mid TYPE string.
****
****  DATA: lt_but0bk   TYPE TABLE OF but0bk,
****        ls_lfb1_old TYPE lfb1,
****        lv_partner  TYPE bu_partner.
****
****
****  DATA: ls_but000      TYPE but000,
****        lv_title_upper TYPE string.  " or TYPE string
****
****
****  CONSTANTS: c_cag_name TYPE rvari_vnam VALUE 'ZSD_INCLUDE_CAG', " Use ZMM_INCLUDE_CAG if you keep separate
****             c_bp_check TYPE rvari_vnam VALUE 'ZMM_BP_VALIDATION'.
****
****
****  "control complete validation using TVARVC field value
****
****
****  SELECT name , low
****    FROM tvarvc
****    INTO @DATA(ls_switch)
****     UP TO 1 ROWS WHERE name = @c_bp_check.
****  ENDSELECT.
****
****  IF ls_switch-low = 'X'.
****    "--------------------------------------------------------------------
****    " 1) Read BP buffer data (S/4HANA CVI FMs)
****    "--------------------------------------------------------------------
****    CALL FUNCTION 'CVIV_BUPA_LFA1_GET'
****      IMPORTING
****        e_lfa1 = ls_lfa1_new.
****
****    IF ls_lfa1_new-lifnr IS NOT INITIAL.
****
****      CALL FUNCTION 'CVIV_BUPA_LFB1_GET'
****        IMPORTING
****          e_lfb1 = ls_lfb1_new.
****
****      CALL FUNCTION 'BUP_BUPA_TAX_GET'
****        TABLES
****          et_tax              = lt_tax
****        EXCEPTIONS
****          no_taxnumbers_found = 1
****          OTHERS              = 2.
****      IF sy-subrc = 0.
****        READ TABLE lt_tax INTO DATA(ls_tax) INDEX 1.
****      ENDIF.
****
****
****      " Read live BP header buffer (reflects current screen edits)
****      CALL FUNCTION 'BUP_BUPA_BUT000_GET'
****        IMPORTING
****          e_but000 = ls_but000.
****
****
****      IF ls_but000-title IS NOT INITIAL.
****        "will get value as 0002, 0003 ... and so on
****        "get corresponding company value from sm30 maintainnance
****        DATA(lv_title_code) = ls_but000-title.
****        SELECT SINGLE title_medi
****          INTO @DATA(lv_title)
****          FROM zsd_title_prefix
****          WHERE title = @lv_title_code.
****
****        IF lv_title IS NOT INITIAL.
****          lv_title_upper = to_upper( lv_title ).
****        ENDIF.
****
****      ELSE.
****        lv_title_upper = to_upper( ls_lfa1_new-anred ).
****      ENDIF.
****
****
****      CALL FUNCTION 'BUP_BUPA_BUT0BK_GET'
****        TABLES
****          t_but0bk = lt_but0bk.
****
****      " If no vendor header buffer, nothing to validate
****      CHECK ls_lfa1_new IS NOT INITIAL.
****
****      "--------------------------------------------------------------------
****      "  Read inclusion vendor account groups from TVARVC
****      "    (apply Title/PAN checks only if vendor acc. group included)
****      "--------------------------------------------------------------------
****      SELECT low
****        FROM tvarvc
****        INTO CORRESPONDING FIELDS OF TABLE @it_cag
****        WHERE name = @c_cag_name.
****
****      " Titles table used to map Title -> expected 4th char (ZKEY) of PAN
****      SELECT *
****        FROM zsd_title_prefix
****        INTO TABLE @it_title.
****
****      "--------------------------------------------------------------------
****      "  Derive PAN & GSTIN
****      "--------------------------------------------------------------------
****      " PAN from LFA1
****      lv_panno = ls_lfa1_new-j_1ipanno.
****
****      " Try to pick GST from TAX table (taxtype = IN1). Fallback to 1st row.
****      READ TABLE lt_tax INTO ls_tax_gst WITH KEY taxtype = 'IN1'.
****      IF sy-subrc <> 0.
****        READ TABLE lt_tax INTO ls_tax_gst INDEX 1.
****      ENDIF.
****      IF sy-subrc = 0.
****        lv_gstn = ls_tax_gst-taxnum.
****      ENDIF.
****
****      "--------------------------------------------------------------------
****      "  If vendor account group is in include list – run PAN/Title checks
****      "--------------------------------------------------------------------
*****  READ TABLE it_cag INTO wa_cag WITH KEY low = ls_lfa1_new-ktokk.
*****  IF sy-subrc = 0.
****
****      " 4.a) PAN format check
****      IF lv_panno IS NOT INITIAL AND lv_panno <> ' '.
****        len = strlen( lv_panno ).
****
****        " Regex: 5 letters + 4 digits + 1 letter
****        FIND REGEX `[A-Z]{5}\d{4}[A-Z]{1}` IN lv_panno IGNORING CASE
****             MATCH OFFSET moff MATCH LENGTH mlen SUBMATCHES s1 s2.
****        IF sy-subrc NE 0.
****
****          CALL FUNCTION 'BUS_MESSAGE_STORE'
****            EXPORTING
****              arbgb = 'ZMM_MSGS'
****              msgty = 'E'
****              txtnr = '012'.  " Invalid PAN Pattern
****          EXIT.
****        ENDIF.
****
****        IF len <> 10.
****          CALL FUNCTION 'BUS_MESSAGE_STORE'
****            EXPORTING
****              arbgb = 'ZMM_MSGS'
****              msgty = 'E'
****              txtnr = '013'.  " Invalid PAN length
****          EXIT.
****        ENDIF.
****
****        " Title must match PAN (use the 4th PAN character logic from SD)
****        "      slices PAN from index 3 with length (len-6),
****        "      which effectively targets the 4th char for the mapping table.
****        IF it_title IS NOT INITIAL.
****          CLEAR: lv_len, ptitle.
****          lv_len = strlen( lv_panno ).
****          lv_len = lv_len - 6.
****          ptitle = lv_panno+3(lv_len). " Same as SD logic
****
*****        DATA(lv_anred_upper) = to_upper( ls_lfa1_new-anred ).
****
****          READ TABLE it_title INTO wa_title WITH KEY title_medi = lv_title_upper.
****          IF sy-subrc = 0.
****            IF ptitle <> wa_title-zkey.
****              CALL FUNCTION 'BUS_MESSAGE_STORE'
****                EXPORTING
****                  arbgb = 'ZMM_MSGS'
****                  msgty = 'E'
****                  txtnr = '014'.  " Title must match with PAN No.
****              EXIT.
****            ENDIF.
****          ENDIF.
****        ENDIF.
****
****        CLEAR: len, lv_len, ptitle, wa_title.
****      ENDIF.
****
*****  ENDIF. " vendor acc group in include list
****
****      "--------------------------------------------------------------------
****      " GSTIN validations (mandatory, format, length)
****      "     - Allow 'URP' (Unregistered Person) as in your SD logic
****      "--------------------------------------------------------------------
*****      IF lv_gstn IS NOT INITIAL.
*****        len = strlen( lv_gstn ).
*****
*****        IF lv_gstn <> 'URP'.
*****          " Regex: 2 digits + 5 letters + 4 digits + 1 letter + 1 alnum + 'Z' + 1 alnum
*****          FIND REGEX `\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}` IN lv_gstn
*****               IGNORING CASE MATCH OFFSET moff MATCH LENGTH mlen SUBMATCHES s1 s2.
*****          IF sy-subrc NE 0.
*****            CALL FUNCTION 'BUS_MESSAGE_STORE'
*****              EXPORTING
*****                arbgb = 'ZMM_MSGS'
*****                msgty = 'E'
*****                txtnr = '015'.  " Invalid GSTIN pattern
*****            EXIT.
*****          ENDIF.
*****
*****          IF len <> 15.
*****            CALL FUNCTION 'BUS_MESSAGE_STORE'
*****              EXPORTING
*****                arbgb = 'ZMM_MSGS'
*****                msgty = 'E'
*****                txtnr = '018'.  " Invalid GSTIN length
*****            EXIT.
*****          ENDIF.
*****        ENDIF.
*****
*****        CLEAR len.
*****      ELSE.
*****        " GSTIN Missing
******    CALL FUNCTION 'BUS_MESSAGE_STORE'
******      EXPORTING
******        arbgb = 'ZMM_MSGS'
******        msgty = 'E'
******        txtnr = '020'.    " Please Enter GSTIN No.
******    EXIT.
*****      ENDIF.
****
*****      CALL FUNCTION 'BUS_PARAMETERS_ISSTA_GET'
*****        TABLES
*****          t_rltyp = lt_roles.
*****
*****      IF lt_roles IS NOT INITIAL.
*****        READ TABLE lt_roles ASSIGNING FIELD-SYMBOL(<fs_roll>) INDEX 1.
*****        IF <fs_roll>-rltyp = 'FLCU00'.
****
****          "--------------------------------------------------------------------
****          " GSTIN vs PAN cross-check (GST[3..12] must equal PAN)
****          "--------------------------------------------------------------------
****          IF lv_gstn IS NOT INITIAL AND lv_panno IS NOT INITIAL AND lv_gstn <> 'URP'.
****            lv_len = strlen( lv_gstn ).
****            lv_len = lv_len - 5.           " 15 - 5 = 10
****            lv_gstn_mid  = lv_gstn+2(lv_len). " positions 3..12
****
****            IF lv_gstn_mid <> lv_panno.
****              CALL FUNCTION 'BUS_MESSAGE_STORE'
****                EXPORTING
****                  arbgb = 'ZMM_MSGS'
****                  msgty = 'E'
****                  txtnr = '017'.  " GST and PAN mismatch
****              EXIT.
****            ENDIF.
****          ENDIF.
****
*****        ENDIF.
*****      ENDIF.
****
****      "---> Bank Control Key Validation
*****    DATA : ls_lfb1_new TYPE lfb1.
****
****      CALL FUNCTION 'BUP_BUPA_BUT0BK_GET' TABLES t_but0bk = lt_but0bk.
****      CALL FUNCTION 'CVIV_BUPA_LFB1_GET' IMPORTING e_lfb1 = ls_lfb1_new.
****      IF lt_but0bk IS NOT INITIAL.
****        LOOP AT lt_but0bk ASSIGNING FIELD-SYMBOL(<fs_but0bk>).
****          IF ls_lfb1_new-bukrs = '1000' AND <fs_but0bk>-bkont <> 10.
****            CALL FUNCTION 'BUS_MESSAGE_STORE'
****              EXPORTING
****                arbgb = 'ZMM_MSGS'
****                msgty = 'E'
****                txtnr = '019'.
****            EXIT.
****          ELSEIF ls_lfb1_new-bukrs = '4000' AND <fs_but0bk>-bkont <> 40.
****            CALL FUNCTION 'BUS_MESSAGE_STORE'
****              EXPORTING
****                arbgb = 'ZMM_MSGS'
****                msgty = 'E'
****                txtnr = '020'.
****            EXIT.
****          ENDIF.
****        ENDLOOP.
****      ENDIF.
****      "---> GET OLD DATA FROM DATABASE
****      SELECT SINGLE lifnr, bukrs FROM lfb1 INTO @ls_lfb1_old WHERE lifnr = @lv_partner.
****      IF ls_lfb1_old-bukrs IS NOT INITIAL.
****        IF ls_lfb1_old-bukrs <> ls_lfb1_new-bukrs.
****          MESSAGE 'Please maintain Control key(90) if supplier is extended.' TYPE 'W'.
****        ENDIF.
****      ENDIF.
****
****    ENDIF.
****  ENDIF.
****
****  "--------------------------------------------------------------------
****  " 7) Bank Control Key validation by Company Code (BUT0BK vs LFB1)
****  "     - If BUKRS 1000 -> BKONT must be 10
****  "     - If BUKRS 4000 -> BKONT must be 40
****  "--------------------------------------------------------------------
*****  IF lt_but0bk IS NOT INITIAL AND ls_lfb1_new-bukrs IS NOT INITIAL.
*****    LOOP AT lt_but0bk ASSIGNING FIELD-SYMBOL(<fs_but0bk>).
*****      IF ls_lfb1_new-bukrs = '1000' AND <fs_but0bk>-bkont <> 10.
*****        CALL FUNCTION 'BUS_MESSAGE_STORE'
*****          EXPORTING
*****            arbgb = 'ZMM_MSGS'
*****            msgty = 'E'
*****            txtnr = '022'.  " Control Key mismatch for BUKRS 1000
*****        EXIT.
*****      ELSEIF ls_lfb1_new-bukrs = '4000' AND <fs_but0bk>-bkont <> 40.
*****        CALL FUNCTION 'BUS_MESSAGE_STORE'
*****          EXPORTING
*****            arbgb = 'ZMM_MSGS'
*****            msgty = 'E'
*****            txtnr = '023'.  " Control Key mismatch for BUKRS 4000
*****        EXIT.
*****      ENDIF.
*****    ENDLOOP.
*****  ENDIF.
****
****  "--------------------------------------------------------------------
****  " 8) Vendor extension warning: if vendor already existed with other BUKRS
****  "--------------------------------------------------------------------
*****  IF ls_lfb1_new-lifnr IS NOT INITIAL AND ls_lfb1_new-bukrs IS NOT INITIAL.
*****    " Find any existing company code other than the one being saved
*****    SELECT SINGLE lifnr bukrs
*****      FROM lfb1
*****      INTO CORRESPONDING FIELDS OF @ls_lfb1_old
*****      WHERE lifnr = @ls_lfb1_new-lifnr
*****        AND bukrs <> @ls_lfb1_new-bukrs.
*****
*****    IF sy-subrc = 0.
*****      " Keep same behavior as your SD FM (plain MESSAGE W). You could switch to BUS_MESSAGE_STORE if required.
*****      MESSAGE 'Please maintain Control key(90) if supplier is extended.' TYPE 'W'.
******     Alternative:
******     CALL FUNCTION 'BUS_MESSAGE_STORE'
******       EXPORTING
******         arbgb = 'ZMM_MSGS'
******         msgty = 'W'
******         txtnr = '024'.  " Create text in ZMM_MSGS for this warning
*****    ENDIF.
*****  ENDIF.

ENDFUNCTION.
