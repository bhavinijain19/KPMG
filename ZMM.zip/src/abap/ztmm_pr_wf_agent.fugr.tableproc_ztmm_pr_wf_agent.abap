*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTMM_PR_WF_AGENT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTMM_PR_WF_AGENT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
