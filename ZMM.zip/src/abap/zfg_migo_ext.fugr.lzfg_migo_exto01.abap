*----------------------------------------------------------------------*
***INCLUDE LZFG_MIGO_EXTO01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Module STATUS_0100 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0100 OUTPUT.
*  SET PF-STATUS 'STANDARD'. " Optional: Set an empty status for a subscreen
*  SET TITLEBAR 'T100'.     " Optional: Set an empty titlebar
  IF gv_display = 'X'.
    LOOP AT SCREEN.
      screen-input = '0'. "Disable input
      MODIFY SCREEN.
    ENDLOOP.
    IF gv_mblnr IS NOT INITIAL AND gv_mjahr IS NOT INITIAL.
      SELECT SINGLE zz1_header_text FROM zmm_migo_cf INTO gv_header_text
        WHERE mblnr = gv_mblnr
          AND mjahr = gv_mjahr.
    ENDIF.
  ELSE.
    LOOP AT SCREEN.
      screen-input = '1'. "Enable input
      MODIFY SCREEN.
    ENDLOOP.
    IF gv_first_fetch IS INITIAL AND gv_header_text IS INITIAL
      AND gv_mblnr IS NOT INITIAL AND gv_mjahr IS NOT INITIAL.
      SELECT SINGLE zz1_header_text FROM zmm_migo_cf INTO gv_header_text
        WHERE mblnr = gv_mblnr
          AND mjahr = gv_mjahr.

      gv_first_fetch = 'X'.         " Mark that initial load is complete
    ENDIF.
  ENDIF.
ENDMODULE.
