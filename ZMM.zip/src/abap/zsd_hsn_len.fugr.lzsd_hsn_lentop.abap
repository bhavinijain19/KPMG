FUNCTION-POOL ZSD_HSN_LEN                MESSAGE-ID SV.

* INCLUDE LZSD_HSN_LEND...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZSD_HSN_LENT00                         . "view rel. data dcl.
