*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_GATE_NEWTOP.                  " Global Declarations
  INCLUDE LZMM_GATE_NEWUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_GATE_NEWF...                  " Subroutines
* INCLUDE LZMM_GATE_NEWO...                  " PBO-Modules
* INCLUDE LZMM_GATE_NEWI...                  " PAI-Modules
* INCLUDE LZMM_GATE_NEWE...                  " Events
* INCLUDE LZMM_GATE_NEWP...                  " Local class implement.
* INCLUDE LZMM_GATE_NEWT99.                  " ABAP Unit tests
