*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDEL_COORD......................................*
DATA:  BEGIN OF STATUS_ZDEL_COORD                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDEL_COORD                    .
CONTROLS: TCTRL_ZDEL_COORD
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDEL_COORD                    .
TABLES: ZDEL_COORD                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
