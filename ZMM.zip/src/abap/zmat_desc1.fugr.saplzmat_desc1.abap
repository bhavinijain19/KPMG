*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMAT_DESC1TOP.                    " Global Data
  INCLUDE LZMAT_DESC1UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMAT_DESC1F...                    " Subroutines
* INCLUDE LZMAT_DESC1O...                    " PBO-Modules
* INCLUDE LZMAT_DESC1I...                    " PAI-Modules
* INCLUDE LZMAT_DESC1E...                    " Events
* INCLUDE LZMAT_DESC1P...                    " Local class implement.
* INCLUDE LZMAT_DESC1T99.                    " ABAP Unit tests
  INCLUDE LZMAT_DESC1F00                          . " subprograms
  INCLUDE LZMAT_DESC1I00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzmat_desc1f01.

INCLUDE lzmat_desc1f02.
