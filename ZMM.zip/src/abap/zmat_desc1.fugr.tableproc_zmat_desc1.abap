*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMAT_DESC1
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMAT_DESC1          .

  PERFORM TABLEPROC.

ENDFUNCTION.
