FUNCTION ZFM_GET_DATA_MIGO.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_ZZGAT) TYPE  ZDE_ZZGAT OPTIONAL
*"     REFERENCE(I_WERKS) TYPE  WERKS_D
*"----------------------------------------------------------------------

  IF i_zzgat IS NOT INITIAL.
    gv_zzgat = i_zzgat.
  ENDIF.
  gv_werks = i_werks.




ENDFUNCTION.
