*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_UNIT_AS56AS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_UNIT_AS56AS     .

  PERFORM TABLEPROC.

ENDFUNCTION.
