FUNCTION-POOL ZFG_VALMAP                 MESSAGE-ID SV.

* INCLUDE LZFG_VALMAPD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_VALMAPT00                          . "view rel. data dcl.
