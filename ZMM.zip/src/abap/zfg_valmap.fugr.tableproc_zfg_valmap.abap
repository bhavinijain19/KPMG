*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_VALMAP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_VALMAP          .

  PERFORM TABLEPROC.

ENDFUNCTION.
