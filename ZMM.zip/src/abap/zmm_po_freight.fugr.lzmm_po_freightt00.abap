*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_PO_FREIGHT..................................*
DATA:  BEGIN OF STATUS_ZMM_PO_FREIGHT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_PO_FREIGHT                .
CONTROLS: TCTRL_ZMM_PO_FREIGHT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_PO_FREIGHT                .
TABLES: ZMM_PO_FREIGHT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
