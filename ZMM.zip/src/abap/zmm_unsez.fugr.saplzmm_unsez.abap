*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_UNSEZTOP.                     " Global Declarations
  INCLUDE LZMM_UNSEZUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_UNSEZF...                     " Subroutines
* INCLUDE LZMM_UNSEZO...                     " PBO-Modules
* INCLUDE LZMM_UNSEZI...                     " PAI-Modules
* INCLUDE LZMM_UNSEZE...                     " Events
* INCLUDE LZMM_UNSEZP...                     " Local class implement.
* INCLUDE LZMM_UNSEZT99.                     " ABAP Unit tests
  INCLUDE LZMM_UNSEZF00                           . " subprograms
  INCLUDE LZMM_UNSEZI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
