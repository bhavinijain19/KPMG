*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_EMAILTOP.                     " Global Declarations
  INCLUDE LZMM_EMAILUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_EMAILF...                     " Subroutines
* INCLUDE LZMM_EMAILO...                     " PBO-Modules
* INCLUDE LZMM_EMAILI...                     " PAI-Modules
* INCLUDE LZMM_EMAILE...                     " Events
* INCLUDE LZMM_EMAILP...                     " Local class implement.
* INCLUDE LZMM_EMAILT99.                     " ABAP Unit tests
  INCLUDE LZMM_EMAILF00                           . " subprograms
  INCLUDE LZMM_EMAILI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
