"Name: \PR:SAPLMBWL\EX:EHP4_MB_CREATE_GOODS_MOVEME_01\EI
ENHANCEMENT 0 ZENHC_LSES_CUSTOM_FIELD.
IF line_exists( imseg[ 1 ] ).
  DATA(lv_ses) = imseg[ 1 ]-lfbnr.
  SELECT SINGLE zz1_documentdate_mdh, zz1_reference_mdh
      FROM mmpur_ses_header
      INTO @DATA(ls_custom_fields)
      WHERE serviceentrysheet = @lv_ses.
  IF ls_custom_fields IS NOT INITIAL.
    iimkpf-bldat = ls_custom_fields-zz1_documentdate_mdh. " Maps to Document Date
    iimkpf-xblnr = ls_custom_fields-zz1_reference_mdh.    " Maps to Reference/Material Slip
  ENDIF.
ENDIF.
ENDENHANCEMENT.
