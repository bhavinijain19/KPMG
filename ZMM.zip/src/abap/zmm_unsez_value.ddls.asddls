@AbapCatalog.sqlViewName: 'ZMMUNSEZ'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Base View exposing OurRef'
@VDM.viewType: #COMPOSITE
@ObjectModel.representativeKey: 'OurRef'
@Search.searchable: true

define view ZMM_UNSEZ_value as select from zmm_unsez
{
  @Search.defaultSearchElement: true
    key unsez as OurRef
}
