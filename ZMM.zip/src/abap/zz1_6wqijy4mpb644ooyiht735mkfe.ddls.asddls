@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_759B3712CD9F'

extend view I_SERVICEENTRYSHEETTP with ZZ1_6WQIJY4MPB644OOYIHT735MKFE
  
{ 
  _ServiceEntrySheetExtension.ZZ1_DOCUMENTDATE_MDH as ZZ1_DOCUMENTDATE_MDH
}
