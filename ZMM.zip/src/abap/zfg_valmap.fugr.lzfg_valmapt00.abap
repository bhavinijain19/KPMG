*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZVAL_MAP........................................*
DATA:  BEGIN OF STATUS_ZVAL_MAP                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVAL_MAP                      .
CONTROLS: TCTRL_ZVAL_MAP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZVAL_MAP                      .
TABLES: ZVAL_MAP                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
