*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_UNSEZ
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_UNSEZ           .

  PERFORM TABLEPROC.

ENDFUNCTION.
