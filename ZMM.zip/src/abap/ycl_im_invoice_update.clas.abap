class YCL_IM_INVOICE_UPDATE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_INVOICE_UPDATE .
protected section.
private section.
ENDCLASS.



CLASS YCL_IM_INVOICE_UPDATE IMPLEMENTATION.


  method IF_EX_INVOICE_UPDATE~CHANGE_AT_SAVE.
  endmethod.


  method IF_EX_INVOICE_UPDATE~CHANGE_BEFORE_UPDATE.
  endmethod.


  method IF_EX_INVOICE_UPDATE~CHANGE_IN_UPDATE.
  endmethod.
ENDCLASS.
