*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM9TOP.                      " Global Declarations
  INCLUDE LZFG_TVM9UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM9F...                      " Subroutines
* INCLUDE LZFG_TVM9O...                      " PBO-Modules
* INCLUDE LZFG_TVM9I...                      " PAI-Modules
* INCLUDE LZFG_TVM9E...                      " Events
* INCLUDE LZFG_TVM9P...                      " Local class implement.
* INCLUDE LZFG_TVM9T99.                      " ABAP Unit tests
  INCLUDE LZFG_TVM9F00                            . " subprograms
  INCLUDE LZFG_TVM9I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
