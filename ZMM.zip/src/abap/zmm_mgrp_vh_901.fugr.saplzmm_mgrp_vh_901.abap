*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_MGRP_VH_901TOP.               " Global Declarations
  INCLUDE LZMM_MGRP_VH_901UXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_MGRP_VH_901F...               " Subroutines
* INCLUDE LZMM_MGRP_VH_901O...               " PBO-Modules
* INCLUDE LZMM_MGRP_VH_901I...               " PAI-Modules
* INCLUDE LZMM_MGRP_VH_901E...               " Events
* INCLUDE LZMM_MGRP_VH_901P...               " Local class implement.
* INCLUDE LZMM_MGRP_VH_901T99.               " ABAP Unit tests
  INCLUDE LZMM_MGRP_VH_901F00                     . " subprograms
  INCLUDE LZMM_MGRP_VH_901I00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
