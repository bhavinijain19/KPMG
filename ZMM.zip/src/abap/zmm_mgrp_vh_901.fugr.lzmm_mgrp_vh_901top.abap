FUNCTION-POOL ZMM_MGRP_VH_901            MESSAGE-ID SV.

* INCLUDE LZMM_MGRP_VH_901D...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_MGRP_VH_901T00                     . "view rel. data dcl.
