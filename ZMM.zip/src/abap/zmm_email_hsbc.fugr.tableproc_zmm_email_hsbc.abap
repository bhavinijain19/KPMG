*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_EMAIL_HSBC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_EMAIL_HSBC      .

  PERFORM TABLEPROC.

ENDFUNCTION.
