*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM6
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM6            .

  PERFORM TABLEPROC.

ENDFUNCTION.
