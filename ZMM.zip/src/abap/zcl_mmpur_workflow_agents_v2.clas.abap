class ZCL_MMPUR_WORKFLOW_AGENTS_V2 definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_MMPUR_WORKFLOW_AGENTS_V2 .
protected section.
private section.

  methods GET_WRKFLW_DEF_THRU_CHILDNODE
    importing
      !CHILDREN type IF_SWF_FLEX_IFS_INST_BLOCK=>TT_COMPONENT optional
    returning
      value(WORKFLOW_TEXT) type STRING .
  methods PURCHASE_REQUISITION_AGENTS
    importing
      !PURCHASE_REQUISITION type BANFN
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !FLEXIBLE_WORKFLOW_NAME type STRING optional
      !PURCHASE_REQ_ITEM type BNFPO optional
    exporting
      !AGENTS type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_BADI_APPROVER .
  methods PURCHASE_ORDER_AGENTS
    importing
      !PURCHASE_ORDER type EBELN
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !FLEXIBLE_WORKFLOW_NAME type STRING optional
    exporting
      !AGENTS type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_BADI_APPROVER .
  methods GET_WRKFLW_DEF_THRU_XML
    importing
      !BUSINESSOBJECT type BUSINESSOBJECTTYPE
      !PURCHASINGDOCUMENT type PURCHASINGDOCUMENT
      !PURCHASINGDOCUMENTITEM type PURCHASINGDOCUMENTITEM
      !WORKFLOWSCENARIO type WORKFLOWSCENARIO
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !STEPINFO type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_S_BADI_STEPINFO
      !TASKTYPE type IF_MMPUR_WORKFLOW_AGENTS_V2=>TASKTYPE
    returning
      value(WORKFLOW_TEXT) type STRING .
  methods GET_WRKFLW_FLEX_DEF
    importing
      !BUSINESSOBJECT type BUSINESSOBJECTTYPE
      !PURCHASINGDOCUMENT type PURCHASINGDOCUMENT
      !PURCHASINGDOCUMENTITEM type PURCHASINGDOCUMENTITEM
      !WORKFLOWSCENARIO type WORKFLOWSCENARIO
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !STEPINFO type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_S_BADI_STEPINFO
      !TASKTYPE type IF_MMPUR_WORKFLOW_AGENTS_V2=>TASKTYPE
      !OBJ_IDEN type STRING
    returning
      value(WORKFLOW_TEXT) type STRING .
  methods PURCHASE_CONTRACT_AGENTS
    importing
      !PURCHASE_CONTRACT type VDM_PURCHASECONTRACT
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !FLEXIBLE_WORKFLOW_NAME type STRING optional
    exporting
      !AGENTS type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_BADI_APPROVER .
  methods SCHEDULING_AGREEMENT
    importing
      !SCHEDULING_AGREEMENT type VDM_PURCHASECONTRACT
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      value(FLEXIBLE_WORKFLOW_NAME) type STRING
    exporting
      !AGENTS type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_BADI_APPROVER .
  methods OBJECT_IDENTIFY
    importing
      !BUSINESSOBJECT type BUSINESSOBJECTTYPE
      !PURCHASINGDOCUMENT type PURCHASINGDOCUMENT
      !PURCHASINGDOCUMENTITEM type PURCHASINGDOCUMENTITEM
      !WORKFLOWSCENARIO type WORKFLOWSCENARIO
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      !STEPINFO type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_S_BADI_STEPINFO
      !TASKTYPE type IF_MMPUR_WORKFLOW_AGENTS_V2=>TASKTYPE
    returning
      value(OBJ_IDEN) type STRING .
  methods SERVICEENTRYSHEET
    importing
      !SERVICEENTRYSHEET type VDM_PURCHASECONTRACT
      !PREVIOUSAPPROVERLIST type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_PREVIOUS_APPROVER
      value(FLEXIBLE_WORKFLOW_NAME) type STRING
    exporting
      !AGENTS type IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_T_BADI_APPROVER .
ENDCLASS.



CLASS ZCL_MMPUR_WORKFLOW_AGENTS_V2 IMPLEMENTATION.


  method GET_WRKFLW_DEF_THRU_CHILDNODE.
       LOOP AT children ASSIGNING FIELD-SYMBOL(<fs_child>).
      DATA(status) =  <fs_child>->get_execution_status( ).

      IF <fs_child>->is_block_component( ).
        IF status NE 'CANCELLED'." 'STARTED' OR status = 'READY' .

          DATA: lo_block TYPE REF TO if_swf_flex_ifs_inst_block.
          lo_block ?= <fs_child>.

          DATA(title) = lo_block->get_block_title( ).
          workflow_text = title.
          EXIT.

        ENDIF.
      ENDIF.

    ENDLOOP.




  endmethod.


  method GET_WRKFLW_DEF_THRU_XML.
    DATA:
      lv_xml_steps   TYPE i,
      lv_log_steps   TYPE i,
      lv_scenario_id TYPE swd_wfd_id,
      lv_object_id   TYPE sibfboriid,
      ls_message     TYPE swf_t100ms.

    FIELD-SYMBOLS:
      <lt_log_buffer> TYPE swlloghist_t.
*--------------------------------------------------------------------*
    lv_object_id = purchasingdocument.
    "pt
  IF BUSINESSOBJECT CS 'PurchaseRequisition'.

lv_object_id = |{ purchasingdocument ALPHA = IN }| && |{ PURCHASINGDOCUMENTITEM ALPHA = IN }|.
    endif.
  "pt
    lv_scenario_id = workflowscenario.

    DATA(lo_wf_inst) = cl_swf_flex_def_factory=>wf_inst_handler( ).
    DATA(lt_instances) = lo_wf_inst->get_workflow_instances(
      EXPORTING
        iv_scenario_id = lv_scenario_id
        iv_appl_obj_id = lv_object_id
        iv_is_draft    = abap_false
        iv_context     = || ).

    SORT lt_instances BY workflow_id DESCENDING.
    READ TABLE lt_instances REFERENCE INTO DATA(ld_instance) INDEX 1.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE cx_swf_flex_ifs_exception.
    ENDIF.

    DATA(lo_ixml) = cl_ixml=>create( ).
    DATA(lo_stream_factory) = lo_ixml->create_stream_factory( ).
    DATA(lo_document) = lo_ixml->create_document( ).

    " parse xml-data into dom
    IF lo_ixml->create_parser(
      document = lo_document
      stream_factory = lo_stream_factory
      istream = lo_stream_factory->create_istream_xstring(
                      string = ld_instance->xmlresource ) )->parse( ) <> 0.

      RAISE EXCEPTION TYPE cx_swf_flex_ifs_exception.
    ENDIF.

    " iterate dom and count steps
    DATA(lo_process_flows_itr) = lo_document->create_iterator( ).
    lo_process_flows_itr->set_filter(
            lo_document->create_filter_name_ns( name = 'workflow' ) ).

    DATA(lo_process_flow) = lo_process_flows_itr->get_next( ).
    DATA(lo_activities_itr) = lo_process_flow->create_iterator( ).
    lo_activities_itr->set_filter(
            lo_document->create_filter_name_ns( name = 'subject' ) ).

    DATA(lo_activity) = lo_activities_itr->get_next( ).
    IF lo_activity->get_name( ) = 'subject'.
      workflow_text = lo_activity->get_value( ).
    ENDIF.

  ENDMETHOD.


  method GET_WRKFLW_FLEX_DEF.
       DATA: ls_appl_obj TYPE sibflporb,
          lv_context  TYPE string.

    DATA(lo_factory) = cl_swf_flex_ifs_factory=>get_instance(
      EXPORTING
        iv_language    = sy-langu
        iv_scenario_id = CONV #( workflowscenario )
    ).

        ls_appl_obj-instid = purchasingdocument.
    "pt
  IF BUSINESSOBJECT CS 'PurchaseRequisition'.

ls_appl_obj-instid = |{ purchasingdocument ALPHA = IN }| && |{ PURCHASINGDOCUMENTITEM ALPHA = IN }|.
    endif.
*    ls_appl_obj-instid = 100000014400010 " purchasingdocument(ALPHA=IN) PURCHASINGDOCUMENTITEM
*    DATA(mv_wiid) = lo_factory->get_workflow_id_by_context(
*                     iv_leading_object = ls_appl_obj iv_context = lv_context ).
    "--- Updated method in case of Mutiple instance - Ankur - 16/12/2024
    "pt
*    DATA(obj_iden) = ME->OBJECT_IDENTIFY(
*      EXPORTING
*        BUSINESSOBJECT         = BUSINESSOBJECT                  " Business Object Type
*        PURCHASINGDOCUMENT     = PURCHASINGDOCUMENT              " Purchasing Document Number
*        PURCHASINGDOCUMENTITEM = PURCHASINGDOCUMENTITEM          " Purchasing Document Item
*        WORKFLOWSCENARIO       = WORKFLOWSCENARIO                " Workflow Scenario
*        PREVIOUSAPPROVERLIST   = PREVIOUSAPPROVERLIST            " Previous Approver List
*        STEPINFO               = STEPINFO
*        TASKTYPE               = TASKTYPE
*                        ).

if obj_iden = 'PR' .
*  ls_appl_obj-catid = 'CL'.
*  ls_appl_obj-TYPEID = 'CL_MM_PUR_WF_OBJECT_PR_ITEM'.
       lv_context = 'PR_ITEM'.
       endif.




    "pt
    DATA(lt_wiid) = lo_factory->get_workflow_ids_by_context(
                     iv_leading_object = ls_appl_obj iv_context = lv_context ).
    sort: lt_wiid by wi_id DESCENDING.
    data(mv_wiid) = VALUE #( lt_wiid[ 1 ]-wi_id OPTIONAL ).
    "---end

    DATA(lo_runtime_handler) = lo_factory->get_runtime_handler( ).
    DATA(mo_workflow) = lo_runtime_handler->get_wf_instance(
                              iv_wf_id = mv_wiid ).

    DATA(lo_root_component) = mo_workflow->get_root_component( ).
    DATA(lt_children) = lo_root_component->get_childs( ).

    " resolve activities and blocks
*-- Checking whether workflow is retriggered or not .
    LOOP AT lt_children[] TRANSPORTING NO FIELDS
      WHERE table_line IS INSTANCE OF if_swf_flex_ifs_inst_block.
      DATA(lv_block_exists) = abap_true.
      EXIT.
    ENDLOOP.

    IF lv_block_exists = abap_true.
      " Get the workflow definition Name
      workflow_text = me->get_wrkflw_def_thru_childnode(
                            children = lt_children[] ).

    ELSE.
      " Get the workflow definition Name from XML.
      workflow_text = get_wrkflw_def_thru_xml(
                              EXPORTING
                                businessobject         = businessobject                 " Business Object Type
                                purchasingdocument     = purchasingdocument             " Purchasing Document Number
                                purchasingdocumentitem = purchasingdocumentitem         " Purchasing Document Item
                                workflowscenario       = workflowscenario               " Workflow Scenario
                                previousapproverlist   = previousapproverlist           " Previous Approver List
                                stepinfo               = stepinfo
                                tasktype               = tasktype
                            ).
    ENDIF.

  ENDMETHOD.


  METHOD if_mmpur_workflow_agents_v2~get_approvers.
    ""pt

    DATA: ls_badi_approver
            TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver,
          lt_badi_approver
           TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_t_badi_approver,
          ls_previous_approver
           TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_previous_approver,
          ls_new_approver
           TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver.

    DATA: lv_level        TYPE i,
          lv_previousstep TYPE i.
    "pt
    DATA(obj_iden) = me->object_identify(
  EXPORTING
    businessobject         = businessobject                  " Business Object Type
    purchasingdocument     = purchasingdocument              " Purchasing Document Number
    purchasingdocumentitem = purchasingdocumentitem          " Purchasing Document Item
    workflowscenario       = workflowscenario                " Workflow Scenario
    previousapproverlist   = previousapproverlist            " Previous Approver List
    stepinfo               = stepinfo
    tasktype               = tasktype
                    ).
    "pt
*-- Get the workflow Defination for the Agent determination
    DATA(lv_workflow_text) = me->get_wrkflw_flex_def(
      EXPORTING
        businessobject         = businessobject                  " Business Object Type
        purchasingdocument     = purchasingdocument              " Purchasing Document Number
        purchasingdocumentitem = purchasingdocumentitem          " Purchasing Document Item
        workflowscenario       = workflowscenario                " Workflow Scenario
        previousapproverlist   = previousapproverlist            " Previous Approver List
        stepinfo               = stepinfo
        tasktype               = tasktype
        obj_iden = obj_iden
                        ).

    IF businessobject CS 'PurchaseRequisition'.
      IF purchasingdocumentitem IS NOT INITIAL.
        SELECT SINGLE procurementhubsourcesystem
          FROM i_purchaserequisitionitemapi01
          INTO @DATA(lv_bck_sys)
          WHERE purchaserequisition = @purchasingdocument
          AND purchaserequisitionitem = @purchasingdocumentitem.
      ELSE.
        SELECT SINGLE procurementhubsourcesystem
          FROM i_purchaserequisitionitemapi01
          INTO @lv_bck_sys
          WHERE purchaserequisition = @purchasingdocument.
      ENDIF.
    ENDIF.

*If procurement hub source system is filled then it is hub scenario.
* coding for procurement hub scenario.
    IF lv_bck_sys IS NOT INITIAL.
      RAISE EXCEPTION TYPE cx_ble_runtime_error.
    ELSE.

      " The below code is for WF scenario.
      IF  businessobject CS 'PurchaseRequisition'.
        me->purchase_requisition_agents(
                         EXPORTING
                           purchase_requisition   = purchasingdocument              " Purchase Requisition Number
                           purchase_req_item   = purchasingdocumentitem              " Purchase Requisition Number
                           previousapproverlist   = previousapproverlist
                           flexible_workflow_name = lv_workflow_text
                         IMPORTING
                           agents                 = lt_badi_approver                " BAdI Approver List
                           ).
      ELSEIF businessobject CS 'PurchaseContract'.
        me->purchase_contract_agents(
          EXPORTING
            purchase_contract      = purchasingdocument                    "Purchasing Contract Header
            previousapproverlist   = previousapproverlist                  "Previous Approver List
            flexible_workflow_name = lv_workflow_text
          IMPORTING
            agents                 = lt_badi_approver                      "BAdI Approver List
        ).

      ELSEIF businessobject CS 'SchedulingAgreement'.
        me->scheduling_agreement(
          EXPORTING
            scheduling_agreement   = purchasingdocument                    "Purchasing Contract Header
            previousapproverlist   = previousapproverlist                  "Previous Approver List
            flexible_workflow_name = lv_workflow_text
          IMPORTING
            agents                 = lt_badi_approver                      "BAdI Approver List
            ).
      ELSEIF businessobject CS 'ServiceEntrySheet'.
        me->serviceentrysheet(
          EXPORTING
            serviceentrysheet   = purchasingdocument                    "Purchasing Contract Header
            previousapproverlist   = previousapproverlist                  "Previous Approver List
            flexible_workflow_name = lv_workflow_text
          IMPORTING
            agents                 = lt_badi_approver                      "BAdI Approver List
            ).

      ELSE.  "PurchaseOrder
        me->purchase_order_agents(
                        EXPORTING
                          purchase_order         = purchasingdocument               " Purchase order
                          previousapproverlist   = previousapproverlist             " Previous Approver List
                          flexible_workflow_name = lv_workflow_text
                        IMPORTING
                          agents                 = lt_badi_approver                 " BAdI Approver List
                            ).
      ENDIF.
    ENDIF.

**  remove the previous approvers from the list of BAdI approvers.
    LOOP AT previousapproverlist INTO ls_previous_approver.
      READ TABLE lt_badi_approver INTO ls_badi_approver
          WITH KEY businessuser = ls_previous_approver-businessuser.
      CHECK sy-subrc = 0.
      DELETE lt_badi_approver WHERE approvallevel = ls_badi_approver-approvallevel.
    ENDLOOP.

**  determine the next approval level and appropriate approvers
    READ TABLE lt_badi_approver INTO ls_badi_approver INDEX 1.
    LOOP AT lt_badi_approver INTO ls_new_approver
            WHERE approvallevel = ls_badi_approver-approvallevel.
      APPEND ls_new_approver-businessuser TO approverlist.
    ENDLOOP.





    ""pt

*    DATA:
*      LS_BADI_APPROVER TYPE IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_S_BADI_APPROVER.
*
*    IF stepinfo-currentstep = 1.
*      LS_BADI_APPROVER-BUSINESSUSER = '138394'."Sample user here, could be anyone...
*      LS_BADI_APPROVER-APPROVALLEVEL = 1.
*      APPEND LS_BADI_APPROVER TO APPROVERLIST.
*     LS_BADI_APPROVER-BUSINESSUSER = 'PARAG'."Sample user here, could be anyone...
*     LS_BADI_APPROVER-APPROVALLEVEL = 1.
*      APPEND LS_BADI_APPROVER TO APPROVERLIST.
*     endif.
*     IF stepinfo-currentstep = 2.
*
*      LS_BADI_APPROVER-BUSINESSUSER = 'SACHIN'."Sample user here, could be anyone...
*      LS_BADI_APPROVER-APPROVALLEVEL = 2.
*      APPEND LS_BADI_APPROVER TO APPROVERLIST.
*      LS_BADI_APPROVER-BUSINESSUSER = 'RITHVIK'."Sample user here, could be anyone...
*     LS_BADI_APPROVER-APPROVALLEVEL = 2.
*     APPEND LS_BADI_APPROVER TO APPROVERLIST.
*      endif.


  ENDMETHOD.


  method OBJECT_IDENTIFY.

       DATA: ls_appl_obj TYPE sibflporb,
          lv_context  TYPE string.



    ls_appl_obj-instid = purchasingdocument.

SELECT SINGLE banfn FROM eban
  into @data(lv_pr) WHERE banfn = @ls_appl_obj-instid.
    IF sy-subrc = 0.
      obj_iden = 'PR'.

    ENDIF.
 IF obj_iden IS INITIAL AND  lv_pr is INITIAL.
 SELECT SINGLE ebeln FROM ekko
    into @data(lv_po)
   WHERE ebeln = @ls_appl_obj-instid.
    IF sy-subrc = 0.
      obj_iden = 'PO'.
    ENDIF.
    ENDIF.



  endmethod.


  method PURCHASE_CONTRACT_AGENTS.
       DATA: LS_BADI_APPROVER
            TYPE IF_MMPUR_WORKFLOW_AGENTS_V2=>BD_MMPUR_S_BADI_APPROVER.
    DATA: LV_LEVEL TYPE I.
*-- Purchase Contract Workflow Agent
    SELECT SINGLE *
      FROM ZTMM_CT_WF_AGENT
      INTO @DATA(LS_PURCHASEREQUISITION_AGENT)
      WHERE WF_NAME = @FLEXIBLE_WORKFLOW_NAME.
    IF SY-SUBRC NE 0.
      RAISE EXCEPTION TYPE CX_BLE_RUNTIME_ERROR
        EXPORTING
          ERROR_MESSAGE       = 'Agent Determination Fail'
          IMPLEMENTATION_NAME = 'ZCL_MMPUR_WORKFLOW_AGENT'.
    ENDIF.
** define the list of BADI approvers for local scenario
    LV_LEVEL = LINES( PREVIOUSAPPROVERLIST ).

**  -----  Approval Level 1
    IF LV_LEVEL = 0.
      LS_BADI_APPROVER-BUSINESSUSER = LS_PURCHASEREQUISITION_AGENT-APPROVAL_LEVEL1.
      LS_BADI_APPROVER-APPROVALLEVEL = 1.
      APPEND LS_BADI_APPROVER TO AGENTS.

*  -----  Approval Level 2
    ELSEIF LV_LEVEL = 1.
      LS_BADI_APPROVER-BUSINESSUSER = LS_PURCHASEREQUISITION_AGENT-APPROVAL_LEVEL2.
      LS_BADI_APPROVER-APPROVALLEVEL = 2.
      APPEND LS_BADI_APPROVER TO AGENTS.

*  -----  Approval Level 3
    ELSEIF LV_LEVEL = 2.
      LS_BADI_APPROVER-BUSINESSUSER = LS_PURCHASEREQUISITION_AGENT-APPROVAL_LEVEL3.
      LS_BADI_APPROVER-APPROVALLEVEL = 3.
      APPEND LS_BADI_APPROVER TO AGENTS.

*  -----  Approval Level 4
    ELSEIF LV_LEVEL = 3.
      LS_BADI_APPROVER-BUSINESSUSER = LS_PURCHASEREQUISITION_AGENT-APPROVAL_LEVEL4.
      LS_BADI_APPROVER-APPROVALLEVEL = 4.
      APPEND LS_BADI_APPROVER TO AGENTS.
    ENDIF.
  ENDMETHOD.


  METHOD purchase_order_agents.
*&---------------------------------------------------------------------*
*       MODULE :    mm                                                   *
*----------------------------------------------------------------------*
*       Objective : CUSTOMER MASTER CREATE                             *
*       Program   : Updates Tables (   )     Downloads data (  )       *
*                   Outputs List   (   )                               *
*                                                                      *
*                                                                      *
*       Date Created :    26/02/2026                                             *
*       Instructed by:    junaid                                              *
*       Devloped by:    pruthva trivedi                                               *
*                                                                      *
*----------------------------------------------------------------------*
*       External Dependencies                                          *
*----------------------------------------------------------------------*
*                                                                      *
*----------------------------------------------------------------------*
* Amendment History                                                    *
*----------------------------------------------------------------------*
* Version Create/Change Owner     TR           CR/ID                   *
*......................................................................*
* <001>                                                                *
* Reason:                                                              *
*......................................................................*
* <002>                                                                *
* Reason:                                                              *
*----------------------------------------------------------------------*

    DATA: ls_badi_approver
         TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver.
    DATA: lv_level TYPE i.
    DATA:
      lt_values_1 TYPE STANDARD TABLE OF string,
      lt_values_2 TYPE STANDARD TABLE OF string,
      lt_values_3 TYPE STANDARD TABLE OF string,
      lt_values_4 TYPE STANDARD TABLE OF string,
      lt_values_5 TYPE STANDARD TABLE OF string,
      lt_values_6 TYPE STANDARD TABLE OF string,
      lt_values_7 TYPE STANDARD TABLE OF string.
*-- Purchase Order details
    SELECT SINGLE
        purchaseordertype,
        purgreleasetimetotalamount,
        purchasinggroup,
        correspncinternalreference,
        plant,
        conditionbasevalue,
     conditionbasevalue_min
      FROM zcds_pofinaldetail
      WHERE purchaseorder =  @purchase_order
      INTO @DATA(ls_purchaseorder_detail).

    IF ls_purchaseorder_detail-purchaseordertype  = 'ZRET'.
      SELECT SINGLE *
        FROM ztmm_po_wf_agent
        INTO @DATA(ls_purchaseorder_agent)
        WHERE wf_name = @flexible_workflow_name
        AND plant = @ls_purchaseorder_detail-plant
        AND purchasing_group = @ls_purchaseorder_detail-purchasinggroup
        AND doc_type = @ls_purchaseorder_detail-purchaseordertype
        AND our_reference = @ls_purchaseorder_detail-correspncinternalreference
        AND low_amt LE @ls_purchaseorder_detail-conditionbasevalue_min
        AND high_amt GE @ls_purchaseorder_detail-conditionbasevalue_min.
    ELSE.
      SELECT SINGLE *
     FROM ztmm_po_wf_agent
     INTO @ls_purchaseorder_agent
     WHERE wf_name = @flexible_workflow_name
     AND plant = @ls_purchaseorder_detail-plant
     AND purchasing_group = @ls_purchaseorder_detail-purchasinggroup
     AND doc_type = @ls_purchaseorder_detail-purchaseordertype
     AND our_reference = @ls_purchaseorder_detail-correspncinternalreference
     AND low_amt LE @ls_purchaseorder_detail-conditionbasevalue
     AND high_amt GE @ls_purchaseorder_detail-conditionbasevalue.
    ENDIF.
    IF sy-subrc NE 0.
      RAISE EXCEPTION TYPE cx_ble_runtime_error
        EXPORTING
          error_message       = 'Agent Determination Fail'
          implementation_name = 'ZCL_MMPUR_WORKFLOW_AGENT'.
    ENDIF.
*-- Define the list of BADI approvers for local scenario
    lv_level = lines( previousapproverlist ).
*-----  Approval Level 1
    IF lv_level = 0.
      SPLIT ls_purchaseorder_agent-approval_level1 AT ',' INTO TABLE lt_values_1.
      LOOP AT lt_values_1 INTO DATA(ls_value_1).
        ls_badi_approver-businessuser = ls_value_1."ls_purchaseorder_agent-approval_level1.
        ls_badi_approver-approvallevel = 1.
        APPEND ls_badi_approver TO agents.

      ENDLOOP.
*  -----  Approval Level 2
    ELSEIF lv_level = 1.
      SPLIT ls_purchaseorder_agent-approval_level2 AT ',' INTO TABLE lt_values_2.
      LOOP AT lt_values_2 INTO DATA(ls_value_2).
        ls_badi_approver-businessuser = ls_value_2.
        ls_badi_approver-approvallevel = 2.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.
*  -----  Approval Level 3
    ELSEIF lv_level = 2.

      SPLIT ls_purchaseorder_agent-approval_level3 AT ',' INTO TABLE lt_values_3.
      LOOP AT lt_values_3 INTO DATA(ls_value_3).
        ls_badi_approver-businessuser = ls_value_3.
        ls_badi_approver-approvallevel = 3.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

*  -----  Approval Level 4
    ELSEIF lv_level = 3.

      SPLIT ls_purchaseorder_agent-approval_level4 AT ',' INTO TABLE lt_values_4.
      LOOP AT lt_values_4 INTO DATA(ls_value_4).
        ls_badi_approver-businessuser = ls_value_4.
        ls_badi_approver-approvallevel = 4.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

*  -----  Approval Level 5
    ELSEIF lv_level = 4.
      SPLIT ls_purchaseorder_agent-approval_level5 AT ',' INTO TABLE lt_values_5.
      LOOP AT lt_values_5 INTO DATA(ls_value_5).
        ls_badi_approver-businessuser = ls_value_5.
        ls_badi_approver-approvallevel = 5.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

**  -----  Approval Level 6
    ELSEIF lv_level = 5.
      SPLIT ls_purchaseorder_agent-approval_level6 AT ',' INTO TABLE lt_values_6.
      LOOP AT lt_values_6 INTO DATA(ls_value_6).
        ls_badi_approver-businessuser = ls_value_6.
        ls_badi_approver-approvallevel = 6.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

    ELSEIF lv_level = 6.

      SPLIT ls_purchaseorder_agent-approval_level7 AT ',' INTO TABLE lt_values_7.
      LOOP AT lt_values_7 INTO DATA(ls_value_7).
        ls_badi_approver-businessuser = ls_value_7.
        ls_badi_approver-approvallevel = 7.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

    ENDIF.
    DATA : ls_addr   TYPE bapiaddr3,
           it_return TYPE TABLE OF bapiret2.

    DATA(agent) = agents[ 1 ]-businessuser.
    IF agent IS NOT INITIAL.

*      DATA(lv_user) = agent+2.
      IF agent IS NOT INITIAL.
        CALL FUNCTION 'BAPI_USER_GET_DETAIL'
          EXPORTING
            username = agent
          IMPORTING
            address  = ls_addr
          TABLES
            return   = it_return.
      ENDIF.


      TYPES: BEGIN OF ty_binary,
               line TYPE x LENGTH 255,         "Binary Data
             END OF ty_binary.

      DATA: lcl_v_wi_id     TYPE sww_wiid,  "Work Item ID
            lv_wid_read     TYPE sww_wiid,  "Work Item ID to read container data
            lv_wid_text     TYPE char12,
            l_it_father_wis TYPE STANDARD TABLE OF swwwihead,
            l_wa_father_wis TYPE swwwihead,
            send_request    TYPE REF TO cl_bcs,
            text            TYPE bcsy_text,
            body_text       TYPE so_text255,
            document        TYPE REF TO cl_document_bcs,
*          sender          TYPE REF TO cl_sapuser_bcs,
            sender          TYPE REF TO if_sender_bcs,
            recipient       TYPE REF TO if_recipient_bcs,
            bcs_exception   TYPE REF TO cx_bcs,
            sent_to_all     TYPE os_boolean,
            g_objcont       TYPE STANDARD TABLE OF ty_binary,
            lv_string       TYPE string,
            xhtml_string    TYPE xstring,
            t_hex           TYPE solix_tab.
* Declare the Work Item Container data
      DATA: l_it_wi_container TYPE STANDARD TABLE OF swcont,
            l_wa_wi_container TYPE swcont,
            l_wa_wi_header    TYPE swwwihead.
* Declaration for the Dynamic Values in text
      DATA: lv_belnr      TYPE belnr_d,
            lv_bukrs      TYPE bukrs,
            lv_gjahr      TYPE char04,
            lv_email      TYPE comm_id_long,
            lv_lines      TYPE i,
            lv_so_obj_len TYPE so_obj_len.

* Other e-mail technique to do the declarations
      DATA : it_message        TYPE STANDARD TABLE OF solisti1,
             wa_message        TYPE solisti1,
             it_attach         TYPE STANDARD TABLE OF solisti1,
             wa_attach         TYPE solisti1,
             t_receivers       TYPE STANDARD TABLE OF somlreci1,
             wa_receivers      TYPE somlreci1,
             w_doc_data        TYPE sodocchgi1,
             it_pdf            TYPE fpformoutput,
             w_subject(50)     TYPE c,
             lv_subject_c(255) TYPE c.

      DATA: lv_netwr     TYPE string,
            lv_zzgmv     TYPE string,
            lv_zzgmp     TYPE string,
            lv_overdue   TYPE string,
            lv_inventory TYPE string,
            l_zzgmp      TYPE p DECIMALS 2,
            lv_tgmp      TYPE string,
            lv_mgmp      TYPE string.

*      lv_wid_text = im_wid.
      "Order Details
*    BREAK-POINT.
*    SELECT SINGLE * FROM zcv_sales_order_details INTO @DATA(ls_order_det) WHERE vbeln = @im_vbeln.
**    "-----added by farhan.
*    SELECT SINGLE * FROM vbak INTO @DATA(ls_vbak) WHERE vbeln = @im_vbeln.
*    SELECT SINGLE * FROM vbkd INTO @DATA(ls_vbkd) WHERE vbeln = @im_vbeln.
*    IF sy-subrc  = 0.
*      SELECT SINGLE * FROM knb1 INTO @DATA(ls_knb1) WHERE kunnr = @ls_order_det-partner AND bukrs = @ls_vbak-bukrs_vf.
*      SELECT SINGLE * FROM t052u INTO @DATA(ls_T052U) WHERE   zterm = @ls_knb1-zterm AND spras = 'E'.
*    ENDIF.

      "Fiori Inbox link
*    SELECT SINGLE low FROM tvarvc INTO @DATA(lv_inb_link) WHERE name = 'ZSD_ORD_WF_FIORI_INBOXLINK'.
*                             -*
      TRY.
*         create persistent send request
          send_request = cl_bcs=>create_persistent( ).
* Start the Mail Body
          lv_string = |<html><body>Dear Approver<br><br>|.
          DATA(lv_vbeln) = purchase_order.
          SHIFT lv_vbeln LEFT DELETING LEADING '0'.
          lv_string = |{ lv_string }The Purchase Order { lv_vbeln } is under  approval status kindly check for any deviations and Approve or Reject the same accordingly.|.
*          lv_string = |{ lv_string }To intimate the below Purchase Order  is pending for approval|.
*        lv_string = |{ lv_string }. <br><br><font size="1">|.
*        lv_string = |{ lv_string }<table border = "1" bgcolor = "skyblue">|.
*        lv_string = |{ lv_string }<tr><th>End customer Name</th><th>OEM Name</th><th>Sales District</th><th>Sales Office</th></tr>|.
**          lv_string = |{ lv_string }<tr><th>Partner Name</th><th>End customer Name</th><th>OEM Name</th><th>Top line Value</th>|.
**        lv_string = |{ lv_string }<th>GM Value</th><th>Actual GM%</th><th>Target GM%</th><th>SO Payment Terms</th><th>Standard Payment Terms</th><th>Channel Type</th></tr>|.
**        lv_string = |{ lv_string }<th>GM Value</th><th>Actual GM%</th><th>Target GM%</th><th>Avg. MIS GM %</th><th>SO Payment Terms</th><th>Standard Payment Terms</th></tr>|.
*        lv_string = |{ lv_string }<tr><td>{ ls_order_det-name2 }</td><td>{ ls_order_det-name3 }</td><td>{ ls_vbkd-bzirk }</td><td>{ ls_vbak-vkbur }</td>|.
**          lv_string = |{ lv_string }</td><td>{ lv_zzgmp }</td><td>{ lv_tgmp }</td><td>{ lv_mgmp }</td><td>{ ls_order_det-zterm }</td><td>{ ls_T052U-text1 }</td>|. "{ ls_order_det-zterm_bp }</td>|. soc by farhan
*        lv_string = |{ lv_string }</td></tr></table><br>|.
*        lv_string = |{ lv_string }<table border = "1" bgcolor = "skyblue">|.
*          lv_string = |{ lv_string }<tr><th>Credit Location</th><th>Overdue Amount</th><th>Inventory Value</th><th>Vertical Account Type</th><th>Channel Type</th></tr>|.
*          lv_string = |{ lv_string }<tr><td>{ ls_order_det-creloc }</td><td>{ lv_overdue }</td><td>{ lv_inventory }</td><td>{ ls_order_det-vert_acct }</td><td>{ ls_order_det-channel }</td></table>|.
*        *    ***** Genrate the Dynamic MAILTO Links
*        lv_string = |{ lv_string }</font><br>To process directly from e-mail, make your selection here  <a href="mailto:ivaluesap@ivalue.co.in?subject=A|.
*        lv_string = |{ lv_string }</font><br>To approve directly from e-mail, click <a href="mailto:ivaluesap@ivalue.co.in?subject=A|.
*        lv_string = |{ lv_string }{ lv_wid_text }{ sy-sysid }_MAIL   approve document">Approve  </a></br>|.
*        lv_string = |{ lv_string }<br>To reject directly from e-mail, click |.
*        lv_string = |  { lv_string }<a href="mailto:ivaluesap@ivalue.co.in?subject=R{ lv_wid_text }{ sy-sysid }_MAIL   Reject document">Reject</a>|.
**        lv_string = |  { lv_string }<a href="mailto:ivaluesap@ivalue.co.in?subject=R{ lv_wid_text }{ sy-sysid }_MAIL   Reject document">Reject</a>|.
**    ***** Generate the YOUR Company Portal Production Link
*        lv_string = |{ lv_string }<br><br>To Process Your request in SAP,Please click on hyperink<a href={ lv_inb_link }>  SAP Inbox Link</a></p>|.
**    *    ***** Start DISCLAIMERS and WARNING Notifications
*        lv_string = |{ lv_string }<br><h4>Please note: the links will send an e-mail via microsoft outlook.Please do not change the subject, body or any information in that e-mail</h4>|.
*        lv_string = |{ lv_string }<span style="color:#ff0000#><h4><style="color:red"> caution! please do not reply to this e-mail.</span></body></html>|.
****
****        'for approval via e-mail, please click the links provided only. </h4></br>
          CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
            EXPORTING
              text   = lv_string
            IMPORTING
              buffer = xhtml_string
            EXCEPTIONS
              failed = 1
              OTHERS = 2.

          CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
            EXPORTING
              buffer     = xhtml_string
            TABLES
              binary_tab = t_hex.
*                       *
* End of HTML Code Body
*                       *
* Calculate the Document Size
          CLEAR: lv_lines, lv_so_obj_len.
* Create the Document
          w_subject = |PO { lv_vbeln } In Approval Status|.
*          w_subject = |Order { lv_vbeln } - { im_category }|.
          document = cl_document_bcs=>create_document(

                          i_type    = 'HTM' "send html e-mail and not 'raw'
                          i_hex    = t_hex
                          i_length  = '1700'
                          i_subject = w_subject ).
*     Add document to send request
          CALL METHOD send_request->set_document( document ).
*         set sender               -
          sender = cl_cam_address_bcs=>create_internet_address(
          i_address_string = 'SAP.NOTIFICATION.EXT@KPMG.COM'
          i_address_name = 'SAP.NOTIFICATION.EXT@KPMG.COM' ).
          lv_subject_c = |PO { lv_vbeln } In Approval Status|.
*          lv_subject_c = |Sales Order Approval { lv_vbeln } - { im_category }|...
          send_request->set_message_subject(
        EXPORTING
          ip_subject = CONV string( lv_subject_c ) ).
          CALL METHOD send_request->set_sender
            EXPORTING
              i_sender = sender.
*         Add recipient (e-mail address)
*     Create recipient   passing the e-mail ID here
          lv_email = ls_addr-e_mail.
*          lv_email = 'Nithinu@kpmg.com'.
          recipient = cl_cam_address_bcs=>create_internet_address( lv_email ).

*     Add recipient with its respective attributes to send request
          CALL METHOD send_request->add_recipient
            EXPORTING
              i_recipient = recipient
              i_express   = 'X'.

*        - Send document
          CALL METHOD send_request->send(
            EXPORTING
              i_with_error_screen = 'X'
            RECEIVING
              result              = sent_to_all ).
          COMMIT WORK.
        CATCH cx_bcs INTO bcs_exception.
      ENDTRY.
    ENDIF.

  ENDMETHOD.


  METHOD purchase_requisition_agents.
    DATA: lv_level TYPE i.
    DATA:
      lt_values_1 TYPE STANDARD TABLE OF string,
      lt_values_2 TYPE STANDARD TABLE OF string,
      lt_values_3 TYPE STANDARD TABLE OF string,
      lt_values_4 TYPE STANDARD TABLE OF string,
      lt_values_5 TYPE STANDARD TABLE OF string,
      lt_values_6 TYPE STANDARD TABLE OF string,
      lt_values_7 TYPE STANDARD TABLE OF string.
    DATA: ls_badi_approver
            TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver.

*--------------------------------------------------------------------*
    SELECT SINGLE a~purchaserequisitiontype, a~plant,
       a~purchasinggroup ,a~requirementtracking
       FROM i_purchaserequisitionitemapi01 AS a
      INTO @DATA(ls_purchaserequisition)
      WHERE purchaserequisition = @purchase_requisition
      AND purchaserequisitionitem = @purchase_req_item.

*-- Purchase Order Workflow Agent

    SELECT SINGLE *
      FROM ztmm_pr_wf_agent
      INTO @DATA(ls_purchaserequisition_agent)
      WHERE wf_name = @flexible_workflow_name
      AND plant = @ls_purchaserequisition-plant
      AND purchasing_group = @ls_purchaserequisition-purchasinggroup.
*      and DOC_TYPE = @ls_purchaserequisition-purchaserequisitiontype.
    IF sy-subrc NE 0.
      RAISE EXCEPTION TYPE cx_ble_runtime_error
        EXPORTING
          error_message       = 'Agent Determination Fail'
          implementation_name = 'ZCL_MMPUR_WORKFLOW_AGENT'.
    ENDIF.

** define the list of BADI approvers for local scenario
    lv_level = lines( previousapproverlist ).

**  -----  Approval Level 1
    IF lv_level = 0.
      SPLIT ls_purchaserequisition_agent-approval_level1 AT ',' INTO TABLE lt_values_1.
      LOOP AT lt_values_1 INTO DATA(ls_value_1).
        ls_badi_approver-businessuser = ls_value_1. "ls_purchaserequisition_agent-approval_level1.
        ls_badi_approver-approvallevel = 1.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.
*  -----  Approval Level 2
    ELSEIF lv_level = 1.
      SPLIT ls_purchaserequisition_agent-approval_level2 AT ',' INTO TABLE lt_values_2.
      LOOP AT lt_values_2 INTO DATA(ls_value_2).
        ls_badi_approver-businessuser = ls_value_2.
        ls_badi_approver-approvallevel = 2.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

*  -----  Approval Level 3
    ELSEIF lv_level = 2.

      SPLIT ls_purchaserequisition_agent-approval_level3 AT ',' INTO TABLE lt_values_3.
      LOOP AT lt_values_3 INTO DATA(ls_value_3).
        ls_badi_approver-businessuser = ls_value_3.
        ls_badi_approver-approvallevel = 3.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.
*  -----  Approval Level 4
    ELSEIF lv_level = 3.
      SPLIT ls_purchaserequisition_agent-approval_level4 AT ',' INTO TABLE lt_values_4.
      LOOP AT lt_values_4 INTO DATA(ls_value_4).
        ls_badi_approver-businessuser = ls_value_4.
        ls_badi_approver-approvallevel = 4.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.
*  -----  Approval Level 5
    ELSEIF lv_level = 4.
      SPLIT ls_purchaserequisition_agent-approval_level5 AT ',' INTO TABLE lt_values_5.
      LOOP AT lt_values_5 INTO DATA(ls_value_5).
        ls_badi_approver-businessuser = ls_value_5.
        ls_badi_approver-approvallevel = 5.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

**  -----  Approval Level 6
    ELSEIF lv_level = 5.
      SPLIT ls_purchaserequisition_agent-approval_level6 AT ',' INTO TABLE lt_values_6.
      LOOP AT lt_values_6 INTO DATA(ls_value_6).
        ls_badi_approver-businessuser = ls_value_6.
        ls_badi_approver-approvallevel = 6.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

    ELSEIF lv_level = 6.

      SPLIT ls_purchaserequisition_agent-approval_level7 AT ',' INTO TABLE lt_values_7.
      LOOP AT lt_values_7 INTO DATA(ls_value_7).
        ls_badi_approver-businessuser = ls_value_7.
        ls_badi_approver-approvallevel = 7.
        APPEND ls_badi_approver TO agents.
      ENDLOOP.

    ENDIF.
  ENDMETHOD.


  method SCHEDULING_AGREEMENT.
   DATA: ls_badi_approver
            TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver.
    DATA: lv_level TYPE i.
    "PT

     SELECT  SINGLE *
      INTO  @DATA(ls_purchaseorder)
      FROM ekko
      WHERE ebeln = @scheduling_agreement
      and bstyp = 'L'.

******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT  SINGLE *
*      INTO @DATA(ls_purchaseorder_itm)
*      FROM ekpo
*      WHERE ebeln = @is_sap_object_node_type-sont_key_part_1.
    SELECT *
      INTO @DATA(ls_purchaseorder_itm)
      FROM ekpo UP TO 1 ROWS
      WHERE ebeln = @scheduling_agreement ORDER BY PRIMARY KEY.
    ENDSELECT.
    "PT

*-- scheduling agreement Workflow Agent
    SELECT SINGLE *
      FROM ZTMM_SA_WF_AGENT
      INTO @DATA(ls_SCHEDULING_agent)
      WHERE wf_name = @flexible_workflow_name
        and plant = @ls_purchaseorder_itm-werks
      and purchasing_group = @ls_purchaseorder-EKGRP
      and DOC_TYPE = @ls_purchaseorder-BSART
        AND low_amt LE @ls_purchaseorder-KTWRT
    AND high_amt GE @ls_purchaseorder-KTWRT .

    IF sy-subrc NE 0.
      RAISE EXCEPTION TYPE cx_ble_runtime_error
        EXPORTING
          error_message       = 'Agent Determination Fail'
          implementation_name = 'ZCL_MMPUR_WORKFLOW_AGENT'.
    ENDIF.
** define the list of BADI approvers for local scenario
    lv_level = lines( previousapproverlist ).

 lv_level = lines( previousapproverlist ).


*-----  Approval Level 1
    IF lv_level = 0.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level1.
      ls_badi_approver-approvallevel = 1.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 2
    ELSEIF lv_level = 1.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level2.
      ls_badi_approver-approvallevel = 2.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 3
    ELSEIF lv_level = 2.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level3.
      ls_badi_approver-approvallevel = 3.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 4
    ELSEIF lv_level = 3.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level4.
      ls_badi_approver-approvallevel = 4.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 5
    ELSEIF lv_level = 4.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level5.
      ls_badi_approver-approvallevel = 5.
      APPEND ls_badi_approver TO agents.
*
**  -----  Approval Level 6
    ELSEIF lv_level = 5.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level6.
      ls_badi_approver-approvallevel = 6.
      APPEND ls_badi_approver TO agents.

       ELSEIF lv_level = 6.
      ls_badi_approver-businessuser = ls_SCHEDULING_agent-approval_level7.
      ls_badi_approver-approvallevel = 7.
      APPEND ls_badi_approver TO agents.

    ENDIF.

  ENDMETHOD.


  METHOD serviceentrysheet.
    DATA: ls_badi_approver
             TYPE if_mmpur_workflow_agents_v2=>bd_mmpur_s_badi_approver.
    DATA: lv_level TYPE i.
    SELECT SINGLE b~purchaseordertype, a~purchasinggroup,  b~plant
      FROM i_serviceentrysheet AS a
  INNER JOIN i_serviceentrysheetitem AS b
    ON a~serviceentrysheet = b~serviceentrysheet
    WHERE b~isdeleted IS INITIAL
    AND a~serviceentrysheet = @serviceentrysheet
  INTO @DATA(ls_serviceentrysheet).
*-- scheduling agreement Workflow Agent
    SELECT SINGLE *
      FROM ztmm_sE_wf_agent
      INTO @DATA(ls_serviceentrysheet_agent)
      WHERE wf_name = @flexible_workflow_name
        AND plant = @ls_serviceentrysheet-plant
      AND purchasing_group = @ls_serviceentrysheet-purchasinggroup.
*      AND doc_type = @ls_serviceentrysheet-purchaseordertype.
    IF sy-subrc NE 0.
      RAISE EXCEPTION TYPE cx_ble_runtime_error
        EXPORTING
          error_message       = 'Agent Determination Fail'
          implementation_name = 'ZCL_MMPUR_WORKFLOW_AGENT'.
    ENDIF.
** define the list of BADI approvers for local scenario
    lv_level = lines( previousapproverlist ).

    lv_level = lines( previousapproverlist ).


*-----  Approval Level 1
    IF lv_level = 0.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level1.
      ls_badi_approver-approvallevel = 1.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 2
    ELSEIF lv_level = 1.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level2.
      ls_badi_approver-approvallevel = 2.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 3
    ELSEIF lv_level = 2.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level3.
      ls_badi_approver-approvallevel = 3.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 4
    ELSEIF lv_level = 3.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level4.
      ls_badi_approver-approvallevel = 4.
      APPEND ls_badi_approver TO agents.

*  -----  Approval Level 5
    ELSEIF lv_level = 4.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level5.
      ls_badi_approver-approvallevel = 5.
      APPEND ls_badi_approver TO agents.
*
**  -----  Approval Level 6
    ELSEIF lv_level = 5.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level6.
      ls_badi_approver-approvallevel = 6.
      APPEND ls_badi_approver TO agents.

    ELSEIF lv_level = 6.
      ls_badi_approver-businessuser = ls_serviceentrysheet_agent-approval_level7.
      ls_badi_approver-approvallevel = 7.
      APPEND ls_badi_approver TO agents.

    ENDIF.

  ENDMETHOD.
ENDCLASS.
