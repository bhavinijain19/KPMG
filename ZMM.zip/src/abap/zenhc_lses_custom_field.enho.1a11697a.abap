"Name: \PR:SAPLMBWL\EX:MB_CREATE_GOODS_MOVEMENT_10\EI
ENHANCEMENT 0 ZENHC_LSES_CUSTOM_FIELD.
IF line_exists( imseg[ 1 ] ).
  lv_ses = imseg[ 1 ]-lfbnr.
  SELECT SINGLE zz1_documentdate_mdh, zz1_reference_mdh
      FROM mmpur_ses_header
      INTO @ls_custom_fields
      WHERE serviceentrysheet = @lv_ses.
  IF ls_custom_fields IS NOT INITIAL.
    iimkpf-bldat = ls_custom_fields-zz1_documentdate_mdh. " Maps to Document Date
    iimkpf-xblnr = ls_custom_fields-zz1_reference_mdh.    " Maps to Reference/Material Slip
  ENDIF.
ENDIF.
ENDENHANCEMENT.
