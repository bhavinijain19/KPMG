*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_RETENTIONTOP.                 " Global Declarations
  INCLUDE LZMM_RETENTIONUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_RETENTIONF...                 " Subroutines
* INCLUDE LZMM_RETENTIONO...                 " PBO-Modules
* INCLUDE LZMM_RETENTIONI...                 " PAI-Modules
* INCLUDE LZMM_RETENTIONE...                 " Events
* INCLUDE LZMM_RETENTIONP...                 " Local class implement.
* INCLUDE LZMM_RETENTIONT99.                 " ABAP Unit tests
  INCLUDE LZMM_RETENTIONF00                       . " subprograms
  INCLUDE LZMM_RETENTIONI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
