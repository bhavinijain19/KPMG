@AbapCatalog.sqlViewAppendName: 'ZPURORITEM_R '
@EndUserText.label: 'R_PurchaseOrderItem'
extend view R_PurchaseOrderItem  with zcl_R_PurchaseOrderItem
{
  test,
  KOSTL,
  SAKTO
}
