*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM7TOP.                      " Global Declarations
  INCLUDE LZFG_TVM7UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM7F...                      " Subroutines
* INCLUDE LZFG_TVM7O...                      " PBO-Modules
* INCLUDE LZFG_TVM7I...                      " PAI-Modules
* INCLUDE LZFG_TVM7E...                      " Events
* INCLUDE LZFG_TVM7P...                      " Local class implement.
* INCLUDE LZFG_TVM7T99.                      " ABAP Unit tests
  INCLUDE LZFG_TVM7F00                            . " subprograms
  INCLUDE LZFG_TVM7I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
