@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_D4CBFE9E4F25'

extend view E_SERVICEENTRYSHEET with ZZ1_34CV5UFI2TZDPWUQ47Y7T6L23Y
  
{ 
  Persistence.ZZ1_REFERENCE_MDH as ZZ1_REFERENCE_MDH
}
