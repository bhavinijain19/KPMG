@AbapCatalog.sqlViewName: 'ZSQLITEMMAX'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'ConditionBaseValue'
@Metadata.ignorePropagatedAnnotations: true
define view Zcds_Item_Max_Base as select from I_PurOrdItmPricingElementAPI01 
{
    key PurchaseOrder,
    key PurchaseOrderItem,
    max( ConditionBaseValue ) as MaxBaseValue,
     min( ConditionBaseValue ) as MinBaseValue
} group by PurchaseOrder, PurchaseOrderItem
