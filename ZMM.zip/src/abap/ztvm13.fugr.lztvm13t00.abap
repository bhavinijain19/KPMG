*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM13..........................................*
DATA:  BEGIN OF STATUS_ZTVM13                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM13                        .
CONTROLS: TCTRL_ZTVM13
            TYPE TABLEVIEW USING SCREEN '9999'.
*.........table declarations:.................................*
TABLES: *ZTVM13                        .
TABLES: ZTVM13                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
