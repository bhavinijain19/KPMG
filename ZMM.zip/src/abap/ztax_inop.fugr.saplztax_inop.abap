*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZTAX_INOPTOP.                     " Global Declarations
  INCLUDE LZTAX_INOPUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTAX_INOPF...                     " Subroutines
* INCLUDE LZTAX_INOPO...                     " PBO-Modules
* INCLUDE LZTAX_INOPI...                     " PAI-Modules
* INCLUDE LZTAX_INOPE...                     " Events
* INCLUDE LZTAX_INOPP...                     " Local class implement.
* INCLUDE LZTAX_INOPT99.                     " ABAP Unit tests
  INCLUDE LZTAX_INOPF00                           . " subprograms
  INCLUDE LZTAX_INOPI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
