*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM11TOP.                     " Global Declarations
  INCLUDE LZFG_TVM11UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM11F...                     " Subroutines
* INCLUDE LZFG_TVM11O...                     " PBO-Modules
* INCLUDE LZFG_TVM11I...                     " PAI-Modules
* INCLUDE LZFG_TVM11E...                     " Events
* INCLUDE LZFG_TVM11P...                     " Local class implement.
* INCLUDE LZFG_TVM11T99.                     " ABAP Unit tests
  INCLUDE LZFG_TVM11F00                           . " subprograms
  INCLUDE LZFG_TVM11I00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
