FUNCTION zfm_migo_set_field.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_DISPLAY) TYPE  FLAG
*"----------------------------------------------------------------------

  gv_display = iv_display.

ENDFUNCTION.
