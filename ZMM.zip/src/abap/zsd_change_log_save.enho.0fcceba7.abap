"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:BEGIN\EN:ZSDCHECK_BEFORE_SAVE_PLANT\SE:END\EI
ENHANCEMENT 0 ZSD_CHANGE_LOG_SAVE.

          TYPES: BEGIN OF ty_log,
            SIGN TYPE tvarv_sign,
            opti TYPE tvarv_opti,
            low  TYPE tvarv_val,
            high TYPE tvarv_val,
          END OF ty_log.
          DATA: it_logs TYPE STANDARD TABLE OF ty_log,
                wa_logs TYPE ty_log.


          CONSTANTS : c_log   TYPE rvari_vnam VALUE 'ZSD_LOG_TCODE',
          c_logs TYPE rsscr_kind VALUE 'S'.


          SELECT SIGN
          opti
          low
          high INTO TABLE it_logs
          FROM tvarvc
          WHERE name = c_log AND
          TYPE = c_logs.




      DATA : wa_log TYPE zsd_log.

*  IF sy-tcode = 'VA01' OR sy-tcode = 'VA02'.
      READ TABLE it_logs INTO wa_logs WITH KEY low = sy-tcode.  "Stvarv T-codes for Logs capturing in Custom Table

*   IF wa_logs-low = 'VA01' OR wa_logs-low = 'VA02'.
      IF sy-subrc = 0.
        IF vbak-cmgst EQ 'A' OR  vbak-cmgst EQ ' ' OR vbak-cmgst EQ 'D'.
          "Adding Start by Rahul Vasita on 14.02.2024 11:32:43
          CALL FUNCTION 'ZSD_LOG_TAB_UPDATE' IN UPDATE TASK
          EXPORTING
            vbeln         = vbak-vbeln
            name          = vbak-zzname
            tcode         = sy-tcode.

          "Adding End by Rahul Vasita on 14.02.2024 11:32:43
          "Comment Start by Rahul Vasita on 14.02.2024 11:30:06
**              SELECT SINGLE zvbeln zzname zudate zutime FROM zsd_log INTO CORRESPONDING FIELDS OF wa_log WHERE zvbeln = vbak-vbeln.
**              IF wa_log IS INITIAL.
**                wa_log-zvbeln = vbak-vbeln.
**                wa_log-zzname = vbak-zzname.
**                wa_log-zudate =  sy-datum.
**                wa_log-zutime =  sy-uzeit.
**                wa_log-ztcode = sy-tcode.
**                MODIFY zsd_log FROM  wa_log.
**              ENDIF.
          "Comment End by Rahul Vasita on 14.02.2024 11:30:06
        ENDIF.
      ENDIF.
*  endif.



ENDENHANCEMENT.
