FUNCTION-POOL ZMM_PRPO_TYPE              MESSAGE-ID SV.

* INCLUDE LZMM_PRPO_TYPED...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_PRPO_TYPET00                       . "view rel. data dcl.
