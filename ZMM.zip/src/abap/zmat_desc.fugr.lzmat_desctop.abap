FUNCTION-POOL ZMAT_DESC                  MESSAGE-ID SV.

* INCLUDE LZMAT_DESCD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMAT_DESCT00                           . "view rel. data dcl.
