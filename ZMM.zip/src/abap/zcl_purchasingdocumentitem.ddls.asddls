@AbapCatalog.sqlViewAppendName: 'ZPURDOCIM'
@EndUserText.label: 'PurchasingDocumentItem'
extend view  I_PurchasingDocumentItem with ZCL_PurchasingDocumentItem
{
    ekpo.ps_psp_pnr as test,
    ekpo.sakto as SAKTO,
    ekpo.kostl as KOSTL
}
