FUNCTION-POOL ZFG_TVM6                   MESSAGE-ID SV.

* INCLUDE LZFG_TVM6D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM6T00                            . "view rel. data dcl.
