*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_RETENTION
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_RETENTION       .

  PERFORM TABLEPROC.

ENDFUNCTION.
