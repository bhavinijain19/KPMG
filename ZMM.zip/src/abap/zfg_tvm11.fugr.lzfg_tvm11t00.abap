*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM11..........................................*
DATA:  BEGIN OF STATUS_ZTVM11                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM11                        .
CONTROLS: TCTRL_ZTVM11
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM11                        .
TABLES: ZTVM11                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
