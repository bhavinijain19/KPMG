FUNCTION-POOL ZFI_BUSP                   MESSAGE-ID SV.

* INCLUDE LZFI_BUSPD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_BUSPT00                            . "view rel. data dcl.
