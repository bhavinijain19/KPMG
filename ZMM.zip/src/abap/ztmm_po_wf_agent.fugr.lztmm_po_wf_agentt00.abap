*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTMM_PO_WF_AGENT................................*
DATA:  BEGIN OF STATUS_ZTMM_PO_WF_AGENT              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTMM_PO_WF_AGENT              .
CONTROLS: TCTRL_ZTMM_PO_WF_AGENT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTMM_PO_WF_AGENT              .
TABLES: ZTMM_PO_WF_AGENT               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
