FUNCTION-POOL zfg_migo_ext.                 "MESSAGE-ID ..

* INCLUDE LZFG_MIGO_EXTD...                  " Local class definition

DATA: gv_header_text TYPE zmm_migo_cf-zz1_header_text,
      gv_mblnr       TYPE mkpf-mblnr,
      gv_mjahr       TYPE mkpf-mjahr,
      gv_display     TYPE flag,
      gv_first_fetch TYPE flag.

DATA: gs_zmm_migo_cf TYPE zmm_migo_cf.
