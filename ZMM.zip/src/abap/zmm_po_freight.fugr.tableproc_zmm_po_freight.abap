*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_PO_FREIGHT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_PO_FREIGHT      .

  PERFORM TABLEPROC.

ENDFUNCTION.
