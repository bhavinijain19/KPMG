*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_EMAIL_HSBCTOP.                " Global Data
  INCLUDE LZMM_EMAIL_HSBCUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_EMAIL_HSBCF...                " Subroutines
* INCLUDE LZMM_EMAIL_HSBCO...                " PBO-Modules
* INCLUDE LZMM_EMAIL_HSBCI...                " PAI-Modules
* INCLUDE LZMM_EMAIL_HSBCE...                " Events
* INCLUDE LZMM_EMAIL_HSBCP...                " Local class implement.
* INCLUDE LZMM_EMAIL_HSBCT99.                " ABAP Unit tests
  INCLUDE LZMM_EMAIL_HSBCF00                      . " subprograms
  INCLUDE LZMM_EMAIL_HSBCI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
