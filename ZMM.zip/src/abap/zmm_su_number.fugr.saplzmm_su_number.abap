*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_SU_NUMBERTOP.                 " Global Data
  INCLUDE LZMM_SU_NUMBERUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_SU_NUMBERF...                 " Subroutines
* INCLUDE LZMM_SU_NUMBERO...                 " PBO-Modules
* INCLUDE LZMM_SU_NUMBERI...                 " PAI-Modules
* INCLUDE LZMM_SU_NUMBERE...                 " Events
* INCLUDE LZMM_SU_NUMBERP...                 " Local class implement.
* INCLUDE LZMM_SU_NUMBERT99.                 " ABAP Unit tests
  INCLUDE LZMM_SU_NUMBERF00                       . " subprograms
  INCLUDE LZMM_SU_NUMBERI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
