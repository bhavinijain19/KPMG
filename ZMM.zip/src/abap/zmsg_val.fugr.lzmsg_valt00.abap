*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMSG_VAL........................................*
DATA:  BEGIN OF STATUS_ZMSG_VAL                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMSG_VAL                      .
CONTROLS: TCTRL_ZMSG_VAL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMSG_VAL                      .
TABLES: ZMSG_VAL                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
