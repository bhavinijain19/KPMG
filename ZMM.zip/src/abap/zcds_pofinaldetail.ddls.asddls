@AbapCatalog.sqlViewName: 'ZSQLPOFIN'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'TotalConditionBaseValue'
@Metadata.ignorePropagatedAnnotations: true
define view Zcds_POFINALDETAIL as select from I_PurchaseOrderAPI01 as Header
  inner join I_PurchaseOrderItemAPI01 as Item 
  on Header.PurchaseOrder = Item.PurchaseOrder
  inner join Zcds_Header_Total_Base as Calc
  on Header.PurchaseOrder = Calc.PurchaseOrder
{
      key Header.PurchaseOrder,
    key Item.PurchaseOrderItem,
    Header.PurchaseOrderType,
    Header.PurgReleaseTimeTotalAmount,
    Header.PurchasingGroup,
    Header.CorrespncInternalReference,
    Item.Plant,
    Calc.TotalConditionBaseValue as ConditionBaseValue,
      Calc. TotalConditionBaseValue_min as ConditionBaseValue_min
}
where Item.PurchasingDocumentDeletionCode = ''
