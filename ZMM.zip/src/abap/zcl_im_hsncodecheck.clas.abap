class ZCL_IM_HSNCODECHECK definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MG_MASS_NEWSEG .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_HSNCODECHECK IMPLEMENTATION.


  method IF_EX_MG_MASS_NEWSEG~ADD_NEW_SEGMENT.

*CONSTANTS:
* c_tvarvc_name TYPE rvari_vnam VALUE 'ZMM_HSN_MTART'.
*
*TYPES: BEGIN OF ty_tvarvc,
*         low TYPE tvarv_val,
*       END OF ty_tvarvc.
*DATA: it_tvarvc  TYPE STANDARD TABLE OF ty_tvarvc.
*DATA: wa_tvarvc TYPE ty_tvarvc.

 DATA: ls_smara LIKE LINE OF smara,
        ls_smarc LIKE LINE OF smarc.
 data: ls_mtart type mara-mtart.
 data: ls_pstat type mara-pstat.

 data : wa_tab TYPE mass_wa_tabdata,
        segname TYPE dcobjdef-name.

DATA : htype type dd01v-datatype.
DATA : len(08) TYPE n.

data : it_hsn type STANDARD TABLE OF ZSD_HSN_LEN,
       wa_hsn type ZSD_HSN_LEN.

SELECT * from ZSD_HSN_LEN into TABLE it_hsn.




segname = 'E1OILMA' .

READ TABLE seldata INTO wa_tab
    WITH KEY tabname-name = 'MARA' .

 loop at smarc into ls_smarc.

*   READ TABLE smara into ls_smara with key matnr = ls_smarc-matnr.
   select single mtart pstat from mara into ( ls_mtart,ls_pstat ) where matnr = ls_smarc-matnr.
   if ls_pstat cs 'V' or ls_pstat cs 'E'.
*   if sy-subrc = 0.
   READ TABLE it_hsn INTO wa_hsn WITH KEY mtart = ls_mtart.
   if sy-subrc = 0.

     CALL FUNCTION 'NUMERIC_CHECK'
    EXPORTING
      string_in = ls_smarc-steuc
    IMPORTING
*     STRING_OUT       =
      htype     = htype.

  IF htype = 'NUMC'.

    len = strlen( ls_smarc-steuc ).
    IF ( len <> wa_hsn-zlent AND  len <> wa_hsn-zlenf AND len <> wa_hsn-zlenm ) .
      MESSAGE 'Please enter valid control code length' TYPE 'E'.
    ENDIF.

  ELSE.
    MESSAGE 'Please enter only numaric value' TYPE 'E'.
   ENDIF.

* ELSE.
*
*    CALL FUNCTION 'NUMERIC_CHECK'
*    EXPORTING
*      string_in = ls_smarc-steuc
*    IMPORTING
**     STRING_OUT       =
*      htype     = htype.
*
*  IF htype = 'NUMC'.
*
*    len = strlen( ls_smarc-steuc ).
*    IF LEN <> '6'.
*      MESSAGE ' Valid control code length' TYPE 'E'.
*    ENDIF.
*
*  ELSE.
*    MESSAGE 'Please enter only numaric value' TYPE 'E'.
*   ENDIF.


    endif.
     endif.
    clear:ls_mtart,wa_hsn,ls_pstat.
 endloop.

  endmethod.


  method IF_EX_MG_MASS_NEWSEG~RETURN_IDOC_TYPE.
  endmethod.
ENDCLASS.
