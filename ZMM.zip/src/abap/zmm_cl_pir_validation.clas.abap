CLASS zmm_cl_pir_validation DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_badi_interface .
    INTERFACES if_ex_me_process_po_cust .
  PROTECTED SECTION.
  PRIVATE SECTION.
    DATA: mv_ekorg TYPE ekorg.
ENDCLASS.



CLASS ZMM_CL_PIR_VALIDATION IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~post.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_header.
    DATA(lo_header) = im_header.
    DATA(ls_header) = lo_header->get_data( ).

    mv_ekorg = ls_header-ekorg.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_item.
**  DATA: lv_infnr      TYPE eina-infnr,
**        lv_manual_pir TYPE abap_bool.
**
**  DATA(lo_item)    = im_item.
**  DATA(ls_mepoitem) = lo_item->get_data( ).
**
**  lv_infnr = ls_mepoitem-infnr.
**  CHECK lv_infnr IS NOT INITIAL.
**
*** Step 1: Read EINA
**  SELECT SINGLE infnr, lifnr, matnr
**    FROM eina
**    INTO @DATA(ls_eina)
**    WHERE infnr = @lv_infnr
**      AND loekz = @space.
**
**  CHECK sy-subrc = 0.
**
*** Step 2: Read EINE
**  SELECT SINGLE esokz, netpr
**    FROM eine
**    INTO @DATA(ls_eine)
**    WHERE infnr = @lv_infnr
**      AND ekorg = @mv_ekorg
**      AND werks = @ls_mepoitem-werks.
**
**  IF sy-subrc <> 0.
**    SELECT SINGLE esokz, netpr
**      FROM eine
**      INTO @ls_eine
**      WHERE infnr = @lv_infnr
**        AND ekorg = @mv_ekorg
**        AND werks = @space.
**  ENDIF.
**
*** Step 3: Manual PIR logic
**  IF ls_eine-esokz IS INITIAL.
**    lv_manual_pir = abap_true.
**  ELSE.
**    lv_manual_pir = abap_false.
**  ENDIF.
**
*** Step 4: Restriction
**  IF lv_manual_pir = abap_true.
**    MESSAGE e001(zmm_pir_check).
**  ENDIF.
*
*    DATA: lv_infnr      TYPE eine-infnr,
*          lv_manual_pir TYPE abap_bool,
*          ls_eina       TYPE eina,
*          ls_eine       TYPE eine,
*          ls_eine_np    TYPE eine,
*          ls_ekpo       TYPE ekpo.
*
*    DATA(lo_item)     = im_item.
*    DATA(ls_mepoitem) = lo_item->get_data( ).
*
*    lv_infnr = ls_mepoitem-infnr.
*    CHECK lv_infnr IS NOT INITIAL.
*
*    CLEAR ls_eina.
*    SELECT SINGLE infnr, lifnr, matnr
*      FROM eina
*      INTO @ls_eina
*      WHERE infnr = @lv_infnr
*        AND loekz = @space.
*
*    CLEAR ls_eine.
*    SELECT SINGLE *
*      FROM eine
*      INTO @ls_eine
*      WHERE infnr = @lv_infnr
*        AND ekorg = @mv_ekorg
*        AND werks = @ls_mepoitem-werks.
*
*    IF sy-subrc <> 0.
*      CLEAR ls_eine_np.
*      SELECT SINGLE *
*        FROM eine
*        INTO @ls_eine_np
*        WHERE infnr = @lv_infnr
*          AND ekorg = @mv_ekorg
*          AND werks = @space.
*    ENDIF.
*
*    lv_manual_pir = abap_false.
*
**" Adjust these ranges to your system’s actual intervals
**IF lv_infnr >= '5200000000' AND lv_infnr < '5300000000'.
**  lv_manual_pir = abap_true.
**ELSE.
**  " Fallback: check any related PO item’s SPINF
**  CLEAR ls_ekpo.
**  SELECT SINGLE spinf
**    FROM ekpo
**    INTO @ls_ekpo-spinf
**    WHERE infnr = @lv_infnr
**      AND ( werks = @ls_mepoitem-werks OR werks = @space ).
**
**  IF sy-subrc = 0.
**    IF ls_ekpo-spinf IS INITIAL OR ls_ekpo-spinf = space.
**      lv_manual_pir = abap_true.
**    ELSE.
**      lv_manual_pir = abap_false.
**    ENDIF.
**  ENDIF.
**ENDIF.
*
*    DATA lv_zmode TYPE zmm_pir_range-zmode.
*    CLEAR lv_zmode.
*
*    SELECT SINGLE zr~zmode
*      FROM zmm_pir_range AS zr
*      WHERE @lv_infnr >= zr~zlow
*        AND @lv_infnr <= zr~zhigh
*      INTO @lv_zmode.
*
*    IF lv_zmode = 'MANUAL'.
*      lv_manual_pir = abap_true.
*    ELSEIF lv_zmode = 'AUTO'.
*      lv_manual_pir = abap_false.
*    ELSE.
*      " No matching config: choose your default
*      lv_manual_pir = abap_false. " allow by default
*    ENDIF.
*
**Error Mesage
*    IF lv_manual_pir = abap_true.
*      MESSAGE 'Price conditions in PO cannot be changed PIR was created manually' TYPE 'E'.
*    ELSE.
*      MESSAGE 'Price changes in PO are allowed since PIR was created automatically' TYPE 'W'.
*    ENDIF.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_item.

*
*    DATA(lo_item)     = im_item.
*    DATA(ls_mepoitem) = lo_item->get_data( ).
*    DATA lv_manual TYPE abap_bool.
*
*    " --- Decide if PIR is manual (use your finalized logic) ---
*    IF ls_mepoitem-infnr IS INITIAL.
*      RETURN.
*    ENDIF.
*
*    " Example heuristic: adjust to your ranges/rules
*    IF ls_mepoitem-infnr >= '5200000000' AND ls_mepoitem-infnr < '5300000000'.
*      lv_manual = abap_true.
*    ELSE.
*      " Optional fallback: check EKPO-SPINF as an indicator
*      DATA(ls_ekpo) = VALUE ekpo( ).
*      SELECT SINGLE spinf
*        FROM ekpo
*        INTO @ls_ekpo-spinf
*        WHERE infnr = @ls_mepoitem-infnr
*          AND ( werks = @ls_mepoitem-werks OR werks = @space ).
*      IF sy-subrc = 0 AND ( ls_ekpo-spinf IS INITIAL OR ls_ekpo-spinf = space ).
*        lv_manual = abap_true.
*      ENDIF.
*    ENDIF.
*
*    IF lv_manual = abap_true.
*
**    " ------------------------------------------------------------
**    " CH_FIELDSELECTION is a TABLE. Loop rows and set FIELDSTATUS.
**    " Use the parameter’s own line type to avoid missing-types.
**    " Status values (domain MEPO_FD_STATUS):
**    "   0=unchanged, 1=required, 2=optional, 3=display-only, 4=hidden
**    " ------------------------------------------------------------
**    FIELD-SYMBOLS <fs_field> TYPE LINE OF TTYP_FIELDSELECTION_MM.
**
**  LOOP AT ch_fieldselection ASSIGNING <fs_field>.
**      CASE <fs_field>-metafield.
**        WHEN 'NETPR'.     " Net price
**          <fs_field>-fieldstatus = 3.  " 3 = read-only
**        WHEN 'UPINF'.     " Info Update checkbox (visible one)
**          <fs_field>-fieldstatus = 3.  " 3 = read-only
**      ENDCASE.
**    ENDLOOP.
*
*      DATA: ls_fieldselection TYPE mmpur_fs.
*
*      " Attempt to find the standard Net Price field
*      READ TABLE ch_fieldselection WITH TABLE KEY metafield = 62
*           ASSIGNING FIELD-SYMBOL(<fs_fieldselection>).
*
*      IF sy-subrc = 0.
*        " If it exists, just change the status
*        <fs_fieldselection>-fieldstatus = '*'.
*      ELSE.
*        " If it's missing (why you only see 90000100), you must add it
*        ls_fieldselection-metafield   = 061.  " 62 = Net Price
*        ls_fieldselection-fieldstatus = '*'. " '*' = Display only
*        INSERT ls_fieldselection INTO TABLE ch_fieldselection.
*      ENDIF.
*    ENDIF.
  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
