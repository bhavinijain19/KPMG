*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTAX_INOP.......................................*
DATA:  BEGIN OF STATUS_ZTAX_INOP                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTAX_INOP                     .
CONTROLS: TCTRL_ZTAX_INOP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTAX_INOP                     .
TABLES: ZTAX_INOP                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
