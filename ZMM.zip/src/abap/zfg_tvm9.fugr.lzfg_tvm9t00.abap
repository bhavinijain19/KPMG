*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM9...........................................*
DATA:  BEGIN OF STATUS_ZTVM9                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM9                         .
CONTROLS: TCTRL_ZTVM9
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM9                         .
TABLES: ZTVM9                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
