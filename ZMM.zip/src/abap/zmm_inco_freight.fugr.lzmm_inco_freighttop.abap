FUNCTION-POOL ZMM_INCO_FREIGHT           MESSAGE-ID SV.

* INCLUDE LZMM_INCO_FREIGHTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_INCO_FREIGHTT00                    . "view rel. data dcl.
