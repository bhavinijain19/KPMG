*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM8...........................................*
DATA:  BEGIN OF STATUS_ZTVM8                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM8                         .
CONTROLS: TCTRL_ZTVM8
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM8                         .
TABLES: ZTVM8                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
