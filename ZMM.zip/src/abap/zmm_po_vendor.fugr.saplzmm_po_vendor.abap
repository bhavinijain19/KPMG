*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_PO_VENDORTOP.                 " Global Declarations
  INCLUDE LZMM_PO_VENDORUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_PO_VENDORF...                 " Subroutines
* INCLUDE LZMM_PO_VENDORO...                 " PBO-Modules
* INCLUDE LZMM_PO_VENDORI...                 " PAI-Modules
* INCLUDE LZMM_PO_VENDORE...                 " Events
* INCLUDE LZMM_PO_VENDORP...                 " Local class implement.
* INCLUDE LZMM_PO_VENDORT99.                 " ABAP Unit tests
  INCLUDE LZMM_PO_VENDORF00                       . " subprograms
  INCLUDE LZMM_PO_VENDORI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
