*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTMM_PO_WF_AGENT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTMM_PO_WF_AGENT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
