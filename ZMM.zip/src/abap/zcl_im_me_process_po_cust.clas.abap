CLASS zcl_im_me_process_po_cust DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_badi_interface .
    INTERFACES if_ex_me_process_po_cust .
  PROTECTED SECTION.
private section.

  types:
**BOC - PIR Validation - Saurabh Saumya
**EOC - PIR Validation - Saurabh Saumya
    BEGIN OF lty_base_cond,
             ebelp    TYPE ebelp,
             cond_ref TYPE REF TO data,
           END OF lty_base_cond .

  data MD_TRTYP type TRTYP .
  data:
    mt_base_cond  TYPE HASHED TABLE OF lty_base_cond WITH UNIQUE KEY ebelp .
  data:
    mt_prot_kschl TYPE SORTED TABLE OF kschl WITH UNIQUE KEY table_line .
  data GV_KTOKK type KTOKK .
  data GV_LIFNR type LIFNR .
  data GV_MTART type MTART .
  data GV_BSART type ESART .
  data GV_PSTYP type PSTYP .
  data GV_BUKRS type BUKRS .
  data GV_RESWK type WERKS_D .
  data GV_FLAG type C .
  data GV_DPTYP type ME_DPTYP .
  data GV_DPPCT type ME_DPPCNT .
  data GV_DPDAT type ME_DPDDAT .
  data GV_BWTAR type BWTAR_D .
  data GV_DPAMT type ME_DPAMNT .
  data GV_CHID type J_1ICHID .
  data GV_MBLNR type MBLNR .

  methods DETERMINE_PIR_MODE
    importing
      !IV_INFNR type INFNR
      !IV_EBELN type EBELN
      !IV_EBELP type EBELP
    exporting
      !EV_MODE type CHAR10 .   "returns 'MANUAL' or 'AUTO'.
ENDCLASS.



CLASS ZCL_IM_ME_PROCESS_PO_CUST IMPLEMENTATION.


  METHOD determine_pir_mode.
*......................................................................*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001> Saurabh Saumya     DEVK954730   Task - DEVK954937              *
* Date: 20.01.2026                                                     *
* Reason: Validation for PIR if its's created manually the Net Price   *
*         field shoudld be disabled                                    *
*......................................................................*
*    " Default to MANUAL unless proven AUTO
*    DATA(lv_mode) = CONV char10( 'MANUAL' ).
*
*    " 1) Configurable by range table (recommended)
*    SELECT SINGLE zmode
*      FROM zmm_pir_range
*      INTO @DATA(lv_rng_mode)
*      WHERE zlow <= @iv_infnr
*        AND zhigh >= @iv_infnr.
*    IF sy-subrc = 0 AND lv_rng_mode IS NOT INITIAL.
*      ev_mode = lv_rng_mode.
*      RETURN.
*    ENDIF.
*
*    " (Temporary alternative if ZMM_PIR_RANGE not created)
*    " CONSTANTS: c_auto_lo TYPE infnr VALUE '5100000000',
*    "            c_auto_hi TYPE infnr VALUE '5199999999'.
*    " IF iv_infnr >= c_auto_lo AND iv_infnr <= c_auto_hi.
*    "   ev_mode = 'AUTO'. RETURN.
*    " ENDIF.
*
*    " 2) Fallback: if current PO item is marked for info-update => treat as AUTO
*    SELECT SINGLE spinf
*      FROM ekpo
*      INTO @DATA(lv_spinf)
*      WHERE ebeln = @iv_ebeln
*        AND ebelp = @iv_ebelp.
*    IF sy-subrc = 0 AND lv_spinf = 'X'.
*      lv_mode = 'AUTO'.
*    ENDIF.
*
*    ev_mode = lv_mode.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~check.
*......................................................................*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001> Saurabh Saumya     DEVK954730   Task - DEVK954937              *
* Date: 20.01.2026                                                     *
* Reason: Validation for PIR if its's created manually the Net Price   *
*         field shoudld be disabled                                    *
*......................................................................*

    INCLUDE mm_messages_mac. " Required for mmpur macros


    TYPES: BEGIN OF ty_material_key,
             ebelp TYPE ebelp,
             matnr TYPE matnr,
             bwkey TYPE bwkey,
             bwtar TYPE mbew-bwtar,
           END OF ty_material_key,

           tt_material_keys TYPE SORTED TABLE OF ty_material_key
                 WITH UNIQUE KEY ebelp matnr bwkey bwtar.

    CONSTANTS: c_po_doctype TYPE rvari_vnam VALUE 'ZPO_DOCTYPE',
               c_selopt     TYPE rsscr_kind VALUE 'S'.

    DATA: lo_services    TYPE REF TO if_services_mm,
          lt_esll        TYPE mmsrv_esll,
          lt_accountings TYPE purchase_order_accountings.

    SELECT sign, opti, low, high
      INTO TABLE @DATA(lt_po_doctyp)
      FROM tvarvc
      WHERE name = @c_po_doctype
        AND type = @c_selopt.

***Start change by archna gupta
*    SELECT ebeln, ebelp, packno
*       FROM ekpo
*      INTO TABLE @DATA(lt_ekpo).
**      where ebeln =
*    IF lt_ekpo IS NOT INITIAL.
*      SELECT srvpos, packno FROM esll
*                      INTO TABLE @DATA(lt_esll)
*        FOR ALL ENTRIES IN @lt_ekpo
*        WHERE packno = @lt_ekpo-packno.
*    ENDIF.
*    IF lt_esll IS NOT INITIAL.
*      SELECT packno, ps_psp_pnr FROM eskn INTO TABLE @DATA(lt_eskn)
*        FOR ALL ENTRIES IN @lt_esll
*        WHERE  packno = @lt_esll-packno.
*    ENDIF.
*    LOOP AT lt_eskn INTO DATA(ls_eskn).
*    ENDLOOP


**    End of change archna gupta


    "change on

*    DATA(ls_header) = im_header->get_data( ).
    DATA  ls_header  TYPE mepoheader.
    ls_header = im_header->get_data( ).

****    IF line_exists( lt_po_doctyp[ low = ls_header-bsart ] ).
    " Retrieve all items from the STO
    "start change on 28-01-26
*    DATA(lt_items) = im_header->get_items( ).
    "this code is copy paste from below code line no 398
    DATA  lt_items TYPE purchase_order_items.
    lt_items = im_header->get_items( ).
    "end change on 28-01-26
    "start chaneg on 28-01-26.
    "code shifted from line no 310 to 75
    DATA : ls_item  TYPE purchase_order_item.
    "end change on 28-01-26
    DATA(lt_material_keys) = VALUE tt_material_keys(
                                    FOR ls_items IN lt_items
                                    LET ls_data = ls_items-item->get_data( ) IN
                                    ( ebelp = ls_data-ebelp matnr = ls_data-matnr bwkey = ls_data-werks bwtar = ls_data-bwtar )
                                  ).

    IF lt_material_keys IS INITIAL.
      RETURN.
    ENDIF.

    SELECT matnr, bwkey, bwtar, vprsv, stprs
      FROM mbew
      FOR ALL ENTRIES IN @lt_material_keys
      WHERE matnr = @lt_material_keys-matnr
        AND bwkey = @lt_material_keys-bwkey
        AND bwtar = @lt_material_keys-bwtar
      INTO TABLE @DATA(lt_mbew_data).

    " Validate results back in the item loop
    LOOP AT lt_items INTO DATA(ls_item_ref).

      DATA(ls_item_data) = ls_item_ref-item->get_data( ).
      DATA(ls_head) = ls_item_ref-item->get_header( ).

      DATA(ls_mbew) = VALUE #( lt_mbew_data[ matnr = ls_item_data-matnr
                                             bwkey = ls_item_data-werks
                                             bwtar = ls_item_data-bwtar ] OPTIONAL ).
      lt_accountings = ls_item_ref-item->get_accountings( ).

      LOOP AT lt_accountings INTO DATA(ls_accounting).
        DATA(ls_acc_data) = ls_accounting-accounting->get_data( ).
      ENDLOOP.
****        IF ls_item_data-pstyp = '9'.
****          TRY.
****              lo_services ?= ls_item_ref-item.
****              CALL METHOD lo_services->get_srv_data
****                EXPORTING
****                  im_packno = ls_item_data-packno
****                IMPORTING
****                  ex_esll   = lt_esll.
****
****              " Collect WBS elements from service lines
****              LOOP AT lt_esll INTO DATA(ls_esll) WHERE ps_psp_pnr IS NOT INITIAL.
****                APPEND ls_esll-ps_psp_pnr TO lt_wbs_check.
****              ENDLOOP.
****            CATCH cx_sy_move_cast_error.
****              CONTINUE.
****          ENDTRY.
****        ENDIF.

      "++ Begin of changes by Hemang Joshi on 12/02/2026 req by : Sidhesh Rai
      "skip validation for valuation type other then those maintained in tvarvc
"Changed by UDAYABAP03 on 15.04.2026
      IF line_exists( lt_po_doctyp[ low = ls_header-bsart ] ).
*      IF line_exists( lt_val_typ[ low = ls_mbew-bwtar ] ).
"Changed by UDAYABAP03 on 15.04.2026

        "++ END of changes by Hemang Joshi on 12/02/2026 req by : Sidhesh Rai

        " Check logic: Standard Price = 0 and Price Control = 'S'
        IF ls_mbew-vprsv = 'S' AND ls_mbew-stprs = 0.
          " Raise modern Error Message
          mmpur_message_forced 'E' 'ZMM_MSGS' '007'
                               ls_item_data-werks '' '' ''.

          " Mark the item as invalid to block saving
          ls_item_ref-item->invalidate( ).
          ch_failed = abap_true.
        ENDIF.
      ENDIF..


    ENDLOOP.
****    ENDIF.

***BOC #001
*
*    DATA(ls_header1) = im_header->get_data( ).
*    DATA(lt_items1)  = im_header->get_items( ).
*
*    LOOP AT lt_items1 INTO DATA(ls_wrap).
*
*      DATA(lo_item) = ls_wrap-item.
*      DATA(ls_item1) = lo_item->get_data( ).
*
*      " Skip items without PIR
*      IF ls_item1-infnr IS INITIAL.
*        CONTINUE.
*      ENDIF.
*
*      " 1) Decide PIR mode (MANUAL/AUTO)
*      DATA lv_mode TYPE char10.
*
*      me->determine_pir_mode(
*        EXPORTING iv_infnr = ls_item1-infnr
*                  iv_ebeln = ls_item1-ebeln
*                  iv_ebelp = ls_item1-ebelp
*        IMPORTING ev_mode  = lv_mode ).
*
*      IF lv_mode = 'AUTO'.
*        CONTINUE. " For auto PIR, price change is allowed
*      ENDIF.
*
*      " 2) Read current conditions (runtime type inferred)
*      CALL METHOD lo_item->get_conditions
*        IMPORTING
*          ex_conditions = DATA(lt_now).
*
*      " 3) Read baseline
*      READ TABLE me->mt_base_cond INTO DATA(ls_base)
*           WITH KEY ebelp = ls_item1-ebelp.
*      IF sy-subrc <> 0 OR ls_base-cond_ref IS INITIAL.
*        " No baseline yet (e.g., first check) -> initialize now and skip once
*        DATA lr_copy TYPE REF TO data.
*        CREATE DATA lr_copy LIKE lt_now.
*        ASSIGN lr_copy->* TO FIELD-SYMBOL(<lt_copy_init>).
*        <lt_copy_init> = lt_now.
*        INSERT VALUE lty_base_cond( ebelp = ls_item1-ebelp cond_ref = lr_copy )
*          INTO TABLE me->mt_base_cond.
*        CONTINUE.
*      ENDIF.
*
*      ASSIGN ls_base-cond_ref->* TO FIELD-SYMBOL(<lt_old>).
*      IF <lt_old> IS NOT ASSIGNED.
*        CONTINUE.
*      ENDIF.
*
*      " 4) Compare only protected KSCHL rows
*      DATA(lv_changed) = abap_false.
*
*      LOOP AT lt_now ASSIGNING FIELD-SYMBOL(<wa_now>).
*
*        " KSCHL of current row
*        ASSIGN COMPONENT 'KSCHL' OF STRUCTURE <wa_now> TO FIELD-SYMBOL(<kschl_now>).
*        IF <kschl_now> IS NOT ASSIGNED.
*          CONTINUE.
*        ENDIF.
*
*        " Check if this KSCHL is protected
*        READ TABLE me->mt_prot_kschl WITH TABLE KEY table_line = <kschl_now> TRANSPORTING NO FIELDS.
*        IF sy-subrc <> 0.
*          CONTINUE.
*        ENDIF.
*
*        " Find same KSCHL in baseline
*        DATA(lv_found) = abap_false.
*        LOOP AT <lt_old> ASSIGNING FIELD-SYMBOL(<wa_old>).
*          ASSIGN COMPONENT 'KSCHL' OF STRUCTURE <wa_old> TO FIELD-SYMBOL(<kschl_old>).
*          IF <kschl_old> IS ASSIGNED AND <kschl_old> = <kschl_now>.
*            lv_found = abap_true.
*
*            " Compare price-relevant fields
*            ASSIGN COMPONENT 'KBETR' OF STRUCTURE <wa_now> TO FIELD-SYMBOL(<kbetr_now>).
*            ASSIGN COMPONENT 'KBETR' OF STRUCTURE <wa_old> TO FIELD-SYMBOL(<kbetr_old>).
*
*            ASSIGN COMPONENT 'KPEIN' OF STRUCTURE <wa_now> TO FIELD-SYMBOL(<kpein_now>).
*            ASSIGN COMPONENT 'KPEIN' OF STRUCTURE <wa_old> TO FIELD-SYMBOL(<kpein_old>).
*
*            ASSIGN COMPONENT 'KMEIN' OF STRUCTURE <wa_now> TO FIELD-SYMBOL(<kmein_now>).
*            ASSIGN COMPONENT 'KMEIN' OF STRUCTURE <wa_old> TO FIELD-SYMBOL(<kmein_old>).
*
*            ASSIGN COMPONENT 'KWERT' OF STRUCTURE <wa_now> TO FIELD-SYMBOL(<kwert_now>).
*            ASSIGN COMPONENT 'KWERT' OF STRUCTURE <wa_old> TO FIELD-SYMBOL(<kwert_old>).
*
*            IF ( <kbetr_now> IS ASSIGNED AND <kbetr_old> IS ASSIGNED AND <kbetr_now> <> <kbetr_old> )
*            OR ( <kpein_now> IS ASSIGNED AND <kpein_old> IS ASSIGNED AND <kpein_now> <> <kpein_old> )
*            OR ( <kmein_now> IS ASSIGNED AND <kmein_old> IS ASSIGNED AND <kmein_now> <> <kmein_old> )
*            OR ( <kwert_now> IS ASSIGNED AND <kwert_old> IS ASSIGNED AND <kwert_now> <> <kwert_old> ).
*              lv_changed = abap_true.
*            ENDIF.
*
*            EXIT. " matched base row checked
*          ENDIF.
*        ENDLOOP.
*
*        " Protected KSCHL newly added (not in baseline) → changed
*        IF lv_found = abap_false.
*          lv_changed = abap_true.
*        ENDIF.
*
*        IF lv_changed = abap_true.
*          EXIT.
*        ENDIF.
*
*      ENDLOOP.
*
*      " 5) If changed and PIR=MANUAL → block save with purchasing error
*      IF lv_changed = abap_true.
*        " Message 001 in your Z class: "Price conditions in PO cannot be changed, PIR was created manually"
*        MESSAGE 'Price conditions in PO cannot be changed, PIR was created manually' TYPE 'E'. "mmpur_message_forced 'E' 'ZMM_MSGS' '001' ls_item1-ebelp '' '' ''.
*      ENDIF.
*
*    ENDLOOP.

*EOC #001
*****************************Retrofit Code*****************************************

    DATA: lv_bsart TYPE esart,
          lv_lifnr TYPE lifnr,
          lv_ktokk TYPE ktokk.
*
*    DATA  : ls_poitem TYPE mepoitem,
********************************************Begin of changes*Added by Raj on 11.07.2024*******
    DATA  : gs_poitem  TYPE mepoitem."Added by Raj on 08.07.2024
    TYPES : BEGIN OF ty_ekpp,
              creationdate TYPE ekpo-creationdate,
              creationtime TYPE ekpo-creationtime,
              ebeln        TYPE ekpo-ebeln,
              ebelp        TYPE ekpo-ebelp,
              werks        TYPE ekpo-werks,
              matnr        TYPE ekpo-matnr,
              ktmng        TYPE ekpo-ktmng,
              netpr        TYPE ekpo-netpr,
              bstyp        TYPE ekpo-bstyp,
              tsl          TYPE string,
            END OF ty_ekpp.

    DATA : it_ekpp TYPE STANDARD TABLE OF ty_ekpp,
           wa_ekpp TYPE ty_ekpp.
    DATA : lv_konnr TYPE ekko-konnr."Added by Raj on 08.07.2024
    DATA : lv_ktpnr TYPE ekpo-ebelp."Added by Raj on 08.07.2024
    DATA : lv_netpr  TYPE ekpo-netpr."Added by Raj on 08.07.2024
    DATA :gs_switch(1) TYPE c."Added by Raj on 08.07.2024
    CONSTANTS :c_tvarvc_mts TYPE rvari_vnam VALUE 'ZMM_PO_TYPES',  "Added by Raj on 08.07.2024
               c_type_mts   TYPE rsscr_kind VALUE 'S'.            "Added by Raj on 08.07.2024
    TYPES: BEGIN OF ty_tvarv,
             sign TYPE tvarv_sign,
             opti TYPE tvarv_opti,
             low  TYPE tvarv_val,
             high TYPE tvarv_val,
           END OF ty_tvarv.
    DATA: it_type TYPE STANDARD TABLE OF ty_tvarv, "Added by Raj on 08.07.2024
          wa_type TYPE ty_tvarv.    "Added by Raj on 08.07.2024
*********************************************End of changes*Added by Raj on 11.07.2024****************


    DATA  : ls_detail  TYPE mepoitem,
            lt_details TYPE tab_mepoitem.
    " start change on 28-01-26
*            ls_header  TYPE mepoheader.
    " end  change on 28-01-26
    "start chaneg on 28-01-26
*    DATA  : lt_items TYPE purchase_order_items,
    "end change on 28-01-26
    "start change on 28-01-26
    "code shifted on line no 74
*     Data : ls_item  TYPE purchase_order_item.
    "end chaneg on 28-01-26
    DATA lv_pstyp TYPE pstyp.
*    TYPES: ty_bsart TYPE RANGE OF ekko-bsart.
*    DATA : rt_bsart    TYPE ty_bsart,
*           rw_bsart    TYPE LINE OF ty_bsart,
*           ls_head     TYPE REF TO if_purchase_order_mm,
*           ls_headdata TYPE mepoheader.
*    DATA: lv_vprsv   TYPE mbew-vprsv VALUE 'S',
*          lv_vprsv1  TYPE mbew-vprsv,
*          lv_tvarvc1 TYPE tvarvc-name VALUE 'ZPO_STO_TYPE_DEL_FLAG'.

    FIELD-SYMBOLS <fs_zdomes> TYPE ANY TABLE.

    lt_items  = im_header->get_items( ).
    REFRESH lt_details.
    LOOP AT lt_items INTO ls_item.
      ls_detail = ls_item-item->get_data( ).
      APPEND ls_detail TO lt_details.
    ENDLOOP.

***** Added by MR on 10/09/2022

    "---Get Head Deep-Structure
*    ls_head     = im_header->get_header( ).
    "---Get Header Data
*    ls_headdata  = ls_head->get_data( ).,
***    ls_headdata  = im_header->get_data( ).
***
***    SELECT low, high
***           FROM tvarvc
***           INTO TABLE @DATA(lt_bsart)
***           WHERE name = @lv_tvarvc1.
***    LOOP AT lt_bsart INTO DATA(lw_bsart).
***      rw_bsart-sign   = 'I'.
***      rw_bsart-option = 'EQ'.
***      rw_bsart-low    = lw_bsart-low.
***      APPEND rw_bsart TO rt_bsart.
***      CLEAR rw_bsart.
***    ENDLOOP.
***
***    CHECK rt_bsart IS NOT INITIAL.
***
***    IF ls_headdata-bsart IN rt_bsart.
****      IF ls_mepoitem-bwtar IS NOT INITIAL.
****      LOOP AT lt_details INTO DATA(ls_details).
***      LOOP AT lt_items INTO ls_item.
***        DATA(ls_details) = ls_item-item->get_data( ).
***
***        SELECT SINGLE *
***              INTO @DATA(lw_mbew)
***              FROM mbew
***              WHERE matnr = @ls_details-matnr
***              AND   bwkey = @ls_details-werks
***              AND   bwtar = @ls_details-bwtar
***              AND   vprsv = @lv_vprsv.
***        IF sy-subrc = 0.
***          MESSAGE w398(00) WITH 'Stardard Price for material' ls_details-matnr 'is zero'.
***          IF sy-tcode = 'ME21N'.
***            ls_details-loekz = 'S'.
***          ELSE.
***            ls_details-loekz = 'L'.
***          ENDIF.
***
****          ls_item-item-my_cust_firewall_on = 'X'.
***          DATA: l_parent  TYPE REF TO cl_po_header_handle_mm, "IF_MESSAGE_OBJ_MM,
***                my_parent TYPE REF TO if_message_obj_mm. "
***
****
***
***          my_parent = im_header->if_message_obj_mm~get_parent( ).
***
***          mmpur_dynamic_cast l_parent my_parent.
***
***
***          CHECK NOT l_parent IS INITIAL.
****          CHECK "l_parent->my_ibs_firewall_on EQ mmpur_yes OR
***                l_parent->my_cust_firewall_on = mmpur_yes.
***
***          "---Change line item with Set method
***          CALL METHOD ls_item-item->set_data
***            EXPORTING
***              im_data = ls_details.
***
***        ENDIF.
***      ENDLOOP.
***    ENDIF.

***** End of Addition bt MR

    READ TABLE lt_details INTO ls_detail INDEX 1.
    LOOP AT lt_details TRANSPORTING NO FIELDS
       WHERE ( werks NE ls_detail-werks ).
      EXIT.
    ENDLOOP.
    IF ( syst-subrc = 0 ) .

      MESSAGE 'MULTIPLE PLANT NOT ALLOW' TYPE 'E'.
      ch_failed = 'X'.
    ENDIF.

    IF gv_lifnr IS NOT INITIAL AND
       gv_bukrs IS NOT INITIAL.
      SELECT SINGLE lifnr
               INTO lv_lifnr
                 FROM lfb1
                   WHERE lifnr = gv_lifnr
                     AND bukrs = gv_bukrs.
      IF sy-subrc NE 0.
        MESSAGE e024(zmm) WITH gv_lifnr gv_bukrs.
      ENDIF.
    ENDIF.
*    IF gv_bwtar EQ 'LOCAL' AND gv_bsart EQ 'ZSTO'.
    IF gv_bwtar EQ 'LOCAL' AND gv_bsart EQ 'ZCBW'.
      MESSAGE e027(zmm) WITH gv_bwtar gv_bsart.
    ENDIF.
*    IF gv_bsart eq 'ZUB'.
*      CALL FUNCTION 'POPUP_TO_CONFIRM'
*        EXPORTING
*         TITLEBAR                    = 'Invoice selection '
**         DIAGNOSE_OBJECT             = ' '
*          text_question               = 'hello'
*         TEXT_BUTTON_1               = 'Yes'
**         ICON_BUTTON_1               = ' '
*         TEXT_BUTTON_2               = 'No'
**         ICON_BUTTON_2               = ' '
**         DEFAULT_BUTTON              = '1'
**         DISPLAY_CANCEL_BUTTON       = 'X'
**         USERDEFINED_F1_HELP         = ' '
**         START_COLUMN                = 25
**         START_ROW                   = 6
**         POPUP_TYPE                  =
**         IV_QUICKINFO_BUTTON_1       = ' '
**         IV_QUICKINFO_BUTTON_2       = ' '
**       IMPORTING
**         ANSWER                      =
**       TABLES
**         PARAMETER                   =
**       EXCEPTIONS
**         TEXT_NOT_FOUND              = 1
**         OTHERS                      = 2
*                .
*      IF sy-subrc <> 0.
** Implement suitable error handling here
*      ENDIF.
*
*
**      MESSAGE e009(zmm) DISPLAY LIKE 'I' WITH gv_bsart gv_bsart.
*    ENDIF.
*&---------------------------------------------------------------------------
*& CR          : CR-5072
*& Author      : Bhushan Bhalerao
*& Company     : AIS, Pune
*& Description : STO Price - Check on FRA1
*&---------------------------------------------------------------------------
*---BOC CR-5072
    DATA : lt_conditions TYPE mmpur_tkomv,
           lo_po_doc     TYPE REF TO if_purchasing_document,
           ls_poheader   TYPE mepoheader.

    ls_poheader  = im_header->get_data( ).
    lo_po_doc ?= im_header.

****** Added changes for check of Release Strategy by Carina Jose on 11.06.2022

    CONSTANTS:
      c_tvarvc_name TYPE rvari_vnam VALUE 'Z_POTYPES_VALI',
      c_type_user   TYPE rsscr_kind VALUE 'S'.

    TYPES :BEGIN OF ty_tvarvc,
             low TYPE tvarvc-low,
           END OF ty_tvarvc.
    DATA : it_tvarvc TYPE STANDARD TABLE OF ty_tvarvc,
           wa_tvarvc TYPE ty_tvarvc.
    SELECT low
      INTO TABLE it_tvarvc
      FROM tvarvc
      WHERE name = c_tvarvc_name.

    READ TABLE it_tvarvc INTO wa_tvarvc WITH KEY low = ls_poheader-bsart.
    IF sy-subrc <> '0'.
      IF ls_detail-loekz NE 'L'.
        IF ls_poheader-frggr IS INITIAL AND ls_poheader-frgsx IS INITIAL.
          MESSAGE 'Please Configure Release Strategy' TYPE 'E'.
        ENDIF.
      ENDIF.
    ENDIF.
****** End of changes by Carina Jose on 11.06.2022



********Added changes to allow hold for past date Po 30-08-2022 (Squirrel Manoj)
*    SELECT SINGLE low FROM tvarvc INTO @DATA(lv_holdtcode) WHERE name = 'ZMM_HOLDPO_TCODE'.
*    IF sy-tcode = lv_holdtcode. "'ME22N'
*
*      FIELD-SYMBOLS: <fs_ekko> TYPE ekko.
*      ASSIGN ('(SAPLMEPO)EKKO') TO <fs_ekko>.
*
*      SELECT SINGLE low FROM tvarvc INTO @DATA(zpo_hold_doctyp) WHERE name = 'ZPO_HOLD_DOCTYP'.
*      IF zpo_hold_doctyp IS NOT INITIAL.
*        SELECT SINGLE * FROM ekko INTO @DATA(ls_ekko) WHERE ebeln = @ls_poheader-ebeln.
*        IF ls_ekko IS NOT INITIAL.
*          IF ( ls_ekko-memorytype = 'H' AND ls_ekko-bsart = zpo_hold_doctyp ).
*
*          ELSE.
**            IF <fs_ekko> IS ASSIGNED.
**              IF <fs_ekko>-bedat < sy-datum.
**                MESSAGE 'Document date is in past' TYPE 'E'.
**                ch_failed = abap_true.
**              ELSEIF <fs_ekko>-bedat > sy-datum.
**                MESSAGE 'Document date is in future' TYPE 'E'.
**                ch_failed = abap_true.
**              ENDIF.
**            ENDIF.
*            exit.
*
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*
*******End of changes by (Squirrel Manoj)

    CALL METHOD lo_po_doc->get_tkomv
      IMPORTING
        ex_tkomv = lt_conditions.

    SELECT name, low
           FROM tvarvc
           INTO TABLE @DATA(lt_tvarvc)
           WHERE name IN ('Z_PO_FRA1_DOCTYPE','Z_PO_FRA1_COND').

    READ TABLE lt_tvarvc INTO DATA(lv_tvarvc) WITH KEY name = 'Z_PO_FRA1_DOCTYPE'
                                                       low  = ls_poheader-bsart.
    IF sy-subrc = 0. "ls_poheader-bsart = lv_tvarvc-low.
      CLEAR lv_tvarvc.
*      READ TABLE lt_tvarvc INTO lv_tvarvc WITH KEY name = 'Z_PO_FRA1_COND'.
      LOOP AT lt_tvarvc INTO lv_tvarvc WHERE name = 'Z_PO_FRA1_COND'.
        READ TABLE lt_conditions INTO DATA(ls_cond) WITH KEY kschl = lv_tvarvc-low.
        IF sy-subrc IS NOT INITIAL.
          MESSAGE 'Please enter required condition' TYPE 'E'.
          ch_failed = abap_true.
        ELSEIF sy-subrc IS INITIAL AND ls_cond-kbetr IS INITIAL.
          MESSAGE 'Please enter required condition' TYPE 'E'.
          ch_failed = abap_true.
        ENDIF.
      ENDLOOP.
    ENDIF.
*---EOC CR-5072

    CHECK sy-tcode NE 'ME29N'.
    CHECK gv_pstyp NE 'U'.
    IF gv_bsart EQ 'SERV' OR gv_bsart EQ 'SCON'.
      IF gv_pstyp IS INITIAL.
*        ls_poitem  = im_header->get_items( ).
*        lv_pstyp   = ls_poitem-pstyp.
      ENDIF.
      SELECT SINGLE bsart INTO lv_bsart
        FROM zmm_po_vendor
          WHERE ktokk = gv_ktokk
            AND bsart = gv_bsart
            AND pstyp = gv_pstyp.
      IF lv_bsart IS INITIAL.
        MESSAGE e021(zmm) WITH gv_lifnr gv_bsart.
      ENDIF.
    ELSE.
      IF gv_ktokk IS NOT INITIAL AND gv_mtart IS NOT INITIAL AND gv_bsart IS NOT INITIAL.
        SELECT SINGLE ktokk
          INTO lv_ktokk
            FROM zmm_po_vendor
              WHERE ktokk = gv_ktokk
                AND mtart = gv_mtart
                AND bsart = gv_bsart.
        IF lv_ktokk IS INITIAL.
          MESSAGE e021(zmm) WITH gv_lifnr gv_bsart gv_mtart.
        ENDIF.
      ENDIF.
    ENDIF.

*************Begin of changes Added by Raj on 11.07.2024**************************

*       IF sy-tcode = 'ME21N'.
*
*      SELECT SINGLE low FROM tvarvc INTO gs_switch WHERE name = 'ZMM_CON_SWITCH' AND type = 'P'.
*      IF gs_switch = abap_true.
*
*        SELECT sign
*           opti
*           low
*           high INTO TABLE it_type
*                     FROM tvarvc
*                     WHERE name = c_tvarvc_mts AND
*                           type =  c_type_mts.
*
*        READ TABLE it_type INTO wa_type WITH KEY low = gv_bsart.
*        IF sy-subrc = 0.
*
*
*          LOOP AT  lt_details INTO gs_poitem.
*
*            LOOP AT lt_conditions INTO DATA(wa_con) WHERE kposn = gs_poitem-ebelp.
*
*              SELECT ebeln,lifnr,bstyp,kdatb,kdate FROM ekko INTO TABLE @DATA(it_ekko) WHERE lifnr = @gv_lifnr AND bstyp = 'K'.
*
*              IF it_ekko IS NOT INITIAL.
*
*                SELECT ebeln,ebelp,matnr,werks,ktmng,netpr,bstyp,creationdate,creationtime FROM ekpo INTO TABLE @DATA(it_ekpo) FOR ALL ENTRIES IN @it_ekko
*                 WHERE ebeln = @it_ekko-ebeln AND matnr =  @gs_poitem-matnr AND werks = @gs_poitem-werks AND bstyp = 'K' AND loekz NE 'L'.
*
*              ENDIF.
*
*
*              LOOP AT it_ekpo INTO DATA(wa_ekpos).
*                MOVE-CORRESPONDING wa_ekpos TO wa_ekpp.
*                CONCATENATE wa_ekpos-creationdate wa_ekpos-creationtime INTO wa_ekpp-tsl.
*                APPEND wa_ekpp TO it_ekpp.
*                CLEAR : wa_ekpos,wa_ekpp.
*              ENDLOOP.
*
*
*              SORT it_ekpp BY tsl DESCENDING.
*              READ TABLE it_ekpp INTO wa_ekpp INDEX 1.
*
*              lv_konnr = wa_ekpp-ebeln.
*              lv_ktpnr = wa_ekpp-ebelp.
*
*              IF lv_konnr IS NOT INITIAL.
*                SELECT kschl,evrtn,evrtp,datbi,datab,knumh FROM a016 INTO TABLE @DATA(it_a016) WHERE evrtn = @lv_konnr AND evrtp = @lv_ktpnr.
*              ENDIF.
*
*              SORT it_a016 BY datab   DESCENDING.
*              SORT it_a016 BY knumh  DESCENDING.
*
*              READ TABLE it_a016 INTO DATA(wa_a016) INDEX 1.
*              SELECT KNUMH,KOPOS,KAPPL,KSCHL,kbetr FROM konp INTO table @DATA(it_konp) WHERE knumh = @wa_a016-knumh.
*
*
*       if gs_poitem-konnr is not INITIAL.                     "QTY VALIDATIONS
*          IF gs_poitem-menge LE wa_ekpp-ktmng .
*          ELSE.
*            MESSAGE e052(zmm) with gs_poitem-ebelp.
*          ENDIF.
*      ENDIF.
*
*              IF lv_konnr IS NOT INITIAL.                      "PRICE VALIDATIONS
*                READ TABLE it_konp into data(wa_konp) with key kschl = wa_con-kschl.
*                IF  wa_con-kbetr NE wa_konp-kbetr.
*                  MESSAGE e053(zmm) WITH gs_poitem-ebelp.
*                  CLEAR : wa_con.
*                ENDIF.
**              ENDLOOP.
*            endif.
*              CLEAR : wa_con,wa_konp.
*          ENDLOOP.
*          CLEAR : gs_poitem,lv_konnr,wa_con,lv_ktpnr.
*          REFRESH : it_ekko,it_ekpo,it_ekpp,it_a016 .
*     ENDLOOP.
*            ENDIF.
*
*
**        ENDIF.
*      ENDIF.
*    ENDIF.

***********************
    IF sy-tcode = 'ME21N'.

      TYPES : BEGIN OF ty_konps,
                kschl TYPE konp-kschl,
                kbetr TYPE konp-kbetr,
              END OF ty_konps.

      DATA : it_konps TYPE STANDARD TABLE OF ty_konps,
             wa_konps TYPE ty_konps.


******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*      SELECT SINGLE low FROM tvarvc INTO gs_switch WHERE name = 'ZMM_CON_SWITCH' AND type = 'P'.
      SELECT low FROM tvarvc INTO gs_switch UP TO 1 ROWS WHERE name = 'ZMM_CON_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
      ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
      IF gs_switch = abap_true.

        SELECT sign
          opti
          low
          high INTO TABLE it_type
                    FROM tvarvc
                    WHERE name = c_tvarvc_mts AND
                          type =  c_type_mts.

        READ TABLE it_type INTO wa_type WITH KEY low = gv_bsart.
        IF sy-subrc = 0.


          LOOP AT  lt_details INTO gs_poitem.

            SELECT ebeln,lifnr,bstyp,kdatb,kdate FROM ekko INTO TABLE @DATA(it_ekko) WHERE lifnr = @gv_lifnr AND bstyp = 'K'.

            IF it_ekko IS NOT INITIAL.

              SELECT ebeln,ebelp,matnr,werks,ktmng,netpr,bstyp,creationdate,creationtime FROM ekpo INTO TABLE @DATA(it_ekpo) FOR ALL ENTRIES IN @it_ekko
               WHERE ebeln = @it_ekko-ebeln AND matnr =  @gs_poitem-matnr AND werks = @gs_poitem-werks AND bstyp = 'K' AND loekz NE 'L'.

            ENDIF.


            LOOP AT it_ekpo INTO DATA(wa_ekpos).
              MOVE-CORRESPONDING wa_ekpos TO wa_ekpp.
              CONCATENATE wa_ekpos-creationdate wa_ekpos-creationtime INTO wa_ekpp-tsl.
              APPEND wa_ekpp TO it_ekpp.
              CLEAR : wa_ekpos,wa_ekpp.
            ENDLOOP.


            SORT it_ekpp BY tsl DESCENDING.
            READ TABLE it_ekpp INTO wa_ekpp INDEX 1.

            lv_konnr = wa_ekpp-ebeln.
            lv_ktpnr = wa_ekpp-ebelp.

            IF lv_konnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*              SELECT kschl,evrtn,evrtp,datbi,datab,knumh FROM a016 INTO TABLE @DATA(it_a016) WHERE evrtn = @lv_konnr AND evrtp = @lv_ktpnr.
              SELECT kschl,evrtn,evrtp,datbi,datab,knumh FROM a016 INTO TABLE @DATA(it_a016) WHERE evrtn = @lv_konnr AND evrtp = @lv_ktpnr ORDER BY PRIMARY KEY.
******************end of ATC changes 13/02/26   UDAYABAP03*************
            ENDIF.

            SORT it_a016 BY datab   DESCENDING.
            SORT it_a016 BY knumh  DESCENDING.

            READ TABLE it_a016 INTO DATA(wa_a016) INDEX 1.
            SELECT knumh,kopos,kappl,kschl,kbetr FROM konp INTO TABLE @DATA(it_konp) WHERE knumh = @wa_a016-knumh.


            REFRESH : it_konps.
            LOOP AT lt_conditions INTO DATA(wa_con) WHERE kposn = gs_poitem-ebelp AND kposn = gs_poitem-ebelp.
              READ TABLE  it_konp INTO DATA(wa_konp) WITH KEY kschl = wa_con-kschl.
              wa_konps-kschl = wa_con-kschl.
              wa_konps-kbetr = wa_konp-kbetr.
              APPEND wa_konps TO it_konps.
              CLEAR : wa_konps,wa_konp.
            ENDLOOP.

*  endloop.
            IF lv_konnr IS NOT INITIAL.

              IF gs_poitem-konnr IS NOT INITIAL.                     "QTY VALIDATIONS
                IF gs_poitem-menge LE wa_ekpp-ktmng .
                ELSE.
                  MESSAGE e052(zmm) WITH gs_poitem-ebelp.
                ENDIF.
              ENDIF.


*      loop at it_konp into wa_knop.
*        READ TABLE lt_conditions with key kschl = wa_konp-kschl.
*
*        ENDLOOP.

              READ TABLE it_ekko INTO DATA(wa_ekko) WITH KEY ebeln  = lv_konnr. "To get the validity end date consideration check of contract
              IF wa_ekko-kdate GE sy-datum.
                LOOP AT lt_conditions INTO wa_con WHERE kposn = gs_poitem-ebelp AND kposn = gs_poitem-ebelp.
                  IF wa_con-kschl NE 'NAVS'.  " To Skip the NAVS condition type for all NC tax codes.Because of all the NC tax codes contains always NAVS condition type that time system will capture the some amount according to NC tax.
                    READ TABLE it_konp INTO wa_konp WITH KEY kschl = wa_con-kschl.
                    IF sy-subrc = 0.
                      IF wa_con-kbetr IS NOT INITIAL.
                        IF  wa_con-kbetr NE wa_konp-kbetr.
                          MESSAGE e053(zmm) WITH gs_poitem-ebelp.
                          CLEAR : wa_con,wa_konp.
                        ENDIF.
                      ENDIF.
                    ELSE.
                      IF wa_con-kbetr NE 0.
                        READ TABLE it_konps INTO wa_konps WITH KEY kschl =  wa_con-kschl.

                        IF  wa_con-kbetr NE wa_konps-kbetr.
                          MESSAGE e053(zmm) WITH gs_poitem-ebelp.
                          CLEAR : wa_con,wa_konps.
                        ENDIF.
                      ENDIF.
                    ENDIF.
                  ENDIF.
                  CLEAR : wa_konp,wa_con.
                ENDLOOP.
              ENDIF.
              REFRESH : it_konp,it_konps.
            ENDIF.
            CLEAR : gs_poitem.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.
*************Begin of changes Added by Raj on 11.07.2024**************************


  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~close.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_header.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_header_refkeys.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_item.
*......................................................................*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001> Saurabh Saumya     DEVK954730   Task - DEVK954937              *
* Date: 20.01.2026                                                     *
* Reason: Validation for PIR if its's created manually the Net Price   *
*         field shoudld be disabled                                    *
*......................................................................*

*    DATA ls_item TYPE mepoitem.
*    ls_item = im_item->get_data( ).
*    IF ls_item-infnr IS INITIAL.
*      RETURN.
*    ENDIF.
*
*    DATA lv_mode TYPE char10.
*    me->determine_pir_mode(
*      EXPORTING iv_infnr = ls_item-infnr
*                iv_ebeln = ls_item-ebeln
*                iv_ebelp = ls_item-ebelp
*      IMPORTING ev_mode  = lv_mode ).
*
*
*    IF lv_mode = 'MANUAL'.
*      " Make selected pricing fields display-only
*      TRY.
*          " NET PRICE (NETPR)
*          ASSIGN COMPONENT 'NETPR' OF STRUCTURE ch_fieldselection TO FIELD-SYMBOL(<f_netpr>).
*          IF <f_netpr> IS ASSIGNED.
*            ASSIGN COMPONENT 'FIELDSTATUS' OF STRUCTURE <f_netpr> TO FIELD-SYMBOL(<st_netpr>).
*            IF <st_netpr> IS ASSIGNED.
*              <st_netpr> = '*'.
*            ENDIF.
*          ENDIF.
*
**          " PRICE UNIT (PEINH)
**          ASSIGN COMPONENT 'PEINH' OF STRUCTURE ch_fieldselection TO FIELD-SYMBOL(<f_peinh>).
**          IF <f_peinh> IS ASSIGNED.
**            ASSIGN COMPONENT 'FIELDSTATUS' OF STRUCTURE <f_peinh> TO FIELD-SYMBOL(<st_peinh>).
**            IF <st_peinh> IS ASSIGNED.
**              <st_peinh> = '*'.
**            ENDIF.
**          ENDIF.
**
**          " ORDER PRICE UNIT (BPRME)
**          ASSIGN COMPONENT 'BPRME' OF STRUCTURE ch_fieldselection TO FIELD-SYMBOL(<f_bprme>).
**          IF <f_bprme> IS ASSIGNED.
**            ASSIGN COMPONENT 'FIELDSTATUS' OF STRUCTURE <f_bprme> TO FIELD-SYMBOL(<st_bprme>).
**            IF <st_bprme> IS ASSIGNED.
**              <st_bprme> = '*'.
**            ENDIF.
**          ENDIF.
*
*        CATCH cx_sy_assign_cast_illegal_cast cx_sy_move_cast_error.
*          " Fail silently; CHECK method still blocks on save
*      ENDTRY.
*    ENDIF.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_item_refkeys.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~initialize.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~open.
*......................................................................*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001> Saurabh Saumya     DEVK954730   Task - DEVK954937              *
* Date: 20.01.2026                                                     *
* Reason: Validation for PIR if its's created manually the Net Price   *
*         field shoudld be disabled                                    *
*......................................................................*
*    me->md_trtyp = im_trtyp.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~post.
     DATA  : ls_header TYPE mepoheader   .
    ls_header  = im_header->get_data( ).


  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_account.

*    DATA: ls_acc   TYPE mepoaccounting,
*          lv_posid TYPE prps-posid.
*
*    ls_acc = im_account->get_data( ).

*    DATA: ls_acc       TYPE mepoaccounting,
*          lv_posid_ext TYPE ps_posid,
*          lv_pspnr type ps_psp_pnr.
*
*    " Get EKKN-like structure
*    ls_acc =  im_account->get_data( ) .
*
*    " Only relevant when account assignment category is WBS
**  IF ls_acc-knttp = 'P'.
*    IF ls_acc-ps_psp_pnr IS NOT INITIAL.
*      lv_pspnr = ls_acc-ps_psp_pnr.
*      " Convert internal PSPNR -> external POSID (for display/log)
*      CALL FUNCTION 'CONVERSION_EXIT_ABPSp_OUTPUT'
*        EXPORTING
*          input  = lv_pspnr
*        IMPORTING
*          output = lv_posid_ext.
*      " Use lv_posid_ext or ls_acc-ps_psp_pnr as needed
*    ENDIF.
*  ENDIF.







  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_header.
    DATA  : ls_poheader TYPE mepoheader   .
    DATA : gt_t052s  TYPE STANDARD TABLE OF t052s,
           gt_t052s1 TYPE STANDARD TABLE OF t052s,
           gw_t052s  TYPE t052s.
    DATA:tekpo TYPE TABLE OF bekpo.
    DATA:lv_val  TYPE ktmng,
         lv_val2 TYPE ktmng,
         lv_val1 TYPE ktmng.

    TYPES :BEGIN OF st_po,
             ebeln TYPE ekpo-ebeln,
             ebelp TYPE ekpo-ebelp,
             menge TYPE ekpo-menge,
             netpr TYPE ekpo-netpr,
           END OF st_po.
    DATA:it_ekpo TYPE TABLE OF st_po,
         wa_ekpo TYPE st_po.


    ls_poheader  = im_header->get_data( ).
    gv_bsart = ls_poheader-bsart.
    gv_lifnr = ls_poheader-lifnr.
    gv_bukrs = ls_poheader-bukrs.

* CALL METHOD im_item->set_data( ls_poitem ).
    SELECT SINGLE ktokk
             FROM lfa1
               INTO gv_ktokk
                 WHERE lifnr = gv_lifnr.
    IF ls_poheader-reswk IS NOT INITIAL.
      gv_reswk = ls_poheader-reswk.
    ENDIF.
    CLEAR : gv_dppct,gv_dptyp,gv_dpdat,gv_dpamt.
***** Fill Down Payment Percentage based on Payment Terms
*    Beggin of SAW on 20.11.2023
*    DATA lt_tvarvc TYPE TABLE OF tvarvc.
    SELECT * FROM tvarvc INTO TABLE @DATA(lt_tvarvc).
    READ TABLE lt_tvarvc INTO DATA(ls_tvarvc) WITH KEY name = 'Z_ADV_PAYMENT_CREATE' low = sy-tcode.
    IF sy-subrc = 0. " ls_tvarvc-name = 'Z_ADV_PAYMENT_CREATE'. " sy-subrc = 0.
      READ TABLE lt_tvarvc INTO DATA(ls_tvarvc1) WITH KEY name = 'Z_PO_DOCUMENT TYPE' low = ls_poheader-bsart. " by SAW on 4.12.2022
      IF sy-subrc = 0.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*        SELECT *
*          INTO TABLE gt_t052s FROM t052s WHERE zterm = ls_poheader-zterm AND ratzt = 'DP01'.

        SELECT *
        INTO TABLE gt_t052s FROM t052s WHERE zterm = ls_poheader-zterm AND ratzt = 'DP01' ORDER BY PRIMARY KEY.
******************end of ATC changes 13/02/26   UDAYABAP03*************
        LOOP AT gt_t052s INTO gw_t052s.
          gv_dppct = gv_dppct + gw_t052s-ratpz.
        ENDLOOP.
      ENDIF.
*        SELECT single ratpz INTO @data(lv_ratpz1) FROM t052s WHERE zterm = @ls_poheader-zterm AND ratzt = 'DP01'.
*        gv_dppct = gv_dppct + lv_ratpz1. "gw_t052s-ratpz.
    ENDIF.
*    End of SAW on 20.11.2023

*    commented by SAW 1.11.2023
*    IF sy-tcode = 'ME21N'.
*      SELECT *
*          INTO TABLE gt_t052s FROM t052s WHERE zterm = ls_poheader-zterm AND ratzt = 'DP01'.
*      LOOP AT gt_t052s INTO gw_t052s.
*        gv_dppct = gv_dppct + gw_t052s-ratpz.
*      ENDLOOP.
*    ENDIF.
*    commented end by SAW 1.11.2023
**************Begin of SAW 1.11.2023**********
    CLEAR ls_tvarvc.
    READ TABLE lt_tvarvc INTO ls_tvarvc WITH KEY name = 'Z_ADV_PAYMENT_CHANGE' low = sy-tcode.
    IF sy-subrc = 0.
      READ TABLE lt_tvarvc INTO DATA(ls_tvarvc2) WITH KEY name = 'Z_PO_DOCUMENT TYPE' low = ls_poheader-bsart. " by SAW on 4.12.2022
      IF sy-subrc = 0.
        DATA(lv_count) = 0.
*    IF ls_tvarvc-name = 'Z_ADV_PAYMENT_CHANGE'.  "sy-tcode = 'ME22N'.
        SELECT COUNT(*) INTO @DATA(lv_item_ekpo) FROM ekpo WHERE ebeln = @ls_poheader-ebeln.
        SELECT ebeln, ebelp, bewtp, shkzg, dmbtr
               FROM ekbe INTO TABLE @DATA(lt_ekbe)
               WHERE ebeln = @ls_poheader-ebeln AND bewtp = 'A'.
        IF lt_ekbe IS NOT INITIAL.
          lv_count = lines( lt_ekbe ) / lv_item_ekpo.
          LOOP AT lt_ekbe INTO DATA(ls_ekbe) WHERE shkzg = 'H'.
            READ TABLE lt_ekbe INTO DATA(ls_ekbe1) WITH KEY shkzg = 'S'.
            IF lt_ekbe IS NOT INITIAL AND ls_ekbe1-dmbtr = ls_ekbe-dmbtr.
              lv_count = lv_count - 2.
            ENDIF.
          ENDLOOP.
          lv_count = lv_count + 1.
        ELSE.
          lv_count = lv_count + 1.
        ENDIF.
*      BREAK-POINT.
*      SELECT SINGLE ratpz FROM t052s INTO @DATA(lv_ratpz) WHERE zterm = @ls_poheader-zterm AND ratnr = @lv_count.
        SELECT SINGLE ratpz , ratzt FROM t052s INTO @DATA(lv_ratpz) WHERE zterm = @ls_poheader-zterm AND ratnr = @lv_count.
        IF sy-subrc = 0.
          gv_dppct = lv_ratpz-ratpz.
        ELSE.
          IF lv_ratpz IS NOT INITIAL.
            SELECT SINGLE zterm FROM t052 INTO @DATA(ls_to52) WHERE zterm = @lv_ratpz-ratzt.
          ELSE.
            SELECT SINGLE zterm FROM t052 INTO @ls_to52 WHERE zterm = @ls_poheader-zterm.
          ENDIF.
          IF sy-subrc <> 0.
            MESSAGE 'Please check down payment completed or Payment term is not valid' TYPE 'E'.
          ENDIF.
        ENDIF.

*****        To change amount of down payment
        IF gv_dppct IS NOT INITIAL.
*          ls_poheader-dppct = gv_dppct.
          " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
*         IMPORT tekpo  TO tekpo FROM   MEMORY ID 'IT_FINAL'.
          IMPORT tekpo TO tekpo FROM MEMORY ID 'IT_FINAL'  ACCEPTING PADDING .
          " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
          FREE MEMORY ID 'IT_FINAL'.
          IMPORT it_ekpo  TO it_ekpo FROM   MEMORY ID 'IT_EKPO'.
          FREE MEMORY ID 'IT_EKPO'.

          LOOP AT tekpo INTO DATA(ls_ekpo).
            lv_val = ls_ekpo-netpr * ls_ekpo-menge.
            lv_val2 = lv_val2 + lv_val.
            CLEAR lv_val.
          ENDLOOP.
          lv_val1 = ( ( lv_val2 * ls_poheader-dppct ) / 100 ).
          ls_poheader-dpamt = lv_val1.

          CLEAR:lv_val2,lv_val1. "END OF PSK
          CALL METHOD im_header->set_data( ls_poheader ).
        ENDIF.
*    ELSEIF sy-tcode = 'ME21N'.
*      lv_count = lv_count + 1.
*      SELECT SINGLE ratpz FROM t052s INTO lv_ratpz WHERE zterm = ls_poheader-zterm AND ratnr = lv_count.
*      IF sy-subrc = 0.
*        gv_dppct = lv_ratpz.
      ENDIF.
    ENDIF.
**************End of SAW 1.11.2023**********

    IF gv_dppct IS NOT INITIAL.
      ls_poheader-dppct = gv_dppct.

      CALL METHOD im_header->set_data( ls_poheader ).
    ENDIF.

**************Begin of SAW 2.11.2023 to change amount of down payment on screen according to percentage**********
*      IF sy-tcode = 'ME22N' AND gv_dppct IS NOT INITIAL.
**      SELECT ebeln, rlwrt, dpamt, dppct, zterm
**             FROM ekko INTO TABLE @DATA(lt_ekko)
**             WHERE ebeln = @ls_poheader-ebeln AND zterm = @ls_poheader-zterm.
**      READ TABLE lt_ekko INTO DATA(ls_ekko) WITH KEY ebeln = ls_poheader-ebeln.
**      gv_dpamt = ( ( ls_ekko-rlwrt ) * gv_dppct ) / 100.
**      IF gv_dpamt IS NOT INITIAL.
**        ls_poheader-dpamt = gv_dpamt.
*        "ADDED BY PSK ON 19.11.2023
*        IF sy-tcode = 'ME22N'.
**          IMPORT tekpo  TO tekpo FROM   MEMORY ID 'IT_FINAL'.
**          FREE MEMORY ID 'IT_FINAL'.
**          IMPORT it_ekpo  TO it_ekpo FROM   MEMORY ID 'IT_EKPO'.
**          FREE MEMORY ID 'IT_EKPO'.
**
**          LOOP AT tekpo INTO DATA(ls_ekpo).
**            lv_val = ls_ekpo-netpr * ls_ekpo-menge.
**            lv_val2 = lv_val2 + lv_val.
**            CLEAR lv_val.
**          ENDLOOP.
**          lv_val1 = ( ( lv_val2 * ls_poheader-dppct ) / 100 ).
**          ls_poheader-dpamt = lv_val1.
*        ENDIF.
**        CLEAR:lv_val2,lv_val1. "END OF PSK
**        CALL METHOD im_header->set_data( ls_poheader ).
**      ENDIF.
**    ELSEIF sy-tcode = 'ME21N' AND gv_dppct IS NOT INITIAL.
***      gv_dpamt = value from selection screen(total value) / gv_dppct.
*      ENDIF.
**************End of SAW 2.11.2023**********
    """"""""psk tem

***********
* IF gv_dppct IS INITIAL AND ls_poheader-dppct > '0.00'.
**   if ls_poheader-zterm <> 'P001'.
**   MESSAGE : 'Payment Terms Not Valid for DPR' TYPE 'E'.
**  ENDIF.
*ENDIF.
    gv_dptyp = ls_poheader-dptyp.
    gv_dppct = ls_poheader-dppct.
    gv_dpdat = ls_poheader-dpdat.
    gv_dpamt = ls_poheader-dpamt.
    .
*    IF  gv_lifnr IS NOT INITIAL.
*      IF gv_bsart = 'CAPT'.
*        IF gv_ktokk <> 'ZDCG'.
*          MESSAGE 'VENDOR IS NOT FOR CAPITAL PURCHASE ' TYPE 'E'.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*    IF ls_poheader-bedat <> sy-datum.
*      MESSAGE 'Purchase Order Date Cannot be Furture Date' TYPE 'E'.
*    ENDIF.


*   * Changes by Sayali
* Vendor Class and  GSTIN Validation
*BREAK-POINT.
    TYPE-POOLS: mmmfd.
    INCLUDE mm_messages_mac.
    DATA : wa_data       TYPE mepoheader,
           wa_lfa1       TYPE  lfa1,
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*             wa_j_1imovend TYPE j_1imovend,
           wa_j_1imovend TYPE lfa1,
******************End of ATC changes 13/02/26   UDAYABAP03*************
           lv_msg        TYPE string.



    wa_data = im_header->get_data( ).
*if wa_data-bsart is not initial and wa_data-bsart <> 'NB' .


    IF  wa_data-lifnr IS NOT INITIAL .


*************get data from j_1imovend*************************
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*        SELECT SINGLE * FROM j_1imovend
      SELECT SINGLE * FROM lfa1
******************End of ATC changes 13/02/26   UDAYABAP03*************
             INTO wa_j_1imovend
             WHERE lifnr = wa_data-lifnr.


************************************************************
      CALL FUNCTION 'GET_VENDOR_DETAILS'
        EXPORTING
          i_lifnr         = wa_data-lifnr
        IMPORTING
          e_lfa1          = wa_lfa1
        EXCEPTIONS
          not_found       = 1
          parameter_error = 2
          OTHERS          = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ELSE.


        IF wa_lfa1-land1 = 'IN' AND wa_j_1imovend-ven_class = ' ' AND wa_lfa1-stcd3 IS INITIAL.
          mmpur_message_forced 'E' 'FV' '00' 'Vendor' wa_lfa1-lifnr '-' ' GST Registration Number is Missing' .
          CONCATENATE 'Vendor' wa_lfa1-lifnr '- GST Registration Number is Missing' INTO lv_msg.
          MESSAGE e000(fv) WITH lv_msg DISPLAY LIKE 'E' .



        ELSEIF wa_lfa1-land1 = 'IN' AND wa_j_1imovend-ven_class = '1' AND wa_lfa1-stcd3 IS INITIAL.
          mmpur_message_forced 'E' 'FV' '00' 'Vendor' wa_lfa1-lifnr '-' ' GST Registration Number is Missing'.
          CONCATENATE 'Vendor' wa_lfa1-lifnr '-' ' GST Registration Number is Missing' INTO lv_msg.
          MESSAGE e000(fv) WITH lv_msg DISPLAY LIKE 'E' .


*        ELSEIF wa_lfa1-land1 = 'IN' AND wa_j_1imovend-ven_class = '0'. "AND wa_lfa1-stcd3 IS NOT INITIAL.
*          mmpur_message_forced 'E' 'FV' '00' 'Vendor' wa_lfa1-lifnr '-' ' Vendor not Registered'.
*          CONCATENATE 'Vendor' wa_lfa1-lifnr '- Vendor not Registered' INTO lv_msg.



*        elseif wa_lfa1-LAND1 = 'IN' and wa_j_1imovend-ven_class = '0' and wa_lfa1-stcd3 is initial.
*          mmpur_message_forced 'E' 'FV' '00' 'Vendor' wa_lfa1-lifnr '-' ' Vendor not Registered and GST Registration Number is Missing' .
*          concatenate 'Vendor' wa_lfa1-lifnr '- Vendor not Registered and GST Registration Number is Missing' into lv_msg.

        ENDIF.
      ENDIF.


    ENDIF.

* Changes by Sayali
*BREAK-POINT.
*  DATA  : ls_poversion TYPE erevitem         .

*   ls_poversion = im_item->get_data( ).
*  DATA ls_poversion1 type erev.
*  ls_poversion  = im_header->get_data( ).

*    ls_poversion  = im_header->get_data( ).

********added by raghavendra to validate version tab in Me22n.
    DATA : lt_erev TYPE STANDARD TABLE OF erev.
    DATA :     ls_erev TYPE erev.

*SELECT * from erev into table lt_erev where EDOKN = ls_poheader-ebeln.
*  sort lt_erev by revno DESCENDING  .
*
*  Delete ADJACENT DUPLICATES FROM lt_erev COMPARING EDOKN.
*
* READ TABLE lt_erev into ls_erev INDEX 1.
*If sy-tcode = 'ME22N'.
*  if ls_erev-revok is INITIAL.
*    MESSAGE 'Please check the version indicator is complete' type 'E'.
*    endif.
*
*    ENdif.
***********ENd by raghavendra

****    DATA: ls_header  TYPE mepoheader,
****          lv_lifnr   TYPE lifnr,
****          lv_partner TYPE bu_partner,
****          lt_addr    TYPE TABLE OF but020,
****          ls_addr    TYPE but020,
****          lt_popup   TYPE TABLE OF spopli,
****          ls_popup   TYPE spopli,
****          lv_choice  TYPE i,
****          lv_adrnr   TYPE adrnr,
****          lo_header  TYPE REF TO if_purchase_order_mm.
****
****    DATA: lv_skip_popup TYPE char1.
****
***** Get PO header
****    ls_header = im_header->get_data( ).
****
***** Get vendor
****    lv_lifnr = ls_header-lifnr.
****
****    IF lv_lifnr IS INITIAL.
****      RETURN.
****    ENDIF.
****
***** Get BP from vendor
****    SELECT SINGLE vendor
****      INTO lv_partner
****      FROM cvi_vend_link
****      WHERE vendor = lv_lifnr.
****
****    IF sy-subrc <> 0.
****      RETURN.
****    ENDIF.
****
***** Get addresses
****    SELECT *
****      INTO TABLE lt_addr
****      FROM but020
****      WHERE partner = lv_partner.
****
****    IF lines( lt_addr ) <= 1.
****      RETURN.
****    ENDIF.
****
***** Prepare popup list
****    LOOP AT lt_addr INTO ls_addr.
****      ls_popup-varoption = |Address No: { ls_addr-addrnumber }|.
****      APPEND ls_popup TO lt_popup.
****    ENDLOOP.
****
****    IMPORT ev_processed = lv_skip_popup FROM MEMORY ID 'PO_POPUP_LOCK'.
****
****    IF lv_skip_popup IS INITIAL AND lines( lt_popup ) > 1.
***** Show popup
****      CALL FUNCTION 'POPUP_TO_DECIDE_LIST'
****        EXPORTING
****          cursorline = '1'
****          mark_max   = '1'
****          textline1  = 'Select Vendor Address'
****          titel      = 'Address Selection'
****        IMPORTING
****          answer     = lv_choice
****        TABLES
****          t_spopli   = lt_popup.
****
****      READ TABLE lt_addr INTO ls_addr INDEX lv_choice.
****
****      IF sy-subrc = 0.
****
****        lv_adrnr = ls_addr-addrnumber.
****
***** Set address into PO header
****        ls_header-adrnr = lv_adrnr.
****
****        im_header->set_data( ls_header ).
****
****      ENDIF.
****
****      EXPORT ev_processed = 'X' TO MEMORY ID 'PO_POPUP_LOCK'.
****
****    ELSE.
****      " Flag exists; skip execution to avoid infinite loop
****      RETURN.
****    ENDIF.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_item.
*......................................................................*
* Version Create/Change Owner     TR           CR/ID                   *
* Date:                                                                *
* Reason:                                                              *
*......................................................................*
* <001> Saurabh Saumya     DEVK954730   Task - DEVK954937              *
* Date: 20.01.2026                                                     *
* Reason: Validation for PIR if its's created manually the Net Price   *
*         field shoudld be disabled                                    *
*......................................................................*
* <002> Archna Gupta    DEVK954730   Task - DEVK902669                 *
* Date: 25.02.2026                                                     *
* Reason: Validation for WBS element raise a error message Multiple wbs*
*    not allowed for a single line item.                               *
*......................................................................*
**    DATA ls_item TYPE mepoitem.
**    ls_item = im_item->get_data( ).
*
*    " 1) Initialize protected condition types once (extend as needed)
*    IF me->mt_prot_kschl IS INITIAL.
*      APPEND 'PB00' TO me->mt_prot_kschl.
*      APPEND 'PBXX' TO me->mt_prot_kschl.
*      " Add any other condition types that must NOT be changed for manual PIRs
*    ENDIF.
*
*    " 2) Read item
*    DATA(ls_item) = im_item->get_data( ).
*    IF ls_item-ebelp IS INITIAL.
*      RETURN.
*    ENDIF.
*
*    " 3) If we already stored baseline for this EBELP, skip
*    READ TABLE me->mt_base_cond WITH KEY ebelp = ls_item-ebelp TRANSPORTING NO FIELDS.
*    IF sy-subrc = 0.
*      RETURN.
*    ENDIF.
*
*    " 4) Get current conditions (type inferred from system)
*    CALL METHOD im_item->get_conditions
*      IMPORTING
*        ex_conditions = DATA(lt_now).
*
*    " 5) Create a deep copy into a generic ref so we don't depend on DDIC names
*    DATA lr_copy TYPE REF TO data.
*    CREATE DATA lr_copy LIKE lt_now.
*    ASSIGN lr_copy->* TO FIELD-SYMBOL(<lt_copy>).
*    <lt_copy> = lt_now.
*
*    " 6) Insert into baseline store
*    INSERT VALUE lty_base_cond( ebelp = ls_item-ebelp cond_ref = lr_copy )
*      INTO TABLE me->mt_base_cond.

    DATA  : ls_poitem  TYPE mepoitem,
            ls_poitem1 TYPE mepoitem,
            lv_pstyp   TYPE pstyp,
            lv_bwtar   TYPE bwtar_d,
            lt_zdomes  TYPE STANDARD TABLE OF komv,
            it_komv    TYPE STANDARD TABLE OF komv,
            wa_komv    TYPE komv,
            wa_zdomes  TYPE komv,
            lv_taxcom  TYPE taxcom,
            wa_ekpo    TYPE ekpo,
            wa_ekko    TYPE ekko,
            t_werks    TYPE STANDARD TABLE OF selopt,
            r_werks    TYPE selopt,
            lv_vgabe   TYPE vgabe.

    DATA : lv_pr TYPE mepoitem-banfn.      "Added By Soham Upadhyay 08.04.2017

    DATA : l_item_cond TYPE mmpur_tkomv.
    TYPES: BEGIN OF t_final,
             matnr TYPE mara-matnr,
             werks TYPE t001w-werks,
           END OF t_final.

    DATA: it_final TYPE STANDARD TABLE OF t_final,
          wa_final TYPE t_final.

    DATA : it_j_1imtchid TYPE STANDARD TABLE OF j_1imtchid,
           wa_j_1imtchid TYPE j_1imtchid.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*    DATA : it_excd TYPE STANDARD TABLE OF j_1imovend,
    DATA : it_excd TYPE STANDARD TABLE OF lfa1,
******************End of ATC changes 13/02/26   UDAYABAP03*************
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*           wa_excd TYPE j_1imovend.
           wa_excd TYPE lfa1.
******************End of ATC changes 13/02/26   UDAYABAP03*************

    FIELD-SYMBOLS : <fs_zdomes> TYPE ANY TABLE." lt_zdomes.
    FIELD-SYMBOLS : <fs_ekpo>  TYPE ANY TABLE, "ekpo,
                    <fs_ekpo1> TYPE ekpo.
    FIELD-SYMBOLS : <fs_ekko>  TYPE ANY TABLE, "ekpo,
                    <fs_ekko1> TYPE ekko.
    DATA:  lv_len TYPE i.
    DATA : v_werks(4). "TYPE I.      " Change by Soham Upadhyay 12.04.2017
    DATA: v_kostl(10).
    DATA: gv_type(4).
************    add for hsn length check 04.06.2021
    DATA : it_lhsn TYPE STANDARD TABLE OF zsd_hsn_len,
           wa_lhsn TYPE zsd_hsn_len.
    DATA: v_matnr TYPE mara-matnr,
          v_mtart TYPE mara-mtart.

    DATA : llen TYPE i.
    DATA : htype TYPE dd01v-datatype.
**********************
***********    added by parth 10.10.2020
    TYPES: BEGIN OF ty_tvarv,
             sign TYPE tvarv_sign,
             opti TYPE tvarv_opti,
             low  TYPE tvarv_val,
             high TYPE tvarv_val,
           END OF ty_tvarv.

    DATA: lt_acc_key  TYPE STANDARD TABLE OF ty_tvarv,
          lwa_acc_key TYPE ty_tvarv.
    DATA: lt_acc_t  TYPE STANDARD TABLE OF ty_tvarv,
          lwa_acc_t TYPE ty_tvarv.

    DATA: lt_acc_po  TYPE STANDARD TABLE OF ty_tvarv, "Added by Raj on 27.12.2023
          lwa_acc_po TYPE ty_tvarv.                      "Added by Raj on 27.12.2023


    DATA: lt_acc_mt  TYPE STANDARD TABLE OF ty_tvarv, "Added by Raj on 11.01.2023
          lwa_acc_mt TYPE ty_tvarv.

    CONSTANTS :c_tvarvc_po TYPE rvari_vnam VALUE 'Z_PO_PRICE',  "Added by Raj on 27.12.2023
               c_type_po   TYPE rsscr_kind VALUE 'S'.            "Added by Raj on 27.12.2023

    CONSTANTS :c_tvarvc_mt TYPE rvari_vnam VALUE 'Z_PO_MT',  "Added by Raj on 27.12.2023
               c_type_mt   TYPE rsscr_kind VALUE 'S'.            "Added by Raj on 27.12.2023

    DATA  : gs_poitem  TYPE mepoitem."Added by Raj on 08.07.2024
    DATA  : gs_pohead  TYPE mepoitem."Added by Raj on 08.07.2024
    DATA :gs_switch(1) TYPE c."Added by Raj on 08.07.2024

    DATA: it_type TYPE STANDARD TABLE OF ty_tvarv, "Added by Raj on 08.07.2024
          wa_type TYPE ty_tvarv.    "Added by Raj on 08.07.2024


    CONSTANTS :c_tvarvc_mts TYPE rvari_vnam VALUE 'ZMM_PO_TYPES',  "Added by Raj on 08.07.2024
               c_type_mts   TYPE rsscr_kind VALUE 'S'.            "Added by Raj on 08.07.2024
    DATA : lv_konnr TYPE ekko-konnr."Added by Raj on 08.07.2024
    DATA : lv_ktpnr TYPE ekpo-ebelp."Added by Raj on 08.07.2024
    DATA : lv_netpr  TYPE ekpo-netpr."Added by Raj on 08.07.2024



    TYPES : BEGIN OF ty_ekpp,
              creationdate TYPE ekpo-creationdate,
              creationtime TYPE ekpo-creationtime,
              ebeln        TYPE ekpo-ebeln,
              ebelp        TYPE ekpo-ebelp,
              werks        TYPE ekpo-werks,
              matnr        TYPE ekpo-matnr,
              ktmng        TYPE ekpo-ktmng,
              netpr        TYPE ekpo-netpr,
              bstyp        TYPE ekpo-bstyp,
              tsl          TYPE string,
            END OF ty_ekpp.

    DATA : it_ekpp TYPE STANDARD TABLE OF ty_ekpp,
           wa_ekpp TYPE ty_ekpp.



**** Added by Carina Jose on 31.01.2022
    DATA: lt_acc_p  TYPE STANDARD TABLE OF ty_tvarv,
          lwa_acc_p TYPE ty_tvarv.
    CONSTANTS : c_tvarvc_p TYPE rvari_vnam VALUE 'PO_PLANT',
                c_type_p   TYPE rsscr_kind VALUE 'S'.
**** End of changes by Carina Jose on 31.01.2022

**************    added by parth 15.06.2022
    DATA: lt_acc_tk TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_tk TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_tk TYPE rvari_vnam VALUE 'ACCOUNT_PO_TYPE',
               c_type_tk   TYPE rsscr_kind VALUE 'S'.

    DATA: lt_acc_k TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_k TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_k TYPE rvari_vnam VALUE 'ACCOUNT_MAT_TYPE',
               c_type_k   TYPE rsscr_kind VALUE 'S'.


    DATA: lt_acc_capt TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_capt TYPE ty_tvarv.
    CONSTANTS :c_tvarvc_ct TYPE rvari_vnam VALUE 'CAPT_PO_TYPE',
               c_type_ct   TYPE rsscr_kind VALUE 'S'.

    DATA: lt_acc_capk TYPE STANDARD TABLE OF ty_tvarv,
          lw_acc_capk TYPE ty_tvarv.

    CONSTANTS :c_tvarvc_ck TYPE rvari_vnam VALUE 'CAPT_MAT_TYPE',
               c_type_ck   TYPE rsscr_kind VALUE 'S'.

    DATA: wa_mtart_type TYPE char200.
    DATA: wa_po_type TYPE char200.


*********

    CONSTANTS:
      c_tvarvc_name TYPE rvari_vnam VALUE 'VALUTION_PLANT',
      c_type_user   TYPE rsscr_kind VALUE 'S',

      c_tvarvc_t    TYPE rvari_vnam VALUE 'VALUTION_TYPE',
      c_type_t      TYPE rsscr_kind VALUE 'S'.
*******
    "Adding Start by Rahul Vasita on 10.05.2024 14:39:48
    TYPES : BEGIN OF ty_hkont,
              hkont TYPE saknr,
            END OF ty_hkont.
    DATA : lt_hkont     TYPE TABLE OF ty_hkont,
           ls_hkont     TYPE ty_hkont,
           lv_msg_e     TYPE char255,
           lv_switch(1) TYPE c.
    CLEAR : lv_switch , lv_msg_e , ls_hkont.
    REFRESH : lt_hkont[].
    "Adding End by Rahul Vasita on 10.05.2024 14:39:48

    ls_poitem  = im_item->get_data( ).

    IF sy-tcode = 'ME22N'. "added by psk
      DATA(total_a) =  ls_poitem-menge * ls_poitem-netpr.
    ENDIF.
    gv_mtart   = ls_poitem-mtart.
    lv_pstyp   = ls_poitem-pstyp.
    gv_bwtar   = ls_poitem-bwtar.
    lv_pr      = ls_poitem-banfn.         "Added By Soham Upadhyay 08.04.2017
    wa_final-matnr   = ls_poitem-matnr.
    wa_final-werks   = ls_poitem-werks.

***** Added changes by Carina Jose on 31.01.2022
    SELECT sign
       opti
       low
       high INTO TABLE lt_acc_p
                 FROM tvarvc
                 WHERE name = c_tvarvc_p AND
                       type =  c_type_p.
***** End of changes by Carina Jose on 31.01.2022
****************   add changes by parth  15.06.2022

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_tk
               FROM tvarvc
               WHERE name = c_tvarvc_tk AND
                     type =  c_type_tk.

    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_k
               FROM tvarvc
               WHERE name = c_tvarvc_k AND
                     type =  c_type_k.


    SELECT sign
   opti
   low
   high INTO TABLE lt_acc_capt
             FROM tvarvc
             WHERE name = c_tvarvc_ct AND
                   type =  c_type_ct.

*    SELECT SINGLE low
*           INTO wa_po_type
*           FROM tvarvc
*           WHERE name = c_tvarvc_ct  .

    SELECT sign
    opti
    low
    high INTO TABLE lt_acc_capk
              FROM tvarvc
              WHERE name = c_tvarvc_ck AND
                    type =  c_type_ck.


*    SELECT SINGLE low
*         INTO wa_mtart_type
*         FROM tvarvc
*         WHERE name = c_tvarvc_ck .

***************      end of changes by parth 15.06.2022

**********Added by Raj on 27.12.2023******

    SELECT sign
       opti
       low
       high INTO TABLE lt_acc_po
                 FROM tvarvc
                 WHERE name = c_tvarvc_po AND
                       type =  c_type_po.



    SELECT sign
         opti
         low
         high INTO TABLE lt_acc_mt
                   FROM tvarvc
                   WHERE name = c_tvarvc_mt AND
                         type =  c_type_mt.






*******Added by Raj on 27.12.2023********

**********************************************************************
****      Added By Soham Upadhyay 08.04.2017
**********************************************************************
*    IF gv_bsart = 'GNRL' OR gv_bsart = 'CAPT' OR gv_bsart = 'SERV'.
    IF gv_bsart = 'ZRAW' OR gv_bsart = 'ZPKG' OR gv_bsart = 'SERV'
        OR gv_bsart = 'ZTRD'
        OR  gv_bsart = 'ZIND'
        OR  gv_bsart = 'ZHOD'
        OR  gv_bsart = 'ZSUB'
        OR  gv_bsart = 'ZMCP'
        OR  gv_bsart = 'ZSCP'.
      IF ls_poitem-uebto > '15.0'.
        MESSAGE : 'Overdelivery Tolerance Limit SHOULD BE <=15%' TYPE 'E'.
      ENDIF.
      IF ls_poitem-untto > '5.0'.
        MESSAGE : 'Underdelivery Tolerance Limit SHOULD BE <= 5%' TYPE 'E'.
      ENDIF.
*      IF ls_poitem-werks = '1701' OR ls_poitem-werks = '1702' OR ls_poitem-werks = '1703' OR ls_poitem-werks = '1704'. " commented by Carina Jose on 31.01.2022
      READ TABLE lt_acc_p INTO lwa_acc_p WITH KEY low = ls_poitem-werks. " Added by Carina Jose on 31.01.2022
      IF sy-subrc = 0." Added by Carina Jose on 31.01.2022
      ELSE.
        IF lv_pr IS INITIAL.
          MESSAGE : 'Please Enter Purchase Requisition Number' TYPE 'E'.
        ENDIF.
      ENDIF.
      CLEAR :lwa_acc_p.
    ENDIF.
**********************************************************************
****      End of Change By Soham Upadhyay 08.04.2017
**********************************************************************
    SELECT SINGLE epstp FROM t163y INTO gv_pstyp WHERE spras = sy-langu
                                                   AND pstyp = lv_pstyp.

*****************      10.10.2020 VALUTION TYPE LOGIC CHANGES
    SELECT sign
     opti
     low
     high INTO TABLE lt_acc_key
               FROM tvarvc
               WHERE name = c_tvarvc_name AND
                     type =  c_type_user.
    SELECT sign
       opti
       low
       high INTO TABLE lt_acc_t
                 FROM tvarvc
                 WHERE name = c_tvarvc_t AND
                       type =  c_type_t.

    READ TABLE lt_acc_key INTO lwa_acc_key WITH KEY low = gv_reswk.
    IF sy-subrc = 0.
*     endif.
*********************

*    IF gv_reswk IS NOT INITIAL AND gv_bsart = 'UB' .
************************ comment by parth 10.10.2020
*    IF gv_reswk = '1000' OR  gv_reswk = '1100' OR  gv_reswk = '1200' OR
*       gv_reswk = '1401' OR  gv_reswk = '1500' OR  gv_reswk = '2000' OR gv_reswk = '2200' OR  gv_reswk = '2300' .
*********************** comment end by parth 10.10.2020

      "or gv_reswk = '1615'.
      READ TABLE lt_acc_t INTO lwa_acc_t WITH KEY low = gv_bsart.
      IF sy-subrc = 0.
        gv_type = lwa_acc_t-low.
      ENDIF.
********************      comment by parth 10.10.2020
*      IF gv_reswk IS NOT INITIAL AND ( gv_bsart = 'ZUB1' OR gv_bsart = 'ZUB2' OR gv_bsart = 'YRCL' OR gv_bsart = 'ZRCL' OR gv_bsart = 'ZFGS' ).
*********************    comment end by 10.10.2020
*************      added by parth 10.10.2020
      IF gv_reswk IS NOT INITIAL AND ( gv_bsart = gv_type ).
*************      ended by parth 10.10.2020
*      r_werks-sign = 'I'.
*      r_werks-option = 'CP'.
*      CONCATENATE gv_reswk '*' INTO r_werks-low.
*      APPEND r_werks TO t_werks.
*      SELECT SINGLE bwtar
*               FROM mbew
*                 INTO lv_bwtar
*                  WHERE matnr = ls_poitem-matnr
*                    AND bwkey = ls_poitem-werks
*                    AND bwtar IN t_werks.
**      gv_flag = 'X'.

        lv_bwtar = gv_reswk.
        IF ls_poitem-bwtar IS INITIAL.
          ls_poitem-bwtar = lv_bwtar.
          CALL METHOD im_item->set_data( ls_poitem ).
        ENDIF.
*      IF sy-subrc EQ 0.
*      ELSE.
*        CLEAR gv_flag.
*      ENDIF.
*    ELSEIF gv_reswk IS INITIAL AND gv_bsart = 'UB' ."COMMENT BY PARTH AFTER GST
*************************************************        comment by parth 10.10.2020
*      ELSEIF gv_reswk IS INITIAL AND ( gv_bsart = 'ZUB1' OR gv_bsart = 'ZUB2' OR gv_bsart = 'YRCL' OR gv_bsart = 'ZRCL' OR gv_bsart = 'ZFGS' ) ." ADDED BY PARTH
**************************************        ended by parth 10.10.2020
****************        added by parth 10.10.2020
      ELSEIF gv_reswk IS INITIAL AND ( gv_bsart = gv_type ).
*******************        comment by parth 10.10.2020
        lv_bwtar = gv_reswk.
        IF ls_poitem-bwtar IS INITIAL.
          ls_poitem-bwtar = lv_bwtar.
          CALL METHOD im_item->set_data( ls_poitem ).
        ENDIF.
      ENDIF.
*    IF gv_dpdat IS  NOT INITIAL AND
*       gv_dppct IS NOT INITIAL AND
*       gv_dptyp IS NOT INITIAL AND
*       ls_poitem-dptyp IS  INITIAL AND
*       ls_poitem-dppct IS  INITIAL AND
*       ls_poitem-dpdat IS  INITIAL.
      CLEAR: lwa_acc_key,lwa_acc_t,gv_type.
    ENDIF.
    IF gv_dppct IS NOT INITIAL.
      ls_poitem-dptyp = gv_dptyp.
      ls_poitem-dppct = gv_dppct.
      ls_poitem-dpdat = gv_dpdat.
*      ls_poitem-dpamt = gv_dpamt.    "commented by SAW on 19.11.2023
      CALL METHOD im_item->set_data( ls_poitem ).
    ENDIF.


*    ELSEIF gv_dptyp EQ ls_poitem-dptyp AND ls_poitem-dppct IS INITIAL.
*      ls_poitem-dppct = gv_dppct.
*      ls_poitem-dpdat = gv_dpdat.
*
*      CALL METHOD im_item->set_data( ls_poitem ).
*
*    ENDIF.

    CALL METHOD im_item->get_conditions
      IMPORTING
        ex_conditions = l_item_cond.


*ASSIGN ('(SAPLV69A)XKOMV[]') to <fs_zdomes>.
    ASSIGN ('(SAPLMEPO)TKOMV[]') TO <fs_zdomes>.
    IF <fs_zdomes> IS ASSIGNED.
      lt_zdomes[] = <fs_zdomes>.
    ENDIF.

    ASSIGN ('(SAPLMEPO)EKPO') TO <fs_ekpo1>.
    IF <fs_ekpo1> IS ASSIGNED .
      wa_ekpo = <fs_ekpo1>.
    ENDIF.

    ASSIGN ('(SAPLMEPO)EKKO') TO <fs_ekko1>.
    IF <fs_ekko1> IS ASSIGNED .
      wa_ekko = <fs_ekko1>.
    ENDIF.
*************************
    lv_taxcom-bukrs = wa_ekpo-bukrs.
    lv_taxcom-budat = wa_ekpo-aedat.
*    lv_taxcom-bldat = wa_ekko-aedat.
*    lv_taxcom-waers = wa_ekko-waers.
*    lv_taxcom-hwaer = wa_ekko-waers.
    lv_taxcom-kposn = wa_ekpo-ebelp.
    lv_taxcom-mwskz = wa_ekpo-mwskz.
    lv_taxcom-wrbtr = wa_ekpo-netwr.
*    lv_taxcom-lifnr = wa_ekko-lifnr.
*    lv_taxcom-ekorg = wa_ekko-ekorg.
    lv_taxcom-matnr = wa_ekpo-matnr.
    lv_taxcom-werks = wa_ekpo-werks.
    lv_taxcom-matkl = wa_ekpo-matkl.
    lv_taxcom-meins = wa_ekpo-meins.
    lv_taxcom-mglme = wa_ekpo-menge.
    lv_taxcom-mtart = wa_ekpo-mtart.
*    lv_taxcom-land1 = wa_ekko-lands.
    lv_taxcom-shkzg =  'H'.
    lv_taxcom-xmwst =  'X'.

    IF lv_taxcom-bukrs IS NOT INITIAL.
      CALL FUNCTION 'CALCULATE_TAX_ITEM'
        EXPORTING
          i_taxcom            = lv_taxcom
        TABLES
          t_xkomv             = it_komv
        EXCEPTIONS
          mwskz_not_defined   = 1
          mwskz_not_found     = 2
          mwskz_not_valid     = 3
          steuerbetrag_falsch = 4
          country_not_found   = 5
          OTHERS              = 6.
      IF sy-subrc <> 0.
*****************
      ENDIF.
    ENDIF.






**************************    COMMENT FOR GST

*
*    READ TABLE it_komv INTO wa_komv WITH KEY kschl = 'JMOP'.
*    IF sy-subrc = 0.
*      SELECT SINGLE j_1ichid FROM j_1imtchid INTO gv_chid WHERE matnr = wa_final-matnr
*                                                         AND werks = wa_final-werks.
*      IF gv_chid IS INITIAL.
*        MESSAGE 'MAINTAIN CHAPTER ID FOR MATERIAL' TYPE 'E'.
** INCLUDE mm_messages_mac.
** mmpur_message_forced 'W' '000' '398' 'MANTAIN CHAPTER ID FOR MATIRAL IF APPLICABLE' WA_FINAL-MATNR  '' ''.
*      ENDIF.
*      SELECT * FROM j_1imovend INTO TABLE it_excd WHERE lifnr = wa_ekko-lifnr.
*
*      LOOP AT it_excd INTO wa_excd.
*        IF wa_excd-j_1iexcd IS INITIAL AND wa_excd-j_1iexrn IS INITIAL AND wa_excd-j_1iexcive IS INITIAL AND wa_excd-j_1ivtyp IS INITIAL.
*          MESSAGE 'Vendor Excise Details Not Manintain' TYPE 'E'.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
*    READ TABLE it_komv INTO wa_komv WITH KEY kschl = 'JMIP'.
*    IF sy-subrc = 0.
*
*      SELECT SINGLE j_1ichid FROM j_1imtchid INTO gv_chid WHERE matnr = wa_final-matnr
*                                                           AND werks = wa_final-werks.
**
*      IF gv_chid IS INITIAL.
*        MESSAGE 'MAINTAIN CHAPTER ID FOR MATERIAL' TYPE 'E'.
***INCLUDE mm_messages_mac.
*** mmpur_message_forced 'W' '000' '398' 'MANTAIN CHAPTER ID FOR MATIRAL IF APPLICABLE' WA_FINAL-MATNR  '' ''.
*      ENDIF.
*      SELECT * FROM j_1imovend INTO TABLE it_excd WHERE lifnr = wa_ekko-lifnr.
*
*      LOOP AT it_excd INTO wa_excd.
*        IF wa_excd-j_1iexcd IS INITIAL AND wa_excd-j_1iexrn IS INITIAL AND wa_excd-j_1iexcive IS INITIAL AND wa_excd-j_1ivtyp IS INITIAL.
*          MESSAGE 'Vendor Excise Details Not Manintain' TYPE 'E'.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
*    READ TABLE lt_zdomes INTO wa_zdomes WITH KEY kschl = 'JCV1'.
*    IF sy-subrc = 0.
*
*      SELECT SINGLE j_1ichid FROM j_1imtchid INTO gv_chid WHERE matnr = wa_final-matnr
*                                                           AND werks = wa_final-werks.
**
*      IF gv_chid IS INITIAL.
*        MESSAGE 'MAINTAIN CHAPTER ID FOR MATERIAL' TYPE 'E'.
*      ENDIF.
*
*      SELECT * FROM j_1imovend INTO TABLE it_excd WHERE lifnr = wa_ekko-lifnr.
*
*      LOOP AT it_excd INTO wa_excd.
*        IF wa_excd-j_1iexcd IS INITIAL AND wa_excd-j_1iexrn IS INITIAL AND wa_excd-j_1iexcive IS INITIAL AND wa_excd-j_1ivtyp IS INITIAL.
*          MESSAGE 'Vendor Excise Details Not Manintain' TYPE 'E'.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
*
*    CLEAR: gv_chid,wa_final,wa_komv,wa_excd.
************************* FOR GO LIVE GST

*********************************    Plant Wise Costcenter
    v_kostl = ls_poitem-kostl.
    IF  v_kostl IS NOT INITIAL.
      lv_len = strlen( v_kostl ).
      lv_len = lv_len - 6.
      v_werks = v_kostl+0(lv_len).
    ENDIF.
    IF v_werks IS NOT INITIAL.
****      IF v_werks = '1600' AND ls_poitem-werks = '1615'.
***      IF v_werks = '1900' AND ls_poitem-werks = '1418'.
****      ELSEIF v_werks = '200N' AND ls_poitem-werks = '2000'.      " Added by Soham Upadhyay 10.04.2017
****      ELSEIF v_werks = '210N' AND ls_poitem-werks = '2100'.      " Added by Soham Upadhyay 10.04.2017
***      ELSEIF v_werks <> ls_poitem-werks.
***        MESSAGE 'Costcenter not relevant to this Plant' TYPE 'E'.
***      ELSEIF v_werks = '2000' AND ls_poitem-werks = '2000'.
***        MESSAGE 'Costcenter not relevant to this Plant' TYPE 'E'.
***      ELSEIF v_werks = '2100' AND ls_poitem-werks = '2100'.
***        MESSAGE 'Costcenter not relevant to this Plant' TYPE 'E'.
***      ENDIF.
    ENDIF.

************************************
************************************************************************
*         PO Final Done by Mahir Maniar for MIGO to Po change          *
************************************************************************



*    TYPES:BEGIN OF ty_ekko,
*            ebeln TYPE ebeln,
**          knumv TYPE knumv,
*          END OF ty_ekko.
* tctrl_konditionen
*    TYPES:BEGIN OF ty_ekpo,
*            ebeln TYPE ebeln,
*            ebelp TYPE ebelp,
*            matnr TYPE matnr,
*            menge TYPE menge_d,
*            meins TYPE meins,
*            netpr TYPE bprei,
*            elikz TYPE elikz,
*          END OF ty_ekpo.
*
*    TYPES:BEGIN OF ty_mseg,
*            mblnr TYPE mblnr,
*            mjahr TYPE mjahr,
*            bwart TYPE bwart,
*            matnr TYPE matnr,
*            menge TYPE menge_d,
*            meins TYPE meins,
*            ebeln TYPE ebeln,
*            ebelp TYPE ebelp,
*          END OF ty_mseg.
*
*    DATA: lwa_ekko TYPE ty_ekko,
*          lwa_ekpo TYPE ty_ekpo,
*          lwa_mseg TYPE ty_mseg,
*          lit_ekko TYPE TABLE OF ty_ekko,
*          lit_ekpo TYPE TABLE OF ty_ekpo,
*          lit_mseg TYPE TABLE OF ty_mseg.
*
*    DATA:sum    TYPE menge_d,
*         sum1   TYPE menge_d,
*         diff   TYPE menge_d,
*         amount TYPE netpr.
*
*    IF wa_ekko-ebeln IS NOT INITIAL.
*
*      SELECT ebeln ebelp matnr menge meins netpr elikz FROM ekpo INTO TABLE lit_ekpo WHERE ebeln = wa_ekko-ebeln.
*
*    ENDIF.
*
*    IF lit_ekpo IS NOT INITIAL.
*
*      SELECT mblnr mjahr bwart matnr menge meins ebeln ebelp FROM mseg
*                                                             INTO TABLE lit_mseg
*                                                             WHERE EBELN = WA_EKPO-EBELN AND EBELP = WA_EKPO-EBELP.
*      SORT lit_mseg BY mblnr ebeln ebelp.
*
*    ENDIF.
*
*    READ TABLE lit_ekpo INTO lwa_ekpo INDEX 1.
*
*    LOOP AT lit_mseg INTO lwa_mseg." WHERE ebeln = wa_ekpo-ebeln AND ebelp = wa_ekpo-ebelp.
*
*      IF lwa_mseg-bwart EQ '101'.
*
*        sum = sum + lwa_mseg-menge.
*
*      ELSEIF lwa_mseg-bwart EQ '102'.
*
*        sum1 = sum1 + lwa_mseg-menge.
*
*      ENDIF.
*
*    ENDLOOP.
*
*    diff = sum - sum1.
*
*    IF diff GE 0.
*
*    ELSE.
*      MESSAGE 'Change Not Allowed' TYPE 'E'.
*    ENDIF.
*
*    IF diff NE 0.
*
**      TCTRL_KONDITIONEN-COLS[ 6 ]-SCREEN-INPUT = 0.
*
*    READ TABLE LIT_EKPO INTO LWA_EKPO WITH KEY EBELN = WA_EKPO-EBELN EBELP = WA_EKPO-EBELP.
*      IF SY-SUBRC EQ 0.
*
*        IF WA_EKPO-NETPR NE LWA_EKPO-NETPR or wa_komv-kbetr ne wa_ekpo-netpr.
*
*          MESSAGE 'You Cannot Change Amount' TYPE 'E'.
*
*        ENDIF.
*
*      ENDIF.
*
*    ENDIF.
*
**    READ TABLE lit_mseg INTO lwa_mseg WITH KEY ebeln = wa_ekpo-ebeln ebelp = wa_ekpo-ebelp.



    "Changes by sayali HSN-SAC Validation.

*BREAK-POINT.
    TYPE-POOLS: mmmfd.
    INCLUDE mm_messages_mac.

    DATA: wa_poitem  TYPE mepoitem,
          im_header  TYPE mepoitem,
          lv_msg     TYPE string,
          lv_hsn_sac TYPE j_1ig_hsn_sac,
          wa_reg(01).

*BREAK in10808.
    wa_poitem = im_item->get_data( ).

    IF  wa_poitem-matnr IS NOT INITIAL .
*      IF wa_ekko-bsart = 'GNRL' OR wa_ekko-bsart = 'CAPT' OR wa_ekko-bsart = 'SERV' OR wa_ekko-bsart = 'ZRET' OR wa_ekko-bsart = 'SCON' OR  wa_ekko-bsart = 'CONT'.
*      IF  wa_ekko-bsart = 'ZRAW' OR wa_ekko-bsart = 'ZPKG' OR wa_ekko-bsart = 'SERV' OR wa_ekko-bsart = 'ZRET' OR wa_ekko-bsart = 'ZRET'
*      OR  wa_ekko-bsart = 'ZTRD'
*      OR  wa_ekko-bsart = 'ZIND'
*      OR  wa_ekko-bsart = 'ZHOD'
*      OR  wa_ekko-bsart = 'ZSUB'
*      OR  wa_ekko-bsart = 'ZMCP'
*      OR  wa_ekko-bsart = 'ZSCP'
*       "soc HSN error PT UDAYABAP01 30/1/2026.
*      OR  wa_ekko-bsart = 'ZFGS'
*      OR  wa_ekko-bsart = 'ZFGS'
*      OR  wa_ekko-bsart = 'ZCON'.
      "eoc HSN error PT UDAYABAP01 30/1/2026..

*      CALL FUNCTION 'J_1IG_GET_HSN_SAC'
*        EXPORTING
*          im_matnr   = wa_poitem-matnr
*          im_werks   = wa_poitem-werks
**         IM_ASNUM   =
*          im_country = 'IN'
*        IMPORTING
*          ex_hsn_sac = lv_hsn_sac.
      SELECT SINGLE steuc FROM marc INTO lv_hsn_sac WHERE matnr = wa_poitem-matnr AND werks = wa_poitem-werks.
      IF lv_hsn_sac IS INITIAL  .

        mmpur_metafield  mmmfd_matnr .
*        message id &2 type &1 number &3 with &4 &5 &6 &7 into gl_dummy.
        mmpur_message_forced 'E' 'FV' '00' 'Material ' wa_poitem-matnr  '-' 'HSN code is Missing hence PO cannot be saved'  .
        CONCATENATE 'Material ' wa_poitem-matnr  '-' 'HSN code is Missing hence PO/SO cannot be saved'  INTO lv_msg.
        MESSAGE   lv_msg TYPE 'E' .
*         MESSAGE  'HSN code is Missing hence PO/SO cannot be saved' type 'E'.
*        LEAVE TO CREEN 0.
      ENDIF.

*      ELSE.
*
*        SELECT SINGLE steuc FROM marc INTO lv_hsn_sac WHERE matnr = wa_poitem-matnr AND werks = wa_ekko-reswk.
*        IF lv_hsn_sac IS INITIAL  .
*
*          mmpur_metafield  mmmfd_matnr .
**        message id &2 type &1 number &3 with &4 &5 &6 &7 into gl_dummy.
*          mmpur_message_forced 'E' 'FV' '00' 'Material ' wa_poitem-matnr  '-' 'HSN code is Missing hence PO cannot be saved'  .
*          CONCATENATE 'Material ' wa_poitem-matnr  '-' 'HSN code is Missing hence PO/SO cannot be saved'  INTO lv_msg.
*          MESSAGE   lv_msg TYPE 'E' .
**         MESSAGE  'HSN code is Missing hence PO/SO cannot be saved' type 'E'.
**        LEAVE TO CREEN 0.
*        ENDIF.

    ENDIF.
*    ENDIF.
****************************    hsn code length check 04.06.2021



    SELECT * FROM zsd_hsn_len INTO TABLE it_lhsn.

    SELECT SINGLE matnr mtart FROM mara INTO ( v_matnr ,v_mtart )
      WHERE matnr = wa_poitem-matnr.

    READ TABLE it_lhsn INTO wa_lhsn WITH KEY mtart = v_mtart.

    IF sy-subrc = 0.

      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
          string_in = lv_hsn_sac
        IMPORTING
*         STRING_OUT       =
          htype     = htype.

      IF htype = 'NUMC'.

        llen = strlen( lv_hsn_sac ).
        IF ( llen <> wa_lhsn-zlent AND  llen <> wa_lhsn-zlenf AND llen <> wa_lhsn-zlenm ) .
          MESSAGE 'control code length is wrong' TYPE 'E'.
        ENDIF.

      ELSE.
        MESSAGE 'Please enter only numaric value' TYPE 'E'.
      ENDIF.
      CLEAR: v_matnr,v_mtart,wa_lhsn.
    ENDIF.

***********
*  ****************** comment by parth 22.11.2022
********************
*    READ TABLE lt_acc_tk INTO lw_acc_tk WITH KEY low = gv_bsart.
*    IF sy-subrc <> 0.
*      READ TABLE lt_acc_k INTO lw_acc_k WITH KEY low = wa_poitem-mtart.
*      IF sy-subrc <> 0.
*        IF wa_poitem-knttp = 'K'.
**          MESSAGE 'Account Assignment Allowd For UNBW Material' TYPE 'E'.
*          MESSAGE e043(zmm) WITH wa_poitem-mtart.
*        ENDIF.
*      ENDIF.
*    ENDIF.
******************
*    READ TABLE lt_acc_capt INTO lw_acc_capt WITH KEY low = gv_bsart.
*
*    IF sy-subrc <> 0.
*
**    IF wa_po_type <> gv_bsart.
*
*      READ TABLE lt_acc_capk INTO lw_acc_capk WITH KEY low = wa_poitem-mtart.
*
*      IF sy-subrc =  0.
*
**      IF  wa_mtart_type  = wa_poitem-mtart.
*
*        MESSAGE e044(zmm) WITH  gv_bsart.
*      ENDIF.
*    ELSE.
*
*      READ TABLE lt_acc_capk INTO lw_acc_capk WITH KEY low = wa_poitem-mtart.
*
*      IF sy-subrc <>  0.
**      IF  wa_mtart_type  <> wa_poitem-mtart.
*
*        MESSAGE e044(zmm) WITH gv_bsart.
*      ENDIF.
*
*    ENDIF.


*    IF gv_bsart <> 'SERV'.
*      IF  wa_poitem-mtart <> 'UNBW' AND   wa_poitem-mtart <> 'WERB' AND wa_poitem-mtart <> 'ZGFT' AND wa_poitem-mtart <> 'NLAG' AND wa_poitem-knttp = 'K'.
*        MESSAGE 'Account Assignment Allowd For UNBW Matiral' TYPE 'E'.
*      ENDIF.
*    ENDIF.

******************* VENDOR REGISTRATION CHECK
*BREAK-POINT.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE ven_class FROM j_1imovend INTO wa_reg WHERE lifnr = wa_ekko-lifnr.
    SELECT SINGLE ven_class FROM lfa1 INTO wa_reg WHERE lifnr = wa_ekko-lifnr.
******************End of ATC changes 13/02/26   UDAYABAP03*************

******************Added by Manish Paul*********18.03.2026*******************
    SELECT low
      FROM tvarvc INTO TABLE @DATA(llt_tvarvc)
      WHERE name = 'ZMM_IMPORTPO_TAXCODE'.


    READ TABLE llt_tvarvc INTO DATA(wa_tvarvc) WITH KEY low = wa_ekpo-mwskz.
    IF sy-subrc <> 0.
*    IF ( wa_reg = '0') AND ( wa_ekpo-mwskz <>'00' AND  wa_ekpo-mwskz <> 'V0' AND wa_ekpo-mwskz <> '3D' AND wa_ekpo-mwskz <> '3I' )
      IF ( wa_reg = '0') " AND ( wa_ekpo-mwskz <> wa_tvarvc-low )
*       AND ( wa_ekko-ekorg = '1000' OR wa_ekko-ekorg = '2000') .
         AND ( wa_ekko-ekorg = '1000' OR wa_ekko-ekorg = '1001') .
        MESSAGE 'Invalid Tax Code - Vendor is not registered in GST' TYPE 'E'.
      ENDIF.
    ENDIF.
    "************EOD********************
*******************
*Begin of Code Restricting Deletion of PO Line items -- 19.03.2021
    DATA:lv_low TYPE rvari_val_255.


******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low
*           FROM tvarvc
*           INTO lv_low
*           WHERE name = 'ZMM_PO_TCODE' AND
*                 low  =  sy-tcode.
    SELECT low
           FROM tvarvc
           INTO lv_low UP TO 1 ROWS
           WHERE name = 'ZMM_PO_TCODE' AND
                 low  =  sy-tcode ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

    IF sy-tcode = lv_low AND
       sy-ucomm = 'YES'.
*    IF ( sy-tcode = 'ME22N' OR sy-tcode = 'ME23N'  OR sy-tcode = 'ME29N' ) AND
*         sy-ucomm = 'YES'.

      SELECT ebeln,ebelp,
             vgabe,bwart
             FROM ekbe
             INTO TABLE @DATA(it_ekbe) "( lv_vgabe )

             WHERE ebeln = @ls_poitem-ebeln AND
                   ebelp = @ls_poitem-ebelp.

      READ TABLE it_ekbe INTO DATA(wa_ekbe) WITH KEY bwart = '102'.
      IF sy-subrc <> 0.
        READ TABLE it_ekbe INTO DATA(wa_ekbe1) WITH KEY bwart = '101'.
        IF sy-subrc = 0.
          IF wa_ekbe-vgabe IS NOT INITIAL.
            MESSAGE 'Deletion is Not Possible Due to Line Item is Processed' TYPE 'E'.
          ENDIF.
        ENDIF.
      ENDIF.

    ENDIF.
*End of Code Restricting Deletion of PO Line items -- 19.03.2021

*  **********************    For Plant xxxxx is not related to co. xxxxx


    DATA: gv_plant TYPE ekpo-werks.
    DATA :lv_error(70).

    SELECT SINGLE bwkey
     FROM t001k
      INTO gv_plant
      WHERE bukrs = wa_ekko-bukrs
      AND   bwkey = wa_ekpo-werks.

    IF sy-subrc <> 0.
      CONCATENATE 'Plant -' wa_ekpo-werks ' is not related to comnapy code - ' wa_ekko-bukrs INTO lv_error.
      MESSAGE lv_error TYPE 'E'.
    ENDIF.


* ****************************  for Condition value not change negative to positive
**  BREAK-POINT.
    DATA: it_t685a TYPE STANDARD TABLE OF t685a,
          wa_t685a TYPE t685a.
    DATA: lv_emsg(100).

    SELECT * FROM t685a
      INTO TABLE it_t685a WHERE kappl = 'M'.

    LOOP AT lt_zdomes INTO wa_zdomes.

      READ TABLE it_t685a INTO wa_t685a WITH KEY kschl = wa_zdomes-kschl.
      IF sy-subrc = 0.
        IF wa_t685a-kaend_wrt = 'X' AND wa_t685a-knega = 'X'.
          IF wa_zdomes-kwert GT '0.00'.
            CONCATENATE 'Please enter negative(-) amount only in condition :' wa_zdomes-kschl INTO lv_emsg SEPARATED BY space.
            MESSAGE lv_emsg TYPE 'E'.
          ENDIF.
        ENDIF.
        IF wa_t685a-kaend_wrt = 'X' AND wa_t685a-knega = 'A'.
          IF wa_zdomes-kwert LT '0.00'.
            CONCATENATE 'Please enter positive(+) amount only in condition :' wa_zdomes-kschl INTO lv_emsg SEPARATED BY space.
            MESSAGE lv_emsg TYPE 'E'.
          ENDIF.
        ENDIF.
      ENDIF.

      CLEAR:wa_zdomes,wa_t685a.
    ENDLOOP.

*******************
    "++hemang
    DATA: lv_supply_plant TYPE ekko-reswk,
          lv_ekpo_bwtar   TYPE ekpo-bwtar.

    SELECT SINGLE low FROM tvarvc INTO @DATA(lv_enhance_val) WHERE name = 'ZPO_VALUATION_TYPE'.
    IF lv_enhance_val IS NOT INITIAL.

      lv_supply_plant = wa_ekko-reswk. "supply plant
      lv_ekpo_bwtar  = wa_ekpo-bwtar. "ekpo-bwtar

      IF lv_supply_plant IS NOT INITIAL AND wa_ekpo-matnr IS NOT INITIAL.
        "fetch valuation type from mbew
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*        SELECT SINGLE bwtar FROM mbew INTO @DATA(lv_mbew_bwtar)
*          WHERE matnr = @wa_ekpo-matnr
*          AND bwkey = @lv_supply_plant.
        SELECT bwtar FROM mbew INTO @DATA(lv_mbew_bwtar) UP TO 1 ROWS
          WHERE matnr = @wa_ekpo-matnr
          AND bwkey = @lv_supply_plant ORDER BY PRIMARY KEY.
        ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************

        IF sy-subrc IS INITIAL AND lv_mbew_bwtar IS NOT INITIAL.
          IF lv_ekpo_bwtar = lv_mbew_bwtar.
          ELSE.
            MESSAGE e056(zmm).
          ENDIF.
        ENDIF.

      ENDIF.
    ENDIF.
    "--hemang
**&---------------------------------------------------------------------------
**& CR          : CR-
**& Author      : Bhushan Bhalerao
**& Company     : AIS, Pune
**& Description : Deletion flag for item in STO Case
**&---------------------------------------------------------------------------
    DATA: ls_head      TYPE REF TO if_purchase_order_mm,
          ls_headdata  TYPE mepoheader,
          ls_mepoitem  TYPE mepoitem,
          lv_vprsv     TYPE mbew-vprsv VALUE 'S',
          lv_vprsv1    TYPE mbew-vprsv,
          lv_me21n     TYPE sy-tcode VALUE 'ME21N',
          lv_me22n     TYPE sy-tcode VALUE 'ME22N',
          lv_tvarvc    TYPE tvarvc-name VALUE 'ZPO_STO_TYPE_DEL_FLAG',
          lv_tvarvc1   TYPE tvarvc-name VALUE 'ZPO_STO_TCODE_DEL_FLAG',
*          it_tvarvc type table of tvarvc,
          lv_mat_split TYPE c.

    TYPES: ty_bsart TYPE RANGE OF ekko-bsart.
    DATA : rt_bsart TYPE ty_bsart,
           rw_bsart TYPE LINE OF ty_bsart.

    "---Get Item Data
    ls_mepoitem = im_item->get_data( ).
    "---Get Head Deep-Structure
    ls_head     = im_item->get_header( ).
    "---Get Header Data
    ls_headdata  = ls_head->get_data( ).

    SELECT low, high
           FROM tvarvc
           INTO TABLE @DATA(lt_bsart)
           WHERE name = @lv_tvarvc.
    LOOP AT lt_bsart INTO DATA(lw_bsart).
      rw_bsart-sign   = 'I'.
      rw_bsart-option = 'EQ'.
      rw_bsart-low    = lw_bsart-low.
      APPEND rw_bsart TO rt_bsart.
      CLEAR rw_bsart.
    ENDLOOP.

    SELECT low, high
           FROM tvarvc
           INTO TABLE @DATA(lt_tcode)
           WHERE name = @lv_tvarvc1.

    CHECK rt_bsart IS NOT INITIAL.

    DATA : lv_ans TYPE c.

    IF ls_headdata-bsart IN rt_bsart.
      SELECT matnr,bwkey,bwtar,vprsv,stprs,verpr
             FROM mbew
             INTO TABLE @DATA(lt_mbew)
             WHERE matnr = @ls_mepoitem-matnr
             AND   bwkey = @ls_mepoitem-werks.

      CLEAR lv_mat_split.
      " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
      SORT lt_mbew .
      " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026 FOR ATC
      LOOP AT lt_mbew INTO DATA(lw_mbew) WHERE bwtar IS NOT INITIAL.
        lv_mat_split = 'X'.
        EXIT.
      ENDLOOP.

      IF lv_mat_split = 'X' AND ls_mepoitem-bwtar IS NOT INITIAL.
*        CALL FUNCTION 'POPUP_TO_CONFIRM'
*          EXPORTING
*            text_question         = 'Do you want to change the Val. Type ?'
*            text_button_1         = 'Yes'
*            text_button_2         = 'No'
*            default_button        = '2'
*            display_cancel_button = ' '
*          IMPORTING
*            answer                = lv_ans
*          EXCEPTIONS
*            text_not_found        = 1
*            OTHERS                = 2.
*
*
*
*        IF lv_ans = '1'.
*          READ TABLE lt_tcode INTO DATA(lw_tcode) WITH KEY low = sy-tcode.
*          IF sy-subrc = 0.
*            ls_mepoitem-bwtar = ' '.
*            "---Change line item with Set method
*            CALL METHOD im_item->set_data
*              EXPORTING
*                im_data = ls_mepoitem.
*          ENDIF.
*        ENDIF.

        READ TABLE lt_mbew INTO lw_mbew WITH KEY matnr = ls_mepoitem-matnr
                                                 bwkey = ls_mepoitem-werks
                                                 bwtar = ls_mepoitem-bwtar.
        IF sy-subrc = 0 AND lw_mbew-vprsv = lv_vprsv AND ls_mepoitem-loekz IS INITIAL .
          IF lw_mbew-stprs IS INITIAL.
            CALL FUNCTION 'POPUP_TO_CONFIRM'
              EXPORTING
                text_question         = 'Material price is 0 in receving plant. Do you want to change the Val. Type ?'
                text_button_1         = 'Yes'
                text_button_2         = 'No'
                default_button        = '2'
                display_cancel_button = ' '
              IMPORTING
                answer                = lv_ans
              EXCEPTIONS
                text_not_found        = 1
                OTHERS                = 2.

            IF lv_ans = '1'.
              READ TABLE lt_tcode INTO DATA(lw_tcode) WITH KEY low = sy-tcode.
              IF sy-subrc = 0.
                ls_mepoitem-bwtar = ' '.
                "---Change line item with Set method
                CALL METHOD im_item->set_data
                  EXPORTING
                    im_data = ls_mepoitem.
              ENDIF.
            ELSE.

              IF sy-tcode = lv_me21n OR sy-tcode = lv_me22n .
                ls_mepoitem-loekz = 'S'.
              ELSE.
                ls_mepoitem-loekz = 'L'.
              ENDIF.

              "---Change line item with Set method
              CALL METHOD im_item->set_data
                EXPORTING
                  im_data = ls_mepoitem.
            ENDIF.
          ENDIF.

        ENDIF.
      ELSE.
        " ATC Correction for S4 HANA **BEGIN OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
        READ TABLE lt_mbew INTO lw_mbew INDEX 1.        "#EC CI_NOORDER
        " ATC Correction for S4 HANA * *END OF CHANGE BY UDAYABAP03 14.02.2026  FOR ATC
        IF lw_mbew-vprsv = lv_vprsv AND lw_mbew-stprs IS INITIAL.
          IF sy-tcode = lv_me21n OR sy-tcode = lv_me22n .
            ls_mepoitem-loekz = 'S'.
          ELSE.
            ls_mepoitem-loekz = 'L'.
          ENDIF.

          "---Change line item with Set method
          CALL METHOD im_item->set_data
            EXPORTING
              im_data = ls_mepoitem.
        ENDIF.
      ENDIF.
    ENDIF.

    DATA  : ls_poversion TYPE erevitem         .

*   ls_poversion = im_item->set_data( ).
*     DATA: v_mtart TYPE mara-mtart.
    SELECT SINGLE mtart FROM mara INTO v_mtart WHERE matnr = ls_poitem-matnr.

    SELECT bsart,
           knttp,
           pstyp,
           mtart FROM zmm_prpo_type INTO TABLE @DATA(lt_prpo).
    SELECT pstyp,
          epstp FROM t163y INTO TABLE @DATA(lt_t163) WHERE spras = 'E'.
    READ TABLE lt_t163 INTO DATA(ls_t163) WITH KEY pstyp = ls_mepoitem-pstyp.

*     LOOP at lt_prpo into data(ls_prpo).
    READ TABLE lt_prpo INTO DATA(ls_prpo) WITH KEY bsart = ls_headdata-bsart knttp = ls_mepoitem-knttp pstyp = ls_t163-epstp mtart = ls_mepoitem-mtart.

    IF ls_prpo IS INITIAL.
      MESSAGE 'Please enter valid value' TYPE 'E'.
    ENDIF.
    IF ls_prpo-bsart <> ls_headdata-bsart AND ls_prpo-knttp <> ls_mepoitem-knttp AND
       ls_prpo-pstyp <> ls_mepoitem-pstyp AND ls_prpo-mtart <> ls_mepoitem-mtart.
      MESSAGE 'Please enter valid value' TYPE 'E'.
    ENDIF.

*       ENDLOOP.

*************Begin of changes Added by Raj on 26.12.2023*******************************
    DATA : v_mtype TYPE mara-mtart.

    SELECT SINGLE mtart FROM mara INTO v_mtype WHERE matnr = ls_poitem-matnr.

    READ TABLE lt_acc_mt INTO  lwa_acc_mt WITH KEY low = v_mtype.

    IF sy-subrc NE 0.
      READ TABLE lt_acc_po INTO lwa_acc_po WITH KEY low = gv_bsart.

      IF lwa_acc_po IS NOT INITIAL. "PO Document type

        DATA: is_item   TYPE   mepoitem,
              is_header TYPE   REF TO if_purchase_order_mm,
              items     TYPE   purchase_order_items,
              item_obj  TYPE   purchase_order_item,
              re_header TYPE    mepoheader,
              rm_header TYPE    mepoheader,
              my_ekpv   TYPE    ekpv,
              l_lgfsb   TYPE    lgfsb,
              v_kondm   TYPE mvke-kondm.

        is_header    = im_item->get_header( ).
*    re_header  = is_header->get_header( ).
        rm_header = is_header->get_data( ).           "Header Data getting from runtime screen
        is_header    = im_item->get_header( ).
        is_item          = im_item->get_data( ).
        items             = is_header->get_items( ).


        IF NOT items IS INITIAL.                             "Getting Sales Organisation from Shipping tab when you enter material
          LOOP AT items INTO item_obj.                                                    "respective line item system will sale org from master data dynamically or runtime
            my_ekpv = item_obj-item->get_shipping_data( ).
          ENDLOOP.
        ENDIF.


        DATA : v_matnrr TYPE ekpo-matnr,
               v_pltyp  TYPE knvv-pltyp,
               v_kunnr  TYPE t001w-kunnr,

               v_knumh  TYPE a777-knumh,
               v_knumh1 TYPE a777-knumh,
               v_knumh2 TYPE a777-knumh,
               v_knumh3 TYPE a777-knumh,
               v_knumh4 TYPE a777-knumh,
               v_knumh5 TYPE a777-knumh,
               v_loevm  TYPE konp-loevm_ko,
               v_loevm1 TYPE konp-loevm_ko,
               v_loevm2 TYPE konp-loevm_ko,
               v_loevm3 TYPE konp-loevm_ko,
               v_loevm4 TYPE konp-loevm_ko,
               v_loevm5 TYPE konp-loevm_ko.


        DATA : wa_a999 TYPE a999,
               wa_a923 TYPE a923,
               wa_a777 TYPE a777,
               wa_a952 TYPE a952,
               wa_a920 TYPE a920,
               wa_a906 TYPE a906.



        IF ls_poitem-matnr IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*          SELECT SINGLE kondm FROM mvke INTO v_kondm WHERE matnr = ls_poitem-matnr AND vkorg = my_ekpv-vkorg."Material Pricing condition
          SELECT kondm FROM mvke INTO v_kondm UP TO 1 ROWS WHERE matnr = ls_poitem-matnr AND vkorg = my_ekpv-vkorg ORDER BY PRIMARY KEY."Material Pricing condition
          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
        ENDIF.

        IF ls_poitem-werks IS NOT INITIAL.
          SELECT SINGLE kunnr FROM t001w INTO v_kunnr WHERE werks = ls_poitem-werks."Customer
        ENDIF.

        IF v_kunnr IS NOT INITIAL.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*          SELECT SINGLE pltyp FROM knvv INTO v_pltyp WHERE kunnr = v_kunnr."Price list type
          SELECT pltyp FROM knvv INTO v_pltyp UP TO 1 ROWS WHERE kunnr = v_kunnr ORDER BY PRIMARY KEY."Price list type
          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
        ENDIF.

        "a777***************************************************


        SELECT SINGLE   matnr  FROM a777 INTO  v_matnrr
         WHERE  vkorg = my_ekpv-vkorg AND
         werks = ls_poitem-werks AND matnr = ls_poitem-matnr
         AND datbi  GE rm_header-bedat AND datab  LE rm_header-bedat
         AND kschl = 'PR00' AND kondm = v_kondm.




*      "a952**********************************************
        IF v_matnrr IS INITIAL.
          SELECT SINGLE   matnr  FROM a952 INTO  v_matnrr
          WHERE  vkorg = my_ekpv-vkorg AND
          matnr = ls_poitem-matnr AND datbi  GE rm_header-bedat  AND datab  LE rm_header-bedat
          AND kschl = 'PR00' AND kunnr = v_kunnr.
        ENDIF.


*      "a920********************************************
*
*
        IF v_matnrr IS INITIAL.
          SELECT SINGLE  matnr FROM a920 INTO v_matnrr
          WHERE vkorg = my_ekpv-vkorg AND
          werks = ls_poitem-werks AND matnr = ls_poitem-matnr AND datbi  GE rm_header-bedat
          AND datab  LE rm_header-bedat AND kschl = 'PR00' AND pltyp = v_pltyp.



        ENDIF.


*      "a906******************************************
        IF v_matnrr IS INITIAL.
          SELECT  SINGLE matnr  FROM a906 INTO v_matnrr
          WHERE  vkorg = my_ekpv-vkorg AND
          matnr = ls_poitem-matnr AND datbi  GE rm_header-bedat
          AND datab  LE rm_header-bedat AND kschl = 'PR00' AND pltyp = v_pltyp.
        ENDIF.



*      "a923**************************************
        IF v_matnrr IS INITIAL.
          SELECT SINGLE matnr  FROM a923 INTO  v_matnrr
          WHERE  vkorg = my_ekpv-vkorg AND
          matnr = ls_poitem-matnr AND datbi  GE rm_header-bedat
          AND datab  LE rm_header-bedat AND kschl = 'PR00' AND kondm = v_kondm.
        ENDIF.


*
*      "a999************************************
*
        IF v_matnrr IS INITIAL.
          SELECT SINGLE  matnr
             FROM a999 INTO   v_matnrr
          WHERE  vkorg = my_ekpv-vkorg AND
          matnr = ls_poitem-matnr AND datbi  GE rm_header-bedat
          AND datab  LE rm_header-bedat AND kschl = 'PR00'.
        ENDIF.


        IF v_matnrr IS INITIAL.
          MESSAGE 'Please maintain the PR00 pricing condition type' TYPE 'E'.
        ENDIF.


      ENDIF.

      CLEAR : lwa_acc_po,v_matnrr,v_kunnr,v_pltyp,v_kondm,v_knumh,v_loevm.
      CLEAR :v_knumh1 ,v_knumh2 ,   v_knumh3 ,v_knumh4 ,  v_knumh5 ,v_loevm1 , v_loevm2 ,   v_loevm3 ,v_loevm4 , v_loevm5 .

    ENDIF.
    CLEAR : lwa_acc_mt , v_mtype.
**
***************End of changes Added by Raj on 26.12.2023*******************************

    "Adding Start by Rahul Vasita on 10.05.2024 14:45:26 T-ALTITBO00300
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low FROM tvarvc INTO lv_switch WHERE name = 'ZMM_GL_EN_SWITCH' AND type = 'P'.
    SELECT low FROM tvarvc INTO lv_switch UP TO 1 ROWS WHERE name = 'ZMM_GL_EN_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF lv_switch = abap_true.
      SELECT name,
             low
        FROM tvarvc
        INTO TABLE @DATA(lt_tvarvc)
        WHERE name = 'ZMM_GL_ENHANCEMENT' AND type = 'S'.
      LOOP AT lt_tvarvc INTO DATA(ls_tv).
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = ls_tv-low
          IMPORTING
            output = ls_hkont-hkont.

        APPEND ls_hkont TO lt_hkont.
        CLEAR : ls_hkont , ls_tv.
      ENDLOOP.

      IF ls_poitem-knttp = 'P' OR ls_poitem-knttp = 'Q'.
        ls_hkont-hkont = VALUE #( lt_hkont[ hkont = ls_poitem-sakto ]-hkont OPTIONAL ).
        IF ls_hkont-hkont IS INITIAL.
          lv_msg_e = 'DIFFERENT G/L FOR STOCK OR PROJECT EXPENSE'. CONDENSE : lv_msg_e.

          MESSAGE lv_msg_e TYPE 'E'.

        ENDIF."IF ls_hkont-hkont IS NOT INITIAL.
      ENDIF."IF ls_poitem-knttp = 'P' OR ls_poitem-knttp = 'Q'.

    ENDIF."IF lv_switch = abap_true.
    "Adding End by Rahul Vasita on 10.05.2024 14:45:26

******************Begin of Changes Added by Raj on 08.07.2024****************Ticket no:ALTITBO00415***************
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE low FROM tvarvc INTO gs_switch WHERE name = 'ZMM_CON_SWITCH' AND type = 'P'.
    SELECT low FROM tvarvc INTO gs_switch UP TO 1 ROWS WHERE name = 'ZMM_CON_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF gs_switch = abap_true.

      IF sy-tcode = 'ME21N'.

        SELECT sign
 opti
 low
 high INTO TABLE it_type
           FROM tvarvc
           WHERE name = c_tvarvc_mts AND
                 type =  c_type_mts.
        READ TABLE it_type INTO wa_type WITH KEY low = gv_bsart.
        IF sy-subrc = 0.
          gs_poitem  = im_item->get_data( ).

          SELECT ebeln,lifnr,bstyp,kdatb,kdate FROM ekko INTO TABLE @DATA(it_ekko) WHERE lifnr = @gv_lifnr AND bstyp = 'K'.

          IF it_ekko IS NOT INITIAL.

            SELECT ebeln,ebelp,matnr,werks,ktmng,netpr,bstyp,creationdate,creationtime FROM ekpo INTO TABLE @DATA(it_ekpo) FOR ALL ENTRIES IN @it_ekko
             WHERE ebeln = @it_ekko-ebeln AND matnr =  @gs_poitem-matnr AND werks = @gs_poitem-werks AND bstyp = 'K' AND loekz NE 'L'.

          ENDIF.


          LOOP AT it_ekpo INTO DATA(wa_ekpos).
            MOVE-CORRESPONDING wa_ekpos TO wa_ekpp.
            CONCATENATE wa_ekpos-creationdate wa_ekpos-creationtime INTO wa_ekpp-tsl.
            APPEND wa_ekpp TO it_ekpp.
            CLEAR : wa_ekpos,wa_ekpp.
          ENDLOOP.


          SORT it_ekpp BY tsl DESCENDING.
          READ TABLE it_ekpp INTO wa_ekpp INDEX 1.

          lv_konnr = wa_ekpp-ebeln.
          lv_ktpnr = wa_ekpp-ebelp.

          gs_poitem-konnr = lv_konnr.
          gs_poitem-ktpnr = lv_ktpnr.

          IF lv_konnr IS NOT INITIAL.
******************begin of ATC changes 13/02/26   UDAYABAP03*************
*            SELECT kschl,evrtn,evrtp,datbi,datab,knumh FROM a016 INTO TABLE @DATA(it_a016) WHERE evrtn = @lv_konnr AND evrtp = @lv_ktpnr.
            SELECT kschl,evrtn,evrtp,datbi,datab,knumh FROM a016 INTO TABLE @DATA(it_a016) WHERE evrtn = @lv_konnr AND evrtp = @lv_ktpnr ORDER BY PRIMARY KEY.
******************end of ATC changes 13/02/26   UDAYABAP03*************
          ENDIF.

          SORT it_a016 BY datab   DESCENDING.
          SORT it_a016 BY knumh  DESCENDING.

          READ TABLE it_a016 INTO DATA(wa_a016) INDEX 1.
******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*          SELECT SINGLE kbetr FROM konp INTO @DATA(lv_kbetr) WHERE knumh = @wa_a016-knumh.
          SELECT kbetr FROM konp INTO @DATA(lv_kbetr) UP TO 1 ROWS WHERE knumh = @wa_a016-knumh ORDER BY PRIMARY KEY.
          ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
          IF lv_konnr IS NOT INITIAL.
            gs_poitem-netpr = lv_kbetr.
            CALL METHOD im_item->set_data( gs_poitem ).
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    CLEAR : wa_ekpos,lv_konnr,lv_ktpnr,wa_ekpp,gs_poitem,lv_kbetr,wa_a016.
    REFRESH : it_ekko,it_ekpo,it_ekpp,it_a016.
*******************End of Changes Added by Raj on 08.07.2024*********************Ticket no:ALTITBO00415***************

*** Start change BY Archna Gupta on 25.02.2026
    DATA: lt_accountings TYPE purchase_order_accountings.
    DATA: lv_item1 TYPE ebelp.
    lt_accountings = im_item->get_accountings( ).

    LOOP AT lt_accountings INTO DATA(ls_accountings).

      DATA(lo_item) = ls_accountings-accounting.
      DATA(ls_item1) = lo_item->get_data( ).

      IF ls_mepoitem-knttp = 'P' AND ls_mepoitem-pstyp = '9'.
        IF ls_item1-ps_psp_pnr IS NOT INITIAL.

          DATA(lv_item) = ls_mepoitem-ebelp.
          IF lv_item <> lv_item1.

            DATA(lv_first_wbs_element) = ls_item1-ps_psp_pnr.
            lv_item1 = lv_item.
          ENDIF.
          IF lv_first_wbs_element <> ls_item1-ps_psp_pnr.
            lv_msg_e = 'Multiple WBS not allowed for a single line item'. CONDENSE : lv_msg_e.

            MESSAGE lv_msg_e TYPE 'E'.
          ENDIF.
        ENDIF.
      ENDIF.
*End of chnage by Archna Gupta on 25.02.2026


    ENDLOOP.



  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_schedule.
  ENDMETHOD.
ENDCLASS.
