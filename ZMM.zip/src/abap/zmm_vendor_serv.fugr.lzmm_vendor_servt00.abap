*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_VENDOR_SERV.................................*
DATA:  BEGIN OF STATUS_ZMM_VENDOR_SERV               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_VENDOR_SERV               .
CONTROLS: TCTRL_ZMM_VENDOR_SERV
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_VENDOR_SERV               .
TABLES: ZMM_VENDOR_SERV                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
