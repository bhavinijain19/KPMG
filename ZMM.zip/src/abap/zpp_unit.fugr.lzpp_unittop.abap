FUNCTION-POOL ZPP_UNIT                   MESSAGE-ID SV.

* INCLUDE LZPP_UNITD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_UNITT00                            . "view rel. data dcl.
