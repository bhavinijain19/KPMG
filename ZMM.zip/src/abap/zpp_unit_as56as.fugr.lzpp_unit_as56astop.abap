FUNCTION-POOL ZPP_UNIT_AS56AS            MESSAGE-ID SV.

* INCLUDE LZPP_UNIT_AS56ASD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_UNIT_AS56AST00                     . "view rel. data dcl.
