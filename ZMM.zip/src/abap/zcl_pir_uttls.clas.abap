CLASS zcl_pir_uttls DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.

    TYPES: BEGIN OF lty_pir_info,
             creation_type TYPE char6, " 'MANUAL' or 'AUTO'
             found         TYPE abap_bool,
           END OF lty_pir_info.

    CONSTANTS:
      gc_manual          TYPE char6     VALUE 'MANUAL',
      gc_auto            TYPE char6     VALUE 'AUTO',
      gc_nr_manual_mask  TYPE eina-infnr VALUE '5200*', " manual range
      gc_nr_auto_mask    TYPE eina-infnr VALUE '5100*', " auto range
      gc_use_custom_flag TYPE abap_bool  VALUE abap_true. " set to abap_false if no EINA flag

    CLASS-METHODS get_pir_creation_type
      IMPORTING iv_infnr          TYPE eina-infnr
      RETURNING VALUE(rs_pirinfo) TYPE lty_pir_info.

  PROTECTED SECTION.

  PRIVATE SECTION.
    CLASS-METHODS get_from_custom_field
      IMPORTING iv_infnr         TYPE eina-infnr
      RETURNING VALUE(rv_crtype) TYPE char6.

    CLASS-METHODS get_from_number_range
      IMPORTING iv_infnr         TYPE eina-infnr
      RETURNING VALUE(rv_crtype) TYPE char6.
ENDCLASS.



CLASS ZCL_PIR_UTTLS IMPLEMENTATION.


  METHOD get_from_custom_field.

*    rv_crtype = ''.
*
*    " Adjust custom component name if different from ZZ_CRTYP
*    SELECT SINGLE * FROM eina INTO @DATA(ls_eina) WHERE infnr = @iv_infnr.
*    IF sy-subrc = 0.
*      ASSIGN COMPONENT 'ZZ_CRTYP' OF STRUCTURE ls_eina TO FIELD-SYMBOL(<lv_crtyp>).
*      IF sy-subrc = 0 AND <lv_crtyp> IS ASSIGNED AND <lv_crtyp> IS NOT INITIAL.
*        rv_crtype = <lv_crtyp>.   " Expected 'MANUAL' or 'AUTO'
*      ENDIF.
*    ENDIF.

  ENDMETHOD.


  METHOD get_from_number_range.

*    rv_crtype = ''.
*
*    IF iv_infnr CP gc_nr_manual_mask.
*      rv_crtype = gc_manual.
*      RETURN.
*    ENDIF.
*
*    IF iv_infnr CP gc_nr_auto_mask.
*      rv_crtype = gc_auto.
*      RETURN.
*    ENDIF.

  ENDMETHOD.


  METHOD get_pir_creation_type.
*    CLEAR rs_pirinfo.
*
*    IF iv_infnr IS INITIAL.
*      RETURN.
*    ENDIF.
*
*    DATA(lv_type) = VALUE char6( ).
*
*    " 1) Prefer explicit creation flag on EINA
*    IF gc_use_custom_flag = abap_true.
*      lv_type = get_from_custom_field( iv_infnr ).
*    ENDIF.
*
*    " 2) Fallback: infer from number range
*    IF lv_type IS INITIAL.
*      lv_type = get_from_number_range( iv_infnr ).
*    ENDIF.
*
*    IF lv_type IS NOT INITIAL.
*      rs_pirinfo-found         = abap_true.
*      rs_pirinfo-creation_type = lv_type.
*    ENDIF.
  ENDMETHOD.
ENDCLASS.
