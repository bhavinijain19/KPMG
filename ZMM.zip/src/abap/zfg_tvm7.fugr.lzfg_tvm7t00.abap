*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM7...........................................*
DATA:  BEGIN OF STATUS_ZTVM7                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM7                         .
CONTROLS: TCTRL_ZTVM7
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM7                         .
TABLES: ZTVM7                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
