*----------------------------------------------------------------------*
***INCLUDE LZMAT_DESC1F02.
*----------------------------------------------------------------------*
FORM set_data.
*  zmat_desc-zusername = sy-uname.
*  zmat_desc-zdate = sy-datum.
*  zmat_desc-ztime = sy-uzeit.
*  modify zmat_desc .
ENDFORM.
