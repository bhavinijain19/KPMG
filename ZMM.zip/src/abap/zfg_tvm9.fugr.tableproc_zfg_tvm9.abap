*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM9
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM9            .

  PERFORM TABLEPROC.

ENDFUNCTION.
