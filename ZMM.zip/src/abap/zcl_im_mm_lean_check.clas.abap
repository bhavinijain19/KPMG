class ZCL_IM_MM_LEAN_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_LEAN_CHECK IMPLEMENTATION.


  method IF_EX_ME_PROCESS_PO_CUST~CHECK.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  METHOD if_ex_me_process_po_cust~fieldselection_item.
    DATA: ls_item TYPE mepoitem.
*    DATA: ls_item TYPE mepo1211.

    CALL METHOD im_item->get_data
      RECEIVING
        re_data = ls_item.

*    ls_item = im_item->get_data( ).
    IF ls_item-pstyp = 'A'
      AND ls_item-knttp = 'P'.

*      IF ls_item-webre IS INITIAL.
      ls_item-webre = 'X'.


      CALL METHOD im_item->set_data
        EXPORTING
          im_data = ls_item.
*        im_item->set_data( ls_item ).

*      ENDIF.
    ENDIF.
  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
