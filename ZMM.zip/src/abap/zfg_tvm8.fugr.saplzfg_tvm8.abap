*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TVM8TOP.                      " Global Declarations
  INCLUDE LZFG_TVM8UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TVM8F...                      " Subroutines
* INCLUDE LZFG_TVM8O...                      " PBO-Modules
* INCLUDE LZFG_TVM8I...                      " PAI-Modules
* INCLUDE LZFG_TVM8E...                      " Events
* INCLUDE LZFG_TVM8P...                      " Local class implement.
* INCLUDE LZFG_TVM8T99.                      " ABAP Unit tests
  INCLUDE LZFG_TVM8F00                            . " subprograms
  INCLUDE LZFG_TVM8I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
