*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_PRPO_TYPE...................................*
DATA:  BEGIN OF STATUS_ZMM_PRPO_TYPE                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_PRPO_TYPE                 .
CONTROLS: TCTRL_ZMM_PRPO_TYPE
            TYPE TABLEVIEW USING SCREEN '0100'.
*.........table declarations:.................................*
TABLES: *ZMM_PRPO_TYPE                 .
TABLES: ZMM_PRPO_TYPE                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
