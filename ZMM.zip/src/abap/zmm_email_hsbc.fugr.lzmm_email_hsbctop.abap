FUNCTION-POOL ZMM_EMAIL_HSBC             MESSAGE-ID SV.

* INCLUDE LZMM_EMAIL_HSBCD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_EMAIL_HSBCT00                      . "view rel. data dcl.
