*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_PLANT_MAT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_PLANT_MAT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
