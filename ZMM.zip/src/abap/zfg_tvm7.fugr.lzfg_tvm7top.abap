FUNCTION-POOL ZFG_TVM7                   MESSAGE-ID SV.

* INCLUDE LZFG_TVM7D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM7T00                            . "view rel. data dcl.
