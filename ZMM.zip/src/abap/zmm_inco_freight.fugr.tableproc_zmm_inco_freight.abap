*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_INCO_FREIGHT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_INCO_FREIGHT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
