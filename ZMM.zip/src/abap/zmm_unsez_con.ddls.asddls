@AbapCatalog.sqlViewName: 'ZMMUNSEZCV'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Value help for our ref'
@ObjectModel.dataCategory:#VALUE_HELP
@OData.publish: true
@ObjectModel.createEnabled: true
define view ZMM_UNSEZ_con as select from zmm_unsez
{
    @Consumption.valueHelpDefinition: [{entity: { name: 'ZMM_UNSEZ_value' , element: 'OurRef' }}]
      key unsez as OurRef
}




