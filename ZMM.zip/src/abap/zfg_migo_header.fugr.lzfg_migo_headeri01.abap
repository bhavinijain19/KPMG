*----------------------------------------------------------------------*
***INCLUDE LZFG_MIGO_HEADERI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9100_2  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9100_2 INPUT.
  CASE sy-ucomm.
    WHEN 'OK_POST' OR 'OK_POST1'.
      CLEAR: gs_zmm_migo_cf.
      IF gv_header_text IS NOT INITIAL.
        gs_zmm_migo_cf-mblnr = gv_mblnr.
        gs_zmm_migo_cf-mjahr = gv_mjahr.
        gs_zmm_migo_cf-zz1_header_text = gv_header_text.
        MODIFY zmm_migo_cf FROM gs_zmm_migo_cf.

        CLEAR: gv_header_text.
      ENDIF.
  ENDCASE.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  M_GET_GATE  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE m_get_gate INPUT.
  IF gv_mblnr IS NOT INITIAL.
    SELECT SINGLE zzgat FROM zgate_header
      INTO gv_zzgat WHERE mblnr = gv_mblnr
                      AND mjahr = gv_mjahr.
  ENDIF.
ENDMODULE.
