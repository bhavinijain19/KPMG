*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMAT_DESC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMAT_DESC           .

  PERFORM TABLEPROC.

ENDFUNCTION.
