FUNCTION ZFM_MIGO_SET_FIELD1.
*"--------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_DISPLAY) TYPE  FLAG
*"--------------------------------------------------------------------

  gv_display = iv_display.

ENDFUNCTION.
