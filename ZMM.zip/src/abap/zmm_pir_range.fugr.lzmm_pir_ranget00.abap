*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_PIR_RANGE...................................*
DATA:  BEGIN OF STATUS_ZMM_PIR_RANGE                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_PIR_RANGE                 .
CONTROLS: TCTRL_ZMM_PIR_RANGE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_PIR_RANGE                 .
TABLES: ZMM_PIR_RANGE                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
