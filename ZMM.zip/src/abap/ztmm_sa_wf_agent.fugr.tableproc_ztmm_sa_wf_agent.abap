*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTMM_SA_WF_AGENT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTMM_SA_WF_AGENT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
