*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM12..........................................*
DATA:  BEGIN OF STATUS_ZTVM12                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM12                        .
CONTROLS: TCTRL_ZTVM12
            TYPE TABLEVIEW USING SCREEN '9999'.
*.........table declarations:.................................*
TABLES: *ZTVM12                        .
TABLES: ZTVM12                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
