FUNCTION-POOL ZMAT_DESC1                 MESSAGE-ID SV.

* INCLUDE LZMAT_DESC1D...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMAT_DESC1T00                          . "view rel. data dcl.
