*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI_BUSPSP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI_BUSPSP          .

  PERFORM TABLEPROC.

ENDFUNCTION.
