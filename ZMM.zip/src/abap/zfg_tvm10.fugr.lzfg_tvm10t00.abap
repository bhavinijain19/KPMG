*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM10..........................................*
DATA:  BEGIN OF STATUS_ZTVM10                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM10                        .
CONTROLS: TCTRL_ZTVM10
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM10                        .
TABLES: ZTVM10                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
