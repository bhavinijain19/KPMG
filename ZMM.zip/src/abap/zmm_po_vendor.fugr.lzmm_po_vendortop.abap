FUNCTION-POOL ZMM_PO_VENDOR              MESSAGE-ID SV.

* INCLUDE LZMM_PO_VENDORD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_PO_VENDORT00                       . "view rel. data dcl.
