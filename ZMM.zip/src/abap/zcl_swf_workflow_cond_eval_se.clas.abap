class ZCL_SWF_WORKFLOW_COND_EVAL_SE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_EVAL .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SWF_WORKFLOW_COND_EVAL_SE IMPLEMENTATION.


  method IF_SWF_FLEX_IFS_CONDITION_EVAL~EVALUATE_CONDITION.
    DATA: lv_custom_field TYPE string.
    cv_is_true = abap_false.
SELECT SINGLE b~purchaseordertype, a~purchasinggroup,  b~plant
      FROM i_serviceentrysheet AS a
      INNER JOIN i_serviceentrysheetitem AS b
      ON a~serviceentrysheet = b~serviceentrysheet
      WHERE b~isdeleted IS INITIAL
      AND a~serviceentrysheet = @is_sap_object_node_type-sont_key_part_1
      INTO @DATA(ls_serviceentry).

*SELECT SINGLE essr~lblni,
*        essr~ebeln,
*        ekko~lifnr,
*        ekko~EKGRP,
*       ekpo~werks
*  INTO @DATA(ls_serviceentry)
*  FROM essr
*  INNER JOIN ekko
*          ON ekko~ebeln = essr~ebeln
*  INNER JOIN ekpo
*          ON ekpo~ebeln = essr~ebeln
*  WHERE essr~lblni = @is_sap_object_node_type-sont_key_part_1
*.


*
*
*    SELECT  SINGLE *
*      INTO  @DATA(ls_purchaseorder)
*      FROM Ekko
*      WHERE ebeln = @ls_serviceentry-ebeln.
*
*
*    SELECT  *
*      INTO @DATA(ls_purchaseorder_itm)
*      FROM ekpo UP TO 1 ROWS
*      WHERE ebeln = @ls_serviceentry-ebeln  ORDER BY PRIMARY KEY.
*    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************


    CASE is_condition-condition_id.
      WHEN 1.
        READ TABLE it_parameter_value INTO DATA(ls_param_value1) WITH KEY name = 'Plant'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value1-value.
          IF lv_custom_field = ls_serviceentry-plant.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.
*      WHEN 2.
*        READ TABLE it_parameter_value INTO DATA(ls_param_value2) WITH KEY name = 'Account Assign Cat'.
*        IF sy-subrc EQ 0.
*          lv_custom_field = ls_param_value2-value.
*          IF lv_custom_field = ls_serviceentry-.
*            cv_is_true = abap_true.
*          ENDIF.
*        ENDIF.
         WHEN 3.
        READ TABLE it_parameter_value INTO DATA(ls_param_value2) WITH KEY name = 'Purchasing Group'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value2-value.
          IF lv_custom_field = ls_serviceentry-purchasinggroup.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
