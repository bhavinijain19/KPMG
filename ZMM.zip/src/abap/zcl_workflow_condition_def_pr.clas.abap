class ZCL_WORKFLOW_CONDITION_DEF_PR definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_DEF .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKFLOW_CONDITION_DEF_PR IMPLEMENTATION.


  method IF_SWF_FLEX_IFS_CONDITION_DEF~GET_CONDITIONS.
FIELD-SYMBOLS: <lv_wf> TYPE any.
    DATA(LV_SCENARIO) = '(CL_SWF_FLEX_DEF_UTL_CONDITION=CP)LV_SCENARIO'.
    ASSIGN (LV_SCENARIO) TO <lv_wf>.
  ct_condition = VALUE #(
            ( id = 1 subject = 'PR Document Type' type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
              ( id = 2 subject = 'Plant'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
               ).

  ct_parameter = VALUE #(
            ( id = 1 name = 'PR Document Type'   xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string   mandatory = abap_true
             service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'DocumentType'
)
 ( id = 2 name = 'Plant'         xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_false
             service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'Plant' )

               ).




  endmethod.
ENDCLASS.
