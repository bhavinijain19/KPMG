class ZCL_SWF_WORKFLOW_COND_EVAL_SA definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_EVAL .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SWF_WORKFLOW_COND_EVAL_SA IMPLEMENTATION.


  METHOD if_swf_flex_ifs_condition_eval~evaluate_condition.
    DATA: lv_custom_field TYPE string.

    IF ( is_condition-condition_id > 1 ).
*      RAISE EXCEPTION TYPE cx_ble_runtime_error
*        EXPORTING
*          previous = NEW cx_swf_flex_lra( textid = cx_swf_flex_lra=>condition_not_supported ).
    ENDIF.

    cv_is_true = abap_false.
    SELECT  SINGLE *
      INTO  @DATA(ls_purchaseorder)
      FROM ekko
      WHERE ebeln = @is_sap_object_node_type-sont_key_part_1
      and bstyp = 'L'.

******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT  SINGLE *
*      INTO @DATA(ls_purchaseorder_itm)
*      FROM ekpo
*      WHERE ebeln = @is_sap_object_node_type-sont_key_part_1.
    SELECT *
      INTO @DATA(ls_purchaseorder_itm)
      FROM ekpo UP TO 1 ROWS
      WHERE ebeln = @is_sap_object_node_type-sont_key_part_1 ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************



    CASE is_condition-condition_id.
      WHEN 1.
        READ TABLE it_parameter_value INTO DATA(ls_param_value) WITH KEY name = 'Our Reference'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value-value.
          IF lv_custom_field = ls_purchaseorder-unsez.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.

      WHEN 2.
        READ TABLE it_parameter_value INTO DATA(ls_param_value1) WITH KEY name = 'Plant'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value1-value.
          IF lv_custom_field = ls_purchaseorder_itm-werks.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.
      WHEN 3.
        READ TABLE it_parameter_value INTO DATA(ls_param_value2) WITH KEY name = 'Account Assignment'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value2-value.
          IF lv_custom_field = ls_purchaseorder_itm-knttp.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.
   WHEN 4.
        READ TABLE it_parameter_value INTO ls_param_value WITH KEY name = 'Purchasing Group'.
        IF sy-subrc EQ 0.
          lv_custom_field = ls_param_value-value.
          IF lv_custom_field = ls_purchaseorder-EKGRP.
            cv_is_true = abap_true.
          ENDIF.
        ENDIF.

      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
