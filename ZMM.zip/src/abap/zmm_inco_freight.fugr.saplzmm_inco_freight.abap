*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_INCO_FREIGHTTOP.              " Global Declarations
  INCLUDE LZMM_INCO_FREIGHTUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_INCO_FREIGHTF...              " Subroutines
* INCLUDE LZMM_INCO_FREIGHTO...              " PBO-Modules
* INCLUDE LZMM_INCO_FREIGHTI...              " PAI-Modules
* INCLUDE LZMM_INCO_FREIGHTE...              " Events
* INCLUDE LZMM_INCO_FREIGHTP...              " Local class implement.
* INCLUDE LZMM_INCO_FREIGHTT99.              " ABAP Unit tests
  INCLUDE LZMM_INCO_FREIGHTF00                    . " subprograms
  INCLUDE LZMM_INCO_FREIGHTI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
