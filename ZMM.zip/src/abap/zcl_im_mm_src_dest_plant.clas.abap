class ZCL_IM_MM_SRC_DEST_PLANT definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MB_CHECK_LINE_BADI .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_SRC_DEST_PLANT IMPLEMENTATION.


  METHOD if_ex_mb_check_line_badi~check_line.
    DATA: lv_bwkey_s    TYPE t001w-bwkey,
          lv_bwkey_r    TYPE t001w-bwkey,
          lv_dummy      TYPE marc-matnr,
          lv_mbew_check TYPE mbew-matnr.

    " 1. Ensure Material is extended to Supplying Plant (MARC)
    SELECT SINGLE matnr FROM marc INTO lv_dummy
      WHERE matnr = is_mseg-matnr
        AND werks = is_mseg-werks. " Supplying Plant
    IF sy-subrc <> 0.
      " Error: Material not extended to supplying plant
    ENDIF.

    " 2. Ensure Material is extended to Receiving Plant (MARC)
    " Note: UMWRK is the receiving plant in transfer postings
    IF is_mseg-umwrk IS NOT INITIAL.
      SELECT SINGLE matnr FROM marc INTO lv_dummy
        WHERE matnr = is_mseg-matnr
          AND werks = is_mseg-umwrk.
      IF sy-subrc <> 0.
        " Error: Material not extended to receiving plant
      ENDIF.
    ENDIF.

    " 3. Get Supplying Valuation Area (T001W)
    SELECT SINGLE bwkey FROM t001w INTO lv_bwkey_s
      WHERE werks = is_mseg-werks.

    " 4. Get Receiving Valuation Area (T001W)
    IF is_mseg-umwrk IS NOT INITIAL.
      SELECT SINGLE bwkey FROM t001w INTO lv_bwkey_r
        WHERE werks = is_mseg-umwrk.
    ENDIF.

    " 5. Verify Valuation Record (MBEW) exists for BOTH plants with same Valuation Type
    " Only check if Split Valuation (BWTAR) is being used
    IF is_mseg-bwtar IS NOT INITIAL.

      " Check Supplying Plant Record
      SELECT SINGLE matnr FROM mbew INTO lv_mbew_check
        WHERE matnr = is_mseg-matnr
          AND bwkey = lv_bwkey_s
          AND bwtar = is_mseg-bwtar.
      IF sy-subrc <> 0.
        MESSAGE e001(zmsg) WITH 'Valuation type missing in supplying plant'.
      ENDIF.

      " Check Receiving Plant Record
      IF lv_bwkey_r IS NOT INITIAL.
        SELECT SINGLE matnr FROM mbew INTO lv_mbew_check
          WHERE matnr = is_mseg-matnr
            AND bwkey = lv_bwkey_r
            AND bwtar = is_mseg-bwtar.
        IF sy-subrc <> 0.
          " Throw the specific ERROR requested
          MESSAGE e001(zmsg) WITH 'Valuation type mismatch between supplying and receiving plant'.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
