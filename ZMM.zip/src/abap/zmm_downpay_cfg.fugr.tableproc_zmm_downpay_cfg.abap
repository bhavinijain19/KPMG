*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_DOWNPAY_CFG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_DOWNPAY_CFG     .

  PERFORM TABLEPROC.

ENDFUNCTION.
