FUNCTION-POOL ZMM_PLANT_MAT              MESSAGE-ID SV.

* INCLUDE LZMM_PLANT_MATD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_PLANT_MATT00                       . "view rel. data dcl.
