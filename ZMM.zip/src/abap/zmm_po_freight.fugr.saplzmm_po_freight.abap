*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_PO_FREIGHTTOP.                " Global Declarations
  INCLUDE LZMM_PO_FREIGHTUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_PO_FREIGHTF...                " Subroutines
* INCLUDE LZMM_PO_FREIGHTO...                " PBO-Modules
* INCLUDE LZMM_PO_FREIGHTI...                " PAI-Modules
* INCLUDE LZMM_PO_FREIGHTE...                " Events
* INCLUDE LZMM_PO_FREIGHTP...                " Local class implement.
* INCLUDE LZMM_PO_FREIGHTT99.                " ABAP Unit tests
  INCLUDE LZMM_PO_FREIGHTF00                      . " subprograms
  INCLUDE LZMM_PO_FREIGHTI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
