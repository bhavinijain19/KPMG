*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTVM6...........................................*
DATA:  BEGIN OF STATUS_ZTVM6                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTVM6                         .
CONTROLS: TCTRL_ZTVM6
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZTVM6                         .
TABLES: ZTVM6                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
