FUNCTION zfm_set_data_gate.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(G_NO_INPUT) TYPE  XFELD OPTIONAL
*"     REFERENCE(IV_MBLNR) TYPE  MKPF-MBLNR OPTIONAL
*"     REFERENCE(IV_MJAHR) TYPE  MKPF-MJAHR OPTIONAL
*"----------------------------------------------------------------------

  g_no_dis = g_no_input.

  gv_mblnr = iv_mblnr.
  gv_mjahr = iv_mjahr.



ENDFUNCTION.
