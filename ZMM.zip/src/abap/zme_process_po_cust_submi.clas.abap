class ZME_PROCESS_PO_CUST_SUBMI definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZME_PROCESS_PO_CUST_SUBMI IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.

    INCLUDE mm_messages_mac.

    DATA: ls_header    TYPE mepoheader,
          lv_submi     TYPE submi,
          lr_bsart_exc TYPE RANGE OF ekko-bsart.

    ls_header = im_header->get_data( ).

    lv_submi = ls_header-submi.

    " 1. IMPORTANT: Clear previous instances of your error message
    " This prevents old errors from sticking when you click 'Check'
    mmpur_context mmcnt_context_badi.
    IF ls_header-id IS NOT INITIAL.
      mmpur_remove_msg_by_context ls_header-id mmcnt_context_badi.
    ENDIF.

    SELECT sign, opti AS option, low, high
      FROM tvarvc
      INTO TABLE @DATA(lt_tvarvc)
      WHERE name = 'ZMM_COLL_STO'
        AND type = 'S'. " 'S' for Selection Options maintained in STVARV

    IF sy-subrc = 0.
      lr_bsart_exc = VALUE #( FOR wa IN lt_tvarvc ( sign   = wa-sign
                                                    option = wa-option
                                                    low    = wa-low
                                                    high   = wa-high ) ).
    ENDIF.

* 3. Logic: If current BSART is NOT in the exclusion list, validate collective no.
*    IF ls_header-bsart NOT IN lr_bsart_exc.
    IF ls_header-bsart IN lr_bsart_exc.
      RETURN.
    ENDIF.

    SELECT SINGLE submi
      FROM zplant_coord
      INTO @DATA(lv_submi_check)
      WHERE submi = @lv_submi.

    IF sy-subrc <> 0.
*      MESSAGE ZMM_MSG TYPE 'E'.
      MESSAGE 'Enter valid collective no.' TYPE 'E'.
    ENDIF.


  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  METHOD if_ex_me_process_po_cust~process_header.

    INCLUDE mm_messages_mac.

    DATA: ls_header    TYPE mepoheader,
          lv_submi     TYPE submi,
          lr_bsart_exc TYPE RANGE OF ekko-bsart.

    ls_header = im_header->get_data( ).

    lv_submi = ls_header-submi.

    " 1. IMPORTANT: Clear previous instances of your error message
    " This prevents old errors from sticking when you click 'Check'
    mmpur_context mmcnt_context_badi.
    IF ls_header-id IS NOT INITIAL.
      mmpur_remove_msg_by_context ls_header-id mmcnt_context_badi.
    ENDIF.

    SELECT sign, opti AS option, low, high
      FROM tvarvc
      INTO TABLE @DATA(lt_tvarvc)
      WHERE name = 'ZMM_COLL_STO'
        AND type = 'S'. " 'S' for Selection Options maintained in STVARV

    IF sy-subrc = 0.
      lr_bsart_exc = VALUE #( FOR wa IN lt_tvarvc ( sign   = wa-sign
                                                    option = wa-option
                                                    low    = wa-low
                                                    high   = wa-high ) ).
    ENDIF.

* 3. Logic: If current BSART is NOT in the exclusion list, validate collective no.
*    IF ls_header-bsart NOT IN lr_bsart_exc.
    IF ls_header-bsart IN lr_bsart_exc.
      RETURN.
    ENDIF.

    SELECT SINGLE submi
      FROM zplant_coord
      INTO @DATA(lv_submi_check)
      WHERE submi = @lv_submi.

    IF sy-subrc <> 0.
*      MESSAGE ZMM_MSG TYPE 'E'.
      MESSAGE 'Enter valid collective no.' TYPE 'E'.
    ENDIF.


  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
