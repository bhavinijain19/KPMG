FUNCTION-POOL ZMM_UNSEZ                  MESSAGE-ID SV.

* INCLUDE LZMM_UNSEZD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_UNSEZT00                           . "view rel. data dcl.
