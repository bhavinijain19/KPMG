*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_PO_VENDOR...................................*
DATA:  BEGIN OF STATUS_ZMM_PO_VENDOR                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_PO_VENDOR                 .
CONTROLS: TCTRL_ZMM_PO_VENDOR
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_PO_VENDOR                 .
TABLES: ZMM_PO_VENDOR                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
