*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_PO_EMAILTOP.                  " Global Declarations
  INCLUDE LZMM_PO_EMAILUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_PO_EMAILF...                  " Subroutines
* INCLUDE LZMM_PO_EMAILO...                  " PBO-Modules
* INCLUDE LZMM_PO_EMAILI...                  " PAI-Modules
* INCLUDE LZMM_PO_EMAILE...                  " Events
* INCLUDE LZMM_PO_EMAILP...                  " Local class implement.
* INCLUDE LZMM_PO_EMAILT99.                  " ABAP Unit tests
