CLASS zcl_pr_del_check_po DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_badi_interface .
    INTERFACES if_ex_me_process_po_cust .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_PR_DEL_CHECK_PO IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~close.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_header.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_header_refkeys.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_item.

*  " 'D' is the standard fixed value for Display in domain MMPUR_FIELDSTATUS
*  CONSTANTS c_fs_display TYPE mmpur_fieldstatus VALUE 'D'.
*
*  DATA: ls_item     TYPE mepoitem,
*        lv_sum_qty  TYPE menge_d,
*        lv_open_qty TYPE menge_d.
*
*  " Only in change mode; avoid greying in ME21N
*  IF sy-tcode <> 'ME22N'.
*    RETURN.
*  ENDIF.
*
*  " Get current item
*  ls_item = im_item->get_data( ).
*
*  " Only for persisted items
*  IF ls_item-ebeln IS INITIAL OR ls_item-ebelp IS INITIAL.
*    RETURN.
*  ENDIF.
*
*  " Delivered quantity with sign from EKBE (goods movements only)
*  CLEAR lv_sum_qty.
*  " If your Open SQL supports CASE:
*  SELECT SUM( CASE WHEN shkzg = 'H' THEN -menge ELSE menge END )
*         INTO @lv_sum_qty
*         FROM ekbe
*         WHERE ebeln = @ls_item-ebeln
*           AND ebelp = @ls_item-ebelp
*           AND bewtp = 'E'.          " Goods movements
*  IF sy-subrc <> 0.
*    lv_sum_qty = 0.
*  ENDIF.

  " Open qty = ordered - delivered
*  lv_open_qty = ls_item-menge - lv_sum_qty.
*
*  " If still open, make Net Price read-only
*  IF lv_open_qty > 0.
**    ch_fieldselection-netpr = c_fs_display.
*  ENDIF.

*    " Delivered qty with sign from EKBE (goods movements only)
*    CLEAR lv_sum_qty.
*    " If your release supports CASE in Open SQL, use this:
*    SELECT SUM( CASE WHEN shkzg = 'H' THEN -menge ELSE menge END )
*           INTO @lv_sum_qty
*           FROM ekbe
*           WHERE ebeln = @ls_item-ebeln
*             AND ebelp = @ls_item-ebelp
*             AND bewtp = 'E'.        " Goods movements
*    IF sy-subrc <> 0.
*      lv_sum_qty = 0.
*    ENDIF.
*
*    " Open qty = ordered - delivered
*    lv_open_qty = ls_item-menge - lv_sum_qty.
*
*    " If still open, make Net Price read-only
*    IF lv_open_qty > 0.
*      ch_fieldselection-netpr = mmpur_fs_display. " requires TYPE-POOLS mmpur
*      " Or alternative without type-pool:
*      " ch_fieldselection-netpr = me_gui_constants=>fieldstatus_display.
*    ENDIF.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~fieldselection_item_refkeys.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~initialize.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_account.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_header.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_item.

*    DATA: lv_open_qty TYPE menge_d.
*
*    DATA(ls_item) = im_item->get_data( ).
*
*    SELECT SINGLE * FROM ekbe INTO @DATA(ls_ekbe) WHERE ebeln = @ls_item-ebeln AND ebelp = @ls_item-ebelp.
*
*    lv_open_qty = ls_item-menge - ls_ekbe-menge.
*
*    IF lv_open_qty IS NOT INITIAL.
*      LOOP AT SCREEN.
*
*      ENDLOOP.
*    ENDIF.

  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_schedule.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~open.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~post.
  ENDMETHOD.
ENDCLASS.
