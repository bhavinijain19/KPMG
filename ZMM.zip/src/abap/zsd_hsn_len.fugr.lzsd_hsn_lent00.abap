*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_HSN_LEN.....................................*
DATA:  BEGIN OF STATUS_ZSD_HSN_LEN                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_HSN_LEN                   .
CONTROLS: TCTRL_ZSD_HSN_LEN
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZSD_HSN_LEN                   .
TABLES: ZSD_HSN_LEN                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
