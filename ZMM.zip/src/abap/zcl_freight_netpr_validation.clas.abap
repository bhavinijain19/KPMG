class ZCL_FREIGHT_NETPR_VALIDATION definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_FREIGHT_NETPR_VALIDATION IMPLEMENTATION.


  method IF_EX_ME_PROCESS_PO_CUST~CHECK.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_HEADER.
  endmethod.


  METHOD if_ex_me_process_po_cust~process_item.

    DATA ls_freight TYPE zmm_po_freight.

    DATA lt_komv TYPE mmpur_tkomv.

    DATA(ls_item) = im_item->get_data( ).

    CALL METHOD im_item->get_conditions
      IMPORTING
        ex_conditions = lt_komv.

    DATA lv_msg TYPE string.

    SELECT SINGLE * FROM ekko INTO @DATA(ls_ekko) WHERE ebeln EQ @ls_item-ebeln AND bsart IN ('ZRAW', 'ZPKG', 'ZTRD').

    IF ls_ekko IS NOT INITIAL.

      DATA(lv_cond_val) = ls_item-menge * ls_item-netpr.

      LOOP AT lt_komv ASSIGNING FIELD-SYMBOL(<lfs_komv>).
        CASE <lfs_komv>-kschl.
          WHEN 'FRA1'.
            DATA(lv_fra1) = <lfs_komv>-kbetr.
          WHEN 'FRC2'.
            DATA(lv_frc2) = <lfs_komv>-kbetr.
          WHEN 'FRB1'.
            DATA(lv_frb1) = <lfs_komv>-kbetr.
          WHEN 'FRC5'.
            DATA(lv_frc5) = <lfs_komv>-kbetr.
          WHEN 'FRB4'.
            DATA(lv_frb4) = <lfs_komv>-kbetr.
          WHEN 'FRB3'.
            DATA(lv_frb3) = <lfs_komv>-kbetr.
          WHEN 'FRC4'.
            DATA(lv_frc4) = <lfs_komv>-kbetr.
        ENDCASE.
      ENDLOOP.

      DATA(lv_freight_val) = lv_fra1 + lv_frb1 + lv_frb3 + lv_frb4 + lv_frc2 + lv_frc4 + lv_frc5.

      IF lv_cond_val < lv_freight_val.
        lv_msg = |Freight Value cannot be greater than Condition Value in line item: { ls_item-ebelp }|.
        MESSAGE lv_msg TYPE 'E'.
      ENDIF.
      CLEAR: lv_cond_val, lv_fra1, lv_frb1, lv_frb3, lv_frb4, lv_frc2, lv_frc4, lv_frc5, lv_freight_val.

      SELECT matnr, bwkey, verpr
        FROM mbew
        INTO TABLE @DATA(lt_mbew)
        WHERE matnr EQ @ls_item-matnr
        AND bwkey EQ @ls_item-werks.
      IF lt_mbew IS NOT INITIAL.

        LOOP AT lt_mbew INTO DATA(ls_mbew).
          CLEAR ls_freight.
          ls_freight-matnr = ls_mbew-matnr.
          ls_freight-bwkey = ls_mbew-bwkey.
          ls_freight-verpr = ls_mbew-verpr.

          MODIFY zmm_po_freight FROM @ls_freight.
        ENDLOOP.

        IF sy-subrc IS INITIAL.
          COMMIT WORK.
          MESSAGE 'Records updated successfully' TYPE 'S'.
        ELSE.
          ROLLBACK WORK.
          MESSAGE 'Records update failed' TYPE 'E'.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
