*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTAX_INOP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTAX_INOP           .

  PERFORM TABLEPROC.

ENDFUNCTION.
