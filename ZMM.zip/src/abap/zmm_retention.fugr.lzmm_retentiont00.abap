*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_RETENTION...................................*
DATA:  BEGIN OF STATUS_ZMM_RETENTION                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_RETENTION                 .
CONTROLS: TCTRL_ZMM_RETENTION
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_RETENTION                 .
TABLES: ZMM_RETENTION                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
