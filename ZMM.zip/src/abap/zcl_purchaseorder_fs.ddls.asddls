@AbapCatalog.sqlViewAppendName: 'ZCLPURCHASEEXT'
@EndUserText.label: 'MY INBOX EXTEND PO ITEM'
--extend view C_PurchaseOrderFs with ZCL_PURCHASEORDER_FS
extend view C_PurOrdItemEnh with ZCL_PURCHASEORDER_FS
{ 
   @UI.lineItem: [{
            qualifier: 'PurchItem',
            position: 120,
            importance: #HIGH }, {
            position: 120,
            importance: #HIGH 
            }]
            
 --  Plant as  GLACCOUNT, 
   test as WBS ,
                   
     @UI.lineItem: [{
            qualifier: 'PurchItem',
            position: 130,
            importance: #HIGH }, {
            position: 130,
            importance: #HIGH 
            }]
            
 --  Plant as  GLACCOUNT, 
   KOSTL as KOSTL ,        
   
     @UI.lineItem: [{
            qualifier: 'PurchItem',
            position: 140,
            importance: #HIGH }, {
            position: 140,
            importance: #HIGH 
            }]
            
 --  Plant as  GLACCOUNT, 
   SAKTO as SAKTO   
      

   } 
