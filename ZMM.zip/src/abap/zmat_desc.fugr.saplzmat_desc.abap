*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMAT_DESCTOP.                     " Global Declarations
  INCLUDE LZMAT_DESCUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMAT_DESCF...                     " Subroutines
* INCLUDE LZMAT_DESCO...                     " PBO-Modules
* INCLUDE LZMAT_DESCI...                     " PAI-Modules
* INCLUDE LZMAT_DESCE...                     " Events
* INCLUDE LZMAT_DESCP...                     " Local class implement.
* INCLUDE LZMAT_DESCT99.                     " ABAP Unit tests
  INCLUDE LZMAT_DESCF00                           . " subprograms
  INCLUDE LZMAT_DESCI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
