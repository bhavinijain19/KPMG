FUNCTION-POOL ZFG_TVM11                  MESSAGE-ID SV.

* INCLUDE LZFG_TVM11D...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_TVM11T00                           . "view rel. data dcl.
