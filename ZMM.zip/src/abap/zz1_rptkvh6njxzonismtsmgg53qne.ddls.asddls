@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_1A7778BA51D5'

extend view I_SERVICEENTRYSHEETAPI01 with ZZ1_RPTKVH6NJXZONISMTSMGG53QNE
  
{ 
  _ServiceEntrySheetExtension.ZZ1_REFERENCE_MDH as ZZ1_REFERENCE_MDH
}
