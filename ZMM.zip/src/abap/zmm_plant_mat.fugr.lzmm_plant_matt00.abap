*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_PLANT_MAT...................................*
DATA:  BEGIN OF STATUS_ZMM_PLANT_MAT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_PLANT_MAT                 .
CONTROLS: TCTRL_ZMM_PLANT_MAT
            TYPE TABLEVIEW USING SCREEN '9000'.
*.........table declarations:.................................*
TABLES: *ZMM_PLANT_MAT                 .
TABLES: ZMM_PLANT_MAT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
