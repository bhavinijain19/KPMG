*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_PRPO_TYPE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_PRPO_TYPE       .

  PERFORM TABLEPROC.

ENDFUNCTION.
