*----------------------------------------------------------------------*
***INCLUDE LZFG_MIGO_EXTI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.
  CASE sy-ucomm.
    WHEN 'OK_POST' OR 'OK_POST1'.
      CLEAR: gs_zmm_migo_cf.
      IF gv_header_text IS NOT INITIAL.
        gs_zmm_migo_cf-mblnr = gv_mblnr.
        gs_zmm_migo_cf-mjahr = gv_mjahr.
        gs_zmm_migo_cf-zz1_header_text = gv_header_text.
        MODIFY zmm_migo_cf FROM gs_zmm_migo_cf.

        CLEAR: gv_header_text.
      ENDIF.
  ENDCASE.
ENDMODULE.
