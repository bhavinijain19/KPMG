*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZLOG_DETAILS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZLOG_DETAILS        .

  PERFORM TABLEPROC.

ENDFUNCTION.
