@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_6FD512398F20'

extend view E_SERVICEENTRYSHEET with ZZ1_OGQZV5HOV3OMFQICMGHMFNSJZ4
  
{ 
  Persistence.ZZ1_DOCUMENTDATE_MDH as ZZ1_DOCUMENTDATE_MDH
}
