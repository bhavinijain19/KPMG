class ZCL_IM_MM_MB_MIGO_BADI_M definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MB_MIGO_BADI .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_MB_MIGO_BADI_M IMPLEMENTATION.


  method IF_EX_MB_MIGO_BADI~CHECK_HEADER.
  endmethod.


  method IF_EX_MB_MIGO_BADI~CHECK_ITEM.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_DELETE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_LOAD.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_SAVE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~INIT.
  endmethod.


  method IF_EX_MB_MIGO_BADI~LINE_DELETE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~LINE_MODIFY.
  endmethod.


  method IF_EX_MB_MIGO_BADI~MAA_LINE_ID_ADJUST.
  endmethod.


  method IF_EX_MB_MIGO_BADI~MODE_SET.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PAI_DETAIL.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PAI_HEADER.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PBO_DETAIL.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PBO_HEADER.
  endmethod.


  method IF_EX_MB_MIGO_BADI~POST_DOCUMENT.
*&----------------------development details----------------------------*
*&--Method           : IF_EX_MB_MIGO_BADI~POST_DOCUMENT             ---*
*&--Package          : ZFI_ABAP                                     ---*
*&--Description      : Mail Intimation 501/502 Movement Type        ---*
*&--Transaction Code : MIGO                                         ---*
*&--Technical Owner  : RAHUL VASITA ( VC-ERP ) / PARTH SHUKLA       ---*
*&--Functional Owner : ANIKET PATIL ( ABHIYANTA )/ VIPUL KULSHRESHTHA -*
*&--TR No            : DEVK943855                                   ---*
*&---------------------------------------------------------------------*

    TYPES : BEGIN OF ty_log,
              werks  TYPE werks_d,
              budat  TYPE budat,
              mblnr  TYPE mseg-mblnr,
              uname  TYPE sy-uname,
              u_name TYPE char20,
              mtart type mara-mtart,"Added by Raj on 17.07.2024
            END OF ty_log.


data :lv_subject type SO_OBJ_DES."Added by Raj on 03.02.2025


    DATA: lt_log TYPE TABLE OF ty_log,
          ls_log TYPE ty_log.

    DATA: lv_bwart TYPE mseg-bwart,
          lv_mblnr TYPE mseg-mblnr.
    DATA : main_text      TYPE bcsy_text,
           binary_content TYPE solix_tab,
           size           TYPE so_obj_len,
           send_to_all    TYPE os_boolean,
           lv_attachname  TYPE so_obj_des,
           lv_string      TYPE string.
    DATA : lv_mailtext TYPE char255.
    DATA :send_request  TYPE REF TO cl_bcs,
          sender        TYPE REF TO cl_cam_address_bcs,
          document      TYPE REF TO cl_document_bcs,
          recipient     TYPE REF TO if_recipient_bcs,
          lv_mail       TYPE adr6-smtp_addr,
          bcs_exception TYPE REF TO cx_bcs.

******************Begin of ATC changes 13/02/26   UDAYABAP03*************
*    SELECT SINGLE name , low FROM tvarvc INTO @DATA(ls_switch) WHERE name = 'ZMM_MIGO_BWART_SWITCH' AND type = 'P'.
    SELECT name , low FROM tvarvc INTO @DATA(ls_switch) UP TO 1 ROWS WHERE name = 'ZMM_MIGO_BWART_SWITCH' AND type = 'P' ORDER BY PRIMARY KEY.
    ENDSELECT.
******************End of ATC changes 13/02/26   UDAYABAP03*************
    IF ls_switch-low = abap_true.
      SELECT  bname , persnumber , addrnumber FROM usr21 INTO TABLE @DATA(lt_usr21) WHERE bname = @sy-uname.
      IF lt_usr21[] IS NOT INITIAL.
        SELECT persnumber , date_to , name_text FROM adrp INTO TABLE @DATA(lt_adrp) FOR ALL ENTRIES IN @lt_usr21 WHERE persnumber = @lt_usr21-persnumber.
      ENDIF."IF lt_usr21[] IS NOT INITIAL.
      SELECT name , low FROM tvarvc INTO TABLE @DATA(lt_bwart) WHERE name = 'ZMM_MIGO_BWART' AND type = 'S'.

*******Begin of changes Added by Raj Kumar Bestha on 17.07.2024*********Ticket no:ALTITB000434**********
        if it_mseg is not INITIAL.
          select matnr,mtart from mara into table @data(it_mara)
            FOR ALL ENTRIES IN @it_mseg WHERE matnr = @it_mseg-matnr.
        endif.
*******End of changes Added by Raj Kumar Bestha on 17.07.2024*********Ticket no:ALTITB000434**********
      LOOP AT it_mseg ASSIGNING FIELD-SYMBOL(<ls_mseg>).
        lv_bwart = VALUE #( lt_bwart[ low = <ls_mseg>-bwart ]-low OPTIONAL ).
        IF lv_bwart IS NOT INITIAL.
          ls_log-werks = <ls_mseg>-werks.
          ls_log-mblnr = <ls_mseg>-mblnr.
          ls_log-budat = <ls_mseg>-budat_mkpf.
          ls_log-uname = <ls_mseg>-usnam_mkpf.
          DATA(ls_usr21) = VALUE #( lt_usr21[ bname = sy-uname ] OPTIONAL ).
          IF ls_usr21 IS NOT INITIAL.
            ls_log-u_name = VALUE #( lt_adrp[ persnumber = ls_usr21-persnumber ]-name_text OPTIONAL ).
          ENDIF.

          READ TABLE it_mara into data(wa_mara) with key matnr = <ls_mseg>-matnr."Material Type Added by Raj on 17.07.2024
          if sy-subrc = 0.
            ls_log-mtart = wa_mara-mtart.
          endif.
          APPEND ls_log TO lt_log.
          CLEAR: ls_log,ls_usr21,lv_bwart,wa_mara.

        ENDIF."IF lv_bwart IS NOT INITIAL.
      ENDLOOP.

      IF lt_log[] IS NOT INITIAL.
        REFRESH: main_text[].
        CLEAR: lv_mblnr , lv_mailtext.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = is_mkpf-mblnr
          IMPORTING
            output = lv_mblnr.

        SELECT name,
               low
          FROM tvarvc
          INTO TABLE @DATA(lt_mail)
          WHERE name = 'ZMM_MIGO_BWART_MAIL'
            AND type = 'S'.

        lv_mailtext = |<!DOCTYPE html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |</head>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = '<style> table, tr , td , th ' && `{` && 'border: 2px solid black; width : auto; border-collapse: collapse;' && `}` && '</style>'.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |<body>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |<h6>Details of 501/502 movement entry that has been posted in system:</h6>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<table>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<tr> <tH> PLANT </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th> POSTING DATE </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |<th> MATERIAL TYPE </th>|.  "Added by Raj on 17.07.2024
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |<th> DOCUMENT NO </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th> SAP ID </th>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<th> USER NAME OF SAP ID</th></tr>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        LOOP AT lt_log INTO ls_log.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
            EXPORTING
              input  = ls_log-mblnr
            IMPORTING
              output = ls_log-mblnr.

          lv_mailtext = |<tr> <td> { ls_log-werks } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td> { ls_log-budat+6(2) }.{ ls_log-budat+4(2) }.{ ls_log-budat+0(4) } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

              lv_mailtext = |<td> { ls_log-mtart } </td>|."Added by Raj on 17.07.2024
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td> { ls_log-mblnr } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td> { ls_log-uname } </td>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.

          lv_mailtext = |<td> { ls_log-u_name } </td></tr>|.
          APPEND lv_mailtext TO main_text.
          CLEAR : lv_mailtext.
        ENDLOOP.

        lv_mailtext = |</table>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.

        lv_mailtext = |<h6>This is System Generated Email do not Reply</h6>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


        lv_mailtext = |</body> </html>|.
        APPEND lv_mailtext TO main_text.
        CLEAR : lv_mailtext.


***********Begin of Changes Added by Raj on 03.02.2025********
  READ TABLE lt_log INTO ls_log INDEX 1.
  CONCATENATE ls_log-mtart '-' 'INTIMATION OF 501/502 MOVEMENT ENTRY POSTING' into lv_subject.
*********End of Changes Added by Raj on 03.02.2025************



        TRY .
            send_request = cl_bcs=>create_persistent( ).
            sender = cl_cam_address_bcs=>create_internet_address(
                 i_address_string = 'SAP.ASTRAL@ASTRALLTD.COM'
             ).

            CALL METHOD send_request->set_sender( sender ).
            document = cl_document_bcs=>create_document(
                  i_type          = 'HTM'
*                  i_subject       = 'INTIMATION OF 501/502 MOVEMENT ENTRY POSTING'  "Commented by Raj on 03.02.2025
                  i_subject       = lv_subject  "Added by Raj on 03.02.2025
            i_text          =  main_text     ).

            send_request->set_document( document ).

            LOOP AT lt_mail INTO DATA(ls_mail).
              lv_mail = ls_mail-low."'SAP.ABAP@ASTRALLTD.COM'. "
              recipient = cl_cam_address_bcs=>create_internet_address( lv_mail ).
              send_request->add_recipient( recipient ).
            ENDLOOP.

            send_to_all = send_request->send( i_with_error_screen = 'X' ).
            IF send_to_all IS NOT INITIAL.
**              COMMIT WORK.
**              MESSAGE 'Mail Send Successfully' TYPE 'S'.
            ELSE.
**              ROLLBACK WORK.
**              MESSAGE 'Error While Send Email' TYPE 'S' DISPLAY LIKE 'E'.
**              RETURN.
            ENDIF.

          CATCH cx_bcs INTO bcs_exception.

        ENDTRY.
      ENDIF.

    ENDIF."IF ls_switch-low = abap_true.


  endmethod.


  method IF_EX_MB_MIGO_BADI~PROPOSE_SERIALNUMBERS.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PUBLISH_MATERIAL_ITEM.
  endmethod.


  method IF_EX_MB_MIGO_BADI~RESET.
  endmethod.


  method IF_EX_MB_MIGO_BADI~STATUS_AND_HEADER.
  endmethod.
ENDCLASS.
