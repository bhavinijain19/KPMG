class ZMM_CL_DPR_VALIDATION definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZMM_CL_DPR_VALIDATION IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_header.
*&----------------------Development Details----------------------------*
*&--Enhancemnet      : ZMM_CL_DPR_VALIDATION                        ---*
*&--Package          : ZMM_ABAP                                     ---*
*&--Description      : Down payment terms validation                ---*
*&--RICEF ID         : 3-1140                                       ---*
*&--Technical Owner  : Saurabh Saumya                               ---*
*&--Functional Owner : Om Prakash                                   ---*
*&--TR No            : DEVK955133                                   ---*
*&---------------------------------------------------------------------*
    DATA ls_header TYPE mepoheader.

    IF im_header IS INITIAL.
      RETURN.
    ENDIF.

    im_header->get_data( RECEIVING re_data = ls_header ).

    IF ls_header-zterm IS NOT INITIAL.
      DATA(lv_exists) = abap_false.

      SELECT SINGLE zterm , zperc
        FROM zmm_downpay_cfg
        WHERE zterm   = @ls_header-zterm
          AND zactive = 'X'
        INTO @DATA(ls_zterm).

      IF sy-subrc = 0.
        lv_exists = abap_true.
      ENDIF.

      IF lv_exists = abap_true.
        ls_header-dptyp = 'M'.
*-- Begin of changes for Downpaymenet Percent and Downpayment Date By Hemang Req By : Sachin k on 03/04/2026
        IF sy-uname = 'ARIBACIG'.
          IF ls_zterm-zperc IS NOT INITIAL.
            ls_header-dppct = ls_zterm-zperc.
          ENDIF.
          ls_header-dpdat = sy-datum.
        ENDIF.
*-- End of changes for Downpaymenet Percent and Downpayment Date By Hemang Req By : Sachin k on 03/04/2026
        im_header->set_data( EXPORTING im_data = ls_header ).
        im_header->set_changed( ).
      ELSEIF lv_exists = abap_false.
        ls_header-dptyp = ' '.
        im_header->set_data( EXPORTING im_data = ls_header ).
        im_header->set_changed( ).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
