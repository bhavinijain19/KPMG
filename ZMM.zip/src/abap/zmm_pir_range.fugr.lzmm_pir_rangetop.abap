FUNCTION-POOL ZMM_PIR_RANGE              MESSAGE-ID SV.

* INCLUDE LZMM_PIR_RANGED...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_PIR_RANGET00                       . "view rel. data dcl.
