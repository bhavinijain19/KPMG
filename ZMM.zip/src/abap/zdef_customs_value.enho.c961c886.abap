"Name: \TY:CL_MRM_INVOICE_CHANGE\ME:INVOICE_PROPOSE_VALUES_MIR7\SE:END\EI
ENHANCEMENT 0 ZDEF_CUSTOMS_VALUE.

FIELD-SYMBOLS : <lx_desreg> TYPE mmcr_drseg .
FIELD-SYMBOLS :<lx_ebeln> TYPE EBELN .
DATA : LV_KNUMV TYPE knumv .
DATA : LV_WKURS TYPE WKURS ,
       LV_KWERT TYPE KWERT .

if ct_drseg  is NOT INITIAL .

  loop at ct_drseg ASSIGNING <lx_desreg> WHERE kschl = 'JCDB'.

     SELECT SINGLE WKURS knumv from ekko into (LV_WKURS , LV_KNUMV) where EBELN = <lx_desreg>-ebeln
                                                                                                    .
       if sy-subrc eq 0 .

     SELECT SINGLE KWERT FROM PRCD_ELEMENTS INTO LV_KWERT WHERE knumv = LV_KNUMV
                                                  and kposn = <lx_desreg>-ebelp
                                                  AND kschl = 'ZASV'.

     IF SY-subrc EQ 0.
        <lx_desreg>-customs_val = LV_KWERT * LV_WKURS.
*        <lx_desreg>-menge = '1000.00'.
     ENDIF.
     CLEAr : LV_WKURS , LV_KNUMV , LV_KWERT.
     endif.
 ENDLOOP.
endif.

ENDENHANCEMENT.
