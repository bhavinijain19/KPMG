FUNCTION-POOL ZMM_GATE_ITEM_NEW.            "MESSAGE-ID ..

* INCLUDE LZMM_GATE_ITEM_NEWD...             " Local class definition
