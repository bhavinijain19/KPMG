*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_SU_NUMBER...................................*
DATA:  BEGIN OF STATUS_ZMM_SU_NUMBER                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_SU_NUMBER                 .
CONTROLS: TCTRL_ZMM_SU_NUMBER
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_SU_NUMBER                 .
TABLES: ZMM_SU_NUMBER                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
