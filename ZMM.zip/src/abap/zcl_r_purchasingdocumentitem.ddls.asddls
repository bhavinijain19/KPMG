@AbapCatalog.sqlViewAppendName: 'ZPURDOCIM_R'
@EndUserText.label: 'R_PurchasingDocumentItem'
extend view  R_PurchasingDocumentItem with ZCL_R_PurchasingDocumentItem
{
    ekpo.ps_psp_pnr as test,
    ekpo.sakto as SAKTO,
    ekpo.kostl as KOSTL
}
