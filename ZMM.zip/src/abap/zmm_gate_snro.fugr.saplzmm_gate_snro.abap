*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_GATE_SNROTOP.                 " Global Declarations
  INCLUDE LZMM_GATE_SNROUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_GATE_SNROF...                 " Subroutines
* INCLUDE LZMM_GATE_SNROO...                 " PBO-Modules
* INCLUDE LZMM_GATE_SNROI...                 " PAI-Modules
* INCLUDE LZMM_GATE_SNROE...                 " Events
* INCLUDE LZMM_GATE_SNROP...                 " Local class implement.
* INCLUDE LZMM_GATE_SNROT99.                 " ABAP Unit tests
  INCLUDE LZMM_GATE_SNROF00                       . " subprograms
  INCLUDE LZMM_GATE_SNROI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
