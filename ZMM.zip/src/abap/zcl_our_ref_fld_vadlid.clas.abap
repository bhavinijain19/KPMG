class ZCL_OUR_REF_FLD_VADLID definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_OUR_REF_FLD_VADLID IMPLEMENTATION.


  method IF_EX_ME_PROCESS_PO_CUST~CHECK.
*&----------------------Development Details----------------------------*
*&--Enhancemnet      : ZCL_OUR_REF_FLD_VALID                       ---*
*&--Package          : ZMM_ABAP                                     ---*
*&--Description      : Defect : Our Ref. field value restriction    ---*
*&--                 : from F4 Search help                          ---*
*&--RICEF ID         : N.A                                          ---*
*&--Technical Owner  : Saurabh Saumya                               ---*
*&--Functional Owner : Om Prakash                                   ---*
*&--TR No            : DEVK902792                                   ---*
*&---------------------------------------------------------------------*
    DATA(lo_header)     = im_header.
    DATA(ls_header) = lo_header->get_data( ).

    IF ls_header-unsez IS NOT INITIAL.
      SELECT SINGLE *
        FROM zmm_unsez
        WHERE unsez EQ @ls_header-unsez
        INTO @DATA(lv_unsez).

        IF sy-subrc NE 0.
          MESSAGE 'Choose Our reference from the available list only' TYPE 'E'.
        ENDIF.
    ENDIF.

  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
