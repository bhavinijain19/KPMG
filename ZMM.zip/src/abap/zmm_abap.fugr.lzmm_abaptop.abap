FUNCTION-POOL ZMM_ABAP.                     "MESSAGE-ID ..

* INCLUDE LZMM_ABAPD...                      " Local class definition
