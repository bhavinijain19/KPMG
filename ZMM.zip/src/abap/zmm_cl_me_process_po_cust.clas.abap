class ZMM_CL_ME_PROCESS_PO_CUST definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZMM_CL_ME_PROCESS_PO_CUST IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.

    DATA: lo_header     TYPE REF TO if_purchase_order_mm,
          lt_text       TYPE  mmpur_t_textlines,
          lt_set_values TYPE TABLE OF rgsb4,
          lr_bsart      TYPE RANGE OF bsart.

    CONSTANTS: lc_set_name TYPE setnamenew VALUE 'ZPO_BSART_MANDATORY_INCO'.

    lo_header = im_header.

    lo_header->if_longtexts_mm~get_text( EXPORTING im_tdid = 'F01'
                                         IMPORTING ex_textlines = lt_text ).
*    IF lt_text IS INITIAL. "Commented by Bhaumik
*      MESSAGE e001(zmm_msgs).
*    ENDIF.

    DATA(ls_header) = lo_header->get_data( ).

    IF ls_header-bsart IS NOT INITIAL.
      CALL FUNCTION 'G_SET_GET_ALL_VALUES'
        EXPORTING
          client        = sy-mandt
          setnr         = lc_set_name
          table         = 'EKKO'
          class         = '0000' " Class '0000' is typically used for general sets
          fieldname     = 'BSART'
        TABLES
          set_values    = lt_set_values
        EXCEPTIONS
          set_not_found = 1
          OTHERS        = 2.

      IF sy-subrc = 0.
        lr_bsart = VALUE #(
          FOR ls_set_value IN lt_set_values
          ( sign   = 'I'
            option = 'EQ'
            low    = ls_set_value-from )
        ).
        IF ls_header-bsart IN lr_bsart AND ( ls_header-inco1 IS INITIAL OR ls_header-inco2_l IS INITIAL ).
          MESSAGE e003(zmm_msgs) WITH ls_header-bsart.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  METHOD if_ex_me_process_po_cust~process_header.
  ENDMETHOD.


  METHOD if_ex_me_process_po_cust~process_item.
    TYPES: ty_range_inco1 TYPE RANGE OF zmm_inco_freight-kschl.

    DATA: lo_item       TYPE REF TO if_purchase_order_item_mm,
          lt_conditions TYPE mmpur_tkomv.

    lo_item = im_item.

    DATA(lo_header) = im_item->get_header( ).
    DATA(ls_header_data) = lo_header->get_data( ).
    DATA(lv_inco1) = ls_header_data-inco1.

    CALL METHOD im_item->get_conditions
      IMPORTING
        ex_conditions = lt_conditions.

    SELECT inco1, kschl, ifallowed
      FROM zmm_inco_freight
      WHERE inco1 EQ @ls_header_data-inco1
      INTO TABLE @DATA(lt_inco_freight).
    IF sy-subrc = 0.
      DATA(lr_kschl) = VALUE ty_range_inco1(
                                   FOR ls_inco_freight IN lt_inco_freight
                                   ( sign = 'I' option = 'EQ' low = ls_inco_freight-kschl )
                                   ).

      IF line_exists( lt_inco_freight[ ifallowed = 'X' ] ).
        DATA(lv_check_any) = abap_true.
      ENDIF.
      IF lv_check_any IS NOT INITIAL.
*        DATA(ls_condition) = lt_conditions[ kschl IN lr_kschl AND kbetr IS NOT INITIAL ].
        LOOP AT lt_conditions INTO DATA(ls_condition) WHERE kschl IN lr_kschl AND kbetr IS NOT INITIAL.
          EXIT.
        ENDLOOP.
        IF sy-subrc <> 0 .
          MESSAGE e004(zmm_msgs) with ls_header_data-inco1.
        ENDIF.
      ELSE.
        LOOP AT lt_conditions INTO ls_condition WHERE kschl IN lr_kschl AND kbetr IS NOT INITIAL.
          EXIT.
        ENDLOOP.
        IF sy-subrc = 0 .
          MESSAGE e005(zmm_msgs) with ls_header_data-inco1.
        ENDIF.
      ENDIF.

    ENDIF.
  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
