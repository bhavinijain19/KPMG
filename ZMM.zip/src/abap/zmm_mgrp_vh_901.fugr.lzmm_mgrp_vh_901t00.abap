*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_MGRP_VH.....................................*
DATA:  BEGIN OF STATUS_ZMM_MGRP_VH                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_MGRP_VH                   .
CONTROLS: TCTRL_ZMM_MGRP_VH
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_MGRP_VH                   .
TABLES: ZMM_MGRP_VH                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
