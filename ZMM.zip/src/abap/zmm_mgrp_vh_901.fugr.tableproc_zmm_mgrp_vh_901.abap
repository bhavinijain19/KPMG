*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_MGRP_VH_901
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_MGRP_VH_901     .

  PERFORM TABLEPROC.

ENDFUNCTION.
