*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_VENDOR_SERV
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_VENDOR_SERV     .

  PERFORM TABLEPROC.

ENDFUNCTION.
