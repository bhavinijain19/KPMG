class ZCL_WORKFLOW_CONDITION_DEF_SE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_SWF_FLEX_IFS_CONDITION_DEF .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKFLOW_CONDITION_DEF_SE IMPLEMENTATION.


  METHOD if_swf_flex_ifs_condition_def~get_conditions.

    ct_condition = VALUE #(
              ( id = 1 subject = 'Plant'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
              ( id = 2 subject = 'Account Assign Cat'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
              ( id = 3 subject = 'Purchasing Group'         type = if_swf_flex_ifs_condition_def=>cs_condtype-start_step )
                 ).

    ct_parameter = VALUE #(

              ( id = 1 name = 'Plant'         xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true
               service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'Plant' )
              ( id = 2 name = 'Account Assign Cat'         xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true

                  service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'AccAssgnmtCat'
              )
                ( id = 3 name = 'Purchasing Group'    xsd_type = if_swf_flex_ifs_condition_def=>cs_xstype-string mandatory = abap_true
                          service_path = '/sap/opu/odata/sap/S_MMPURWORKFLOWVH_CDS' entity = 'S_MMPURWorkflowVH' property = 'PurchasingGroup'   )

                 )
                .


  ENDMETHOD.
ENDCLASS.
