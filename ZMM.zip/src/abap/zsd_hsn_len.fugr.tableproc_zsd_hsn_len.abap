*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSD_HSN_LEN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSD_HSN_LEN         .

  PERFORM TABLEPROC.

ENDFUNCTION.
