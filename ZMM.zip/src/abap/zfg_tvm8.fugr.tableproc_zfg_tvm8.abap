*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM8
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM8            .

  PERFORM TABLEPROC.

ENDFUNCTION.
