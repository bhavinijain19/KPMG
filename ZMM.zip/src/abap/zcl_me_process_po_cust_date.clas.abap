class ZCL_ME_PROCESS_PO_CUST_DATE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ME_PROCESS_PO_CUST_DATE IMPLEMENTATION.


  METHOD if_ex_me_process_po_cust~check.
    DATA: lo_header     TYPE REF TO if_purchase_order_mm.
    lo_header = im_header.
    DATA(ls_header) = lo_header->get_data( ).
    DATA ls_tvarv TYPE tvarvc.
    IF sy-tcode = 'ME21N'.
      IF ls_header-bedat NE sy-datum.
        MESSAGE e010(zmm_msgs) .
      ENDIF.
    ENDIF.
    SELECT SINGLE *
      FROM tvarvc
      INTO ls_tvarv
      WHERE name = 'Z_UNSEZ' AND low = ls_header-bsart .
    IF ls_tvarv IS  NOT INITIAL.
      IF ls_header-unsez IS INITIAL.
        MESSAGE e011(zmm_msgs).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method IF_EX_ME_PROCESS_PO_CUST~CLOSE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~OPEN.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~POST.
     DATA: lo_header     TYPE REF TO if_purchase_order_mm.
    lo_header = im_header.
    DATA(ls_header) = lo_header->get_data( ).
    DATA ls_tvarv TYPE tvarvc.
    IF sy-tcode = 'ME21N'.
      IF ls_header-bedat NE sy-datum.
        MESSAGE e010(zmm_msgs) .
      ENDIF.
    ENDIF.
    SELECT SINGLE *
      FROM tvarvc
      INTO ls_tvarv
      WHERE name = 'Z_UNSEZ' AND low = ls_header-bsart .
    IF ls_tvarv IS  NOT INITIAL.
      IF ls_header-unsez IS INITIAL.
        MESSAGE e011(zmm_msgs).
      ENDIF.
    ENDIF.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ACCOUNT.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_HEADER.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_ITEM.
  endmethod.


  method IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE.
  endmethod.
ENDCLASS.
