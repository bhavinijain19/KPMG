class ZMM_MB_MIGO_BADI definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MB_MIGO_BADI .
protected section.
private section.

  data GS_GOHEAD type GOHEAD .
ENDCLASS.



CLASS ZMM_MB_MIGO_BADI IMPLEMENTATION.


  METHOD if_ex_mb_migo_badi~check_header.

    DATA: ls_bapiret TYPE bapiret2.

    " Use the captured class attribute GS_GOHEAD instead of IS_MIGO_631_HEADER
    IF me->gs_gohead-budat > sy-datum.
*      CLEAR ls_bapiret.
*      ls_bapiret-type       = 'E'.
*      ls_bapiret-id         = 'M7'.
*      ls_bapiret-number     = '895'.
*      ls_bapiret-message_v1 = 'Posting date is in the future'.
*
*      APPEND ls_bapiret TO et_bapiret2.

      MESSAGE 'Posting date cannot be in the future.' TYPE 'E'.

    ENDIF.

  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~CHECK_ITEM.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_DELETE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_LOAD.
  endmethod.


  method IF_EX_MB_MIGO_BADI~HOLD_DATA_SAVE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~INIT.
  endmethod.


  method IF_EX_MB_MIGO_BADI~LINE_DELETE.
  endmethod.


  method IF_EX_MB_MIGO_BADI~LINE_MODIFY.
  endmethod.


  method IF_EX_MB_MIGO_BADI~MAA_LINE_ID_ADJUST.
  endmethod.


  method IF_EX_MB_MIGO_BADI~MODE_SET.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PAI_DETAIL.
  endmethod.


  METHOD if_ex_mb_migo_badi~pai_header.
    me->gs_gohead = is_gohead.
  ENDMETHOD.


  method IF_EX_MB_MIGO_BADI~PBO_DETAIL.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PBO_HEADER.
  endmethod.


  method IF_EX_MB_MIGO_BADI~POST_DOCUMENT.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PROPOSE_SERIALNUMBERS.
  endmethod.


  method IF_EX_MB_MIGO_BADI~PUBLISH_MATERIAL_ITEM.
  endmethod.


  method IF_EX_MB_MIGO_BADI~RESET.
  endmethod.


  method IF_EX_MB_MIGO_BADI~STATUS_AND_HEADER.
  endmethod.
ENDCLASS.
