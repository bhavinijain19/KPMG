FUNCTION-POOL ZFI_BUSPSP                 MESSAGE-ID SV.

* INCLUDE LZFI_BUSPSPD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI_BUSPSPT00                          . "view rel. data dcl.
