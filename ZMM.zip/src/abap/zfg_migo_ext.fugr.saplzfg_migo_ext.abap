*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_MIGO_EXTTOP.                  " Global Declarations
  INCLUDE LZFG_MIGO_EXTUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_MIGO_EXTF...                  " Subroutines
* INCLUDE LZFG_MIGO_EXTO...                  " PBO-Modules
* INCLUDE LZFG_MIGO_EXTI...                  " PAI-Modules
* INCLUDE LZFG_MIGO_EXTE...                  " Events
* INCLUDE LZFG_MIGO_EXTP...                  " Local class implement.
* INCLUDE LZFG_MIGO_EXTT99.                  " ABAP Unit tests

INCLUDE lzfg_migo_exto01.

INCLUDE lzfg_migo_exti01.
