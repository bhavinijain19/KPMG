*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_TVM10
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_TVM10           .

  PERFORM TABLEPROC.

ENDFUNCTION.
