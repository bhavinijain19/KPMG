@AbapCatalog.internal.setChange: 'FLDADD_NO_ASS_INFLUENCE'
@AbapCatalog.sqlViewAppendName: 'ZZ1_0DE5DA2DAA2C'

extend view I_SERVICEENTRYSHEET with ZZ1_2RX4VW7XIJE6DHRVLVXJA24OYM
  
{ 
  _ServiceEntrySheetExtension.ZZ1_REFERENCE_MDH as ZZ1_REFERENCE_MDH
}
