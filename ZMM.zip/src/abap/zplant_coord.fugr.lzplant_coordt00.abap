*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZPLANT_COORD....................................*
DATA:  BEGIN OF STATUS_ZPLANT_COORD                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPLANT_COORD                  .
CONTROLS: TCTRL_ZPLANT_COORD
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZPLANT_COORD                  .
TABLES: ZPLANT_COORD                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
