FUNCTION-POOL ZMM_SU_NUMBER              MESSAGE-ID SV.

* INCLUDE LZMM_SU_NUMBERD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMM_SU_NUMBERT00                       . "view rel. data dcl.
