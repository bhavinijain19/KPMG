class ZCL_IM_MATDESCHECK definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MG_MASS_NEWSEG .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MATDESCHECK IMPLEMENTATION.


  METHOD if_ex_mg_mass_newseg~add_new_segment.
*    BREAK-POINT.
    DATA: ls_smakt LIKE LINE OF smakt.
    DATA: s_maktx  TYPE maktx.


  TYPES : BEGIN OF ty_mtart,
            low TYPE tvarvc-low,
          END OF ty_mtart.
  DATA: it_mtart TYPE STANDARD TABLE OF ty_mtart,
        wa_mtart TYPE ty_mtart.

    CONSTANTS: c_mtart_name  TYPE rvari_vnam VALUE 'Z_MATDUPL_CHECK'.

    TYPES: BEGIN OF ty_mara,
             matnr TYPE mara-matnr,
             mtart TYPE mara-mtart,
           END OF ty_mara.
 data: it_mara type STANDARD TABLE OF ty_mara,
       wa_mara type ty_mara.

    SELECT matnr mtart FROM mara INTO TABLE it_mara
      FOR ALL ENTRIES IN smakt
      WHERE matnr = smakt-matnr.

      SELECT low
      INTO TABLE it_mtart
       FROM tvarvc
       WHERE name = c_mtart_name.

    LOOP AT smakt INTO ls_smakt.

      READ TABLE it_mara into wa_mara with key matnr = ls_smakt-matnr.
      if sy-subrc = 0.

      READ TABLE it_mtart INTO wa_mtart WITH KEY low = wa_mara-mtart.
      if sy-subrc = 0.

      SELECT SINGLE maktx FROM makt
      INTO s_maktx
      WHERE spras = 'EN' AND
            maktx = ls_smakt-maktx.

      IF s_maktx IS NOT INITIAL.
        MESSAGE e041(zmm) WITH ls_smakt-matnr .
*   RAISE completion_rejected.
      ENDIF.
     endif.
     endif.
     clear: wa_mara,wa_mtart,ls_smakt.
    ENDLOOP.
  ENDMETHOD.


  method IF_EX_MG_MASS_NEWSEG~RETURN_IDOC_TYPE.
  endmethod.
ENDCLASS.
