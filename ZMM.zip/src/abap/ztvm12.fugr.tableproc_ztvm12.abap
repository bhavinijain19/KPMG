*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTVM12
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTVM12              .

  PERFORM TABLEPROC.

ENDFUNCTION.
