@AbapCatalog.sqlViewAppendName: 'ZPURITMENH'
@EndUserText.label: 'I_PurchaseorderItemEnhanced'
extend view I_PurchaseorderItemEnhanced with zcl_PurchaseorderItemEnhanced
{
   test,
   KOSTL,
   SAKTO 
}
