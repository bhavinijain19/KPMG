*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_DOWNPAY_CFG.................................*
DATA:  BEGIN OF STATUS_ZMM_DOWNPAY_CFG               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_DOWNPAY_CFG               .
CONTROLS: TCTRL_ZMM_DOWNPAY_CFG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_DOWNPAY_CFG               .
TABLES: ZMM_DOWNPAY_CFG                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
