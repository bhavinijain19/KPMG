*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_GATE_SNRO
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_GATE_SNRO       .

  PERFORM TABLEPROC.

ENDFUNCTION.
