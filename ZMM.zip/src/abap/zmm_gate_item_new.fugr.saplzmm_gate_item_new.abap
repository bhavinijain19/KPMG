*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMM_GATE_ITEM_NEWTOP.             " Global Declarations
  INCLUDE LZMM_GATE_ITEM_NEWUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMM_GATE_ITEM_NEWF...             " Subroutines
* INCLUDE LZMM_GATE_ITEM_NEWO...             " PBO-Modules
* INCLUDE LZMM_GATE_ITEM_NEWI...             " PAI-Modules
* INCLUDE LZMM_GATE_ITEM_NEWE...             " Events
* INCLUDE LZMM_GATE_ITEM_NEWP...             " Local class implement.
* INCLUDE LZMM_GATE_ITEM_NEWT99.             " ABAP Unit tests
