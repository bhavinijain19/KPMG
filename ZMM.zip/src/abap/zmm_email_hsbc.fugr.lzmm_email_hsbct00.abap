*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_EMAIL_HSBC..................................*
DATA:  BEGIN OF STATUS_ZMM_EMAIL_HSBC                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_EMAIL_HSBC                .
CONTROLS: TCTRL_ZMM_EMAIL_HSBC
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_EMAIL_HSBC                .
TABLES: ZMM_EMAIL_HSBC                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
