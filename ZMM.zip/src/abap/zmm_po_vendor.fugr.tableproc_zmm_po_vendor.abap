*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMM_PO_VENDOR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMM_PO_VENDOR       .

  PERFORM TABLEPROC.

ENDFUNCTION.
