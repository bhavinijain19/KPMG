*&---------------------------------------------------------------------*
*& Report  ZMM_LOAD_POST
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zmm_load_post.

TABLES: ltak.
TYPES: BEGIN OF ty_pick,
         werks TYPE werks_d,
         lgort TYPE lgort_d,
         lgnum TYPE lgnum,
         lgtyp TYPE lgtyp,
         lgber TYPE lgber,
       END OF ty_pick,

       BEGIN OF ty_lein,
         lenum TYPE  lenum,
         lgnum TYPE  lgnum,
         letyp TYPE lvs_letyp,
         lgtyp TYPE lgtyp,
         lgpla TYPE lgpla,
       END OF ty_lein.

DATA lw_qty TYPE zmm_load_sloc.
DATA: it_load_sloc      TYPE STANDARD TABLE OF zmm_load_sloc,
      wa_load_sloc      TYPE zmm_load_sloc,
      it_load_slocx     TYPE STANDARD TABLE OF zmm_load_sloc,
      it_load_slocx_tmp TYPE STANDARD TABLE OF zmm_load_sloc,
      wa_load_slocx     TYPE zmm_load_sloc,
      it_picklist       TYPE STANDARD TABLE OF ty_pick,
      wa_picklist       TYPE ty_pick,
      it_lein           TYPE STANDARD TABLE OF ty_lein,
      wa_lein           TYPE ty_lein.

DATA: it_delit     TYPE l03b_delit_t,
      wa_delit     LIKE LINE OF it_delit,
      it_ltak      TYPE STANDARD TABLE OF ltak_vb,
      it_wmgrp_msg TYPE STANDARD TABLE OF wmgrp_msg,
      it_ltap      TYPE STANDARD TABLE OF  ltap_vb , "ltap_conf,
      it_ltap_temp TYPE STANDARD TABLE OF  ltap_vb , "ltap_conf,
      wa_ltap_temp TYPE ltap_vb,
      lw_ltap1_tmp TYPE  ltap_vb,
      lv_flag      TYPE c,
      wa_ltap      LIKE LINE OF it_ltap.

DATA: it_bdcdata TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
      wa_bdcdata TYPE bdcdata.                            "bdc internal table declaration.
DATA :gv_text TYPE char100,
      v_tanum TYPE char10.
gv_text = 'TO created and confirmed with no'.
FIELD-SYMBOLS: <lfs_load_sloc>  LIKE LINE OF it_load_sloc,
               <lfs_load_slocx> LIKE LINE OF it_load_slocx.

DATA: lv_tanum TYPE ltak-tanum,
      lv_teilk TYPE t340d-teilv,
      flag     TYPE c,
      lv_tabix TYPE i,
      row      TYPE i,
      lv_vbeln TYPE vbeln,
      lv_msg   TYPE string.
CONSTANTS load_status TYPE c VALUE 'W'.
DATA :it_ltap_conf  TYPE STANDARD TABLE OF ltap_conf,
      lw_ltap1_tmp1 TYPE ltap_conf.
DATA: su_qty     TYPE menge_d,
      lv_budat   TYPE budat,
      lv_load_no TYPE zload_no,
      p_load     TYPE zload_no.

DATA total_del_qty TYPE lips-lfimg.
SELECTION-SCREEN BEGIN OF BLOCK a.

SELECT-OPTIONS : s_date FOR lv_budat,
                 s_load FOR lv_load_no.
PARAMETERS p_status TYPE c NO-DISPLAY.

SELECTION-SCREEN END OF BLOCK a.


START-OF-SELECTION.


* Quick Fix Append ORDER BY PRIMARY KEY to the SELECT statement
* Transport DEVK900950 ABAP : ECC to S4 HANA Migration V1.3
* Replaced Code:
*  SELECT * FROM zmm_load_sloc INTO TABLE it_load_sloc
*  WHERE load_no IN s_load
*    AND to_create_date IN s_date
*  AND   load_status IN ('I', 'W')" load_status
*  AND to_no       = ' '
*  AND del_ind     = ' '.

SELECT * FROM zmm_load_sloc INTO TABLE it_load_sloc
  WHERE load_no IN s_load
    AND to_create_date IN s_date
  AND   load_status IN ('I', 'W')" load_status
  AND to_no       = ' '
  AND del_ind     = ' ' ORDER BY PRIMARY KEY .

* End of Quick Fix


  IF sy-subrc = 0.
    CLEAR lw_qty.
    READ TABLE it_load_sloc INTO lw_qty INDEX 1. "#EC CI_NOORDER
    p_load = lw_qty-load_no.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = p_load
      IMPORTING
        output = p_load.

    IF sy-subrc = 0 AND it_load_sloc IS NOT INITIAL.
      SELECT werks lgort lgnum lgtyp lgber FROM zwm_picklist
                                           INTO TABLE it_picklist
                                           FOR ALL ENTRIES IN it_load_sloc
                                           WHERE werks = it_load_sloc-plant.

      IF it_load_sloc IS NOT INITIAL.
        SELECT lenum lgnum letyp lgtyp lgpla FROM lein
                                       INTO TABLE it_lein
                                       FOR ALL ENTRIES IN it_load_sloc
                                       WHERE lenum = it_load_sloc-su_no.

        it_load_slocx = it_load_sloc.
        DELETE ADJACENT DUPLICATES FROM it_load_sloc COMPARING load_no.
      ENDIF.


      SORT: it_load_sloc BY load_no,
            it_load_slocx BY load_no.

*    LOOP AT it_load_sloc ASSIGNING <lfs_load_sloc>.

*      READ TABLE it_load_slocx TRANSPORTING NO FIELDS
*       WITH KEY load_no = pload.
*      lv_tabix = sy-tabix.

      CLEAR: lv_vbeln.
      LOOP AT it_load_slocx  ASSIGNING <lfs_load_slocx>.
*        IF <lfs_load_slocx>-load_no <> <lfs_load_sloc>-load_no.
*          EXIT.
*        ENDIF.

        IF sy-tabix = 1.
          lv_vbeln = <lfs_load_slocx>-obd_no.
        ENDIF.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = <lfs_load_slocx>-su_no
          IMPORTING
            output = <lfs_load_slocx>-su_no.

        su_qty = su_qty + <lfs_load_slocx>-su_qty.

        READ TABLE it_picklist INTO wa_picklist
        WITH KEY werks = <lfs_load_slocx>-plant.


        READ TABLE it_lein INTO wa_lein
        WITH KEY lenum = <lfs_load_slocx>-su_no.
        IF sy-subrc = 0.
          wa_ltap-letyp  =  wa_lein-letyp.
          wa_ltap-lgnum  =  wa_lein-lgnum.
          wa_ltap-vlber  =  wa_picklist-lgber.
          wa_ltap-posnr = <lfs_load_slocx>-obd_lineitem.
        ENDIF.
        wa_delit-posnr = <lfs_load_slocx>-obd_lineitem.
        wa_delit-anfme = <lfs_load_slocx>-su_qty.
        wa_delit-altme = <lfs_load_slocx>-uom.
        wa_delit-charg = <lfs_load_slocx>-batch_no.

        wa_delit-letyp  =  wa_lein-letyp.
        wa_delit-vltyp =  wa_lein-lgtyp.
        wa_delit-vlpla = <lfs_load_slocx>-bin_loc.
        wa_delit-vlber  = wa_picklist-lgber.
*      wa_delit-vlenr = <lfs_load_slocx>-su_no.
        UNPACK <lfs_load_slocx>-su_no TO wa_delit-vlenr.
        APPEND wa_delit TO it_delit.
        row = row + 1.
        wa_ltap-tapos = row.
        wa_ltap-altme = <lfs_load_slocx>-uom.
        wa_ltap-charg = <lfs_load_slocx>-batch_no.

        wa_ltap-vltyp =  wa_lein-lgtyp.
        wa_ltap-letyp = wa_lein-letyp.
        wa_ltap-vlpla = <lfs_load_slocx>-bin_loc.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            input  = <lfs_load_slocx>-su_no
          IMPORTING
            output = <lfs_load_slocx>-su_no.
        wa_ltap-matnr  = <lfs_load_slocx>-matnr.
        wa_ltap-sonum = <lfs_load_slocx>-su_no.
        wa_ltap-nista = <lfs_load_slocx>-su_qty.
        APPEND wa_ltap TO it_ltap.

      ENDLOOP.

      CLEAR it_load_slocx_tmp.
      it_load_slocx_tmp = it_load_slocx.
      SORT it_load_slocx_tmp BY matnr batch_no.
      IF p_status = ' '.
        DELETE ADJACENT DUPLICATES FROM it_load_slocx_tmp COMPARING matnr batch_no.
      ENDIF.
      LOOP AT it_load_slocx_tmp ASSIGNING FIELD-SYMBOL(<fs_ltap_temp>).

        IF <fs_ltap_temp> IS ASSIGNED.
          total_del_qty = total_del_qty + <fs_ltap_temp>-quantity.
        ENDIF.

      ENDLOOP.
      CLEAR: lv_flag.
      IF su_qty NE total_del_qty."lw_qty-quantity.
        lv_flag  = 'X'.
        UPDATE zmm_load_sloc SET "to_no          = lv_tanum
        err_msg   = 'Delivery quantity not equal to box qty.'
        load_status    = 'I'
        WHERE load_no = p_load.
        COMMIT WORK AND WAIT.
        MESSAGE 'Delivery quantity not equal to box qty.' TYPE 'E'.
        RETURN.
      ENDIF.
      IF it_ltap IS NOT INITIAL AND lv_flag IS INITIAL.
        CALL FUNCTION 'L_TO_CREATE_DN'
          EXPORTING
            i_lgnum                    = wa_picklist-lgnum
            i_vbeln                    = lv_vbeln "<lfs_load_slocx>-obd_no
            i_commit_work              = 'X'
            i_bname                    = sy-uname
            i_solex                    = total_del_qty
            it_delit                   = it_delit
          IMPORTING
            e_tanum                    = lv_tanum
            e_teilk                    = lv_teilk
          TABLES
            t_ltak                     = it_ltak
            t_ltap_vb                  = it_ltap
            t_wmgrp_msg                = it_wmgrp_msg
          EXCEPTIONS
            foreign_lock               = 1
            dn_completed               = 2
            partial_delivery_forbidden = 3
            xfeld_wrong                = 4
            ldest_wrong                = 5
            drukz_wrong                = 6
            dn_wrong                   = 7
            squit_forbidden            = 8
            no_to_created              = 9
            teilk_wrong                = 10
            update_without_commit      = 11
            no_authority               = 12
            no_picking_allowed         = 13
            dn_hu_not_choosable        = 14
            input_error                = 15
            OTHERS                     = 16.
        IF sy-subrc = 0.
          flag = 'X'.
          CLEAR: wa_ltap.
        ELSE.
          CALL FUNCTION 'FORMAT_MESSAGE'
            EXPORTING
              id        = sy-msgid
              lang      = '-D'
              no        = sy-msgno
              v1        = sy-msgv1
              v2        = sy-msgv2
              v3        = sy-msgv3
              v4        = sy-msgv4
            IMPORTING
              msg       = lv_msg
            EXCEPTIONS
              not_found = 1
              OTHERS    = 2.
          CLEAR flag.

          UPDATE zmm_load_sloc SET
            err_msg        = lv_msg
            to_create_date = sy-datum
            load_status    = 'I'
            WHERE load_no = p_load.
          CLEAR: lv_msg.
        ENDIF.

        DATA:  lt_messtab TYPE STANDARD TABLE OF bdcmsgcoll,
               lw_messtab TYPE bdcmsgcoll.

***********************************************************
*BDC for confirming created TO.
***********************************************************
        IF wa_picklist-lgnum IS NOT INITIAL AND flag = 'X' AND lv_tanum IS NOT INITIAL.
          PERFORM bdc_dynpro      USING 'SAPML03T' '0111'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                'LTAK-TANUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                '/00'.
          PERFORM bdc_field       USING 'LTAK-TANUM'
                                          lv_tanum.
          PERFORM bdc_field       USING 'LTAK-LGNUM'
                                         wa_picklist-lgnum.

          PERFORM bdc_dynpro      USING 'SAPML03T' '0113'.
          PERFORM bdc_field       USING 'BDC_CURSOR'
                'LTAK-LGNUM'.
          PERFORM bdc_field       USING 'BDC_OKCODE'
                '=BU'.
          CALL TRANSACTION 'LT12' USING it_bdcdata
                 MESSAGES INTO lt_messtab MODE 'N' UPDATE 'S'.

          CLEAR it_bdcdata.
          CLEAR wa_bdcdata.
*        CALL FUNCTION 'L_TO_CONFIRM'
*          EXPORTING
*            i_lgnum     = wa_picklist-lgnum
*            i_tanum     = lv_tanum
*            i_qname     = sy-uname
**           i_commit_work = 'X'
*          TABLES
*            t_ltap_conf = it_ltap_conf.

          CLEAR:lw_messtab,lv_msg.
          READ TABLE lt_messtab INTO lw_messtab WITH KEY msgtyp = 'S' .
          IF sy-subrc <> 0.
            CALL FUNCTION 'FORMAT_MESSAGE'
              EXPORTING
                id        = lw_messtab-msgid
                lang      = '-D'
                no        = lw_messtab-msgnr
                v1        = lw_messtab-msgv1
                v2        = lw_messtab-msgv2
                v3        = lw_messtab-msgv3
                v4        = lw_messtab-msgv4
              IMPORTING
                msg       = lv_msg
              EXCEPTIONS
                not_found = 1
                OTHERS    = 2.

            UPDATE zmm_load_sloc SET "to_no          = lv_tanum
             err_msg        = lv_msg
             to_create_date = sy-datum
             load_status    = 'I'
             WHERE load_no = p_load.
            COMMIT WORK AND WAIT.

*          MESSAGE lv_msg TYPE 'E'.
          ELSE.
            UPDATE zmm_load_sloc SET to_no = lv_tanum
            err_msg        = ' '
            to_create_date = sy-datum
            load_status    = 'C'
            WHERE load_no = p_load.
            COMMIT WORK AND WAIT.
            FREE:it_delit[],it_bdcdata.

            CONCATENATE gv_text lv_tanum INTO gv_text SEPARATED BY space.
            MESSAGE gv_text TYPE 'S'.
          ENDIF.
          CLEAR lv_tanum.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

FORM bdc_dynpro USING program dynpro.
  CLEAR wa_bdcdata.
  wa_bdcdata-program  = program.
  wa_bdcdata-dynpro   = dynpro.
  wa_bdcdata-dynbegin = abap_true.
  APPEND wa_bdcdata TO it_bdcdata.
ENDFORM.
***********************************************************
*BDC FORM bdc_field
***********************************************************
FORM bdc_field USING fnam fval.

  CLEAR wa_bdcdata.
  wa_bdcdata-fnam = fnam.
  wa_bdcdata-fval = fval.
  APPEND wa_bdcdata TO it_bdcdata.

ENDFORM.
