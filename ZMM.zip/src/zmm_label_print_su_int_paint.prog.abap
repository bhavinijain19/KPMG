*&---------------------------------------------------------------------*
*&                     New Development
*&  Technical Consultant    :    Khushbu Garg
*&  Functional Consultant   :    Sachin
*&  Requirement             :    For Label Printing in WM Module
*&  Revieved By             :    Sneha
*&  Request                 :    DEVK912058
*&---------------------------------------------------------------------*
*& Report  ZMM_LABEL_PRINT
*&---------------------------------------------------------------------*
REPORT zmm_label_print_paint98.
*&---------------------------------------------------------------------*
*&                INCLUDES
*&---------------------------------------------------------------------*
TABLES : zmm_su_number,makt,mara,lqua.
INCLUDE zmm_label_print_paint_int_top.
*INCLUDE zmm_label_print_paint_top.
*INCLUDE zmm_label_print_paint_top.
*INCLUDE zmm_label_print_top.
INCLUDE zmm_label_print_paint_int_scr.
*INCLUDE zmm_label_print_paint_scr.
*INCLUDE zmm_label_print_paint_scr.
*INCLUDE zmm_label_print_scr.
*&---------------------------------------------------------------------*
*&                start-of-selection
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CLEAR : it_zmm_su_number,it_lqua,
            it_makt,
            it_mch1.
  PERFORM authorisation_check.
*  IF s_zsu_no IS NOT INITIAL.
*    SELECT mandt
*    zsu_no
*    aufnr
*    matnr
*    werks
*    lgort
*    charg
*    zbatch_stk
*    meins
*    lhmg1
*    lety1
*    lhme1
*    lgpla
*       FROM zmm_su_number
*      INTO TABLE it_zmm_su_number
*    WHERE zsu_no IN s_zsu_no AND werks = p_werks.
*    IF sy-subrc EQ 0.
*      SORT it_zmm_su_number BY zsu_no.
*    ENDIF.
*  ENDIF.


  IF s_lenum IS NOT INITIAL.
    SELECT mandt
        lenum
        matnr
        werks
        charg
        lgpla
        meins
        verme
        lgort
           FROM lqua
          INTO TABLE it_lqua
        WHERE lenum IN s_lenum AND werks = p_werks.
    IF sy-subrc EQ 0.
      SORT it_lqua BY lenum.
    ENDIF.
  ENDIF.


*Begin of Changes*******************************************************Added by Raj Kumar 4806

  SELECT sign
         opti
         low
         high
INTO TABLE it_tvarvc
    FROM tvarvc
   WHERE name = c_var_name.

  SELECT sign
         opti
         low
         high
INTO TABLE it_tvarvc1
    FROM tvarvc
   WHERE name = c_var_name1.


  IF it_tvarvc IS NOT INITIAL.
    LOOP AT it_tvarvc INTO wa_tvarvc.
      gc_rv-sign   = wa_tvarvc-sign.
      gc_rv-option = wa_tvarvc-option.
      gc_rv-low    = wa_tvarvc-low.
      gc_rv-high   = wa_tvarvc-high.
      APPEND gc_rv.
    ENDLOOP.
  ENDIF.

  IF it_tvarvc1 IS NOT INITIAL.
    LOOP AT it_tvarvc1 INTO wa_tvarvc1.
      gc_rv1-sign   = wa_tvarvc1-sign.
      gc_rv1-option = wa_tvarvc1-option.
      gc_rv1-low    = wa_tvarvc1-low.
      gc_rv1-high   = wa_tvarvc1-high.
      APPEND gc_rv1.
    ENDLOOP.
  ENDIF.

***************************************************************************Added by Raj Kumar 4806
  SELECT bwkey bukrs FROM t001k INTO  TABLE it_t001k WHERE bwkey = p_werks.

*  SELECT bukrs adrnr FROM t001 INTO TABLE it_t001 FOR ALL ENTRIES IN it_t001k WHERE bukrs = it_t001k-bukrs.

  DATA : v_adrnr1 TYPE t001w-adrnr.

  LOOP AT it_t001k INTO wa_t001k.
    SELECT SINGLE  adrnr
         INTO (v_adrnr1)
          FROM t001
          WHERE bukrs = wa_t001k-bukrs.
  ENDLOOP.

*End of changes***************************************************************************Added by Raj Kumar 4806

*******  Added by Carina Jose on 05/01/2022
  CLEAR : v_uom,wa_header,wa_address.
  SELECT SINGLE low
  INTO v_uom
  FROM tvarvc
  WHERE name = c_uom .

  SELECT SINGLE adrnr
    INTO @DATA(v_adrnr)
    FROM t001w
    WHERE werks = @p_werks.

************************PLANT ADDRESS************** COMMENT BY RAJ
*    SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
*    city1 city2 post_code1 region country
*      INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
*                    wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
*                    wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country)
*      FROM adrc
*      WHERE addrnumber = v_adrnr.

**********************COMPANY ADDRESS*************COMMENT BY RAJ
  SELECT SINGLE smtp_addr FROM adr6 INTO ( wa_adr6-smtp_addr )  WHERE addrnumber = v_adrnr1.

  SELECT SINGLE name1 street house_num1 house_num2 str_suppl1 str_suppl2 str_suppl3
  city1 city2 post_code1 region country tel_number fax_number
    INTO (wa_header-plant_name1,wa_header-plant_street,wa_header-plant_house_num1,wa_header-plant_house_num2,
                  wa_header-plant_str_suppl1,wa_header-plant_str_suppl2,wa_header-plant_str_suppl3,wa_header-plant_city1,wa_header-plant_city2,
                  wa_header-plant_post_code1,wa_header-plant_region,wa_header-plant_country,wa_header-plant_tel_number,wa_header-plant_fax_number)
    FROM adrc
    WHERE addrnumber = v_adrnr1.


  SELECT SINGLE bezei FROM t005u INTO v_region WHERE bland = wa_header-plant_region AND land1 = wa_header-plant_country AND spras = sy-langu.
  SELECT SINGLE landx50 FROM t005t INTO v_country WHERE land1 = wa_header-plant_country AND spras = sy-langu.


  v_plant_name = wa_header-plant_name1.
  IF NOT wa_header-plant_house_num1 IS INITIAL.
    IF NOT wa_address-street_address1 IS INITIAL.
      CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num1 INTO wa_address-street_address1 SEPARATED BY space.
    ELSE.
      wa_address-street_address1 = wa_header-plant_house_num1.
    ENDIF.
  ENDIF.

  IF NOT wa_header-plant_house_num2 IS INITIAL.
    IF NOT wa_address-street_address1 IS INITIAL.
      CONCATENATE wa_address-street_address1 ',' wa_header-plant_house_num2 INTO wa_address-street_address1 SEPARATED BY space.
    ELSE.
      wa_address-street_address1 = wa_header-plant_house_num2.
    ENDIF.
  ENDIF.

  IF NOT wa_header-plant_street IS INITIAL.
    IF NOT wa_address-street_address1 IS INITIAL.
      CONCATENATE wa_address-street_address1 ',' wa_header-plant_street INTO wa_address-street_address1 SEPARATED BY space.
    ELSE.
      wa_address-street_address1 = wa_header-plant_street.
    ENDIF.
  ENDIF.


  IF NOT wa_header-plant_str_suppl1 IS INITIAL.
    wa_address-street_address2 = wa_header-plant_str_suppl1.
  ENDIF.
**************************************************************PHONE NUMBER  "ADDED BY RAJ KUMAR 4806
  IF NOT wa_header-plant_tel_number IS INITIAL.
    wa_address-street_address3 = wa_header-plant_tel_number.     " wa_address-street_address3 = PHONE NUMBER IS STORED IN THS FIELD
  ENDIF.
**************************************************************PHONE NUMBER
************************************************************MAIL ADDRESS
  IF NOT wa_adr6-smtp_addr IS INITIAL.
    wa_address-street_address4 = wa_adr6-smtp_addr.              " wa_address-street_address4 = MAIL ADDRESS IS STORED IN THS FIELD
  ENDIF.
************************************************************MAIL ADDRESS
  IF NOT wa_header-plant_city1 IS INITIAL.
    wa_address-city_address1 = wa_header-plant_city1.
  ENDIF.

  IF NOT wa_header-plant_city2 IS INITIAL.
    IF NOT wa_address-city_address1 IS INITIAL.
      CONCATENATE wa_address-city_address1 ','  wa_header-plant_city1 INTO wa_address-city_address1 SEPARATED BY space.
*        wa_address-city_address1 = wa_header-plant_city2.
      wa_address-city_address1 = wa_header-plant_city1.
    ENDIF.
  ENDIF.

  IF NOT wa_header-plant_post_code1 IS INITIAL.
    IF NOT wa_address-city_address1 IS INITIAL.
      CONCATENATE wa_address-city_address1 '-' wa_header-plant_post_code1 INTO wa_address-city_address1 SEPARATED BY space.
    ELSE.
      wa_address-city_address1 = wa_header-plant_post_code1.
    ENDIF.
  ENDIF.
  IF NOT v_region IS INITIAL.
    wa_address-state_address1 = v_region.
  ENDIF.

  IF NOT v_country IS INITIAL.
    IF NOT wa_address-state_address1 IS INITIAL.
      CONCATENATE wa_address-state_address1 ',' v_country INTO wa_address-state_address1 SEPARATED BY space.
    ELSE.
      wa_address-state_address1 = v_country.
    ENDIF.
  ENDIF.
****** End of changes by Carina Jose on 05/01/2022
  SELECT matnr
       charg
       hsdat
       FROM mch1
       INTO TABLE it_mch1
       FOR ALL ENTRIES IN it_lqua
       WHERE matnr EQ it_lqua-matnr AND
  charg EQ it_lqua-charg.

  IF sy-subrc EQ 0.
    SORT it_mch1 BY matnr charg.
  ENDIF.

  SELECT matnr
         maktx
  FROM   makt
  INTO TABLE it_makt
  FOR ALL ENTRIES IN it_lqua
  WHERE matnr
  EQ it_lqua-matnr
  AND spras = 'EN'.

  IF sy-subrc EQ 0.
    SORT it_makt BY matnr.
  ENDIF.


*  Begin of changes by B Raj Kumar 4806.
  IF it_lqua IS NOT INITIAL.
    SELECT matnr
           groes
    FROM   mara
    INTO TABLE it_mara
    FOR ALL ENTRIES IN it_lqua
    WHERE matnr EQ it_lqua-matnr.
  ENDIF.
  IF it_lqua IS NOT INITIAL.
    SELECT kschl
           vkorg
           matnr
           datbi
           datab
           knumh
    FROM   a999
    INTO TABLE it_a999
    FOR ALL ENTRIES IN it_lqua
    WHERE kschl = 'PR00'
    AND   vkorg IN gc_rv1
    AND   matnr EQ it_lqua-matnr
    AND   datab LE sy-datum
    AND   datbi GE sy-datum.
  ENDIF.

  IF it_a999 IS NOT INITIAL.
    SELECT
            knumh
            kbetr
            kmein
    FROM    konp
    INTO TABLE it_konp
    FOR ALL ENTRIES IN it_a999
    WHERE knumh = it_a999-knumh.
  ENDIF.

  IF it_lqua IS NOT INITIAL.
    SELECT  kschl
            vkorg
            pltyp
            matnr
            datbi
            datab
            knumh
      FROM a906
      INTO TABLE it_a906
      FOR ALL ENTRIES IN it_lqua
      WHERE kschl = 'PR00'
      AND   vkorg IN gc_rv1
      AND   pltyp = '07'
      AND   matnr EQ it_lqua-matnr
      AND   datab LE sy-datum
      AND   datbi GE sy-datum.
  ENDIF.



  IF it_a906 IS NOT INITIAL.

    SELECT  knumh
            kbetr
            kmein
    FROM    konp
    INTO TABLE it_konp1
    FOR ALL ENTRIES IN it_a906
    WHERE knumh = it_a906-knumh.
  ENDIF .

  IF it_lqua IS NOT INITIAL.
    SELECT   matnr
             meinh
             umrez
             umren
     FROM    marm
  INTO TABLE it_marm
  FOR ALL ENTRIES IN it_lqua
  WHERE matnr EQ it_lqua-matnr
    AND meinh IN gc_rv.
  ENDIF .

  IF it_lqua IS NOT INITIAL.
    SELECT matnr mvgr5 FROM mvke INTO TABLE it_mvke FOR ALL ENTRIES IN it_lqua WHERE  matnr EQ it_lqua-matnr
                                                                                              AND vkorg = gc_rv1-low .

    SELECT matnr lhmg1 FROM mlgn INTO TABLE it_mlgn FOR ALL ENTRIES IN it_lqua WHERE matnr = it_lqua-matnr.

  ENDIF.

*   DATA : V_CONVE TYPE MARM-UMREN.
*   LOOP AT IT_MARM INTO WA_MARM.
*   ENDLOOP.
*   IF WA_MARM-MEINH IS NOT INITIAL.
*   V_CONVE = WA_MARM-UMREN / WA_MARM-UMREZ.
*   ENDIF .




  CLEAR it_final.
  CLEAR wa_final.


  LOOP AT it_lqua INTO wa_lqua.
    wa_final-zsu_no =  wa_lqua-lenum.
*    wa_final-zbatch_stk = wa_lqua-lhmg1.
*    wa_final-uom = wa_lqua-lhme1.
    wa_final-matnr = wa_lqua-matnr .
    wa_final-charg = wa_lqua-charg.
    wa_final-lgpla = wa_lqua-lgpla.

***********************************************************************
******    Added by Carina Jose on 06/01/2022
*    IF wa_final-uom = 'EA'.
*      wa_final-uom = v_uom.
*    ENDIF.
******    End of changes by Carina Jose on 06/01/2022
********************************************************************

    CALL FUNCTION 'VB_BATCH_GET_DETAIL'
      EXPORTING
        matnr              = wa_lqua-matnr
        charg              = wa_lqua-charg
        werks              = wa_lqua-werks
        get_classification = 'X'
*       EXISTENCE_CHECK    =
*       READ_FROM_BUFFER   =
*       NO_CLASS_INIT      = ' '
*       LOCK_BATCH         = ' '
      IMPORTING
        ymcha              = gv_ymcha
        classname          = gv_classname
      TABLES
        char_of_batch      = it_clbatch
      EXCEPTIONS
        no_material        = 1
        no_batch           = 2
        no_plant           = 3
        material_not_found = 4
        plant_not_found    = 5
        no_authority       = 6
        batch_not_exist    = 7
        lock_on_batch      = 8
        OTHERS             = 9.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
    CLEAR wa_clbatch.
    IF gv_classname = 'BATCH_EXP'.
      READ TABLE it_clbatch INTO wa_clbatch WITH KEY atnam = 'MFGD_DATE_PRINT'.
      IF sy-subrc EQ 0.
        REPLACE ALL OCCURRENCES OF '.' IN wa_clbatch-atwtb WITH space.
        CONDENSE wa_clbatch-atwtb.
        CONCATENATE wa_clbatch-atwtb+4(4) wa_clbatch-atwtb+2(2) wa_clbatch-atwtb+0(2) INTO wa_final-hsdat.
      ENDIF.
    ENDIF.

    IF wa_clbatch-atwtb IS INITIAL.
      CLEAR wa_mch1.
      READ TABLE it_mch1 INTO wa_mch1 WITH KEY matnr = wa_lqua-matnr
                                               charg = wa_lqua-charg BINARY SEARCH.
      IF sy-subrc EQ 0.
        wa_final-hsdat = wa_mch1-hsdat.
      ENDIF.
    ENDIF.

    CLEAR wa_makt.
    READ TABLE it_makt INTO wa_makt WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-maktx = wa_makt-maktx.
    ENDIF.
*    ADDED BY RAJ  Begin of changes 4806 B Raj Kumar
    CLEAR wa_mara.
    READ TABLE it_mara INTO wa_mara WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-groes = wa_mara-groes.
    ENDIF.
*    ADDED BY RAJ

    CLEAR wa_a999.
    READ TABLE it_a999 INTO wa_a999 WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    CLEAR wa_konp.

    READ TABLE it_konp INTO wa_konp WITH KEY knumh = wa_a999-knumh BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-kbetr = wa_konp-kbetr.
      wa_final-kmein = wa_konp-kmein.
    ENDIF.


    CLEAR wa_a906.
    READ TABLE it_a906 INTO wa_a906 WITH KEY matnr = wa_lqua-matnr BINARY SEARCH. "COST P U
    CLEAR wa_konp1.
    READ TABLE it_konp1 INTO wa_konp1 WITH KEY knumh1 = wa_a906-knumh BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-kbetr1 = wa_konp1-kbetr1.
      wa_final-kmein1 = wa_konp1-kmein1.

    ENDIF.
    CLEAR wa_marm.
    READ TABLE it_marm INTO wa_marm WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      v_conve1 = wa_marm-umren / wa_marm-umrez.
      wa_final-v_conve2 = v_conve1.                     " NET QUANTiTY
      wa_final-total = v_conve1 *  wa_final-zbatch_stk .
      wa_final-meinh = wa_marm-meinh.
*      wa_final-umren1 = wa_marm-umren. "comment 10.04.2023
      wa_final-umren1 = v_conve1.  "add 10.04.2023
    ENDIF.

    IF rad1 = 'X'.
      CLEAR: wa_mlgn.
      READ TABLE it_mlgn INTO wa_mlgn WITH KEY matnr = wa_lqua-matnr.
      IF sy-subrc = 0.
        wa_final-zbatch_stk = wa_mlgn-lhmg1.
      ENDIF.
    ENDIF.

    CLEAR wa_mvke.
    READ TABLE it_mvke INTO wa_mvke WITH KEY matnr = wa_lqua-matnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      wa_final-mvgr5 = wa_mvke-mvgr5.
    ENDIF.
*  *End of changes 4806 B Raj Kumar

    wa_final-kbetr_mrp = wa_final-kbetr1 * wa_final-v_conve2.

    i_mrp = wa_final-kbetr_mrp.


    CALL FUNCTION 'J_1I6_ROUND_TO_NEAREST_AMT'
      EXPORTING
        i_amount = i_mrp
      IMPORTING
        e_amount = o_mrp.

    wa_final-kbetr_mrp = o_mrp.

    APPEND wa_final TO it_final.
    CLEAR : wa_final, i_mrp, o_mrp.
  ENDLOOP.

*Added by Raj Kumar 4806
  IF rad1 = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname = 'ZLABEL_PNT_IN_PAINT_WITHOUTMRP'
*       VARIANT  = ' '
*       DIRECT_CALL              = ' '
      IMPORTING
        fm_name  = v_form_name
*           EXCEPTIONS
*       NO_FORM  = 1
*       NO_FUNCTION_MODULE       = 2
*       OTHERS   = 3
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    IF it_final IS NOT INITIAL.
      DESCRIBE TABLE it_final LINES w_cnt.

      LOOP AT it_final INTO wa_final.
        IF w_cnt GT 1.
          w_cnt2 = sy-tabix .
          CASE w_cnt2.
            WHEN 1.
              control_parameters-no_open   = space .
              control_parameters-no_close  = 'X' .
            WHEN w_cnt .
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = space .
            WHEN OTHERS.
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = 'X' .
          ENDCASE.
        ELSE.
          control_parameters-no_open   = space .
          control_parameters-no_close  = space .
        ENDIF.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            wa_final           = wa_final
            wa_address         = wa_address
            v_plant_name       = v_plant_name
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
      ENDLOOP.
    ENDIF.
  ENDIF .

  IF rad2 = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname = 'ZLABEL_PNT_IN_PAINT_WITHMRP'
*       VARIANT  = ' '
*       DIRECT_CALL              = ' '
      IMPORTING
        fm_name  = v_form_name
*           EXCEPTIONS
*       NO_FORM  = 1
*       NO_FUNCTION_MODULE       = 2
*       OTHERS   = 3
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    IF it_final IS NOT INITIAL.
      DESCRIBE TABLE it_final LINES w_cnt.

      LOOP AT it_final INTO wa_final.
        IF w_cnt GT 1.
          w_cnt2 = sy-tabix .
          CASE w_cnt2.
            WHEN 1.
              control_parameters-no_open   = space .
              control_parameters-no_close  = 'X' .
            WHEN w_cnt .
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = space .
            WHEN OTHERS.
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = 'X' .
          ENDCASE.
        ELSE.
          control_parameters-no_open   = space .
          control_parameters-no_close  = space .
        ENDIF.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            wa_final           = wa_final
            wa_address         = wa_address
            v_plant_name       = v_plant_name
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
      ENDLOOP.
    ENDIF.
  ENDIF .

****************************  WITHOUT QTY.

  IF rad3 = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname = 'ZLABEL_PNT_IN_PAINT_WITHOUTQTY'
*       VARIANT  = ' '
*       DIRECT_CALL              = ' '
      IMPORTING
        fm_name  = v_form_name
*           EXCEPTIONS
*       NO_FORM  = 1
*       NO_FUNCTION_MODULE       = 2
*       OTHERS   = 3
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    IF it_final IS NOT INITIAL.
      DESCRIBE TABLE it_final LINES w_cnt.

      LOOP AT it_final INTO wa_final.
        IF w_cnt GT 1.
          w_cnt2 = sy-tabix .
          CASE w_cnt2.
            WHEN 1.
              control_parameters-no_open   = space .
              control_parameters-no_close  = 'X' .
            WHEN w_cnt .
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = space .
            WHEN OTHERS.
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = 'X' .
          ENDCASE.
        ELSE.
          control_parameters-no_open   = space .
          control_parameters-no_close  = space .
        ENDIF.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            wa_final           = wa_final
            wa_address         = wa_address
            v_plant_name       = v_plant_name
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
      ENDLOOP.
    ENDIF.
  ENDIF .

  IF rad4 = 'X'.
    CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
      EXPORTING
        formname = 'ZLABEL_PNT_IN_PAINT_WOMRP_QTY'
*       VARIANT  = ' '
*       DIRECT_CALL              = ' '
      IMPORTING
        fm_name  = v_form_name
*           EXCEPTIONS
*       NO_FORM  = 1
*       NO_FUNCTION_MODULE       = 2
*       OTHERS   = 3
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    IF it_final IS NOT INITIAL.
      DESCRIBE TABLE it_final LINES w_cnt.

      LOOP AT it_final INTO wa_final.
        IF w_cnt GT 1.
          w_cnt2 = sy-tabix .
          CASE w_cnt2.
            WHEN 1.
              control_parameters-no_open   = space .
              control_parameters-no_close  = 'X' .
            WHEN w_cnt .
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = space .
            WHEN OTHERS.
              control_parameters-no_open   = 'X' .
              control_parameters-no_close  = 'X' .
          ENDCASE.
        ELSE.
          control_parameters-no_open   = space .
          control_parameters-no_close  = space .
        ENDIF.

        CALL FUNCTION v_form_name
          EXPORTING
            control_parameters = control_parameters
            wa_final           = wa_final
            wa_address         = wa_address
            v_plant_name       = v_plant_name
          EXCEPTIONS
            formatting_error   = 1
            internal_error     = 2
            send_error         = 3
            user_canceled      = 4
            OTHERS             = 5.
      ENDLOOP.
    ENDIF.
  ENDIF .

*Added by Raj Kumar 4806

*  *&---------------------------------------------------------------------*
*&      Form  ZSU_NOF4HELP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM zsu_nof4help .

  CLEAR it_zsu_no.

  SELECT lenum
        FROM lqua
  INTO TABLE it_lqua1.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
*     DDIC_STRUCTURE  = ' '
      retfield        = 'lenum'
*     PVALKEY         = ' '
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'S_ZSU_NO '
*     STEPL           = 0
*     WINDOW_TITLE    =
*     VALUE           = ' '
      value_org       = 'S'
*     MULTIPLE_CHOICE = ' '
*     DISPLAY         = ' '
*     CALLBACK_PROGRAM       = ' '
*     CALLBACK_FORM   = ' '
*     CALLBACK_METHOD =
*     MARK_TAB        =
*    IMPORTING
*     USER_RESET      =
    TABLES
      value_tab       = it_zsu_no
*     FIELD_TAB       =
*     RETURN_TAB      =
*     DYNPFLD_MAPPING =
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORISATION_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorisation_check .
******************************************************************Authorisation Object
**
  AUTHORITY-CHECK OBJECT 'ZMM_SU_WRK'
      ID 'WERKS' FIELD p_werks
      ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e047(zmm) WITH  p_werks.
  ENDIF.
  CLEAR :  wa_zmm_su_number.
  CLEAR :  wa_lqua.

*****************************************************************Authorisatio Object

ENDFORM.
