*&---------------------------------------------------------------------*
*&  Include           ZI_GOODS_ISSUE_TOP
*&---------------------------------------------------------------------*
TABLES:ltbp.
DATA:lgort TYPE lgort_d.
TYPES:BEGIN OF ty_ltbp,
        tbpos TYPE tbpos,
        "line(5) TYPE n,
        matnr TYPE matnr,
        charg TYPE  ltbp-charg,
        menge TYPE  ltbp-menge,
        meins TYPE ltbp-meins,
      END OF ty_ltbp.

TYPES:BEGIN OF ty_final,
        matnr TYPE   matnr,
        charg TYPE  ltbp-charg,
        menge TYPE  ltbp-menge,
        meins TYPE ltbp-meins,
        tbpos TYPE tbpos,
      END OF ty_final.

DATA fill TYPE i.
DATA fill_9000 TYPE i.
DATA it_final TYPE STANDARD TABLE OF ty_final.
DATA it_final_comp TYPE STANDARD TABLE OF ty_final.
DATA flag_enter TYPE c VALUE 0.
DATA flag_post TYPE c VALUE 0.
DATA : p_scan  TYPE char40.
DATA : v_field1 TYPE char18,
       v_field2 TYPE string,
       v_field3 TYPE char18,
       v_field4 TYPE char10.
DATA wa_final TYPE ty_final.
DATA wa_final_comp TYPE ty_final.
DATA wa_final1 TYPE ty_final.
DATA:gt_ltbp  TYPE STANDARD TABLE OF ty_ltbp,
     gt_sltbp TYPE STANDARD TABLE OF ty_ltbp,
     wa_sltbp TYPE  ty_ltbp,
     wa_ltbp  TYPE ty_ltbp.
CONSTANTS:gc_flines TYPE i VALUE 6.

DATA: idx          TYPE i,
      line         TYPE i,
      lines        TYPE i,
      limit        TYPE i,
      scount       TYPE i VALUE 6,
      c            TYPE i,
      name         TYPE char40,
      value        TYPE char40,
      n2           TYPE i VALUE 25,
      slines       TYPE i,
      sidx         TYPE i,
      scr          TYPE i,
      gv_matnr     TYPE matnr,
      gv_charg     TYPE charg_d,
      gv_menge     TYPE ltbp_menge,
      gv_issue_qty TYPE ltbp_menge,
      gv_tbpos     TYPE tbpos.

DATA idx_9001              TYPE i.
DATA lines_9001           TYPE i.
DATA line_9001            TYPE i.
DATA flag_check TYPE C VALUE 0.
data gv_lgnum TYPE lgnum.
data IT_TRITE TYPE  L03B_TRITE_T.
data wa_trite TYPE L03B_TRITE.
data gv_plant TYPE werks_d.
data flag_less TYPE c VALUE 0.
data gv_tanum type LTAK-TANUM.
data : it_bdcdata      TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
       wa_bdcdata      TYPE bdcdata.                            "bdc internal table declaration.
data gv_text TYPE char100.
DATA idx_9000              TYPE I.
DATA lines_9000           TYPE I.
DATA line_9000            TYPE I.
data limit_9000 TYPE i.

data flag_dlt TYPE n VALUE 0.
data flag_edit TYPE n VALUE 0.
data flag_exceed TYPE n VALUE 0.
