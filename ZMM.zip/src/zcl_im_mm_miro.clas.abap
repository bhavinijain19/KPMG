class ZCL_IM_MM_MIRO definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MRM_HEADER_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_MIRO IMPLEMENTATION.


  METHOD if_ex_mrm_header_check~headerdata_check.
* soa: For Block Invoice Posting for po by udayabap01 on 25.12.2025
    DATA: lt_rseg TYPE  TABLE OF mmcr_drseg.
    lt_rseg[] = ti_drseg[].
    IF lt_rseg IS NOT INITIAL.
      SELECT ebeln, zz1_block_invoice_pdh
        FROM ekko
        INTO TABLE @DATA(lt_ekko_data)
        FOR ALL ENTRIES IN @lt_rseg[]
        WHERE ebeln EQ @lt_rseg-ebeln
          AND zz1_block_invoice_pdh = @abap_true.

      " Raise an error message if blocked
      IF sy-subrc = 0.

        DATA(ls_ekko_data) = VALUE #( lt_ekko_data[ 1 ] OPTIONAL ).

        MESSAGE e006(zmm_msgs) WITH ls_ekko_data-ebeln.
      ENDIF.
    ENDIF.
* EOA: For Block Invoice Posting for PO by UDAYABAP01 on 25.12.2025
*soc attachments check while posting UDAYABAP01 PT 12022026
      IF sy-ucomm = 'BU'.
    DATA: lt_srgbtbrel TYPE TABLE OF srgbtbrel.
    IF lt_rseg[] IS NOT INITIAL.
      lt_srgbtbrel = VALUE #( FOR ls_rseg IN lt_rseg[]
                               (  instid_a = |{ ls_rseg-bukrs }| && |{ ls_rseg-belnr }| && |{ ls_rseg-gjahr }|
                                  reltype =  'ATTA'
                                  typeid_a  = 'FIPP'
                                  catid_a = 'BO'
                                  client = sy-mandt ) ).
      IF lt_srgbtbrel IS INITIAL .
        MESSAGE e000(ZFI_ABAP) WITH 'ATTACHMENTS NOT AVAILABLE' DISPLAY LIKE 'S'.
      ENDIF.
    ENDIF.
  ENDIF.
*Eoc attachments check while posting UDAYABAP01 PT 12022026
  endmethod.
ENDCLASS.
