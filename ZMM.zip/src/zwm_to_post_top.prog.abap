*&---------------------------------------------------------------------*
*&  Include           ZWM_TO_POST_TOP
*&---------------------------------------------------------------------*
TYPE-POOLS: slis,
            icon.

TYPES : BEGIN OF ty_ltbk,
          lgnum	TYPE lgnum,
          tbnum	TYPE tbnum,
          statu	TYPE ltbk_statu,
          trart	TYPE lvs_trart,
          mblnr	TYPE mblnr,
        END OF ty_ltbk,

        BEGIN OF ty_ltbp,
          lgnum	TYPE lgnum,
          tbnum	TYPE tbnum,
          tbpos	TYPE tbpos,
          elikz	TYPE ltbp_elikz,
          matnr	TYPE matnr,
          werks	TYPE werks_d,
          charg	TYPE charg_d,
          menge TYPE ltbp-menge,
          meins	TYPE meins,
          tamen	TYPE ltbp_tamen,
          mbpos	TYPE mblpo,
          lgort	TYPE lgort_d,
        END OF ty_ltbp,

        BEGIN OF ty_lagp,
          lgnum	TYPE lgnum,
          lgtyp	TYPE lgtyp,
          lgpla	TYPE lgpla,
          kzler type LAGP_KZLER,
        END OF ty_lagp,

        BEGIN OF ty_t300t,
          lgnum	TYPE lgnum,
          lnumt	TYPE lvs_lnumt,
        END OF ty_t300t,

        BEGIN OF ty_ltbk1,
          lgnum TYPE lgnum,
          tbnum	TYPE tbnum,
        END OF ty_ltbk1,

        BEGIN OF ty_lein,
          lenum	TYPE lenum,
          lgnum	TYPE lgnum,
          lgtyp	TYPE lgtyp,
        END OF ty_lein,

        BEGIN OF ty_final,
          checkbox TYPE c,
          tbnum    TYPE tbnum,
          tbpos	   TYPE tbpos,
          trart	   TYPE lvs_trart,
          matnr    TYPE matnr,
          maktx    TYPE maktx,
          mblnr	   TYPE mblnr,
          mbpos    TYPE mblpo,
          werks	   TYPE werks_d,
          lgort	   TYPE lgort_d,
          charg	   TYPE charg_d,
          menge    TYPE ltbp-menge,
          meins	   TYPE meins,
          tamen	   TYPE ltbp_tamen,
          tamen1   TYPE ltbp_tamen,
          lgpla	   TYPE lgpla,
          zsu_no   TYPE	zsu_no,
          zsu_no1  TYPE  zsu_no,
          lety1	   TYPE lvs_letyp1,
        END OF ty_final,

        BEGIN OF ty_makt,
          matnr TYPE matnr,
          maktx TYPE maktx,
        END OF ty_makt,

        BEGIN OF ty_zmm_su_number,
          zsu_no TYPE  zsu_no,
          matnr  TYPE matnr,
          werks  TYPE werks_d,
          charg  TYPE charg_d,
          lhmg1  TYPE zlvs_lhmng12,
          lety1  TYPE lvs_letyp1,
*          mark   TYPE c,
        END OF ty_zmm_su_number,

        BEGIN OF ty_zwm_picklist,
          werks TYPE  werks_d,
          lgort	TYPE lgort_d,
          lgnum	TYPE lgnum,
          lgtyp	TYPE lgtyp,
          lgber TYPE  lgber,
        END OF ty_zwm_picklist,

        BEGIN OF ty_mlgn,
          matnr TYPE matnr,
          lgnum TYPE lgnum,
          lety1 TYPE lvs_letyp1,
        END OF ty_mlgn.

DATA it_mlgn TYPE STANDARD TABLE OF ty_mlgn.
DATA wa_mlgn TYPE ty_mlgn.

DATA: lhmg_sum TYPE zlvs_lhmng12.

DATA : it_ltbk               TYPE STANDARD TABLE OF ty_ltbk,
       it_ltbp               TYPE STANDARD TABLE OF ty_ltbp,
       it_lagp               TYPE STANDARD TABLE OF ty_lagp,
       it_t300t              TYPE STANDARD TABLE OF ty_t300t,
       it_ltbk1              TYPE STANDARD TABLE OF ty_ltbk1,
       it_lein               TYPE STANDARD TABLE OF ty_lein,
       it_final              TYPE STANDARD TABLE OF ty_final,
       it_makt               TYPE STANDARD TABLE OF ty_makt,
       it_ltap_vb            TYPE STANDARD TABLE OF ltap_vb,
       it_ltak               TYPE STANDARD TABLE OF ltak_vb,
       wa_ltap_vb            TYPE ltap_vb,
       it_zmm_su_number      TYPE STANDARD TABLE OF ty_zmm_su_number,
       it_zmm_su_number_temp TYPE STANDARD TABLE OF ty_zmm_su_number,
       it_ltap_conf          TYPE STANDARD TABLE OF ltap_conf,
       wa_ltap_conf          TYPE ltap_conf,
       it_zwm_picklist       TYPE STANDARD TABLE OF ty_zwm_picklist,
       wa_zwm_picklist       TYPE ty_zwm_picklist,
       wa_zmm_su_number      TYPE ty_zmm_su_number,
       wa_zmm_su_number_temp TYPE ty_zmm_su_number,
       wa_makt               TYPE ty_makt,
       wa_final              TYPE ty_final,
       wa_copy               TYPE ty_final,
       wa_lein               TYPE ty_lein,
       gt_dynpfields         TYPE TABLE OF dynpread,
       wa_ltbk1              TYPE ty_ltbk1,
       wa_t300t              TYPE ty_t300t,
       wa_lagp               TYPE ty_lagp,
       wa_ltbp               TYPE ty_ltbp,
       wa_ltbk               TYPE ty_ltbk,
       gwa_dynpfields        TYPE dynpread,
       it_fldcat             TYPE  lvc_t_fcat, "slis_t_fieldcat_alv,
       gv_lbnum              TYPE lgnum,
       it_trite              TYPE STANDARD TABLE OF l03b_trite,
       wa_trite              TYPE  l03b_trite,
       gv_tbnum              TYPE tbnum,
       gv_cnt                TYPE i,
       rt_extab              TYPE slis_t_extab,
       r_ucomm               LIKE sy-ucomm,
       rs_selfield           TYPE slis_selfield,
       gv_tanum              TYPE ltak-tanum,
       gv_teilv              TYPE t340d-teilv,
       gv_text(1000)         TYPE c,
       gv_text1(1000)        TYPE c,
       gv_text2(1000)        TYPE c,
       gv_text3(1000)        TYPE c,
       gv_text4(500)        TYPE c,
       gv_text5(500)        TYPE c,
       gv_typ                TYPE char20,
       gv_typ1               TYPE char20,
       gv_zsu_no             TYPE  zsu_no,
       row                   TYPE i VALUE '0',
       it_bdcdata            TYPE TABLE OF bdcdata,                   "bdc internal table declaration.
       wa_bdcdata            TYPE bdcdata.                            "bdc internal table declaration..

FIELD-SYMBOLS :  <fs_fldcat> TYPE lvc_s_fcat. "slis_fieldcat_alv.

DATA : ty_toolbar TYPE stb_button.
DATA:   it_layout          TYPE lvc_s_layo.        "Layout

DATA flag TYPE c.
DATA flag2 TYPE c.
DATA flag_no TYPE c.
DATA flag_sum TYPE i value 0.
data counter(10) type i value 1.
*
*DATA: gd_repid LIKE sy-repid, "Exists
*            ref_grid TYPE REF TO cl_gui_alv_grid.
data execute TYPE N VALUE 0.
DATA:v_su_no TYPE zsu_no.
DATA:v_lenum TYPE lein-lenum.
SELECT-OPTIONS: s_number FOR v_su_no NO-DISPLAY.
SELECT-OPTIONS: s_num1 FOR v_lenum NO-DISPLAY.
