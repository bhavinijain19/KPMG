*&---------------------------------------------------------------------*
*& Report ZMM_SU_BOM_NUMBER
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zmm_su_bom_number.

TABLES : afko,afpo.
*&---------------------------------------------------------------------*
*&                INCLUDES
*&---------------------------------------------------------------------*
INCLUDE zmm_su_box_number_top.
INCLUDE zmm_su_box_number_scr.

INITIALIZATION.
  executed = 1.

AT SELECTION-SCREEN.

  IF p_aufnr IS INITIAL.
    MESSAGE 'Enter production Order Number' TYPE 'E'.
  ELSE.
********************************************changed done by rajni*************8
    SELECT SINGLE aufnr,posnr, matnr FROM afpo INTO @DATA(wa_afpo) WHERE aufnr = @p_aufnr.
*    SELECT SINGLE aufnr,posnr, matnr FROM afpo INTO @DATA(wa_afpo) WHERE aufnr = @p_aufnr.
    IF sy-subrc = 0 AND wa_afpo IS NOT INITIAL.
      SELECT SINGLE matnr FROM mlgt INTO @DATA(v_mlgt) WHERE matnr = @wa_afpo-matnr.
      IF sy-subrc <> 0.
        MESSAGE:'Material is not warehouse managed' TYPE 'E'.
      ENDIF.
    ENDIF.
  ENDIF.

********************************************changed done by rajni*************


  IF p_prdqty IS INITIAL.

    MESSAGE 'Production Order confimed Qty' TYPE 'I'.
    CLEAR :
    p_matnr1,
    p_maktx1,
    p1_charg,
    p1_dwerk,
    p1_lgort,
    p_lgpla ,
    p1_stock,
    p1_lhmg1,
    p1_no   ,
    p1_meins,
    p1_lety1,
    p1_lhme1,
    p_aufnr,
    p_matnr ,
    p_maktx,
    p_charg ,
    p_dwerk ,
    p_prdqty,
    p_lhmg1 ,
    p_no    ,
    p_amein ,
    p_logrt ,
    p_pgmng ,
    p_lety1 ,
    p_lhme1.
    EXIT.
  ENDIF.
********************************************************
*Changes made on 12.04.2019.

***********************************************************
  v_matnr = gv_matnr.
  IF  gv_charg IS NOT INITIAL.
    v_charg = gv_charg.
  ELSEIF gv_charg1 IS NOT INITIAL.
    v_charg = gv_charg1.

  ENDIF.
  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = v_charg
    IMPORTING
      output = v_charg.


  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = v_matnr
    IMPORTING
      output = v_matnr.


  SELECT SINGLE matnr ,charg ,hsdat
  FROM mch1
  INTO @DATA(wa_mch1)
        WHERE matnr   EQ  @v_matnr
        AND   charg   EQ @v_charg.
  IF wa_mch1-hsdat IS INITIAL.
    MESSAGE 'Enter Manufacturing date' TYPE 'E'. "DISPLAY LIKE 'E'.
  ENDIF.
***************************************************************************
*&---------------------------------------------------------------------*
*&                start-of-selection
*&---------------------------------------------------------------------*
START-OF-SELECTION.

*  CLEAR : it_zmm_su_number, gv_zsu_no.
*  SELECT mandt
*         zsu_no
*         FROM zmm_su_number
*         INTO TABLE it_zmm_su_number.
*  IF sy-subrc EQ 0.
*    SORT it_zmm_su_number BY zsu_no DESCENDING.
*  ENDIF.
  gv_text = 'SU Number is generated'.
*  READ TABLE it_zmm_su_number INTO wa_zmm_su_number INDEX 1.
*  IF sy-subrc EQ 0.
*    gv_zsu_no = wa_zmm_su_number-zsu_no.
*  ENDIF.
  CLEAR wa_final.
  IF rad2 = 'X'.
    wa_final-matnr = gv_matnr.
    wa_final-werks = gv_plant1.
    wa_final-lgort = gv_lgort1.
    wa_final-charg = gv_charg1.
    wa_final-meins = gv_meins.
    wa_final-lhmg1 = gv1_lhmg1.
    wa_final-lety1 = gv_lety1.
    wa_final-lhme1 = gv_lhme1.
    wa_final-mandt = sy-mandt.
    wa_final-lgpla = p_lgpla.
    gv_no_label = gv_p1_no.

    CONDENSE gv_stock.
    CONDENSE gv_stock1.
    IF gv_stock IS NOT INITIAL.
      wa_final-zbatch_stk = gv_stock.
      IF gv_zlhmg1 IS INITIAL.
        wa_final-zlhmg1 = gv_stock1 - gv_stock.
      ELSE.
        wa_final-zlhmg1 = gv_zlhmg1 - gv_stock.
      ENDIF.
    ELSE.
      wa_final-zbatch_stk = gv_stock1.
      wa_final-zlhmg1 = gv_stock - gv_stock1.
    ENDIF.


  ELSEIF rad1 = 'X' OR rad3 = 'X'.
    wa_final-aufnr = gv_aufnr.
    wa_final-matnr = gv_matnr.
    wa_final-werks = gv_plant.
    wa_final-lgort = gv_lgort.
    wa_final-charg = gv_charg.
    wa_final-meins = gv_meins1.
    wa_final-lety1 = gv_lety1.
    wa_final-lhmg1 = gv_lhmg1.
    wa_final-lhme1 = gv_lhme1.
    gv_no_label = gv_p_no.
    wa_final-dispo = gv_dispo.
    wa_final-budat = sy-datum.


*******************************    03.02.2023 for number range based on company code

    SELECT SINGLE bukrs FROM t001k INTO gv_bukrs WHERE bwkey = gv_plant.

*    SELECT SINGLE nrrangenr FROM zwm_snro_box INTO gv_snro WHERE bukrs = gv_bukrs.

************************************ end of

*    IF gv_menge1 IS NOT INITIAL.
*      wa_final-zbatch_stk = gv_menge1.
*      IF gv_zlhmg1 IS INITIAL.
*        wa_final-zlhmg1 = gv_menge - gv_menge1.
*      ELSE.
*        wa_final-zlhmg1 = gv_zlhmg1 - gv_menge1.
*      ENDIF.
*    ELSE.
*      wa_final-zbatch_stk = gv_menge.
*      wa_final-zlhmg1 = gv_menge - gv_menge1.
*    ENDIF.
*
    IF wa_check-confirm_qty IS INITIAL.
      wa_final-zbatch_stk = gv_menge1.
      wa_final-zlhmg1 = difference.
      wa_final-confirm_qty = gv_menge.
    ELSEIF gv_menge1 IS NOT INITIAL AND  wa_check-confirm_qty = gv_menge.
      wa_final-zbatch_stk = gv_menge1.
      wa_final-zlhmg1 = difference.
      wa_final-confirm_qty = gv_menge.
    ELSEIF gv_menge1 IS NOT INITIAL AND  wa_check-confirm_qty <> gv_menge.
      wa_final-zbatch_stk = gv_menge1.
      wa_final-zlhmg1 = difference - gv_menge1.
      wa_final-confirm_qty = gv_menge.
    ENDIF.
  ENDIF.

  gv_last = gv_no_label - 1.
  " IF wa_mch1-hsdat IS  NOT INITIAL.
  WHILE ( gv_no_label  NE gv_count ).
*    gv_zsu_no = gv_zsu_no + 1.*
*    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*      EXPORTING
*        input  = gv_zsu_no
*      IMPORTING
*        output = gv_zsu_no.


    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr = '01' "gv_snro
        object      = 'ZSU_NO'
*       QUANTITY    = '1'
*       SUBOBJECT   = ' '
*       TOYEAR      = '0000'
*       IGNORE_BUFFER                 = ' '
      IMPORTING
        number      = gv_num
*       QUANTITY    =
*       RETURNCODE  =
*   EXCEPTIONS
*       INTERVAL_NOT_FOUND            = 1
*       NUMBER_RANGE_NOT_INTERN       = 2
*       OBJECT_NOT_FOUND              = 3
*       QUANTITY_IS_0                 = 4
*       QUANTITY_IS_NOT_1             = 5
*       INTERVAL_OVERFLOW             = 6
*       BUFFER_OVERFLOW               = 7
*       OTHERS      = 8
      .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    wa_final-zsu_no = gv_num. "gv_zsu_no.

    IF gv_last EQ gv_count.
      wa_final-lhmg1 = wa_final-zbatch_stk - gv_sum.
    ENDIF.
    APPEND wa_final TO it_final.

    INSERT zmm_su_number FROM TABLE it_final.

    gv_count = gv_count + 1.
    gv_sum = gv_sum + wa_final-lhmg1.
    CLEAR : it_final.

  ENDWHILE.
  "endif.
  "IF wa_mch1-hsdat IS NOT INITIAL.
* if it_final is NOT INITIAL.
  MESSAGE gv_text TYPE 'S'.
* endif.
  "ENDIF.
  CLEAR :gwa_dynpfields ,
    gv_matnr,
    gv_aufnr,
    gv_menge,
    gv_text,
    gv_zsu_no,
    gv_meins,
    gv_maktx,
    gv_lety1,
    gv_lhme1,
    gv_lhmg1,
    gv1_lhmg1,
    gv_stock,
    gv_amein,
    gv_plant,
    gv_pgmng,
    gv_lgort,
    gv_charg,
    gt_dynpfields,
    gv_p_no,
    gv_p1_no,
    gv_count,
    gv_no_label,
    gv_dispo,
    difference,
    gv_bukrs, " added 03.01.2023
    gv_amt,
    gv_amt1,
*    gv_snro,
    gc.




*  *  *&---------------------------------------------------------------------*
*&      Form  P_LGPLA_F4
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM p_lgpla_f4 .

  CLEAR it_zwm_picklist.
  IF gv_plant1 IS NOT INITIAL AND gv_lgort1 IS NOT INITIAL.

    SELECT werks
              lgort
              lgnum
              lgtyp
              lgber
              FROM zwm_picklist
              INTO TABLE it_zwm_picklist
              WHERE werks = gv_plant1 AND
                    lgort = gv_lgort1.
  ENDIF.

  IF sy-subrc EQ 0 AND it_zwm_picklist IS NOT INITIAL.

    CLEAR it_lagp.

    SELECT lgnum
           lgtyp
           lgpla
           lgber FROM lagp
           INTO TABLE it_lagp
           FOR ALL ENTRIES IN it_zwm_picklist
           WHERE lgnum = it_zwm_picklist-lgnum AND
                 lgtyp = it_zwm_picklist-lgtyp AND
                 lgber = it_zwm_picklist-lgber.
  ENDIF.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
*     DDIC_STRUCTURE  = ' '
      retfield        = 'LGPLA'
*     PVALKEY         = ' '
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      dynprofield     = 'P_LGPLA'
*     STEPL           = 0
*     WINDOW_TITLE    =
*     VALUE           = ' '
      value_org       = 'S'
*     MULTIPLE_CHOICE = ' '
*     DISPLAY         = ' '
*     CALLBACK_PROGRAM       = ' '
*     CALLBACK_FORM   = ' '
*     CALLBACK_METHOD =
*     MARK_TAB        =
*    IMPORTING
*     USER_RESET      =
    TABLES
      value_tab       = it_lagp
*     FIELD_TAB       =
*     RETURN_TAB      =
*     DYNPFLD_MAPPING =
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


ENDFORM.
