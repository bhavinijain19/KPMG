*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_LOAD_SLOC...................................*
DATA:  BEGIN OF STATUS_ZMM_LOAD_SLOC                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_LOAD_SLOC                 .
CONTROLS: TCTRL_ZMM_LOAD_SLOC
            TYPE TABLEVIEW USING SCREEN '9001'.
*.........table declarations:.................................*
TABLES: *ZMM_LOAD_SLOC                 .
TABLES: ZMM_LOAD_SLOC                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
