*&---------------------------------------------------------------------*
*&  Include           ZMM_HU_LOAD_UNLOAD_STATUS_8O04
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8004  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8004 INPUT.
  TYPES:BEGIN OF tt_lqua,
          matnr TYPE matnr,
          charg TYPE charg_d,
          lgtyp TYPE lgtyp,
          lgpla TYPE lgpla,
          verme TYPE lqua_verme,
          lenum TYPE lenum,
          lgort TYPE lgort_d,
        END OF tt_lqua.
  DATA: it_lqua     TYPE STANDARD TABLE OF tt_lqua,
        wa_lqua_tmp TYPE tt_lqua,
*        lw_sloc8004_tmp TYPE zmm_load_sloc,
        wa_lqua     TYPE tt_lqua.
  DATA: no        TYPE posnr_vl,
        amt       TYPE mensh,
        totbal    TYPE lips-lfimg,
        su_totbal TYPE lips-lfimg,
        lv_mat    TYPE matnr18.   "matnr.
  CASE sy-ucomm.
    WHEN 'NEXTV'.
      line804 = line804 + lines804.
      limit804 = fill804 - lines804.
      IF line804 > limit804.
        line804 = limit804.
      ENDIF.
    WHEN 'PREVV'.
      line804 = line804 - lines804. "1.
      IF line804 < 0.
        line804 = 0.
      ENDIF.
    WHEN 'BACK'.
      CLEAR: su_cnt,lw_lips-matnr,lw_8004,wa_lqua,lw_lips.
      FREE: lt_8004,it_lqua,barcode_scan.
      FREE: obd_no,lin_item,lt_8002,lw_8002,gw_lenum,lt_8004,lw_8004,su_cnt,barcode_scan,cnt,barcode_scan.
      LEAVE TO SCREEN 8000.
    WHEN 'ENTER'.
      FREE: amt,wa_lqua,gw_lenum, lv_total_qty,lv_matnr.
*      clear : wa_lqua_tmp, lw_8004,lw_8002.
      SPLIT barcode_scan AT space INTO lv_mat gw_lenum.
      READ TABLE lt_8004 INTO lw_8004 WITH KEY lenum = gw_lenum.
      IF sy-subrc NE 0.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = lv_mat
          IMPORTING
            output = lv_mat.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = gw_lenum
          IMPORTING
            output = gw_lenum.

        SELECT SINGLE lenum  FROM lein
                         INTO @DATA(v_lein)
                   WHERE lenum = @gw_lenum.
        IF sy-subrc <> 0.
*          SET CURSOR FIELD 'BARCODE_SCAN'.
*          CLEAR: barcode_scan.
          MESSAGE 'Storage Unit Doesnot exist' TYPE 'I'.
          RETURN.
        ENDIF.

        SELECT COUNT(*) FROM lqua WHERE matnr =  lv_mat
                                    AND lenum = gw_lenum.
        IF sy-subrc = 0 AND  lt_8002 IS NOT INITIAL.

          SELECT COUNT(*) FROM lqua FOR ALL ENTRIES IN lt_8002
                                    WHERE charg = lt_8002-batch_no
                                      AND lenum = gw_lenum.
          IF sy-subrc NE 0.
*            SET CURSOR FIELD 'BARCODE_SCAN'.
*            CLEAR: barcode_scan.
            MESSAGE 'Wrong Batch Selected.' TYPE 'I'.
*            RETURN.
          ELSE.
            SELECT matnr charg lgtyp lgpla verme lenum lgort FROM lqua
               APPENDING TABLE  it_lqua WHERE lenum = gw_lenum.
            IF sy-subrc = 0.
              SORT it_lqua BY charg matnr lenum ASCENDING.
              DELETE ADJACENT DUPLICATES FROM it_lqua COMPARING charg matnr lenum .

              READ TABLE it_lqua INTO wa_lqua_tmp
              WITH KEY lenum = gw_lenum.

              DELETE lt_8004 WHERE lenum = ' '.
*              CLEAR: lw_8002.
*              LOOP AT it_lqua INTO wa_lqua WHERE charg = wa_lqua_tmp-charg.
*              LOOP AT lt_8002 INTO lw_8002 WHERE batch_no = wa_lqua_tmp-charg.
*                amt = amt + lw_8002-qty.
*                CLEAR: wa_free_qty.
*              ENDLOOP.
*              CLEAR : lw_8004,lv_total_qty,lw_8002.
*              LOOP AT lt_8004 INTO lw_8004 WHERE charg = wa_lqua_tmp-charg.
*                lv_total_qty  = lv_total_qty + lw_8004-qty.
*              ENDLOOP.

              LOOP AT it_lqua INTO wa_lqua WHERE charg = wa_lqua_tmp-charg.
                READ TABLE lt_lips INTO lw_lips WITH KEY  matnr = wa_lqua-matnr
                                                          charg = wa_lqua-charg.
                IF sy-subrc = 0.
*                  lv_total_qty  = lw_lips-lfimg.
                  amt = amt + wa_lqua-verme.
                ENDIF.
                CLEAR: wa_free_qty.
              ENDLOOP.
              CLEAR : lw_8004,lv_total_qty,lw_8002.
              LOOP AT lt_8002 INTO lw_8002 WHERE batch_no = wa_lqua-charg.
                lv_total_qty  = lv_total_qty + lw_8002-qty.
              ENDLOOP.

              SORT lt_8002 BY batch_no ASCENDING.

*              lv_total_qty = lv_total_qty + wa_lqua_tmp-verme.

*              IF lv_total_qty LE amt."lw_8002-qty. " changes done on 13.04.2019.
              IF amt LE lv_total_qty ."lw_8002-qty. " changes done on 13.04.2019.
                CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
                  EXPORTING
                    input  = gw_lenum
                  IMPORTING
                    output = gw_lenum.
                lw_8004-charg = wa_lqua-charg.
                lw_8004-lenum = gw_lenum.
                lw_8004-qty   = wa_lqua-verme.
                APPEND lw_8004 TO lt_8004.
                CLEAR : lw_8004, gw_lenum,amt.
                su_cnt = su_cnt + 1.
              ELSE.
                DELETE it_lqua WHERE lenum =  gw_lenum.
                FREE: gw_lenum.
*                SET CURSOR FIELD 'BARCODE_SCAN'.
*                CLEAR: barcode_scan.
                CONCATENATE 'Quantity exceeded for batch '  wa_lqua-charg INTO lv_msg SEPARATED BY space.
                MESSAGE lv_msg TYPE 'I'.
              ENDIF.
            ENDIF.
          ENDIF.
        ELSE.
          FREE:gw_lenum.
*          SET CURSOR FIELD 'BARCODE_SCAN'.
          MESSAGE 'Wrong Material Selected.' TYPE 'I'.
        ENDIF.
      ELSE.
*        SET CURSOR FIELD 'BARCODE_SCAN'.
*        CLEAR: barcode_scan.
        MESSAGE 'SU no. already selected.' TYPE 'I'.
      ENDIF.
      FREE: barcode_scan.
    WHEN 'SAVE'.
      FREE: lv_num, no, lw_lips, lt_lips[],it_free_qty.
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING
          nr_range_nr             = '01'
          object                  = 'ZMM_LOAD'
*         QUANTITY                = '1'
*         SUBOBJECT               = ' '
*         TOYEAR                  = '0000'
*         IGNORE_BUFFER           = ' '
        IMPORTING
          number                  = lv_num
        EXCEPTIONS
          interval_not_found      = 1
          number_range_not_intern = 2
          object_not_found        = 3
          quantity_is_0           = 4
          quantity_is_not_1       = 5
          interval_overflow       = 6
          buffer_overflow         = 7
          OTHERS                  = 8.
      IF lv_num IS NOT INITIAL.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = obd_no
          IMPORTING
            output = obd_no.

        SELECT vbeln posnr matnr lgort charg
          lfimg meins uepos lgpla  uecha uepvw FROM lips
          INTO TABLE lt_lips
          WHERE vbeln = obd_no.
*          and uecha =  lin_item.

        lt_lips_tmp =  lt_lips.

        DELETE lt_lips WHERE uecha <> lin_item.
*
*        LOOP AT lt_lips INTO lw_lips.
*          READ TABLE lt_lips_tmp INTO lw_lips_tmp WITH KEY
*                                        uepos = lin_item
*                                        uepvw = 'B'.
*          IF sy-subrc = 0.
*            READ TABLE lt_lips_tmp INTO lw_lips_tmp1 WITH KEY
*                                    uecha = lw_lips_tmp-posnr.
*            IF sy-subrc = 0.
*              wa_free_qty-charg = lw_lips-charg.
*              wa_free_qty-matnr = lw_lips-matnr.
*              wa_free_qty-vbeln = lw_lips-vbeln.
*              wa_free_qty-posnr = lw_lips_tmp1-posnr.
*              wa_free_qty-free_qty = lw_lips_tmp1-lfimg.
*              wa_free_qty-del_item = lw_lips-posnr.
*              APPEND wa_free_qty TO it_free_qty.
*              CLEAR: wa_free_qty,lw_lips.
*            ENDIF.
*          ENDIF.
*        ENDLOOP.

        IF lt_8004 IS NOT INITIAL.
          SELECT matnr werks charg lenum verme lgpla lgort
                FROM lqua INTO TABLE lt_lqua
                FOR ALL ENTRIES IN lt_8004  " add perfromance issue 04.09.2023
                WHERE charg = lt_8004-charg. " add perfromance issue 04.09.2023

        ENDIF.
        IF sy-subrc = 0 .
          SORT lt_lqua ASCENDING.
          LOOP AT lt_8004 INTO lw_8004.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = lw_8004-lenum
              IMPORTING
                output = lw_8004-lenum.
            READ TABLE lt_lqua INTO lw_lqua
            WITH KEY lenum = lw_8004-lenum.

            READ TABLE lt_lips INTO lw_lips
            WITH KEY charg = lw_lqua-charg.
            no = no + 1.
            lw_sloc8004-load_no       = lv_num.
            lw_sloc8004-load_item     = no.
            lw_sloc8004-su_no         = lw_8004-lenum.
            lw_sloc8004-obd_no        = obd_no.
            lw_sloc8004-obd_lineitem  = lw_lips-posnr.
            lw_sloc8004-obd_headitem  = lin_item.
            lw_sloc8004-entry_date    = sy-datum.
            lw_sloc8004-storage_loc   = lw_lqua-lgort.
            lw_sloc8004-matnr         = lw_lips-matnr.
            lw_sloc8004-batch_no      = lw_lqua-charg.
            lw_sloc8004-quantity      = lw_lips-lfimg.
            lw_sloc8004-uom           = lw_lips-meins.
            lw_sloc8004-bin_loc       = lw_lqua-lgpla.
            lw_sloc8004-load_status   = 'I'.
            lw_sloc8004-plant         = lw_lqua-werks.
            lw_sloc8004-su_qty        = lw_lqua-verme.
            APPEND lw_sloc8004 TO lt_sloc8004.

*            CLEAR: wa_free_qty.
*            READ TABLE lt_sloc8004 WITH KEY obd_no = obd_no
*                                              matnr = lw_lips-matnr
*                                              batch_no = lw_lqua-charg TRANSPORTING NO FIELDS.
*            IF sy-subrc <> 0.
*              READ TABLE it_free_qty INTO wa_free_qty WITH KEY
*                                                       vbeln = obd_no
*                                                       matnr = lw_lips-matnr
*                                                       charg = lw_lqua-charg.
**                                                     del_item = lw_lips-posnr.
*              IF sy-subrc = 0.
*              lw_sloc8004-quantity = wa_free_qty-free_qty.
*               lw_sloc8004-su_qty = wa_free_qty-free_qty.
*              lw_sloc8004-obd_lineitem = wa_free_qty-posnr.
*              APPEND lw_sloc8004 TO lt_sloc8004.
*              ENDIF.
*            ENDIF.
*            CLEAR: lw_sloc8004,lw_8004,lw_lqua.
          ENDLOOP.
*
          IF it_free_qty IS NOT INITIAL.
            READ TABLE it_free_qty INTO wa_free_qty WITH KEY
                                                      vbeln = obd_no
                                                      matnr = lw_lips-matnr
                                                      charg = lw_lqua-charg.
            IF sy-subrc = 0.

              READ TABLE  lt_sloc8004 INTO  lw_sloc8004
                                          TRANSPORTING NO FIELDS WITH KEY obd_no = obd_no
                                                                      su_no = lw_8004-lenum
                                                                      matnr = lw_lips-matnr
                                                                      batch_no = lw_lqua-charg.

              IF sy-subrc = 0.
                lw_sloc8004-su_qty =  lw_sloc8004-su_qty - wa_free_qty-free_qty.

                MODIFY lt_sloc8004 FROM lw_sloc8004 TRANSPORTING su_qty WHERE  obd_no = obd_no
                                                                      AND matnr = lw_lips-matnr
                                                                      AND batch_no = lw_lqua-charg.
                lw_sloc8004-quantity =  wa_free_qty-free_qty.
                lw_sloc8004-load_item = lw_sloc8004-load_item + 1.
                lw_sloc8004-quantity = wa_free_qty-free_qty.
                lw_sloc8004-su_qty = wa_free_qty-free_qty.
                lw_sloc8004-obd_lineitem = wa_free_qty-posnr.
                APPEND lw_sloc8004 TO lt_sloc8004.

              ENDIF.
            ENDIF.
          ENDIF.
          CLEAR: lw_sloc8004,lw_8004,lw_lqua.

          MODIFY zmm_load_sloc FROM TABLE lt_sloc8004.
          COMMIT WORK AND WAIT.
*          CLEAR:lt_sloc8004.
          IF sy-subrc = 0.
            ls_num = lv_num.
            load_no = ls_num.
            CONDENSE ls_num.
            CONCATENATE 'Load No.' ls_num  'is generated.' INTO lv_msg SEPARATED BY space.
            MESSAGE lv_msg TYPE 'S'.
          ENDIF.
          CALL SCREEN 8005.
        ENDIF.
      ENDIF.
  ENDCASE.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8004  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8004 OUTPUT.
  SET PF-STATUS 'ZMM_8004'.
*  fill804 = cnt.
  fill804 = su_cnt.
*  SET TITLEBAR 'xxx'.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_OUT_8004  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_out_8004 OUTPUT.
  DATA: lw_8004d TYPE ty_suno.
  idx804 = sy-stepl + line804.
  READ TABLE lt_8004 INTO lw_8004d INDEX idx804.
  IF sy-subrc = 0.
    lw_8004 = lt_8004[ idx804 ].
  ENDIF.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  TRANSP_ITAB_IN_8004  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE transp_itab_in_8004 INPUT.
  lines804 = sy-loopc.
  idx804 = sy-stepl + line804.
*  MODIFY lt_8004 FROM lw_8004 INDEX idx804.
*   CLEAR: lw_8004.
ENDMODULE.
