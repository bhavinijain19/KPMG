*&---------------------------------------------------------------------*
*&  Include           ZMM_SU_NUMBER_LIST_REP_FORM
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorization .

  SELECT werks FROM t001w INTO TABLE gt_t001w WHERE werks IN s_werks.
  LOOP AT gt_t001w INTO wa_t001w.
    AUTHORITY-CHECK OBJECT 'ZSUNUM_WRK'
    ID 'WERKS' FIELD wa_t001w-werks
    ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e007(zsd) WITH wa_t001w-werks.
    ENDIF.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  SELECT * FROM zmm_su_number INTO TABLE it_main WHERE zsu_no IN s_num AND matnr IN s_matnr AND werks IN s_werks AND charg IN s_charg
                                                   AND aufnr IN s_aufnr AND dispo IN s_dispo AND budat IN s_budat.

  IF it_main IS NOT INITIAL.

    SELECT * FROM makt INTO TABLE it_makt FOR ALL ENTRIES IN it_main WHERE matnr = it_main-matnr AND spras = 'EN'.
    SELECT matnr lvorm mtart bismt FROM mara  INTO TABLE it_mara  FOR ALL ENTRIES IN it_main WHERE matnr = it_main-matnr.
    SELECT werks dispo dsnam FROM t024d INTO TABLE it_t024d FOR ALL ENTRIES IN it_main WHERE werks = it_main-werks AND dispo = it_main-dispo.

  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PROCESS_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_data .

  LOOP AT it_main INTO wa_main.

    wa_final-zsu_no     = wa_main-zsu_no.
    wa_final-aufnr      = wa_main-aufnr.
    wa_final-matnr      = wa_main-matnr.
    wa_final-werks      = wa_main-werks.
    wa_final-lgort      = wa_main-lgort.
    wa_final-charg      = wa_main-charg.
    wa_final-meins      = wa_main-meins.
    wa_final-lgpla      = wa_main-lgpla.
    wa_final-zlhmg1     = wa_main-zlhmg1.
    wa_final-lhme1      = wa_main-lhme1.
    wa_final-lhmg1      = wa_main-lhmg1.
    wa_final-lety1      = wa_main-lety1.
    wa_final-zbatch_stk = wa_main-zbatch_stk.
    wa_final-dispo      = wa_main-dispo.
    wa_final-budat      = wa_main-budat.

    IF wa_main-matnr IS NOT INITIAL.
      wa_final-maktx      = it_makt[ matnr = wa_main-matnr ]-maktx.
      wa_final-mtart      = it_mara[ matnr = wa_main-matnr ]-mtart.
      wa_final-lvorm      = it_mara[ matnr = wa_main-matnr ]-lvorm.
      wa_final-bismt      = it_mara[ matnr = wa_main-matnr ]-bismt.
    ENDIF.

    IF wa_main-werks IS NOT INITIAL AND wa_main-dispo IS NOT INITIAL.
      wa_final-dsnam      = it_t024d[ werks = wa_main-werks dispo = wa_main-dispo ]-dsnam.
    ENDIF.

    APPEND wa_final TO it_final.
    CLEAR: wa_final, wa_main.

  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_LISTHEADER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_listheader .

  it_listheader-typ = 'H'.
  it_listheader-key = ' '.
  it_listheader-info = 'Storage Unit Number List For Label Print Report'.
  APPEND it_listheader.

  it_listheader-typ = 'S'.
  it_listheader-key = 'Date :' .
  CONCATENATE  sy-datum+6(2)

               sy-datum+4(2)
               sy-datum(4)
               INTO it_listheader-info
               SEPARATED BY '/'.
  APPEND it_listheader.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FILL_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_layout .

  t_event-name = slis_ev_top_of_page.
  t_event-form = 'TOP_OF_PAGE'.
  APPEND t_event.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  TOP_OF_PAGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM top_of_page.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = it_listheader[].

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELD_CATALOGUE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM field_catalogue .

  wa_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_append  USING  'ZSU_NO'       'SU Number'              'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'AUFNR'        'Order'                  'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MATNR'        'Material'               'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'WERKS'        'Plant'                  'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LGORT'        'SLoc'                   'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'CHARG'        'Batch'                  'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MEINS'        'BUn'                    'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LGPLA'        'Stor. Bin'              'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'ZLHMG1'       'Remaining Qty'          'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MEINS'        'BUn'                    'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LHME1'        'Un'                     'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LHMG1'        'Box Quantity'           'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MEINS'        'BUn'                    'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LETY1'        'SUT'                    'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'ZBATCH_STK'   'Quantity'               'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MTART'        'MTyp'                   'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'LVORM'        'Clt'                    'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'BISMT'        'Old Material No.'       'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'DISPO'        'MRP Controller'         'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'BUDAT'        'SU Date'                'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'MAKTX'        'Material Desc.'         'X' 'IT_FINAL' .
  PERFORM fieldcat_append  USING  'DSNAM'        'Prod Supervisor'        'X' 'IT_FINAL' .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0045   text
*      -->P_0046   text
*      -->P_0047   text
*      -->P_0048   text
*----------------------------------------------------------------------*
FORM fieldcat_append  USING    VALUE(p_fname)
                               VALUE(p_ftext)
                               VALUE(p_fixcol)
                               VALUE(p_table).

  it_fieldcat-fieldname   = p_fname.
  it_fieldcat-seltext_l   = p_ftext.
  it_fieldcat-fix_column  = p_fixcol.
  it_fieldcat-tabname     = p_table.

  APPEND it_fieldcat.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_data .

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program     = sy-repid
*     i_callback_pf_status_set = 'PF_STATUS'
*     i_callback_user_command  = 'USER_COMMAND'
      i_callback_top_of_page = 'TOP_OF_PAGE'
      is_layout              = wa_layout
      it_fieldcat            = it_fieldcat[]
      it_events              = t_event[]
      i_save                 = 'A'
    TABLES
      t_outtab               = it_final[]
    EXCEPTIONS
      program_error          = 1
      OTHERS                 = 2.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.

ENDFORM.
